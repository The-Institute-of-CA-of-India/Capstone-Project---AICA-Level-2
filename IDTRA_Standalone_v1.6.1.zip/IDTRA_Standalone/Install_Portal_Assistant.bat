@echo off
title Install GST Portal Assistant (optional)
cd /d "%~dp0"
echo The GST Portal Assistant fills the GST login (you type only the CAPTCHA) and downloads the returns
echo automatically. It is optional: you can always download the returns yourself and import them.
echo It needs about 40 MB and an internet connection (or the add-on folder 'wheels_extra').
echo.
if not exist "%~dp0venv\Scripts\python.exe" (
  echo Run Start_IDTRA.bat once first.
  pause
  exit /b 1
)
if exist "%~dp0wheels_extra" (
  "%~dp0venv\Scripts\python.exe" -m pip install --no-index --find-links "%~dp0wheels_extra" --find-links "%~dp0wheels" playwright
) else (
  "%~dp0venv\Scripts\python.exe" -m pip install playwright
)
if errorlevel 1 (
  echo.
  echo Installation failed - check the internet connection and try again.
) else (
  echo.
  echo GST Portal Assistant installed. It uses your Google Chrome or Microsoft Edge - no other download is needed.
)
pause
