@echo off
rem Opens the Inverted Tax Duty Refund Application in its own app window.
set "URL=http://127.0.0.1:8765"
set "B=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%B%" goto run
set "B=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%B%" goto run
set "B=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%B%" goto run
set "B=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%B%" goto run
set "B=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if exist "%B%" goto run
start "" "%URL%"
exit /b
:run
start "" "%B%" --app=%URL% --window-size=1440,900
