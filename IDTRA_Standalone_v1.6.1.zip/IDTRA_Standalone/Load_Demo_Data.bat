@echo off
title Load demo company
cd /d "%~dp0"
set "IDTRA_CONFIG_DIR=%~dp0config"
set "IDTRA_DATA_ROOT=%~dp0IDTRA_Data"
if not exist "%~dp0venv\Scripts\python.exe" (
  echo Run Start_IDTRA.bat once first.
  pause
  exit /b 1
)
cd /d "%~dp0app"
"%~dp0venv\Scripts\python.exe" -m idtra.demo "%~dp0Sample_Data"
echo.
echo Open the application (Start_IDTRA.bat) - All Claims - Sunrise Polysacks Pvt Ltd (DEMO).
pause
