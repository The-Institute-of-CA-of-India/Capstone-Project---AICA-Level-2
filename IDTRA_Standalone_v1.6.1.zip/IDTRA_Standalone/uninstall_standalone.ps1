# Inverted Tax Duty Refund Application - STANDALONE uninstall.
#   -Folder   the standalone folder to remove (default: this folder)
#   -Migrate  copy that folder's data (database, client folders, encryption key) into -Target first
#   -Quiet    no questions (used by the setup of a newer version)
param([string]$Folder = "", [string]$Target = "", [switch]$Migrate, [switch]$Quiet, [switch]$DeleteData)
$ErrorActionPreference = "Continue"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Folder) { $Folder = $Here }
$Folder = (Resolve-Path $Folder -ErrorAction SilentlyContinue).Path
function Say($t, $c = "Cyan") { Write-Host $t -ForegroundColor $c }

# an older copy in another folder (its desktop icon) - offer to remove that one instead
if (-not $Quiet) {
    try {
        $ws1 = New-Object -ComObject WScript.Shell
        $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "IDTRA (Standalone).lnk"
        if (Test-Path $lnk) {
            $other = Split-Path -Parent $ws1.CreateShortcut($lnk).TargetPath
            if ($other -and (Test-Path "$other\app\idtra") -and ($other.TrimEnd('\') -ne $Folder.TrimEnd('\'))) {
                Say "Another copy is installed in $other (the desktop icon opens that one)." Yellow
                Say "  1 = uninstall that OTHER copy ($other)"
                Say "  2 = uninstall THIS copy ($Folder)"
                if ((Read-Host "Choose 1 or 2 [1]") -ne "2") {
                    $Folder = $other
                    if ($Folder -ne $Here -and (Test-Path "$Here\app\idtra")) {
                        $m = Read-Host "Copy its data (clients, claims, files) into $Here first? (Y/N) [Y]"
                        if ($m -notmatch "^[Nn]") { $Migrate = $true; $Target = $Here }
                    }
                }
            }
        }
    } catch {}
}
if (-not $Folder -or -not (Test-Path "$Folder\app\idtra")) { Say "No IDTRA standalone installation found in '$Folder'." Yellow; exit 1 }

$ver = "?"
try { $ver = (Select-String -Path "$Folder\app\idtra\__init__.py" -Pattern 'APP_VERSION = "([^"]+)"').Matches[0].Groups[1].Value } catch {}
Say "Uninstalling IDTRA standalone version $ver in $Folder" Cyan

# 1. stop the program if it is running from that folder (or any copy still listening)
Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*idtra.server*' -or $_.CommandLine -like '*portal_assistant*' } |
    ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
Start-Sleep -Seconds 2

# 2. move the data to the new version if asked
$hasData = (Test-Path "$Folder\IDTRA_Data\_Database\idtra.db")
if ($Migrate -and $Target -and $hasData) {
    if (Test-Path "$Target\IDTRA_Data\_Database\idtra.db") {
        Say "The new version already has its own data - the old data is kept in $Folder\IDTRA_Data (not copied)." Yellow
        $DeleteData = $false
    } else {
        Say "Copying your data (database, client folders, encryption key) to $Target ..." Cyan
        New-Item -ItemType Directory -Force -Path "$Target\config", "$Target\IDTRA_Data" | Out-Null
        Copy-Item "$Folder\IDTRA_Data\*" "$Target\IDTRA_Data\" -Recurse -Force
        if (Test-Path "$Folder\config\secret.key") { Copy-Item "$Folder\config\secret.key" "$Target\config\secret.key" -Force }
        if (-not (Test-Path "$Target\IDTRA_Data\_Database\idtra.db")) { Say "Copy failed - nothing was deleted." Red; exit 1 }
        Say "Data copied." Green
        $DeleteData = $true
    }
}

if (-not $Quiet) {
    if ($hasData -and -not $Migrate) {
        Say "`nThis folder holds data (database and client folders in IDTRA_Data, key in config)." Yellow
        $a = Read-Host "Delete the DATA as well? Type YES to delete it, or press Enter to keep it"
        $DeleteData = ($a -eq "YES")
    }
    $c = Read-Host "Remove the program from $Folder now? (Y/N) [Y]"
    if ($c -match "^[Nn]") { exit 2 }
}

# 3. desktop / start-menu shortcuts that point to that folder
$ws = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))) {
    Get-ChildItem -Path $dir -Filter "*.lnk" -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $t = $ws.CreateShortcut($_.FullName).TargetPath
            if ($t -and $t.StartsWith($Folder.TrimEnd("\") + "\", [StringComparison]::OrdinalIgnoreCase)) { Remove-Item $_.FullName -Force; Say "Removed shortcut $($_.Name)" }
        } catch {}
    }
}

# 4. program files (data only if confirmed / migrated)
$keep = @("IDTRA_Data", "config")
if ($DeleteData) { $keep = @() }
Get-ChildItem -Path $Folder -Force | Where-Object { $keep -notcontains $_.Name -and $_.Name -ne "uninstall_standalone.ps1" -and $_.Name -ne "Uninstall_IDTRA.bat" } |
    ForEach-Object { Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
Remove-Item "$env:LOCALAPPDATA\IDTRA\portal-profile-*" -Recurse -Force -ErrorAction SilentlyContinue
if ($DeleteData) {
    Say "Program and data removed from $Folder." Green
    # the folder itself (with this script) is removed after this window closes
    Start-Process -WindowStyle Hidden cmd.exe -ArgumentList "/c timeout /t 3 >nul & rmdir /s /q `"$Folder`""
} else {
    Say "Program removed. Your data is still in $Folder\IDTRA_Data and $Folder\config (delete the folder yourself when no longer needed)." Green
}
exit 0
