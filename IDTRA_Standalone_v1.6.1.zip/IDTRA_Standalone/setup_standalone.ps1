# Inverted Tax Duty Refund Application - STANDALONE (single laptop) first-time setup.
# No administrator rights needed. Everything stays inside this folder.
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Say($t, $c = "Cyan") { Write-Host $t -ForegroundColor $c }

Get-ChildItem -Path $Here -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
Say "=================================================================" Magenta
Say "  Inverted Tax Duty Refund Application - STANDALONE SETUP" Magenta
Say "=================================================================" Magenta

function Find-Python {
    $cands = @()
    foreach ($v in @("3.14", "3.15", "3.13", "3.12", "3.11", "3.10")) {
        try { $p = & py "-$v" -c "import sys;print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { $cands += $p.Trim() } } catch {}
    }
    foreach ($cmd in @("python", "python3")) {
        try {
            $p = & $cmd -c "import sys;print(sys.executable if sys.version_info>=(3,10) else '')" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p -and ($p -notmatch "WindowsApps")) { $cands += $p.Trim() }
        } catch {}
    }
    foreach ($base in @("$env:LOCALAPPDATA\Programs\Python\Python313", "$env:LOCALAPPDATA\Programs\Python\Python312",
                        "$env:LOCALAPPDATA\Programs\Python\Python314", "$env:LOCALAPPDATA\Programs\Python\Python315", "$env:LOCALAPPDATA\Programs\Python\Python311",
                        "$env:LOCALAPPDATA\Programs\Python\Python310", "$env:ProgramFiles\Python313", "$env:ProgramFiles\Python312",
                        "$env:ProgramFiles\Python314", "$env:ProgramFiles\Python315", "$env:ProgramFiles\Python311", "$env:ProgramFiles\Python310")) {
        if (Test-Path "$base\python.exe") { $cands += "$base\python.exe" }
    }
    return ($cands | Where-Object { $_ } | Select-Object -First 1)
}

Say "`n[1/4] Checking Python 3.10 or later ..."
$Py = Find-Python
if (-not $Py) {
    $local = Get-ChildItem -Path $Here -Filter "python-3*.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($local) {
        Say "Installing $($local.Name) for this user ..." Yellow
        Start-Process -Wait -FilePath $local.FullName -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0"
    } else {
        Say "Python not found - installing Python 3.14 for this user with winget (needs internet) ..." Yellow
        try { winget install --id Python.Python.3.14 -e --scope user --accept-package-agreements --accept-source-agreements --silent } catch {}
    }
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
    $Py = Find-Python
}
if (-not $Py) {
    Say "Python could not be installed automatically." Red
    Say "Install Python 3.12 (64-bit) from https://www.python.org/downloads/windows/ - tick 'Add python.exe to PATH' - or copy the installer (python-3.12.x-amd64.exe) into this folder, then run Start_IDTRA.bat again." Red
    exit 1
}
Say "Using Python: $Py" Green

Say "`n[2/4] Creating private Python environment ..."
if (-not (Test-Path "$Here\venv\Scripts\python.exe")) { & $Py -m venv "$Here\venv" }
$VPy = "$Here\venv\Scripts\python.exe"

Say "`n[3/4] Installing libraries from the bundled 'wheels' folder (offline) ..."
# 'wheels' holds the libraries for Python 3.13 - 3.15; the optional add-on folder 'wheels_extra' (separate download)
# adds Python 3.10 - 3.12 and the GST Portal Assistant for computers without internet
$links = @("--find-links", "$Here\wheels")
if (Test-Path "$Here\wheels_extra") { $links += @("--find-links", "$Here\wheels_extra") }
& $VPy -m pip install --no-index @links -r "$Here\requirements.txt" --quiet
if ($LASTEXITCODE -ne 0) {
    Say "Offline install incomplete - trying the internet ..." Yellow
    & $VPy -m pip install -r "$Here\requirements.txt" --quiet
    if ($LASTEXITCODE -ne 0) { Say "Library installation failed." Red; exit 1 }
}

if (Test-Path "$Here\wheels_extra\playwright-*.whl") {
    & $VPy -m pip install --no-index @links playwright --quiet
}
Set-Content -Path "$Here\venv\installed_v1.6.1.txt" -Value (Get-Date) -Encoding ASCII
Say "`n[4/4] Running the self test on this laptop (about 1 minute) ..."
& "$Here\Run_Self_Test.bat" /quiet
if ($LASTEXITCODE -eq 0) { Say "Self test PASSED." Green } else { Say "Self test FAILED - see $env:TEMP\idtra_selftest.log (the application will still start)." Red }

# older standalone copy in another folder (found through its desktop icon) -> move its data here and uninstall it
try {
    $ws0 = New-Object -ComObject WScript.Shell
    $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "IDTRA (Standalone).lnk"
    if (Test-Path $lnk) {
        $oldDir = Split-Path -Parent $ws0.CreateShortcut($lnk).TargetPath
        if ($oldDir -and (Test-Path "$oldDir\app\idtra") -and ((Resolve-Path $oldDir).Path.TrimEnd('\') -ne $Here.TrimEnd('\'))) {
            $ov = "?"
            try { $ov = (Select-String -Path "$oldDir\app\idtra\__init__.py" -Pattern 'APP_VERSION = "([^"]+)"').Matches[0].Groups[1].Value } catch {}
            Say "`nAn older version ($ov) is installed in $oldDir." Yellow
            Say "Its desktop icon still opens the OLD version." Yellow
            $a = Read-Host "Move its data (clients, claims, files) to this version and uninstall the old one? (Y/N) [Y]"
            if ($a -notmatch "^[Nn]") {
                & powershell -NoProfile -ExecutionPolicy Bypass -File "$Here\uninstall_standalone.ps1" -Folder $oldDir -Target $Here -Migrate -Quiet
                if ($LASTEXITCODE -eq 0) { Say "Old version removed; its data now opens in this version." Green }
            } else {
                Say "Old version kept. Use Uninstall_IDTRA.bat in $oldDir to remove it later." Yellow
            }
        }
    }
} catch { Say "Could not check for an older version: $($_.Exception.Message)" Yellow }

# desktop shortcut
try {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "IDTRA (Standalone).lnk"))
    $sc.TargetPath = "$Here\Start_IDTRA.bat"; $sc.WorkingDirectory = $Here; $sc.IconLocation = "$Here\IDTRA.ico"; $sc.WindowStyle = 7
    $sc.Save()
} catch {}
Say "`nSetup complete. A desktop icon 'IDTRA (Standalone)' has been created." Green
exit 0
