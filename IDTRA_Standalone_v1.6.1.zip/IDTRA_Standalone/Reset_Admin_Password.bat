@echo off
title Reset administrator login - Inverted Tax Duty Refund Application
rem Put this file in the standalone folder (the folder with Start_IDTRA.bat) and double-click it.
if not exist "%~dp0venv\Scripts\python.exe" (
  echo Copy this file into the folder that contains Start_IDTRA.bat, app and venv, then run it again.
  pause
  exit /b 1
)
set "IDTRA_CONFIG_DIR=%~dp0config"
set "IDTRA_DATA_ROOT=%~dp0IDTRA_Data"
set "PY=%~dp0venv\Scripts\python.exe"
cd /d "%~dp0app"
echo This resets the APPLICATION login to   admin / admin@123
echo (clients, claims and files are NOT changed; you will be asked to set a new password).
choice /M "Reset now"
if errorlevel 2 exit /b
"%PY%" -c "exec(open(r'%~f0', encoding='utf-8').read().split('#PYTHON' + '#')[1])"
if errorlevel 1 echo Reset failed - see the message above.
echo.
echo Now open the application and log in with  admin / admin@123
pause
exit /b
#PYTHON#
import sys, os
sys.path.insert(0, os.getcwd())
from idtra import config, db, security
c = config.load()
db.init(c["db_path"])
u = db.q1("SELECT id FROM users WHERE username='admin'")
h = security.hash_pw("admin@123")
if u:
    db.x("UPDATE users SET pw_hash=?, role='admin', active=1 WHERE id=?", (h, u["id"]))
else:
    db.insert("users", dict(username="admin", full_name="Administrator", pw_hash=h, role="admin", created_at=db.now()))
db.set_setting("force_pw_change_admin", "1")
try:
    db.audit("system", "Administrator password reset", None, "Reset_Admin_Password.bat")
except Exception:
    pass
print()
print("  Administrator login reset.   User name: admin    Password: admin@123")
print("  Other users in this database: " + ", ".join(r["username"] for r in db.q("SELECT username FROM users WHERE active=1")))
print("  Database: " + str(c["db_path"]))
