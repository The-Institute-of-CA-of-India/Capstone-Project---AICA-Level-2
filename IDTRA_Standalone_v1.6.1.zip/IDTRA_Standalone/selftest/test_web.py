"""Drive the whole workflow through the web application (Flask test client)."""
import io
import os
import re
import sys
import shutil
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "app"))
TMP = Path(tempfile.mkdtemp(prefix="idtra_web_"))
os.environ["IDTRA_CONFIG_DIR"] = str(TMP / "config")
os.environ["IDTRA_DATA_ROOT"] = str(TMP / "data")
from idtra import db  # noqa
from idtra.web import create_app  # noqa

app = create_app()
app.testing = True
c = app.test_client()
S = HERE / "samples"


def csrf():
    with c.session_transaction() as s:
        return s.get("_csrf")


def ok(r, *needles):
    assert r.status_code in (200, 302), (r.status_code, r.data[:2000])
    body = r.data.decode("utf-8", "ignore")
    for n in needles:
        assert n in body, f"'{n}' not found in page"
    return body


def post(url, data=None, files=None, follow=True):
    data = dict(data or {})
    data["_csrf"] = csrf()
    if files:
        data.update(files)
        return c.post(url, data=data, content_type="multipart/form-data", follow_redirects=follow)
    return c.post(url, data=data, follow_redirects=follow)


def flashes(body):
    return re.findall(r'<div class="flash (\w+)">(.*?)</div>', body)


ok(c.get("/login"), "Inverted Tax Duty Refund Application")
c.get("/login")
body = ok(post("/login", {"username": "admin", "password": "admin@123"}), "change the default administrator password")
ok(post("/profile", {"old": "admin@123", "new": "Admin@2026", "new2": "Admin@2026"}), "Password changed")
# CSRF protection
r = c.post("/settings", data={"firm_name": "x"})
assert r.status_code == 400
ok(post("/settings", {"firm_name": "ABC & Associates", "firm_frn": "123456W", "firm_city": "Pune", "trading_min_gp": "10"}), "Firm settings saved")
ok(post("/users/save", {"username": "staff1", "full_name": "Staff One", "role": "staff", "password": "staff@1", "active": "on"}), "User staff1 saved")
ok(post("/ca/new", {"ca_name": "CA Priya Shah", "membership_no": "123456", "designation": "Partner",
                    "firm_name": "ABC & Associates", "frn": "123456W", "city": "Pune", "active": "on"}), "CA details saved")
# invalid GSTIN rejected
ok(post("/clients/new", {"legal_name": "Bad", "gstin": "12345"}), "GSTIN format is invalid")
body = ok(post("/clients/new", {"legal_name": "Sunrise Polysacks Pvt Ltd", "gstin": "27AAACS1234F1Z5", "state": "Maharashtra",
                                "constitution": "Private Limited Company", "filing_freq": "Monthly",
                                "address": "Plot 12, MIDC Bhosari, Pune 411026", "gst_username": "sunrise_gst",
                                "gst_password": "Secret@123", "sig_name": "Rajesh Mehta", "sig_desg": "Director",
                                "sig_pan": "ABCPM1234K", "sig_mobile": "9800000000", "sig_default": "0"}), "Client saved")
r = c.post("/clients/1/secret", headers={"X-CSRF": csrf()})
assert r.json["password"] == "Secret@123", r.json
assert (TMP / "data" / "Sunrise Polysacks Pvt Ltd").is_dir()

body = ok(post("/claims/new", {"client_id": "1", "period_from": "2026-07", "period_to": "2026-09",
                               "filing_date": "2026-11-20", "same_fy": "on"}), "Claim opened", "Jul-2026")
assert (TMP / "data" / "Sunrise Polysacks Pvt Ltd" / "2026-27" / "Jul-2026 to Sep-2026" / "01_Portal_Downloads").is_dir()
# compute blocked before recon
ok(post("/claims/1/compute"), "Run the reconciliation first")

files = [(open(p, "rb"), p.name) for p in sorted(S.glob("GSTR*.json"))]
body = ok(post("/claims/1/portal/upload", files={"files": files}), "GSTR2B Sep-2026 imported")
# Excel and PDF formats through the upload screen (re-import of Aug: same data)
OF = S / "other_formats"
body = ok(post("/claims/1/portal/upload", {"rtype": "", "month": ""},
               files={"files": [(open(OF / "GSTR3B_27AAACS1234F1Z5_082026.pdf", "rb"), "GSTR3B_27AAACS1234F1Z5_082026.pdf"),
                                (open(OF / "GSTR2B_27AAACS1234F1Z5_082026.xlsx", "rb"), "GSTR2B_27AAACS1234F1Z5_082026.xlsx"),
                                (open(OF / "GSTR1_Excel_27AAACS1234F1Z5_082026.xlsx", "rb"), "GSTR1_Excel_27AAACS1234F1Z5_082026.xlsx")]}),
          "GSTR3B Aug-2026 imported", "read from the PDF", "GSTR2B Aug-2026 imported", "GSTR1 Aug-2026 imported")
# Excel workbook without month in the name -> month selected on screen is used
body = ok(post("/claims/1/portal/upload", {"rtype": "GSTR1", "month": "2026-08"},
               files={"files": [(open(OF / "GSTR1_Excel_27AAACS1234F1Z5_082026.xlsx", "rb"), "my_gstr1.xlsx")]}), "GSTR1 Aug-2026 imported")
ok(post("/claims/1/portal/upload", {}, files={"files": [(io.BytesIO(b"hello"), "notes.docx")]}), "Unsupported file type")
ok(c.get("/claims/1?tab=portal"), "Download from GST portal", "Import files from folder")
# wrong GSTIN file rejected
bad = io.BytesIO(b'{"gstin":"29AAACK8888U1Z6","fp":"072026","b2b":[]}')
body = ok(post("/claims/1/portal/upload", files={"files": [(bad, "x.json")]}), "does not match client GSTIN")
# outside period rejected
bad = io.BytesIO(b'{"gstin":"27AAACS1234F1Z5","fp":"012026","b2b":[]}')
body = ok(post("/claims/1/portal/upload", files={"files": [(bad, "y.json")]}), "outside the claim period")

for reg, fn in (("Sales", "Sales_Register_Tally.xlsx"), ("Purchase", "Purchase_Register_Tally.xlsx"),
                ("Expense", "Expense_Register_Tally.xlsx")):
    body = ok(post("/claims/1/books/upload", {"register": reg}, files={"file": (open(S / fn, "rb"), fn)}),
              "imported: ")
ok(c.get("/claims/1?tab=books"), "3926", "Same HSN sold")
ok(post("/claims/1/books/trading", {"trading": ["3926"]}), "Trading goods updated")
body = ok(post("/claims/1/recon"), "Reconciliation completed")
body = ok(c.get("/claims/1?tab=recon"), "Not in GSTR-2B", "Value mismatch")
body = ok(c.get("/claims/1?tab=queries"), "open query")
ok(post("/claims/1/compute"), "must be resolved before computing")
# close queries - a response is mandatory
qids = [q["id"] for q in db.q("SELECT id FROM queries WHERE claim_id=1 AND status='Open'")]
ok(post("/claims/1/queries", {"qid": qids[0], "status": "Accepted", "response": ""}), "response / reason is required")
for q in qids:
    ok(post("/claims/1/queries", {"qid": q, "status": "Accepted", "response": "Supplier contacted; ITC restricted to 2B."}), "Query updated")
ok(post("/claims/1/queries", {"new": "1", "reference": "General", "description": "Confirm HSN 6305 classification", "amount": "0"}), "Query posted")
mq = db.q1("SELECT id FROM queries WHERE claim_id=1 AND status='Open'")["id"]
ok(post("/claims/1/queries", {"qid": mq, "status": "Resolved", "response": "Confirmed with client - HDPE woven sacks"}), "Query updated")

ok(c.get("/claims/1?tab=compute"), "Inverted?", "6305")
ok(post("/claims/1/ecl", {"end_period_date": "2026-09-30", "end_period_igst": "900000", "end_period_cgst": "600000",
                          "end_period_sgst": "600000", "at_filing_date": "2026-11-20", "at_filing_igst": "850000",
                          "at_filing_cgst": "650000", "at_filing_sgst": "640000", "turnover_4a4b": "0",
                          "formula_version": "V2022", "override_reason": ""}), "Give a reason")
ok(post("/claims/1/ecl", {"end_period_date": "2026-09-30", "end_period_igst": "900000", "end_period_cgst": "600000",
                          "end_period_sgst": "600000", "at_filing_date": "2026-11-20", "at_filing_igst": "850000",
                          "at_filing_cgst": "650000", "at_filing_sgst": "640000", "turnover_4a4b": "0",
                          "formula_version": "V2026", "trading_method": "gross_up", "gp_basis": "sales",
                          "gp_percent": "15"}), "balances and options saved")
body = ok(post("/claims/1/compute"), "Refund computed: Rs 8,62,970", "deemed trading turnover 5,29,411.76")
ok(post("/claims/1/ecl", {"end_period_igst": "900000", "end_period_cgst": "600000", "end_period_sgst": "600000",
                          "at_filing_igst": "850000", "at_filing_cgst": "650000", "at_filing_sgst": "640000",
                          "formula_version": "V2026", "gp_percent": "120"}), "between 0 and 100")
ok(post("/claims/1/ecl", {"end_period_date": "2026-09-30", "end_period_igst": "900000", "end_period_cgst": "600000",
                          "end_period_sgst": "600000", "at_filing_date": "2026-11-20", "at_filing_igst": "850000",
                          "at_filing_cgst": "650000", "at_filing_sgst": "640000", "turnover_4a4b": "0",
                          "formula_version": "V2026", "trading_method": "identified"}), "balances and options saved")
body = ok(post("/claims/1/compute"), "Refund computed: Rs 8,89,781", "8,89,781")
# staff cannot approve
c2 = app.test_client()
c2.get("/login")
with c2.session_transaction() as s:
    t2 = s["_csrf"]
c2.post("/login", data={"username": "staff1", "password": "staff@1", "_csrf": t2})
c2.get("/")
with c2.session_transaction() as s:
    t2 = s["_csrf"]
r = c2.post("/claims/1/approve", data={"_csrf": t2})
assert r.status_code == 403
ok(c2.get("/claims/1?tab=compute"), "8,89,781")

ok(post("/claims/1/docs", {"action": "declarations", "signatory_id": "1"}), "must be approved first")
ok(post("/claims/1/approve"), "approved and locked")
r = post("/claims/1/recon", follow=False)
assert r.status_code == 403
ok(post("/claims/1/docs", {"action": "declarations", "signatory_id": "1"}), "Applicant declarations generated")
ok(post("/claims/1/docs", {"action": "udin", "udin": "26123456ABCDEF1234"}), "Generate the CA certificate first")
ok(post("/claims/1/docs", {"action": "ca_cert", "ca_id": "1"}), "CA certificate generated")
ok(post("/claims/1/docs", {"action": "udin", "udin": "BAD"}), "18 alphanumeric")
ok(post("/claims/1/docs", {"action": "udin", "udin": "26999999ABCDEF1234", "udin_date": "2026-11-19"}), "do not match membership")
ok(post("/claims/1/docs", {"action": "udin", "udin": "26123456ABCDEF1234", "udin_date": "2026-11-19"}), "UDIN saved")
ok(post("/claims/1/docs", {"action": "upload_files"}), "Annexure-B validated")
body = ok(c.get("/claims/1?tab=documents"), "Annexure-B JSON (upload on portal)", "Annexure-B Excel (utility layout)", "FINAL with UDIN 26123456ABCDEF1234", "Net ITC after reversals")
for d in db.q("SELECT id, file_path FROM documents WHERE claim_id=1"):
    r = c.get(f"/claims/1/file/{d['id']}")
    assert r.status_code == 200 and len(r.data) > 100, d
r = c.get("/claims/1/zip")
assert r.status_code == 200 and r.data[:2] == b"PK"
for page in ("/", "/clients", "/clients/1", "/ca", "/law", "/claims", "/settings", "/audit", "/claims/1",
             "/claims/1?tab=portal", "/claims/1?tab=books", "/claims/1?tab=recon&f=all", "/template/Purchase"):
    r = c.get(page)
    assert r.status_code == 200, (page, r.status_code, r.data[:500])
ok(post("/backup"), "Backup created")
ok(post("/law", {"hsn_prefix": "9999", "description": "test", "notification": "x/2026", "applies_to": "Warn"}), "Law library updated")
# ---------------- SCN / notices
ok(c.get("/claims/1?tab=scn"), "Upload a show cause notice", "No notice received")
body = ok(post("/claims/1/notices/new", {"notice_type": "", "received_date": "2026-12-03", "amount_proposed": "145000"},
               files={"file": (open(S / "Sample_SCN_RFD-08.pdf", "rb"), "Sample_SCN_RFD-08.pdf")}),
          "Notice saved", "ITC not reflected in GSTR-2A / 2B", "Trading / same input and output",
          "Input services / capital goods included", "ITC in refund vs GSTR-3B")
n = db.q1("SELECT * FROM notices WHERE claim_id=1")
assert n["notice_type"].startswith("RFD-08") and n["due_date"] == "2026-12-18", n
assert n["ref_no"] == "ZD2711260012345" and n["arn"].startswith("AA271126012345K") and n["notice_date"] == "2026-12-02", n
assert n["status"] == "Analysed"
gr = db.q("SELECT * FROM notice_grounds WHERE notice_id=?", (n["id"],))
codes = {g["code"] for g in gr}
assert {"G01", "G02", "G03", "G15"} <= codes, codes
g03 = [g for g in gr if g["code"] == "G03"][0]
assert "1,28,469.06" in [g for g in gr if g["code"] == "G01"][0]["allegation"]
assert "Circular No. 135/05/2020" in g03["reply_text"] and "trading purchases" in g03["reply_text"]
# edit: drop one ground, add one from library and one own ground, regenerate another
form = {}
for g in gr:
    form[f"inc_{g['id']}"] = "on"
    form[f"title_{g['id']}"] = g["title"]
    form[f"alleg_{g['id']}"] = g["allegation"]
    form[f"reply_{g['id']}"] = g["reply_text"] + (" EDITED-BY-USER" if g["code"] == "G01" else "")
    form[f"sort_{g['id']}"] = str(g["sort"])
drop = [g for g in gr if g["code"] not in ("G01", "G02", "G03", "G15")]
if drop:
    form[f"del_{drop[0]['id']}"] = "on"
form.update({"add_code": "G06", "new_title": "Interest under section 56", "new_reply": "Interest is payable for delay."})
ok(post(f"/notices/{n['id']}/grounds", form), "Grounds and replies saved")
gr2 = db.q("SELECT * FROM notice_grounds WHERE notice_id=?", (n["id"],))
assert any(g["code"] == "G06" for g in gr2) and any(g["title"] == "Interest under section 56" for g in gr2)
assert any("EDITED-BY-USER" in g["reply_text"] for g in gr2)
# re-analyse keeps manual grounds
ok(post(f"/notices/{n['id']}/text", {"notice_text": n["notice_text"]}), "Manually added grounds were kept")
assert any(g["title"] == "Interest under section 56" for g in db.q("SELECT * FROM notice_grounds WHERE notice_id=?", (n["id"],)))
body = ok(post(f"/notices/{n['id']}/reply", {"signatory_id": "1", "extra_docs": "E-way bills"}), "Draft reply")
fl = db.q("SELECT * FROM notice_files WHERE notice_id=?", (n["id"],))
kinds = {f["kind"] for f in fl}
assert {"Notice (as received)", "Draft reply (Word)", "SCN analysis (Excel)"} <= kinds, kinds
from docx import Document as _D
rp = [f for f in fl if f["kind"] == "Draft reply (Word)"][0]
_doc = _D(str(TMP / "data" / rp["file_path"]))
txt = "\n".join(p.text for p in _doc.paragraphs) + "\n".join(c.text for t_ in _doc.tables for r_ in t_.rows for c in r_.cells)
for frag in ("FORM GST RFD-09", "ZD2711260012345", "BRIEF FACTS", "Ground 1", "PRAYER", "personal hearing",
             "Interest under section 56", "E-way bills", "VERIFICATION", "Rajesh Mehta"):
    assert frag in txt, frag
assert "08_SCN_and_Replies" in rp["file_path"]
for f in fl:
    assert c.get(f"/notices/{n['id']}/file/{f['id']}").status_code == 200
# tracking: reply filed, order received -> appeal due date
ok(post(f"/notices/{n['id']}/save", {"notice_type": n["notice_type"], "ref_no": n["ref_no"], "received_date": "2026-12-03",
                                     "status": "Order received", "reply_date": "2026-12-15", "order_date": "2027-01-20",
                                     "order_result": "Partly sanctioned", "amount_sanctioned": "800000",
                                     "amount_rejected": "89781"}), "Notice details saved", "20-04-2027")
ok(post(f"/notices/{n['id']}/upload", {"kind": "Order RFD-06"}, files={"file": (io.BytesIO(b"%PDF-1.4 test"), "order.pdf")}),
   "Order RFD-06 uploaded")
ok(c.get("/notices"), "ZD2711260012345", "Partly sanctioned")
# pasted text only (scanned notice) + vague notice
ok(post("/claims/1/notices/new", {"notice_type": "RFD-08 Show cause notice (Rule 92(3))", "received_date": "2026-12-05",
                                  "notice_text": "Reason for rejection: Other. Refund is not admissible."}),
   "Notice does not state specific grounds")
# dashboard shows replies due within 5 days
import datetime as _dt
ok(post("/claims/1/notices/new", {"notice_type": "Personal hearing notice", "received_date": _dt.date.today().isoformat(),
                                  "due_date": (_dt.date.today() + _dt.timedelta(days=2)).isoformat(), "ref_no": "PH-777",
                                  "notice_text": "Personal hearing is fixed regarding refund."}), "Notice saved")
ok(c.get("/"), "Replies due within 5 days", "PH-777")

# re-open and check UDIN cleared
ok(post("/claims/1/reopen", {"reason": "Supplier amended invoice"}), "re-opened")
assert db.q1("SELECT udin, status FROM claims WHERE id=1") == {"udin": None, "status": "Computed"}
# overlapping claim prevented
ok(post("/claims/new", {"client_id": "1", "period_from": "2026-09", "period_to": "2026-10", "filing_date": "2026-12-01"}),
   "overlapping period")
# Nov-Dec 2026 claim: input services from 01.11.2026 enter Net ITC

# ---- new client from GST portal profile: user ID + password only, details arrive from the assistant
ok(c.get("/clients/fetch"), "Log in &amp; fetch details")
ok(c.get("/clients/new"), "Add client from GST portal", "Log in &amp; fetch details from GST portal")
r0 = post("/clients/fetch", {"legal_name": "", "gstin": "", "gst_username": "inline_user", "gst_password": "pw1"}, follow=False)
assert r0.status_code == 302 and "/clients/fetch/" in r0.headers["Location"], r0.headers
r = post("/clients/fetch", {"gst_username": "acme_gst", "gst_password": "Pw@12345"}, follow=False)
pcode = r.headers["Location"].rsplit("/", 1)[-1]
ok(c.get(f"/clients/fetch/{pcode}"), "Waiting for the GST portal", pcode)
jr = c.get(f"/api/profile-job/{pcode}").get_json()
assert jr["kind"] == "profile" and jr["username"] == "acme_gst" and jr["password"] == "Pw@12345", jr
assert c.post(f"/api/profile-job/{pcode}/log", json={"msg": "Logged in"}).status_code == 200
prof = {"data": {"gstin": "24AABCA9876K1Z3", "lgnm": "ACME FILMS LLP", "tradeNam": "ACME", "ctb": "Limited Liability Partnership",
                 "pradr": {"addr": {"bno": "12", "st": "Ring Road", "loc": "Surat", "pncd": "395002"}},
                 "partners": [{"name": "ANIL SHAH", "desig": "Designated Partner"}]}}
rr = c.post(f"/api/profile-job/{pcode}/result", json={"texts": ["Mobile 9876543210 accounts@acme.example"], "jsons": [prof]}).get_json()
assert rr["ok"] and rr["gstin"] == "24AABCA9876K1Z3", rr
assert c.get(f"/clients/fetch/{pcode}.json").get_json()["ready"]
ok(c.get(f"/clients/fetch/{pcode}"), "ACME FILMS LLP", "Anil Shah", "Gujarat")
form = {"v_gstin": "24AABCA9876K1Z3", "person_0": "on"}
for k, v in (("legal_name", "ACME FILMS LLP"), ("trade_name", "ACME"), ("pan", "AABCA9876K"), ("state", "Gujarat"),
             ("constitution", "LLP"), ("address", "12, Ring Road, Surat - 395002"), ("email", "accounts@acme.example"),
             ("phone", "9876543210")):
    form[f"v_{k}"] = v
ok(post(f"/clients/fetch/{pcode}/apply", form), "saved from the GST portal")
nc = db.q1("SELECT * FROM clients WHERE gstin='24AABCA9876K1Z3'")
assert nc and nc["constitution"] == "LLP" and nc["state"] == "Gujarat" and nc["gst_username"] == "acme_gst", nc
assert db.q1("SELECT designation FROM client_signatories WHERE client_id=?", (nc["id"],))["designation"] == "Designated Partner"
assert c.get(f"/api/profile-job/{pcode}").status_code == 410       # used job cannot hand out the password again
print("Profile fetch (web) OK")

# ---- manual route: files saved in the claim's folder, then "Import files from folder"
body = ok(c.get("/claims/1?tab=portal"), "Put_portal_files_here", "Import files from folder", "The folder is empty")
inbox = next((TMP / "data").rglob("Put_portal_files_here"))
shutil.copy(S / "GSTR2B_27AAACS1234F1Z5_082026.json", inbox / "082026_27AAACS1234F1Z5_GSTR2B.json")
shutil.copy(S / "GSTR3B_27AAACS1234F1Z5_092026.json", inbox / "GSTR3B_092026.json")
(inbox / "notes.txt").write_text("not a return")
ok(c.get("/claims/1?tab=portal"), "3 file(s) waiting")
body = ok(post("/claims/1/portal/folder"), "Folder import: 2 file(s) imported", "notes.txt: not imported", "GSTR2B Aug-2026 imported")
assert sorted(f.name for f in inbox.iterdir()) == ["notes.txt"], list(inbox.iterdir())
assert (inbox.parent / "GSTR3B_092026.json").exists()
(inbox / "notes.txt").unlink()
print("Folder import OK")

# ---- purchase returns net against ITC; purchase review (HSN map, trading per line); refresh; remove
from idtra import calc as _calc  # noqa: E402
import openpyxl as _ox  # noqa: E402
cl1 = db.q1("SELECT * FROM claims WHERE id=1")
def _itc(bucket="Inputs"):
    return round(sum(l["e_tax"] for l in _calc.classify_purchases(cl1, "V2026") if l["bucket"] == bucket), 2)
before = _itc()
wbx = _ox.Workbook(); wsx = wbx.active; wsx.title = "Debit Note Register"
wsx.append(["Date", "Particulars", "Voucher Type", "Supplier Invoice No", "GSTIN/UIN", "HSN/SAC", "Rate", "Taxable Value", "IGST", "CGST", "SGST"])
wsx.append(["2026-07-25", "Reliable Polymers Ltd", "Debit Note", "DN/OWN/1", "27AABCR5678K1Z2", "3901", 18, 10000, 0, 900, 900])
bio = io.BytesIO(); wbx.save(bio); bio.seek(0)
ok(post("/claims/1/books/upload", {"register": "Purchase-CN"}, files={"file": (bio, "DebitNoteRegister.xlsx")}), "Purchase returns / supplier credit notes imported")
ret = db.q1("SELECT * FROM book_purchases WHERE claim_id=1 AND src_reg='Purchase-CN'")
assert ret["txval"] == -10000 and ret["cgst"] == -900 and ret["doc_type"] == "Credit Note", ret
ok(post("/claims/1/recon"), "Reconciliation completed")
cl1 = db.q1("SELECT * FROM claims WHERE id=1")
assert abs(_itc() - (before - 1800)) < 0.01, (before, _itc())          # return reduces ITC even if not in GSTR-2B
assert db.q1("SELECT match_status FROM book_purchases WHERE id=?", (ret["id"],))["match_status"] == "Credit note - reduces ITC"
ok(c.get("/claims/1?tab=books"), "Net inward supplies", "Purchase returns / supplier credit notes", "Review purchase register")
body = ok(c.get("/claims/1/purchases"), "HSN and goods description by item", "Trading purchase or not".lower()[:5])
# HSN map for an item description, applied to all its lines and kept for the client
line = db.q1("SELECT * FROM book_purchases WHERE claim_id=1 AND src_reg='Purchase' ORDER BY id LIMIT 1")
from idtra import importer as _imp  # noqa: E402
keys = re.findall(r'name="k_(\d+)" value="([^"]*)"', body)
idx = next(i for i, k in keys if k == _imp.item_key(line).replace("&", "&amp;"))
form = {"form": "map", "count": str(len(keys))}
for i, k in keys:
    form[f"k_{i}"] = k.replace("&amp;", "&")
form[f"h_{idx}"], form[f"d_{idx}"] = "39011010", "LLDPE granules"
ok(post("/claims/1/purchases", form), "HSN and goods description saved")
same = db.q("SELECT * FROM book_purchases WHERE claim_id=1 AND goods_desc='LLDPE granules'")
assert same and all(r["hsn"] == "39011010" and r["hsn_src"] == "map" for r in same), same
assert len(same) == len([r for r in db.q("SELECT * FROM book_purchases WHERE claim_id=1 AND hsn IN ('3901', '39011010')")]), same
assert db.q1("SELECT hsn FROM hsn_map WHERE client_id=1")["hsn"] == "39011010"
# trading decided per line
lid = db.q1("SELECT id FROM book_purchases WHERE claim_id=1 AND src_reg='Purchase' AND is_trading=0 ORDER BY id LIMIT 1")["id"]
lr = db.q1("SELECT * FROM book_purchases WHERE id=?", (lid,))
ok(post("/claims/1/purchases", {"form": "lines", "ids": [str(lid)], f"t_{lid}": "yes", f"c_{lid}": lr["category"],
                                f"h_{lid}": lr["hsn"], f"d_{lid}": lr["goods_desc"] or ""}), "1 purchase line(s) updated")
assert db.q1("SELECT is_trading FROM book_purchases WHERE id=?", (lid,))["is_trading"] == 3
# refresh everything from the stored files: decisions survive
n_gd = db.q1("SELECT COUNT(*) n FROM book_purchases WHERE claim_id=1 AND goods_desc='LLDPE granules'")["n"]
assert n_gd >= len(same) > 0
ok(post("/claims/1/refresh", {"back": "books"}), "Refreshed:")
lr2 = db.q1("SELECT * FROM book_purchases WHERE claim_id=1 AND line_key=?", (lr["line_key"],))
assert lr2["is_trading"] == 3 and lr2["trade_override"] == 1, lr2
assert db.q1("SELECT COUNT(*) n FROM book_purchases WHERE claim_id=1 AND goods_desc='LLDPE granules'")["n"] == n_gd
assert db.q1("SELECT COUNT(*) n FROM book_purchases WHERE claim_id=1 AND src_reg='Purchase-CN'")["n"] == 1
# remove the returns register again
ok(post("/claims/1/books/Purchase-CN/delete"), "removed from this claim")
assert not db.q1("SELECT 1 FROM book_purchases WHERE claim_id=1 AND src_reg='Purchase-CN'")
ok(post("/claims/1/purchases", {"form": "lines", "ids": [str(lr2["id"])], f"t_{lr2['id']}": "auto", f"c_{lr2['id']}": lr2["category"],
                                f"h_{lr2['id']}": lr2["hsn"], f"d_{lr2['id']}": lr2["goods_desc"] or ""}), "updated")
ok(post("/claims/1/recon"), "Reconciliation completed")
print("Purchase returns / review / refresh OK")
print("tree:")
for p in sorted((TMP / "data" / "Sunrise Polysacks Pvt Ltd").rglob("*")):
    print("  ", p.relative_to(TMP / "data"))
print("WEB TESTS PASSED", TMP)
