"""End-to-end test of the engine without the GUI."""
import json
import re
import os
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "app"))
TMP = Path(tempfile.mkdtemp(prefix="idtra_"))
os.environ["IDTRA_CONFIG_DIR"] = str(TMP / "config")
os.environ["IDTRA_DATA_ROOT"] = str(TMP / "data")

from idtra import calc, config, db, docgen, exports, importer, law, recon, security, storage  # noqa

cfg = config.load()
security.init(cfg["key_file"])
db.init(cfg["db_path"])
storage.init(cfg["data_root"])
S = HERE / "samples"

cid_client = db.insert("clients", dict(legal_name="Sunrise Polysacks Pvt Ltd", gstin="27AAACS1234F1Z5",
                                      state="Maharashtra", address="Plot 12, MIDC, Pune", filing_freq="Monthly",
                                      gst_username="sunrise_gst", gst_password_enc=security.encrypt("Secret@123"),
                                      folder_name=storage.client_folder_name("Sunrise Polysacks Pvt Ltd", "27AAACS1234F1Z5"),
                                      created_at=db.now()))
assert security.decrypt(db.q1("SELECT gst_password_enc p FROM clients")["p"]) == "Secret@123"
client = db.q1("SELECT * FROM clients WHERE id=?", (cid_client,))
claim_id = db.insert("claims", dict(client_id=cid_client, fy="2026-27", period_from="2026-07", period_to="2026-09",
                                    filing_date="2026-11-20", status="Draft", created_by="test", created_at=db.now(),
                                    options_json=json.dumps({"trading_method": "identified"})))
claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
folder = storage.claim_dir(claim, client)
print("Claim folder:", storage.rel(folder))

for f in sorted(S.glob("GSTR*.json")):
    dst = folder / "01_Portal_Downloads" / f.name
    shutil.copy(f, dst)
    claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
    print(importer.import_portal(claim, client, dst, "test"))
for f, reg in (("Sales_Register_Tally.xlsx", "Sales"), ("Purchase_Register_Tally.xlsx", "Purchase"),
               ("Expense_Register_Tally.xlsx", "Expense")):
    n, w = importer.import_register(claim, S / f, reg, "test")
    print(reg, n, w)

claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
snap = recon.run(claim, client, "test")
print("Purchase status:", snap["purchase_status"])
for q in db.q("SELECT code, status, amount, description FROM queries WHERE claim_id=?", (claim_id,)):
    print(" Q", q["code"], q["status"], q["amount"], q["description"][:110])

# mark trading HSN 3926 via the list (already flagged in file too)
db.x("INSERT INTO trading_hsn(claim_id,hsn) VALUES(?,?)", (claim_id, "3926"))
importer.apply_trading_hsn(claim_id)
claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
snap = recon.run(claim, client, "test")
print("Open queries after trading flag:", recon.open_queries(claim_id))
# resolve all queries
db.x("UPDATE queries SET status='Accepted', response='Checked - supplier to amend', resolved_by='test', "
     "resolved_at=? WHERE claim_id=? AND status='Open'", (db.now(), claim_id))
assert recon.open_queries(claim_id) == 0

db.x("INSERT INTO ecl_balances(claim_id,kind,igst,cgst,sgst,as_on) VALUES(?,?,?,?,?,?)",
     (claim_id, "end_period", 900000, 600000, 600000, "2026-09-30"))
db.x("INSERT INTO ecl_balances(claim_id,kind,igst,cgst,sgst,as_on) VALUES(?,?,?,?,?,?)",
     (claim_id, "at_filing", 850000, 650000, 640000, "2026-11-20"))
res = calc.compute(claim, client)
print(json.dumps({k: res[k] for k in ("version", "turnover", "refund", "trading_purchases", "warnings")}, indent=1))
for k, v in res["versions"].items():
    print(k, "net_itc", v["net_itc"], "itc_in+serv", v["itc_inputs_services"], "max", v["max_refund"], v["buckets"].keys())

# ---- independent hand check of V2026 / V2022
t = res["turnover"]
v22 = res["versions"]["V2022"]
exp22 = t["inverted"] * v22["net_itc"] / t["att"] - t["tax_inverted"] * v22["net_itc"] / v22["itc_inputs_services"]
assert abs(exp22 - v22["raw"]) < 0.05, (exp22, v22["raw"])
v26 = res["versions"]["V2026"]
exp26 = t["inverted"] * v26["net_itc"] / t["att"] - t["tax_inverted"]
assert abs(exp26 - v26["raw"]) < 0.05
assert v26["net_itc"] == v22["net_itc"], "input services before 01.11.2026 must be excluded under V2026"
heads = res["refund"]["heads"]
assert sum(heads.values()) == res["refund"]["amount"], heads
calc.save(claim, res, "test", final=True)

out = folder / "04_Computation"
exports.workings_xlsx(out / "Workings.xlsx", claim, client, res, snap)
from idtra import annexb
out = annexb.generate(folder / "07_Upload_Files", "T1", claim, client, res)
print("ANNEXURE-B rows", out["rows"], "errors", out["errors"][:5], "files", [p.name for p in out["jsons"]])
assert not out["errors"], out["errors"]
js = json.loads(out["jsons"][0].read_text())
# exact key order written by the department utility's CreateJson macro
assert list(js.keys()) == ["gstin", "fromFp", "toFp", "version", "revCGST", "revSGST", "revIGST", "revCess",
                           "revOthCGST", "revOthSGST", "revOthIGST", "revOthCess", "stmt"], js.keys()
inv = js["stmt"][0]["invoices"]
assert list(inv[0].keys()) == ["sno", "typeOfInwardSupply", "istype", "stin", "snm", "inum", "idt", "portCode", "val",
                               "catOfInv", "hsnSac", "camt", "samt", "iamt", "cessamt", "totCredit", "isItcBlocked",
                               "elgItc", "elgItcAmt", "returnPeriod2B", "inelgItcAmt"]
assert js["fromFp"] == "072026" and js["toFp"] == "092026" and js["version"] == "1.0"
for r in inv:
    assert abs(r["elgItcAmt"] + r["inelgItcAmt"] - r["totCredit"]) < 0.005
    assert r["istype"] in annexb.DOC_TYPES and r["typeOfInwardSupply"] in annexb.SUPPLY_TYPES
    assert re.match(r"^\d{2}-\d{4}$", r["returnPeriod2B"]) and re.match(r"^\d{2}-\d{2}-\d{4}$", r["idt"])
assert not any(r["catOfInv"] == "Inputs" and r["hsnSac"] == "3926" for r in inv), "trading excluded by default"
assert sum(1 for r in inv if r["elgItc"] == "No") == 1 and sum(1 for r in inv if r["elgItc"] == "Partially") == 1
print("sample JSON row:", inv[0])
# deliberate bad rows -> same errors as the GST utility
bad = [dict(annexb.build_rows(claim, res)[0], sno=1, hsn="39", orig_hsn="39"),
       dict(annexb.build_rows(claim, res)[0], sno=2, docno="ABC 123/2026-27/XYZ9", orig_docno="ABC 123/2026-27/XYZ9"),
       dict(annexb.build_rows(claim, res)[0], sno=3, igst=10.0),
       dict(annexb.build_rows(claim, res)[0], sno=4, supply_type=annexb.T_IMPG, docno="12", port=""),
       dict(annexb.build_rows(claim, res)[0], sno=5, date="15-10-2026"),
       dict(annexb.build_rows(claim, res)[0], sno=6, gstin="27AAACS1234F1Z5")]
ev = annexb.validate(bad, client["gstin"], "2026-07", "2026-09")
msgs = " | ".join(m for _, m in ev)
print("validator:", msgs)
for frag in ("4, 6, or 8 digits", "max 16 characters", "Either IGST field should be blank", "Bill of entry",
             "Port Code", "To Return period", "same as the GSTIN of refund applicant"):
    assert frag in msgs, frag
import openpyxl
ws = openpyxl.load_workbook(out["xlsx"]).active
assert ws["D6"].value == "27AAACS1234F1Z5" and ws["D7"].value == "072026" and ws.cell(20, 1).value == 1
assert ws.cell(20, 2).value == annexb.T_REG and ws.cell(17, 21).value.startswith("2B Return Period")
sig = {"name": "Rajesh Mehta", "designation": "Director"}
docgen.applicant_declarations(folder / "05_Declarations" / "Declarations.docx", claim, client, sig, res, "Pune")
ca = {"firm_name": "ABC & Associates", "frn": "123456W", "ca_name": "CA Priya Shah", "membership_no": "123456",
      "designation": "Partner", "address": "Pune", "city": "Pune"}
docgen.ca_certificate(folder / "06_CA_Certificate" / "CA_Certificate.docx", claim, client, ca, res, snap,
                      udin="26123456ABCDEF1234", place="Pune")
exports.register_template(TMP / "tmpl.xlsx", "Sales")

# ---- trading purchases grossed up for gross profit (deemed trading turnover)
opts = {"trading_method": "gross_up", "gp_basis": "sales", "gp_percent": 15}
db.x("UPDATE claims SET options_json=? WHERE id=?", (json.dumps(opts), claim_id))
cg = calc.compute(db.q1("SELECT * FROM claims WHERE id=?", (claim_id,)), client)
ta = cg["trading_adjustment"]
assert ta["purchases"] == 450000 and abs(ta["deemed_turnover"] - 450000 / 0.85) < 0.01, ta
assert abs(cg["turnover"]["inverted"] - (17569378 - 450000 / 0.85)) < 0.02, cg["turnover"]
assert abs(ta["deduct_tax"] - round(450000 / 0.85 * 0.05, 2)) < 0.02, ta          # 5% average rate of inverted supply
assert cg["turnover"]["att"] == 18079378.0                                           # ATT unchanged by default
exp = cg["turnover"]["inverted"] * cg["selected"]["net_itc"] / cg["turnover"]["att"] - cg["turnover"]["tax_inverted"]
assert abs(cg["selected"]["raw"] - exp) < 0.05
print("Gross-up: deemed", ta["deemed_turnover"], "refund", cg["refund"]["amount"], "vs identified", res["refund"]["amount"])
# mark-up on cost + stock adjustment + ATT option + GP computed from books
opts = {"trading_method": "gross_up", "gp_basis": "cost", "gp_amount": 20, "gp_sales": 120,
        "trading_opening_stock": 50000, "trading_closing_stock": 100000, "trading_reduce_att": True}
db.x("UPDATE claims SET options_json=? WHERE id=?", (json.dumps(opts), claim_id))
cg2 = calc.compute(db.q1("SELECT * FROM claims WHERE id=?", (claim_id,)), client)
ta2 = cg2["trading_adjustment"]
assert ta2["cost_sold"] == 400000 and abs(ta2["gp_percent"] - 20) < 1e-9 and abs(ta2["deemed_turnover"] - 480000) < 0.01, ta2
assert abs(cg2["turnover"]["att"] - (18079378 - 480000)) < 0.01
print("Mark-up on cost with stock adjustment OK")
# minimum GP of 10% adopted by the department, or higher GP declared
def _gp(o):
    db.x("UPDATE claims SET options_json=? WHERE id=?", (json.dumps(o), claim_id))
    return calc.compute(db.q1("SELECT * FROM claims WHERE id=?", (claim_id,)), client)["trading_adjustment"]
t0 = _gp({"trading_method": "gross_up"})
assert t0["gp_percent"] == 10 and abs(t0["deemed_turnover"] - 450000 / 0.9) < 0.01 and t0["gp_source"].startswith("Minimum"), t0
t1 = _gp({"trading_method": "gross_up", "gp_percent": 6})
assert t1["gp_percent"] == 10 and t1["gp_declared"] == 6, t1
t2 = _gp({"trading_method": "gross_up", "gp_percent": 15})
assert t2["gp_percent"] == 15 and "higher than the minimum" in t2["gp_source"], t2
t3 = _gp({"trading_method": "gross_up", "gp_basis": "cost", "gp_percent": 4})
assert abs(t3["deemed_turnover"] - 450000 * 1.10) < 0.01, t3
db.set_setting("trading_min_gp", "12")
assert _gp({"trading_method": "gross_up", "gp_percent": 11})["gp_percent"] == 12
db.set_setting("trading_min_gp", "10")
print("Minimum GP tests OK")
db.x("UPDATE claims SET options_json=? WHERE id=?", (json.dumps({"trading_method": "identified"}), claim_id))

# debit_heads edge cases
assert calc.debit_heads(1000, {"igst": 400, "cgst": 100, "sgst": 900}) == {"igst": 400, "cgst": 100, "sgst": 500}
assert calc.debit_heads(1001, {"igst": 0, "cgst": 1000, "sgst": 1000}) in ({"igst": 0, "cgst": 501, "sgst": 500}, {"igst": 0, "cgst": 500, "sgst": 501})
# formula version by date
assert law.formula_for_filing_date("2022-07-04") == "V2018"
assert law.formula_for_filing_date("2026-10-31") == "V2022"
assert law.formula_for_filing_date("2026-11-01") == "V2026"
print("TIME LIMIT", law.time_limit("2026-07", "2026-09", "Quarterly (22nd)"))

# ---- Scenario 2: Nov-2026 claim. Input services availed on/after 01.11.2026 enter Net ITC (N/N 05/2026-CT);
#      edible oil (HSN 1512, N/N 9/2022-CT(R)) is excluded from inverted turnover.
c2 = db.insert("claims", dict(client_id=cid_client, fy="2026-27", period_from="2026-11", period_to="2026-11",
                              filing_date="2026-12-15", status="Draft", created_by="t", created_at=db.now()))
cl2 = db.q1("SELECT * FROM claims WHERE id=?", (c2,))
ins = ("INSERT INTO book_purchases(claim_id,register,tax_period,supplier_gstin,supplier_name,inv_no,inv_norm,inv_date,"
       "hsn,rate,txval,igst,cgst,sgst,cess,category,inward_type,itc_availed_date,match_status,blocked_17_5,is_trading) "
       "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0)")
db.x(ins, (c2, "Purchase", "2026-11", "27AABCR5678K1Z2", "S", "P1", "P1", "2026-11-05", "3901", 18, 1000000, 0, 90000, 90000, 0,
           "Inputs", "Regular", "2026-11-05", "Matched"))
db.x(ins, (c2, "Expense", "2026-11", "27AAACF2222R1Z1", "F", "E1", "E1", "2026-11-20", "9965", 18, 100000, 0, 9000, 9000, 0,
           "Input Services", "Regular", "2026-11-20", "Matched"))
db.x(ins, (c2, "Expense", "2026-11", "27AAACF2222R1Z1", "F", "E0", "E0", "2026-10-28", "9965", 18, 50000, 0, 4500, 4500, 0,
           "Input Services", "Regular", "2026-11-02", "Matched"))   # invoice Oct, availed Nov -> counts
sal = ("INSERT INTO book_sales(claim_id,tax_period,inv_no,inv_norm,inv_date,hsn,rate,txval,igst,cgst,sgst,cess,supply_type,"
       "is_trading) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0)")
db.x(sal, (c2, "2026-11", "S1", "S1", "2026-11-10", "6305", 5, 2000000, 0, 50000, 50000, 0, "Taxable"))
db.x(sal, (c2, "2026-11", "S2", "S2", "2026-11-11", "1512", 5, 500000, 0, 12500, 12500, 0, "Taxable"))
db.x("INSERT INTO ecl_balances(claim_id,kind,igst,cgst,sgst) VALUES(?,?,?,?,?)", (c2, "end_period", 0, 500000, 500000))
db.x("INSERT INTO ecl_balances(claim_id,kind,igst,cgst,sgst) VALUES(?,?,?,?,?)", (c2, "at_filing", 0, 500000, 500000))
db.x("INSERT INTO gst_3b(claim_id,tax_period,source,itcrev_cgst,itcrev_sgst) VALUES(?,?,?,?,?)", (c2, "2026-11", "Manual", 0, 0))
r2 = calc.compute(cl2, client)
assert r2["version"] == "V2026"
assert r2["turnover"]["inverted"] == 2000000 and r2["turnover"]["restricted_outward"] == 500000, r2["turnover"]
assert r2["turnover"]["att"] == 2500000
assert r2["versions"]["V2026"]["net_itc"] == 180000 + 18000 + 9000, r2["versions"]["V2026"]
assert r2["versions"]["V2022"]["net_itc"] == 180000
exp = 2000000 * 207000 / 2500000 - 100000
assert abs(r2["selected"]["max_refund"] - round(exp, 2)) < 0.01, (r2["selected"], exp)
assert r2["refund"]["amount"] == int(exp) and r2["refund"]["heads"]["igst"] == 0
assert abs(r2["refund"]["heads"]["cgst"] - r2["refund"]["heads"]["sgst"]) <= 1
print("Scenario 2 OK: Nov-2026 refund", r2["refund"], "V2022 would be", r2["versions"]["V2022"]["max_refund"])
# reversals: 4(B)(1) of 10,350 (5,175 + 5,175) apportioned in ratio of eligible ITC (all eligible here -> Net ITC share 100%)
db.x("UPDATE gst_3b SET itcrev_cgst=5175, itcrev_sgst=5175 WHERE claim_id=?", (c2,))
r3 = calc.compute(cl2, client)
assert r3["selected"]["reversal_net_itc"] == 10350 and r3["selected"]["net_itc"] == 207000 - 10350, r3["selected"]
db.x("UPDATE claims SET options_json=? WHERE id=?", (json.dumps({"reversal_net_itc": 0}), c2))
r4 = calc.compute(db.q1("SELECT * FROM claims WHERE id=?", (c2,)), client)
assert r4["selected"]["net_itc"] == 207000
print("Reversal tests OK")
# ---- import of other formats (Excel / PDF) gives the same data as JSON
from idtra import parsers_ext
OF = S / "other_formats"
c3 = db.insert("claims", dict(client_id=cid_client, fy="2026-27", period_from="2026-07", period_to="2026-09",
                              filing_date="2026-11-20", status="Draft", created_by="t", created_at=db.now()))
cl3 = db.q1("SELECT * FROM claims WHERE id=?", (c3,))
f3 = storage.claim_dir(cl3, client)
for f in sorted(OF.glob("GSTR2B_27*.xlsx")) + sorted(OF.glob("GSTR1_Excel_*.xlsx")) + sorted(OF.glob("GSTR3B_*.pdf")):
    dst = f3 / "01_Portal_Downloads" / f.name
    shutil.copy(f, dst)
    t, p, s_, notes = importer.import_any(db.q1("SELECT * FROM claims WHERE id=?", (c3,)), client, dst, "t")
    print("  imported", f.name, "->", t, p)
for tbl, cols in (("gst_2b", "SUM(igst+cgst+sgst), SUM(txval), COUNT(*)"), ("gst_outward", "SUM(igst+cgst+sgst), SUM(txval), COUNT(*)"),
                  ("gst_3b", "SUM(osup_txval), SUM(itc_igst+itc_cgst+itc_sgst), SUM(nil_exempt)")):
    a = db.q1(f"SELECT {cols} FROM {tbl} WHERE claim_id=?", (claim_id,))
    b = db.q1(f"SELECT {cols} FROM {tbl} WHERE claim_id=?", (c3,))
    assert all(abs((x or 0) - (y or 0)) < 0.05 for x, y in zip(a.values(), b.values())), (tbl, a, b)
print("Excel / PDF imports equal JSON imports")
# GSTR-1 PDF (totals only) and GSTR-2B PDF (document only)
c4 = db.insert("claims", dict(client_id=cid_client, fy="2026-27", period_from="2026-08", period_to="2026-08",
                              filing_date="2026-11-20", status="Draft", created_by="t", created_at=db.now()))
cl4 = db.q1("SELECT * FROM claims WHERE id=?", (c4,))
f4 = storage.claim_dir(cl4, client)
for f in (OF / "GSTR1_Summary_27AAACS1234F1Z5_082026.pdf", OF / "GSTR2B_Summary_27AAACS1234F1Z5_082026.pdf"):
    dst = f4 / "01_Portal_Downloads" / f.name
    shutil.copy(f, dst)
    print("  ", importer.import_any(cl4, client, dst, "t")[:2])
row = db.q1("SELECT * FROM gst_outward WHERE claim_id=?", (c4,))
assert row["section"] == "PDF-SUMMARY" and abs(row["txval"] - 6354543.0) < 0.01
assert db.q1("SELECT COUNT(*) n FROM gst_2b WHERE claim_id=?", (c4,))["n"] == 0
assert db.q1("SELECT return_type FROM portal_files WHERE claim_id=? AND return_type LIKE 'GSTR2B%'", (c4,))["return_type"] == "GSTR2B_PDF"
shutil.copy(S / "Sales_Register_Tally.xlsx", f4 / "s.xlsx")
importer.import_register(cl4, f4 / "s.xlsx", "Sales", "t")
recon.run(cl4, client, "t")
codes = {q["code"] for q in db.q("SELECT code FROM queries WHERE claim_id=?", (c4,))}
assert "R1-G1-2026-08" not in codes and not any(c.startswith(("R2-", "R3-")) for c in codes), codes
assert "R0-GSTR2B-2026-08" in codes, codes
print("PDF summary import OK (month totals reconciled, no false invoice/rate queries; 2B PDF flagged)")
# a file for another month than selected / wrong GSTIN is refused
try:
    importer.import_any(cl4, client, f3 / "01_Portal_Downloads" / "GSTR2B_27AAACS1234F1Z5_072026.xlsx", "t")
    raise AssertionError("out-of-period file accepted")
except importer.ImportError_ as e:
    assert "outside the claim period" in str(e)
print("ALL SCENARIOS PASSED")
print("ALL TESTS PASSED. Output in", folder)


# ---- Tally columnar register (one column per ledger, item lines below, both registers in one workbook)
def _tally_columnar_test():
    import datetime as _d
    import tempfile as _t
    import openpyxl as _o
    from idtra import parsers as _p
    wb = _o.Workbook()
    ws = wb.active; ws.title = "Sales Register"
    for t in ("DEMO STEEL", "Sales Register", "1-Apr-26 to 30-Jun-26"):
        ws.append([t])
    ws.append(["Date", "Particulars", "Buyer", "Voucher Type", "Voucher Ref. No.", "GSTIN/UIN", "Gross Total",
               "SALES OMS 73 - 5%", "IGST", "ROUND OFF", "SALES LOCAL 73 - 5%", "CGST", "SGST", "Packing Charges", "TCS"])
    ws.append([_d.datetime(2026, 4, 1), "A TRADERS", "A TRADERS", "Sales", "", "36AICPJ6779R1ZB", 10520.2, 10000, 520, 0.2])
    ws.append([None, "S S UTENSILS"])
    ws.append([_d.datetime(2026, 4, 2), "B TRADERS", "B TRADERS", "Sales", "", "27AAMFB1081A1ZW", 21110, None, None, -0.1,
               20000, 525, 525, 1000, 60.1])
    ws.append([_d.datetime(2026, 4, 3), "(cancelled )", "", "Sales"])
    ws.append([None, "Grand Total", "", "", "", "", 31630.2, 10000, 520, 0.1, 20000, 525, 525, 1000, 60.1])
    w2 = wb.create_sheet("Purchase Register")
    for t in ("DEMO STEEL", "Purchase Register", "1-Apr-26 to 30-Jun-26"):
        w2.append([t])
    w2.append(["Date", "Particulars", "Supplier", "Supplier Invoice No.", "GSTIN/UIN", "Gross Total", "Repair & Maintenance",
               "PURCHASE LOCAL 18%", "CGST", "SGST", "ROUND OFF", "Transport Charges RCM", "Dies & Moulds", "Bank Charges GST"])
    w2.append([_d.datetime(2026, 4, 1), "R K Works", "R K Works", "450", "", 43400, 43400])
    w2.append([_d.datetime(2026, 4, 2), "X LLP", "X LLP", "X/1", "27ACJFA3226D1ZR", 70818, None, 60015, 5401.35, 5401.35, 0.3])
    w2.append([None, "S S Coil"])
    w2.append([_d.datetime(2026, 4, 3), "T Co", "T Co", "T/9", "", 7500, None, None, None, None, None, 7500])
    w2.append([_d.datetime(2026, 4, 4), "D Co", "D Co", "D/1", "27AAFHM2217L2Z4", 11800, None, None, 900, 900, None, None, 10000])
    w2.append([_d.datetime(2026, 4, 5), "Bank", "Bank", "KB1", "27AAACK4409J1ZK", 5.9, None, None, 0.45, 0.45, None, None, None, 5])
    f = Path(_t.mkdtemp()) / "tally_columnar.xlsx"
    wb.save(f)
    rows, w = _p.parse_register(f, "Sales")
    assert len(rows) == 3 and any("AUTO/" in x for x in [r["inv_no"] for r in rows]), rows
    pk = [r for r in rows if r["description"].startswith("Packing")][0]
    assert pk["rate"] == 5.0 and abs(pk["cgst"] - 25) < 0.01, pk
    oms = [r for r in rows if r["description"].startswith("SALES OMS")][0]
    assert oms["hsn"] == "73" and oms["igst"] == 520 and "S S UTENSILS" in oms["description"], oms
    assert abs(sum(r["txval"] for r in rows) - 31000) < 0.01
    rows, w = _p.parse_register(f, "Purchase")
    by = {r["inv_no"]: r for r in rows}
    assert by["450"]["category"] == "Input Services" and by["450"]["rate"] == 0, by["450"]
    assert by["X/1"]["category"] == "Inputs" and by["X/1"]["rate"] == 18 and abs(by["X/1"]["cgst"] - 5401.35) < 0.01
    assert by["T/9"]["inward_type"] == "RCM", by["T/9"]
    assert by["D/1"]["category"] == "Capital Goods" and by["D/1"]["rate"] == 18, by["D/1"]
    assert by["KB1"]["rate"] == 18 and abs(by["KB1"]["cgst"] - 0.45) < 0.001, by["KB1"]
    print("Tally columnar register OK (ledger split, rates, item lines, RCM, capital goods, cancelled skipped, sheet choice)")


_tally_columnar_test()


# ---- credit / debit notes, multi-file GSTR-1 ZIP, amendments and GSTR-1A
def _notes_amend_test():
    import datetime as _d
    import json as _j
    import tempfile as _t
    import zipfile as _z
    import openpyxl as _o
    from idtra import config as _cfg, db as _db, importer as _im, parsers as _p, recon as _r, security as _sec, storage as _st
    tmp = Path(_t.mkdtemp(prefix="idtra_notes_"))
    os.environ["IDTRA_CONFIG_DIR"] = str(tmp / "config"); os.environ["IDTRA_DATA_ROOT"] = str(tmp / "data")
    c = _cfg.load(); _db.init(c["db_path"]); _st.init(c["data_root"]); _sec.init(c["key_file"])
    G = "27AABCN4321Q1Z7"
    cid_cl = _db.insert("clients", dict(legal_name="Notes Test", gstin=G, folder_name="Notes_Test", created_at=_db.now()))
    cl = _db.q1("SELECT * FROM clients WHERE id=?", (cid_cl,))
    cid = _db.insert("claims", dict(client_id=cid_cl, fy="2026-27", period_from="2026-04", period_to="2026-06",
                                    filing_date="2026-11-20", status="Draft", created_at=_db.now()))
    claim = _db.q1("SELECT * FROM claims WHERE id=?", (cid,))
    item = lambda tx, rt=5: [{"num": 1, "itm_det": {"rt": rt, "txval": tx, "iamt": 0, "camt": tx * rt / 200, "samt": tx * rt / 200, "csamt": 0}}]
    # April GSTR-1 as a ZIP of two JSON files (invoices + notes)
    apr_b2b = {"gstin": G, "fp": "042026", "b2b": [{"ctin": "27AAMFB1081A1ZW", "inv": [
        {"inum": "S/1", "idt": "05-04-2026", "val": 105000, "pos": "27", "itms": item(100000)},
        {"inum": "S/2", "idt": "06-04-2026", "val": 52500, "pos": "27", "itms": item(50000)}]}]}
    apr_cdn = {"gstin": G, "fp": "042026", "cdnr": [{"ctin": "27AAMFB1081A1ZW", "nt": [
        {"ntty": "C", "nt_num": "CN/1", "nt_dt": "20-04-2026", "val": 10500, "itms": item(10000)},
        {"ntty": "D", "nt_num": "DN/1", "nt_dt": "21-04-2026", "val": 2100, "itms": item(2000)}]}]}
    pdl = _st.claim_dir(claim, cl) / "01_Portal_Downloads"
    zp = pdl / "returns_042026_R1_offline.zip"
    with _z.ZipFile(zp, "w") as z:
        z.writestr("returns_042026_R1_b2b_0.json", _j.dumps(apr_b2b))
        z.writestr("returns_042026_R1_cdnr_0.json", _j.dumps(apr_cdn))
    _im.import_any(claim, cl, zp, "t")
    tot = _db.q1("SELECT SUM(txval) t FROM gst_outward WHERE claim_id=? AND tax_period='2026-04'", (cid,))["t"]
    assert abs(tot - (150000 - 10000 + 2000)) < 0.01, tot                     # both files of the ZIP read
    # May GSTR-1: B2BA amends April invoice S/2 (50,000 -> 60,000) and a new invoice
    may = {"gstin": G, "fp": "052026", "b2b": [{"ctin": "27AAMFB1081A1ZW", "inv": [
        {"inum": "S/3", "idt": "02-05-2026", "val": 21000, "pos": "27", "itms": item(20000)}]}],
        "b2ba": [{"ctin": "27AAMFB1081A1ZW", "inv": [{"oinum": "S/2", "oidt": "06-04-2026", "inum": "S/2", "idt": "06-04-2026",
                                                     "val": 63000, "pos": "27", "itms": item(60000)}]}]}
    f = pdl / "GSTR1_052026.json"; f.write_text(_j.dumps(may))
    _im.import_any(claim, cl, f, "t")
    may_t = _db.q1("SELECT SUM(txval) t FROM gst_outward WHERE claim_id=? AND tax_period='2026-05'", (cid,))["t"]
    assert abs(may_t - (20000 + 60000 - 50000)) < 0.01, may_t                # amendment counts only the difference
    # GSTR-1A for May: adds a missed invoice and amends S/3 of the same month (20,000 -> 25,000)
    m1a = {"gstin": G, "fp": "052026", "b2b": [{"ctin": "27AAFHM2217L2Z4", "inv": [
        {"inum": "S/9", "idt": "28-05-2026", "val": 10500, "pos": "27", "itms": item(10000)}]}],
        "b2ba": [{"ctin": "27AAMFB1081A1ZW", "inv": [{"oinum": "S/3", "oidt": "02-05-2026", "inum": "S/3", "idt": "02-05-2026",
                                                     "val": 26250, "pos": "27", "itms": item(25000)}]}]}
    f = pdl / "returns_052026_GSTR1A.json"; f.write_text(_j.dumps(m1a))
    t, per, summ, _n = _im.import_any(claim, cl, f, "t")
    assert t == "GSTR1A", t
    may_t = _db.q1("SELECT SUM(txval) t FROM gst_outward WHERE claim_id=? AND tax_period='2026-05'", (cid,))["t"]
    assert abs(may_t - (25000 + 60000 - 50000 + 10000)) < 0.01, may_t
    # re-importing GSTR-1 of May keeps GSTR-1A; re-importing 1A replaces only 1A
    f = pdl / "GSTR1_052026.json"; _im.import_any(claim, cl, f, "t")
    f = pdl / "returns_052026_GSTR1A.json"; _im.import_any(claim, cl, f, "t")
    assert abs(_db.q1("SELECT SUM(txval) t FROM gst_outward WHERE claim_id=? AND tax_period='2026-05'", (cid,))["t"] - 45000) < 0.01
    # June: amendment of an invoice from before the claim -> flagged in the reconciliation
    jun = {"gstin": G, "fp": "062026", "b2ba": [{"ctin": "27AAMFB1081A1ZW", "inv": [
        {"oinum": "S/0", "oidt": "20-03-2026", "inum": "S/0", "idt": "20-03-2026", "val": 1050, "pos": "27", "itms": item(1000)}]}]}
    f = pdl / "GSTR1_062026.json"; f.write_text(_j.dumps(jun)); _im.import_any(claim, cl, f, "t")
    # books: invoices, then credit notes and debit notes as separate registers (Tally columnar)
    def reg(path, title, rows):
        wb = _o.Workbook(); ws = wb.active; ws.title = title
        ws.append(["X STEEL"]); ws.append([title])
        ws.append(["Date", "Particulars", "Buyer", "Voucher Type", "Voucher No.", "GSTIN/UIN", "Gross Total",
                   "SALES LOCAL 73 - 5%", "CGST", "SGST"])
        for r in rows:
            ws.append(r)
        wb.save(path)
    reg(tmp / "sales.xlsx", "Sales Register", [[_d.datetime(2026, 4, 5), "B", "B", "Sales", "S/1", "27AAMFB1081A1ZW", 105000, 100000, 2500, 2500],
                                               [_d.datetime(2026, 4, 6), "B", "B", "Sales", "S/2", "27AAMFB1081A1ZW", 52500, 50000, 1250, 1250]])
    reg(tmp / "cn.xlsx", "Credit Note Register", [[_d.datetime(2026, 4, 20), "B", "B", "Credit Note", "CN/1", "27AAMFB1081A1ZW", 10500, 10000, 250, 250]])
    reg(tmp / "dn.xlsx", "Debit Note Register", [[_d.datetime(2026, 4, 21), "B", "B", "Debit Note", "DN/1", "27AAMFB1081A1ZW", 2100, 2000, 50, 50]])
    _im.import_register(claim, tmp / "sales.xlsx", "Sales", "t")
    _im.import_register(claim, tmp / "cn.xlsx", "Sales-CN", "t")
    _im.import_register(claim, tmp / "dn.xlsx", "Sales-DN", "t")
    _im.import_register(claim, tmp / "cn.xlsx", "Sales-CN", "t")              # again: replaces only the credit notes
    bk = _db.q1("SELECT SUM(txval) t, COUNT(*) n FROM book_sales WHERE claim_id=? AND tax_period='2026-04'", (cid,))
    assert bk["n"] == 4 and abs(bk["t"] - 142000) < 0.01, bk
    snap = _r.run(_db.q1("SELECT * FROM claims WHERE id=?", (cid,)), cl, "t")
    apr = [o for o in snap["outward"] if o["period"] == "2026-04"][0]
    assert apr["diff_g1"] == 0 and apr["books_cn"] == -10000 and apr["g1_cdn"] == -8000, apr
    codes = [q["code"] for q in _db.q("SELECT code FROM queries WHERE claim_id=?", (cid,))]
    assert any(c_.startswith("R9-AMD-2026-06") for c_ in codes), codes
    print("Credit / debit notes, multi-file GSTR-1 ZIP, amendments (B2BA) and GSTR-1A OK")


_notes_amend_test()
