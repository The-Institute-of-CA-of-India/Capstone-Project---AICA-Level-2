INVERTED TAX DUTY REFUND APPLICATION - STANDALONE (single laptop) v1.6.1

1. Extract this folder to a NEW folder (do not run from inside the zip).
2. Double-click Start_IDTRA.bat in THIS folder (not the old desktop icon). First run sets up in 2-5 minutes.
   If an older version is installed, the setup asks to move its data here and uninstall it - answer Y.
3. Log in: admin / admin@123. The left menu must show "v1.6.1" at the bottom.
4. Double-click Load_Demo_Data.bat to load the demo company with sample data (fresh install only).
5. Follow Standalone_Testing_Guide.pdf - it lists the expected result of every step.

DOWNLOAD SIZE: this package is kept under 25 MB. It contains the libraries for Python 3.13, 3.14 and 3.15
(Python 3.14 is installed automatically if the laptop has none). With Python 3.10 - 3.12 the setup fetches the
libraries from the internet - or extract the optional add-on IDTRA_Standalone_AddOn (wheels_extra folder) into
this folder for a fully offline install.
GST Portal Assistant (automatic download from the portal) is optional: Install_Portal_Assistant.bat (one time,
internet or add-on). Without it, download the returns yourself and use 'Import files from folder'.

NEW in 1.6.1: package under 25 MB (Portal Assistant and older-Python libraries moved to an optional add-on).
NEW in 1.6.0:
 - Credit notes are netted against sales and purchase returns / debit notes against purchases (ITC is
   reduced even when the supplier's credit note is not in GSTR-2B). Books tab shows net outward / inward.
 - Refresh: every imported register can be imported again or removed; 'Refresh all imported data'
   re-imports all portal files and registers of the claim from the stored copies.
 - Books > Review purchase register: mark each purchase line trading / not trading, change category or
   17(5), and give HSN + goods description per item (remembered for the client) - needed for Annexure-B.
   Annexure-B Excel gets a companion sheet with the goods description of every line.

In 1.5.5: credit / debit notes and amendments.
 - Books tab: import the Tally Credit Note Register and Debit Note Register too (own choices in the
   Register list) - they are kept next to the invoices and netted.
 - GSTR-1: all JSON files in the portal ZIP are read (invoices, credit / debit notes, amendments); amendments
   replace the original document. GSTR-1A can be imported for any month (return type GSTR-1A).

In 1.5.4: simple manual route for portal returns - download GSTR-1 / GSTR-2B (JSON) and GSTR-3B (PDF)
from the GST portal yourself, put them in the claim's folder (Portal Data tab > Open folder) and click
'Import files from folder'. The automatic download is still there (optional, bottom of the tab).

In 1.5.3: fixes 'Access Denied - your session is expired' right after the GST login: the Returns
Dashboard is now opened through the portal's own RETURN DASHBOARD button / Services menu (the portal
refuses a direct jump). The '--no-sandbox' browser warning is gone.

In 1.5.2: Download from GST portal brings in JSON only - GSTR-1 and GSTR-2B JSON files and the
GSTR-3B data as JSON from the portal's VIEW screen. PDF / Excel are no longer imported automatically
(their figures could give mismatches); months still holding PDF / Excel data show 'use JSON'.

Also: Tally Sales / Purchase Registers exported in COLUMNAR form (one column per ledger such as
"SALES LOCAL 73 - 5%", "PURCHASE OMS 18%", IGST, CGST, SGST) are now imported directly. A workbook that
holds both registers is fine - the right sheet is chosen for the register type you select.

NEW in 1.5:
 - Clients > Add client: type only the GSTIN user ID and password and click
   "Log in & fetch details from GST portal" (or use "Add client from GST portal" at the top).
   Chrome/Edge opens with both filled in - type the CAPTCHA. GSTIN, legal/trade name, PAN, state,
   constitution, address, email, mobile and partners/directors are fetched for you to confirm.
 - Colours: light blue, cream white, green, orange and red.
 - Uninstall_IDTRA.bat removes this (or an older) copy; it asks before deleting any data.

Earlier: Portal Data tab > Download from GST portal (returns downloaded and imported automatically);
manual upload accepts JSON, ZIP, Excel and PDF.

LOGIN: the application login is admin / admin@123 (first time) - NOT your GST portal user ID.
Forgot it? Double-click Reset_Admin_Password.bat (login becomes admin / admin@123; data is not changed).

Stop_IDTRA.bat stops the program. Reset_All_Data.bat deletes the trial data.
