"""GST Portal Assistant - runs on the user's own PC.

1. Fetches a download job from the IDTRA server (job code shown in the application).
2. Opens the user's default browser (Google Chrome or Microsoft Edge) in a separate window,
   fills the GSTIN user ID and password - the user types only the CAPTCHA (and OTP if asked) and clicks LOGIN.
3. For every month of the claim: opens the Returns Dashboard, selects the period and downloads
   GSTR-2B, GSTR-3B and GSTR-1.
4. EVERY file downloaded in that browser window - automatically or by the user's own clicks - is sent
   to the server and imported into the claim immediately.

Self-contained: needs only Python + the 'playwright' package (uses the installed Chrome / Edge, no
browser download). Screen labels are in portal_steps.json.
"""
import argparse
import json
import mimetypes
import os
import re
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
QUEUE = []           # downloads waiting to be saved / uploaded
STATE = {"rtype": "", "period": "", "uploaded": 0, "failed": 0}


def say(msg, colour=""):
    codes = {"g": "\033[92m", "y": "\033[93m", "r": "\033[91m", "c": "\033[96m", "m": "\033[95m"}
    print(f"{codes.get(colour, '')}{msg}\033[0m" if colour else msg, flush=True)


# ------------------------------------------------------------------ server API
class Server:
    def __init__(self, base, code):
        self.base, self.code = base.rstrip("/"), code.strip().upper()
        self.api = "/api/portal-job"          # return downloads; "/api/profile-job" = client master fetch

    def _req(self, path, data=None, headers=None, timeout=120):
        req = urllib.request.Request(self.base + path, data=data, headers=headers or {})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def job(self):
        try:
            return self._req(f"{self.api}/{self.code}")
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise
            self.api = "/api/profile-job"     # the code belongs to a 'fetch details from GST portal' job
            return self._req(f"{self.api}/{self.code}")

    def result(self, texts, jsons, final=False):
        body = json.dumps({"texts": texts, "jsons": jsons, "final": final}).encode()
        return self._req(f"{self.api}/{self.code}/result", body, {"Content-Type": "application/json"}, 120)

    def log(self, msg, status=None):
        try:
            body = json.dumps({"msg": msg, "status": status}).encode()
            self._req(f"{self.api}/{self.code}/log", body, {"Content-Type": "application/json"}, 20)
        except Exception:  # noqa: BLE001 - logging must never stop the assistant
            pass

    def upload(self, path, rtype, period):
        boundary = uuid.uuid4().hex
        parts = []
        for k, v in (("rtype", rtype or ""), ("period", period or "")):
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
                      f"Content-Type: {ctype}\r\n\r\n").encode() + path.read_bytes() + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        return self._req(f"{self.api}/{self.code}/upload", b"".join(parts),
                         {"Content-Type": f"multipart/form-data; boundary={boundary}"}, 300)


# ------------------------------------------------------------------ browser choice
def default_browser():
    """'chrome' / 'msedge' / '' from the Windows default-browser setting."""
    if os.name != "nt":
        return ""
    try:
        import winreg
        for proto in ("https", "http"):
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                    rf"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\{proto}\UserChoice") as k:
                    prog = str(winreg.QueryValueEx(k, "ProgId")[0]).lower()
                    if "chrome" in prog:
                        return "chrome"
                    if "edge" in prog:
                        return "msedge"
                    return "other"
            except OSError:
                continue
    except ImportError:
        pass
    return ""


def installed(channel):
    pf = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
          os.environ.get("LOCALAPPDATA", "")]
    rel = {"chrome": r"Google\Chrome\Application\chrome.exe", "msedge": r"Microsoft\Edge\Application\msedge.exe"}[channel]
    return any(Path(p, rel).exists() for p in pf if p)


def choose_browser():
    d = default_browser()
    if d == "chrome" and installed("chrome"):
        return "chrome", "Google Chrome (your default browser)"
    if d == "msedge" and installed("msedge"):
        return "msedge", "Microsoft Edge (your default browser)"
    if installed("chrome"):
        return "chrome", "Google Chrome" + (" (default browser is not Chrome/Edge)" if d == "other" else "")
    return "msedge", "Microsoft Edge"


# ------------------------------------------------------------------ page helpers
def first_visible(page, selectors, timeout=0):
    end = time.time() + timeout
    while True:
        for s in selectors:
            try:
                loc = page.locator(s)
                for i in range(min(loc.count(), 5)):
                    if loc.nth(i).is_visible():
                        return loc.nth(i)
            except Exception:  # noqa: BLE001
                continue
        if time.time() >= end:
            return None
        page.wait_for_timeout(500)


CLICKABLE = "button, a, input[type=button], input[type=submit], [role=button]"


def find_clickable(scope, texts):
    for t in texts:
        rx = re.compile(re.escape(t), re.I)
        try:
            for kind in ("button, input[type=button], input[type=submit], [role=button]", "a"):   # buttons before links
                loc = scope.locator(kind).filter(has_text=rx)
                for i in range(min(loc.count(), 10)):
                    if loc.nth(i).is_visible():
                        return loc.nth(i)
            loc = scope.locator(f"input[value*='{t}' i]")
            for i in range(min(loc.count(), 5)):
                if loc.nth(i).is_visible():
                    return loc.nth(i)
        except Exception:  # noqa: BLE001
            continue
    return None


def find_in_tile(page, tile_texts, button_texts):
    """Button inside the box (tile) that shows one of tile_texts, e.g. DOWNLOAD inside the GSTR-2B tile."""
    for tt in tile_texts:
        rx = re.compile(r"\b" + re.escape(tt).replace(r"\-", r"-?") + r"\b", re.I)
        for bt in button_texts:
            btn_rx = re.compile(re.escape(bt), re.I)
            try:
                boxes = page.locator("div, td, section, li").filter(has_text=rx).filter(
                    has=page.locator(CLICKABLE).filter(has_text=btn_rx))
                n = boxes.count()
                if n:
                    box = boxes.nth(n - 1)          # innermost box
                    b = box.locator(CLICKABLE).filter(has_text=btn_rx)
                    for i in range(min(b.count(), 5)):
                        if b.nth(i).is_visible():
                            return b.nth(i)
            except Exception:  # noqa: BLE001
                continue
    return None


def select_contains(page, selectors, needles, position):
    sel = first_visible(page, selectors)
    if sel is None:
        try:
            alls = page.locator("select")
            vis = [alls.nth(i) for i in range(alls.count()) if alls.nth(i).is_visible()]
            sel = vis[position] if len(vis) > position else None
        except Exception:  # noqa: BLE001
            sel = None
    if sel is None:
        return False
    opts = sel.locator("option")
    for i in range(opts.count()):
        txt = (opts.nth(i).inner_text() or "").strip()
        if any(n.lower() in txt.lower() for n in needles):
            val = opts.nth(i).get_attribute("value")
            sel.select_option(value=val if val is not None else txt)
            page.wait_for_timeout(700)
            return True
    return False


# ------------------------------------------------------------------ downloads
def on_download(dl):
    QUEUE.append((dl, STATE["rtype"], STATE["period"]))


def attach(ctx):
    def hook(pg):
        pg.on("download", on_download)
    for pg in ctx.pages:
        hook(pg)
    ctx.on("page", hook)


def process_queue(server, outdir, pump_page=None, wait_ms=0):
    if pump_page is not None and wait_ms:
        try:
            pump_page.wait_for_timeout(wait_ms)
        except Exception:  # noqa: BLE001
            pass
    done = 0
    while QUEUE:
        dl, rt, per = QUEUE.pop(0)
        try:
            name = dl.suggested_filename or f"download_{int(time.time())}"
            target = outdir / name
            k = 2
            while target.exists():
                target = outdir / f"{Path(name).stem}_{k}{Path(name).suffix}"
                k += 1
            dl.save_as(str(target))
            if STATE.get("json_only") and target.suffix.lower() not in (".json", ".zip"):
                say(f"   downloaded: {target.name} - NOT sent: only JSON files are imported (PDF / Excel figures can "
                    f"differ). Download the JSON of this return instead.", "y")
                STATE["skipped"] = STATE.get("skipped", 0) + 1
                continue
            say(f"   downloaded: {target.name} - sending to the application ...", "c")
            res = server.upload(target, rt, per)
            if res.get("ok"):
                STATE["uploaded"] += 1
                say(f"   IMPORTED: {res.get('message')}", "g")
                for n in res.get("notes", []):
                    say(f"   note: {n}", "y")
            else:
                STATE["failed"] += 1
                say(f"   NOT imported: {res.get('message')}", "r")
            done += 1
        except Exception as e:  # noqa: BLE001
            STATE["failed"] += 1
            say(f"   could not process a download: {e}", "r")
    return done


def wait_for_new_download(server, outdir, page, timeout):
    before = STATE["uploaded"] + STATE["failed"]
    skipped = STATE.get("skipped", 0)
    end = time.time() + timeout
    while time.time() < end:
        process_queue(server, outdir, page, 1000)
        if STATE["uploaded"] + STATE["failed"] > before:
            return True
        if STATE.get("skipped", 0) > skipped:
            return False                     # a PDF / Excel came instead of JSON
    return False


def current_page(ctx, page):
    pages = [p for p in ctx.pages if not p.is_closed()]
    return pages[-1] if pages else page


def ask(prompt):
    try:
        return input(prompt)
    except EOFError:
        return ""


# ------------------------------------------------------------------ main flow
def run(args):
    server = Server(args.server, args.code)
    try:
        job = server.job()
    except urllib.error.HTTPError as e:
        say(f"The application refused the job code ({e.code}). Create a new download job in the application.", "r")
        return 2
    except Exception as e:  # noqa: BLE001
        say(f"Cannot reach the application at {args.server}: {e}", "r")
        return 2
    steps = json.loads(Path(args.steps or HERE / "portal_steps.json").read_text(encoding="utf-8"))
    STATE["json_only"] = steps.get("json_only", True)
    if args.login_url:
        steps["login_url"] = args.login_url
    if args.dashboard_url:
        steps["dashboard_url"] = args.dashboard_url
    if args.logged_in_contains:
        steps["logged_in_url_contains"] = [args.logged_in_contains]
    profile_mode = job.get("kind") == "profile"
    STATE["gstin"] = job.get("gstin", "")
    outdir = Path(args.download_dir or Path(os.environ.get("TEMP", "/tmp")) / "IDTRA_portal_downloads" /
                  (job.get("gstin") or "profile"))
    outdir.mkdir(parents=True, exist_ok=True)

    say("=" * 70, "m")
    say(f"  GST Portal Assistant - {job['client']} {('(' + job['gstin'] + ')') if job.get('gstin') else ''}", "m")
    if profile_mode:
        say("  Task: read the registration details (client master) from the GST portal profile", "m")
    else:
        say(f"  Periods: {', '.join(m['label'] for m in job['months'])}   Returns: {', '.join(job['returns'])}", "m")
    say("=" * 70, "m")
    from playwright.sync_api import sync_playwright
    channel, bname = choose_browser() if not args.browser_path else (None, args.browser_path)
    # fresh browser profile for every run (a re-used profile restores old tabs and can close the window);
    # nothing needs to be kept - the GST portal asks for a new login every time anyway
    import shutil
    import tempfile
    base = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "IDTRA"
    base.mkdir(parents=True, exist_ok=True)
    for old in base.glob("portal-profile-*"):
        shutil.rmtree(old, ignore_errors=True)
    profile = Path(tempfile.mkdtemp(prefix="portal-profile-", dir=base))
    say(f"Opening {bname} in a separate window (your normal browser windows are not touched) ...")
    with sync_playwright() as p:
        kw = dict(headless=args.headless, accept_downloads=True, no_viewport=True, chromium_sandbox=not args.no_sandbox,
                  args=["--start-maximized", "--disable-blink-features=AutomationControlled"])
        if args.browser_path:
            kw["executable_path"] = args.browser_path
        else:
            kw["channel"] = channel
        try:
            try:
                ctx = p.chromium.launch_persistent_context(str(profile), **kw)
            except Exception:  # noqa: BLE001 - a PC where the browser sandbox cannot start
                if not kw.get("chromium_sandbox"):
                    raise
                kw["chromium_sandbox"] = False
                ctx = p.chromium.launch_persistent_context(str(profile), **kw)
        except Exception as e:  # noqa: BLE001
            if channel == "chrome":
                say(f"Chrome could not be started ({e.__class__.__name__}); using Microsoft Edge.", "y")
                kw["channel"] = "msedge"
                ctx = p.chromium.launch_persistent_context(str(profile), **kw)
            else:
                raise
        attach(ctx)
        ctx.on("response", on_response)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        # ---------------- login
        server.log("Opening GST portal login", "running")
        page.goto(steps["login_url"], wait_until="domcontentloaded")
        u = first_visible(page, steps["username_selectors"], 30)
        pw = first_visible(page, steps["password_selectors"], 10)
        if u is not None:
            u.fill(job["username"])
        if pw is not None:
            pw.fill(job["password"])
        cap = first_visible(page, steps["captcha_selectors"], 5)
        if u is None or pw is None:
            say("Could not find the user ID / password boxes - please type them yourself.", "y")
        if cap is not None:
            cap.focus()
        if args.test_captcha and cap is not None:          # automated testing only
            cap.fill(args.test_captcha)
            cap.press("Enter")
        say("\n>>> In the browser window: type the CAPTCHA characters and click LOGIN (enter the OTP if asked).", "y")
        say("    The assistant continues by itself as soon as you are logged in.\n", "y")
        end = time.time() + args.login_timeout
        logged = False
        while time.time() < end:
            for pg in ctx.pages:
                url = pg.url or ""
                if any(s in url for s in steps["logged_in_url_contains"]) and "login" not in url.lower():
                    logged, page = True, pg
                    break
            if logged:
                break
            process_queue(server, outdir, page, 1000)
        if not logged:
            say("Login was not completed in time. Run the assistant again.", "r")
            server.log("Login not completed", "failed")
            ctx.close()
            return 3
        try:
            page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:  # noqa: BLE001
            pass
        page.wait_for_timeout(2500)          # let the portal finish setting up the session
        STATE["welcome"] = page.url
        say("Logged in.", "g")
        server.log("Logged in to GST portal")
        if profile_mode:
            rc = fetch_profile(page, ctx, steps, server, args)
            ctx.close()
            shutil.rmtree(profile, ignore_errors=True)
            return rc

        # ---------------- Returns Dashboard (entered through the portal's own button / menu)
        dash = open_dashboard(page, ctx, steps, first=True)
        if dash is None:
            say("\n>>> Could not open the Returns Dashboard automatically. In the browser window click "
                "Services > Returns > Returns Dashboard.", "y")
            if not args.no_prompt:
                ask("    Press Enter here when the Returns Dashboard is on the screen ... ")
            dash = next((pg for pg in ctx.pages if not pg.is_closed() and on_dashboard(pg, steps)), None)
        if dash is None:
            say("The Returns Dashboard could not be reached - log in again and retry.", "r")
            server.log("Returns Dashboard not reachable after login", "failed")
            ctx.close()
            return 4
        page = dash
        say("Returns Dashboard open.", "g")

        # ---------------- downloads, month by month
        order = [r for r in steps.get("return_order", job["returns"]) if r in job["returns"]]
        for m in job["months"]:
            for rt in order:
                STATE["rtype"], STATE["period"] = rt, m["period"]
                say(f"\n[{m['label']}] {rt} ...", "c")
                ok = auto_download(page, ctx, steps, m, rt, server, outdir, args)
                page = current_page(ctx, page)
                if not ok:
                    RESPONSES.clear()
                    say(f"   Could not download {rt} for {m['label']} automatically.", "y")
                    say(f"   In the browser: open Returns Dashboard > {m['fy']} > {m['month_name']} > {rt} and "
                        + ("click VIEW - the GSTR-3B data is read from the screen." if rt == "GSTR3B" else
                           "download the JSON file (GENERATE JSON FILE TO DOWNLOAD).") +
                        " It is picked up automatically.", "y")
                    if not args.no_prompt:
                        ask("   Press Enter here when done (or just Enter to skip) ... ")
                    process_queue(server, outdir, page, 2500)
                    if rt == "GSTR3B":
                        page = current_page(ctx, page)
                        ok = capture_json(page, ["sup_details", "itc_elg"], 3, m, rt, server, outdir)
                server.log(f"{m['label']} {rt}: {'downloaded' if ok else 'manual / skipped'}")
        STATE["rtype"] = STATE["period"] = ""
        say("\nAll automatic steps done. Any further file you download in this browser window is also imported.", "g")
        if not args.no_prompt:
            ask("Press Enter to finish and close the browser ... ")
        process_queue(server, outdir, page, 2000)
        if STATE.get("skipped"):
            say(f"{STATE['skipped']} PDF / Excel download(s) were not imported (JSON only).", "y")
        say(f"\nFinished: {STATE['uploaded']} file(s) imported, {STATE['failed']} not imported.", "g" if not STATE["failed"] else "y")
        server.log(f"Finished: {STATE['uploaded']} imported, {STATE['failed']} not imported", "done")
        ctx.close()
    shutil.rmtree(profile, ignore_errors=True)
    return 0


# ------------------------------------------------------------------ client master (profile) fetch
RESPONSES = []       # JSON answers the portal pages load in the background


def on_response(resp):
    try:
        ct = (resp.headers or {}).get("content-type", "")
        if "json" in ct.lower() and len(RESPONSES) < 300:
            RESPONSES.append(resp)
    except Exception:  # noqa: BLE001
        pass


def _collect(ctx, texts, jsons, wait_page=None):
    if wait_page is not None:
        try:
            wait_page.wait_for_timeout(1500)
        except Exception:  # noqa: BLE001
            pass
    for pg in ctx.pages:
        try:
            if not pg.is_closed():
                t = pg.inner_text("body", timeout=5000)
                if t and t not in texts:
                    texts.append(t)
        except Exception:  # noqa: BLE001
            continue
    while RESPONSES:
        r = RESPONSES.pop(0)
        try:
            body = r.json()
            if isinstance(body, (dict, list)) and len(json.dumps(body)) < 500000:
                jsons.append(body)
        except Exception:  # noqa: BLE001
            continue


def fetch_profile(page, ctx, steps, server, args):
    """After login: open the taxpayer profile, read every tab and send the text / JSON to the application."""
    prof = steps.get("profile", {})
    texts, jsons = [], []
    say("\nReading the registration details from the portal profile ...", "c")
    server.log("Reading the profile")
    _collect(ctx, texts, jsons, page)
    for url in prof.get("urls", []):
        try:
            page = current_page(ctx, page)
            page.goto(url, wait_until="domcontentloaded")
            _collect(ctx, texts, jsons, page)
        except Exception as e:  # noqa: BLE001
            say(f"   ({url}: {e.__class__.__name__})", "y")
    try:
        page = current_page(ctx, page)
        b = find_clickable(page, prof.get("link_texts", ["View Profile"]))
        if b is not None:
            n = len(ctx.pages)
            b.click()
            page.wait_for_timeout(2000)
            if len(ctx.pages) > n:
                page = ctx.pages[-1]
                page.wait_for_load_state("domcontentloaded")
            _collect(ctx, texts, jsons, page)
        for tab in prof.get("tab_texts", []):
            b = find_clickable(current_page(ctx, page), [tab])
            if b is not None:
                b.click()
                _collect(ctx, texts, jsons, page)
    except Exception as e:  # noqa: BLE001
        say(f"   ({e.__class__.__name__}: {str(e)[:150]})", "y")
    res = server.result(texts, jsons)
    if not res.get("ok"):
        say("   Could not read the GSTIN and legal name automatically.", "y")
        if not args.no_prompt:
            say("   In the browser open the profile yourself (e.g. 'View Profile' on the dashboard) and the tabs showing "
                "Business Details, Promoters / Partners and Authorised Signatories.", "y")
            ask("   Press Enter here when the profile is on the screen ... ")
            _collect(ctx, texts, jsons, current_page(ctx, page))
        res = server.result(texts, jsons, final=True)
    found = ", ".join(res.get("found") or []) or "nothing"
    say(f"\nRead from the portal: {found}; {res.get('people', 0)} partner(s) / signatory(ies).", "g" if res.get("ok") else "y")
    if res.get("gstin"):
        say(f"   {res.get('gstin')}  {res.get('legal_name', '')}", "g")
    say("Go back to the application to check the details and save them to the client master.", "g")
    server.log("Profile read" if res.get("ok") else "Profile read only partly - complete the details on screen")
    if not args.no_prompt:
        ask("Press Enter to close the browser ... ")
    return 0


def denied(pg, steps):
    u = (pg.url or "").lower()
    if any(x in u for x in steps.get("denied_url_contains", ["accessdenied", "/error/"])):
        return True
    try:
        t = pg.inner_text("body", timeout=2000).lower()
    except Exception:  # noqa: BLE001
        return False
    return "access denied" in t and "session is expired" in t


def on_dashboard(pg, steps):
    try:
        if denied(pg, steps):
            return False
        return first_visible(pg, steps["period_selects"]["fy"], 0) is not None
    except Exception:  # noqa: BLE001
        return False


def _settle(pg, ms=1500):
    try:
        pg.wait_for_load_state("domcontentloaded", timeout=20000)
    except Exception:  # noqa: BLE001
        pass
    pg.wait_for_timeout(ms)


def open_dashboard(page, ctx, steps, first):
    """Open the Returns Dashboard. The GST portal refuses a direct jump to return.gst.gov.in right after login
    ('Access Denied - session expired'): the returns site gets its session only when it is entered from the
    portal's own Dashboard button / Services menu. So: direct link only once that has happened, else click through."""
    if not first and STATE.get("dash_ok"):
        try:
            page.goto(steps["dashboard_url"], wait_until="domcontentloaded")
            _settle(page)
            if on_dashboard(page, steps):
                return page
        except Exception:  # noqa: BLE001
            pass
    for attempt in range(2):
        try:
            if attempt or denied(page, steps) or not first:
                page.goto(STATE.get("welcome") or steps.get("welcome_url"), wait_until="domcontentloaded")
                _settle(page, 2500)
            n = len(ctx.pages)
            b = find_clickable(page, steps.get("dashboard_link_texts", ["RETURN DASHBOARD"]))
            if b is not None:
                b.click()
            else:                                            # Services > Returns > Returns Dashboard
                for texts in steps.get("dashboard_menu", []):
                    m = find_clickable(page, texts)
                    if m is None:
                        break
                    try:
                        m.hover()
                    except Exception:  # noqa: BLE001
                        pass
                    m.click()
                    page.wait_for_timeout(800)
            _settle(page, 2500)
            if len(ctx.pages) > n:
                page = ctx.pages[-1]
                _settle(page, 2500)
            end = time.time() + 15
            while time.time() < end:
                if on_dashboard(page, steps):
                    STATE["dash_ok"] = True
                    return page
                if denied(page, steps):
                    break
                page.wait_for_timeout(700)
        except Exception as e:  # noqa: BLE001
            say(f"   ({e.__class__.__name__}: {str(e)[:120]})", "y")
    return None


def _find_dict(o, keys):
    if isinstance(o, dict):
        if any(k in o for k in keys):
            return o
        for v in o.values():
            r = _find_dict(v, keys)
            if r is not None:
                return r
    elif isinstance(o, list):
        for v in o:
            r = _find_dict(v, keys)
            if r is not None:
                return r
    return None


def capture_json(page, keys, timeout, m, rt, server, outdir):
    """The return's own data as the portal screen loads it (JSON) - saved as a JSON file and imported.
    Used for GSTR-3B, for which the portal offers only a PDF download."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            page.wait_for_timeout(700)
        except Exception:  # noqa: BLE001
            pass
        while RESPONSES:
            r = RESPONSES.pop(0)
            try:
                d = _find_dict(r.json(), keys)
            except Exception:  # noqa: BLE001
                continue
            if d is None:
                continue
            d = dict(d)
            rp = m["period"][5:7] + m["period"][:4]
            got = str(d.get("ret_period") or d.get("rtnprd") or "")
            if got and got != rp:
                continue                     # data of another period
            d.setdefault("ret_period", rp)
            d.setdefault("gstin", STATE.get("gstin", ""))
            target = outdir / f"{rt}_{d.get('gstin') or 'GSTIN'}_{rp}.json"
            target.write_text(json.dumps(d, indent=1), encoding="utf-8")
            say(f"   {rt} data read from the portal screen (JSON): {target.name} - sending to the application ...", "c")
            try:
                res = server.upload(target, rt, m["period"])
            except Exception as e:  # noqa: BLE001
                STATE["failed"] += 1
                say(f"   could not send {target.name}: {e}", "r")
                return False
            if res.get("ok"):
                STATE["uploaded"] += 1
                say(f"   IMPORTED: {res.get('message')}", "g")
                return True
            STATE["failed"] += 1
            say(f"   NOT imported: {res.get('message')}", "r")
            return False
    return False


def auto_download(page, ctx, steps, m, rt, server, outdir, args):
    try:
        page = open_dashboard(current_page(ctx, page), ctx, steps, first=False)
        if page is None:
            say("   (the Returns Dashboard did not open)", "y")
            return False
        ps = steps["period_selects"]
        okf = select_contains(page, ps["fy"], [m["fy"]], 0)
        okq = select_contains(page, ps["quarter"], m["quarter_texts"], 1)
        okm = select_contains(page, ps["month"], [m["month_name"]], 2)
        if not (okf and okm):
            say("   (could not select the period on the Returns Dashboard)", "y")
            return False
        b = find_clickable(page, steps["search_texts"])
        if b is None:
            return False
        b.click()
        page.wait_for_timeout(2500)
        for st in steps["returns"][rt]:
            page = current_page(ctx, page)
            n_pages = len(ctx.pages)
            timeout = st.get("timeout", 20)
            if st.get("tile"):
                btn = None
                end = time.time() + 10
                while btn is None and time.time() < end:
                    btn = find_in_tile(page, st["tile"], st["click"])
                    if btn is None:
                        page.wait_for_timeout(700)
            else:
                btn = None
                end = time.time() + (timeout if st.get("wait_for_text") else 10)
                while btn is None and time.time() < end:
                    btn = find_clickable(page, st["click"])
                    if btn is None:
                        process_queue(server, outdir, page, 1000)
            if btn is None:
                return False
            if st.get("capture_json"):
                RESPONSES.clear()
            btn.click()
            page.wait_for_timeout(1500)
            if len(ctx.pages) > n_pages:
                page = ctx.pages[-1]
                page.wait_for_load_state("domcontentloaded")
            if st.get("capture_json"):
                return capture_json(page, st["capture_json"], timeout, m, rt, server, outdir)
            if st.get("expect_download"):
                return wait_for_new_download(server, outdir, page, timeout)
        return True
    except Exception as e:  # noqa: BLE001
        say(f"   ({e.__class__.__name__}: {str(e)[:150]})", "y")
        return False


def main():
    ap = argparse.ArgumentParser(description="GST Portal Assistant")
    ap.add_argument("--server", default="")
    ap.add_argument("--code", default="")
    ap.add_argument("--steps")
    ap.add_argument("--browser-path")
    ap.add_argument("--download-dir")
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--no-sandbox", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--no-prompt", action="store_true")
    ap.add_argument("--login-timeout", type=int, default=900)
    ap.add_argument("--login-url")
    ap.add_argument("--dashboard-url")
    ap.add_argument("--logged-in-contains")
    ap.add_argument("--test-captcha", help=argparse.SUPPRESS)
    args = ap.parse_args()
    if os.name == "nt":
        os.system("")      # enable colours in the Windows console
    cfg = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "IDTRA" / "assistant_server.txt"
    if not args.server:
        if cfg.exists():
            args.server = cfg.read_text().strip()
        else:
            args.server = input("Address of the IDTRA application (e.g. http://SERVER:8765): ").strip()
    if not args.code:
        args.code = input("Enter the 8-character job code shown in the application: ").strip()
    rc = run(args)
    if rc == 0 and not args.no_prompt:
        pass
    elif rc and not args.no_prompt:
        ask("Press Enter to close ...")
    sys.exit(rc)


if __name__ == "__main__":
    main()
