"""Parsers for GST portal files (GSTR-1, GSTR-2B, GSTR-3B JSON) and for
Sales / Purchase / Expense registers exported from Tally (Excel / CSV)."""
import csv
import datetime as dt
import io
import json
import re
import zipfile
from pathlib import Path

import openpyxl


class ParseError(Exception):
    pass


def num(v):
    if v is None or v == "":
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "").replace("₹", "").replace("Rs.", "").replace("Rs", "")
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()").strip()
    if s.lower().endswith(" cr"):
        s = s[:-3]
    if s.lower().endswith(" dr"):
        s = s[:-3]
    try:
        f = float(s)
    except ValueError:
        return 0.0
    return -f if neg else f


def norm_inv(s):
    s = re.sub(r"[^A-Z0-9]", "", str(s or "").upper())
    s2 = s.lstrip("0")
    return s2 or s or ""


def norm_gstin(s):
    return re.sub(r"[^A-Z0-9]", "", str(s or "").upper())[:15]


GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z0-9]{10}[0-9A-Z]Z[0-9A-Z]$")


def valid_gstin(s):
    return bool(GSTIN_RE.match(norm_gstin(s)))


def to_iso(d):
    """Convert many date formats to YYYY-MM-DD; '' if not parseable."""
    if d is None or d == "":
        return ""
    if isinstance(d, dt.datetime):
        return d.date().isoformat()
    if isinstance(d, dt.date):
        return d.isoformat()
    if isinstance(d, (int, float)):  # Excel serial
        try:
            return (dt.date(1899, 12, 30) + dt.timedelta(days=int(d))).isoformat()
        except (OverflowError, ValueError):
            return ""
    s = str(d).strip()
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d-%b-%Y", "%d-%b-%y", "%d.%m.%Y",
                "%d/%m/%y", "%d-%m-%y", "%Y/%m/%d", "%d %b %Y", "%d-%B-%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            continue
    return ""


# ------------------------------------------------------------------ GST JSON
def load_json_file(path):
    path = Path(path)
    raw = path.read_bytes()
    if raw[:2] == b"PK":
        # the portal splits a large GSTR-1 into several JSON files in one ZIP (b2b, cdnr, others ...): read them all
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = sorted(n for n in z.namelist() if n.lower().endswith(".json"))
            if not names:
                raise ParseError("ZIP file does not contain a JSON file")
            merged = None
            for n in names:
                d = _json_bytes(z.read(n))
                merged = d if merged is None else _merge(merged, d)
            return merged
    return _json_bytes(raw)


def _json_bytes(raw):
    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            return json.loads(raw.decode(enc))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    raise ParseError("File is not valid JSON")


def _merge(a, b):
    """Combine two parts of one return: lists are joined, dicts merged, other values kept from the first."""
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            out[k] = _merge(out[k], v) if k in out else v
        return out
    if isinstance(a, list) and isinstance(b, list):
        return a + b
    return a if a not in (None, "", [], {}) else b


def _unwrap(d):
    if isinstance(d, dict) and "data" in d and isinstance(d["data"], dict) and len(d) <= 4:
        inner = d["data"]
        if any(k in inner for k in ("docdata", "sup_details", "itc_elg", "b2b", "b2cs", "hsn", "fp", "gstin")):
            return inner
    return d


def detect_type(d):
    d = _unwrap(d)
    if "docdata" in d:
        return "GSTR2B"
    if "sup_details" in d or "itc_elg" in d:
        return "GSTR3B"
    if "fp" in d or any(k in d for k in ("b2b", "b2cs", "b2cl", "hsn", "exp", "cdnr", "nil")):
        return "GSTR1"
    raise ParseError("Could not recognise this file as GSTR-1, GSTR-2B or GSTR-3B JSON")


def _itm_tax(it):
    det = it.get("itm_det", it)
    return (num(det.get("rt")), num(det.get("txval")), num(det.get("iamt")), num(det.get("camt")),
            num(det.get("samt")), num(det.get("csamt")))


def parse_gstr1(d):
    d = _unwrap(d)
    period = ""
    if d.get("fp"):
        from .law import from_ret_period
        period = from_ret_period(d["fp"])
    rows, hsn_rows = [], []
    nil = {"nil": 0.0, "exempt": 0.0, "non_gst": 0.0}

    def add(section, ctin, inv, sign=1.0, pos=""):
        inum = inv.get("inum") or inv.get("nt_num") or inv.get("ntnum") or ""
        idt = to_iso(inv.get("idt") or inv.get("nt_dt") or inv.get("dt"))
        for it in inv.get("itms", []) or []:
            rt, tx, ia, ca, sa, cs = _itm_tax(it)
            rows.append(dict(section=section, ctin=ctin, inv_no=inum, inv_norm=norm_inv(inum), inv_date=idt,
                             inv_value=num(inv.get("val")) * sign, pos=inv.get("pos", pos), rate=rt,
                             txval=tx * sign, igst=ia * sign, cgst=ca * sign, sgst=sa * sign, cess=cs * sign))

    for e in d.get("b2b", []) or []:
        for inv in e.get("inv", []) or []:
            add("B2B", norm_gstin(e.get("ctin")), inv)
    for e in d.get("b2cl", []) or []:
        for inv in e.get("inv", []) or []:
            add("B2CL", "", inv, pos=e.get("pos", ""))
    for e in d.get("exp", []) or []:
        for inv in e.get("inv", []) or []:
            add("EXP-" + str(e.get("exp_typ", "")), "", inv)
    for e in d.get("sez", []) or []:
        for inv in e.get("inv", []) or []:
            add("SEZ", norm_gstin(e.get("ctin")), inv)
    for e in d.get("b2cs", []) or []:
        rows.append(dict(section="B2CS", ctin="", inv_no="", inv_norm="", inv_date="", inv_value=0.0,
                         pos=e.get("pos", ""), rate=num(e.get("rt")), txval=num(e.get("txval")),
                         igst=num(e.get("iamt")), cgst=num(e.get("camt")), sgst=num(e.get("samt")),
                         cess=num(e.get("csamt"))))
    for e in d.get("cdnr", []) or []:
        for nt in e.get("nt", []) or []:
            sign = -1.0 if str(nt.get("ntty", "C")).upper() == "C" else 1.0
            add("CDNR", norm_gstin(e.get("ctin")), nt, sign)
    for nt in d.get("cdnur", []) or []:
        sign = -1.0 if str(nt.get("ntty", "C")).upper() == "C" else 1.0
        add("CDNUR", "", nt, sign)

    # ---- amendments (table 9A / 9C / 10): the amended document replaces the original one
    def amend(section, ctin, doc, sign=1.0, pos=""):
        n0 = len(rows)
        add(section, ctin, doc, sign, pos)
        oinv = doc.get("oinum") or doc.get("ont_num") or doc.get("ontnum") or ""
        for r in rows[n0:]:
            r.update(orig_inv=str(oinv), orig_ctin=ctin, orig_period="")
    for e in d.get("b2ba", []) or []:
        for inv in e.get("inv", []) or []:
            amend("B2BA", norm_gstin(e.get("ctin")), inv)
    for e in d.get("b2cla", []) or []:
        for inv in e.get("inv", []) or []:
            amend("B2CLA", "", inv, pos=e.get("pos", ""))
    for e in d.get("expa", []) or []:
        for inv in e.get("inv", []) or []:
            amend("EXPA-" + str(e.get("exp_typ", "")), "", inv)
    for e in d.get("cdnra", []) or []:
        for nt in e.get("nt", []) or []:
            sign = -1.0 if str(nt.get("ntty", "C")).upper() == "C" else 1.0
            amend("CDNRA", norm_gstin(e.get("ctin")), nt, sign)
    for nt in d.get("cdnura", []) or []:
        sign = -1.0 if str(nt.get("ntty", "C")).upper() == "C" else 1.0
        amend("CDNURA", "", nt, sign)
    for e in d.get("b2csa", []) or []:
        from .law import from_ret_period
        om = from_ret_period(e.get("omon", "")) if e.get("omon") else ""
        for it in e.get("itms", []) or [e]:
            rows.append(dict(section="B2CSA", ctin="", inv_no="", inv_norm="", inv_date="", inv_value=0.0,
                             pos=e.get("pos", ""), rate=num(it.get("rt")), txval=num(it.get("txval")),
                             igst=num(it.get("iamt")), cgst=num(it.get("camt")), sgst=num(it.get("samt")),
                             cess=num(it.get("csamt")), orig_inv="", orig_ctin="", orig_period=om))
    niljs = d.get("nil") or {}
    for e in (niljs.get("inv", []) if isinstance(niljs, dict) else []):
        nil["nil"] += num(e.get("nil_amt"))
        nil["exempt"] += num(e.get("expt_amt"))
        nil["non_gst"] += num(e.get("ngsup_amt"))
    hsn = d.get("hsn") or {}
    lists = []
    if isinstance(hsn, dict):
        for k, v in hsn.items():
            if isinstance(v, list):
                lists.append((k, v))
    elif isinstance(hsn, list):
        lists.append(("data", hsn))
    for k, lst in lists:
        tt = {"hsn_b2b": "B2B", "hsn_b2c": "B2C"}.get(k, "ALL")
        for h in lst:
            hsn_rows.append(dict(table_type=tt, hsn=str(h.get("hsn_sc", "")), description=h.get("desc", ""),
                                 uqc=h.get("uqc", ""), qty=num(h.get("qty")), rate=num(h.get("rt")),
                                 txval=num(h.get("txval")), igst=num(h.get("iamt")), cgst=num(h.get("camt")),
                                 sgst=num(h.get("samt")), cess=num(h.get("csamt"))))
    return {"type": "GSTR1", "gstin": d.get("gstin", ""), "period": period, "rows": rows,
            "hsn": hsn_rows, "nil": nil}


def _2b_inv_row(section, doc_type, ctin, trdnm, inv, sign=1.0):
    items = inv.get("items", []) or []
    tx = num(inv.get("txval")) if "txval" in inv else sum(num(i.get("txval")) for i in items)
    ig = num(inv.get("igst")) if "igst" in inv else sum(num(i.get("igst")) for i in items)
    cg = num(inv.get("cgst")) if "cgst" in inv else sum(num(i.get("cgst")) for i in items)
    sg = num(inv.get("sgst")) if "sgst" in inv else sum(num(i.get("sgst")) for i in items)
    cs = num(inv.get("cess")) if "cess" in inv else sum(num(i.get("cess")) for i in items)
    rate = 0.0
    if items:
        rate = num(max(items, key=lambda i: num(i.get("txval"))).get("rt"))
    elif tx:
        rate = round((ig + cg + sg) / tx * 100, 2)
    inum = inv.get("inum") or inv.get("ntnum") or inv.get("docnum") or inv.get("boenum") or ""
    # GSTR-2B normally has no HSN; when a version / e-invoice based download carries it, keep it
    hsn = ""
    for src in [inv] + list(items):
        for k in ("hsn", "hsn_sc", "hsnsc", "hsncd", "hsn_cd"):
            if src.get(k):
                hsn = str(src[k]).strip()
                break
        if hsn:
            break
    return dict(section=section, doc_type=doc_type, ctin=ctin, trade_name=trdnm, inv_no=str(inum), hsn=hsn,
                inv_norm=norm_inv(inum), inv_date=to_iso(inv.get("dt") or inv.get("docdt") or inv.get("boedt")),
                inv_value=num(inv.get("val")) * sign, rate=rate, txval=tx * sign, igst=ig * sign,
                cgst=cg * sign, sgst=sg * sign, cess=cs * sign, itc_avl=str(inv.get("itcavl", inv.get("itcelg", "Y"))),
                rev=str(inv.get("rev", "N")))


def parse_gstr2b(d):
    d = _unwrap(d)
    from .law import from_ret_period
    period = from_ret_period(d.get("rtnprd", ""))
    dd = d.get("docdata", {}) or {}
    rows = []
    for sec in ("b2b", "b2ba"):
        for e in dd.get(sec, []) or []:
            for inv in e.get("inv", []) or []:
                rows.append(_2b_inv_row(sec.upper(), "Invoice", norm_gstin(e.get("ctin")), e.get("trdnm", ""), inv))
    for sec in ("cdnr", "cdnra"):
        for e in dd.get(sec, []) or []:
            for nt in e.get("nt", []) or []:
                typ = str(nt.get("typ", "C")).upper()
                sign = -1.0 if typ == "C" else 1.0
                rows.append(_2b_inv_row(sec.upper(), "Credit Note" if typ == "C" else "Debit Note",
                                        norm_gstin(e.get("ctin")), e.get("trdnm", ""), nt, sign))
    for sec in ("impg", "impgsez"):
        for e in dd.get(sec, []) or []:
            r = _2b_inv_row(sec.upper(), "Bill of Entry", norm_gstin(e.get("ctin", "")), e.get("trdnm", ""), e)
            r["inv_no"] = str(e.get("boenum", ""))
            r["port_code"] = str(e.get("portcode", e.get("portcd", "")) or "")
            r["inv_norm"] = norm_inv(r["inv_no"])
            rows.append(r)
    for e in dd.get("isd", []) or []:
        sign = -1.0 if str(e.get("doctyp", "I")).upper() == "C" else 1.0
        rows.append(_2b_inv_row("ISD", "ISD", norm_gstin(e.get("ctin")), e.get("trdnm", ""), e, sign))
    return {"type": "GSTR2B", "gstin": d.get("gstin", ""), "period": period, "rows": rows}


def parse_gstr3b(d):
    d = _unwrap(d)
    from .law import from_ret_period
    period = from_ret_period(d.get("ret_period", d.get("rtnprd", "")))
    sd = d.get("sup_details", {}) or {}
    o = sd.get("osup_det", {}) or {}
    z = sd.get("osup_zero", {}) or {}
    ne = sd.get("osup_nil_exmp", {}) or {}
    ng = sd.get("osup_nongst", {}) or {}
    rc = sd.get("isup_rev", {}) or {}
    itc = d.get("itc_elg", {}) or {}
    avl = {"iamt": 0.0, "camt": 0.0, "samt": 0.0, "csamt": 0.0}
    for e in itc.get("itc_avl", []) or []:
        for k in avl:
            avl[k] += num(e.get(k))
    rev = {"iamt": 0.0, "camt": 0.0, "samt": 0.0, "csamt": 0.0}     # 4(B)(1) Rules 38/42/43 & 17(5)
    oth = {"iamt": 0.0, "camt": 0.0, "samt": 0.0, "csamt": 0.0}     # 4(B)(2) Others
    for e in itc.get("itc_rev", []) or []:
        tgt = oth if str(e.get("ty", "")).upper() == "OTH" else rev
        for k in rev:
            tgt[k] += num(e.get(k))
    row = dict(osup_txval=num(o.get("txval")), osup_igst=num(o.get("iamt")), osup_cgst=num(o.get("camt")),
               osup_sgst=num(o.get("samt")), osup_cess=num(o.get("csamt")), zero_txval=num(z.get("txval")),
               zero_igst=num(z.get("iamt")), nil_exempt=num(ne.get("txval")), non_gst=num(ng.get("txval")),
               rcm_txval=num(rc.get("txval")), itc_igst=avl["iamt"], itc_cgst=avl["camt"], itc_sgst=avl["samt"],
               itc_cess=avl["csamt"], itcrev_igst=rev["iamt"], itcrev_cgst=rev["camt"], itcrev_sgst=rev["samt"],
               itcrev_cess=rev["csamt"], itcrevoth_igst=oth["iamt"], itcrevoth_cgst=oth["camt"],
               itcrevoth_sgst=oth["samt"], itcrevoth_cess=oth["csamt"])
    return {"type": "GSTR3B", "gstin": d.get("gstin", ""), "period": period, "row": row}


GSTR1A_NAME = re.compile(r"gstr[-_ ]?1a|(?:^|[_\-])r1a(?:[_\-.]|$)|gstr1a", re.I)


def is_gstr1a(d, filename=""):
    d2 = _unwrap(d)
    for k in ("ret_typ", "rtn_typ", "return_type", "rtntype", "form_typ"):
        v = str((d2.get(k) if isinstance(d2, dict) else "") or (d.get(k) if isinstance(d, dict) else "") or "")
        if v.upper().replace("-", "") == "GSTR1A":
            return True
    return bool(GSTR1A_NAME.search(Path(filename).name)) if filename else False


def parse_portal_file(path, hint_type=None):
    d = load_json_file(path)
    t = detect_type(d)
    if t == "GSTR1" and (hint_type == "GSTR1A" or is_gstr1a(d, str(path))):
        res = parse_gstr1(d)
        res["type"] = "GSTR1A"
        for r in res["rows"]:
            r["section"] = "1A:" + r["section"]
        return res
    return {"GSTR1": parse_gstr1, "GSTR2B": parse_gstr2b, "GSTR3B": parse_gstr3b}[t](d)


# ------------------------------------------------------------- Book registers
SYNONYMS = {
    "inv_no": ["invoice no", "invoice number", "voucher no", "vch no", "bill no", "inv no", "document no",
               "supplier invoice no", "doc no", "voucher number", "ref no", "reference no", "supplier inv no"],
    "inv_date": ["invoice date", "date", "voucher date", "bill date", "inv date", "document date", "doc date",
                 "supplier invoice date", "ref date"],
    "gstin": ["gstin", "gstin/uin", "party gstin", "supplier gstin", "customer gstin", "gst no", "gstin of supplier",
              "gstin of recipient", "gst number", "gstin uin"],
    "party": ["party name", "particulars", "supplier name", "customer name", "party", "name", "ledger name",
              "name of supplier", "name of recipient", "trade name"],
    "hsn": ["hsn", "hsn/sac", "hsn code", "sac", "hsn sac", "hsn/sac code"],
    "description": ["item", "item name", "description", "stock item", "goods description", "product"],
    "rate": ["rate", "gst rate", "tax rate", "rate of tax", "gst %", "gst rate %", "rate %", "igst rate"],
    "txval": ["taxable value", "taxable amount", "assessable value", "taxable", "value", "net amount",
              "taxable val"],
    "inv_value": ["invoice value", "gross total", "total", "invoice amount", "bill amount", "total amount",
                  "gross amount"],
    "igst": ["igst", "integrated tax", "igst amount", "integrated tax amount"],
    "cgst": ["cgst", "central tax", "cgst amount", "central tax amount"],
    "sgst": ["sgst", "sgst/utgst", "state tax", "utgst", "sgst amount", "state/ut tax", "state tax amount"],
    "cess": ["cess", "cess amount", "compensation cess"],
    "supply_type": ["supply type", "type of supply", "nature of supply"],
    "category": ["category", "itc category", "eligibility", "type of input", "input type",
                 "category of input supplies"],
    "inward_type": ["inward type", "inward supply type", "rcm", "reverse charge", "type of inward supply"],
    "doc_type": ["document type", "doc type", "voucher type", "vch type", "type of document"],
    "trading": ["trading", "is trading", "trading goods", "traded"],
    "blocked": ["blocked", "17(5)", "blocked credit", "ineligible", "blocked u/s 17(5)"],
    "port_code": ["port code", "port", "portcode"],
    "itc_date": ["itc availed date", "itc date", "date of availment", "itc availment date"],
}


def _clean_head(h):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9/%() ]", " ", str(h or "").lower())).strip()


def _match_header(cells):
    mapping = {}
    for idx, c in enumerate(cells):
        h = _clean_head(c)
        if not h:
            continue
        for field, syns in SYNONYMS.items():
            if field in mapping:
                continue
            if h in syns:
                mapping[field] = idx
                break
    # second pass: contains
    for idx, c in enumerate(cells):
        h = _clean_head(c)
        if not h or idx in mapping.values():
            continue
        for field, syns in SYNONYMS.items():
            if field in mapping:
                continue
            if any(s in h for s in syns if len(s) > 4):
                mapping[field] = idx
                break
    return mapping


SHEET_WORDS = {"Sales": ["sales register", "sales", "outward"],
               "Purchase": ["purchase register", "purchase", "inward"],
               "Expense": ["journal register", "expense", "journal"]}


def read_table(path, register=None, note=None):
    """Return list of rows (list of cell values) from xlsx/xls/csv.
    A workbook with several sheets (e.g. Tally export with Sales Register + Purchase Register):
    the sheet named / titled after the register is used, otherwise the sheet with most rows."""
    p = Path(path)
    ext = p.suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        wb = openpyxl.load_workbook(p, data_only=True, read_only=True)
        sheets = [(w.title, [list(r) for r in w.iter_rows(values_only=True)]) for w in wb.worksheets]
        wb.close()
        if register and len(sheets) > 1:
            words = (SHEET_WORDS_NOTES.get(note, []) if note else []) + SHEET_WORDS.get(register, [])
            for word in words:
                for title, rows in sheets:
                    head = " ".join(str(c) for r in rows[:10] for c in r if isinstance(c, str)).lower()
                    if word in title.lower() or word in head:
                        return rows
        return max(sheets, key=lambda t: len(t[1]))[1] if sheets else []
    if ext in (".csv", ".txt"):
        raw = p.read_bytes()
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        return [r for r in csv.reader(io.StringIO(text))]
    if ext == ".xls":
        raise ParseError("Old .xls format: please open in Excel and 'Save As' .xlsx (Tally: Export -> Excel (xlsx)).")
    raise ParseError(f"Unsupported file type {ext}. Use .xlsx or .csv")


STD_RATES = [0, 0.1, 0.25, 1, 1.5, 3, 5, 6, 7.5, 12, 18, 28, 40]


def snap_rate(r):
    if r <= 0:
        return 0.0
    return float(min(STD_RATES, key=lambda s: abs(s - r)))


NOTE_KINDS = {"CN": "Credit Note", "DN": "Debit Note"}
SHEET_WORDS_NOTES = {"CN": ["credit note register", "credit note", "sales return"],
                     "DN": ["debit note register", "debit note", "purchase return"]}


def parse_register(path, register, note=None):
    """register in {'Sales','Purchase','Expense'}; note None (invoices - credit / debit notes inside the file are
    recognised by their voucher / document type) or 'CN' / 'DN' (the whole file is a credit / debit note register).
    Sales: credit notes reduce, debit notes increase the outward supplies.
    Purchase: 'CN' = purchase returns / supplier credit notes (reduce ITC), 'DN' = supplier debit notes (increase).
    Returns (rows, warnings)."""
    table = read_table(path, register, note)
    if not table:
        raise ParseError("The file is empty")
    col = tally_columnar_header(table)
    if col is not None:
        rows, warnings = parse_tally_columnar(table, col, register, note)
        return rows, warnings
    hdr_idx, mapping = None, {}
    for i, r in enumerate(table[:25]):
        m = _match_header(r)
        if "inv_no" in m and ("txval" in m or "inv_value" in m) and len(m) >= 4:
            hdr_idx, mapping = i, m
            break
    if hdr_idx is None:
        raise ParseError("Could not find a header row. Required columns: Invoice No, Date, Taxable Value "
                         "and tax columns (IGST/CGST/SGST). Use the template provided in the Books tab.")
    warnings = []
    if "hsn" not in mapping:
        warnings.append("HSN/SAC column not found - HSN set to 'NA'. Add HSN for correct inverted turnover.")
    if "rate" not in mapping:
        warnings.append("Rate column not found - rate derived from tax / taxable value.")
    rows = []
    for ri, r in enumerate(table[hdr_idx + 1:], start=hdr_idx + 2):
        def g(f, default=None):
            i = mapping.get(f)
            if i is None or i >= len(r):
                return default
            return r[i]
        inv = g("inv_no")
        if inv is None or str(inv).strip() == "":
            continue
        sinv = str(inv).strip()
        if sinv.lower() in ("total", "grand total", "sub total"):
            continue
        if isinstance(inv, float) and inv.is_integer():
            sinv = str(int(inv))
        igst, cgst, sgst, cess = num(g("igst")), num(g("cgst")), num(g("sgst")), num(g("cess"))
        txval = num(g("txval")) if "txval" in mapping else num(g("inv_value")) - igst - cgst - sgst - cess
        inv_value = num(g("inv_value")) if "inv_value" in mapping else txval + igst + cgst + sgst + cess
        rate = num(g("rate"))
        if rate and rate < 1 and rate not in (0.1, 0.25):   # given as 0.18
            rate = rate * 100
        if not rate and txval:
            rate = snap_rate(abs((igst + cgst + sgst) / txval * 100))
        idate = to_iso(g("inv_date"))
        hsn = str(g("hsn", "") or "").strip()
        if hsn.endswith(".0"):
            hsn = hsn[:-2]
        hsn = hsn or "NA"
        doc = str(g("doc_type", "") or "").strip().lower()
        doc_type = "Credit Note" if "credit" in doc else ("Debit Note" if "debit" in doc else "Invoice")
        if note:
            doc_type = NOTE_KINDS[note]
        elif register != "Sales" and doc_type == "Debit Note":
            doc_type = "Credit Note"          # debit note in purchases = purchase return (reduces ITC)
        sign = _note_sign(register, doc_type, txval, note)
        base = dict(inv_no=sinv, inv_norm=norm_inv(sinv), inv_date=idate,
                    tax_period=idate[:7] if idate else "", hsn=hsn,
                    description=str(g("description", "") or "")[:200], rate=rate,
                    txval=txval * sign, igst=igst * sign, cgst=cgst * sign, sgst=sgst * sign, cess=cess * sign,
                    doc_type=doc_type, src_row=ri,
                    is_trading=1 if str(g("trading", "") or "").strip().lower() in ("y", "yes", "1", "true") else 0)
        if not idate:
            warnings.append(f"Row {ri}: invoice date not readable ('{g('inv_date')}')")
        if register == "Sales":
            st = str(g("supply_type", "") or "Taxable").strip().lower()
            if "zero" in st or "export" in st or "sez" in st:
                st = "Zero Rated"
            elif "nil" in st:
                st = "Nil Rated"
            elif "non" in st:
                st = "Non-GST"
            elif "exempt" in st:
                st = "Exempt"
            else:
                st = "Taxable"
            base.update(party_gstin=norm_gstin(g("gstin", "")), party_name=str(g("party", "") or "")[:200],
                        supply_type=st)
        else:
            cat = str(g("category", "") or "").strip().lower()
            if "capital" in cat:
                category = "Capital Goods"
            elif "service" in cat:
                category = "Input Services"
            elif "input" in cat or "goods" in cat:
                category = "Inputs"
            else:
                category = "Input Services" if register == "Expense" else "Inputs"
            it = str(g("inward_type", "") or "").strip().lower()
            if it in ("y", "yes", "rcm", "reverse charge") or "reverse" in it or "rcm" in it:
                inward = "RCM"
            elif "import" in it and "serv" in it:
                inward = "Import of Services"
            elif "import" in it or "boe" in it:
                inward = "Import of Goods"
            elif "isd" in it:
                inward = "ISD"
            else:
                inward = "Regular"
            blk = str(g("blocked", "") or "").strip().lower() in ("y", "yes", "1", "true")
            base.update(register=register, supplier_gstin=norm_gstin(g("gstin", "")),
                        supplier_name=str(g("party", "") or "")[:200], inv_value=inv_value * sign,
                        category=category, inward_type=inward, blocked_17_5=1 if blk else 0,
                        itc_availed_date=to_iso(g("itc_date")) or (idate or ""),
                        port_code=str(g("port_code", "") or "").strip().upper())
            # ITC is claimed in the period in which it is availed in books / GSTR-3B
            if base["itc_availed_date"]:
                base["tax_period"] = base["itc_availed_date"][:7]
        rows.append(base)
    if not rows:
        raise ParseError("No data rows found below the header row")
    return rows, warnings



# ------------------------------------------------------------- Tally columnar register
# Tally Prime "Sales Register / Purchase Register" exported in columnar form: one row per voucher,
# one column per ledger ("SALES LOCAL 73 - 5%", "PURCHASE OMS 18%", "Repair & Maintenance", "IGST", "CGST" ...),
# item names on the lines below the voucher. There is no taxable-value / HSN / rate column: the taxable value
# is read from each sales / purchase / expense ledger column, the rate from the ledger name (or from the tax),
# and the tax of the voucher is spread over its ledgers.
META_COLS = ["date", "particulars", "buyer", "supplier", "party", "consignee", "voucher type", "vch type",
             "voucher no", "vch no", "voucher ref", "ref no", "supplier invoice no", "supplier invoice date",
             "invoice no", "gstin", "gst no", "pan", "gross total", "narration", "address", "quantity",
             "value", "voucher number", "bill no", "state", "place of supply"]
IGNORE_COLS = ["round", "tcs", "tds", "rounding", "r/off", "kasar"]
CAPITAL_WORDS = ["dies", "die ", "mould", "mold", "machine", "plant", "furniture", "computer", "laptop",
                 "fixed asset", "capital", "vehicle", "equipment", "air condition", "building"]
GOODS_WORDS = ["purchase", "material", "tools", "glass", "consumable", "stationery", "spare", "raw", "goods",
               "packing", "stores", "coil", "sheet", "steel", "chemical", "oil", "gas", "fuel"]
SERVICE_WORDS = ["repair", "maintenance", "telephone", "mobile", "internet", "labour", "labor", "job work",
                 "transport", "freight", "cartage", "bank", "rent", "professional", "consult", "audit", "legal",
                 "commission", "insurance", "courier", "security", "service", "charges", "fees", "brokerage",
                 "advertis", "software", "hire", "testing", "travel", "printing"]
BLOCKED_WORDS = ["food", "canteen", "gift", "club", "membership", "motor car", "beauty", "health insurance",
                 "life insurance", "staff welfare"]


def _lower(c):
    return re.sub(r"\s+", " ", str(c or "").strip().lower())


def tally_columnar_header(table):
    """Index of the header row of a Tally columnar register, or None."""
    for i, r in enumerate(table[:25]):
        cells = [_lower(c) for c in r]
        if "date" in cells and "particulars" in cells and any(c.startswith("gross total") for c in cells) \
                and not any(c in ("taxable value", "taxable amount", "hsn", "hsn/sac", "hsn code") for c in cells):
            return i
    return None


def _col_kind(h):
    if not h:
        return "skip"
    if any(w in h for w in IGNORE_COLS):
        return "skip"
    if re.search(r"\bigst\b|integrated", h):
        return "igst"
    if re.search(r"\bcgst\b|central tax", h):
        return "cgst"
    if re.search(r"\bsgst\b|\butgst\b|state tax", h):
        return "sgst"
    if re.search(r"\bcess\b", h):
        return "cess"
    if any(h == m or h.startswith(m) for m in META_COLS):
        return "meta"
    return "ledger"


def _ledger_rate(name):
    m = re.search(r"(\d+(?:\.\d+)?)\s*%", name)
    return float(m.group(1)) if m else None


def _ledger_hsn(name):
    n = re.sub(r"(\d+(?:\.\d+)?)\s*%", " ", name)
    m = re.search(r"\b(\d{2}|\d{4}|\d{6}|\d{8})\b", n)
    return m.group(1) if m else ""


def _purchase_category(name, register):
    n = name.lower()
    if any(w in n for w in CAPITAL_WORDS):
        return "Capital Goods"
    if any(w in n for w in GOODS_WORDS):
        return "Inputs"
    if any(w in n for w in SERVICE_WORDS):
        return "Input Services"
    return "Input Services" if register == "Expense" else "Inputs"


def _note_sign(register, doc_type, amount, note=None):
    """Sign for a note line. Sales: credit note -, debit note +. Purchase: supplier credit note / purchase return -,
    supplier debit note +. Amounts already shown negative in the file are kept as they are."""
    if amount < 0:
        return 1.0
    return -1.0 if doc_type == "Credit Note" else 1.0


def parse_tally_columnar(table, hdr_idx, register, note=None):
    header = [str(c or "").strip() for c in table[hdr_idx]]
    low = [_lower(c) for c in header]
    kinds = [_col_kind(h) for h in low]

    def idx(*names):
        for n in names:
            for i, h in enumerate(low):
                if h == n:
                    return i
        for n in names:
            for i, h in enumerate(low):
                if h.startswith(n):
                    return i
        return None

    i_date = idx("date")
    i_part = idx("particulars")
    i_party = idx("buyer", "supplier", "party", "consignee")
    i_vtype = idx("voucher type", "vch type")
    i_inv = idx("supplier invoice no", "voucher no", "vch no", "invoice no", "voucher ref. no", "voucher ref no",
                "voucher ref", "bill no") if register != "Sales" else \
        idx("voucher no", "vch no", "invoice no", "voucher ref. no", "voucher ref no", "voucher ref", "bill no")
    i_inv2 = idx("voucher ref. no", "voucher ref no", "voucher ref", "voucher no", "vch no")
    i_gstin = idx("gstin/uin", "gstin", "gst no")
    i_gross = idx("gross total")
    ledgers = [i for i, k in enumerate(kinds) if k == "ledger"]
    if not ledgers:
        raise ParseError("Tally register without sales / purchase ledger columns - export it with the ledger "
                         "columns (columnar register) or use the template in the Books tab.")
    rows, warnings, auto_no = [], [], 0
    current = None

    def g(r, i):
        return r[i] if i is not None and i < len(r) else None

    for ri, r in enumerate(table[hdr_idx + 1:], start=hdr_idx + 2):
        d = g(r, i_date)
        part = str(g(r, i_part) or "").strip()
        if part.lower() in ("grand total", "total") or str(d or "").strip().lower() in ("grand total", "total"):
            break
        idate = to_iso(d) if d not in (None, "") else ""
        if not idate:
            if current is not None and part and not any(num(g(r, i)) for i in ledgers):
                current["items"].append(part)          # item line below the voucher
            continue
        vt = str(g(r, i_vtype) or "").strip().lower()
        doc_type = "Credit Note" if "credit" in vt else ("Debit Note" if "debit" in vt else "Invoice")
        if note:
            doc_type = NOTE_KINDS[note]
        elif register != "Sales" and doc_type == "Debit Note":
            doc_type = "Credit Note"          # Tally debit note in purchases = purchase return (reduces ITC)
        inv = str(g(r, i_inv) or "").strip() or str(g(r, i_inv2) or "").strip()
        if inv.endswith(".0") and inv[:-2].isdigit():
            inv = inv[:-2]
        tax = {k: sum(num(g(r, i)) for i, kk in enumerate(kinds) if kk == k) for k in ("igst", "cgst", "sgst", "cess")}
        led = [(header[i], num(g(r, i))) for i in ledgers if num(g(r, i))]
        if not led and not any(tax.values()):          # cancelled voucher
            current = None
            continue
        if not inv:
            auto_no += 1
            inv = f"AUTO/{idate.replace('-', '')}/{auto_no}"
        current = {"row": ri, "date": idate, "inv": inv, "doc": doc_type, "gstin": norm_gstin(g(r, i_gstin)),
                   "party": str(g(r, i_party) or part or "")[:200], "tax": tax, "led": led, "items": [],
                   "gross": num(g(r, i_gross))}
        rows.append(current)

    out = []
    for v in rows:
        T = v["tax"]["igst"] + v["tax"]["cgst"] + v["tax"]["sgst"]
        known = [(n, a, _ledger_rate(n)) for n, a in v["led"]]
        exp = sum(a * r / 100 for n, a, r in known if r is not None)
        unk = sum(a for n, a, r in known if r is None)
        ru = 0.0
        if unk and abs(T - exp) > 0.01:
            ru = snap_rate(abs((T - exp) / unk * 100))
        lines = []
        for n, a, r in known:
            rate = r if r is not None else ru
            lines.append([n, a, rate, a * rate / 100])
        calc = sum(l[3] for l in lines)
        for l in lines:   # the voucher's actual tax, spread in proportion to the computed tax
            l[3] = T * l[3] / calc if calc else 0.0
        sign = _note_sign(register, v["doc"], sum(a for _, a in v["led"]), note)
        inter = abs(v["tax"]["igst"]) > 0.005 and abs(v["tax"]["cgst"]) < 0.005
        cs = v["tax"]["cgst"] + v["tax"]["sgst"]
        items = ", ".join(dict.fromkeys(v["items"]))
        for n, a, rate, t in lines:
            if inter:
                ig, cg, sg = t, 0.0, 0.0
            else:
                ig = 0.0
                cg = t * (v["tax"]["cgst"] / cs) if cs else t / 2
                sg = t - cg
            ces = v["tax"]["cess"] * (a / sum(x[1] for x in lines)) if v["tax"]["cess"] and sum(x[1] for x in lines) else 0.0
            base = dict(inv_no=v["inv"], inv_norm=norm_inv(v["inv"]), inv_date=v["date"], tax_period=v["date"][:7],
                        hsn=_ledger_hsn(n) or "NA", description=(f"{n}" + (f" - {items}" if items else ""))[:200],
                        rate=rate, txval=a * sign, igst=ig * sign, cgst=cg * sign, sgst=sg * sign, cess=ces * sign,
                        doc_type=v["doc"], src_row=v["row"], is_trading=0)
            if register == "Sales":
                st = "Taxable" if (rate or t) else "Nil Rated"
                if v["gstin"][:2] and v["gstin"][:2] == "SE":
                    st = "Zero Rated"
                base.update(party_gstin=v["gstin"], party_name=v["party"], supply_type=st)
            else:
                nl = n.lower()
                inward = "RCM" if ("rcm" in nl or "reverse" in nl) else "Regular"
                if "import" in nl:
                    inward = "Import of Services" if any(w in nl for w in SERVICE_WORDS) else "Import of Goods"
                blk = 1 if any(w in nl for w in BLOCKED_WORDS) else 0
                base.update(register=register, supplier_gstin=v["gstin"], supplier_name=v["party"],
                            inv_value=(v["gross"] if len(lines) == 1 else a + ig + cg + sg) * sign,
                            category=_purchase_category(n, register), inward_type=inward, blocked_17_5=blk,
                            itc_availed_date=v["date"], port_code="")
            out.append(base)
    if not out:
        raise ParseError("No vouchers found below the header row of the Tally register")
    warnings.append(f"Tally columnar register read: {len(rows)} voucher(s) split into {len(out)} line(s) by ledger. "
                    "Taxable value and rate are taken from the ledger columns (e.g. 'SALES LOCAL 73 - 5%'); HSN is "
                    "taken from the ledger name where it contains a code, otherwise 'NA' - check the Books tab.")
    if auto_no:
        warnings.append(f"{auto_no} voucher(s) have no invoice / voucher number in the export - numbered "
                        "AUTO/date/serial. Books are then compared with GSTR-1 party-wise (GSTIN), not invoice-wise. "
                        "Tip: in Tally press F12 / Configure and set 'Show Voucher Number' before exporting.")
    if register != "Sales":
        cats = {}
        for o in out:
            cats[o["category"]] = cats.get(o["category"], 0) + 1
        warnings.append("Ledgers classified as " + ", ".join(f"{k}: {v}" for k, v in cats.items()) +
                        " - correct any line on the Books tab if needed.")
    return out, warnings
