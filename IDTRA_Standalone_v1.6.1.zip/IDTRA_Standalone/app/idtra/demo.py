"""Loads a demo company with sample data (for trial on a standalone laptop).
Usage: python -m idtra.demo <Sample_Data folder>
"""
import json
import shutil
import sys
from pathlib import Path

from . import config, db, importer, security, storage
from .web import create_app

GSTIN = "27AAACS1234F1Z5"


def load(sample_dir):
    sample = Path(sample_dir)
    cfg = config.load()
    create_app(cfg)                       # initialises database, key, folders
    if db.q1("SELECT id FROM clients WHERE gstin=?", (GSTIN,)):
        print("Demo company already loaded - open 'All Claims' in the application.")
        return None
    if not db.get_setting("firm_name"):
        db.set_setting("firm_name", "Demo & Associates")
        db.set_setting("firm_frn", "100000W")
        db.set_setting("firm_city", "Pune")
    if not db.q1("SELECT id FROM ca_master WHERE membership_no='123456'"):
        db.insert("ca_master", dict(firm_name="Demo & Associates", frn="100000W", ca_name="CA Demo Partner",
                                    membership_no="123456", designation="Partner", city="Pune", active=1,
                                    created_at=db.now(), updated_at=db.now()))
    name = "Sunrise Polysacks Pvt Ltd (DEMO)"
    cid = db.insert("clients", dict(legal_name=name, trade_name="Sunrise Polysacks", gstin=GSTIN, pan=GSTIN[2:12],
                                    state="Maharashtra", constitution="Private Limited Company",
                                    address="Plot 12, MIDC Bhosari, Pune 411026 (fictitious demo company)",
                                    filing_freq="Monthly", gst_username="demo_user",
                                    gst_password_enc=security.encrypt("Demo@123"),
                                    folder_name=storage.client_folder_name(name, GSTIN), created_at=db.now(),
                                    updated_at=db.now()))
    db.insert("client_signatories", dict(client_id=cid, name="Rajesh Mehta (Demo)", designation="Director",
                                         pan="ABCPM1234K", is_default=1))
    claim_id = db.insert("claims", dict(client_id=cid, fy="2026-27", period_from="2026-07", period_to="2026-09",
                                        filing_date="2026-11-20", status="Draft", created_by="demo",
                                        created_at=db.now(), updated_at=db.now(), options_json=json.dumps({})))
    claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
    client = db.q1("SELECT * FROM clients WHERE id=?", (cid,))
    folder = storage.claim_dir(claim, client)
    db.update("claims", claim_id, {"folder": storage.rel(folder),
                                   "signatory_id": db.q1("SELECT id FROM client_signatories WHERE client_id=?", (cid,))["id"]})
    for f in sorted(sample.glob("GSTR*.json")):
        dst = folder / "01_Portal_Downloads" / f.name
        shutil.copy(f, dst)
        claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
        importer.import_portal(claim, client, dst, "demo")
    for fn, reg in (("Sales_Register_Tally.xlsx", "Sales"), ("Purchase_Register_Tally.xlsx", "Purchase"),
                    ("Expense_Register_Tally.xlsx", "Expense")):
        dst = folder / "02_Books_of_Account" / fn
        shutil.copy(sample / fn, dst)
        importer.import_register(claim, dst, reg, "demo")
        storage.register_doc(claim_id, f"{reg} Register (uploaded)", dst, "demo")
    db.update("claims", claim_id, {"status": "Data Imported"})
    db.audit("demo", "Demo company loaded", claim_id)
    print(f"Demo company loaded: {name}, claim Jul-2026 to Sep-2026 (data imported).")
    return claim_id


if __name__ == "__main__":
    load(sys.argv[1] if len(sys.argv) > 1 else "Sample_Data")
