"""Import of portal returns in Excel and PDF formats (JSON/ZIP are handled in parsers.py).

Excel  : GSTR-2B details (portal download, sheets B2B / B2BA / B2B-CDNR / ISD / IMPG ...),
         GSTR-1 Excel workbook (offline-tool template: b2b, b2cl, b2cs, cdnr, cdnur, exp, exemp, hsn ...)
PDF    : GSTR-3B (filed / system generated) - tables 3.1 and 4 are read;
         GSTR-1 - total liability read where available; GSTR-2B - kept as a document (no invoice detail).
All results use the same structures as the JSON parsers.
"""
import re
from pathlib import Path

import openpyxl

from .parsers import ParseError, norm_gstin, norm_inv, num, to_iso

MONTHS = {m: i for i, m in enumerate(["january", "february", "march", "april", "may", "june", "july", "august",
                                       "september", "october", "november", "december"], start=1)}
MON3 = {k[:3]: v for k, v in MONTHS.items()}


# ----------------------------------------------------------------- period detection
def period_from_text(text):
    """Find a return period in free text. Priority: labelled month ('Period July' / 'Tax Period July' with
    'Year 2026-27'), then 'Return Period 072026', then a bare MMYYYY / 'Jul-2026' - never part of a full date
    such as an ARN date '20/08/2026'."""
    t = text or ""
    fy = re.search(r"(?:financial\s+year|year|fy)\s*[:\-]?\s*(20\d{2})\s*[-/]\s*(\d{2,4})", t, re.I) or \
        re.search(r"\b(20\d{2})\s*-\s*(\d{2})\b", t)
    mon = re.search(r"(?:tax\s+period|return\s+period|period|month)\s*[:\-]?\s*([A-Za-z]{3,9})\b", t, re.I)
    if mon and mon.group(1).lower()[:3] in MON3:
        mm = MON3[mon.group(1).lower()[:3]]
        if fy:
            start = int(fy.group(1))
            y = start if mm >= 4 else start + 1
            return f"{y:04d}-{mm:02d}"
        ym = re.search(r"\b(20\d{2})\b", t[mon.end():mon.end() + 40])
        if ym:
            return f"{ym.group(1)}-{mm:02d}"
    m = re.search(r"(?:return\s+period|ret_?period|rtnprd|tax\s+period|period)\s*[:\-]?\s*(0[1-9]|1[0-2])[\-/ ]?(20\d{2})", t, re.I)
    if m:
        return f"{m.group(2)}-{m.group(1)}"
    m = re.search(r"(?<![\d/.\-])(0[1-9]|1[0-2])[\-_ ]?(20\d{2})(?!\d)", t)
    if m:
        return f"{m.group(2)}-{m.group(1)}"
    m2 = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s\-_,']*(20\d{2})\b", t, re.I)
    if m2:
        return f"{m2.group(2)}-{MON3[m2.group(1).lower()]:02d}"
    return ""


# ----------------------------------------------------------------- Excel helpers
def _cell(v):
    return "" if v is None else str(v).strip()


def _norm(h):
    return re.sub(r"[^a-z0-9/%]+", " ", str(h or "").lower()).strip()


def _find_header(rows, must):
    for i, r in enumerate(rows[:30]):
        hs = [_norm(c) for c in r]
        if all(any(m in h for h in hs) for m in must):
            return i
    return None


def _headers(rows, i):
    """Combine a 2-row header (group row + sub row) into one list of labels."""
    top = [_norm(c) for c in rows[i]]
    sub = [_norm(c) for c in rows[i + 1]] if i + 1 < len(rows) else []
    out = []
    for j in range(max(len(top), len(sub))):
        s = sub[j] if j < len(sub) else ""
        t = top[j] if j < len(top) else ""
        out.append(s or t)
    data_start = i + 2 if any(sub) and not any(re.match(r"^\d{2}[A-Z]", _cell(c)) for c in rows[i + 1]) else i + 1
    return out, data_start


def _col(hdrs, *keys, exclude=()):
    for k in keys:
        for j, h in enumerate(hdrs):
            if k in h and not any(x in h for x in exclude):
                return j
    return None


def _wb_rows(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    out = {}
    try:
        for ws in wb.worksheets:
            out[ws.title] = [list(r) for r in ws.iter_rows(values_only=True)]
    finally:
        wb.close()
    return out


def detect_excel(sheets):
    names = [n.lower() for n in sheets]
    joined = " ".join(_cell(c) for n in list(sheets)[:3] for r in sheets[n][:15] for c in r).lower()
    if "gstr-2b" in joined or "gstr2b" in joined or any(n.startswith("b2b-cdnr") or n == "impg" for n in names):
        return "GSTR2B"
    if any(n.startswith("b2b,") or n in ("b2cs", "b2cl", "hsn(b2b)", "hsn(b2c)", "exemp", "hsn") for n in names) \
            or "gstr-1" in joined or "gstr1" in joined:
        return "GSTR1"
    if "gstr-3b" in joined or "gstr3b" in joined:
        return "GSTR3B"
    return ""


def _gstin_and_period(sheets):
    """GSTIN / period only from labelled cells ('GSTIN', 'Tax Period', 'Financial Year', 'Return Period') -
    never from invoice rows (they contain customers' GSTINs and invoice dates)."""
    gstin, fy, mon, rp = "", "", "", ""
    for n in sheets:
        for r in sheets[n][:15]:
            cells = [_cell(c) for c in r]
            for i, c in enumerate(cells):
                lab = c.lower().rstrip(":").strip()
                nxt = next((x for x in cells[i + 1:] if x), "")
                if lab in ("gstin", "gstin of the taxpayer", "gstin of taxpayer") and re.match(r"^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$", nxt):
                    gstin = gstin or nxt
                elif lab in ("financial year", "fy"):
                    fy = fy or nxt
                elif lab in ("tax period", "month", "period"):
                    mon = mon or nxt
                elif lab in ("return period", "ret period"):
                    rp = rp or nxt
    period = ""
    if rp:
        period = period_from_text(rp)
    elif mon:
        period = period_from_text(f"Tax Period {mon} {('Year ' + fy) if fy else ''}")
    return gstin, period


# ----------------------------------------------------------------- GSTR-2B Excel
def parse_gstr2b_excel(path):
    sheets = _wb_rows(path)
    gstin, period = _gstin_and_period(sheets)
    period = period or period_from_text(Path(path).stem)
    rows = []
    for name, data in sheets.items():
        lname = name.lower().replace(" ", "")
        if lname in ("readme", "itcavailable", "itcnotavailable", "itcreversal", "itcrejected") or "summary" in lname \
                or "read" in lname:
            continue
        hi = _find_header(data, ["taxable value"]) or _find_header(data, ["integrated tax"])
        if hi is None:
            continue
        hdr, start = _headers(data, hi)
        c = {"gstin": _col(hdr, "gstin of supplier", "gstin of isd", "gstin"),
             "name": _col(hdr, "trade/legal name", "trade legal name", "legal name", "trade name"),
             "no": _col(hdr, "invoice number", "note number", "isd invoice number", "isd document number",
                        "document number", "number", exclude=("gstin",)),
             "type": _col(hdr, "note type", "isd document type", "document type"),
             "date": _col(hdr, "invoice date", "note date", "isd invoice date", "document date", "date",
                          exclude=("filing", "irn", "icegate", "reference")),
             "value": _col(hdr, "invoice value", "note value", "document value", "value", exclude=("taxable",)),
             "port": _col(hdr, "port code"),
             "txval": _col(hdr, "taxable value"),
             "igst": _col(hdr, "integrated tax"), "cgst": _col(hdr, "central tax"), "sgst": _col(hdr, "state/ut tax", "state ut tax", "state tax"),
             "cess": _col(hdr, "cess"), "itc": _col(hdr, "itc availability", "eligibility of itc", "itc eligibility"),
             "rcm": _col(hdr, "reverse charge"), "rate": _col(hdr, "rate")}
        if c["igst"] is None or c["no"] is None:
            continue
        sec = name.upper().replace(" ", "")
        is_note = "CDN" in sec
        is_impg = sec.startswith("IMPG")
        is_isd = sec.startswith("ISD")
        for r in data[start:]:
            def g(k):
                j = c.get(k)
                return r[j] if j is not None and j < len(r) else None
            no = _cell(g("no"))
            if not no or no.lower().startswith("total"):
                continue
            if isinstance(g("no"), float) and float(g("no")).is_integer():
                no = str(int(g("no")))
            typ = _cell(g("type")).lower()
            sign = -1.0 if (is_note and typ.startswith("c")) or (is_isd and "credit" in typ) else 1.0
            ig, cg, sg, cs = num(g("igst")), num(g("cgst")), num(g("sgst")), num(g("cess"))
            tx = num(g("txval"))
            rate = num(g("rate")) if c.get("rate") is not None and "%" not in str(hdr[c["rate"]]) else 0.0
            if not rate and tx:
                rate = round((ig + cg + sg) / tx * 100, 2)
            itc = _cell(g("itc")) or "Yes"
            rows.append(dict(
                section=("IMPG" if is_impg else "ISD" if is_isd else "CDNR" if is_note else "B2B") + ("A" if sec.endswith("A") and not is_impg else ""),
                doc_type="Bill of Entry" if is_impg else "ISD" if is_isd else ("Credit Note" if sign < 0 else "Debit Note") if is_note else "Invoice",
                ctin=norm_gstin(g("gstin")) if not is_impg else "", trade_name=_cell(g("name")), inv_no=no,
                inv_norm=norm_inv(no), inv_date=to_iso(g("date")), inv_value=num(g("value")) * sign, rate=rate,
                txval=tx * sign, igst=ig * sign, cgst=cg * sign, sgst=sg * sign, cess=cs * sign,
                itc_avl="Y" if itc.lower().startswith(("y", "eligible")) else "N", rev="Y" if _cell(g("rcm")).lower().startswith("y") else "N",
                port_code=_cell(g("port")).upper()))
    if not rows:
        raise ParseError("No invoice rows found in the GSTR-2B Excel file (expected sheets B2B, B2B-CDNR, IMPG ...).")
    return {"type": "GSTR2B", "gstin": gstin, "period": period, "rows": rows}


# ----------------------------------------------------------------- GSTR-1 Excel workbook
def _pos_code(pos):
    m = re.match(r"\s*(\d{2})", str(pos or ""))
    return m.group(1) if m else ""


def parse_gstr1_excel(path, client_gstin):
    sheets = _wb_rows(path)
    gstin, period = _gstin_and_period(sheets)
    period = period or period_from_text(Path(path).stem)
    state = (client_gstin or gstin or "")[:2]
    rows, hsn_rows = [], []
    nil = {"nil": 0.0, "exempt": 0.0, "non_gst": 0.0}

    def taxes(txv, rt, pos, inter=None):
        t = txv * rt / 100.0
        if inter is None:
            inter = bool(pos) and _pos_code(pos) != state
        return (round(t, 2), 0.0, 0.0) if inter else (0.0, round(t / 2, 2), round(t / 2, 2))

    for name, data in sheets.items():
        n = name.lower().replace(" ", "")
        if n.startswith("hsn"):
            hi = _find_header(data, ["hsn", "taxable value"])
            if hi is None:
                continue
            hdr = [_norm(x) for x in data[hi]]
            c = {k: _col(hdr, *v) for k, v in {"hsn": ("hsn",), "desc": ("description",), "uqc": ("uqc",),
                                                "qty": ("total quantity", "quantity"), "rate": ("rate",),
                                                "tx": ("taxable value",), "ig": ("integrated tax",),
                                                "cg": ("central tax",), "sg": ("state/ut tax", "state ut tax"),
                                                "cs": ("cess",)}.items()}
            for r in data[hi + 1:]:
                h = _cell(r[c["hsn"]]) if c["hsn"] is not None and c["hsn"] < len(r) else ""
                if not h or h.lower().startswith("total"):
                    continue
                gv = lambda k: num(r[c[k]]) if c[k] is not None and c[k] < len(r) else 0.0  # noqa: E731
                hsn_rows.append(dict(table_type="B2C" if "b2c" in n else "B2B" if "b2b" in n else "ALL",
                                     hsn=h.replace(".0", ""), description=_cell(r[c["desc"]]) if c["desc"] is not None else "",
                                     uqc=_cell(r[c["uqc"]]) if c["uqc"] is not None else "", qty=gv("qty"), rate=gv("rate"),
                                     txval=gv("tx"), igst=gv("ig"), cgst=gv("cg"), sgst=gv("sg"), cess=gv("cs")))
            continue
        if n.startswith("exemp"):
            hi = _find_header(data, ["description", "nil rated"])
            if hi is None:
                continue
            hdr = [_norm(x) for x in data[hi]]
            cn = _col(hdr, "nil rated", exclude=("exempted",))
            ce = _col(hdr, "exempted")
            cg = _col(hdr, "non gst", exclude=("exempted",))
            for r in data[hi + 1:]:
                nil["nil"] += num(r[cn]) if cn is not None and cn < len(r) else 0
                nil["exempt"] += num(r[ce]) if ce is not None and ce < len(r) else 0
                nil["non_gst"] += num(r[cg]) if cg is not None and cg < len(r) else 0
            continue
        sec = {"b2b": "B2B", "b2cl": "B2CL", "b2cs": "B2CS", "cdnr": "CDNR", "cdnur": "CDNUR", "exp": "EXP"}.get(
            n.split(",")[0].split("(")[0], None)
        if not sec:
            continue
        hi = _find_header(data, ["taxable value", "rate"])
        if hi is None:
            continue
        hdr = [_norm(x) for x in data[hi]]
        c = {"ctin": _col(hdr, "gstin/uin of recipient", "gstin"), "no": _col(hdr, "invoice number", "note number", "note/refund voucher number"),
             "date": _col(hdr, "invoice date", "note date", "note/refund voucher date"), "val": _col(hdr, "invoice value", "note value", "note/refund voucher value"),
             "pos": _col(hdr, "place of supply"), "rate": _col(hdr, "rate", exclude=("applicable",)), "tx": _col(hdr, "taxable value"),
             "cs": _col(hdr, "cess"), "ntype": _col(hdr, "note type", "document type"), "etype": _col(hdr, "export type", "type")}
        for r in data[hi + 1:]:
            gx = lambda k: r[c[k]] if c[k] is not None and c[k] < len(r) else None  # noqa: E731
            tx = num(gx("tx"))
            if not tx and not _cell(gx("no")):
                continue
            if str(_cell(gx("no"))).lower().startswith("total"):
                continue
            rt = num(gx("rate"))
            sign = -1.0 if sec.startswith("CDN") and _cell(gx("ntype")).upper().startswith("C") else 1.0
            if sec == "EXP":
                inter = True
            elif sec == "CDNUR":
                inter = True
            else:
                inter = None
            ig, cg, sg = taxes(tx, rt, gx("pos"), inter)
            if sec == "EXP" and "wop" in _cell(gx("etype")).lower():
                ig = 0.0
            no = _cell(gx("no"))
            if isinstance(gx("no"), float) and float(gx("no")).is_integer():
                no = str(int(gx("no")))
            rows.append(dict(section=sec, ctin=norm_gstin(gx("ctin")) if c["ctin"] is not None else "", inv_no=no,
                             inv_norm=norm_inv(no), inv_date=to_iso(gx("date")), inv_value=num(gx("val")) * sign,
                             pos=_pos_code(gx("pos")), rate=rt, txval=tx * sign, igst=ig * sign, cgst=cg * sign,
                             sgst=sg * sign, cess=num(gx("cs")) * sign))
    if not rows and not hsn_rows:
        raise ParseError("No data found in the GSTR-1 Excel workbook (expected sheets b2b, b2cs, cdnr, hsn ...).")
    return {"type": "GSTR1", "gstin": gstin, "period": period, "rows": rows, "hsn": hsn_rows, "nil": nil}


# ----------------------------------------------------------------- PDF
NUM = r"(-?\(?[\d,]+(?:\.\d{1,2})?\)?|-)"


def pdf_text(path):
    from pypdf import PdfReader
    r = PdfReader(str(path))
    return "\n".join((p.extract_text() or "") for p in r.pages)


def _nums_after(text, label_regex, count, window=400):
    m = re.search(label_regex, text, re.I | re.S)
    if not m:
        return None
    seg = text[m.end():m.end() + window]
    toks = re.findall(NUM, seg)
    vals = []
    for t in toks:
        if t == "-":
            vals.append(0.0)
        else:
            vals.append(num(t))
        if len(vals) == count:
            break
    return vals if len(vals) == count else None


def detect_pdf(text):
    t = re.sub(r"\s+", " ", text or "").upper()
    if "GSTR-3B" in t or "GSTR 3B" in t or "GSTR3B" in t:
        return "GSTR3B"
    if "GSTR-2B" in t or "GSTR 2B" in t or "GSTR2B" in t:
        return "GSTR2B"
    if "GSTR-1" in t or "GSTR 1" in t or "GSTR1" in t:
        return "GSTR1"
    return ""


def parse_gstr3b_pdf(text):
    t = re.sub(r"[ \t]+", " ", text)
    flat = re.sub(r"\s+", " ", t)
    g = re.search(r"\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b", flat)
    a = _nums_after(flat, r"\(a\)\s*Outward taxable supplies\s*\(other than zero rated[^)]*\)", 5)
    b = _nums_after(flat, r"\(b\)\s*Outward taxable supplies\s*\(zero rated\s*\)", 5)
    c = _nums_after(flat, r"\(c\)\s*Other outward supplies\s*\(Nil rated,?\s*exempted\s*\)", 5)
    d = _nums_after(flat, r"\(d\)\s*Inward supplies\s*\(liable to reverse charge\s*\)", 5)
    e = _nums_after(flat, r"\(e\)\s*Non-GST outward supplies", 5)
    s4 = re.search(r"Eligible ITC(.*?)(?:5\.?\s*Values of exempt|Values of exempt|$)", flat, re.I)
    seg4 = s4.group(1) if s4 else flat
    itc = [0.0, 0.0, 0.0, 0.0]
    found4 = False
    for lab in (r"\(1\)\s*Import of goods", r"\(2\)\s*Import of services",
                r"\(3\)\s*Inward supplies liable to reverse charge\s*\(other than 1\s*&\s*2 above\)",
                r"\(4\)\s*Inward supplies from ISD", r"\(5\)\s*All other ITC"):
        v = _nums_after(seg4, lab, 4)
        if v:
            found4 = True
            itc = [x + y for x, y in zip(itc, v)]
    rev1 = _nums_after(seg4, r"\(1\)\s*As per rules?\s*38,?\s*42\s*&\s*43 of CGST Rules and section 17\s*\(5\)", 4) or [0.0] * 4
    rev2 = _nums_after(seg4, r"B\.?\s*ITC Reversed.*?\(2\)\s*Others", 4) or [0.0] * 4
    if not a and not found4:
        raise ParseError("Could not read Table 3.1 / Table 4 from this GSTR-3B PDF. Enter the figures in the GSTR-3B form.")
    a = a or [0.0] * 5
    b = b or [0.0] * 5
    row = dict(osup_txval=a[0], osup_igst=a[1], osup_cgst=a[2], osup_sgst=a[3], osup_cess=a[4],
               zero_txval=b[0], zero_igst=b[1], nil_exempt=(c or [0])[0], non_gst=(e or [0])[0],
               rcm_txval=(d or [0])[0], itc_igst=itc[0], itc_cgst=itc[1], itc_sgst=itc[2], itc_cess=itc[3],
               itcrev_igst=rev1[0], itcrev_cgst=rev1[1], itcrev_sgst=rev1[2], itcrev_cess=rev1[3],
               itcrevoth_igst=rev2[0], itcrevoth_cgst=rev2[1], itcrevoth_sgst=rev2[2], itcrevoth_cess=rev2[3])
    return {"type": "GSTR3B", "gstin": g.group(0) if g else "", "period": period_from_text(flat), "row": row,
            "partial": not (a and found4)}


def parse_gstr1_pdf(text):
    flat = re.sub(r"\s+", " ", text)
    g = re.search(r"\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b", flat)
    tot = None
    for lab in (r"Total Liability\s*\(Outward supplies other than Reverse charge\)",
                r"Total\s+Liability", r"Grand\s+Total"):
        tot = _nums_after(flat, lab, 5)
        if tot:
            break
    return {"type": "GSTR1_PDF", "gstin": g.group(0) if g else "", "period": period_from_text(flat), "total": tot}


def parse_gstr2b_pdf(text):
    flat = re.sub(r"\s+", " ", text)
    g = re.search(r"\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b", flat)
    return {"type": "GSTR2B_PDF", "gstin": g.group(0) if g else "", "period": period_from_text(flat)}
