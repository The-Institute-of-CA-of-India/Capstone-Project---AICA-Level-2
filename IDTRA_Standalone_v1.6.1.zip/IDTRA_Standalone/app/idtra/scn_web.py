"""Routes for show cause notices / notices on refund claims (tab 'SCN / Notices')."""
import datetime as dt

from flask import abort, flash, g, jsonify, redirect, render_template, request, send_file, url_for

from . import db, parsers, scn, storage
from .web import _claim_ctx, _uname, login_required

SCN_FOLDER = "08_SCN_and_Replies"


def _notice(nid):
    n = db.q1("SELECT * FROM notices WHERE id=?", (nid,))
    if not n:
        abort(404, "Notice not found")
    claim, client = _claim_ctx(n["claim_id"])
    return n, claim, client


def _folder(claim, client, n=None):
    d = storage.claim_dir(claim, client) / SCN_FOLDER
    if n:
        d = d / storage.safe(f"Notice_{n['id']}" + (f"_{n['ref_no']}" if n.get('ref_no') else ""), 50)
    d.mkdir(parents=True, exist_ok=True)
    return d


def register(app):
    @app.route("/notices")
    @login_required
    def notices_all():
        rows = db.q("SELECT n.*, cl.legal_name, cl.gstin, c.period_from, c.period_to FROM notices n "
                    "JOIN claims c ON c.id=n.claim_id JOIN clients cl ON cl.id=c.client_id "
                    "ORDER BY CASE WHEN n.status IN ('Order received','Closed') THEN 1 ELSE 0 END, n.due_date")
        return render_template("notices.html", rows=rows, today=dt.date.today().isoformat())

    @app.route("/claims/<int:claim_id>/notices/new", methods=["POST"])
    @login_required
    def notice_new(claim_id):
        claim, client = _claim_ctx(claim_id)
        f = request.form
        fs = request.files.get("file")
        text = (f.get("notice_text") or "").strip()
        warn = ""
        nid = db.insert("notices", dict(claim_id=claim_id, notice_type=f.get("notice_type") or scn.NOTICE_TYPES[0],
                                        status="Received", created_by=_uname(), created_at=db.now(), updated_at=db.now()))
        n = db.q1("SELECT * FROM notices WHERE id=?", (nid,))
        folder = _folder(claim, client, n)
        rel_path = None
        if fs and fs.filename:
            p = storage.save_upload(fs, folder, prefix="SCN_")
            rel_path = storage.rel(p)
            db.insert("notice_files", dict(notice_id=nid, kind="Notice (as received)", file_path=rel_path,
                                           created_by=_uname(), created_at=db.now()))
            if not text:
                text, warn = scn.extract_text(p)
        facts = scn.parse_facts(text)
        received = f.get("received_date") or dt.date.today().isoformat()
        from . import calc
        res = calc.latest(claim_id, final_only=True) or calc.latest(claim_id)
        data = dict(file_path=rel_path, notice_text=text, received_date=received,
                    ref_no=f.get("ref_no") or facts.get("ref_no", ""),
                    notice_date=f.get("notice_date") or facts.get("notice_date", ""),
                    arn=f.get("arn") or facts.get("arn", ""),
                    amount_claimed=(res or {}).get("refund", {}).get("amount"),
                    amount_proposed=parsers.num(f.get("amount_proposed")) or None,
                    due_date=f.get("due_date") or scn.due_date(received))
        if not f.get("notice_type") and facts.get("notice_type"):
            data["notice_type"] = facts["notice_type"]
        db.update("notices", nid, data)
        n = db.q1("SELECT * FROM notices WHERE id=?", (nid,))
        found = scn.build_grounds(n, scn.context(claim, client)) if text else []
        if found:
            db.update("notices", nid, {"status": "Analysed"})
        db.audit(_uname(), "Notice received", claim_id, f"{n['notice_type']} {n['ref_no'] or ''}")
        if warn:
            flash(warn, "warning")
        flash(f"Notice saved. {len(found)} ground(s) identified - review them and the draft replies below. "
              f"Reply due by {n['due_date']}.", "success")
        if facts.get("amounts") and not data["amount_proposed"]:
            flash("Amounts found in the notice: " + ", ".join(f"Rs {a:,.2f}" for a in facts["amounts"][:6]) +
                  " - enter the amount proposed to be rejected.", "info")
        return redirect(url_for("notice_view", nid=nid))

    @app.route("/notices/<int:nid>")
    @login_required
    def notice_view(nid):
        n, claim, client = _notice(nid)
        grounds = db.q("SELECT * FROM notice_grounds WHERE notice_id=? ORDER BY sort, id", (nid,))
        files = db.q("SELECT * FROM notice_files WHERE notice_id=? ORDER BY id DESC", (nid,))
        used = {gr["code"] for gr in grounds}
        library = [(c, t) for c, t in scn.all_ground_titles() if c not in used]
        return render_template("notice.html", n=n, claim=claim, client=client, grounds=grounds, files=files,
                               library=library, types=scn.NOTICE_TYPES, statuses=scn.STATUSES,
                               appeal_due=scn.appeal_due(n.get("order_date")), today=dt.date.today().isoformat(),
                               sigs=db.q("SELECT * FROM client_signatories WHERE client_id=?", (client["id"],)))

    @app.route("/notices/<int:nid>/save", methods=["POST"])
    @login_required
    def notice_save(nid):
        n, claim, client = _notice(nid)
        f = request.form
        data = {k: (f.get(k) or "").strip() for k in ("notice_type", "ref_no", "notice_date", "received_date", "due_date",
                                                       "arn", "arn_date", "officer", "status", "hearing_date",
                                                       "hearing_notes", "reply_date", "reply_ack", "order_ref",
                                                       "order_date", "order_result", "notes")}
        for k in ("amount_claimed", "amount_proposed", "amount_sanctioned", "amount_rejected"):
            v = (f.get(k) or "").strip()
            data[k] = parsers.num(v) if v else None
        if not data["due_date"] and data["received_date"]:
            data["due_date"] = scn.due_date(data["received_date"])
        if data["status"] not in scn.STATUSES:
            data["status"] = n["status"]
        data["updated_at"] = db.now()
        db.update("notices", nid, data)
        db.audit(_uname(), "Notice updated", claim["id"], f"#{nid} {data['status']}")
        flash("Notice details saved", "success")
        return redirect(url_for("notice_view", nid=nid))

    @app.route("/notices/<int:nid>/text", methods=["POST"])
    @login_required
    def notice_text(nid):
        n, claim, client = _notice(nid)
        db.update("notices", nid, {"notice_text": request.form.get("notice_text", ""), "updated_at": db.now()})
        n = db.q1("SELECT * FROM notices WHERE id=?", (nid,))
        found = scn.build_grounds(n, scn.context(claim, client))
        if n["status"] == "Received" and found:
            db.update("notices", nid, {"status": "Analysed"})
        db.audit(_uname(), "Notice re-analysed", claim["id"], f"#{nid}: {len(found)} grounds")
        flash(f"Notice analysed again: {len(found)} ground(s) identified. Manually added grounds were kept.", "success")
        return redirect(url_for("notice_view", nid=nid))

    @app.route("/notices/<int:nid>/grounds", methods=["POST"])
    @login_required
    def notice_grounds(nid):
        n, claim, client = _notice(nid)
        f = request.form
        ctx = None
        for gr in db.q("SELECT * FROM notice_grounds WHERE notice_id=?", (nid,)):
            gid = gr["id"]
            if f.get(f"del_{gid}"):
                db.x("DELETE FROM notice_grounds WHERE id=?", (gid,))
                continue
            data = {"include": 1 if f.get(f"inc_{gid}") else 0,
                    "title": f.get(f"title_{gid}", gr["title"]),
                    "allegation": f.get(f"alleg_{gid}", gr["allegation"]),
                    "reply_text": f.get(f"reply_{gid}", gr["reply_text"]),
                    "sort": int(parsers.num(f.get(f"sort_{gid}", gr["sort"])))}
            if f.get(f"regen_{gid}"):
                ctx = ctx or scn.context(claim, client)
                fn = scn.ground_fn(gr["code"])
                if fn:
                    data["reply_text"] = fn(ctx)
            db.update("notice_grounds", gid, data)
        if f.get("add_code"):
            scn.add_from_library(nid, f["add_code"], ctx or scn.context(claim, client))
        if (f.get("new_title") or "").strip():
            mx = db.q1("SELECT COALESCE(MAX(sort),0)+1 s FROM notice_grounds WHERE notice_id=?", (nid,))["s"]
            db.insert("notice_grounds", dict(notice_id=nid, code="M", title=f["new_title"].strip(),
                                             allegation=f.get("new_allegation", ""), reply_text=f.get("new_reply", ""),
                                             include=1, auto=0, sort=mx))
        db.audit(_uname(), "Notice grounds edited", claim["id"], f"#{nid}")
        flash("Grounds and replies saved", "success")
        return redirect(url_for("notice_view", nid=nid) + "#grounds")

    @app.route("/notices/<int:nid>/reply", methods=["POST"])
    @login_required
    def notice_reply(nid):
        n, claim, client = _notice(nid)
        grounds = db.q("SELECT * FROM notice_grounds WHERE notice_id=? ORDER BY sort, id", (nid,))
        if not any(gr["include"] for gr in grounds):
            flash("Select at least one ground to include in the reply", "danger")
            return redirect(url_for("notice_view", nid=nid))
        sig = db.q1("SELECT * FROM client_signatories WHERE id=?", (request.form.get("signatory_id") or 0,)) or \
            db.q1("SELECT * FROM client_signatories WHERE client_id=? ORDER BY is_default DESC LIMIT 1", (client["id"],))
        docs = [d["doc_type"] for d in db.q("SELECT DISTINCT doc_type FROM documents WHERE claim_id=? AND "
                                            "(doc_type LIKE 'CA Certificate - FINAL%' OR doc_type LIKE 'Annexure-B Excel%' OR "
                                            "doc_type LIKE 'Computation workings (FINAL)%' OR doc_type LIKE 'Reconciliation%' "
                                            "OR doc_type LIKE 'Statement of outward%' OR doc_type LIKE 'Applicant declarations%')",
                                            (claim["id"],))]
        docs += [x.strip() for x in (request.form.get("extra_docs") or "").split("\n") if x.strip()]
        ctx = scn.context(claim, client)
        folder = _folder(claim, client, n)
        stamp = f"{dt.datetime.now():%Y%m%d_%H%M%S}"
        p = folder / f"Reply_RFD-09_{stamp}.docx"
        scn.reply_docx(p, n, grounds, ctx, sig, docs or ["Copies of documents as listed in the reply"])
        p2 = folder / f"SCN_Analysis_{stamp}.xlsx"
        scn.analysis_xlsx(p2, n, grounds, ctx)
        for kind, path in (("Draft reply (Word)", p), ("SCN analysis (Excel)", p2)):
            db.insert("notice_files", dict(notice_id=nid, kind=kind, file_path=storage.rel(path), created_by=_uname(),
                                           created_at=db.now()))
        if n["status"] in ("Received", "Analysed"):
            db.update("notices", nid, {"status": "Reply drafted", "updated_at": db.now()})
        db.audit(_uname(), "Draft reply generated", claim["id"], f"#{nid}")
        flash("Draft reply (Word, FORM GST RFD-09) and analysis (Excel) generated. Review, edit and file on the portal.",
              "success")
        return redirect(url_for("notice_view", nid=nid) + "#files")

    @app.route("/notices/<int:nid>/upload", methods=["POST"])
    @login_required
    def notice_upload(nid):
        n, claim, client = _notice(nid)
        fs = request.files.get("file")
        if not fs or not fs.filename:
            flash("Choose a file", "danger")
            return redirect(url_for("notice_view", nid=nid))
        kind = request.form.get("kind") or "Other"
        p = storage.save_upload(fs, _folder(claim, client, n), prefix=storage.safe(kind, 25).replace(" ", "_") + "_")
        db.insert("notice_files", dict(notice_id=nid, kind=kind, file_path=storage.rel(p), created_by=_uname(),
                                       created_at=db.now()))
        db.audit(_uname(), "Notice document uploaded", claim["id"], f"#{nid} {kind}")
        flash(f"{kind} uploaded", "success")
        return redirect(url_for("notice_view", nid=nid) + "#files")

    @app.route("/notices/<int:nid>/file/<int:fid>")
    @login_required
    def notice_file(nid, fid):
        f = db.q1("SELECT * FROM notice_files WHERE id=? AND notice_id=?", (fid, nid))
        if not f:
            abort(404)
        p = storage.absolute(f["file_path"])
        if not p.exists():
            abort(404, "File missing on server")
        return send_file(p, as_attachment=True, download_name=p.name)

    @app.route("/notices/<int:nid>/delete", methods=["POST"])
    @login_required
    def notice_delete(nid):
        if g.user["role"] != "admin":
            abort(403)
        n, claim, client = _notice(nid)
        db.x("DELETE FROM notices WHERE id=?", (nid,))
        db.audit(_uname(), "Notice deleted (files kept)", claim["id"], f"#{nid}")
        flash("Notice deleted from the database; files remain on the server.", "warning")
        return redirect(url_for("claim_view", claim_id=claim["id"], tab="scn"))
