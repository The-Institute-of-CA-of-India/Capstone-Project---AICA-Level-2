"""Backup of database + all client folders. Run daily by the scheduled task:
    python -m idtra.backup
"""
import datetime as dt
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path

KEEP = 30


def make_backup(cfg):
    data_root = Path(cfg["data_root"])
    bdir = data_root / "_Backups"
    bdir.mkdir(parents=True, exist_ok=True)
    name = bdir / f"IDTRA_Backup_{dt.datetime.now():%Y%m%d_%H%M%S}.zip"
    tmpdir = Path(tempfile.mkdtemp())
    tmpdb = tmpdir / "idtra.db"
    src = sqlite3.connect(cfg["db_path"])
    dst = sqlite3.connect(tmpdb)
    src.backup(dst)
    dst.close()
    src.close()
    with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmpdb, "_Database/idtra.db")
        key = Path(cfg["key_file"])
        if key.exists():
            z.write(key, "_Config/secret.key")   # needed to decrypt saved GST passwords after a restore
        for p in data_root.rglob("*"):
            if p.is_file() and not ({"_Backups", "_Database", "_Logs"} & set(p.relative_to(data_root).parts)):
                z.write(p, str(p.relative_to(data_root)))
    shutil.rmtree(tmpdir, ignore_errors=True)
    old = sorted(bdir.glob("IDTRA_Backup_*.zip"))
    for p in old[:-KEEP]:
        p.unlink(missing_ok=True)
    return name


if __name__ == "__main__":
    from . import config
    print(make_backup(config.load()))
