"""Reconciliation of portal data (GSTR-1, GSTR-2B, GSTR-3B) with books of account
and automatic generation of queries that must be resolved before computation."""
import json
from collections import defaultdict

from . import db, law

TOL_INVOICE = 1.0     # rupees, invoice level
TOL_SUMMARY = 10.0    # rupees, period level


def r2(v):
    return round(float(v or 0), 2)


def _tax(r):
    return (r.get("igst") or 0) + (r.get("cgst") or 0) + (r.get("sgst") or 0)


def match_purchases(cid):
    """Invoice level matching of purchase/expense register with GSTR-2B."""
    books = db.q("SELECT * FROM book_purchases WHERE claim_id=?", (cid,))
    b2 = db.q("SELECT * FROM gst_2b WHERE claim_id=?", (cid,))
    db.x("UPDATE book_purchases SET match_status=NULL, match_2b_id=NULL, match_note=NULL WHERE claim_id=?", (cid,))
    db.x("UPDATE gst_2b SET matched_book_id=NULL WHERE claim_id=?", (cid,))

    idx = defaultdict(list)
    for r in b2:
        key = ("BOE", r["inv_norm"]) if r["section"].startswith("IMPG") else (r["ctin"], r["inv_norm"])
        idx[key].append(r)
    groups = defaultdict(list)
    for b in books:
        if b["inward_type"] == "Import of Goods":
            groups[("BOE", b["inv_norm"])].append(b)
        else:
            groups[(b["supplier_gstin"], b["inv_norm"])].append(b)
    updates, used2b = [], set()
    for key, lines in groups.items():
        first = lines[0]
        btax = sum(_tax(l) for l in lines)
        if first["inward_type"] in ("RCM", "Import of Services"):
            for l in lines:
                updates.append(("Not required (" + first["inward_type"] + ")", None, "", l["id"]))
            continue
        cands = idx.get(key, [])
        if btax < 0 or first["doc_type"] == "Credit Note":
            # purchase return / supplier credit note: the supplier's credit note in GSTR-2B carries its own number
            if not cands:
                for r in b2:
                    if r["ctin"] == key[0] and r["id"] not in used2b and _tax(r) < 0 and abs(_tax(r) - btax) <= max(TOL_INVOICE, 1):
                        cands = [r]
                        break
            if not cands:
                for l in lines:
                    updates.append(("Credit note - reduces ITC", None, "Supplier credit note not found in GSTR-2B; "
                                    "ITC reduced as per books", l["id"]))
                continue
        if not cands and first["inward_type"] != "Import of Goods":
            # fallback: same supplier, same tax amount, same date
            for r in b2:
                if r["ctin"] == key[0] and r["id"] not in used2b and abs(_tax(r) - btax) <= TOL_INVOICE \
                        and r["inv_date"] == first["inv_date"]:
                    cands = [r]
                    break
        if not cands:
            for l in lines:
                updates.append(("Not in GSTR-2B", None, "", l["id"]))
            continue
        ptax = sum(_tax(c) for c in cands)
        for c in cands:
            used2b.add(c["id"])
        avl = all(str(c["itc_avl"]).upper().startswith("Y") for c in cands)
        if not avl:
            status, note = "In 2B - ITC not available", "GSTR-2B shows ITC availability 'N'"
        elif abs(ptax - btax) <= TOL_INVOICE:
            status, note = "Matched", ""
        else:
            status, note = "Value mismatch", f"Books tax {r2(btax)} vs 2B tax {r2(ptax)}"
        for l in lines:
            updates.append((status, cands[0]["id"], note, l["id"]))
        db.x("UPDATE gst_2b SET matched_book_id=? WHERE id IN (%s)" % ",".join(str(c["id"]) for c in cands),
             (lines[0]["id"],))
    db.xmany("UPDATE book_purchases SET match_status=?, match_2b_id=?, match_note=? WHERE id=?", updates)
    from . import importer
    importer.apply_line_settings(cid)          # HSN from matched GSTR-2B documents, user decisions


def run(claim, client, user):
    """Run all reconciliations, store a snapshot and refresh automatic queries."""
    cid = claim["id"]
    months = law.months_between(claim["period_from"], claim["period_to"])
    match_purchases(cid)
    issues = []   # (code, category, reference, description, amount)

    def issue(code, cat, ref, desc, amt=0.0):
        issues.append((code, cat, ref, desc, r2(amt)))

    # ---- 0. completeness
    pf = {(r["return_type"], r["tax_period"]) for r in db.q("SELECT return_type,tax_period FROM portal_files WHERE claim_id=?", (cid,))}
    have3b = {r["tax_period"] for r in db.q("SELECT tax_period FROM gst_3b WHERE claim_id=?", (cid,))}
    for p in months:
        for t in ("GSTR1", "GSTR2B"):
            if (t, p) not in pf:
                issue(f"R0-{t}-{p}", "Missing data", law.period_label(p),
                      f"{t} for {law.period_label(p)} has not been imported.")
        if p not in have3b:
            issue(f"R0-GSTR3B-{p}", "Missing data", law.period_label(p),
                  f"GSTR-3B figures for {law.period_label(p)} not imported / entered.")
    nsales = db.q1("SELECT COUNT(*) n FROM book_sales WHERE claim_id=?", (cid,))["n"]
    npur = db.q1("SELECT COUNT(*) n FROM book_purchases WHERE claim_id=? AND register='Purchase'", (cid,))["n"]
    if not nsales:
        issue("R0-BOOKS-SALES", "Missing data", "Books", "Sales register has not been uploaded.")
    if not npur:
        issue("R0-BOOKS-PURCHASE", "Missing data", "Books", "Purchase register has not been uploaded.")

    # ---- 1. outward summary per month: Books vs GSTR-1 vs GSTR-3B
    outward = []
    for p in months:
        bk = db.q1("SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) tax FROM book_sales "
                   "WHERE claim_id=? AND tax_period=? AND supply_type IN ('Taxable','Zero Rated')", (cid, p))
        g1 = db.q1("SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) tax, COUNT(*) n FROM gst_outward "
                   "WHERE claim_id=? AND tax_period=?", (cid, p))
        if not g1["n"]:
            g1 = db.q1("SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) tax, COUNT(*) n FROM gst_hsn "
                       "WHERE claim_id=? AND tax_period=? AND table_type IN ('ALL','B2B','B2C')", (cid, p))
        g3 = db.q1("SELECT osup_txval+zero_txval tx, osup_igst+osup_cgst+osup_sgst+zero_igst tax FROM gst_3b "
                   "WHERE claim_id=? AND tax_period=?", (cid, p)) or {"tx": None, "tax": None}
        row = {"period": p, "books_tx": r2(bk["tx"]), "books_tax": r2(bk["tax"]), "g1_tx": r2(g1["tx"]),
               "g1_tax": r2(g1["tax"]), "g3_tx": None if g3["tx"] is None else r2(g3["tx"]),
               "g3_tax": None if g3["tax"] is None else r2(g3["tax"])}
        bn = db.q1("SELECT COALESCE(SUM(CASE WHEN doc_type='Credit Note' THEN txval END),0) cn, "
                   "COALESCE(SUM(CASE WHEN doc_type='Debit Note' THEN txval END),0) dn FROM book_sales "
                   "WHERE claim_id=? AND tax_period=? AND supply_type IN ('Taxable','Zero Rated')", (cid, p))
        gn = db.q1("SELECT COALESCE(SUM(CASE WHEN REPLACE(section,'1A:','') IN ('CDNR','CDNUR') THEN txval END),0) cdn, "
                   "COALESCE(SUM(CASE WHEN REPLACE(REPLACE(section,'1A:',''),'-REV','') IN ('B2BA','B2CLA','CDNRA','CDNURA','B2CSA') "
                   "OR section LIKE '%EXPA%' THEN txval END),0) amd, "
                   "COALESCE(SUM(CASE WHEN section LIKE '1A:%' THEN txval END),0) g1a FROM gst_outward "
                   "WHERE claim_id=? AND tax_period=?", (cid, p))
        row.update(books_cn=r2(bn["cn"]), books_dn=r2(bn["dn"]), g1_cdn=r2(gn["cdn"]), g1_amend=r2(gn["amd"]),
                   g1_1a=r2(gn["g1a"]))
        row["diff_g1"] = r2(row["books_tx"] - row["g1_tx"])
        row["diff_g1_tax"] = r2(row["books_tax"] - row["g1_tax"])
        row["diff_g3"] = None if row["g3_tx"] is None else r2(row["books_tx"] - row["g3_tx"])
        outward.append(row)
        if ("GSTR1", p) in pf and (abs(row["diff_g1"]) > TOL_SUMMARY or abs(row["diff_g1_tax"]) > TOL_SUMMARY):
            issue(f"R1-G1-{p}", "Outward: Books vs GSTR-1", law.period_label(p),
                  f"Taxable value differs by {row['diff_g1']:,.2f} and tax by {row['diff_g1_tax']:,.2f} "
                  f"(Books {row['books_tx']:,.2f} / GSTR-1 {row['g1_tx']:,.2f}).", row["diff_g1"])
        if row["diff_g3"] is not None and abs(row["diff_g3"]) > TOL_SUMMARY:
            issue(f"R1-3B-{p}", "Outward: Books vs GSTR-3B", law.period_label(p),
                  f"Taxable value differs by {row['diff_g3']:,.2f} (Books {row['books_tx']:,.2f} / "
                  f"GSTR-3B 3.1(a)+(b) {row['g3_tx']:,.2f}).", row["diff_g3"])

        if row["g1_cdn"] and not (row["books_cn"] or row["books_dn"]) and abs(row["diff_g1"]) > TOL_SUMMARY:
            issue(f"R1-CN-{p}", "Outward: credit / debit notes", law.period_label(p),
                  f"GSTR-1 has credit / debit notes of {row['g1_cdn']:,.2f} for this month but the books have none - "
                  f"import the Credit Note / Debit Note register (Books tab).", row["g1_cdn"])
    for a in db.q("SELECT tax_period, section, inv_no, orig_inv, amend_note, SUM(txval) tx FROM gst_outward WHERE claim_id=? "
                  "AND COALESCE(amend_note,'')<>'' AND section NOT LIKE '%-REV' GROUP BY tax_period, section, inv_no, orig_inv",
                  (cid,)):
        issue(f"R9-AMD-{a['tax_period']}-{a['section']}-{a['inv_no']}", "Outward: amendments", law.period_label(a["tax_period"]),
              f"{a['section'].replace('1A:', 'GSTR-1A ')} amends {a['orig_inv'] or 'an earlier document'} "
              f"({a['amend_note']}): the amended value {a['tx']:,.2f} is counted in full in this month; GSTR-3B counts only "
              f"the difference from the original. Check the original value.", a["tx"])

    # ---- 2. rate-wise outward Books vs GSTR-1 (only months with invoice-level GSTR-1, not PDF totals)
    detail = [r["tax_period"] for r in db.q("SELECT DISTINCT tax_period FROM gst_outward WHERE claim_id=? AND "
                                            "section<>'PDF-SUMMARY'", (cid,))]
    dph = ",".join("?" for _ in detail) or "''"
    ratewise = []
    bkr = {r["rate"]: r for r in db.q(f"SELECT rate, SUM(txval) tx FROM book_sales WHERE claim_id=? AND "
                                      f"supply_type IN ('Taxable','Zero Rated') AND tax_period IN ({dph}) GROUP BY rate",
                                      (cid, *detail))}
    g1r = {r["rate"]: r for r in db.q("SELECT rate, SUM(txval) tx FROM gst_outward WHERE claim_id=? AND "
                                      "section<>'PDF-SUMMARY' GROUP BY rate", (cid,))}
    for rt in sorted(set(bkr) | set(g1r)):
        b, g = r2((bkr.get(rt) or {}).get("tx")), r2((g1r.get(rt) or {}).get("tx"))
        ratewise.append({"rate": rt, "books": b, "gstr1": g, "diff": r2(b - g)})
        if g1r and abs(b - g) > TOL_SUMMARY:
            issue(f"R2-RATE-{rt}", "Outward: rate-wise", f"{rt}%",
                  f"Turnover at {rt}% differs between books ({b:,.2f}) and GSTR-1 ({g:,.2f}).", b - g)

    # ---- 3. B2B outward invoice-level
    # books exported without voucher numbers (Tally columnar register -> AUTO/...) are compared party-wise
    party_only = bool(db.q1("SELECT 1 FROM book_sales WHERE claim_id=? AND inv_no LIKE 'AUTO/%' LIMIT 1", (cid,)))
    bs = defaultdict(float)
    for r in db.q(f"SELECT party_gstin, inv_norm, SUM(txval) tx FROM book_sales WHERE claim_id=? AND party_gstin<>'' "
                  f"AND tax_period IN ({dph}) GROUP BY party_gstin, inv_norm", (cid, *detail)):
        bs[(r["party_gstin"], "ALL" if party_only else r["inv_norm"])] += r["tx"]
    gs = defaultdict(float)
    for r in db.q("SELECT ctin, inv_norm, SUM(txval) tx FROM gst_outward WHERE claim_id=? AND ctin<>'' "
                  "GROUP BY ctin, inv_norm", (cid,)):
        gs[(r["ctin"], "ALL" if party_only else r["inv_norm"])] += r["tx"]
    b2b_diff = []
    if gs:
        for k in set(bs) | set(gs):
            d = bs.get(k, 0) - gs.get(k, 0)
            if abs(d) > TOL_INVOICE:
                b2b_diff.append({"gstin": k[0], "inv": k[1], "books": r2(bs.get(k)), "gstr1": r2(gs.get(k)), "diff": r2(d)})
        per_party = defaultdict(list)
        for d in b2b_diff:
            per_party[d["gstin"]].append(d)
        for g, lst in per_party.items():
            if party_only:
                msg = (f"Total sales to this party differ between books ({lst[0]['books']:,.2f}) and GSTR-1 "
                       f"({lst[0]['gstr1']:,.2f}). Books have no invoice numbers, so they are compared party-wise.")
            else:
                msg = (f"{len(lst)} invoice(s) differ between books and GSTR-1: " +
                       ", ".join(x["inv"] for x in lst[:8]) + (" ..." if len(lst) > 8 else ""))
            issue(f"R3-B2B-{g}", "Outward: B2B invoices", g, msg, sum(x["diff"] for x in lst))

    # ---- 4. Purchases vs GSTR-2B (grouped per supplier)
    bp = db.q("SELECT * FROM book_purchases WHERE claim_id=?", (cid,))
    agg = defaultdict(lambda: {"n": 0, "tax": 0.0, "invs": []})
    for b in bp:
        if b["match_status"] in ("Not in GSTR-2B", "Value mismatch", "In 2B - ITC not available") \
                and not b["blocked_17_5"]:
            k = (b["match_status"], b["supplier_gstin"] or "NO-GSTIN")
            agg[k]["n"] += 1
            agg[k]["tax"] += _tax(b)
            if b["inv_no"] not in agg[k]["invs"]:
                agg[k]["invs"].append(b["inv_no"])
    for (st, g), v in agg.items():
        code = {"Not in GSTR-2B": "R4-NOT2B", "Value mismatch": "R4-MISM", "In 2B - ITC not available": "R4-ITCN"}[st]
        issue(f"{code}-{g}", "Inward: Books vs GSTR-2B", g,
              f"{st}: {len(v['invs'])} invoice(s) [{', '.join(v['invs'][:8])}{' ...' if len(v['invs']) > 8 else ''}]. "
              f"ITC on these is excluded / restricted in Net ITC unless corrected.", v["tax"])
    not_in_books = db.q("SELECT ctin, trade_name, COUNT(*) n, SUM(igst+cgst+sgst) tax FROM gst_2b WHERE claim_id=? "
                        "AND matched_book_id IS NULL GROUP BY ctin", (cid,))
    for r in not_in_books:
        issue(f"R4-NOTBK-{r['ctin'] or 'BOE'}", "Inward: GSTR-2B not in books", r["ctin"] or "Imports",
              f"{r['n']} document(s) of {r['trade_name'] or r['ctin']} appear in GSTR-2B but not in books "
              f"(ITC {r2(r['tax']):,.2f}). Confirm whether ITC was availed.", r["tax"])
    bad_gstin = [b for b in bp if b["inward_type"] == "Regular" and b["supplier_gstin"] and len(b["supplier_gstin"]) != 15]
    if bad_gstin:
        issue("R4-GSTIN", "Inward: data quality", "GSTIN",
              f"{len(bad_gstin)} purchase line(s) have an invalid supplier GSTIN.")

    # ---- 5. ITC books vs GSTR-3B vs GSTR-2B per month
    itc_rows = []
    for p in months:
        bk = db.q1("SELECT COALESCE(SUM(igst+cgst+sgst),0) t FROM book_purchases WHERE claim_id=? AND tax_period=? "
                   "AND blocked_17_5=0", (cid, p))["t"]
        g3 = db.q1("SELECT itc_igst+itc_cgst+itc_sgst t FROM gst_3b WHERE claim_id=? AND tax_period=?", (cid, p))
        g2 = db.q1("SELECT COALESCE(SUM(igst+cgst+sgst),0) t FROM gst_2b WHERE claim_id=? AND tax_period=? "
                   "AND itc_avl LIKE 'Y%'", (cid, p))["t"]
        row = {"period": p, "books": r2(bk), "g3b": None if not g3 else r2(g3["t"]), "g2b": r2(g2)}
        row["diff_3b"] = None if row["g3b"] is None else r2(row["books"] - row["g3b"])
        itc_rows.append(row)
        if row["diff_3b"] is not None and abs(row["diff_3b"]) > TOL_SUMMARY:
            issue(f"R5-ITC-{p}", "ITC: Books vs GSTR-3B", law.period_label(p),
                  f"Eligible ITC in books {row['books']:,.2f} vs ITC availed in GSTR-3B Table 4(A) {row['g3b']:,.2f}.",
                  row["diff_3b"])

    # ---- 6. Law checks on outward HSN
    sales_hsn = db.q("SELECT hsn, rate, SUM(txval) tx FROM book_sales WHERE claim_id=? AND supply_type='Taxable' "
                     "GROUP BY hsn, rate", (cid,))
    for s in sales_hsn:
        rg = law.restricted_for(s["hsn"], claim["period_from"], claim["period_to"])
        if rg:
            issue(f"R6-RESTR-{s['hsn']}", "Law: restricted goods", s["hsn"],
                  f"HSN {s['hsn']} is covered by {rg['notification']} ({rg['description']}). "
                  f"{'Turnover is excluded from inverted rated supply.' if rg['applies_to'] == 'Exclude' else 'Verify eligibility.'}",
                  s["tx"])
        if s["hsn"] in ("NA", ""):
            issue("R6-NOHSN", "Data quality", "HSN", "Some sales lines have no HSN. Inverted supply cannot be "
                  "identified for these lines.", s["tx"])
    in_hsn = {r["hsn"] for r in db.q("SELECT DISTINCT hsn FROM book_purchases WHERE claim_id=? AND category='Inputs' "
                                     "AND is_trading=0 AND hsn<>'NA'", (cid,))}
    for s in sales_hsn:
        if s["hsn"] in in_hsn:
            issue(f"R7-SAME-{s['hsn']}", "Law: Circular 135/05/2020", s["hsn"],
                  f"HSN {s['hsn']} appears in both inputs and outward supplies. If the same goods are bought and "
                  f"sold (trading), refund is not available - mark the HSN as trading in the Books tab, or record "
                  f"why the goods differ.", s["tx"])

    # ---- 7. time limit
    if claim.get("filing_date"):
        tl = law.time_limit(claim["period_from"], claim["period_to"], client.get("filing_freq") or "Monthly")
        late = [t for t in tl if claim["filing_date"] > t["last_date"]]
        if late:
            issue("R8-TIME", "Law: time limit u/s 54(1)", "Filing date",
                  f"Filing date {claim['filing_date']} is beyond the two-year limit for " +
                  ", ".join(law.period_label(t["period"]) for t in late) + ".")

    _refresh_queries(cid, issues, user)
    snap = {"outward": outward, "ratewise": ratewise, "b2b_diff": b2b_diff[:500], "itc": itc_rows,
            "purchase_status": db.q("SELECT match_status, COUNT(*) n, ROUND(SUM(igst+cgst+sgst),2) tax FROM "
                                    "book_purchases WHERE claim_id=? GROUP BY match_status", (cid,)),
            "issues": len(issues), "run_at": db.now(), "run_by": user}
    db.set_setting(f"recon_{cid}", json.dumps(snap))
    if claim["status"] in ("Draft", "Data Imported"):
        db.update("claims", cid, {"status": "Reconciled", "updated_at": db.now()})
    db.audit(user, "Reconciliation run", cid, f"{len(issues)} issue(s)")
    return snap


def snapshot(cid):
    s = db.get_setting(f"recon_{cid}")
    return json.loads(s) if s else None


def _refresh_queries(cid, issues, user):
    existing = {q["code"]: q for q in db.q("SELECT * FROM queries WHERE claim_id=? AND code LIKE 'R%'", (cid,))}
    merged = {}
    for code, cat, ref, desc, amt in issues:
        if code in merged:
            m = merged[code]
            merged[code] = (code, cat, ref, desc, r2(m[4] + amt))
        else:
            merged[code] = (code, cat, ref, desc, amt)
    seen = set()
    for code, cat, ref, desc, amt in merged.values():
        seen.add(code)
        q = existing.get(code)
        if q is None:
            db.insert("queries", dict(claim_id=cid, code=code, category=cat, reference=ref, description=desc,
                                      amount=amt, status="Open", raised_by="System", raised_at=db.now()))
        elif q["status"] in ("Open", "Auto-closed"):
            db.update("queries", q["id"], {"description": desc, "amount": amt, "status": "Open", "category": cat})
        elif q["status"] in ("Resolved", "Accepted") and abs((q["amount"] or 0) - amt) > TOL_SUMMARY:
            # the difference changed after it was resolved -> reopen
            db.update("queries", q["id"], {"description": desc, "amount": amt, "status": "Open",
                                           "response": (q["response"] or "") + f"\n[Re-opened {db.now()}: amount changed]"})
    for code, q in existing.items():
        if code not in seen and q["status"] == "Open":
            db.update("queries", q["id"], {"status": "Auto-closed", "resolved_by": "System",
                                           "resolved_at": db.now(),
                                           "response": "Difference no longer exists after re-reconciliation."})


def open_queries(cid):
    return db.q1("SELECT COUNT(*) n FROM queries WHERE claim_id=? AND status='Open'", (cid,))["n"]
