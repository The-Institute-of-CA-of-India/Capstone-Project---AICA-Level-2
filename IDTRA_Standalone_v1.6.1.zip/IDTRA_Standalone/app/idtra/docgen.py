"""Word documents: applicant declarations / undertakings and CA certificate."""
import datetime as dt

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Cm

from . import law


def inr(v, dec=0):
    v = float(v or 0)
    neg = v < 0
    v = abs(v)
    s = f"{v:.{dec}f}"
    whole, _, frac = s.partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        whole = ",".join(parts) + "," + tail
    out = whole + ("." + frac if frac else "")
    return ("-" if neg else "") + out


def _dmy(iso):
    if not iso:
        return "____________"
    try:
        return dt.date.fromisoformat(iso[:10]).strftime("%d.%m.%Y")
    except ValueError:
        return iso


def _base_doc():
    d = Document()
    for s in d.sections:
        s.top_margin = s.bottom_margin = Cm(2)
        s.left_margin = s.right_margin = Cm(2.2)
    st = d.styles["Normal"]
    st.font.name = "Cambria"
    st.font.size = Pt(11)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Cambria")
    st.paragraph_format.space_after = Pt(6)
    return d


def _shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def _heading(d, text, size=13, color="1F3864", center=True, space_before=6):
    p = d.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    r.bold = True
    r.font.size = Pt(size)
    r.font.color.rgb = RGBColor.from_string(color)
    return p


def _para(d, text, bold=False, justify=True, italic=False, size=None):
    p = d.add_paragraph()
    if justify:
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    r = p.add_run(text)
    r.bold = bold
    r.italic = italic
    if size:
        r.font.size = Pt(size)
    return p


def _table(d, header, rows, widths=None, num_cols=()):
    t = d.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(str(h))
        r.bold = True
        r.font.size = Pt(9.5)
        _shade(c, "DCE6F1")
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(v))
            r.font.size = Pt(9.5)
            if i in num_cols:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if widths:
        t.autofit = False
        for i, w in enumerate(widths):
            t.columns[i].width = Cm(w)
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    return t


def _period_text(claim):
    return f"{law.period_label(claim['period_from'])} to {law.period_label(claim['period_to'])}" \
        if claim["period_from"] != claim["period_to"] else law.period_label(claim["period_from"])


def statement1_rows(claim, res):
    t = res["turnover"]
    sel = res["selected"]
    return [["1", _period_text(claim), inr(t["inverted"], 2), inr(t["tax_inverted"], 2), inr(t["att"], 2),
             inr(sel["net_itc"], 2), inr(sel["max_refund"], 2)]]


STMT1_HDR = ["Sr.", "Tax period", "Turnover of inverted rated supply of goods and services",
             "Tax payable on such inverted rated supply", "Adjusted total turnover", "Net input tax credit",
             "Maximum refund amount to be claimed"]


def applicant_declarations(path, claim, client, signatory, res, firm_place=""):
    d = _base_doc()
    sig_name = signatory["name"] if signatory else "____________________"
    sig_desg = signatory["designation"] if signatory else "Authorised Signatory"
    per = _period_text(claim)
    fdate = _dmy(claim.get("filing_date"))
    ref = res["refund"]

    # ---- letterhead
    _heading(d, client["legal_name"].upper(), 15, "C00000")
    p = d.add_paragraph(client.get("address") or "")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = d.add_paragraph(f"GSTIN: {client['gstin']}" + (f"   |   PAN: {client['pan']}" if client.get("pan") else ""))
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # ---- covering letter
    _para(d, f"Date: {fdate}", justify=False)
    _para(d, "To,\nThe Proper Officer,\nGoods and Services Tax Department,\n" + (client.get("state") or ""), justify=False)
    _para(d, f"Subject: Application for refund of unutilised input tax credit on account of inverted duty structure "
             f"under clause (ii) of the first proviso to section 54(3) of the CGST Act, 2017 for the period {per} "
             f"- GSTIN {client['gstin']}", bold=True)
    _para(d, "Respected Sir/Madam,")
    _para(d, f"We, {client['legal_name']}, are filing an application in FORM GST RFD-01 for refund of unutilised input "
             f"tax credit accumulated on account of the rate of tax on inputs being higher than the rate of tax on "
             f"output supplies for the period {per}. The refund amount of Rs. {inr(ref['amount'])}/- "
             f"(IGST Rs. {inr(ref['heads']['igst'])}, CGST Rs. {inr(ref['heads']['cgst'])}, "
             f"SGST/UTGST Rs. {inr(ref['heads']['sgst'])}) has been computed in accordance with "
             f"{res['formula_label']}. The computation (Statement 1), the statement of inward invoices ("
             f"Annexure-B), the statement of outward invoices, the following declarations and undertakings and the certificate of the Chartered "
             f"Accountant are enclosed.")
    _para(d, "We request you to kindly sanction the refund at the earliest.")
    _para(d, f"Thanking you,\nFor {client['legal_name']}\n\n\n\n{sig_name}\n{sig_desg}", justify=False)

    # ---- Statement 1
    d.add_page_break()
    _heading(d, "STATEMENT 1  [Rule 89(2)(h) and 89(5)]", 12)
    _para(d, "Refund Type: ITC accumulated due to inverted tax structure [clause (ii) of first proviso to section 54(3)]",
          italic=True, justify=False)
    _table(d, STMT1_HDR, statement1_rows(claim, res), num_cols=(2, 3, 4, 5, 6))
    _para(d, f"Formula applied: {res['formula_text']}", italic=True, size=9)

    # ---- Declarations
    def decl(title, body, basis=None):
        _heading(d, title, 12, "1F3864", space_before=14)
        if basis:
            _para(d, basis, italic=True, size=9, justify=False)
        _para(d, body)
        _para(d, f"Place: {firm_place or '____________'}\nDate: {fdate}\n\n\n"
                 f"Signature of Authorised Signatory: ____________________\nName: {sig_name}\n"
                 f"Designation: {sig_desg}\nFor {client['legal_name']} (GSTIN {client['gstin']})", justify=False)

    d.add_page_break()
    decl("DECLARATION UNDER SECTION 54(3)(ii)",
         "I hereby declare that the refund of ITC claimed in the application does not include ITC availed on goods "
         "or services used for making nil rated or fully exempt supplies.",
         "[Declaration in FORM GST RFD-01 for refund on account of inverted duty structure]")
    decl("UNDERTAKING IN RELATION TO SECTIONS 16(2)(c) AND 42(2)",
         "I hereby undertake to pay back to the Government the amount of refund sanctioned along with interest in "
         "case it is found subsequently that the requirements of clause (c) of sub-section (2) of section 16 read "
         "with sub-section (2) of section 42 of the CGST/SGST Act have not been complied with in respect of the "
         "amount refunded.")
    tp = res["trading_purchases"]
    decl("DECLARATION REGARDING NOTIFIED GOODS, TRADING AND GSTR-2B",
         f"I hereby declare that (a) no refund has been claimed in respect of outward supplies of goods notified "
         f"under Notification No. 5/2017-Central Tax (Rate) dated 28.06.2017, as amended; (b) no refund has been "
         f"claimed where the input and the output supplies are the same (Circular No. 135/05/2020-GST): the input "
         f"tax credit of Rs. {inr(tp['itc'], 2)} on trading purchases has been excluded from Net ITC and the turnover "
         f"corresponding to such purchases has been excluded from the turnover of inverted rated supply; (c) the Net ITC "
         f"considered for refund pertains only to invoices / documents reflected in FORM GSTR-2B (other than "
         f"imports, reverse charge and ISD credit as applicable) and excludes credit blocked under section 17(5); "
         f"and (d) the electronic credit ledger shall be debited for the amount claimed in accordance with rule 89(3).")
    if (claim.get("filing_date") or "") >= law.PROSECUTION_DECL_FROM:
        decl("DECLARATION UNDER RULE 89(2)(o)",
             "I hereby declare that the applicant has not been prosecuted for any offence under the Act or under an "
             "existing law, where the amount of tax evaded exceeds two hundred and fifty lakh rupees, during the "
             "period of five years immediately preceding the tax period to which this claim for refund relates.",
             "[Inserted by Notification No. 05/2026-Central Tax w.e.f. 01.12.2026 - verify the wording against the "
             "revised FORM GST RFD-01 on the portal before signing]")
    if res["selected"].get("cg_attributable"):
        decl("DECLARATION UNDER RULE 89(2)(p)",
             "I hereby declare that the capital goods, the input tax credit on which has been included in the Net ITC "
             "for this claim, have not been sold, disposed of or permanently removed from the business.",
             "[Inserted by Notification No. 05/2026-Central Tax w.e.f. 01.04.2027]")
    decl("SELF-DECLARATION AND VERIFICATION",
         f"I hereby solemnly affirm and declare that the information given in the application, statements and "
         f"annexures for the period {per} is true and correct to the best of my knowledge and belief and nothing "
         f"has been concealed therefrom; that no other application for refund of the same input tax credit for this "
         f"period has been filed; and that I am authorised to sign this declaration on behalf of the applicant.")
    d.save(path)
    return path


def _trading_text(res):
    ta = res.get("trading_adjustment") or {}
    if ta.get("method") == "gross_up" and ta.get("purchases"):
        return (f"The turnover corresponding to trading purchases of Rs. {inr(ta['purchases'], 2)} (cost of traded goods "
                f"sold Rs. {inr(ta['cost_sold'], 2)} after stock adjustment, grossed up for gross profit of "
                f"{ta['gp_percent']:.2f}% {'of sales' if ta['gp_basis'] == 'sales' else 'on cost'}, being the higher of the "
                f"minimum of {ta.get('gp_minimum', 10):g}% and the gross profit declared), i.e. Rs. "
                f"{inr(ta['deemed_turnover'], 2)}, has been excluded from the turnover of inverted rated supply "
                f"(Rs. {inr(ta['deduct_inverted'], 2)}) with the corresponding tax of Rs. {inr(ta['deduct_tax'], 2)}"
                + (f" and from the adjusted total turnover (Rs. {inr(ta['deduct_att'], 2)})" if ta.get("reduce_att") else "")
                + ", the input tax credit on such purchases having been excluded from Net ITC.")
    t = res["turnover"]
    return (f"Outward supplies of traded goods amounting to Rs. {inr(t['trading_outward'], 2)} have not been treated "
            f"as inverted rated supply.")


def ca_certificate(path, claim, client, ca, res, recon_snap, udin=None, place=""):
    d = _base_doc()
    per = _period_text(claim)
    t = res["turnover"]
    sel = res["selected"]
    ref = res["refund"]
    cert_date = _dmy(claim.get("udin_date") or claim.get("filing_date") or dt.date.today().isoformat())

    _heading(d, (ca.get("firm_name") or "").upper(), 15, "7030A0")
    p = d.add_paragraph("Chartered Accountants" + (f"  |  FRN: {ca['frn']}" if ca.get("frn") else ""))
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if ca.get("address"):
        p = d.add_paragraph(ca["address"])
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _heading(d, "CERTIFICATE", 14, "C00000", space_before=12)
    _heading(d, "Refund of unutilised input tax credit on account of inverted duty structure "
                "[Section 54(3)(ii) of the CGST Act, 2017 read with Rule 89(5) of the CGST Rules, 2017]", 11)
    _para(d, "To,\nThe Proper Officer,\nGoods and Services Tax Department", justify=False)
    _para(d, f"1. At the request of M/s {client['legal_name']} (GSTIN {client['gstin']}) (\"the Applicant\"), we have "
             f"examined the books of account, sales and purchase registers, FORM GSTR-1, FORM GSTR-3B, FORM GSTR-2B "
             f"and the electronic credit ledger of the Applicant for the period {per}, for the purpose of certifying "
             f"the computation of refund of unutilised input tax credit on account of inverted duty structure.")
    _para(d, "2. Management's responsibility: The preparation of the refund application and the maintenance of books "
             "and records is the responsibility of the management of the Applicant, including the design and "
             "maintenance of internal controls relevant to the preparation of the claim.")
    _para(d, "3. Our responsibility: Our responsibility is to provide reasonable assurance on the computation stated "
             "below on the basis of our examination of the records referred to above. We conducted our examination "
             "in accordance with the Guidance Note on Reports or Certificates for Special Purposes issued by the "
             "Institute of Chartered Accountants of India.")
    _para(d, "4. Based on our examination and according to the information and explanations given to us, we certify "
             "that:")
    items = [
        f"(a) The turnover of inverted rated supply of goods and services for the period is Rs. {inr(t['inverted'], 2)} "
        f"and the tax payable on such inverted rated supply is Rs. {inr(t['tax_inverted'], 2)}.",
        f"(b) The Adjusted Total Turnover as defined in rule 89(4)(E) is Rs. {inr(t['att'], 2)} (total turnover "
        f"Rs. {inr(t['total'], 2)} less exempt / nil rated / non-GST supplies Rs. {inr(t['exempt_total'], 2)}"
        + (f" and turnover under rule 89(4A)/(4B) Rs. {inr(t['less_4a4b'], 2)}" if t["less_4a4b"] else "") + ").",
        f"(c) The Net ITC for the purpose of rule 89(5) is Rs. {inr(sel['net_itc'], 2)}. It excludes input tax credit "
        f"on trading purchases (Rs. {inr(res['trading_purchases']['itc'], 2)}), credit blocked under section 17(5), "
        f"credit on invoices not reflected in FORM GSTR-2B, reversals of Rs. {inr(sel.get('reversal_net_itc', 0), 2)} "
        f"attributable to such credit" +
        (", input services and capital goods" if res["version"] != "V2026" else
         ", input services availed before 01.11.2026 and capital goods other than those attributable under rule 89(4)(G)") + ".",
        f"(d) Outward supplies of goods notified under Notification No. 5/2017-Central Tax (Rate), as amended, "
        f"amounting to Rs. {inr(t['restricted_outward'], 2)} have not been treated as inverted rated supply. "
        + _trading_text(res) + "",
        f"(e) The maximum refund amount computed as per {res['formula_label']} is Rs. {inr(sel['max_refund'], 2)}.",
        f"(f) The balance in the electronic credit ledger was Rs. {inr(res['ecl']['end_total'], 2)} at the end of the "
        f"tax period and Rs. {inr(res['ecl']['filing_total'], 2)} at the time of filing. The refund admissible, being "
        f"the least of the above, is Rs. {inr(ref['amount'])} (IGST Rs. {inr(ref['heads']['igst'])}, CGST "
        f"Rs. {inr(ref['heads']['cgst'])}, SGST/UTGST Rs. {inr(ref['heads']['sgst'])}), the ledger being debited in "
        f"the manner provided in rule 89(3).",
        "(g) The refund claimed does not include input tax credit availed on goods or services used for making "
        "nil rated or fully exempt supplies.",
    ]
    for it in items:
        p = _para(d, it)
        p.paragraph_format.left_indent = Cm(0.8)
    _para(d, "5. The computation is enclosed as Annexure I and the reconciliation summary as Annexure II.")
    _para(d, "6. Restriction on use: This certificate is issued at the request of the Applicant solely for submission "
             "to the GST authorities along with the refund application and should not be used for any other purpose.")
    _para(d, f"For {ca.get('firm_name')}\nChartered Accountants\nFRN: {ca.get('frn') or '________'}\n\n\n\n"
             f"({ca['ca_name']})\n{ca.get('designation') or 'Partner'}\nMembership No.: {ca['membership_no']}\n"
             f"UDIN: {udin or '______________________ (to be generated)'}\n"
             f"Place: {place or ca.get('city') or '____________'}\nDate: {cert_date}", justify=False)

    # Annexure I
    d.add_page_break()
    _heading(d, "ANNEXURE I - COMPUTATION OF REFUND", 12)
    _table(d, STMT1_HDR, statement1_rows(claim, res), num_cols=(2, 3, 4, 5, 6))
    d.add_paragraph()
    rows = [
        ["", "Turnover of inverted rated supply before trading adjustment", inr(t.get("inverted_before_trading", t["inverted"]), 2)],
        ["", "Less: turnover corresponding to trading purchases (grossed up for GP)",
         inr((res.get("trading_adjustment") or {}).get("deduct_inverted", 0), 2)],
        ["A", "Turnover of inverted rated supply", inr(t["inverted"], 2)],
        ["B", "Tax payable on inverted rated supply", inr(t["tax_inverted"], 2)],
        ["C", "Adjusted Total Turnover", inr(t["att"], 2)],
        ["", "ITC on inputs" + (" and eligible input services" if res["version"] == "V2026" else "") + " (before reversals)",
         inr(sel.get("net_itc_gross", sel["net_itc"]), 2)],
        ["", "Less: ITC reversals attributable (GSTR-3B Table 4(B))", inr(sel.get("reversal_net_itc", 0), 2)],
        ["D", "Net ITC", inr(sel["net_itc"], 2)],
        ["E", "ITC availed on inputs and input services", inr(sel["itc_inputs_services"], 2)],
        ["F", "A x D / C", inr(sel["part1"], 2)],
        ["G", "Deduction for tax payable" + (" (B x D / E)" if res["version"] == "V2022" else " (B)"), inr(sel["part2"], 2)],
        ["H", "Maximum refund (F - G)", inr(sel["max_refund"], 2)],
        ["I", "Balance in electronic credit ledger - end of period", inr(res["ecl"]["end_total"], 2)],
        ["J", "Balance in electronic credit ledger - at filing", inr(res["ecl"]["filing_total"], 2)],
        ["K", "Refund admissible (least of H, I, J)", inr(ref["amount"])],
    ]
    _table(d, ["Ref", "Particulars", "Amount (Rs.)"], rows, widths=[1.2, 11, 4], num_cols=(2,))
    d.add_paragraph()
    _heading(d, "Comparison of formula versions (for information)", 11, center=False)
    vr = []
    for k, v in res["versions"].items():
        vr.append([law.FORMULAS[k]["short"] + (" (applied)" if k == res["version"] else ""), inr(v["net_itc"], 2),
                   inr(v["part1"], 2), inr(v["part2"], 2), inr(v["max_refund"], 2)])
    _table(d, ["Formula", "Net ITC", "A x D / C", "Deduction", "Maximum refund"], vr, num_cols=(1, 2, 3, 4))

    # Annexure II
    if recon_snap:
        d.add_page_break()
        _heading(d, "ANNEXURE II - RECONCILIATION SUMMARY", 12)
        _heading(d, "Outward supplies: Books vs GSTR-1 vs GSTR-3B", 10.5, center=False)
        _table(d, ["Period", "Books taxable", "GSTR-1 taxable", "GSTR-3B taxable", "Diff (Books-GSTR-1)"],
               [[law.period_label(o["period"]), inr(o["books_tx"], 2), inr(o["g1_tx"], 2),
                 "-" if o["g3_tx"] is None else inr(o["g3_tx"], 2), inr(o["diff_g1"], 2)] for o in recon_snap["outward"]],
               num_cols=(1, 2, 3, 4))
        d.add_paragraph()
        _heading(d, "Input tax credit: Books vs GSTR-3B vs GSTR-2B", 10.5, center=False)
        _table(d, ["Period", "Books (eligible)", "GSTR-3B 4(A)", "GSTR-2B", "Diff (Books-3B)"],
               [[law.period_label(o["period"]), inr(o["books"], 2), "-" if o["g3b"] is None else inr(o["g3b"], 2),
                 inr(o["g2b"], 2), "-" if o["diff_3b"] is None else inr(o["diff_3b"], 2)] for o in recon_snap["itc"]],
               num_cols=(1, 2, 3, 4))
    d.save(path)
    return path
