"""Entry point: python -m idtra.server  (runs on the server machine)."""
import logging
import socket
import sys

from . import APP_NAME, APP_VERSION, config
from .web import create_app


def lan_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except socket.gaierror:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127."))


def main():
    cfg = config.load()
    app = create_app(cfg)
    logdir = cfg["data_root"] / "_Logs"
    logdir.mkdir(parents=True, exist_ok=True)
    from logging.handlers import RotatingFileHandler
    handlers = [RotatingFileHandler(logdir / "server.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8")]
    if sys.stdout is not None:
        handlers.append(logging.StreamHandler())
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=handlers)
    logging.info("Starting %s v%s on port %s, data %s", APP_NAME, APP_VERSION, cfg["port"], cfg["data_root"])
    print("=" * 70)
    print(f" {APP_NAME}  v{APP_VERSION}")
    print(f" Data folder : {cfg['data_root']}")
    print(f" Database    : {cfg['db_path']}")
    if cfg["host"] in ("127.0.0.1", "localhost"):
        print(" Mode        : standalone (this computer only)")
    else:
        for ip in lan_ips():
            print(f" LAN address : http://{ip}:{cfg['port']}")
    print(f" This PC     : http://localhost:{cfg['port']}")
    print(" Keep this window open (or run as the 'IDTRA Server' scheduled task).")
    print("=" * 70)
    if "--dev" in sys.argv:
        app.run(host=cfg["host"], port=cfg["port"], debug=True)
        return
    from waitress import serve
    serve(app, host=cfg["host"], port=cfg["port"], threads=cfg["threads"], max_request_body_size=200 * 1024 * 1024)


if __name__ == "__main__":
    main()
