"""Folder structure on the server:
<DATA_ROOT>/<Client Name>/<Financial Year>/<Period>/<sub-folders>
"""
import hashlib
import re
import shutil
from pathlib import Path

from . import db, law

SUBFOLDERS = ["01_Portal_Downloads", "02_Books_of_Account", "03_Reconciliation", "04_Computation",
              "05_Declarations", "06_CA_Certificate", "07_Upload_Files", "08_SCN_and_Replies"]

DATA_ROOT = None


def init(data_root):
    global DATA_ROOT
    DATA_ROOT = Path(data_root)
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    (DATA_ROOT / "_Backups").mkdir(exist_ok=True)


WIN_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}


def safe(name, maxlen=60):
    """Folder/file name valid on Windows: no reserved characters or device names, no trailing dot/space,
    length limited so that full paths stay well inside the 260-character Windows limit."""
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", str(name))
    s = re.sub(r"\s+", " ", s).strip()[:maxlen].strip().rstrip(". ")
    if s.split(".")[0].upper() in WIN_RESERVED:
        s = "_" + s
    return s or "Unnamed"


def client_folder_name(legal_name, gstin, exclude_id=None):
    base = safe(legal_name)
    clash = db.q1("SELECT id FROM clients WHERE folder_name=? AND id IS NOT ?", (base, exclude_id))
    return f"{base} ({gstin})" if clash else base


def period_folder_name(p_from, p_to):
    if p_from == p_to:
        return law.period_label(p_from)
    return f"{law.period_label(p_from)} to {law.period_label(p_to)}"


def claim_dir(claim, client):
    d = DATA_ROOT / client["folder_name"] / claim["fy"] / period_folder_name(claim["period_from"], claim["period_to"])
    for s in SUBFOLDERS:
        (d / s).mkdir(parents=True, exist_ok=True)
    return d


def rel(path):
    return str(Path(path).resolve().relative_to(DATA_ROOT.resolve())).replace("\\", "/")


def absolute(relpath):
    p = (DATA_ROOT / relpath).resolve()
    if DATA_ROOT.resolve() not in p.parents and p != DATA_ROOT.resolve():
        raise PermissionError("Path outside data folder")
    return p


def save_upload(fs, dest_dir, prefix=""):
    """Save a werkzeug FileStorage into dest_dir, keeping older versions."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    base = Path(fs.filename or "upload").name
    if prefix and base.lower().startswith(prefix.lower().rstrip("_")):
        prefix = ""
    suffix = re.sub(r"[^A-Za-z0-9.]", "", Path(base).suffix)[:8]
    name = safe(prefix + Path(base).stem, 70) + suffix
    target = dest_dir / name
    if target.exists():
        stem, ext = target.stem, target.suffix
        i = 2
        while (dest_dir / f"{stem}_v{i}{ext}").exists():
            i += 1
        target = dest_dir / f"{stem}_v{i}{ext}"
    fs.save(str(target))
    return target


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def register_doc(claim_id, doc_type, path, user):
    db.insert("documents", dict(claim_id=claim_id, doc_type=doc_type, file_path=rel(path),
                                sha256=sha256(path), created_by=user, created_at=db.now()))


def rename_client_folder(old, new):
    if old and new and old != new and (DATA_ROOT / old).exists() and not (DATA_ROOT / new).exists():
        shutil.move(str(DATA_ROOT / old), str(DATA_ROOT / new))
        for c in db.q("SELECT id, file_path FROM documents"):
            if c["file_path"].startswith(old + "/"):
                db.x("UPDATE documents SET file_path=? WHERE id=?", (new + c["file_path"][len(old):], c["id"]))
        for c in db.q("SELECT id, file_path FROM portal_files"):
            if (c["file_path"] or "").startswith(old + "/"):
                db.x("UPDATE portal_files SET file_path=? WHERE id=?", (new + c["file_path"][len(old):], c["id"]))
