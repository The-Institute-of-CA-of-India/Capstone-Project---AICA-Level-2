"""Show cause notices (FORM GST RFD-08) and other notices on a refund claim:
text extraction, identification of the grounds raised, and draft replies (FORM GST RFD-09) built
from the claim's own computation, reconciliation and Annexure-B.

The analysis is rule-based (works offline): each ground in GROUNDS has search patterns and a reply
template. Every draft must be reviewed and edited by the professional before it is filed.
"""
import datetime as dt
import json
import re
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt, RGBColor

from . import calc, db, law, recon
from .docgen import inr

NOTICE_TYPES = ["RFD-08 Show cause notice (Rule 92(3))", "RFD-03 Deficiency memo (Rule 90(3))",
                "Personal hearing notice", "Other notice / letter"]
STATUSES = ["Received", "Analysed", "Reply drafted", "Reply filed", "Hearing attended", "Order received", "Closed"]
REPLY_DAYS = 15          # Rule 92(3): reply in FORM GST RFD-09 within fifteen days of receipt
APPEAL_MONTHS = 3        # Section 107(1)


# ------------------------------------------------------------------ text extraction
def extract_text(path):
    p = Path(path)
    ext = p.suffix.lower()
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            r = PdfReader(str(p))
            txt = "\n".join((pg.extract_text() or "") for pg in r.pages)
            return txt.strip(), ("" if len(txt.strip()) > 40 else
                                 "The PDF appears to be scanned (no text layer). Paste the text of the notice below "
                                 "(e.g. copy from the portal) so that it can be analysed.")
        if ext == ".docx":
            d = Document(str(p))
            return "\n".join(par.text for par in d.paragraphs).strip(), ""
        if ext in (".txt", ".htm", ".html"):
            raw = p.read_bytes().decode("utf-8", "ignore")
            return re.sub(r"<[^>]+>", " ", raw).strip(), ""
    except Exception as e:      # noqa: BLE001 - any parsing failure is reported to the user
        return "", f"Could not read the file ({e}). Paste the text of the notice below."
    return "", "Images cannot be read automatically. Paste the text of the notice below."


# ------------------------------------------------------------------ facts from the notice
def parse_facts(text):
    t = text or ""
    facts = {}
    m = re.search(r"(?:SCN|Notice|Reference|Ref\.?)\s*(?:No\.?|Number)\s*[:.\-]?\s*([A-Z0-9][A-Z0-9/\-]{5,40})", t, re.I)
    if m:
        facts["ref_no"] = m.group(1)
    m = re.search(r"\bARN\b\s*(?:No\.?)?\s*[:.\-]?\s*([A-Z]{2}[0-9A-Z]{10,20})", t, re.I)
    if m:
        facts["arn"] = m.group(1)
    dates = re.findall(r"\b(\d{1,2})[./-](\d{1,2})[./-](20\d{2})\b", t)
    if dates:
        d, mth, y = dates[0]
        try:
            facts["notice_date"] = dt.date(int(y), int(mth), int(d)).isoformat()
        except ValueError:
            pass
    amts = []
    for a in re.findall(r"(?:Rs\.?|INR|₹)\s*([0-9][0-9,]*(?:\.\d{1,2})?)", t, re.I):
        try:
            amts.append(float(a.replace(",", "")))
        except ValueError:
            pass
    if amts:
        facts["amounts"] = sorted(set(amts), reverse=True)[:10]
    if re.search(r"RFD[\s\-]*08", t, re.I):
        facts["notice_type"] = NOTICE_TYPES[0]
    elif re.search(r"RFD[\s\-]*03|deficiency", t, re.I):
        facts["notice_type"] = NOTICE_TYPES[1]
    return facts


# ------------------------------------------------------------------ context for replies
def context(claim, client):
    res = calc.latest(claim["id"], final_only=True) or calc.latest(claim["id"])
    snap = recon.snapshot(claim["id"]) or {}
    a = db.get_setting(f"annexb_{claim['id']}")
    annexb = json.loads(a) if a else {}
    months = law.months_between(claim["period_from"], claim["period_to"])
    per = law.period_label(months[0]) + ("" if len(months) == 1 else " to " + law.period_label(months[-1]))
    return {"claim": claim, "client": client, "res": res, "snap": snap, "annexb": annexb, "period": per,
            "months": months,
            "tl": law.time_limit(claim["period_from"], claim["period_to"], client.get("filing_freq") or "Monthly")}


def _r(ctx):
    return ctx["res"] or {}


def _amt(v, d=2):
    return "Rs. " + inr(v or 0, d)


# ------------------------------------------------------------------ grounds library
def g_2b(ctx):
    res = _r(ctx)
    ex = (res.get("selected", {}).get("buckets", {}) or {}).get("Excluded", {})
    ab = ctx["annexb"]
    return (
        "The notice alleges that input tax credit included in the claim is not reflected in FORM GSTR-2A/2B of the "
        "applicant. In this regard it is submitted that:\n"
        f"(a) Every inward invoice of the period was matched with FORM GSTR-2B invoice-wise (supplier GSTIN and "
        f"document number). Credit on documents not reflected in GSTR-2B, amounting to {_amt(ex.get('tax'))}, was "
        f"already excluded from Net ITC while computing the refund, in terms of section 16(2)(aa) of the CGST Act, 2017 "
        f"and paragraph 5 of Circular No. 135/05/2020-GST. Where the value in GSTR-2B was lower than in the invoice, "
        f"credit was restricted to the GSTR-2B amount.\n"
        f"(b) Annexure-B uploaded with the application ({ab.get('rows', '__')} lines) states against each invoice the "
        f"GSTR-2B return period in which it appears; the officer may verify any invoice against that period.\n"
        "(c) The reconciliation of books, GSTR-3B and GSTR-2B for each month of the claim is enclosed.\n"
        "Hence no part of the refund is based on credit not reflected in GSTR-2B, and the proposal to reject the claim "
        "on this ground deserves to be dropped. [If any specific invoice is listed in the notice, add its position here.]")


def g_services_cg(ctx):
    res = _r(ctx)
    v = res.get("version", "")
    b = res.get("selected", {}).get("buckets", {}) or {}
    if v == "V2026":
        txt = ("Rule 89(5) of the CGST Rules, 2017 was substituted by Notification No. 05/2026-Central Tax dated "
               "26.10.2026 with effect from 01.11.2026. Under the substituted rule, 'Net ITC' means the sum of input tax "
               "credit availed on inputs and eligible input services, 'eligible input services' being input services on "
               "which credit has been availed on or after 01.11.2026. The applicant has included only such input "
               f"services ({_amt(b.get('Eligible Input Services', {}).get('tax'))}); credit on input services availed "
               f"before 01.11.2026 ({_amt(b.get('Input Services', {}).get('tax'))}) and on capital goods has been excluded.")
    else:
        txt = ("Net ITC has been computed on input tax credit availed on inputs (goods) only. Credit on input services "
               f"({_amt(b.get('Input Services', {}).get('tax'))}) and on capital goods has NOT been included in Net ITC, in "
               "accordance with the explanation to rule 89(5) as upheld by the Hon'ble Supreme Court in Union of India v. "
               "VKC Footsteps India Pvt. Ltd. (2021). Credit on input services appears only in the denominator "
               "'ITC availed on inputs and input services' where the formula as amended by Notification No. 14/2022-"
               "Central Tax requires it.")
    return "The notice alleges that credit on input services / capital goods has been included in Net ITC. " + txt + \
        " The category of every invoice (Inputs / Input Services / Capital Goods) is shown in Annexure-B."


def g_trading(ctx):
    res = _r(ctx)
    ta = res.get("trading_adjustment") or {}
    tp = res.get("trading_purchases") or {}
    if ta.get("method") == "gross_up":
        adj = (f"The turnover corresponding to these purchases has also been excluded from the turnover of inverted rated "
               f"supply: cost of traded goods sold {_amt(ta.get('cost_sold'))} (purchases {_amt(ta.get('purchases'))} "
               f"adjusted for opening and closing stock) grossed up by the gross profit of {ta.get('gp_percent', 0):.2f}% "
               f"{'of sales' if ta.get('gp_basis') == 'sales' else 'on cost'} (the higher of the minimum of "
               f"{ta.get('gp_minimum', 10):g}% and the gross profit declared by the applicant), i.e. "
               f"{_amt(ta.get('deemed_turnover'))}, with the corresponding tax of {_amt(ta.get('deduct_tax'))}.")
    else:
        adj = (f"Sales of traded goods identified in the books, {_amt(res.get('turnover', {}).get('trading_outward'))}, "
               f"have not been treated as inverted rated supply.")
    return ("The notice alleges that the applicant is a trader / that the input and the output supplies are the same, "
            "so that refund under section 54(3)(ii) is not admissible in view of paragraph 3 of Circular No. "
            "135/05/2020-GST. It is submitted that the applicant is a manufacturer: the outward supplies on which refund "
            "is claimed are goods manufactured by the applicant, which are different from the inputs (different goods / "
            "HSN, as shown in the HSN-wise statement of inputs and outputs enclosed). Goods purchased and sold as such have "
            f"been segregated: input tax credit of {_amt(tp.get('itc'))} on trading purchases of {_amt(tp.get('txval'))} has "
            f"been excluded from Net ITC. {adj} The refund claimed therefore relates only to the accumulation caused by "
            "the inverted rate structure of manufactured goods, and paragraph 3 of the Circular does not apply.")


def g_inverted(ctx):
    res = _r(ctx)
    t = res.get("turnover", {})
    rates = ", ".join(f"{k}%: {_amt(v.get('txval'))}" for k, v in (t.get("inverted_by_rate") or {}).items())
    return ("The notice states that an inverted duty structure is not established. It is submitted that the rate of tax "
            f"on the principal inputs is {res.get('max_input_rate', '__')}% while the outward supplies considered as "
            f"inverted rated supply are taxed at lower rates ({rates or 'as per statement enclosed'}). The accumulation "
            "of credit is therefore on account of the rate of tax on inputs being higher than the rate of tax on output "
            "supplies, which is the condition of clause (ii) of the first proviso to section 54(3). The outward supplies "
            "are neither nil rated nor fully exempt. The HSN- and rate-wise statement of inputs and outputs is enclosed.")


def g_turnover(ctx):
    res = _r(ctx)
    t = res.get("turnover", {})
    rows = "; ".join(f"{law.period_label(o['period'])}: books {inr(o['books_tx'], 2)} / GSTR-1 {inr(o['g1_tx'], 2)} / "
                     f"GSTR-3B {inr(o['g3_tx'] or 0, 2)}" for o in (ctx["snap"].get("outward") or []))
    return ("Regarding the turnover figures: the turnover of inverted rated supply "
            f"({_amt(t.get('inverted'))}) and the adjusted total turnover ({_amt(t.get('att'))}) have been taken from the "
            "books of account and reconciled month-wise with FORM GSTR-1 and FORM GSTR-3B. The adjusted total turnover "
            f"excludes exempt / nil rated / non-GST supplies ({_amt(t.get('exempt_total'))}) as required by rule 89(4)(E); "
            "credit notes have been reduced from turnover. Month-wise position: " + (rows or "see reconciliation") +
            ". Any difference noted in the reconciliation has been explained in the enclosed statement.")


def g_time(ctx):
    rows = "; ".join(f"{law.period_label(t['period'])}: relevant date {t['relevant_date']}, last date {t['last_date']}"
                     for t in ctx["tl"])
    return ("The notice alleges that the claim is barred by limitation. Under section 54(1) read with clause (e) of "
            "Explanation 2 to section 54, the relevant date for refund of unutilised input tax credit on account of "
            "inverted duty structure is the due date for furnishing the return under section 39 for the period in which "
            f"the claim arises. For this claim: {rows}. The application was filed on "
            f"{ctx['claim'].get('filing_date') or '__'}, within two years of the relevant date for every tax period "
            "covered. [Verify the dates against the notice.]")


def g_notified(ctx):
    res = _r(ctx)
    return ("The notice refers to goods notified under the proviso to section 54(3)(ii) (Notification No. 5/2017-Central "
            "Tax (Rate), as amended). It is submitted that turnover of goods covered by that notification for the "
            f"relevant period ({_amt(res.get('turnover', {}).get('restricted_outward'))}) has not been included in the "
            "turnover of inverted rated supply. The goods on which refund is claimed fall under HSN codes that are not "
            "notified (HSN-wise statement enclosed).")


def g_unjust(ctx):
    return ("The notice raises unjust enrichment. It is submitted that the doctrine of unjust enrichment does not apply "
            "to refund of unutilised input tax credit: by virtue of clause (b) of sub-section (8) of section 54, refund "
            "of unutilised input tax credit under section 54(3) is paid to the applicant instead of being credited to the "
            "Consumer Welfare Fund, and no question of passing on the incidence of tax arises. A certificate under rule "
            "89(2)(m) is not required for this category of refund.")


def g_ecl(ctx):
    res = _r(ctx)
    e = res.get("ecl", {})
    rf = res.get("refund", {})
    return ("Regarding the balance in the electronic credit ledger: the balance was "
            f"{_amt(e.get('end_total'))} at the end of the tax period and {_amt(e.get('filing_total'))} at the time of "
            f"filing. The refund claimed, {_amt(rf.get('amount'), 0)}, is the least of the maximum refund as per formula "
            f"({_amt(res.get('selected', {}).get('max_refund'))}) and these balances, and the ledger was debited head-wise "
            f"(IGST {inr(rf.get('heads', {}).get('igst', 0))}, CGST {inr(rf.get('heads', {}).get('cgst', 0))}, "
            f"SGST/UTGST {inr(rf.get('heads', {}).get('sgst', 0))}) in the manner provided in rule 89(3).")


def g_formula(ctx):
    res = _r(ctx)
    t, s = res.get("turnover", {}), res.get("selected", {})
    vers = "; ".join(f"{k}: {inr(v.get('max_refund'), 2)}" for k, v in (res.get("versions") or {}).items())
    return ("Regarding the computation under rule 89(5): the refund has been computed as per "
            f"{res.get('formula_label', '')}, applicable to the date of filing. Formula: {res.get('formula_text', '')}. "
            f"A = {inr(t.get('inverted'), 2)}; B = {inr(t.get('tax_inverted'), 2)}; C = {inr(t.get('att'), 2)}; "
            f"Net ITC = {inr(s.get('net_itc'), 2)}; maximum refund = {inr(s.get('max_refund'), 2)}. "
            "The working, which the officer may verify step by step, is enclosed (CA certificate Annexure I). "
            f"For reference, the result under each version of the rule is: {vers}. Where the officer has applied a "
            "different version, it is submitted that the amendment by Notification No. 14/2022-Central Tax has been "
            "held to be clarificatory and curative in nature (Hon'ble Gujarat High Court, Tirth Agro Technology Pvt. "
            "Ltd., 20.12.2024). [Verify citation and its applicability before filing.]")


def g_blocked(ctx):
    res = _r(ctx)
    return ("The notice alleges inclusion of ineligible / blocked credit. Credit blocked under section 17(5) was not "
            "availed / has been excluded from Net ITC; Annexure-B shows against each invoice whether the credit is "
            "blocked under section 17(5), and the eligible and ineligible amount. ITC reversals reported in Table 4(B) of "
            f"GSTR-3B ({_amt(res.get('reversals_3b', {}).get('total'))}) have been deducted from Net ITC to the extent "
            f"attributable ({_amt(res.get('selected', {}).get('reversal_net_itc'))}).")


def g_supplier(ctx):
    return ("The notice questions the genuineness of certain suppliers / alleges that suppliers' registrations were "
            "cancelled or that tax was not paid by them. It is submitted that (a) the invoices were issued by suppliers "
            "who were registered on the date of supply and are reflected in FORM GSTR-2B; (b) the goods were actually "
            "received and used in manufacture (purchase invoices, e-way bills, goods receipt notes, stock records and "
            "payment through banking channels are enclosed); and (c) the applicant has given the undertaking under "
            "sections 16(2)(c) and 42(2) to repay the refund with interest if the conditions are found not to be "
            "satisfied. The applicant has fulfilled every condition of section 16 that is within its control. "
            "[List the suppliers named in the notice with the documents for each.]")


def g_documents(ctx):
    return ("The notice states that documents were not furnished. The following documents were uploaded with the "
            "application / are furnished with this reply: Statement 1 (computation), Annexure-B (statement of inward "
            "invoices with GSTR-2B period), statement of outward invoices, declarations and undertakings, certificate of "
            "the Chartered Accountant with UDIN, reconciliation of books with GSTR-1, GSTR-3B and GSTR-2B, and "
            "HSN-wise statement of inputs and outputs. Any further document the officer requires will be furnished.")


def g_rate_change(ctx):
    return ("The notice relies on paragraph 3.2 of Circular No. 135/05/2020-GST (accumulation due to a reduction in "
            "the rate of the same goods). It is submitted that the accumulation in the present case is not due to a "
            "change in the rate of the same goods over time: the inputs and the outputs are different goods, and the "
            "output rate is lower than the input rate throughout the period. The clarification therefore has no "
            "application.")


def g_itc_3b(ctx):
    rows = "; ".join(f"{law.period_label(o['period'])}: books {inr(o['books'], 2)} / GSTR-3B {inr(o['g3b'] or 0, 2)} / "
                     f"GSTR-2B {inr(o['g2b'], 2)}" for o in (ctx["snap"].get("itc") or []))
    return ("Regarding the difference between ITC in the refund working and ITC availed in GSTR-3B: Net ITC for refund "
            "is a part of the credit availed in GSTR-3B (credit on inputs, after excluding trading, blocked and "
            "non-2B credit and reversals), so it is necessarily lower than the total credit availed. Month-wise "
            f"reconciliation: {rows or 'enclosed'}.")


def g_credit_notes(ctx):
    return ("Regarding the treatment of credit notes and exempt / zero-rated turnover: credit notes issued for goods "
            "returned have been reduced from turnover, since returned goods no longer form part of the supply (see "
            "GSTAT Kolkata, Rajshahi Banijya Pvt. Ltd., 2026 - verify citation). Exempt and nil rated supplies are "
            "excluded from adjusted total turnover as required by rule 89(4)(E).")


def g_vague(ctx):
    return ("At the outset, the notice does not state the specific reasons for which the refund is proposed to be "
            "rejected, nor the computation of the amount proposed to be rejected. Rule 92(3) requires the proper officer "
            "to record reasons in writing; a notice that does not disclose the grounds denies the applicant a fair "
            "opportunity to reply. The applicant requests that the specific grounds and the working be communicated. "
            "Without prejudice, the applicant replies below on all aspects of the claim.")


GROUNDS = [
    ("G01", "ITC not reflected in GSTR-2A / 2B", [r"gstr[\s\-]*2\s*[ab]\b", r"not\s+reflect", r"mismatch\s+of\s+itc",
                                                  r"not\s+appearing", r"supplier[s]?\s+(?:have\s+)?not\s+(?:filed|uploaded)"], g_2b),
    ("G02", "Input services / capital goods included in Net ITC", [r"input\s+services?", r"capital\s+goods"], g_services_cg),
    ("G03", "Trading / same input and output (Circular 135)", [r"trad(?:ing|er)", r"same\s+(?:goods|hsn|input)",
                                                               r"input\s+and\s+output\s+(?:are|is)\s+(?:the\s+)?same",
                                                               r"para(?:graph)?\s*3\b.*135"], g_trading),
    ("G04", "Inverted duty structure not established", [r"not\s+(?:an?\s+)?invert", r"inverted\s+(?:duty|tax|rate)\s+structure\s+(?:is\s+)?not",
                                                        r"rate\s+of\s+(?:tax\s+on\s+)?(?:input|output)", r"higher\s+rate"], g_inverted),
    ("G05", "Turnover / adjusted total turnover mismatch", [r"turnover\s+(?:\w+\s+){0,4}(?:does\s+not\s+match|not\s+match|mismatch|differ)",
                                                            r"(?:mismatch|difference|differs?)\s+(?:\w+\s+){0,6}turnover",
                                                            r"adjusted\s+total\s+turnover", r"gstr[\s\-]*1\b.{0,80}(?:not\s+match|differ|mismatch)"], g_turnover),
    ("G06", "Time limitation u/s 54(1)", [r"time[\s\-]*barred", r"limitation", r"two\s+years", r"relevant\s+date"], g_time),
    ("G07", "Goods notified under N/N 5/2017-CT(R)", [r"5/2017", r"notified\s+goods", r"9/2022"], g_notified),
    ("G08", "Unjust enrichment", [r"unjust", r"incidence\s+of\s+tax", r"passed\s+on"], g_unjust),
    ("G09", "Electronic credit ledger balance / debit", [r"credit\s+ledger", r"\becl\b", r"insufficient\s+balance", r"89\s*\(\s*3\s*\)"], g_ecl),
    ("G10", "Computation / formula under Rule 89(5)", [r"formula", r"excess\s+refund", r"computation\s+(?:is\s+)?(?:incorrect|wrong|erroneous|not\s+as\s+per)",
                                                         r"(?:incorrect|wrong|erroneous)(?:ly)?\s+(?:\w+\s+){0,3}comput", r"tax\s+payable\s+on\s+(?:such\s+)?inverted"], g_formula),
    ("G11", "Blocked / ineligible credit, ITC reversals", [r"17\s*\(\s*5\s*\)", r"blocked", r"ineligible", r"rule\s*4[23]", r"revers"], g_blocked),
    ("G12", "Supplier genuineness / cancelled registration", [r"cancel", r"non[\s\-]*existent", r"fake", r"bogus", r"genuine",
                                                               r"16\s*\(\s*2\s*\)\s*\(\s*c\s*\)", r"non[\s\-]*filer"], g_supplier),
    ("G13", "Documents not furnished", [r"not\s+(?:been\s+)?(?:furnished|submitted|uploaded|enclosed)", r"annexure[\s\-]*b",
                                       r"documents?\s+(?:are\s+)?(?:missing|required)", r"certificate"], g_documents),
    ("G14", "Rate change of same goods (Circular 135 para 3.2)", [r"rate\s+(?:change|reduc)", r"reduction\s+in\s+(?:the\s+)?rate"], g_rate_change),
    ("G15", "ITC in refund vs GSTR-3B", [r"itc\s+(?:availed\s+)?(?:in|as\s+per)\s+gstr[\s\-]*3b", r"table\s*4"], g_itc_3b),
    ("G16", "Credit notes / exempt supplies in turnover", [r"credit\s+note", r"exempt", r"nil\s+rated"], g_credit_notes),
]
G_VAGUE = ("G00", "Notice does not state specific grounds", [r"\bother\b", r"\bothers\b"], g_vague)


def analyse(text):
    """Return list of (code, title, snippet) for grounds found in the notice text."""
    t = text or ""
    # split the notice into its paragraphs / numbered points (not on every full stop: "Rs." and "No." contain one)
    segs = re.split(r"\n\s*\n|\n(?=\s*(?:\d{1,2}|[a-h]|[ivx]{1,4})\s*[.)]\s)", t)
    segs = [re.sub(r"\s+", " ", s).strip() for s in segs if s and s.strip()]
    found = []
    for code, title, pats, _fn in [G_VAGUE] + GROUNDS:
        snip = None
        for p in pats:
            for s in segs:
                m = re.search(p, s, re.I)
                if m:
                    snip = s if len(s) <= 600 else s[max(0, m.start() - 250):m.end() + 250]
                    break
            if snip:
                break
        if snip:
            found.append((code, title, snip))
    words = len(re.findall(r"\w+", t))
    if words and words < 60 and not any(f[0] == "G00" for f in found):
        found.insert(0, (G_VAGUE[0], G_VAGUE[1], "Notice text is very short / non-speaking."))
    if found and found[0][0] == "G00" and len(found) > 3:
        found = found[1:]     # a detailed notice is not a vague one
    return found


def ground_fn(code):
    for c, _t, _p, fn in [G_VAGUE] + GROUNDS:
        if c == code:
            return fn
    return None


def build_grounds(notice, ctx):
    """(Re)create automatic grounds for a notice; manual grounds are kept."""
    db.x("DELETE FROM notice_grounds WHERE notice_id=? AND auto=1", (notice["id"],))
    found = analyse(notice.get("notice_text"))
    for i, (code, title, snip) in enumerate(found):
        fn = ground_fn(code)
        db.insert("notice_grounds", dict(notice_id=notice["id"], code=code, title=title, allegation=snip,
                                         reply_text=fn(ctx) if fn else "", include=1, auto=1, sort=i))
    return found


def all_ground_titles():
    return [(c, t) for c, t, _p, _f in [G_VAGUE] + GROUNDS]


def add_from_library(notice_id, code, ctx):
    fn = ground_fn(code)
    title = dict(all_ground_titles()).get(code, "Additional ground")
    n = db.q1("SELECT COALESCE(MAX(sort),0)+1 s FROM notice_grounds WHERE notice_id=?", (notice_id,))["s"]
    db.insert("notice_grounds", dict(notice_id=notice_id, code=code, title=title, allegation="",
                                     reply_text=fn(ctx) if fn else "", include=1, auto=0, sort=n))


def due_date(received):
    try:
        return (dt.date.fromisoformat(received) + dt.timedelta(days=REPLY_DAYS)).isoformat()
    except (TypeError, ValueError):
        return ""


def appeal_due(order_date):
    try:
        d = dt.date.fromisoformat(order_date)
    except (TypeError, ValueError):
        return ""
    m = d.month - 1 + APPEAL_MONTHS
    y, m = d.year + m // 12, m % 12 + 1
    import calendar
    return dt.date(y, m, min(d.day, calendar.monthrange(y, m)[1])).isoformat()


# ------------------------------------------------------------------ reply document
def _dmy(iso):
    try:
        return dt.date.fromisoformat(iso[:10]).strftime("%d.%m.%Y")
    except (TypeError, ValueError):
        return iso or "__________"


def reply_docx(path, notice, grounds, ctx, signatory, docs_list):
    claim, client, res = ctx["claim"], ctx["client"], _r(ctx)
    d = Document()
    for s in d.sections:
        s.left_margin = s.right_margin = Cm(2.2)
        s.top_margin = s.bottom_margin = Cm(2)
    st = d.styles["Normal"]
    st.font.name = "Cambria"
    st.font.size = Pt(11)

    def H(text, size=12, center=False, color="1F3864"):
        p = d.add_paragraph()
        if center:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        r.bold = True
        r.font.size = Pt(size)
        r.font.color.rgb = RGBColor.from_string(color)
        return p

    def P(text, bold=False, italic=False, indent=0.0, justify=True):
        p = d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY if justify else WD_ALIGN_PARAGRAPH.LEFT
        if indent:
            p.paragraph_format.left_indent = Cm(indent)
        r = p.add_run(text)
        r.bold, r.italic = bold, italic
        return p

    is_scn = (notice.get("notice_type") or "").startswith("RFD-08")
    H("FORM GST RFD-09" if is_scn else "REPLY", 13, True, "C00000")
    if is_scn:
        p = d.add_paragraph("[See rule 92(3)]  -  Reply to show cause notice")
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    P(f"Date: {_dmy(dt.date.today().isoformat())}")
    P("To,\nThe Proper Officer,\n" + (notice.get("officer") or "Goods and Services Tax Department"), justify=False)
    rows = [("1. Reference No. of notice", notice.get("ref_no") or "________"),
            ("2. Date of notice", _dmy(notice.get("notice_date"))),
            ("3. GSTIN", client["gstin"]), ("4. Name", client["legal_name"]),
            ("5. ARN of refund application", f"{notice.get('arn') or '________'} dated {_dmy(notice.get('arn_date'))}"),
            ("6. Tax period", ctx["period"]),
            ("7. Refund claimed", _amt(notice.get("amount_claimed") or (res.get("refund") or {}).get("amount"), 0)),
            ("8. Amount proposed to be rejected", _amt(notice.get("amount_proposed"), 0))]
    t = d.add_table(rows=0, cols=2)
    t.style = "Table Grid"
    for a, b in rows:
        c = t.add_row().cells
        c[0].text, c[1].text = a, str(b)
    d.add_paragraph()
    P(f"Subject: Reply to the {'show cause notice in FORM GST RFD-08' if is_scn else 'notice'} referred above in "
      f"respect of the application for refund of unutilised input tax credit on account of inverted duty structure "
      f"for the period {ctx['period']}.", bold=True)
    P("Respected Sir/Madam,")

    H("A. BRIEF FACTS", 11.5)
    tt, sel, rf = res.get("turnover", {}), res.get("selected", {}), res.get("refund", {})
    P(f"1. The applicant, {client['legal_name']} (GSTIN {client['gstin']}), filed an application in FORM GST RFD-01 "
      f"for refund of unutilised input tax credit under clause (ii) of the first proviso to section 54(3) of the CGST "
      f"Act, 2017 for {ctx['period']}, claiming {_amt(rf.get('amount'), 0)}.")
    P(f"2. The claim was computed as per {res.get('formula_label', 'rule 89(5)')}: turnover of inverted rated supply "
      f"{_amt(tt.get('inverted'))}, tax payable thereon {_amt(tt.get('tax_inverted'))}, adjusted total turnover "
      f"{_amt(tt.get('att'))}, Net ITC {_amt(sel.get('net_itc'))}, maximum refund {_amt(sel.get('max_refund'))}, "
      f"limited to the balance in the electronic credit ledger where lower. The computation is certified by a Chartered "
      f"Accountant" + (f" (UDIN {claim.get('udin')})" if claim.get("udin") else "") + ".")
    P(f"3. The notice dated {_dmy(notice.get('notice_date'))} proposes to reject "
      f"{_amt(notice.get('amount_proposed'), 0)} of the claim. The applicant replies to each ground as follows.")

    H("B. REPLY TO THE GROUNDS IN THE NOTICE", 11.5)
    for i, g in enumerate([g for g in grounds if g["include"]], start=1):
        P(f"Ground {i}: {g['title']}", bold=True)
        if g.get("allegation"):
            P(f"Allegation in the notice: \"{g['allegation']}\"", italic=True, indent=0.6)
        for para in (g.get("reply_text") or "").split("\n"):
            if para.strip():
                P(para.strip(), indent=0.6)

    H("C. LEGAL PROVISIONS RELIED UPON", 11.5)
    for x in ["Section 54(3)(ii), 54(1) with Explanation 2(e), 54(8)(b) and section 56 of the CGST Act, 2017;",
              "Rules 89(2), 89(3), 89(4) and 89(5) and rule 92(3) of the CGST Rules, 2017;",
              f"{res.get('formula_label', 'Rule 89(5)')};",
              "Circular No. 125/44/2019-GST and Circular No. 135/05/2020-GST;",
              "Notification No. 5/2017-Central Tax (Rate), as amended."]:
        P("• " + x, indent=0.4)

    H("D. PRAYER", 11.5)
    P("In view of the above, the applicant prays that (i) the proceedings proposed in the notice be dropped; (ii) the "
      f"refund of {_amt(rf.get('amount'), 0)} be sanctioned in full in FORM GST RFD-06; (iii) interest under section 56 "
      "be granted for any delay beyond sixty days from the date of receipt of the application; and (iv) before any "
      "adverse order is passed, the applicant be granted an opportunity of personal hearing as required by the proviso "
      "to rule 92(3) of the CGST Rules, 2017, after considering this reply.")
    H("E. DOCUMENTS ENCLOSED", 11.5)
    for i, x in enumerate(docs_list, start=1):
        P(f"{i}. {x}", indent=0.4)
    d.add_paragraph()
    P("VERIFICATION", bold=True)
    sig = signatory or {}
    P(f"I, {sig.get('name', '____________')}, hereby solemnly affirm and declare that the information given hereinabove "
      "is true and correct to the best of my knowledge and belief and nothing has been concealed therefrom.")
    P(f"Place: ____________\nDate: {_dmy(dt.date.today().isoformat())}\n\n\nSignature of Authorised Signatory\n"
      f"Name: {sig.get('name', '____________')}\nDesignation: {sig.get('designation', '____________')}\n"
      f"For {client['legal_name']} (GSTIN {client['gstin']})", justify=False)
    d.add_paragraph()
    P("Draft prepared with the Inverted Tax Duty Refund Application on the basis of the claim records. To be reviewed, "
      "edited and verified by the authorised representative before filing; verify every citation.", italic=True)
    d.save(path)
    return path


def analysis_xlsx(path, notice, grounds, ctx):
    from openpyxl import Workbook
    from .exports import _sheet
    res = _r(ctx)
    wb = Workbook()
    _sheet(wb, "SCN analysis", ["#", "Ground", "Allegation (from notice)", "Included in reply", "Draft reply"],
           [[i, g["title"], g.get("allegation"), "Yes" if g["include"] else "No", g.get("reply_text")]
            for i, g in enumerate(grounds, start=1)], widths={1: 35, 2: 60, 4: 100}, first=True)
    _sheet(wb, "Claim position", ["Particulars", "Amount"], [
        ["Refund claimed", (res.get("refund") or {}).get("amount")], ["Amount proposed to be rejected", notice.get("amount_proposed")],
        ["Turnover of inverted rated supply", res.get("turnover", {}).get("inverted")],
        ["Adjusted total turnover", res.get("turnover", {}).get("att")], ["Net ITC", res.get("selected", {}).get("net_itc")],
        ["Maximum refund", res.get("selected", {}).get("max_refund")]], num_cols=(1,), widths={0: 45})
    wb.save(path)
    return path
