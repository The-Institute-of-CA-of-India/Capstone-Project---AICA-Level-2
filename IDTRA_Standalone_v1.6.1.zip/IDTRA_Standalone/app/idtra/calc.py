"""Refund computation under Section 54(3)(ii) read with Rule 89(5) CGST Rules.

All three historical versions of the formula are computed so the reviewer can
see the effect of the date-based choice; the version applicable to the filing
date (or a reasoned override) is used for the claim.
"""
import json
from collections import defaultdict

from . import db, law

HEADS = ("igst", "cgst", "sgst")


def r2(v):
    return round(float(v or 0), 2)


def _tax(r):
    return (r["igst"] or 0) + (r["cgst"] or 0) + (r["sgst"] or 0)


def _is_reduction(l):
    return l["doc_type"] == "Credit Note" or (l["txval"] or 0) < 0 or _tax(l) < 0


def outward_groups(claim):
    """Outward taxable supplies grouped by HSN + rate with inverted flag suggestion."""
    cid = claim["id"]
    months = law.months_between(claim["period_from"], claim["period_to"])
    ph = ",".join("?" for _ in months)
    max_in = db.q1(f"SELECT MAX(rate) m FROM book_purchases WHERE claim_id=? AND category='Inputs' AND is_trading=0 "
                   f"AND blocked_17_5=0 AND tax_period IN ({ph})", (cid, *months))["m"] or 0
    flags = {(f["hsn"], f["rate"]): f for f in db.q("SELECT * FROM outward_flags WHERE claim_id=?", (cid,))}
    groups = db.q(f"SELECT hsn, rate, MAX(description) description, SUM(txval) txval, SUM(igst) igst, SUM(cgst) cgst, "
                  f"SUM(sgst) sgst, SUM(CASE WHEN is_trading>0 THEN txval ELSE 0 END) trading_tx, COUNT(*) n "
                  f"FROM book_sales WHERE claim_id=? AND supply_type='Taxable' AND tax_period IN ({ph}) "
                  f"GROUP BY hsn, rate ORDER BY txval DESC", (cid, *months))
    for g in groups:
        rg = law.restricted_for(g["hsn"], claim["period_from"], claim["period_to"])
        g["restricted"] = rg["notification"] if rg and rg["applies_to"] == "Exclude" else ""
        g["warn"] = rg["notification"] if rg and rg["applies_to"] != "Exclude" else ""
        g["suggested"] = 1 if (g["rate"] or 0) < max_in and not g["restricted"] else 0
        f = flags.get((g["hsn"], g["rate"]))
        g["is_inverted"] = g["suggested"] if f is None else f["is_inverted"]
        g["overridden"] = f is not None and f["is_inverted"] != g["suggested"]
        g["note"] = f["note"] if f else ""
        g["tax"] = (g["igst"] or 0) + (g["cgst"] or 0) + (g["sgst"] or 0)
    return groups, max_in


def classify_purchases(claim, version):
    """Return list of purchase lines with eligibility bucket and amounts."""
    cid = claim["id"]
    months = set(law.months_between(claim["period_from"], claim["period_to"]))
    lines = db.q("SELECT bp.*, g.igst g_igst, g.cgst g_cgst, g.sgst g_sgst FROM book_purchases bp "
                 "LEFT JOIN gst_2b g ON g.id = bp.match_2b_id WHERE bp.claim_id=? ORDER BY bp.id", (cid,))
    # Restrict value-mismatch invoices to the lower of books and 2B (computed per invoice group)
    grp = defaultdict(list)
    for l in lines:
        grp[(l["supplier_gstin"], l["inv_norm"], l["match_2b_id"])].append(l)
    factor = {}
    for k, ls in grp.items():
        if ls[0]["match_status"] == "Value mismatch" and ls[0]["match_2b_id"]:
            b2 = db.q("SELECT igst+cgst+sgst t FROM gst_2b WHERE matched_book_id=? AND claim_id=?",
                      (ls[0]["id"], cid))
            ptax = sum(x["t"] for x in b2)
            btax = sum(_tax(x) for x in ls)
            f = min(1.0, ptax / btax) if btax > 0 else 0.0
            for x in ls:
                factor[x["id"]] = max(0.0, f)
    out = []
    for l in lines:
        tax = _tax(l)
        bucket, reason, f = None, "", 1.0
        if l["tax_period"] not in months:
            bucket, reason = "Excluded", "Outside claim period"
        elif l["blocked_17_5"]:
            bucket, reason = "Excluded", "Blocked u/s 17(5)"
        elif l["is_trading"]:
            bucket, reason = "Trading", "Trading purchase - no IDS refund (Circular 135/05/2020)"
        elif _is_reduction(l):
            # purchase return / supplier credit note: always reduces the ITC of its category,
            # whether or not the supplier's credit note is seen in GSTR-2B
            bucket = {"Inputs": "Inputs", "Input Services": "Input Services"}.get(l["category"], "Capital Goods")
            if bucket == "Input Services" and version == "V2026" and (l["itc_availed_date"] or "") >= law.INPUT_SERVICE_CUTOFF:
                bucket = "Eligible Input Services"
            reason = "Credit note / purchase return - reduces ITC"
        elif l["inward_type"] == "Regular" and l["match_status"] in ("Not in GSTR-2B", None):
            bucket, reason = "Excluded", "Not reflected in GSTR-2B (S.16(2)(aa), Circular 135/05/2020)"
        elif l["match_status"] == "In 2B - ITC not available":
            bucket, reason = "Excluded", "GSTR-2B shows ITC not available"
        elif l["inward_type"] == "Import of Goods" and l["match_status"] == "Not in GSTR-2B":
            bucket, reason = "Excluded", "Bill of entry not in GSTR-2B"
        else:
            if l["match_status"] == "Value mismatch":
                f = factor.get(l["id"], 1.0)
                reason = "Restricted to GSTR-2B amount" if f < 1 else ""
            cat = l["category"]
            if cat == "Inputs":
                bucket = "Inputs"
            elif cat == "Input Services":
                if version == "V2026" and (l["itc_availed_date"] or "") >= law.INPUT_SERVICE_CUTOFF:
                    bucket = "Eligible Input Services"
                else:
                    bucket = "Input Services"
                    reason = reason or ("Input services availed before 01.11.2026" if version == "V2026"
                                        else "Input services not part of Net ITC under this formula")
            else:
                bucket = "Capital Goods"
                reason = "Capital goods - handled through attributable ITC (from 01.04.2027)"
        out.append(dict(l, bucket=bucket, reason=reason, factor=f,
                        e_igst=r2((l["igst"] or 0) * f), e_cgst=r2((l["cgst"] or 0) * f),
                        e_sgst=r2((l["sgst"] or 0) * f), e_tax=r2(tax * f), tax=r2(tax)))
    return out


def cg_attributable(claim):
    """ITC on capital goods attributable to the relevant period (Rule 89(4)(B)/(G), w.e.f. 01.04.2027)."""
    months = law.months_between(claim["period_from"], claim["period_to"])
    if months[-1] < law.CAPITAL_GOODS_CUTOFF[:7]:
        return 0.0, []
    rows = db.q("SELECT bp.supplier_gstin, bp.inv_norm, bp.inv_no, bp.itc_availed_date, "
                "SUM(bp.igst+bp.cgst+bp.sgst) itc FROM book_purchases bp JOIN claims c ON c.id=bp.claim_id "
                "WHERE c.client_id=? AND bp.category='Capital Goods' AND bp.blocked_17_5=0 AND bp.itc_availed_date>=? "
                "GROUP BY bp.supplier_gstin, bp.inv_norm", (claim["client_id"], law.CAPITAL_GOODS_CUTOFF))
    total, detail = 0.0, []
    for r in rows:
        start = r["itc_availed_date"][:7]
        window = law.months_between(start, _add_months(start, 59))
        n = len([m for m in months if m in window])
        if n:
            amt = r["itc"] * n / 60.0
            total += amt
            detail.append({"inv": r["inv_no"], "gstin": r["supplier_gstin"], "itc": r2(r["itc"]), "months": n,
                           "attributable": r2(amt)})
    return r2(total), detail


def _add_months(p, n):
    y, m = map(int, p.split("-"))
    m += n
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    return f"{y:04d}-{m:02d}"


def _f(v, default=0.0):
    try:
        return float(v) if v not in (None, "") else default
    except (TypeError, ValueError):
        return default


def trading_adjustment(claim, opts, method, tinv, tax_inv, trading_out_identified):
    """Turnover corresponding to trading purchases, to be excluded from turnover of inverted rated supply.

    gross_up  : deemed trading turnover = cost of traded goods sold grossed up for gross profit
                (cost of goods sold = opening stock + trading purchases - closing stock)
                GP basis 'sales' -> turnover = cost / (1 - GP%);  basis 'cost' -> turnover = cost x (1 + mark-up%)
    identified: trading sales identified in the sales register (no gross-up needed)
    """
    months = law.months_between(claim["period_from"], claim["period_to"])
    ph = ",".join("?" for _ in months)
    tp = db.q1(f"SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) itc, COUNT(*) n FROM book_purchases "
               f"WHERE claim_id=? AND is_trading>0 AND blocked_17_5=0 AND tax_period IN ({ph})", (claim["id"], *months))
    purchases = tp["tx"] or 0.0
    opening, closing = _f(opts.get("trading_opening_stock")), _f(opts.get("trading_closing_stock"))
    basis = opts.get("gp_basis") or "sales"
    gp = _f(opts.get("gp_percent"), None)
    gp_amt, gp_sales = _f(opts.get("gp_amount")), _f(opts.get("gp_sales"))
    gp_source = "Declared by applicant"
    if gp is None:
        if gp_amt and gp_sales:
            gp = gp_amt / gp_sales * 100.0 if basis == "sales" else gp_amt / max(gp_sales - gp_amt, 1e-9) * 100.0
            gp_source = "Computed from books (GP / sales)" if basis == "sales" else "Computed from books (GP / cost of sales)"
        else:
            gp_source = "Not declared"
    declared = gp
    # Department adopts a minimum gross profit ratio (default 10%) or the higher ratio declared by the applicant
    min_gp = _f(db.get_setting("trading_min_gp", "10"), 10.0)
    if gp is None or gp < min_gp:
        gp = min_gp
        gp_source = (f"Minimum {min_gp:g}% adopted by the department"
                     + (f" (declared {declared:.2f}% is lower)" if declared is not None else " (no GP declared)"))
    else:
        gp_source += f" - higher than the minimum {min_gp:g}%"
    cost_sold = max(0.0, opening + purchases - closing)
    if basis == "sales":
        deemed = cost_sold / (1 - gp / 100.0) if gp < 100 else cost_sold
    else:
        deemed = cost_sold * (1 + gp / 100.0)
    reduce_att = bool(opts.get("trading_reduce_att"))
    rate_override = _f(opts.get("trading_tax_rate"), None)
    out = {"method": method, "purchases": r2(purchases), "purchase_itc": r2(tp["itc"]), "lines": tp["n"],
           "opening_stock": r2(opening), "closing_stock": r2(closing), "cost_sold": r2(cost_sold),
           "gp_basis": basis, "gp_percent": round(gp, 4), "gp_declared": None if declared is None else round(declared, 4),
           "gp_minimum": min_gp, "gp_source": gp_source, "deemed_turnover": r2(deemed),
           "identified_sales": r2(trading_out_identified), "reduce_att": reduce_att}
    if method == "identified":
        out.update(deduct_inverted=0.0, deduct_tax=0.0,
                   deduct_att=r2(trading_out_identified) if reduce_att else 0.0, rate_used=None,
                   note="Trading sales identified in the sales register are excluded from inverted turnover.")
        return out
    ded = min(deemed, tinv)
    if rate_override is not None:
        rate, rate_note = rate_override, f"{rate_override}% (entered)"
    else:
        rate = (tax_inv / tinv * 100.0) if tinv else 0.0
        rate_note = f"{rate:.4f}% (average rate of inverted rated supply)"
    out.update(deduct_inverted=r2(ded), deduct_tax=r2(ded * rate / 100.0), deduct_att=r2(deemed) if reduce_att else 0.0,
               rate_used=rate_note, capped=deemed > tinv,
               note="Deemed trading turnover (trading purchases adjusted for gross profit) excluded from turnover of "
                    "inverted rated supply" + (" and adjusted total turnover" if reduce_att else "") + ".")
    return out


def formula(version, tinv, tax_inv, att, net_itc, itc_in_serv):
    if att <= 0 or net_itc <= 0:
        return 0.0, 0.0, 0.0
    part1 = tinv * net_itc / att
    if version == "V2022":
        part2 = tax_inv * (net_itc / itc_in_serv) if itc_in_serv > 0 else 0.0
    else:
        part2 = tax_inv
    return r2(part1), r2(part2), r2(part1 - part2)


def debit_heads(amount, avail):
    """Rule 89(3) (as substituted by N/N 05/2026-CT): IGST first, then CGST and
    SGST equally; shortfall in one head met from the other."""
    amount = round(amount)
    ig = min(amount, int(avail["igst"]))
    rem = amount - ig
    half = rem / 2.0
    cg = min(avail["cgst"], half)
    sg = min(avail["sgst"], half)
    short = rem - cg - sg
    if short > 0:
        extra_c = min(avail["cgst"] - cg, short)
        cg += extra_c
        short -= extra_c
        extra_s = min(avail["sgst"] - sg, short)
        sg += extra_s
    cg, sg = round(cg), round(sg)
    # fix rounding so heads add up
    diff = amount - (ig + cg + sg)
    if diff and avail["cgst"] >= cg + diff:
        cg += diff
    return {"igst": int(ig), "cgst": int(cg), "sgst": int(sg)}


def compute(claim, client):
    cid = claim["id"]
    opts = json.loads(claim.get("options_json") or "{}")
    months = law.months_between(claim["period_from"], claim["period_to"])
    ph = ",".join("?" for _ in months)
    auto_version = law.formula_for_filing_date(claim.get("filing_date"))
    version = claim.get("formula_version") or auto_version

    # ---------- outward
    sales = db.q(f"SELECT * FROM book_sales WHERE claim_id=? AND tax_period IN ({ph})", (cid, *months))
    by_type = defaultdict(float)
    for s in sales:
        by_type[s["supply_type"]] += s["txval"] or 0
    total_turnover = sum(by_type.values())
    exempt = by_type["Nil Rated"] + by_type["Exempt"] + by_type["Non-GST"]
    less_4a4b = float(opts.get("turnover_4a4b", 0) or 0)
    att = by_type["Taxable"] + by_type["Zero Rated"] - less_4a4b

    groups, max_in = outward_groups(claim)
    inv_set = {(g["hsn"], g["rate"]) for g in groups if g["is_inverted"] and not g["restricted"]}
    tr_method = opts.get("trading_method") or "gross_up"
    tinv = tax_inv = trading_out = restricted_out = 0.0
    inv_detail = defaultdict(lambda: {"txval": 0.0, "tax": 0.0})
    for s in sales:
        if s["supply_type"] != "Taxable":
            continue
        if s["is_trading"] and tr_method == "identified":
            trading_out += s["txval"] or 0
            continue
        if (s["hsn"], s["rate"]) in inv_set:
            tinv += s["txval"] or 0
            tax_inv += _tax(s)
            inv_detail[s["rate"]]["txval"] += s["txval"] or 0
            inv_detail[s["rate"]]["tax"] += _tax(s)
        elif any(g["restricted"] and g["hsn"] == s["hsn"] and g["rate"] == s["rate"] for g in groups):
            restricted_out += s["txval"] or 0

    # ---------- Trading goods: turnover corresponding to trading purchases (Circular 135/05/2020-GST)
    trade = trading_adjustment(claim, opts, tr_method, tinv, tax_inv, trading_out)
    tinv_before, tax_before, att_before = tinv, tax_inv, att
    tinv = max(0.0, tinv - trade["deduct_inverted"])
    tax_inv = max(0.0, tax_inv - trade["deduct_tax"])
    att = max(0.0, att - trade["deduct_att"])

    # ---------- ITC reversals reported in GSTR-3B Table 4(B) for the period
    from .annexb import reversals as _rev
    rv1, rv2 = _rev(claim)
    rev_total = sum(rv1[h] + rv2[h] for h in HEADS)
    rev_override = opts.get("reversal_net_itc")
    rev_override = None if rev_override in (None, "") else float(rev_override)

    # ---------- ITC
    results = {}
    for ver in ("V2018", "V2022", "V2026"):
        lines = classify_purchases(claim, ver)
        b = defaultdict(lambda: {"igst": 0.0, "cgst": 0.0, "sgst": 0.0, "tax": 0.0, "n": 0})
        for l in lines:
            k = l["bucket"]
            b[k]["igst"] += l["e_igst"]
            b[k]["cgst"] += l["e_cgst"]
            b[k]["sgst"] += l["e_sgst"]
            b[k]["tax"] += l["e_tax"] if k not in ("Excluded",) else l["tax"]
            b[k]["n"] += 1
        cg_amt, cg_detail = cg_attributable(claim) if ver == "V2026" else (0.0, [])
        net_gross = b["Inputs"]["tax"] + (b["Eligible Input Services"]["tax"] if ver == "V2026" else 0) + cg_amt
        itc_in_serv_gross = b["Inputs"]["tax"] + b["Input Services"]["tax"] + b["Eligible Input Services"]["tax"]
        total_elig = sum(b[k]["tax"] for k in ("Inputs", "Input Services", "Eligible Input Services",
                                               "Capital Goods", "Trading"))
        if rev_override is not None:
            rev_net = rev_override
            rev_is = rev_override * (itc_in_serv_gross / net_gross) if net_gross else 0.0
            rev_basis = "Entered by user"
        else:
            rev_net = rev_total * net_gross / total_elig if total_elig else 0.0
            rev_is = rev_total * itc_in_serv_gross / total_elig if total_elig else 0.0
            rev_basis = "GSTR-3B 4(B) reversals apportioned in the ratio of eligible ITC"
        net_itc = max(0.0, net_gross - rev_net)
        itc_in_serv = max(0.0, itc_in_serv_gross - rev_is)
        p1, p2, mx = formula(ver, tinv, tax_inv, att, net_itc, itc_in_serv)
        results[ver] = {"net_itc": r2(net_itc), "net_itc_gross": r2(net_gross), "reversal_net_itc": r2(rev_net),
                        "reversal_basis": rev_basis, "itc_inputs_services": r2(itc_in_serv), "part1": p1, "part2": p2,
                        "max_refund": r2(max(mx, 0)), "raw": mx, "cg_attributable": cg_amt, "cg_detail": cg_detail,
                        "buckets": {k: {kk: r2(vv) if kk != "n" else vv for kk, vv in v.items()} for k, v in b.items()}}
        if ver == version:
            sel_lines = lines

    sel = results[version]
    # ---------- electronic credit ledger
    ecl = {r["kind"]: r for r in db.q("SELECT * FROM ecl_balances WHERE claim_id=?", (cid,))}
    end = ecl.get("end_period") or {"igst": 0, "cgst": 0, "sgst": 0}
    filing = ecl.get("at_filing") or {"igst": 0, "cgst": 0, "sgst": 0}
    avail = {h: max(0.0, min(end[h] or 0, filing[h] or 0)) for h in HEADS}
    end_total = sum((end[h] or 0) for h in HEADS)
    filing_total = sum((filing[h] or 0) for h in HEADS)
    eligible = max(0.0, min(sel["max_refund"], end_total, filing_total, sum(avail.values())))
    eligible = float(int(eligible))       # refund claimed in whole rupees (rounded down)
    split = debit_heads(eligible, avail)
    limiting = "Maximum refund as per formula (rounded down to rupee)"
    if min(end_total, filing_total, sum(avail.values())) < sel["max_refund"]:
        limiting = "Balance in electronic credit ledger"
    warnings = []
    if 0 < eligible < law.MIN_REFUND:
        warnings.append("Refund amount is below Rs 1,000 - no refund under Section 54(14).")
    if version != auto_version:
        warnings.append(f"Formula {version} applied instead of {auto_version} (applicable to filing date): "
                        f"{claim.get('formula_override_reason') or 'reason not recorded'}.")
    if version == "V2026" and months[0] < law.INPUT_SERVICE_CUTOFF[:7]:
        warnings.append("Claim period includes months before Nov-2026. Input services availed before 01.11.2026 are "
                        "excluded from Net ITC under the substituted Rule 89(5); compare with the July-2022 formula "
                        "result and take a considered view on the transition.")
    if not ecl:
        warnings.append("Electronic credit ledger balances have not been entered.")
    if trade["method"] == "gross_up" and trade["purchases"] and trade["gp_source"].startswith("Minimum"):
        warnings.append(f"Gross profit on traded goods taken at the minimum {trade['gp_minimum']:g}% adopted by the "
                        f"department ({trade['gp_source']}).")
    if trade["method"] == "gross_up" and trade.get("capped"):
        warnings.append("Deemed trading turnover exceeds the turnover of inverted rated supply; deduction limited to it.")
    if trade["method"] == "gross_up" and trade["identified_sales"] == 0:
        tr_non_inv = sum((s["txval"] or 0) for s in sales if s["is_trading"] and s["supply_type"] == "Taxable"
                         and (s["hsn"], s["rate"]) not in inv_set)
        if tr_non_inv:
            warnings.append(f"Sales marked as trading of Rs {tr_non_inv:,.2f} are at rates not treated as inverted; "
                            f"deducting deemed trading turnover from inverted turnover may then be excessive - review.")
    if tinv <= 0:
        warnings.append("No inverted rated supply identified. Review the outward HSN/rate table.")
    tl = law.time_limit(claim["period_from"], claim["period_to"], client.get("filing_freq") or "Monthly")

    month_rows = []
    for p in months:
        ms = [s for s in sales if s["tax_period"] == p]
        mt = sum((s["txval"] or 0) for s in ms if s["supply_type"] == "Taxable" and not s["is_trading"]
                 and (s["hsn"], s["rate"]) in inv_set)
        mx = sum(_tax(s) for s in ms if s["supply_type"] == "Taxable" and not s["is_trading"]
                 and (s["hsn"], s["rate"]) in inv_set)
        ma = sum((s["txval"] or 0) for s in ms if s["supply_type"] in ("Taxable", "Zero Rated"))
        mn = sum(l["e_tax"] for l in sel_lines if l["tax_period"] == p and
                 (l["bucket"] == "Inputs" or (version == "V2026" and l["bucket"] == "Eligible Input Services")))
        month_rows.append({"period": p, "inverted_turnover": r2(mt), "tax_payable": r2(mx), "att": r2(ma),
                           "net_itc": r2(mn)})

    trading = [l for l in sel_lines if l["bucket"] == "Trading"]
    result = {
        "claim_id": cid, "version": version, "auto_version": auto_version,
        "formula_label": law.FORMULAS[version]["label"], "formula_text": law.FORMULAS[version]["text"],
        "computed_at": db.now(),
        "turnover": {"taxable": r2(by_type["Taxable"]), "zero_rated": r2(by_type["Zero Rated"]),
                     "nil": r2(by_type["Nil Rated"]), "exempt": r2(by_type["Exempt"]),
                     "non_gst": r2(by_type["Non-GST"]), "total": r2(total_turnover), "exempt_total": r2(exempt),
                     "less_4a4b": r2(less_4a4b), "att": r2(att), "inverted": r2(tinv), "tax_inverted": r2(tax_inv),
                     "trading_outward": r2(trading_out), "restricted_outward": r2(restricted_out),
                     "inverted_before_trading": r2(tinv_before), "tax_before_trading": r2(tax_before),
                     "att_before_trading": r2(att_before),
                     "inverted_by_rate": {str(k): {"txval": r2(v["txval"]), "tax": r2(v["tax"])} for k, v in inv_detail.items()}},
        "max_input_rate": max_in,
        "versions": results,
        "selected": sel,
        "ecl": {"end_period": {h: r2(end[h]) for h in HEADS}, "at_filing": {h: r2(filing[h]) for h in HEADS},
                "available": {h: r2(v) for h, v in avail.items()}, "end_total": r2(end_total),
                "filing_total": r2(filing_total)},
        "refund": {"amount": eligible, "heads": split, "limiting_factor": limiting,
                   "provisional_90": float(int(eligible * 0.9))},
        "trading_purchases": {"count": len(trading), "txval": r2(sum(l["txval"] or 0 for l in trading)),
                              "itc": r2(sum(l["tax"] for l in trading))},
        "months": month_rows, "time_limit": tl, "warnings": warnings, "trading_adjustment": trade,
        "reversals_3b": {"rule_38_42_43_17_5": rv1, "others": rv2, "total": r2(rev_total)},
    }
    return result


def save(claim, result, user, final=False):
    if final:
        db.x("UPDATE calculations SET is_final=0 WHERE claim_id=?", (claim["id"],))
    cid = db.insert("calculations", dict(claim_id=claim["id"], formula_version=result["version"],
                                         result_json=json.dumps(result), is_final=1 if final else 0,
                                         created_by=user, created_at=db.now()))
    return cid


def latest(cid, final_only=False):
    r = db.q1("SELECT * FROM calculations WHERE claim_id=? %s ORDER BY id DESC LIMIT 1"
              % ("AND is_final=1" if final_only else ""), (cid,))
    if not r:
        return None
    res = json.loads(r["result_json"])
    res["_calc_id"] = r["id"]
    res["_is_final"] = r["is_final"]
    res["_by"] = r["created_by"]
    return res
