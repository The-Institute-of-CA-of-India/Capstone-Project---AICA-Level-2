"""Import of portal files and book registers into the claim database."""
from . import db, law, parsers


class ImportError_(Exception):
    pass


def import_portal(claim, client, path, user, expect_type=None, preparsed=None):
    res = preparsed or parsers.parse_portal_file(path)
    t = res["type"]
    if expect_type and t != expect_type:
        raise ImportError_(f"This file is {t}, but it was uploaded as {expect_type}.")
    gstin = parsers.norm_gstin(res.get("gstin"))
    if gstin and gstin != client["gstin"]:
        raise ImportError_(f"GSTIN in file ({gstin}) does not match client GSTIN ({client['gstin']}).")
    period = res.get("period")
    months = law.months_between(claim["period_from"], claim["period_to"])
    if not period:
        raise ImportError_("Return period not found in the file.")
    if period not in months:
        raise ImportError_(f"File is for {law.period_label(period)}, which is outside the claim period.")
    cid = claim["id"]
    from . import storage
    summary = {}
    if t in ("GSTR1", "GSTR1A"):
        if t == "GSTR1":
            db.x("DELETE FROM gst_outward WHERE claim_id=? AND tax_period=? AND section NOT LIKE '1A:%'", (cid, period))
            db.x("DELETE FROM gst_hsn WHERE claim_id=? AND tax_period=?", (cid, period))
        else:
            db.x("DELETE FROM gst_outward WHERE claim_id=? AND tax_period=? AND section LIKE '1A:%'", (cid, period))
        db.xmany("INSERT INTO gst_outward(claim_id,tax_period,section,ctin,inv_no,inv_norm,inv_date,inv_value,pos,rate,"
                 "txval,igst,cgst,sgst,cess,orig_inv,orig_ctin,orig_period) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 [(cid, period, r["section"], r["ctin"], r["inv_no"], r["inv_norm"], r["inv_date"], r["inv_value"],
                   r["pos"], r["rate"], r["txval"], r["igst"], r["cgst"], r["sgst"], r["cess"],
                   r.get("orig_inv", ""), r.get("orig_ctin", ""), r.get("orig_period", "")) for r in res["rows"]])
        if t == "GSTR1":
            db.xmany("INSERT INTO gst_hsn(claim_id,tax_period,table_type,hsn,description,uqc,qty,rate,txval,igst,cgst,sgst,cess)"
                     " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     [(cid, period, h["table_type"], h["hsn"], h["description"], h["uqc"], h["qty"], h["rate"], h["txval"],
                       h["igst"], h["cgst"], h["sgst"], h["cess"]) for h in res["hsn"]])
        secs = {}
        for r in res["rows"]:
            k = r["section"].replace("1A:", "")
            k = "Credit / debit notes" if k.startswith("CDN") and not k.endswith("A") else (
                "Amendments" if k.endswith("A") or k.startswith("EXPA") else "Invoices")
            secs[k] = round(secs.get(k, 0) + r["txval"], 2)
        summary = {"documents": len(res["rows"]), "hsn_lines": len(res["hsn"]) if t == "GSTR1" else 0,
                   "taxable": round(sum(r["txval"] for r in res["rows"]), 2), "by_kind": secs}
        if t == "GSTR1":
            summary["nil"] = res["nil"]
            opts = _opts(claim)
            opts.setdefault("gstr1_nil", {})[period] = res["nil"]
            db.update("claims", cid, {"options_json": _dump(opts)})
        apply_amendments(cid)
    elif t == "GSTR2B":
        db.x("DELETE FROM gst_2b WHERE claim_id=? AND tax_period=?", (cid, period))
        db.x("DELETE FROM portal_files WHERE claim_id=? AND return_type='GSTR2B_PDF' AND tax_period=?", (cid, period))
        db.xmany("INSERT INTO gst_2b(claim_id,tax_period,section,doc_type,ctin,trade_name,inv_no,inv_norm,inv_date,"
                 "inv_value,rate,txval,igst,cgst,sgst,cess,itc_avl,rev,port_code,hsn) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 [(cid, period, r["section"], r["doc_type"], r["ctin"], r["trade_name"], r["inv_no"], r["inv_norm"],
                   r["inv_date"], r["inv_value"], r["rate"], r["txval"], r["igst"], r["cgst"], r["sgst"], r["cess"],
                   r["itc_avl"], r["rev"], r.get("port_code", ""), r.get("hsn", "")) for r in res["rows"]])
        summary = {"documents": len(res["rows"]),
                   "itc": round(sum(r["igst"] + r["cgst"] + r["sgst"] for r in res["rows"]), 2)}
    else:
        save_3b(cid, period, res["row"], "PDF" if str(path).lower().endswith(".pdf") else "JSON")
        summary = {"outward_taxable": res["row"]["osup_txval"],
                   "itc_availed": round(res["row"]["itc_igst"] + res["row"]["itc_cgst"] + res["row"]["itc_sgst"], 2)}
    db.x("DELETE FROM portal_files WHERE claim_id=? AND return_type=? AND tax_period=?", (cid, t, period))
    db.insert("portal_files", dict(claim_id=cid, return_type=t, tax_period=period, file_path=storage.rel(path),
                                   summary_json=_dump(summary), imported_by=user, imported_at=db.now()))
    db.audit(user, f"Imported {t}", cid, f"{law.period_label(period)} {summary}")
    return t, period, summary


RETURN_TYPES = ("GSTR1", "GSTR1A", "GSTR2B", "GSTR3B")


def import_any(claim, client, path, user, hint_type=None, hint_period=None):
    """Import a portal return in any supported format: JSON / ZIP (full), Excel (GSTR-2B details, GSTR-1 workbook),
    PDF (GSTR-3B tables read; GSTR-1 total liability; GSTR-2B kept as document).
    hint_type / hint_period are used when the file itself does not show them.
    Returns (type, period, summary, notes)."""
    from pathlib import Path
    from . import parsers_ext as px
    ext = Path(path).suffix.lower()
    notes = []
    if ext in (".json", ".zip"):
        res = parsers.parse_portal_file(path, hint_type)
    elif ext in (".xlsx", ".xlsm"):
        sheets = px._wb_rows(path)
        t = hint_type or px.detect_excel(sheets)
        if t == "GSTR2B":
            res = px.parse_gstr2b_excel(path)
        elif t == "GSTR1":
            res = px.parse_gstr1_excel(path, client["gstin"])
            notes.append("GSTR-1 tax amounts computed from rate x taxable value as in the Excel workbook.")
        else:
            raise ImportError_("Could not tell whether this Excel file is GSTR-1 or GSTR-2B - choose the return type.")
    elif ext == ".xls":
        raise ImportError_("Old .xls format: open it in Excel and 'Save As' .xlsx, then upload.")
    elif ext == ".pdf":
        text = px.pdf_text(path)
        if len(text.strip()) < 40:
            raise ImportError_("This PDF has no readable text (scanned image). Upload the JSON / Excel, or enter "
                               "GSTR-3B figures in the form.")
        t = hint_type or px.detect_pdf(text)
        if t == "GSTR3B":
            res = px.parse_gstr3b_pdf(text)
            notes.append("GSTR-3B figures read from the PDF - please check them in the GSTR-3B form below.")
            if res.get("partial"):
                notes.append("Some tables could not be read from the PDF - complete them in the form.")
        elif t == "GSTR1":
            res = px.parse_gstr1_pdf(text)
        elif t == "GSTR2B":
            res = px.parse_gstr2b_pdf(text)
        else:
            raise ImportError_("Could not tell which return this PDF is - choose the return type.")
    else:
        raise ImportError_(f"Unsupported file type '{ext}'. Use JSON, ZIP, Excel (.xlsx) or PDF.")
    if not res.get("period") and hint_period:
        res["period"] = hint_period
    elif hint_period and res.get("period") and res["period"] != hint_period:
        notes.append(f"Month in file ({res['period']}) used instead of the month selected ({hint_period}).")
    if not res.get("period"):
        raise ImportError_("The return period could not be read from the file - select the month and upload again.")
    t = res["type"]
    if t in RETURN_TYPES:
        if t == "GSTR3B":
            res.pop("partial", None)
        tt, p, s = _store(claim, client, path, user, res)
        return tt, p, s, notes
    # PDF summary-only documents
    return _store_pdf_summary(claim, client, path, user, res, notes)


def _check(claim, client, res):
    gstin = parsers.norm_gstin(res.get("gstin"))
    if gstin and gstin != client["gstin"]:
        raise ImportError_(f"GSTIN in file ({gstin}) does not match client GSTIN ({client['gstin']}).")
    months = law.months_between(claim["period_from"], claim["period_to"])
    if res["period"] not in months:
        raise ImportError_(f"File is for {law.period_label(res['period'])}, which is outside the claim period.")


def _store(claim, client, path, user, res):
    _check(claim, client, res)
    return import_portal(claim, client, path, user, preparsed=res)


def _store_pdf_summary(claim, client, path, user, res, notes):
    from . import storage
    _check(claim, client, res)
    cid, period = claim["id"], res["period"]
    if res["type"] == "GSTR1_PDF":
        tot = res.get("total")
        summary = {"source": "PDF"}
        if tot:
            have_detail = db.q1("SELECT COUNT(*) n FROM gst_outward WHERE claim_id=? AND tax_period=? AND section<>'PDF-SUMMARY'",
                                (cid, period))["n"]
            if have_detail:
                notes.append("Invoice-level GSTR-1 already imported for this month - the PDF was stored as a document only.")
            else:
                db.x("DELETE FROM gst_outward WHERE claim_id=? AND tax_period=?", (cid, period))
                db.insert("gst_outward", dict(claim_id=cid, tax_period=period, section="PDF-SUMMARY", ctin="", inv_no="",
                                              inv_norm="", inv_date="", inv_value=0, pos="", rate=0, txval=tot[0],
                                              igst=tot[1], cgst=tot[2], sgst=tot[3], cess=tot[4]))
                summary.update(taxable=tot[0], tax=round(tot[1] + tot[2] + tot[3], 2))
                notes.append("Only the total liability is available in a GSTR-1 PDF: month totals are reconciled, but "
                             "invoice-wise and rate-wise checks need the GSTR-1 JSON or Excel.")
            rtype = "GSTR1"
        else:
            rtype = "GSTR1_PDF"
            notes.append("Totals could not be read from this GSTR-1 PDF; it was stored as a document. Upload the JSON / Excel.")
    else:
        rtype = "GSTR2B_PDF"
        summary = {"source": "PDF"}
        notes.append("GSTR-2B PDF contains only a summary: it was stored as a document. Invoice matching needs the "
                     "GSTR-2B JSON or Excel (Download GSTR-2B details).")
    db.x("DELETE FROM portal_files WHERE claim_id=? AND return_type=? AND tax_period=?", (cid, rtype, period))
    db.insert("portal_files", dict(claim_id=cid, return_type=rtype, tax_period=period, file_path=storage.rel(path),
                                   summary_json=_dump(summary), imported_by=user, imported_at=db.now()))
    db.audit(user, f"Imported {rtype} (PDF)", cid, law.period_label(period))
    return rtype, period, summary, notes


def save_3b(cid, period, row, source):
    db.x("DELETE FROM gst_3b WHERE claim_id=? AND tax_period=?", (cid, period))
    data = dict(claim_id=cid, tax_period=period, source=source)
    data.update(row)
    db.insert("gst_3b", data)


REGISTER_KINDS = {
    "Sales": ("Sales", None, "Sales register (invoices)"),
    "Sales-CN": ("Sales", "CN", "Credit notes issued / sales returns"),
    "Sales-DN": ("Sales", "DN", "Debit notes issued to customers"),
    "Purchase": ("Purchase", None, "Purchase register (invoices)"),
    "Purchase-CN": ("Purchase", "CN", "Purchase returns / supplier credit notes"),
    "Purchase-DN": ("Purchase", "DN", "Supplier debit notes"),
    "Expense": ("Expense", None, "Expense register"),
}


def import_register(claim, path, register, user, replace=True):
    """register: a key of REGISTER_KINDS. Uploading again replaces only what came from the same kind of register,
    so invoices and credit / debit notes can be imported one after the other."""
    base, note, label = REGISTER_KINDS[register]
    rows, warnings = parsers.parse_register(path, base, note)
    cid = claim["id"]
    months = law.months_between(claim["period_from"], claim["period_to"])
    outside = [r for r in rows if r["tax_period"] and r["tax_period"] not in months]
    if outside:
        warnings.append(f"{len(outside)} row(s) dated outside the claim period were imported but will be "
                        f"ignored in the computation.")
    notes_in = sum(1 for r in rows if r["doc_type"] != "Invoice")
    if notes_in and not note:
        warnings.append(f"{notes_in} credit / debit note line(s) found in this register and taken with their sign.")
    if base == "Sales":
        if replace:
            db.x("DELETE FROM book_sales WHERE claim_id=? AND COALESCE(src_reg,'Sales')=?", (cid, register))
        db.xmany("INSERT INTO book_sales(claim_id,tax_period,inv_no,inv_norm,inv_date,party_gstin,party_name,hsn,"
                 "description,rate,txval,igst,cgst,sgst,cess,supply_type,doc_type,is_trading,src_row,src_reg,trade_file) "
                 "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 [(cid, r["tax_period"], r["inv_no"], r["inv_norm"], r["inv_date"], r["party_gstin"], r["party_name"],
                   r["hsn"], r["description"], r["rate"], r["txval"], r["igst"], r["cgst"], r["sgst"], r["cess"],
                   r["supply_type"], r["doc_type"], r["is_trading"], r["src_row"], register, r["is_trading"]) for r in rows])
    else:
        if replace:
            db.x("DELETE FROM book_purchases WHERE claim_id=? AND COALESCE(src_reg,register)=?", (cid, register))
        db.xmany("INSERT INTO book_purchases(claim_id,register,tax_period,supplier_gstin,supplier_name,inv_no,inv_norm,"
                 "inv_date,inv_value,hsn,description,rate,txval,igst,cgst,sgst,cess,category,inward_type,doc_type,"
                 "itc_availed_date,blocked_17_5,is_trading,src_row,port_code,src_reg,trade_file,line_key,goods_desc,hsn_src,books_hsn) "
                 "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 [(cid, base, r["tax_period"], r["supplier_gstin"], r["supplier_name"], r["inv_no"], r["inv_norm"],
                   r["inv_date"], r["inv_value"], r["hsn"], r["description"], r["rate"], r["txval"], r["igst"],
                   r["cgst"], r["sgst"], r["cess"], r["category"], r["inward_type"], r["doc_type"],
                   r["itc_availed_date"], r["blocked_17_5"], r["is_trading"], r["src_row"], r.get("port_code", ""), register,
                   r["is_trading"], line_key(dict(r, src_reg=register)), "",
                   "" if _no_hsn(r["hsn"]) else "books", r["hsn"])
                  for r in rows])
    record_book_file(cid, register, path, len(rows), user)
    apply_line_settings(cid)
    db.audit(user, f"Imported {label}", cid, f"{len(rows)} rows")
    return len(rows), warnings


def desc_key(description):
    import re
    return re.sub(r"\s+", " ", str(description or "").strip().lower())[:120]


def item_key(r):
    """What a purchase line is grouped by for the HSN map: its item / ledger text, or its HSN when there is none."""
    k = desc_key(r.get("description") if isinstance(r, dict) else r["description"])
    if k:
        return k
    h = str((r.get("books_hsn") or r.get("hsn")) or "").strip()
    return f"hsn {h}" if h and not _no_hsn(h) else "(no description, no hsn)"


def line_key(r):
    return "|".join([r.get("src_reg") or r.get("register") or "", r.get("supplier_gstin") or "", r.get("inv_norm") or "",
                     f"{round(float(r.get('txval') or 0), 2):.2f}", desc_key(r.get("description"))[:60]])


def _no_hsn(h):
    h = str(h or "").strip().upper()
    return h in ("", "NA", "N/A", "NONE", "0")


def apply_line_settings(cid):
    """Everything that is decided after a register is imported, applied again after every import / refresh:
    1. HSN + goods description from the client's HSN map (by item / ledger description) where the books have no HSN;
    2. credit / debit notes without HSN take the HSN of the invoices at the same rate (so they net in the same group);
    3. the user's line decisions (trading yes / no, category, blocked, HSN, goods description);
    4. the trading flag: user decision > 'Trading = Y' in the file > trading HSN list."""
    claim = db.q1("SELECT * FROM claims WHERE id=?", (cid,))
    if not claim:
        return
    client_id = claim["client_id"]
    # legacy rows: the file flag was kept in is_trading = 1
    db.x("UPDATE book_purchases SET trade_file=CASE WHEN is_trading=1 THEN 1 ELSE 0 END WHERE claim_id=? AND trade_file IS NULL", (cid,))
    db.x("UPDATE book_sales SET trade_file=CASE WHEN is_trading=1 THEN 1 ELSE 0 END WHERE claim_id=? AND trade_file IS NULL", (cid,))
    # 1. HSN map
    hmap = {m["desc_key"]: m for m in db.q("SELECT * FROM hsn_map WHERE client_id=?", (client_id,))}
    ups = []
    db.x("UPDATE book_purchases SET books_hsn=hsn WHERE claim_id=? AND books_hsn IS NULL AND COALESCE(hsn_src,'') "
         "NOT IN ('map', 'inherited', 'user', '2b')", (cid,))
    for r in db.q("SELECT id, hsn, books_hsn, description, hsn_src, goods_desc, line_key, src_reg, register, supplier_gstin, "
                  "inv_norm, txval FROM book_purchases WHERE claim_id=?", (cid,)):
        lk = r["line_key"] or line_key(r)
        m = hmap.get(item_key(r))
        if m:
            hsn, src = (m["hsn"], "map") if m["hsn"] else (r["hsn"], r["hsn_src"] or ("" if _no_hsn(r["hsn"]) else "books"))
            ups.append((hsn, m["goods_desc"] or r["goods_desc"] or "", src, lk, r["id"]))
        else:
            ups.append((r["hsn"], r["goods_desc"] or "", r["hsn_src"] or ("" if _no_hsn(r["hsn"]) else "books"), lk, r["id"]))
    db.xmany("UPDATE book_purchases SET hsn=?, goods_desc=?, hsn_src=?, line_key=? WHERE id=?", ups)
    # 1b. HSN carried by the matched GSTR-2B document (only some downloads have it)
    db.x("UPDATE book_purchases SET hsn=(SELECT g.hsn FROM gst_2b g WHERE g.id=book_purchases.match_2b_id), hsn_src='2b' "
         "WHERE claim_id=? AND (hsn IS NULL OR hsn IN ('', 'NA')) AND match_2b_id IS NOT NULL AND "
         "COALESCE((SELECT g.hsn FROM gst_2b g WHERE g.id=book_purchases.match_2b_id), '') <> ''", (cid,))
    # 2. notes without HSN
    for tbl, party in (("book_sales", "party_gstin"), ("book_purchases", "supplier_gstin")):
        inv = db.q(f"SELECT {party} p, rate, hsn, SUM(ABS(txval)) v FROM {tbl} WHERE claim_id=? AND doc_type='Invoice' "
                   f"AND hsn NOT IN ('', 'NA') GROUP BY {party}, rate, hsn", (cid,))
        by_pr, by_r = {}, {}
        for i in inv:
            if i["v"] > by_pr.get((i["p"], i["rate"]), ("", 0))[1]:
                by_pr[(i["p"], i["rate"])] = (i["hsn"], i["v"])
            tot = by_r.setdefault(i["rate"], {})
            tot[i["hsn"]] = tot.get(i["hsn"], 0) + i["v"]
        ups = []
        for n in db.q(f"SELECT id, {party} p, rate FROM {tbl} WHERE claim_id=? AND doc_type<>'Invoice' AND "
                      f"(hsn IN ('', 'NA') OR hsn_src='inherited')", (cid,)):
            h = by_pr.get((n["p"], n["rate"]), ("", 0))[0] or (max(by_r[n["rate"]].items(), key=lambda x: x[1])[0]
                                                               if by_r.get(n["rate"]) else "")
            if h:
                ups.append((h, "inherited", n["id"]))
        db.xmany(f"UPDATE {tbl} SET hsn=?, hsn_src=? WHERE id=?", ups)
    # 3. user decisions on purchase lines
    ov = {o["line_key"]: o for o in db.q("SELECT * FROM line_overrides WHERE claim_id=? AND tbl='P'", (cid,))}
    if ov:
        ups = []
        for r in db.q("SELECT id, line_key, category, blocked_17_5, hsn, goods_desc FROM book_purchases WHERE claim_id=?", (cid,)):
            o = ov.get(r["line_key"])
            if not o:
                continue
            ups.append((o["trade_override"], o["category"] or r["category"],
                        r["blocked_17_5"] if o["blocked"] is None else o["blocked"],
                        o["hsn"] or r["hsn"], o["goods_desc"] or r["goods_desc"], "user" if o["hsn"] else None, r["id"]))
        db.xmany("UPDATE book_purchases SET trade_override=?, category=?, blocked_17_5=?, hsn=?, goods_desc=?, "
                 "hsn_src=COALESCE(?, hsn_src) WHERE id=?", ups)
    # 4. trading flag: 3 = marked by the user, 1 = 'Trading = Y' in the register file, 2 = trading HSN list
    hs = [r["hsn"] for r in db.q("SELECT hsn FROM trading_hsn WHERE claim_id=?", (cid,))]
    ph = ",".join("?" for _ in hs) or "''"
    db.x(f"UPDATE book_purchases SET is_trading = CASE WHEN trade_override=1 THEN 3 WHEN trade_override=0 THEN 0 "
         f"WHEN trade_file=1 THEN 1 WHEN hsn IN ({ph}) THEN 2 ELSE 0 END WHERE claim_id=?", (*hs, cid))
    db.x(f"UPDATE book_sales SET is_trading = CASE WHEN trade_file=1 THEN 1 WHEN hsn IN ({ph}) THEN 2 ELSE 0 END "
         f"WHERE claim_id=?", (*hs, cid))


apply_trading_hsn = apply_line_settings


def record_book_file(cid, register, path, n, user):
    from . import storage
    try:
        rel = storage.rel(path)
    except ValueError:            # file outside the data folder (tests / tools): nothing to refresh from
        return
    db.x("DELETE FROM book_files WHERE claim_id=? AND src_reg=?", (cid, register))
    db.insert("book_files", dict(claim_id=cid, src_reg=register, file_path=rel, lines=n,
                                 imported_by=user, imported_at=db.now()))


def delete_register(cid, register, user):
    base = REGISTER_KINDS[register][0]
    if base == "Sales":
        db.x("DELETE FROM book_sales WHERE claim_id=? AND COALESCE(src_reg,'Sales')=?", (cid, register))
    else:
        db.x("DELETE FROM book_purchases WHERE claim_id=? AND COALESCE(src_reg,register)=?", (cid, register))
    db.x("DELETE FROM book_files WHERE claim_id=? AND src_reg=?", (cid, register))
    db.audit(user, f"Removed {REGISTER_KINDS[register][2]}", cid, "")


def refresh_all(claim, client, user):
    """Re-import every portal file and register of the claim from the stored copies (e.g. after a program update
    or after correcting the client master). Line decisions and the HSN map are applied again afterwards."""
    from . import storage
    cid = claim["id"]
    done, errors = [], []
    for pf in db.q("SELECT * FROM portal_files WHERE claim_id=? ORDER BY CASE return_type WHEN 'GSTR1' THEN 1 "
                   "WHEN 'GSTR1A' THEN 2 ELSE 3 END, tax_period", (cid,)):
        try:
            path = storage.absolute(pf["file_path"])
            if not path.exists():
                errors.append(f"{pf['return_type']} {law.period_label(pf['tax_period'])}: stored file missing")
                continue
            hint = pf["return_type"] if pf["return_type"] in RETURN_TYPES else None
            import_any(db.q1("SELECT * FROM claims WHERE id=?", (cid,)), client, path, user, hint, pf["tax_period"])
            done.append(f"{pf['return_type']} {law.period_label(pf['tax_period'])}")
        except Exception as e:  # noqa: BLE001
            errors.append(f"{pf['return_type']} {law.period_label(pf['tax_period'])}: {e}")
    for bf in db.q("SELECT * FROM book_files WHERE claim_id=?", (cid,)):
        try:
            path = storage.absolute(bf["file_path"])
            if not path.exists():
                errors.append(f"{REGISTER_KINDS.get(bf['src_reg'], (0, 0, bf['src_reg']))[2]}: stored file missing")
                continue
            n, _w = import_register(db.q1("SELECT * FROM claims WHERE id=?", (cid,)), path, bf["src_reg"], user)
            done.append(f"{REGISTER_KINDS[bf['src_reg']][2]} ({n} lines)")
        except Exception as e:  # noqa: BLE001
            errors.append(f"{bf['src_reg']}: {e}")
    apply_line_settings(cid)
    db.audit(user, "Refreshed imported data", cid, f"{len(done)} re-imported, {len(errors)} error(s)")
    return done, errors


def _opts(claim):
    import json
    try:
        return json.loads(claim.get("options_json") or "{}")
    except ValueError:
        return {}


def _dump(o):
    import json
    return json.dumps(o, default=str)


AMEND = ("B2BA", "B2CLA", "CDNRA", "CDNURA", "B2CSA")


def _is_amend(section):
    s = section.replace("1A:", "")
    return s in AMEND or s.startswith("EXPA")


def apply_amendments(cid):
    """An amendment (B2BA, CDNRA ... in GSTR-1 or GSTR-1A) replaces the original document. When the original is
    in this claim's data, it is reversed in the amendment's month, so that month carries only the difference
    (as GSTR-3B does). Originals outside the claim period cannot be reversed: noted for the reconciliation."""
    db.x("DELETE FROM gst_outward WHERE claim_id=? AND section LIKE '%-REV'", (cid,))
    rows = db.q("SELECT * FROM gst_outward WHERE claim_id=? ORDER BY tax_period, id", (cid,))
    by_doc = {}
    for r in rows:
        by_doc.setdefault((r["ctin"] or "", r["inv_norm"]), []).append(r)
    groups = {}
    for a in rows:
        if _is_amend(a["section"]):
            k = (a["tax_period"], a["section"], a["ctin"] or "", a["inv_norm"], a["orig_inv"] or "", a["orig_period"] or "",
                 a["pos"] if a["section"].endswith("B2CSA") else "", a["rate"] if a["section"].endswith("B2CSA") else 0)
            groups.setdefault(k, []).append(a)
    final, reversed_ids = [], set()
    for k in sorted(groups, key=lambda k: k[0], reverse=True):      # latest amendment first
        grp = groups[k]
        a = grp[0]
        note = ""
        if a["section"].endswith("B2CSA"):
            orig = [r for r in rows if r["section"].replace("1A:", "") == "B2CS" and r["tax_period"] == a["orig_period"]
                    and r["pos"] == a["pos"] and r["rate"] == a["rate"]]
            if not orig:
                note = f"original B2CS of {a['orig_period'] or '?'} not in this claim"
        else:
            key = (a["orig_ctin"] or a["ctin"] or "", parsers.norm_inv(a["orig_inv"]))
            ids = {x["id"] for x in grp}
            cands = [r for r in by_doc.get(key, []) if r["id"] not in ids and (r["tax_period"], r["id"]) < (a["tax_period"], a["id"])]
            if cands:
                last = max(cands, key=lambda r: (r["tax_period"], r["id"]))
                orig = [r for r in cands if r["tax_period"] == last["tax_period"] and r["section"] == last["section"]]
            else:
                orig, note = [], f"original document {a['orig_inv']} not in this claim's GSTR-1 data"
        for o in orig:
            if o["id"] in reversed_ids:
                continue
            reversed_ids.add(o["id"])
            final.append((cid, a["tax_period"], a["section"] + "-REV", o["ctin"], o["inv_no"], o["inv_norm"], o["inv_date"],
                          -(o["inv_value"] or 0), o["pos"], o["rate"], -o["txval"], -o["igst"], -o["cgst"], -o["sgst"],
                          -o["cess"], o["inv_no"], o["ctin"], o["tax_period"], f"reverses {o['section']} {o['tax_period']}"))
        for x in grp:
            db.x("UPDATE gst_outward SET amend_note=? WHERE id=?", (note, x["id"]))
    db.xmany("INSERT INTO gst_outward(claim_id,tax_period,section,ctin,inv_no,inv_norm,inv_date,inv_value,pos,rate,"
             "txval,igst,cgst,sgst,cess,orig_inv,orig_ctin,orig_period,amend_note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
             final)
