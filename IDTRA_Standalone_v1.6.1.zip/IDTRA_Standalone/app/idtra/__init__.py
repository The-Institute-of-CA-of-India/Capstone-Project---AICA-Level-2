"""Inverted Tax Duty Refund Application (IDTRA).

Computes refund of unutilised ITC on account of inverted duty structure
under Section 54(3)(ii) of the CGST Act, 2017 read with Rule 89(5) of the
CGST Rules, 2017.
"""
APP_NAME = "Inverted Tax Duty Refund Application"
APP_SHORT = "IDTRA"
APP_VERSION = "1.6.1"
LAW_UPDATED_UPTO = "Notification 05/2026-Central Tax dated 26.10.2026"
