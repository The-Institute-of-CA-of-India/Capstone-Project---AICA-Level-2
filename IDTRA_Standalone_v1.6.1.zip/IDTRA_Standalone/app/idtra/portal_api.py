"""Download jobs for the GST Portal Assistant.

The user clicks 'Download from GST portal' in a claim -> a job with an 8-character code is created.
 - Standalone (this computer only): the assistant is started automatically on this computer.
 - LAN: the user starts 'GST Portal Assistant' on his own PC and types the code.
The assistant reads the job (incl. the saved portal credentials), and uploads every downloaded file,
which is imported into the claim immediately. Codes are single-claim and expire after 3 hours.
"""
import datetime as dt
import json
import os
import secrets
import subprocess
import sys
from pathlib import Path

from flask import abort, flash, jsonify, redirect, request, url_for

from . import db, importer, law, parsers, security, storage
from .web import STATUSES, _claim_ctx, _set_status, _uname, login_required

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
VALID_HOURS = 3
QUARTERS = {4: (1, "Apr - Jun"), 5: (1, "Apr - Jun"), 6: (1, "Apr - Jun"), 7: (2, "Jul - Sep"), 8: (2, "Jul - Sep"),
            9: (2, "Jul - Sep"), 10: (3, "Oct - Dec"), 11: (3, "Oct - Dec"), 12: (3, "Oct - Dec"), 1: (4, "Jan - Mar"),
            2: (4, "Jan - Mar"), 3: (4, "Jan - Mar")}
MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]

SCHEMA = """CREATE TABLE IF NOT EXISTS portal_jobs(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE, code TEXT UNIQUE,
  returns TEXT, status TEXT DEFAULT 'waiting', log TEXT DEFAULT '', created_by TEXT, created_at TEXT, expires_at TEXT,
  imported INTEGER DEFAULT 0)"""


def _month_info(p):
    y, m = map(int, p.split("-"))
    q, rng = QUARTERS[m]
    return {"period": p, "label": law.period_label(p), "fy": law.fy_of(p), "month_name": MONTH_NAMES[m - 1],
            "quarter_texts": [f"Quarter {q} ({rng})", f"Quarter {q}", rng, f"Q{q}"]}


def _job(code, need_active=True):
    j = db.q1("SELECT * FROM portal_jobs WHERE code=?", ((code or "").strip().upper(),))
    if not j:
        abort(404)
    if need_active and (j["expires_at"] < db.now() or j["status"] in ("done", "cancelled")):
        abort(410)
    return j


def _log(job_id, msg, status=None):
    j = db.q1("SELECT log FROM portal_jobs WHERE id=?", (job_id,))
    line = f"{dt.datetime.now():%H:%M:%S}  {msg}"
    db.x("UPDATE portal_jobs SET log=?" + (", status=?" if status else "") + " WHERE id=?",
         ((j["log"] or "") + line + "\n", status, job_id) if status else ((j["log"] or "") + line + "\n", job_id))


NOT_INSTALLED = ("The GST Portal Assistant is not installed on this laptop (it is optional, to keep the download small). "
                 "Double-click Install_Portal_Assistant.bat in the program folder once (needs internet), then try again - "
                 "or download the returns yourself and use 'Import files from folder'.")


def assistant_installed():
    import importlib.util
    return importlib.util.find_spec("playwright") is not None or bool(os.environ.get("IDTRA_TEST_SPAWN"))


def spawn_local(code, port):
    """Start the assistant on this computer (standalone mode)."""
    if not assistant_installed():
        return None
    py = Path(sys.executable)
    if py.name.lower() == "pythonw.exe":
        py = py.with_name("python.exe")
    script = Path(__file__).with_name("portal_assistant.py")
    cmd = [str(py), str(script), "--server", f"http://127.0.0.1:{port}", "--code", code]
    if os.name == "nt":
        subprocess.Popen(cmd, creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0x10), cwd=str(script.parent))
        return True
    if os.environ.get("IDTRA_TEST_SPAWN"):
        subprocess.Popen(cmd + os.environ["IDTRA_TEST_SPAWN"].split(), cwd=str(script.parent))
        return True
    return False


def register(app):
    db.conn().execute(SCHEMA)
    db.conn().commit()

    @app.route("/claims/<int:claim_id>/portal/auto", methods=["POST"])
    @login_required
    def portal_auto(claim_id):
        claim, client = _claim_ctx(claim_id)
        if STATUSES.index(claim["status"]) >= STATUSES.index("Approved"):
            abort(403, "Claim is approved. Re-open it first.")
        if not client.get("gst_username") or not client.get("gst_password_enc"):
            flash("Save the GST portal user ID and password in the client master first.", "danger")
            return redirect(url_for("client_form", cid=client["id"]))
        rets = [r for r in request.form.getlist("returns") if r in importer.RETURN_TYPES] or list(importer.RETURN_TYPES)
        code = "".join(secrets.choice(ALPHABET) for _ in range(8))
        exp = (dt.datetime.now() + dt.timedelta(hours=VALID_HOURS)).strftime("%Y-%m-%d %H:%M:%S")
        jid = db.insert("portal_jobs", dict(claim_id=claim_id, code=code, returns=",".join(rets), status="waiting",
                                            created_by=_uname(), created_at=db.now(), expires_at=exp))
        _log(jid, f"Job created by {_uname()} for {', '.join(rets)}")
        db.audit(_uname(), "Portal download job created", claim_id, code)
        cfg = app.config["IDTRA"]
        local = request.remote_addr in ("127.0.0.1", "::1")
        started = spawn_local(code, cfg["port"]) if cfg["host"] in ("127.0.0.1", "localhost") and local else False
        if started is None:
            flash(NOT_INSTALLED, "warning")
        elif started:
            flash(f"GST Portal Assistant started (job {code}). A browser window opens with your user ID and password "
                  f"filled in - type the CAPTCHA and click LOGIN. Downloads are imported automatically.", "success")
        else:
            flash(f"Job code {code} created. On your PC open 'GST Portal Assistant' (desktop icon installed with the "
                  f"client setup) and enter this code. Valid for {VALID_HOURS} hours.", "info")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal") + "#jobs")

    @app.route("/claims/<int:claim_id>/portal/jobs.json")
    @login_required
    def portal_jobs_json(claim_id):
        rows = db.q("SELECT code, status, log, created_at, expires_at, imported FROM portal_jobs WHERE claim_id=? "
                    "ORDER BY id DESC LIMIT 5", (claim_id,))
        return jsonify(rows)

    @app.route("/claims/<int:claim_id>/portal/jobs/<code>/cancel", methods=["POST"])
    @login_required
    def portal_job_cancel(claim_id, code):
        j = _job(code, need_active=False)
        if j["claim_id"] != claim_id:
            abort(404)
        db.x("UPDATE portal_jobs SET status='cancelled' WHERE id=?", (j["id"],))
        flash(f"Job {code} cancelled", "warning")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal") + "#jobs")

    # ------------------------------------------------ API used by the assistant (auth = job code)
    @app.route("/api/portal-job/<code>")
    def api_job(code):
        j = _job(code)
        claim, client = _claim_ctx(j["claim_id"])
        months = law.months_between(claim["period_from"], claim["period_to"])
        db.x("UPDATE portal_jobs SET status='running' WHERE id=?", (j["id"],))
        _log(j["id"], f"Assistant connected from {request.remote_addr}")
        db.audit(j["created_by"], "Portal assistant read credentials", claim["id"], f"job {j['code']} from {request.remote_addr}")
        return jsonify(client=client["legal_name"], gstin=client["gstin"], username=client["gst_username"] or "",
                       password=security.decrypt(client["gst_password_enc"]), returns=j["returns"].split(","),
                       months=[_month_info(p) for p in months])

    @app.route("/api/portal-job/<code>/log", methods=["POST"])
    def api_job_log(code):
        j = _job(code)
        d = request.get_json(silent=True) or {}
        st = d.get("status") if d.get("status") in ("running", "done", "failed") else None
        _log(j["id"], str(d.get("msg", ""))[:500], st)
        return jsonify(ok=True)

    @app.route("/api/portal-job/<code>/upload", methods=["POST"])
    def api_job_upload(code):
        j = _job(code)
        claim, client = _claim_ctx(j["claim_id"])
        if STATUSES.index(claim["status"]) >= STATUSES.index("Approved"):
            return jsonify(ok=False, message="Claim is approved/locked - file not imported")
        fs = request.files.get("file")
        if not fs or not fs.filename:
            return jsonify(ok=False, message="no file")
        folder = storage.claim_dir(claim, client) / "01_Portal_Downloads"
        path = storage.save_upload(fs, folder)
        rt = request.form.get("rtype") or None
        per = request.form.get("period") or None
        try:
            t, p, s, notes = importer.import_any(claim, client, path, j["created_by"], rt, per)
        except (parsers.ParseError, importer.ImportError_) as e:
            _log(j["id"], f"{fs.filename}: NOT imported - {e}")
            return jsonify(ok=False, message=f"{fs.filename}: {e}")
        except Exception as e:  # noqa: BLE001
            _log(j["id"], f"{fs.filename}: NOT imported - {type(e).__name__}: {e}")
            return jsonify(ok=False, message=f"{fs.filename}: could not be read ({type(e).__name__})")
        db.x("UPDATE portal_jobs SET imported=imported+1 WHERE id=?", (j["id"],))
        if t in importer.RETURN_TYPES:
            _set_status(claim["id"], "Data Imported")
        msg = f"{t} {law.period_label(p)} imported from {fs.filename}"
        _log(j["id"], msg)
        return jsonify(ok=True, message=msg, notes=notes, type=t, period=p, summary=s)
