// Small helpers - work over plain HTTP on the LAN (no secure-context APIs needed)
function copyText(t){
  const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';
  document.body.appendChild(ta);ta.select();
  try{document.execCommand('copy');}catch(e){}
  document.body.removeChild(ta);
}
function toast(msg){
  const d=document.createElement('div');d.textContent=msg;
  d.style.cssText='position:fixed;bottom:24px;right:24px;background:linear-gradient(135deg,#2b8ce0,#2e9e4f);color:#fff;padding:12px 18px;border-radius:12px;font-weight:700;z-index:99;box-shadow:0 10px 30px rgba(0,0,0,.25)';
  document.body.appendChild(d);setTimeout(()=>d.remove(),2200);
}
async function getSecret(clientId){
  const r=await fetch('/clients/'+clientId+'/secret',{method:'POST',headers:{'X-CSRF':window.CSRF}});
  if(!r.ok){toast('Not allowed');return null;}
  return await r.json();
}
async function copyCred(clientId,what){
  const s=await getSecret(clientId); if(!s) return;
  copyText(s[what]||''); toast((what==='password'?'Password':'Username')+' copied - paste it on the GST portal');
}
async function showPw(clientId,el){
  const s=await getSecret(clientId); if(!s) return;
  document.getElementById(el).textContent=s.password||'(not saved)';
}
function confirmSubmit(f,msg){return confirm(msg||'Are you sure?');}
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.drop').forEach(d=>{
    const inp=d.querySelector('input[type=file]');
    d.addEventListener('click',e=>{if(e.target.tagName!=='INPUT')inp.click();});
    d.addEventListener('dragover',e=>{e.preventDefault();d.style.borderColor='#f07c1b';});
    d.addEventListener('drop',e=>{e.preventDefault();inp.files=e.dataTransfer.files;d.querySelector('.fn').textContent=[...inp.files].map(f=>f.name).join(', ');});
    inp.addEventListener('change',()=>{d.querySelector('.fn').textContent=[...inp.files].map(f=>f.name).join(', ');});
  });
  document.querySelectorAll('form').forEach(f=>{
    if(f.method.toLowerCase()!=='post') return;
    f.addEventListener('submit',(e)=>{setTimeout(()=>{ if(e.defaultPrevented) return;
      const b=e.submitter; if(b){b.disabled=true;b.dataset.t=b.textContent;b.textContent='Working...';}},10);});
  });
});
