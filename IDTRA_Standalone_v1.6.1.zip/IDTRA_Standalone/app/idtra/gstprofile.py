"""Reads the taxpayer's registration details from what the GST portal shows after login.

Two sources are combined (whichever has the field wins in this order):
 1. JSON data the portal's profile pages load in the background - GSTN taxpayer field names
    (gstin, lgnm, tradeNam, ctb, rgdt, sts, stj, pradr.addr{bno, flno, bnm, st, loc, dst, stcd, pncd}, ...)
 2. The visible text of the profile pages, read by their labels
    ('Legal Name of Business', 'Trade Name', 'Constitution of Business', 'Principal Place of Business', ...)
"""
import re

STATES = {"01": "Jammu and Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh", "05": "Uttarakhand",
          "06": "Haryana", "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim",
          "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura", "17": "Meghalaya",
          "18": "Assam", "19": "West Bengal", "20": "Jharkhand", "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh",
          "24": "Gujarat", "26": "Dadra and Nagar Haveli and Daman and Diu", "27": "Maharashtra", "29": "Karnataka",
          "30": "Goa", "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu", "34": "Puducherry",
          "35": "Andaman and Nicobar Islands", "36": "Telangana", "37": "Andhra Pradesh", "38": "Ladakh",
          "97": "Other Territory"}
GSTIN_RE = re.compile(r"\b(\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z])\b")
DESIGNATIONS = ["Managing Director", "Whole Time Director", "Whole-time Director", "Designated Partner", "Managing Partner",
                "Director", "Partner", "Proprietor", "Karta", "Member", "Trustee", "Chairman", "CEO", "CFO", "Secretary",
                "Authorised Signatory", "Authorized Signatory", "President", "Manager"]
SECTION_HEADS = ["Business Details", "Promoter", "Partner", "Director", "Authori", "Principal Place", "Additional Place",
                 "Goods and Services", "Goods", "Services", "Bank Account", "State Specific", "Aadhaar", "Verification",
                 "Contact", "Jurisdiction", "Nature of Business"]


def _clean(s):
    return re.sub(r"\s+", " ", str(s or "")).strip(" :,-")


def constitution_choice(text):
    t = (text or "").lower()
    if "limited liability" in t or re.search(r"\bllp\b", t):
        return "LLP"
    if "partnership" in t:
        return "Partnership Firm"
    if "public" in t and "compan" in t:
        return "Public Limited Company"
    if "private" in t and "compan" in t:
        return "Private Limited Company"
    if "proprietor" in t:
        return "Proprietorship"
    return "Others" if t else ""


# ------------------------------------------------------------------ JSON
def _walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)


def _addr(a):
    if not isinstance(a, dict):
        return _clean(a)
    if "addr" in a and isinstance(a["addr"], dict):
        a = a["addr"]
    parts = [a.get(k) for k in ("bno", "flno", "bnm", "st", "loc", "city", "dst", "stcd")]
    s = ", ".join(_clean(p) for p in parts if _clean(p))
    if _clean(a.get("pncd")):
        s += f" - {_clean(a.get('pncd'))}"
    return s


def from_json(objs):
    f = {}
    keys = {"gstin": "gstin", "lgnm": "legal_name", "legalName": "legal_name", "tradeNam": "trade_name",
            "tradeName": "trade_name", "ctb": "constitution_raw", "constitution": "constitution_raw", "rgdt": "reg_date",
            "sts": "status", "stj": "jurisdiction", "dty": "taxpayer_type", "em": "email", "email": "email",
            "emailId": "email", "mob": "mobile", "mobile": "mobile", "mobileNo": "mobile", "pan": "pan"}
    for o in objs:
        for d in _walk(o):
            for k, name in keys.items():
                v = d.get(k)
                if isinstance(v, (str, int)) and _clean(v) and name not in f:
                    f[name] = _clean(v)
            if "pradr" in d and "address" not in f:
                f["address"] = _addr(d["pradr"])
            for lk in ("promoters", "partners", "promoterDetails", "partnerDetails", "authSignatory", "signatories"):
                lst = d.get(lk)
                if isinstance(lst, list):
                    for p in lst:
                        if isinstance(p, dict):
                            nm = " ".join(_clean(p.get(k)) for k in ("fname", "firstName", "mname", "lname", "lastName", "name")
                                          if _clean(p.get(k)))
                            if nm:
                                f.setdefault("people", []).append(
                                    {"name": nm.title() if nm.isupper() else nm,
                                     "designation": _clean(p.get("desig") or p.get("designation")) or ("Authorised Signatory" if "auth" in lk.lower() or "sign" in lk.lower() else "Partner"),
                                     "pan": _clean(p.get("pan")).upper(), "mobile": _clean(p.get("mob") or p.get("mobile")),
                                     "email": _clean(p.get("em") or p.get("email"))})
    return f


# ------------------------------------------------------------------ text
def _after(text, labels, pattern=r"([^\n]{2,200})"):
    for lab in labels:
        m = re.search(rf"{lab}\s*[:\-]?\s*\n?\s*{pattern}", text, re.I)
        if m:
            v = _clean(m.group(1))
            if v and not re.match(r"^(?:%s)" % "|".join(re.escape(x) for x in labels), v, re.I):
                return v
    return ""


def _section(text, starts):
    """Lines under a heading such as 'Promoters / Partners' until the next section heading.
    A line that is only a designation ('Director') is content, not a heading."""
    desig = {d.lower() for d in DESIGNATIONS}
    out = []
    for block in text.split("\f"):
        on = False
        for l in (x.strip() for x in block.splitlines()):
            if not l:
                continue
            low = l.lower()
            if low in desig:
                if on:
                    out.append(l)
                continue
            if any(low.startswith(st.lower()) for st in starts) and len(l) <= 60:
                on = True
                continue
            if on and any(low.startswith(h.lower()) for h in SECTION_HEADS):
                on = False
                continue
            if on:
                out.append(l)
    return out


def _people(lines, default_desig):
    people = []
    skip = re.compile(r"^(name|designation|status|pan|mobile|email|e-mail|sr|s\.?no|#|citizen|resident|gender|"
                      r"father|date|address|din|aadhaar|telephone|primary|yes|no|view|details|action)\b", re.I)
    for i, l in enumerate(lines):
        if skip.match(l) or "@" in l or re.search(r"\d{4,}", l):
            continue
        desig = next((d for d in DESIGNATIONS if re.search(rf"\b{re.escape(d)}\b", l, re.I)), "")
        name = re.sub("|".join(rf"\b{re.escape(d)}\b" for d in DESIGNATIONS), "", l, flags=re.I)
        name = _clean(re.sub(r"[^A-Za-z .']", " ", name))
        if len(name) < 4 or len(name.split()) > 6:
            continue
        if not desig and i + 1 < len(lines):
            desig = next((d for d in DESIGNATIONS if re.search(rf"\b{re.escape(d)}\b", lines[i + 1], re.I)), "")
        pan = ""
        for nxt in lines[i + 1:i + 6]:
            mp = re.search(r"\b([A-Z]{5}\d{4}[A-Z])\b", nxt)
            if mp:
                pan = mp.group(1)
                break
        people.append({"name": name.title() if name.isupper() else name, "designation": desig or default_desig,
                       "pan": pan, "mobile": "", "email": ""})
    return people


def from_text(texts):
    text = "\n".join(t for t in texts if t)
    pages = "\f".join(t for t in texts if t)
    f = {}
    g = GSTIN_RE.search(text)
    if g:
        f["gstin"] = g.group(1)
    f["legal_name"] = _after(text, [r"Legal Name of Business", r"Legal Name", r"Name of Business"])
    f["trade_name"] = _after(text, [r"Trade Name"])
    f["constitution_raw"] = _after(text, [r"Constitution of Business", r"Constitution"])
    f["reg_date"] = _after(text, [r"Date of Registration", r"Effective Date of Registration", r"Registration Date"],
                           r"(\d{2}[/\-.]\d{2}[/\-.]\d{4})")
    f["status"] = _after(text, [r"GSTIN\s*/\s*UIN Status", r"Status"], r"(Active|Cancelled|Suspended|Inactive)")
    f["taxpayer_type"] = _after(text, [r"Taxpayer Type"])
    f["address"] = _after(text, [r"Address of Principal Place of Business", r"Principal Place of Business\s*(?:Address)?",
                                 r"Principal Place of Business"])
    m = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text)
    if m:
        f["email"] = m.group(0)
    m = re.search(r"(?:Mobile|Phone|Contact)[^\n\d]{0,40}(?:\+?91[\s-]?)?([6-9]\d{9})", text, re.I)
    if m:
        f["mobile"] = m.group(1)
    people = _people(_section(pages, ["Promoter", "Partner", "Director", "Proprietor"]), "Partner")
    signs = _people(_section(pages, ["Authorised Signator", "Authorized Signator"]), "Authorised Signatory")
    seen = set()
    for p in people + signs:
        k = p["name"].lower()
        if k in seen:
            continue
        seen.add(k)
        f.setdefault("people", []).append(p)
    return {k: v for k, v in f.items() if v}


def parse(texts, jsons):
    j = from_json(jsons)
    t = from_text(texts)
    f = dict(t)
    f.update({k: v for k, v in j.items() if v and k != "people"})
    f["people"] = j.get("people") or t.get("people") or []
    g = f.get("gstin", "")
    if g:
        f["pan"] = f.get("pan") or g[2:12]
        f["state"] = STATES.get(g[:2], "")
    if f.get("constitution_raw"):
        f["constitution"] = constitution_choice(f["constitution_raw"])
    return f
