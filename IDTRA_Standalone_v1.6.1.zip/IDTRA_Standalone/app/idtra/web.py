"""Flask web application - served from the server machine to all LAN clients."""
import datetime as dt
import functools
import io
import os
import json
import secrets
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file, session,
                   url_for)

from . import (APP_NAME, APP_SHORT, APP_VERSION, LAW_UPDATED_UPTO, calc, config, db, docgen, exports, importer,
               law, parsers, recon, security, storage)

STATUSES = ["Draft", "Data Imported", "Reconciled", "Computed", "Approved", "CA Certified", "UDIN Recorded",
            "Upload Files Ready"]
STATUS_COLORS = {"Draft": "#94a3b8", "Data Imported": "#56b0f0", "Reconciled": "#2b8ce0", "Computed": "#f07c1b",
                 "Approved": "#2e9e4f", "CA Certified": "#d93636", "UDIN Recorded": "#1f78c8",
                 "Upload Files Ready": "#2e9e4f"}


def create_app(cfg=None):
    cfg = cfg or config.load()
    security.init(cfg["key_file"])
    db.init(cfg["db_path"])
    storage.init(cfg["data_root"])
    app = Flask(__name__)
    app.secret_key = cfg["secret_key"]
    app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024
    app.config["IDTRA"] = cfg
    _ensure_admin()

    @app.template_filter("inr")
    def _inr(v, dec=2):
        if v is None or v == "":
            return "-"
        return docgen.inr(v, dec)

    @app.template_filter("plabel")
    def _pl(p):
        return law.period_label(p) if p else ""

    @app.template_filter("dmy")
    def _dmy(v):
        if not v:
            return ""
        try:
            return dt.date.fromisoformat(str(v)[:10]).strftime("%d-%m-%Y") + (str(v)[10:16] if len(str(v)) > 10 else "")
        except ValueError:
            return v

    @app.context_processor
    def _ctx():
        return dict(APP_NAME=APP_NAME, APP_SHORT=APP_SHORT, APP_VERSION=APP_VERSION, LAW_UPDATED_UPTO=LAW_UPDATED_UPTO,
                    user=g.get("user"), csrf=_csrf_token(), STATUS_COLORS=STATUS_COLORS, STATUSES=STATUSES,
                    firm_name=db.get_setting("firm_name", ""))

    @app.before_request
    def _load_user():
        g.user = None
        uid = session.get("uid")
        if uid:
            g.user = db.q1("SELECT * FROM users WHERE id=? AND active=1", (uid,))
        if request.method == "POST" and request.endpoint not in ("login", "static") and not request.path.startswith("/api/"):
            tok = request.form.get("_csrf") or request.headers.get("X-CSRF")
            if not tok or tok != session.get("_csrf"):
                abort(400, "Session expired. Please reload the page.")

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(410)
    @app.errorhandler(413)
    def _err(e):
        code = getattr(e, "code", 500)
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error=getattr(e, "description", str(e))), code
        if not g.get("user"):
            return (f"<h3>{code} - {getattr(e, 'name', 'Error')}</h3><p>{getattr(e, 'description', '')}</p>"
                    f"<p><a href='{url_for('login')}'>Go to login</a></p>"), code
        return render_template("error.html", e=e), code

    _routes(app)
    from .scn_web import register as _scn_register
    _scn_register(app)
    from .portal_api import register as _portal_register
    _portal_register(app)
    from .profile_api import register as _profile_register
    _profile_register(app)
    from .books_web import register as _books_register
    _books_register(app)
    return app


def _ensure_admin():
    if not db.q1("SELECT id FROM users LIMIT 1"):
        db.insert("users", dict(username="admin", full_name="Administrator", pw_hash=security.hash_pw("admin@123"),
                                role="admin", created_at=db.now()))
        db.set_setting("force_pw_change_admin", "1")


INBOX = "Put_portal_files_here"


def _inbox(claim, client):
    d = storage.claim_dir(claim, client) / "01_Portal_Downloads" / INBOX
    d.mkdir(parents=True, exist_ok=True)
    return d


def _csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def login_required(f):
    @functools.wraps(f)
    def w(*a, **k):
        if not g.user:
            return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return w


def role_required(*roles):
    def deco(f):
        @functools.wraps(f)
        def w(*a, **k):
            if not g.user:
                return redirect(url_for("login"))
            if g.user["role"] not in roles:
                abort(403, "You do not have permission for this action.")
            return f(*a, **k)
        return w
    return deco


def _uname():
    return g.user["username"] if g.get("user") else "?"


def _claim_ctx(claim_id):
    claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
    if not claim:
        abort(404, "Claim not found")
    client = db.q1("SELECT * FROM clients WHERE id=?", (claim["client_id"],))
    return claim, client


def _set_status(claim_id, status, at_least=True):
    cur = db.q1("SELECT status FROM claims WHERE id=?", (claim_id,))["status"]
    if at_least and STATUSES.index(cur) >= STATUSES.index(status):
        return
    db.update("claims", claim_id, {"status": status, "updated_at": db.now()})


def _locked(claim):
    return STATUSES.index(claim["status"]) >= STATUSES.index("Approved")


def _routes(app):
    # ------------------------------------------------------------------ auth
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            u = db.q1("SELECT * FROM users WHERE username=? AND active=1", (request.form.get("username", "").strip(),))
            if u and security.check_pw(u["pw_hash"], request.form.get("password", "")):
                session.clear()
                session["uid"] = u["id"]
                session.permanent = True
                db.audit(u["username"], "Login", None, request.remote_addr)
                if u["username"] == "admin" and db.get_setting("force_pw_change_admin") == "1":
                    flash("Please change the default administrator password now.", "warning")
                    return redirect(url_for("profile"))
                return redirect(request.args.get("next") or url_for("dashboard"))
            flash("Invalid username or password", "danger")
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        if g.user:
            db.audit(_uname(), "Logout")
        session.clear()
        return redirect(url_for("login"))

    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        if request.method == "POST":
            old, new, new2 = (request.form.get(k, "") for k in ("old", "new", "new2"))
            if not security.check_pw(g.user["pw_hash"], old):
                flash("Current password is wrong", "danger")
            elif len(new) < 6 or new != new2:
                flash("New password must be at least 6 characters and both entries must match", "danger")
            else:
                db.update("users", g.user["id"], {"pw_hash": security.hash_pw(new)})
                if g.user["username"] == "admin":
                    db.set_setting("force_pw_change_admin", "0")
                db.audit(_uname(), "Changed password")
                flash("Password changed", "success")
                return redirect(url_for("dashboard"))
        return render_template("profile.html")

    # ------------------------------------------------------------- dashboard
    @app.route("/")
    @login_required
    def dashboard():
        stats = {
            "clients": db.q1("SELECT COUNT(*) n FROM clients WHERE active=1")["n"],
            "claims": db.q1("SELECT COUNT(*) n FROM claims")["n"],
            "open_queries": db.q1("SELECT COUNT(*) n FROM queries WHERE status='Open'")["n"],
            "approved": db.q1("SELECT COUNT(*) n FROM claims WHERE status IN ('Approved','CA Certified','UDIN Recorded','Upload Files Ready')")["n"],
        }
        total = 0.0
        for r in db.q("SELECT result_json FROM calculations WHERE is_final=1"):
            total += json.loads(r["result_json"])["refund"]["amount"]
        stats["refund_total"] = total
        soon = (dt.date.today() + dt.timedelta(days=5)).isoformat()
        stats["notices_due"] = db.q("SELECT n.*, cl.legal_name FROM notices n JOIN claims c ON c.id=n.claim_id JOIN clients cl "
                                    "ON cl.id=c.client_id WHERE n.status IN ('Received','Analysed','Reply drafted') "
                                    "AND n.due_date<>'' AND n.due_date<=? ORDER BY n.due_date", (soon,))
        claims = db.q("SELECT c.*, cl.legal_name, cl.gstin, (SELECT COUNT(*) FROM queries q WHERE q.claim_id=c.id AND "
                      "q.status='Open') oq FROM claims c JOIN clients cl ON cl.id=c.client_id ORDER BY c.updated_at DESC, "
                      "c.id DESC LIMIT 15")
        for c in claims:
            r = calc.latest(c["id"])
            c["refund"] = r["refund"]["amount"] if r else None
        return render_template("dashboard.html", stats=stats, claims=claims)

    # --------------------------------------------------------------- clients
    @app.route("/clients")
    @login_required
    def clients():
        rows = db.q("SELECT c.*, (SELECT COUNT(*) FROM claims WHERE client_id=c.id) nclaims FROM clients c "
                    "ORDER BY active DESC, legal_name")
        return render_template("clients.html", rows=rows)

    @app.route("/clients/new", methods=["GET", "POST"])
    @app.route("/clients/<int:cid>", methods=["GET", "POST"])
    @login_required
    def client_form(cid=None):
        c = db.q1("SELECT * FROM clients WHERE id=?", (cid,)) if cid else None
        if cid and not c:
            abort(404)
        if request.method == "POST":
            f = request.form
            gstin = parsers.norm_gstin(f.get("gstin"))
            if not parsers.valid_gstin(gstin):
                flash("GSTIN format is invalid", "danger")
                return render_template("client_form.html", c=dict(f), sigs=[])
            data = {k: f.get(k, "").strip() for k in ("legal_name", "trade_name", "pan", "state", "constitution",
                                                       "address", "email", "phone", "filing_freq", "gst_username",
                                                       "notes")}
            data["gstin"] = gstin
            data["pan"] = data["pan"] or gstin[2:12]
            if f.get("gst_password"):
                data["gst_password_enc"] = security.encrypt(f.get("gst_password"))
            data["updated_at"] = db.now()
            dup = db.q1("SELECT id FROM clients WHERE gstin=? AND id IS NOT ?", (gstin, cid))
            if dup:
                flash("A client with this GSTIN already exists", "danger")
                return render_template("client_form.html", c=dict(f), sigs=[])
            if c:
                newfolder = storage.client_folder_name(data["legal_name"], gstin, exclude_id=cid)
                if newfolder != c["folder_name"]:
                    storage.rename_client_folder(c["folder_name"], newfolder)
                    data["folder_name"] = newfolder
                db.update("clients", cid, data)
                db.audit(_uname(), "Updated client", None, f"{data['legal_name']} {gstin}")
            else:
                data["folder_name"] = storage.client_folder_name(data["legal_name"], gstin)
                data["created_at"] = db.now()
                cid = db.insert("clients", data)
                (storage.DATA_ROOT / data["folder_name"]).mkdir(parents=True, exist_ok=True)
                db.audit(_uname(), "Created client", None, f"{data['legal_name']} {gstin}")
            # signatories
            names = f.getlist("sig_name")
            desg = f.getlist("sig_desg")
            pans = f.getlist("sig_pan")
            mobs = f.getlist("sig_mobile")
            default = f.get("sig_default", "0")
            db.x("DELETE FROM client_signatories WHERE client_id=?", (cid,))
            for i, n in enumerate(names):
                if n.strip():
                    db.insert("client_signatories", dict(client_id=cid, name=n.strip(), designation=desg[i].strip(),
                                                         pan=pans[i].strip().upper(), mobile=mobs[i].strip(),
                                                         is_default=1 if str(i) == default else 0))
            flash("Client saved", "success")
            return redirect(url_for("client_form", cid=cid))
        sigs = db.q("SELECT * FROM client_signatories WHERE client_id=? ORDER BY id", (cid,)) if cid else []
        claims = db.q("SELECT * FROM claims WHERE client_id=? ORDER BY period_from DESC", (cid,)) if cid else []
        return render_template("client_form.html", c=c or {}, sigs=sigs, claims=claims)

    @app.route("/clients/<int:cid>/secret", methods=["POST"])
    @login_required
    def client_secret(cid):
        c = db.q1("SELECT legal_name, gst_username, gst_password_enc FROM clients WHERE id=?", (cid,))
        if not c:
            abort(404)
        db.audit(_uname(), "Viewed GST portal credentials", None, c["legal_name"])
        return jsonify(username=c["gst_username"] or "", password=security.decrypt(c["gst_password_enc"]))

    @app.route("/clients/<int:cid>/toggle", methods=["POST"])
    @role_required("admin", "partner")
    def client_toggle(cid):
        db.x("UPDATE clients SET active=1-active WHERE id=?", (cid,))
        return redirect(url_for("clients"))

    # ------------------------------------------------------------ CA master
    @app.route("/ca")
    @login_required
    def ca_list():
        return render_template("ca_list.html", rows=db.q("SELECT * FROM ca_master ORDER BY active DESC, ca_name"))

    @app.route("/ca/new", methods=["GET", "POST"])
    @app.route("/ca/<int:caid>", methods=["GET", "POST"])
    @role_required("admin", "partner")
    def ca_form(caid=None):
        ca = db.q1("SELECT * FROM ca_master WHERE id=?", (caid,)) if caid else None
        if request.method == "POST":
            f = request.form
            data = {k: f.get(k, "").strip() for k in ("firm_name", "frn", "ca_name", "membership_no", "designation",
                                                       "address", "city", "email", "phone")}
            data["active"] = 1 if f.get("active") else 0
            data["updated_at"] = db.now()
            if not data["membership_no"].isdigit():
                flash("Membership number should be numeric", "danger")
                return render_template("ca_form.html", ca=data)
            if ca:
                db.update("ca_master", caid, data)
            else:
                data["created_at"] = db.now()
                caid = db.insert("ca_master", data)
            db.audit(_uname(), "Saved CA master", None, f"{data['ca_name']} M.No {data['membership_no']}")
            flash("CA details saved", "success")
            return redirect(url_for("ca_list"))
        return render_template("ca_form.html", ca=ca or {"active": 1, "designation": "Partner",
                                                         "firm_name": db.get_setting("firm_name", ""),
                                                         "frn": db.get_setting("firm_frn", "")})

    # ------------------------------------------------------- settings / users
    @app.route("/settings", methods=["GET", "POST"])
    @role_required("admin")
    def settings():
        if request.method == "POST":
            for k in ("firm_name", "firm_frn", "firm_address", "firm_city", "firm_email", "firm_phone"):
                db.set_setting(k, request.form.get(k, "").strip())
            mg = parsers.num(request.form.get("trading_min_gp", "10"))
            if not 0 <= mg < 100:
                flash("Minimum GP % must be between 0 and 100", "danger")
                return redirect(url_for("settings"))
            db.set_setting("trading_min_gp", str(mg))
            flash("Firm settings saved", "success")
            return redirect(url_for("settings"))
        s = {k: db.get_setting(k) for k in ("firm_name", "firm_frn", "firm_address", "firm_city", "firm_email",
                                             "firm_phone")}
        s["trading_min_gp"] = db.get_setting("trading_min_gp", "10")
        cfg = app.config["IDTRA"]
        backups = sorted((storage.DATA_ROOT / "_Backups").glob("*.zip"), reverse=True)[:10]
        return render_template("settings.html", s=s, cfg=cfg, backups=[b.name for b in backups],
                               users=db.q("SELECT * FROM users ORDER BY username"))

    @app.route("/users/save", methods=["POST"])
    @role_required("admin")
    def user_save():
        f = request.form
        uname = f.get("username", "").strip().lower()
        if not uname:
            flash("Username required", "danger")
            return redirect(url_for("settings"))
        u = db.q1("SELECT * FROM users WHERE username=?", (uname,))
        data = {"full_name": f.get("full_name", "").strip(), "role": f.get("role", "staff"),
                "active": 1 if f.get("active") else 0}
        if f.get("password"):
            if len(f["password"]) < 6:
                flash("Password must be at least 6 characters", "danger")
                return redirect(url_for("settings"))
            data["pw_hash"] = security.hash_pw(f["password"])
        if u:
            if u["username"] == "admin":
                data["role"], data["active"] = "admin", 1
            db.update("users", u["id"], data)
        else:
            if "pw_hash" not in data:
                flash("Password required for a new user", "danger")
                return redirect(url_for("settings"))
            data.update(username=uname, created_at=db.now())
            db.insert("users", data)
        db.audit(_uname(), "Saved user", None, uname)
        flash(f"User {uname} saved", "success")
        return redirect(url_for("settings"))

    @app.route("/backup", methods=["POST"])
    @role_required("admin")
    def backup():
        from .backup import make_backup
        name = make_backup(app.config["IDTRA"])
        db.audit(_uname(), "Backup created", None, name.name)
        flash(f"Backup created: {name.name}", "success")
        return redirect(url_for("settings"))

    @app.route("/backup/<name>")
    @role_required("admin")
    def backup_download(name):
        p = storage.DATA_ROOT / "_Backups" / Path(name).name
        if not p.exists():
            abort(404)
        return send_file(p, as_attachment=True)

    @app.route("/audit")
    @role_required("admin", "partner")
    def audit():
        rows = db.q("SELECT a.*, c.period_from, cl.legal_name FROM audit_log a LEFT JOIN claims c ON c.id=a.claim_id "
                    "LEFT JOIN clients cl ON cl.id=c.client_id ORDER BY a.id DESC LIMIT 500")
        return render_template("audit.html", rows=rows)

    # ------------------------------------------------------------- law library
    @app.route("/law", methods=["GET", "POST"])
    @login_required
    def law_library():
        if request.method == "POST":
            if g.user["role"] not in ("admin", "partner"):
                abort(403)
            f = request.form
            if f.get("delete"):
                db.x("UPDATE restricted_goods SET active=0 WHERE id=?", (int(f["delete"]),))
            else:
                db.insert("restricted_goods", dict(hsn_prefix=f.get("hsn_prefix", "").strip(),
                                                   description=f.get("description", "").strip(),
                                                   notification=f.get("notification", "").strip(),
                                                   effective_from=f.get("effective_from", ""),
                                                   effective_to=f.get("effective_to", ""),
                                                   applies_to=f.get("applies_to", "Exclude"), note=f.get("note", "")))
            db.audit(_uname(), "Updated law library")
            flash("Law library updated", "success")
            return redirect(url_for("law_library"))
        return render_template("law.html", formulas=law.FORMULAS, notes=law.LAW_NOTES,
                               goods=db.q("SELECT * FROM restricted_goods WHERE active=1 ORDER BY hsn_prefix"))

    # ------------------------------------------------------------------ claims
    @app.route("/claims")
    @login_required
    def claims():
        rows = db.q("SELECT c.*, cl.legal_name, cl.gstin, (SELECT COUNT(*) FROM queries q WHERE q.claim_id=c.id AND "
                    "q.status='Open') oq FROM claims c JOIN clients cl ON cl.id=c.client_id ORDER BY cl.legal_name, "
                    "c.period_from DESC")
        for c in rows:
            r = calc.latest(c["id"])
            c["refund"] = r["refund"]["amount"] if r else None
        return render_template("claims.html", rows=rows)

    @app.route("/claims/new", methods=["GET", "POST"])
    @login_required
    def claim_new():
        clients_ = db.q("SELECT * FROM clients WHERE active=1 ORDER BY legal_name")
        if request.method == "POST":
            f = request.form
            cid = int(f.get("client_id") or 0)
            pf, pt = f.get("period_from", ""), f.get("period_to", "")
            if not cid or not pf or not pt or pf > pt:
                flash("Select client and a valid period (From <= To)", "danger")
                return render_template("claim_new.html", clients=clients_, f=f)
            fy = law.fy_of(pf)
            if f.get("same_fy") and law.fy_of(pt) != fy:
                flash("Period crosses financial years. Untick 'same financial year' if intended "
                      "(Circular 135/05/2020 allows bunching across FYs).", "warning")
                return render_template("claim_new.html", clients=clients_, f=f)
            dup = db.q1("SELECT id FROM claims WHERE client_id=? AND period_from<=? AND period_to>=?", (cid, pt, pf))
            if dup:
                flash("A claim already exists for an overlapping period for this client.", "danger")
                return redirect(url_for("claim_view", claim_id=dup["id"]))
            filing = f.get("filing_date") or dt.date.today().isoformat()
            claim_id = db.insert("claims", dict(client_id=cid, fy=fy, period_from=pf, period_to=pt, filing_date=filing,
                                                status="Draft", created_by=_uname(), created_at=db.now(),
                                                updated_at=db.now()))
            claim, client = _claim_ctx(claim_id)
            folder = storage.claim_dir(claim, client)
            sig = db.q1("SELECT id FROM client_signatories WHERE client_id=? ORDER BY is_default DESC, id LIMIT 1", (cid,))
            db.update("claims", claim_id, {"folder": storage.rel(folder), "signatory_id": sig["id"] if sig else None})
            db.audit(_uname(), "Created claim", claim_id, f"{client['legal_name']} {pf} to {pt}")
            flash("Claim opened. Folder created on server: " + storage.rel(folder), "success")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))
        return render_template("claim_new.html", clients=clients_, f={"client_id": request.args.get("client_id", "")})

    @app.route("/claims/<int:claim_id>")
    @login_required
    def claim_view(claim_id):
        claim, client = _claim_ctx(claim_id)
        tab = request.args.get("tab", "overview")
        months = law.months_between(claim["period_from"], claim["period_to"])
        ctx = dict(claim=claim, client=client, tab=tab, months=months, locked=_locked(claim),
                   open_q=recon.open_queries(claim_id), opts=json.loads(claim.get("options_json") or "{}"))
        pf = db.q("SELECT * FROM portal_files WHERE claim_id=?", (claim_id,))
        ctx["pfmap"] = {(p["return_type"], p["tax_period"]): p for p in pf}
        if tab == "portal":
            inbox = _inbox(claim, client)
            ctx["inbox"] = str(inbox)
            ctx["inbox_files"] = sorted(f.name for f in inbox.iterdir() if f.is_file() and not f.name.startswith("~$"))
            ctx["standalone"] = app.config["IDTRA"]["host"] in ("127.0.0.1", "localhost")
        ctx["g3b"] = {r["tax_period"]: r for r in db.q("SELECT * FROM gst_3b WHERE claim_id=?", (claim_id,))}
        ctx["time_limit"] = law.time_limit(claim["period_from"], claim["period_to"], client.get("filing_freq") or "Monthly")
        ctx["calc"] = calc.latest(claim_id)
        if tab == "books":
            st = db.q("SELECT COALESCE(src_reg,'Sales') reg, COUNT(*) n, SUM(txval) tx, SUM(igst+cgst+sgst) tax FROM book_sales "
                      "WHERE claim_id=? GROUP BY 1 UNION ALL SELECT COALESCE(src_reg,register), COUNT(*), SUM(txval), "
                      "SUM(igst+cgst+sgst) FROM book_purchases WHERE claim_id=? GROUP BY 1", (claim_id, claim_id))
            files = {f["src_reg"]: f for f in db.q("SELECT * FROM book_files WHERE claim_id=?", (claim_id,))}
            for b in st:
                b["key"] = b["reg"]
                b["base"] = importer.REGISTER_KINDS.get(b["reg"], ("Purchase",))[0]
                b["reg"] = importer.REGISTER_KINDS.get(b["reg"], (0, 0, b["reg"]))[2]
                b["file"] = files.get(b["key"])
            ctx["book_stats"] = st
            ctx["net_sales"] = db.q1("SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) tax FROM book_sales "
                                     "WHERE claim_id=?", (claim_id,))
            ctx["net_purch"] = db.q1("SELECT COALESCE(SUM(txval),0) tx, COALESCE(SUM(igst+cgst+sgst),0) tax, "
                                     "SUM(CASE WHEN hsn IN ('','NA') OR hsn IS NULL THEN 1 ELSE 0 END) nohsn FROM book_purchases "
                                     "WHERE claim_id=?", (claim_id,))
            ctx["pur_hsn"] = db.q("SELECT hsn, MAX(description) description, COUNT(*) n, SUM(txval) tx, "
                                  "SUM(igst+cgst+sgst) tax, MAX(is_trading) tr FROM book_purchases WHERE claim_id=? "
                                  "AND category='Inputs' GROUP BY hsn ORDER BY tx DESC", (claim_id,))
            ctx["sale_hsn"] = {r["hsn"] for r in db.q("SELECT DISTINCT hsn FROM book_sales WHERE claim_id=?", (claim_id,))}
            ctx["trading"] = {r["hsn"] for r in db.q("SELECT hsn FROM trading_hsn WHERE claim_id=?", (claim_id,))}
            ctx["sales_preview"] = db.q("SELECT * FROM book_sales WHERE claim_id=? ORDER BY inv_date, id LIMIT 50", (claim_id,))
        if tab == "recon":
            ctx["snap"] = recon.snapshot(claim_id)
            flt = request.args.get("f", "issues")
            sql = "SELECT * FROM book_purchases WHERE claim_id=?"
            if flt == "issues":
                sql += " AND match_status NOT IN ('Matched') AND match_status NOT LIKE 'Not required%'"
            ctx["purchases"] = db.q(sql + " ORDER BY supplier_gstin, inv_no LIMIT 1000", (claim_id,))
            ctx["not_in_books"] = db.q("SELECT * FROM gst_2b WHERE claim_id=? AND matched_book_id IS NULL ORDER BY ctin",
                                       (claim_id,))
            ctx["flt"] = flt
        if tab == "queries":
            ctx["queries"] = db.q("SELECT * FROM queries WHERE claim_id=? ORDER BY CASE status WHEN 'Open' THEN 0 ELSE 1 END, id",
                                  (claim_id,))
        if tab == "compute":
            ctx["groups"], ctx["max_in"] = calc.outward_groups(claim)
            ctx["ecl"] = {r["kind"]: r for r in db.q("SELECT * FROM ecl_balances WHERE claim_id=?", (claim_id,))}
            ctx["formulas"] = law.FORMULAS
            ctx["auto_version"] = law.formula_for_filing_date(claim.get("filing_date"))
            ctx["min_gp"] = db.get_setting("trading_min_gp", "10")
        if tab in ("documents", "overview"):
            ctx["docs"] = db.q("SELECT * FROM documents WHERE claim_id=? ORDER BY id DESC", (claim_id,))
            ctx["sigs"] = db.q("SELECT * FROM client_signatories WHERE client_id=?", (client["id"],))
            ctx["cas"] = db.q("SELECT * FROM ca_master WHERE active=1 ORDER BY ca_name")
            ctx["has_ca_cert"] = any(d["doc_type"].startswith("CA Certificate") for d in ctx["docs"])
            ctx["has_upload"] = any(d["doc_type"].startswith("Annexure-B JSON") for d in ctx["docs"])
            a = db.get_setting(f"annexb_{claim_id}")
            ctx["annexb"] = json.loads(a) if a else None
            ctx["final"] = calc.latest(claim_id, final_only=True)
        if tab == "scn":
            from . import scn as _scn
            ctx["notices"] = db.q("SELECT * FROM notices WHERE claim_id=? ORDER BY id DESC", (claim_id,))
            ctx["notice_types"] = _scn.NOTICE_TYPES
            ctx["today"] = dt.date.today().isoformat()
        ctx["open_notices"] = db.q1("SELECT COUNT(*) n FROM notices WHERE claim_id=? AND status NOT IN "
                                    "('Order received','Closed')", (claim_id,))["n"]
        ctx["queries_summary"] = db.q("SELECT status, COUNT(*) n FROM queries WHERE claim_id=? GROUP BY status", (claim_id,))
        return render_template("claim.html", **ctx)

    @app.route("/claims/<int:claim_id>/edit", methods=["POST"])
    @login_required
    def claim_edit(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403, "Claim is approved. Re-open it first.")
        fd = request.form.get("filing_date")
        db.update("claims", claim_id, {"filing_date": fd, "notes": request.form.get("notes", ""), "updated_at": db.now()})
        db.audit(_uname(), "Edited claim", claim_id, f"filing date {fd}")
        flash("Claim updated", "success")
        return redirect(url_for("claim_view", claim_id=claim_id))

    @app.route("/claims/<int:claim_id>/delete", methods=["POST"])
    @role_required("admin")
    def claim_delete(claim_id):
        claim, client = _claim_ctx(claim_id)
        db.x("DELETE FROM claims WHERE id=?", (claim_id,))
        db.audit(_uname(), "Deleted claim (files kept on server)", None, f"{client['legal_name']} {claim['period_from']}")
        flash("Claim deleted from database. Files remain in the server folder.", "warning")
        return redirect(url_for("claims"))

    # --------------------------------------------------------------- portal data
    @app.route("/claims/<int:claim_id>/portal/upload", methods=["POST"])
    @login_required
    def portal_upload(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403, "Claim is approved. Re-open it first.")
        folder = storage.claim_dir(claim, client) / "01_Portal_Downloads"
        ok, errs = 0, []
        hint_t = request.form.get("rtype") or None
        hint_p = request.form.get("month") or None
        for fs in request.files.getlist("files"):
            if not fs or not fs.filename:
                continue
            path = storage.save_upload(fs, folder)
            try:
                claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
                t, p, s, notes = importer.import_any(claim, client, path, _uname(), hint_t, hint_p)
                ok += 1
                flash(f"{t.replace('_PDF', ' (PDF)')} {law.period_label(p)} imported from {fs.filename}: {s}", "success")
                for n_ in notes:
                    flash(n_, "warning")
            except (parsers.ParseError, importer.ImportError_, ValueError, KeyError, TypeError, IndexError) as e:
                errs.append(f"{fs.filename}: {e}")
                path.unlink(missing_ok=True)
            except Exception as e:  # noqa: BLE001 - unreadable file of any kind
                errs.append(f"{fs.filename}: could not be read ({type(e).__name__}: {e})")
                path.unlink(missing_ok=True)
        for e in errs:
            flash(e, "danger")
        if ok:
            _set_status(claim_id, "Data Imported")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))

    @app.route("/claims/<int:claim_id>/portal/folder", methods=["POST"])
    @login_required
    def portal_folder_import(claim_id):
        """Import every GSTR-1 / GSTR-2B / GSTR-3B file put in the claim's inbox folder (downloaded manually)."""
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403, "Claim is approved. Re-open it first.")
        inbox = _inbox(claim, client)
        done_dir = inbox.parent
        files = sorted(f for f in inbox.iterdir() if f.is_file() and not f.name.startswith("~$"))
        if not files:
            flash(f"No files in the folder {inbox}. Download the returns from the GST portal, save them there and click "
                  f"Import again.", "warning")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))
        ok, bad = 0, 0
        # GSTR-2B / GSTR-1 first, then GSTR-3B; JSON / ZIP before PDF / Excel of the same return
        files.sort(key=lambda f: (f.suffix.lower() not in (".json", ".zip"), f.name.lower()))
        for f in files:
            target = done_dir / f.name
            i = 2
            while target.exists():
                target = done_dir / f"{f.stem}_v{i}{f.suffix}"
                i += 1
            shutil.move(str(f), str(target))
            try:
                claim = db.q1("SELECT * FROM claims WHERE id=?", (claim_id,))
                t, per, summ, notes = importer.import_any(claim, client, target, _uname(), None, None)
                ok += 1
                kind = "" if f.suffix.lower() in (".json", ".zip") else f" - from {f.suffix.upper()[1:]}, JSON is preferred"
                flash(f"{t.replace('_PDF', ' (PDF)')} {law.period_label(per)} imported from {f.name}{kind}: {summ}", "success")
                for n_ in notes:
                    flash(n_, "warning")
            except Exception as e:  # noqa: BLE001 - leave the file in the folder and say why
                bad += 1
                shutil.move(str(target), str(f))
                flash(f"{f.name}: not imported - {e}", "danger")
        if ok:
            _set_status(claim_id, "Data Imported")
        db.audit(_uname(), "Imported portal files from folder", claim_id, f"{ok} imported, {bad} left in folder")
        flash(f"Folder import: {ok} file(s) imported" + (f", {bad} left in the folder (see the messages)" if bad else "") +
              ". Imported files are moved to 01_Portal_Downloads.", "info" if not bad else "warning")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))

    @app.route("/claims/<int:claim_id>/portal/openfolder", methods=["POST"])
    @login_required
    def portal_open_folder(claim_id):
        claim, client = _claim_ctx(claim_id)
        inbox = _inbox(claim, client)
        if request.remote_addr in ("127.0.0.1", "::1") and hasattr(os, "startfile"):
            os.startfile(str(inbox))          # noqa: S606 - opens Windows Explorer on this PC (standalone)
            flash("The folder is open in Windows Explorer - save the downloaded files there.", "info")
        else:
            flash(f"Folder on the server: {inbox}", "info")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))

    @app.route("/claims/<int:claim_id>/portal/3b", methods=["POST"])
    @login_required
    def portal_3b(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        f = request.form
        p = f.get("period")
        fields = ["osup_txval", "osup_igst", "osup_cgst", "osup_sgst", "osup_cess", "zero_txval", "zero_igst",
                  "nil_exempt", "non_gst", "rcm_txval", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess",
                  "itcrev_igst", "itcrev_cgst", "itcrev_sgst", "itcrev_cess",
                  "itcrevoth_igst", "itcrevoth_cgst", "itcrevoth_sgst", "itcrevoth_cess"]
        importer.save_3b(claim_id, p, {k: parsers.num(f.get(k)) for k in fields}, "Manual")
        db.audit(_uname(), "Entered GSTR-3B manually", claim_id, law.period_label(p))
        _set_status(claim_id, "Data Imported")
        flash(f"GSTR-3B figures saved for {law.period_label(p)}", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="portal"))

    # -------------------------------------------------------------------- books
    @app.route("/template/<kind>")
    @login_required
    def template(kind):
        if kind not in ("Sales", "Purchase", "Expense"):
            abort(404)
        bio = Path(tempfile.mkdtemp()) / f"{kind}_Register_Template.xlsx"
        exports.register_template(bio, kind)
        return send_file(bio, as_attachment=True, download_name=bio.name)

    @app.route("/claims/<int:claim_id>/books/upload", methods=["POST"])
    @login_required
    def books_upload(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        reg = request.form.get("register")
        fs = request.files.get("file")
        if reg not in importer.REGISTER_KINDS or not fs or not fs.filename:
            flash("Choose the register type and a file", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="books"))
        path = storage.save_upload(fs, storage.claim_dir(claim, client) / "02_Books_of_Account", prefix=f"{reg}_")
        try:
            n, warns = importer.import_register(claim, path, reg, _uname())
            flash(f"{importer.REGISTER_KINDS[reg][2]} imported: {n} lines", "success")
            for w in warns[:15]:
                flash(w, "warning")
            _set_status(claim_id, "Data Imported")
            storage.register_doc(claim_id, f"{reg} Register (uploaded)", path, _uname())
        except parsers.ParseError as e:
            flash(f"{reg} register could not be read: {e}", "danger")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="books"))

    @app.route("/claims/<int:claim_id>/books/trading", methods=["POST"])
    @login_required
    def books_trading(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        db.x("DELETE FROM trading_hsn WHERE claim_id=?", (claim_id,))
        for h in request.form.getlist("trading"):
            db.x("INSERT OR IGNORE INTO trading_hsn(claim_id,hsn) VALUES(?,?)", (claim_id, h))
        importer.apply_trading_hsn(claim_id)
        db.audit(_uname(), "Updated trading HSN list", claim_id, ",".join(request.form.getlist("trading")))
        flash("Trading goods updated. Re-run reconciliation and computation.", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="books"))

    # ------------------------------------------------------------ reconciliation
    @app.route("/claims/<int:claim_id>/recon", methods=["POST"])
    @login_required
    def recon_run(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        snap = recon.run(claim, client, _uname())
        p = storage.claim_dir(claim, client) / "03_Reconciliation" / f"Reconciliation_{dt.datetime.now():%Y%m%d_%H%M%S}.xlsx"
        exports.recon_xlsx(p, claim, client, snap)
        storage.register_doc(claim_id, "Reconciliation working paper", p, _uname())
        flash(f"Reconciliation completed - {snap['issues']} point(s) noted. Open queries: {recon.open_queries(claim_id)}",
              "info")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="recon"))

    # ----------------------------------------------------------------- queries
    @app.route("/claims/<int:claim_id>/queries", methods=["POST"])
    @login_required
    def query_post(claim_id):
        claim, client = _claim_ctx(claim_id)
        f = request.form
        if f.get("new"):
            db.insert("queries", dict(claim_id=claim_id, code=f"M-{dt.datetime.now():%y%m%d%H%M%S}", category="Manual",
                                      reference=f.get("reference", ""), description=f.get("description", ""),
                                      amount=parsers.num(f.get("amount")), status="Open", raised_by=_uname(),
                                      raised_at=db.now()))
            db.audit(_uname(), "Raised query", claim_id, f.get("description", "")[:200])
            flash("Query posted", "success")
        else:
            qid = int(f.get("qid"))
            st = f.get("status")
            if st not in ("Open", "Resolved", "Accepted"):
                abort(400)
            if st != "Open" and not f.get("response", "").strip():
                flash("A response / reason is required to close a query", "danger")
                return redirect(url_for("claim_view", claim_id=claim_id, tab="queries"))
            db.x("UPDATE queries SET status=?, response=?, resolved_by=?, resolved_at=? WHERE id=? AND claim_id=?",
                 (st, f.get("response", "").strip(), _uname() if st != "Open" else None,
                  db.now() if st != "Open" else None, qid, claim_id))
            db.audit(_uname(), f"Query {st}", claim_id, f"#{qid}: {f.get('response', '')[:200]}")
            flash("Query updated", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="queries"))

    # -------------------------------------------------------------- computation
    @app.route("/claims/<int:claim_id>/flags", methods=["POST"])
    @login_required
    def flags(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        groups, _ = calc.outward_groups(claim)
        db.x("DELETE FROM outward_flags WHERE claim_id=?", (claim_id,))
        for i, gr in enumerate(groups):
            val = 1 if request.form.get(f"inv_{i}") else 0
            note = request.form.get(f"note_{i}", "").strip()
            if val != gr["suggested"] or note:
                db.insert("outward_flags", dict(claim_id=claim_id, hsn=gr["hsn"], rate=gr["rate"], is_inverted=val, note=note))
        db.audit(_uname(), "Updated inverted supply flags", claim_id)
        flash("Inverted supply selection saved", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))

    @app.route("/claims/<int:claim_id>/ecl", methods=["POST"])
    @login_required
    def ecl(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        f = request.form
        for kind in ("end_period", "at_filing"):
            db.x("DELETE FROM ecl_balances WHERE claim_id=? AND kind=?", (claim_id, kind))
            db.insert("ecl_balances", dict(claim_id=claim_id, kind=kind, igst=parsers.num(f.get(f"{kind}_igst")),
                                           cgst=parsers.num(f.get(f"{kind}_cgst")), sgst=parsers.num(f.get(f"{kind}_sgst")),
                                           cess=parsers.num(f.get(f"{kind}_cess")), as_on=f.get(f"{kind}_date", "")))
        opts = json.loads(claim.get("options_json") or "{}")
        opts["turnover_4a4b"] = parsers.num(f.get("turnover_4a4b"))
        rv = (f.get("reversal_net_itc") or "").strip()
        opts["reversal_net_itc"] = parsers.num(rv) if rv != "" else None
        # trading goods adjustment
        opts["trading_method"] = f.get("trading_method") if f.get("trading_method") in ("gross_up", "identified") else "gross_up"
        opts["gp_basis"] = "cost" if f.get("gp_basis") == "cost" else "sales"
        for k in ("gp_percent", "gp_amount", "gp_sales", "trading_opening_stock", "trading_closing_stock", "trading_tax_rate"):
            v = (f.get(k) or "").strip()
            opts[k] = parsers.num(v) if v != "" else None
        if opts.get("gp_percent") is not None and not (0 <= opts["gp_percent"] < 100):
            flash("Gross profit % must be between 0 and 100", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))
        opts["trading_reduce_att"] = bool(f.get("trading_reduce_att"))
        ver = f.get("formula_version") or None
        reason = f.get("override_reason", "").strip()
        auto = law.formula_for_filing_date(claim.get("filing_date"))
        if ver and ver != auto and not reason:
            flash("Give a reason for applying a formula other than the one applicable to the filing date", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))
        db.update("claims", claim_id, {"options_json": json.dumps(opts), "formula_version": ver if ver != auto else None,
                                       "formula_override_reason": reason if ver and ver != auto else None,
                                       "updated_at": db.now()})
        db.audit(_uname(), "Saved ledger balances / options", claim_id)
        flash("Credit ledger balances and options saved", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))

    @app.route("/claims/<int:claim_id>/compute", methods=["POST"])
    @login_required
    def compute(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403)
        if not recon.snapshot(claim_id):
            flash("Run the reconciliation first", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="recon"))
        oq = recon.open_queries(claim_id)
        if oq:
            flash(f"{oq} open query(ies) must be resolved before computing the refund", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="queries"))
        res = calc.compute(claim, client)
        calc.save(claim, res, _uname())
        folder = storage.claim_dir(claim, client)
        path = folder / "04_Computation" / f"Refund_Workings_{dt.datetime.now():%Y%m%d_%H%M%S}.xlsx"
        exports.workings_xlsx(path, claim, client, res, recon.snapshot(claim_id))
        storage.register_doc(claim_id, "Computation workings (draft)", path, _uname())
        db.update("claims", claim_id, {"status": "Computed", "updated_at": db.now()})
        db.audit(_uname(), "Computed refund", claim_id, f"{res['version']} refund {res['refund']['amount']}")
        flash(f"Refund computed: Rs {docgen.inr(res['refund']['amount'])}", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))

    @app.route("/claims/<int:claim_id>/approve", methods=["POST"])
    @role_required("admin", "partner")
    def approve(claim_id):
        claim, client = _claim_ctx(claim_id)
        res = calc.latest(claim_id)
        if not res or claim["status"] != "Computed":
            flash("Compute the refund before approval", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))
        if recon.open_queries(claim_id):
            flash("Open queries exist", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="queries"))
        db.x("UPDATE calculations SET is_final=CASE WHEN id=? THEN 1 ELSE 0 END WHERE claim_id=?", (res["_calc_id"], claim_id))
        db.update("claims", claim_id, {"status": "Approved", "approved_by": _uname(), "approved_at": db.now(),
                                       "updated_at": db.now()})
        folder = storage.claim_dir(claim, client)
        path = folder / "04_Computation" / "Refund_Workings_FINAL.xlsx"
        exports.workings_xlsx(path, claim, client, res, recon.snapshot(claim_id))
        storage.register_doc(claim_id, "Computation workings (FINAL)", path, _uname())
        db.audit(_uname(), "Approved refund computation", claim_id, f"Rs {res['refund']['amount']}")
        flash("Refund computation approved and locked. Generate declarations and CA certificate next.", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))

    @app.route("/claims/<int:claim_id>/reopen", methods=["POST"])
    @role_required("admin", "partner")
    def reopen(claim_id):
        claim, client = _claim_ctx(claim_id)
        reason = request.form.get("reason", "").strip()
        if not reason:
            flash("Reason is required to re-open", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
        db.update("claims", claim_id, {"status": "Computed", "udin": None, "udin_date": None, "approved_by": None,
                                       "approved_at": None, "updated_at": db.now()})
        db.x("UPDATE calculations SET is_final=0 WHERE claim_id=?", (claim_id,))
        db.audit(_uname(), "Re-opened claim", claim_id, reason)
        flash("Claim re-opened. UDIN cleared - certificates must be regenerated after re-approval.", "warning")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="compute"))

    # --------------------------------------------------------------- documents
    @app.route("/claims/<int:claim_id>/docs", methods=["POST"])
    @login_required
    def docs(claim_id):
        claim, client = _claim_ctx(claim_id)
        action = request.form.get("action")
        res = calc.latest(claim_id, final_only=True)
        if not res or STATUSES.index(claim["status"]) < STATUSES.index("Approved"):
            flash("The computation must be approved first", "danger")
            return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
        folder = storage.claim_dir(claim, client)
        stamp = f"{dt.datetime.now():%Y%m%d_%H%M%S}"
        firm_city = db.get_setting("firm_city", "")
        if request.form.get("signatory_id") or request.form.get("ca_id"):
            upd = {}
            if request.form.get("signatory_id"):
                upd["signatory_id"] = int(request.form["signatory_id"])
            if request.form.get("ca_id"):
                upd["ca_id"] = int(request.form["ca_id"])
            db.update("claims", claim_id, upd)
            claim, client = _claim_ctx(claim_id)
        if action == "declarations":
            sig = db.q1("SELECT * FROM client_signatories WHERE id=?", (claim["signatory_id"],)) if claim["signatory_id"] else None
            if not sig:
                flash("Add an authorised signatory (partner/director) in the client master first", "danger")
                return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
            p = folder / "05_Declarations" / f"Applicant_Declarations_{stamp}.docx"
            docgen.applicant_declarations(p, claim, client, sig, res, firm_city)
            storage.register_doc(claim_id, "Applicant declarations & undertakings (Word)", p, _uname())
            flash("Applicant declarations generated", "success")
        elif action == "ca_cert":
            ca = db.q1("SELECT * FROM ca_master WHERE id=?", (claim["ca_id"],)) if claim["ca_id"] else None
            if not ca:
                flash("Select the CA who will sign (CA master)", "danger")
                return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
            p = folder / "06_CA_Certificate" / f"CA_Certificate_DRAFT_{stamp}.docx"
            docgen.ca_certificate(p, claim, client, ca, res, recon.snapshot(claim_id), udin=None, place=ca.get("city"))
            storage.register_doc(claim_id, "CA Certificate - draft for UDIN (Word)", p, _uname())
            _set_status(claim_id, "CA Certified")
            flash("CA certificate generated. Generate the UDIN on the ICAI portal and record it below.", "success")
        elif action == "udin":
            udin = request.form.get("udin", "").strip().upper()
            ca = db.q1("SELECT * FROM ca_master WHERE id=?", (claim["ca_id"],)) if claim["ca_id"] else None
            if not ca or claim["status"] not in ("CA Certified", "UDIN Recorded", "Upload Files Ready"):
                flash("Generate the CA certificate first", "danger")
                return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
            if len(udin) != 18 or not udin.isalnum():
                flash("UDIN must be 18 alphanumeric characters", "danger")
                return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))
            mno = (ca["membership_no"] or "").zfill(6)
            if udin[2:8] != mno[-6:]:
                flash(f"Warning: UDIN digits 3-8 ({udin[2:8]}) do not match membership no. {ca['membership_no']}. "
                      f"Saved anyway - please verify on udin.icai.org.", "warning")
            udate = request.form.get("udin_date") or dt.date.today().isoformat()
            db.update("claims", claim_id, {"udin": udin, "udin_date": udate})
            claim, client = _claim_ctx(claim_id)
            p = folder / "06_CA_Certificate" / f"CA_Certificate_FINAL_UDIN_{udin}.docx"
            docgen.ca_certificate(p, claim, client, ca, res, recon.snapshot(claim_id), udin=udin, place=ca.get("city"))
            storage.register_doc(claim_id, f"CA Certificate - FINAL with UDIN {udin} (Word)", p, _uname())
            _set_status(claim_id, "UDIN Recorded")
            db.audit(_uname(), "UDIN recorded", claim_id, udin)
            flash("UDIN saved and final CA certificate generated", "success")
        elif action == "upload_files":
            from . import annexb
            up = folder / "07_Upload_Files"
            inc_tr = bool(request.form.get("include_trading"))
            out = annexb.generate(up, stamp, claim, client, res, include_trading=inc_tr)
            storage.register_doc(claim_id, "Annexure-B Excel (utility layout)", out["xlsx"], _uname())
            for p in out["jsons"]:
                storage.register_doc(claim_id, "Annexure-B JSON (upload on portal)", p, _uname())
            p2, n2 = annexb.outward_statement_xlsx(up / f"Outward_Invoices_Inverted_{stamp}.xlsx", claim, client, res)
            storage.register_doc(claim_id, "Statement of outward invoices - inverted supplies (Excel)", p2, _uname())
            db.set_setting(f"annexb_{claim_id}", json.dumps({
                "at": db.now(), "rows": out["rows"], "errors": out["errors"][:500], "nerr": len(out["errors"]),
                "total": out["total"], "rev": out["rev"], "rev_oth": out["rev_oth"], "net": out["net"],
                "files": len(out["jsons"]), "trading_included": inc_tr}))
            if out["errors"]:
                flash(f"Annexure-B: {len(out['errors'])} validation error(s) as per the GST utility rules - JSON not "
                      f"created. The Excel shows each error in column V. Correct the data and generate again.", "danger")
            else:
                _set_status(claim_id, "Upload Files Ready")
                flash(f"Annexure-B validated ({out['rows']} lines) and JSON created in {len(out['jsons'])} file(s). "
                      f"Upload with 'JSON File Upload' on the refund application.", "success")
        db.audit(_uname(), f"Documents: {action}", claim_id)
        return redirect(url_for("claim_view", claim_id=claim_id, tab="documents"))

    @app.route("/claims/<int:claim_id>/file/<int:doc_id>")
    @login_required
    def doc_download(claim_id, doc_id):
        d = db.q1("SELECT * FROM documents WHERE id=? AND claim_id=?", (doc_id, claim_id))
        if not d:
            abort(404)
        p = storage.absolute(d["file_path"])
        if not p.exists():
            abort(404, "File missing on server")
        return send_file(p, as_attachment=True, download_name=p.name)

    @app.route("/claims/<int:claim_id>/portalfile/<int:pid>")
    @login_required
    def portal_file_download(claim_id, pid):
        d = db.q1("SELECT * FROM portal_files WHERE id=? AND claim_id=?", (pid, claim_id))
        if not d:
            abort(404)
        p = storage.absolute(d["file_path"])
        return send_file(p, as_attachment=True, download_name=p.name)

    @app.route("/claims/<int:claim_id>/zip")
    @login_required
    def claim_zip(claim_id):
        claim, client = _claim_ctx(claim_id)
        folder = storage.claim_dir(claim, client)
        bio = io.BytesIO()
        with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
            for p in folder.rglob("*"):
                if p.is_file():
                    z.write(p, str(p.relative_to(folder.parent)))
        bio.seek(0)
        return send_file(bio, as_attachment=True,
                         download_name=f"{storage.safe(client['legal_name'])}_{claim['period_from']}_{claim['period_to']}.zip")

    @app.route("/health")
    def health():
        return jsonify(ok=True, app=APP_NAME, version=APP_VERSION)
