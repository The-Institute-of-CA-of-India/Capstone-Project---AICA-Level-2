"""Encryption of GST portal passwords and hashing of application logins."""
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from werkzeug.security import check_password_hash, generate_password_hash

_fernet = None


def init(key_file: Path):
    global _fernet
    key_file = Path(key_file)
    if not key_file.exists():
        key_file.parent.mkdir(parents=True, exist_ok=True)
        key_file.write_bytes(Fernet.generate_key())
    _fernet = Fernet(key_file.read_bytes().strip())


def encrypt(text: str) -> str:
    if not text:
        return ""
    return _fernet.encrypt(text.encode("utf-8")).decode("ascii")


def decrypt(token: str) -> str:
    if not token:
        return ""
    try:
        return _fernet.decrypt(token.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError):
        return ""


def hash_pw(pw: str) -> str:
    return generate_password_hash(pw)


def check_pw(pw_hash: str, pw: str) -> bool:
    return check_password_hash(pw_hash, pw)
