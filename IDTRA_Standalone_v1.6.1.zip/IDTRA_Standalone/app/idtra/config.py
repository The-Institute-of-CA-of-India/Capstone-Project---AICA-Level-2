"""Configuration handling. config.ini lives in <install>/config/config.ini."""
import configparser
import os
import secrets
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent          # .../app
INSTALL_ROOT = APP_ROOT.parent                              # .../IDTRA
CONFIG_DIR = Path(os.environ.get("IDTRA_CONFIG_DIR", INSTALL_ROOT / "config"))
CONFIG_FILE = CONFIG_DIR / "config.ini"

DEFAULTS = {
    "host": "0.0.0.0",
    "port": "8765",
    "data_root": str(INSTALL_ROOT / "IDTRA_Data"),
    "threads": "12",
}


def load():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cp = configparser.ConfigParser(interpolation=None)
    if CONFIG_FILE.exists():
        cp.read(CONFIG_FILE, encoding="utf-8")
    if "server" not in cp:
        cp["server"] = {}
    changed = False
    for k, v in DEFAULTS.items():
        if k not in cp["server"]:
            cp["server"][k] = v
            changed = True
    if "secret_key" not in cp["server"]:
        cp["server"]["secret_key"] = secrets.token_hex(32)
        changed = True
    if changed:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            cp.write(f)
    s = cp["server"]
    data_root = Path(os.environ.get("IDTRA_DATA_ROOT", s["data_root"]))
    data_root.mkdir(parents=True, exist_ok=True)
    return {
        "host": s["host"],
        "port": int(s["port"]),
        "threads": int(s.get("threads", "12")),
        "data_root": data_root,
        "db_path": data_root / "_Database" / "idtra.db",
        "secret_key": s["secret_key"],
        "key_file": CONFIG_DIR / "secret.key",
    }


def save_value(key, value):
    cp = configparser.ConfigParser(interpolation=None)
    if CONFIG_FILE.exists():
        cp.read(CONFIG_FILE, encoding="utf-8")
    if "server" not in cp:
        cp["server"] = {}
    cp["server"][key] = str(value)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        cp.write(f)
