"""Books: refresh / remove imported data and the purchase-register review
(trading yes / no per line, category, blocked credit, HSN and goods description for Annexure-B)."""
from flask import abort, flash, redirect, render_template, request, url_for

from . import db, importer
from .web import _claim_ctx, _locked, _uname, login_required

CATS = ["Inputs", "Input Services", "Capital Goods"]


def register(app):

    @app.route("/claims/<int:claim_id>/refresh", methods=["POST"])
    @login_required
    def data_refresh(claim_id):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim):
            abort(403, "Claim is approved. Re-open it first.")
        done, errors = importer.refresh_all(claim, client, _uname())
        flash(f"Refreshed: {len(done)} file(s) imported again" + (f" - {', '.join(done[:10])}" if done else ""), "success")
        for e in errors:
            flash(e, "danger")
        flash("Run the reconciliation and computation again.", "info")
        return redirect(url_for("claim_view", claim_id=claim_id, tab=request.form.get("back") or "books"))

    @app.route("/claims/<int:claim_id>/books/<reg>/refresh", methods=["POST"])
    @login_required
    def books_refresh(claim_id, reg):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim) or reg not in importer.REGISTER_KINDS:
            abort(403)
        from . import storage
        bf = db.q1("SELECT * FROM book_files WHERE claim_id=? AND src_reg=?", (claim_id, reg))
        if not bf:
            flash("No stored file for this register - upload it again.", "warning")
        else:
            try:
                n, warns = importer.import_register(claim, storage.absolute(bf["file_path"]), reg, _uname())
                flash(f"{importer.REGISTER_KINDS[reg][2]} imported again: {n} lines", "success")
                for w in warns[:8]:
                    flash(w, "warning")
            except Exception as e:  # noqa: BLE001
                flash(f"Could not import again: {e}", "danger")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="books"))

    @app.route("/claims/<int:claim_id>/books/<reg>/delete", methods=["POST"])
    @login_required
    def books_delete(claim_id, reg):
        claim, client = _claim_ctx(claim_id)
        if _locked(claim) or reg not in importer.REGISTER_KINDS:
            abort(403)
        importer.delete_register(claim_id, reg, _uname())
        flash(f"{importer.REGISTER_KINDS[reg][2]} removed from this claim.", "success")
        return redirect(url_for("claim_view", claim_id=claim_id, tab="books"))

    @app.route("/claims/<int:claim_id>/purchases", methods=["GET", "POST"])
    @login_required
    def purchases_review(claim_id):
        claim, client = _claim_ctx(claim_id)
        locked = _locked(claim)
        if request.method == "POST":
            if locked:
                abort(403)
            f = request.form
            if f.get("form") == "map":
                n = 0
                for i in range(int(f.get("count", 0))):
                    key, hsn, gd = f.get(f"k_{i}", ""), (f.get(f"h_{i}") or "").strip(), (f.get(f"d_{i}") or "").strip()
                    if not key:
                        continue
                    if hsn or gd:
                        db.x("INSERT INTO hsn_map(client_id,desc_key,hsn,goods_desc,updated_by,updated_at) VALUES(?,?,?,?,?,?) "
                             "ON CONFLICT(client_id,desc_key) DO UPDATE SET hsn=excluded.hsn, goods_desc=excluded.goods_desc, "
                             "updated_by=excluded.updated_by, updated_at=excluded.updated_at",
                             (client["id"], key, hsn, gd, _uname(), db.now()))
                        n += 1
                    else:
                        db.x("DELETE FROM hsn_map WHERE client_id=? AND desc_key=?", (client["id"], key))
                importer.apply_line_settings(claim_id)
                db.audit(_uname(), "HSN map updated", claim_id, f"{n} item(s)")
                flash(f"HSN and goods description saved for {n} item(s) - kept for this client's future claims too.", "success")
            else:
                ids = [int(x) for x in f.getlist("ids")]
                cur = {r["id"]: r for r in db.q("SELECT * FROM book_purchases WHERE claim_id=? AND id IN (%s)" %
                                                 (",".join(str(i) for i in ids) or "0"), (claim_id,))}
                changed = 0
                for i in ids:
                    r = cur.get(i)
                    if not r:
                        continue
                    t = f.get(f"t_{i}", "auto")
                    tro = 1 if t == "yes" else (0 if t == "no" else None)
                    cat = f.get(f"c_{i}") or r["category"]
                    blk = 1 if f.get(f"b_{i}") else 0
                    hsn = (f.get(f"h_{i}") or "").strip()
                    gd = (f.get(f"d_{i}") or "").strip()
                    if tro == r["trade_override"] and cat == r["category"] and blk == (r["blocked_17_5"] or 0) \
                            and hsn == (r["hsn"] or "") and gd == (r["goods_desc"] or ""):
                        continue
                    db.x("INSERT INTO line_overrides(claim_id,tbl,line_key,trade_override,category,blocked,hsn,goods_desc,"
                         "updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(claim_id,tbl,line_key) DO UPDATE SET "
                         "trade_override=excluded.trade_override, category=excluded.category, blocked=excluded.blocked, "
                         "hsn=excluded.hsn, goods_desc=excluded.goods_desc, updated_by=excluded.updated_by, "
                         "updated_at=excluded.updated_at",
                         (claim_id, "P", r["line_key"], tro, cat, blk,
                          hsn if hsn != (r["hsn"] or "") or r["hsn_src"] == "user" else None,
                          gd or None, _uname(), db.now()))
                    changed += 1
                importer.apply_line_settings(claim_id)
                db.audit(_uname(), "Purchase lines reviewed", claim_id, f"{changed} line(s) changed")
                flash(f"{changed} purchase line(s) updated. Run the reconciliation and computation again.", "success")
            return redirect(url_for("purchases_review", claim_id=claim_id, **{k: v for k, v in request.args.items()}))

        q = (request.args.get("q") or "").strip().lower()
        flt = request.args.get("f", "")
        lines = db.q("SELECT * FROM book_purchases WHERE claim_id=? ORDER BY inv_date, id", (claim_id,))
        allp = lines
        if q:
            lines = [l for l in lines if q in " ".join(str(l[k] or "") for k in ("supplier_name", "supplier_gstin", "inv_no",
                                                                                   "description", "hsn", "goods_desc")).lower()]
        if flt == "nohsn":
            lines = [l for l in lines if importer._no_hsn(l["hsn"])]
        elif flt == "trading":
            lines = [l for l in lines if l["is_trading"]]
        elif flt in CATS:
            lines = [l for l in lines if l["category"] == flt]
        elif flt == "notes":
            lines = [l for l in lines if l["doc_type"] != "Invoice"]
        hmap = {m["desc_key"]: m for m in db.q("SELECT * FROM hsn_map WHERE client_id=?", (client["id"],))}
        items = {}
        for l in allp:
            k = importer.item_key(l)
            it = items.setdefault(k, {"key": k, "description": l["description"] or f"(no item text) {k}", "n": 0, "tx": 0.0, "tax": 0.0,
                                      "hsns": set(), "missing": 0, "map": hmap.get(k)})
            it["n"] += 1
            it["tx"] += l["txval"] or 0
            it["tax"] += (l["igst"] or 0) + (l["cgst"] or 0) + (l["sgst"] or 0)
            if importer._no_hsn(l["hsn"]):
                it["missing"] += 1
            else:
                it["hsns"].add(l["hsn"])
        items = sorted(items.values(), key=lambda x: (-x["missing"], -abs(x["tx"])))
        stats = {"lines": len(allp), "nohsn": sum(1 for l in allp if importer._no_hsn(l["hsn"])),
                 "trading": sum(1 for l in allp if l["is_trading"]),
                 "notes": sum(1 for l in allp if l["doc_type"] != "Invoice")}
        return render_template("purchases.html", claim=claim, client=client, lines=lines[:1000], shown=len(lines),
                               items=items, stats=stats, cats=CATS, locked=locked, q=q, flt=flt)
