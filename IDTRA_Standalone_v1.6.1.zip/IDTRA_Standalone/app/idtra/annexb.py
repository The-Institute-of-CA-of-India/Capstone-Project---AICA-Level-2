"""Annexure-B exactly as the GSTN offline utility "GST_REFUND_ANNEXURE_B.xlsb" (Version 1.0):
 - 22 columns, sheet RFD_ANNEXURE_B, data from row 20 (A..U, V = Error)
 - dropdown values copied from the utility's list sheet
 - JSON written in the same structure as the utility's 'Create File to Upload' macro
 - validations replicate the utility's 'Validate & Calculate' macro
 - max 10,000 rows per file; reversals reported only in the last file (Read Me note 9)
"""
import datetime as dt
import json
import re
from collections import OrderedDict
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from . import calc, db, law

MAX_ROWS = 10000
UTILITY_VERSION = "1.0"

T_REG = "Inward Supplies from Registered Persons"
T_RCM_REG = "Inward Supplies liable to Reverse Charge (Registered Persons)"
T_RCM_UNREG = "Inward Supplies liable to Reverse Charge (Unregistered Persons)"
T_ISD = "Inward Supplies from ISD"
T_IMPG = "Import of Goods"
T_IMPS = "Import of Services"
T_IMPG_SEZ = "Import of Goods(Supplies from SEZ to DTA)"
T_IMPS_SEZ = "Import of Services(Supplies from SEZ to DTA)"
SUPPLY_TYPES = [T_IMPG, T_IMPS, T_IMPG_SEZ, T_IMPS_SEZ, T_REG, T_RCM_REG, T_RCM_UNREG, T_ISD]
DOC_TYPES = ["Invoice/Bill of Entry", "Credit Note", "Debit Note"]
CATEGORIES = ["Inputs", "Input Services", "Capital Goods"]
YNP = ["Yes", "No", "Partially"]
IMPORTS = (T_IMPG, T_IMPS, T_IMPG_SEZ, T_IMPS_SEZ)

GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[Z1-9A-J]{1}[0-9A-Z]{1}$")
DOCNO_RE = re.compile(r"^[a-zA-Z0-9/-]{1,16}$")
BOE_RE = re.compile(r"^[0-9]{3,7}$")
HSN_RE = re.compile(r"^(?:\d{4}|\d{6}|\d{8})$")
PORT_RE = re.compile(r"^[a-zA-Z0-9]{6}$")

HEADERS = ["Sr. No. *", "Type of Inward Supply *", "Type of Document *", "GSTIN of the Supplier *",
           "Name of the Supplier *", "Document No./ Bill of Entry No. *", "Date * (dd-mm-yyyy)", "Port Code *",
           "Value *", "Category of Input Supplies *", "HSN/SAC *", "Central Tax", "State Tax / Union Territory Tax",
           "Integrated Tax", "Cess", "Total Input Tax Credit (12+13+14+15)",
           "Whether ITC blocked under Section 17(5) *", "Eligible for ITC *", "Amount of Eligible ITC *",
           "Amount of Ineligible ITC *", "2B Return Period * (mm-yyyy)", "Error"]


def _r2(v):
    return round(float(v or 0) + 0.0, 2)


def _amt(v):
    """Amount as the utility expects (string with 2 decimals), '' for blank heads."""
    return f"{_r2(v):.2f}"


def _dmy(iso):
    if not iso:
        return ""
    y, m, d = iso[:10].split("-")
    return f"{d}-{m}-{y}"


def supply_type(line):
    it = line["inward_type"]
    g = (line["supplier_gstin"] or "").strip()
    if it == "RCM":
        return T_RCM_REG if g else T_RCM_UNREG
    if it == "Import of Goods":
        return T_IMPG_SEZ if g else T_IMPG
    if it == "Import of Services":
        return T_IMPS_SEZ if g else T_IMPS
    if it == "ISD":
        return T_ISD
    return T_REG


def doc_type(line):
    return {"Credit Note": "Credit Note", "Debit Note": "Debit Note"}.get(line["doc_type"], "Invoice/Bill of Entry")


def clean_docno(s):
    return re.sub(r"[^A-Za-z0-9/-]", "", str(s or ""))


def clean_hsn(h):
    h = re.sub(r"\D", "", str(h or ""))
    if len(h) in (4, 6, 8):
        return h
    if len(h) in (5, 7):
        return h[:len(h) - 1]
    if len(h) > 8:
        return h[:8]
    return h          # < 4 digits -> validation error


def build_rows(claim, res, include_trading=False):
    """Annexure-B lines: one per invoice x category x HSN (utility Read Me point 6)."""
    lines = calc.classify_purchases(claim, res["version"])
    groups = OrderedDict()
    for l in lines:
        if l["reason"] == "Outside claim period":
            continue
        if l["bucket"] == "Trading" and not include_trading:
            continue
        st = supply_type(l)
        dtp = doc_type(l)
        b2 = db.q1("SELECT * FROM gst_2b WHERE id=?", (l["match_2b_id"],)) if l["match_2b_id"] else None
        docno = (b2["inv_no"] if b2 and b2["inv_no"] else l["inv_no"])
        docno = docno if st in (T_IMPG, T_IMPG_SEZ) else clean_docno(docno)
        key = (st, dtp, l["supplier_gstin"] or "", docno, l["inv_date"], l["category"], clean_hsn(l["hsn"]))
        g = groups.get(key)
        sign = -1.0 if dtp == "Credit Note" else 1.0      # utility takes credit notes as positive figures
        if g is None:
            g = groups[key] = dict(
                supply_type=st, doc_type=dtp, gstin=l["supplier_gstin"] or "",
                name=(l["supplier_name"] or (b2["trade_name"] if b2 else "") or "")[:100], docno=docno,
                orig_docno=l["inv_no"], date=l["inv_date"], port=(l.get("port_code") or (b2 or {}).get("port_code") or "").upper(),
                value=0.0, category=l["category"], hsn=clean_hsn(l["hsn"]), orig_hsn=l["hsn"],
                cgst=0.0, sgst=0.0, igst=0.0, cess=0.0, eligible=0.0, blocked=bool(l["blocked_17_5"]),
                period2b=law.gst_ret_period(b2["tax_period"]) if b2 else "", itc_period=l["tax_period"],
                trading=l["bucket"] == "Trading", ids=[], goods_desc="")
        g["ids"].append(l["id"])
        if not g["goods_desc"]:
            g["goods_desc"] = (l.get("goods_desc") or "").strip()
        g["value"] += sign * (l["txval"] or 0)
        for h in ("cgst", "sgst", "igst", "cess"):
            g[h] += sign * (l[h] or 0)
        if not l["blocked_17_5"] and l["bucket"] != "Excluded":
            g["eligible"] += sign * (l["e_tax"] + (l["cess"] or 0) * l["factor"])
    rows = []
    for i, g in enumerate(groups.values(), start=1):
        for h in ("value", "cgst", "sgst", "igst", "cess", "eligible"):
            g[h] = abs(_r2(g[h]))
        total = _r2(g["cgst"] + g["sgst"] + g["igst"] + g["cess"])
        elg = min(_r2(g["eligible"]), total)
        inelg = _r2(total - elg)
        if g["blocked"]:
            elg, inelg = 0.0, total
        flag = "Yes" if inelg == 0 else ("No" if elg == 0 else "Partially")
        period2b = g["period2b"]
        if not period2b and g["supply_type"] not in (T_IMPS, T_IMPS_SEZ, T_RCM_UNREG):
            period2b = law.gst_ret_period(g["itc_period"])          # RCM (registered) / ISD: month of availment
        if g["supply_type"] in (T_IMPS, T_IMPS_SEZ, T_RCM_UNREG):
            period2b = period2b or ""
        imp = g["supply_type"] in IMPORTS
        rows.append({
            "sno": i, "supply_type": g["supply_type"], "doc_type": g["doc_type"],
            "gstin": "" if g["supply_type"] in (T_IMPG, T_IMPS, T_RCM_UNREG) else g["gstin"],
            "name": g["name"], "docno": g["docno"], "orig_docno": g["orig_docno"], "date": _dmy(g["date"]),
            "port": g["port"] if g["supply_type"] in (T_IMPG, T_IMPG_SEZ) else "",
            "value": g["value"], "category": g["category"], "hsn": g["hsn"], "orig_hsn": g["orig_hsn"],
            "cgst": 0.0 if imp else g["cgst"], "sgst": 0.0 if imp else g["sgst"], "igst": g["igst"], "cess": g["cess"],
            "total": total, "blocked": "Yes" if g["blocked"] else "No", "eligible_flag": flag,
            "eligible": elg, "ineligible": inelg,
            "period2b": f"{period2b[:2]}-{period2b[2:]}" if period2b else "",
            "trading": g["trading"], "line_ids": g["ids"], "goods_desc": g["goods_desc"]})
    return rows


def validate(rows, gstin, p_from, p_to, today=None):
    """Replicates the utility's checks. Returns list of (sno, message)."""
    today = today or dt.date.today()
    to_end = dt.date.fromisoformat(law.month_end(p_to))
    errs, seen = [], {}
    for r in rows:
        def e(m):
            errs.append((r["sno"], m))
        st = r["supply_type"]
        stn_req = st not in (T_IMPG, T_IMPS, T_RCM_UNREG)
        b2_req = st not in (T_IMPS, T_IMPS_SEZ, T_RCM_UNREG)
        if stn_req and not r["gstin"]:
            e("Please Enter GSTIN of the Supplier")
        elif r["gstin"] and r["gstin"] == gstin:
            e("GSTIN of Supplier field shall not be same as the GSTIN of refund applicant")
        elif r["gstin"] and not GSTIN_RE.match(r["gstin"]):
            e("GSTIN is not available/incorrect")
        if not r["name"]:
            e("Please Enter Supplier Name")
        if st in (T_IMPG, T_IMPG_SEZ):
            if r["doc_type"] != "Invoice/Bill of Entry":
                e("Valid Document Type for selected Type of Inward Supply is Invoice/Bill of Entry")
            if not BOE_RE.match(str(r["docno"])):
                e("Please enter valid Bill of entry (min 3 digits and max 7 digits numeric value only)")
            if not PORT_RE.match(r["port"] or ""):
                e("Please Enter Port Code details for Goods (6 character alphanumeric) - add a 'Port Code' column to the purchase register")
        elif not DOCNO_RE.match(r["docno"] or ""):
            e(f"Document No. '{r['orig_docno']}' must be max 16 characters of letters, digits, / and - only")
        try:
            d = dt.datetime.strptime(r["date"], "%d-%m-%Y").date()
            if d > today:
                e("Future date is not allowed for Document Details")
            elif d < dt.date(2017, 7, 1):
                e("Document date cannot be before 01-Jul-2017")
            elif d > to_end:
                e("Document Date cannot be greater than To Return period")
        except ValueError:
            e("Please enter document date in dd-mm-yyyy format")
        if st != T_ISD and r["value"] <= 0:
            e("Please Enter the Document Value")
        if r["category"] not in CATEGORIES:
            e("Please select Category of Input supplies")
        if not HSN_RE.match(r["hsn"] or ""):
            e(f"Invalid HSN/SAC '{r['orig_hsn']}'. Please enter a code with 4, 6, or 8 digits only "
              f"(Books tab > Review purchase register > HSN and goods description)")
        if r["igst"] and (r["cgst"] or r["sgst"]):
            e("Either IGST field should be blank or (CGST and SGST) field should be blank")
        if _r2(r["eligible"] + r["ineligible"]) != _r2(r["total"]):
            e("The sum total of Amount of Eligible ITC and Amount of Ineligible ITC should be equal to the value reported in Column 16")
        if b2_req and not r["period2b"]:
            e("Please Enter 2B return period")
        key = (st, r["doc_type"], r["gstin"], r["docno"], r["date"], r["category"], r["hsn"])
        if key in seen:
            e(f"Document with Duplicate Entry in Sr. No. {seen[key]}")
        seen[key] = r["sno"]
    return errs


def summary(rows):
    """Total ITC as per invoices (credit notes deducted) - utility rows 11."""
    tot = {"cgst": 0.0, "sgst": 0.0, "igst": 0.0, "cess": 0.0}
    for r in rows:
        s = -1 if r["doc_type"] == "Credit Note" else 1
        for h in tot:
            tot[h] += s * r[h]
    return {h: _r2(v) for h, v in tot.items()}


def reversals(claim):
    """GSTR-3B Table 4(B)(1) and 4(B)(2) for the claim months."""
    months = law.months_between(claim["period_from"], claim["period_to"])
    ph = ",".join("?" for _ in months)
    r = db.q1(f"SELECT COALESCE(SUM(itcrev_cgst),0) c, COALESCE(SUM(itcrev_sgst),0) s, COALESCE(SUM(itcrev_igst),0) i, "
              f"COALESCE(SUM(itcrev_cess),0) x, COALESCE(SUM(itcrevoth_cgst),0) oc, COALESCE(SUM(itcrevoth_sgst),0) os, "
              f"COALESCE(SUM(itcrevoth_igst),0) oi, COALESCE(SUM(itcrevoth_cess),0) ox FROM gst_3b "
              f"WHERE claim_id=? AND tax_period IN ({ph})", (claim["id"], *months))
    return ({"cgst": _r2(r["c"]), "sgst": _r2(r["s"]), "igst": _r2(r["i"]), "cess": _r2(r["x"])},
            {"cgst": _r2(r["oc"]), "sgst": _r2(r["os"]), "igst": _r2(r["oi"]), "cess": _r2(r["ox"])})


def _blank0(v):
    return "" if not v else _amt(v)


def _row_values(r):
    imp = r["supply_type"] in IMPORTS
    if r["igst"]:
        c, s, i = "", "", _amt(r["igst"])
    else:
        c, s, i = ("" if imp else _blank0(r["cgst"])), ("" if imp else _blank0(r["sgst"])), ""
    return [r["sno"], r["supply_type"], r["doc_type"], r["gstin"], r["name"], r["docno"], r["date"], r["port"],
            _amt(r["value"]) if r["supply_type"] != T_ISD else "", r["category"], r["hsn"], c, s, i,
            _blank0(r["cess"]), _amt(r["total"]), r["blocked"], r["eligible_flag"], _amt(r["eligible"]),
            _amt(r["ineligible"]), r["period2b"]]


def write_xlsx(path, rows, gstin, p_from, p_to, rev, rev_oth, errors=None):
    """Same layout as the utility (rows 6-8 header, 10-14 summary, 17-19 column heads, data from row 20)
    so that A20:U can be copied and pasted (values) into GST_REFUND_ANNEXURE_B.xlsb."""
    errs = {}
    for sno, m in errors or []:
        errs.setdefault(sno, []).append(m)
    wb = Workbook()
    ws = wb.active
    ws.title = "RFD_ANNEXURE_B"
    purple = PatternFill("solid", fgColor="1F3864")
    hfont = Font(bold=True, color="FFFFFF")
    thin = Side(style="thin", color="999999")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"] = "Goods and Services Tax - Annexure-B"
    ws["A1"].font = Font(bold=True, size=14, color="1F3864")
    ws["A2"] = ("Statement of Invoices to be submitted with application for Refund of Unutilized ITC. Prepared in the "
                "layout of the GSTN offline utility GST_REFUND_ANNEXURE_B (Version 1.0): copy A20:U and paste as values "
                "into the utility, then 'Validate & Calculate' and 'Create File to Upload' - or upload the JSON produced "
                "by this application directly.")
    ws["A2"].alignment = Alignment(wrap_text=True)
    ws.merge_cells("A2:U3")
    ws["B6"], ws["D6"] = "GSTIN*", gstin
    ws["B7"], ws["D7"] = "From Return Period* (mmyyyy)", law.gst_ret_period(p_from)
    ws["B8"], ws["D8"] = "To Return Period* (mmyyyy)", law.gst_ret_period(p_to)
    for c in ("D6", "D7", "D8"):
        ws[c].number_format = "@"
        ws[c].font = Font(bold=True)
    tot = summary(rows)
    ws["K10"], ws["L10"], ws["M10"], ws["N10"], ws["O10"] = ("Particulars*", "Total Central Tax",
                                                           "Total State Tax / Union Territory Tax",
                                                           "Total Integrated Tax", "Total Cess")
    lines = [("Total ITC as per Invoices mentioned in Utility (1)", tot),
             ("Reversal as per Rules 38,42 & 43 of CGST Rules and Section 17(5) * (2)", rev),
             ("Reversals - Others * (3)", rev_oth)]
    net = {h: _r2(tot[h] - rev[h] - rev_oth[h]) for h in tot}
    lines.append(("Net Input Tax Credit after Reversals (1)-(2)-(3)", net))
    for i, (lab, v) in enumerate(lines, start=11):
        ws.cell(i, 11, lab)
        for j, h in enumerate(("cgst", "sgst", "igst", "cess"), start=12):
            c = ws.cell(i, j, v[h])
            c.number_format = "#,##0.00"
    for c in ws[10][10:15]:
        c.fill, c.font = purple, hfont
    hdr_row = 17
    for j, h in enumerate(HEADERS, start=1):
        c = ws.cell(hdr_row, j, h)
        c.fill, c.font, c.border = purple, hfont, bd
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        ws.cell(19, j, j).alignment = Alignment(horizontal="center")
        ws.cell(19, j).font = Font(bold=True, color="666666")
    ws.row_dimensions[hdr_row].height = 60
    for i, r in enumerate(rows, start=20):
        vals = _row_values(r) + ["; ".join(errs.get(r["sno"], []))]
        for j, v in enumerate(vals, start=1):
            c = ws.cell(i, j, v)
            c.border = bd
            if 4 <= j <= 21 and j != 5 and j != 10:
                c.number_format = "@"
        if errs.get(r["sno"]):
            ws.cell(i, 22).font = Font(color="C00000", bold=True)
    widths = [7, 34, 18, 18, 30, 18, 12, 9, 13, 14, 10, 12, 12, 12, 9, 13, 11, 10, 13, 13, 11, 50]
    for j, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "C20"
    n = max(20, 19 + len(rows))
    for vals, col in ((SUPPLY_TYPES, "B"), (DOC_TYPES, "C"), (CATEGORIES, "J"), (["Yes", "No"], "Q"), (YNP, "R")):
        dv = DataValidation(type="list", formula1='"' + ",".join(vals) + '"', allow_blank=True)
        if len('"' + ",".join(vals) + '"') <= 255:
            ws.add_data_validation(dv)
            dv.add(f"{col}20:{col}{n}")
    # companion sheet (not part of the utility layout): goods / service description of every line
    wd = wb.create_sheet("HSN_Goods_Description")
    wd.append(["Sr. No.", "Document No.", "Date", "Supplier", "HSN/SAC", "Goods / service description", "Category"])
    for r in rows:
        wd.append([r["sno"], r["docno"], r["date"], r["name"], r["hsn"], r.get("goods_desc", ""), r["category"]])
    for col, w in zip("ABCDEFG", (8, 18, 12, 34, 10, 40, 16)):
        wd.column_dimensions[col].width = w
    wb.save(path)
    return path


def write_json(path, rows, gstin, p_from, p_to, rev, rev_oth):
    """Identical structure to the JSON written by the utility's CreateJson macro."""
    filename = Path(path).stem
    invoices = []
    for r in rows:
        imp = r["supply_type"] in IMPORTS
        invoices.append(OrderedDict([
            ("sno", r["sno"]), ("typeOfInwardSupply", r["supply_type"]), ("istype", r["doc_type"]),
            ("stin", r["gstin"]), ("snm", r["name"]), ("inum", str(r["docno"])), ("idt", r["date"]),
            ("portCode", r["port"]), ("val", 0 if r["supply_type"] == T_ISD else _r2(r["value"])),
            ("catOfInv", r["category"]), ("hsnSac", r["hsn"] or "null"),
            ("camt", 0 if imp else _r2(r["cgst"])), ("samt", 0 if imp else _r2(r["sgst"])),
            ("iamt", _r2(r["igst"])), ("cessamt", _r2(r["cess"])), ("totCredit", _r2(r["total"])),
            ("isItcBlocked", r["blocked"]), ("elgItc", r["eligible_flag"]), ("elgItcAmt", _r2(r["eligible"])),
            ("returnPeriod2B", r["period2b"]), ("inelgItcAmt", _r2(r["ineligible"]))]))
    doc = OrderedDict([
        ("gstin", gstin), ("fromFp", law.gst_ret_period(p_from)), ("toFp", law.gst_ret_period(p_to)),
        ("version", UTILITY_VERSION),
        ("revCGST", rev["cgst"]), ("revSGST", rev["sgst"]), ("revIGST", rev["igst"]), ("revCess", rev["cess"]),
        ("revOthCGST", rev_oth["cgst"]), ("revOthSGST", rev_oth["sgst"]), ("revOthIGST", rev_oth["igst"]),
        ("revOthCess", rev_oth["cess"]),
        ("stmt", [OrderedDict([("filename", filename), ("invoices", invoices)])])])
    Path(path).write_text(json.dumps(doc, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    return path


def generate(folder, stamp, claim, client, res, include_trading=False):
    """Writes Excel + JSON part files. Returns dict with paths, counts and validation errors."""
    rows = build_rows(claim, res, include_trading)
    errs = validate(rows, client["gstin"], claim["period_from"], claim["period_to"])
    rev, rev_oth = reversals(claim)
    zero = {"cgst": 0.0, "sgst": 0.0, "igst": 0.0, "cess": 0.0}
    base = f"AnnexureB_{client['gstin']}_{law.gst_ret_period(claim['period_from'])}_{law.gst_ret_period(claim['period_to'])}"
    xlsx = write_xlsx(Path(folder) / f"{base}_{stamp}.xlsx", rows, client["gstin"], claim["period_from"],
                      claim["period_to"], rev, rev_oth, errs)
    parts = [rows[i:i + MAX_ROWS] for i in range(0, len(rows), MAX_ROWS)] or [[]]
    jsons = []
    if not errs:
        for n, part in enumerate(parts, start=1):
            last = n == len(parts)
            part = [dict(r, sno=i) for i, r in enumerate(part, start=1)]
            suffix = f"_part{n}of{len(parts)}" if len(parts) > 1 else ""
            p = write_json(Path(folder) / f"{base}{suffix}_{stamp}.json", part, client["gstin"], claim["period_from"],
                           claim["period_to"], rev if last else zero, rev_oth if last else zero)
            jsons.append(p)
    tot = summary(rows)
    return {"xlsx": xlsx, "jsons": jsons, "rows": len(rows), "errors": errs, "total": tot, "rev": rev,
            "rev_oth": rev_oth, "net": {h: _r2(tot[h] - rev[h] - rev_oth[h]) for h in tot},
            "excluded_trading": not include_trading}


def outward_statement_xlsx(path, claim, client, res):
    """Statement of invoices issued during the period for inverted rated supplies (Rule 89(2)(h))."""
    from .exports import _sheet
    months = law.months_between(claim["period_from"], claim["period_to"])
    ph = ",".join("?" for _ in months)
    groups, _ = calc.outward_groups(claim)
    inv_set = {(g["hsn"], g["rate"]) for g in groups if g["is_inverted"] and not g["restricted"]}
    sales = db.q(f"SELECT * FROM book_sales WHERE claim_id=? AND supply_type='Taxable' AND is_trading=0 "
                 f"AND tax_period IN ({ph}) ORDER BY inv_date, inv_no", (claim["id"], *months))
    rows = []
    for s in sales:
        if (s["hsn"], s["rate"]) in inv_set:
            rows.append([len(rows) + 1, s["party_gstin"], s["party_name"], s["inv_no"], _dmy(s["inv_date"]), s["hsn"],
                         s["rate"], s["txval"], s["igst"], s["cgst"], s["sgst"], s["cess"]])
    wb = Workbook()
    _sheet(wb, "Outward inverted invoices", ["Sr", "Recipient GSTIN", "Recipient", "Invoice No.", "Date", "HSN",
                                            "Rate %", "Taxable value", "IGST", "CGST", "SGST/UTGST", "Cess"],
           rows, num_cols=(7, 8, 9, 10, 11), first=True)
    wb.save(path)
    return path, len(rows)
