"""Excel workings (computation, reconciliation) and register templates."""
import json
import shutil
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import calc, config, db, law

HDR_FILL = PatternFill("solid", fgColor="4F2D7F")
HDR_FONT = Font(bold=True, color="FFFFFF")
TITLE_FONT = Font(bold=True, size=14, color="C00000")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
NUM = "#,##0.00"


def _sheet(wb, title, header, rows, num_cols=(), widths=None, first=False):
    ws = wb.active if first else wb.create_sheet()
    ws.title = title[:31]
    ws.append(header)
    for c in ws[1]:
        c.fill, c.font, c.border = HDR_FILL, HDR_FONT, BORDER
        c.alignment = Alignment(wrap_text=True, vertical="center")
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.border = BORDER
            if c.column - 1 in num_cols:
                c.number_format = NUM
    for i, h in enumerate(header, start=1):
        w = (widths or {}).get(i - 1) or min(45, max(10, len(str(h)) + 2))
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    return ws


def _dmy(iso):
    if not iso:
        return ""
    y, m, d = iso[:10].split("-")
    return f"{d}-{m}-{y}"


def annexure_b_rows(claim, res):
    version = res["version"]
    lines = calc.classify_purchases(claim, version)
    out = []
    for l in lines:
        if l["bucket"] == "Excluded" and l["reason"] == "Outside claim period":
            continue
        tot = l["tax"] + (l["cess"] or 0)
        if l["blocked_17_5"]:
            blk, elg = tot, 0.0
        else:
            blk = 0.0
            elg = l["e_tax"] if l["bucket"] in ("Inputs", "Eligible Input Services", "Input Services",
                                                "Capital Goods", "Trading") else 0.0
        inelg = round(tot - blk - elg, 2)
        flag = "Yes" if elg and abs(inelg) < 0.01 else ("Partially" if elg else "No")
        g2b = db.q1("SELECT tax_period FROM gst_2b WHERE id=?", (l["match_2b_id"],)) if l["match_2b_id"] else None
        out.append(dict(l, total_itc=round(tot, 2), blocked_itc=round(blk, 2), eligible_itc=round(elg, 2),
                        ineligible_itc=inelg, eligible_flag=flag,
                        gstr2b_period=law.gst_ret_period(g2b["tax_period"]) if g2b else "",
                        in_net_itc="Yes" if (l["bucket"] == "Inputs" or l["bucket"] == "Eligible Input Services") else "No"))
    return out


def workings_xlsx(path, claim, client, res, recon_snap):
    wb = Workbook()
    ws = wb.active
    ws.title = "Computation"
    t, sel, ref = res["turnover"], res["selected"], res["refund"]
    ws["A1"] = "Inverted Tax Duty Refund Application - Computation"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"{client['legal_name']}  |  GSTIN {client['gstin']}  |  Period {law.period_label(claim['period_from'])} to {law.period_label(claim['period_to'])}"
    ws["A3"] = res["formula_label"]
    ws["A4"] = res["formula_text"]
    rows = [
        ("Total turnover", t["total"]), ("Less: Nil / exempt / non-GST", t["exempt_total"]),
        ("Less: Turnover under rule 89(4A)/(4B)", t["less_4a4b"]), ("Adjusted Total Turnover (C)", t["att"]),
        ("Turnover of inverted rated supply before trading adjustment", t.get("inverted_before_trading", t["inverted"])),
        ("Less: deemed trading turnover (trading purchases grossed up for GP)",
         (res.get("trading_adjustment") or {}).get("deduct_inverted", 0)),
        ("Turnover of inverted rated supply (A)", t["inverted"]), ("Tax payable on inverted rated supply (B)", t["tax_inverted"]),
        ("Outward trading turnover (excluded from A)", t["trading_outward"]),
        ("Outward turnover of restricted goods (excluded from A)", t["restricted_outward"]),
        ("Net ITC (D)", sel["net_itc"]), ("ITC on inputs and input services (E)", sel["itc_inputs_services"]),
        ("A x D / C", sel["part1"]), ("Deduction", sel["part2"]), ("Maximum refund (H)", sel["max_refund"]),
        ("ECL balance - end of period (I)", res["ecl"]["end_total"]), ("ECL balance - at filing (J)", res["ecl"]["filing_total"]),
        ("REFUND ADMISSIBLE (least of H, I, J)", ref["amount"]), ("  IGST", ref["heads"]["igst"]),
        ("  CGST", ref["heads"]["cgst"]), ("  SGST/UTGST", ref["heads"]["sgst"]),
        ("90% provisional refund (Rule 91(2))", ref["provisional_90"]),
        ("Trading purchases - ITC excluded", res["trading_purchases"]["itc"]),
    ]
    for i, (k, v) in enumerate(rows, start=6):
        ws.cell(i, 1, k).border = BORDER
        c = ws.cell(i, 2, v)
        c.number_format, c.border = NUM, BORDER
        if k.startswith("REFUND"):
            ws.cell(i, 1).font = Font(bold=True, color="006100")
            c.font = Font(bold=True, color="006100")
    ws.column_dimensions["A"].width = 55
    ws.column_dimensions["B"].width = 20
    r0 = 6 + len(rows) + 2
    ws.cell(r0, 1, "Formula comparison").font = Font(bold=True)
    for j, h in enumerate(["Version", "Net ITC", "A x D / C", "Deduction", "Maximum refund"], start=1):
        c = ws.cell(r0 + 1, j, h)
        c.fill, c.font = HDR_FILL, HDR_FONT
    for i, (k, v) in enumerate(res["versions"].items(), start=r0 + 2):
        ws.cell(i, 1, law.FORMULAS[k]["short"] + (" (applied)" if k == res["version"] else ""))
        for j, key in enumerate(["net_itc", "part1", "part2", "max_refund"], start=2):
            ws.cell(i, j, v[key]).number_format = NUM
    rw = r0 + 6
    for w in res["warnings"]:
        ws.cell(rw, 1, "Note: " + w).font = Font(italic=True, color="C00000")
        rw += 1

    ta = res.get("trading_adjustment") or {}
    if ta:
        _sheet(wb, "Trading adjustment", ["Particulars", "Amount / value"], [
            ["Method", "Trading purchases + gross profit" if ta.get("method") == "gross_up" else "Identified trading sales"],
            ["Trading purchases (taxable value)", ta.get("purchases")], ["ITC on trading purchases (excluded)", ta.get("purchase_itc")],
            ["Add: opening stock of traded goods", ta.get("opening_stock")], ["Less: closing stock of traded goods", ta.get("closing_stock")],
            ["Cost of traded goods sold", ta.get("cost_sold")],
            ["Gross profit % declared by applicant", "-" if ta.get("gp_declared") is None else f"{ta.get('gp_declared')}%"],
            ["Minimum gross profit % adopted by the department", f"{ta.get('gp_minimum')}%"],
            ["Gross profit % applied (higher of the two)", f"{ta.get('gp_percent')}% {'of sales' if ta.get('gp_basis') == 'sales' else 'on cost'} ({ta.get('gp_source')})"],
            ["Deemed trading turnover", ta.get("deemed_turnover")],
            ["Deducted from turnover of inverted rated supply", ta.get("deduct_inverted")],
            ["Deducted from tax payable on inverted rated supply", ta.get("deduct_tax")], ["Tax rate used", ta.get("rate_used")],
            ["Deducted from adjusted total turnover", ta.get("deduct_att")],
            ["Identified trading sales (register)", ta.get("identified_sales")], ["Note", ta.get("note")]],
            num_cols=(1,), widths={0: 50, 1: 40})
    _sheet(wb, "Statement 1", ["Sr", "Tax period", "Turnover of inverted rated supply", "Tax payable",
                               "Adjusted total turnover", "Net ITC", "Maximum refund"],
           [[1, f"{law.period_label(claim['period_from'])} to {law.period_label(claim['period_to'])}", t["inverted"],
             t["tax_inverted"], t["att"], sel["net_itc"], sel["max_refund"]]], num_cols=(2, 3, 4, 5, 6))
    _sheet(wb, "Month-wise", ["Period", "Inverted turnover", "Tax payable", "Adjusted turnover", "Net ITC"],
           [[law.period_label(m["period"]), m["inverted_turnover"], m["tax_payable"], m["att"], m["net_itc"]]
            for m in res["months"]], num_cols=(1, 2, 3, 4))
    groups, _ = calc.outward_groups(claim)
    _sheet(wb, "Outward HSN-Rate", ["HSN", "Description", "Rate", "Taxable value", "Tax", "Trading value",
                                    "Inverted?", "Restricted notification", "Note"],
           [[g["hsn"], g["description"], g["rate"], g["txval"], g["tax"], g["trading_tx"],
             "Yes" if g["is_inverted"] else "No", g["restricted"], g["note"]] for g in groups], num_cols=(3, 4, 5))
    ab = annexure_b_rows(claim, res)
    _sheet(wb, "Purchase eligibility", ["Register", "Period", "Supplier GSTIN", "Supplier", "Invoice", "Date", "HSN",
                                        "Rate", "Category", "Inward type", "Taxable", "IGST", "CGST", "SGST",
                                        "2B match", "Bucket", "Eligible tax", "Reason"],
           [[l["register"], l["tax_period"], l["supplier_gstin"], l["supplier_name"], l["inv_no"], l["inv_date"],
             l["hsn"], l["rate"], l["category"], l["inward_type"], l["txval"], l["igst"], l["cgst"], l["sgst"],
             l["match_status"], l["bucket"], l["e_tax"], l["reason"]] for l in ab],
           num_cols=(10, 11, 12, 13, 16))
    trading = [l for l in ab if l["bucket"] == "Trading"]
    _sheet(wb, "Trading purchases", ["Supplier GSTIN", "Supplier", "Invoice", "Date", "HSN", "Taxable", "ITC"],
           [[l["supplier_gstin"], l["supplier_name"], l["inv_no"], l["inv_date"], l["hsn"], l["txval"], l["tax"]]
            for l in trading], num_cols=(5, 6))
    if recon_snap:
        _sheet(wb, "Recon Outward", ["Period", "Books taxable", "Books tax", "GSTR-1 taxable", "GSTR-1 tax",
                                     "GSTR-3B taxable", "Diff Books-GSTR1", "Diff Books-3B"],
               [[law.period_label(o["period"]), o["books_tx"], o["books_tax"], o["g1_tx"], o["g1_tax"], o["g3_tx"],
                 o["diff_g1"], o["diff_g3"]] for o in recon_snap["outward"]], num_cols=(1, 2, 3, 4, 5, 6, 7))
        _sheet(wb, "Recon ITC", ["Period", "Books eligible ITC", "GSTR-3B ITC", "GSTR-2B ITC", "Diff Books-3B"],
               [[law.period_label(o["period"]), o["books"], o["g3b"], o["g2b"], o["diff_3b"]] for o in recon_snap["itc"]],
               num_cols=(1, 2, 3, 4))
    qs = db.q("SELECT * FROM queries WHERE claim_id=? ORDER BY id", (claim["id"],))
    _sheet(wb, "Queries", ["Code", "Category", "Reference", "Description", "Amount", "Status", "Response",
                           "Resolved by", "Resolved at"],
           [[q["code"], q["category"], q["reference"], q["description"], q["amount"], q["status"], q["response"],
             q["resolved_by"], q["resolved_at"]] for q in qs], num_cols=(4,), widths={3: 70, 6: 50})
    wb.save(path)
    return path


def recon_xlsx(path, claim, client, snap):
    """Reconciliation working paper saved in 03_Reconciliation on every run."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "Reconciliation - portal data vs books of account"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"{client['legal_name']} | GSTIN {client['gstin']} | {law.period_label(claim['period_from'])} to {law.period_label(claim['period_to'])}"
    ws["A3"] = f"Run at {snap['run_at']} by {snap['run_by']} - {snap['issues']} point(s) noted"
    _sheet(wb, "Outward", ["Period", "Books taxable", "Books tax", "GSTR-1 taxable", "GSTR-1 tax", "GSTR-3B taxable",
                           "GSTR-3B tax", "Diff Books-GSTR1", "Diff tax Books-GSTR1", "Diff Books-3B"],
           [[law.period_label(o["period"]), o["books_tx"], o["books_tax"], o["g1_tx"], o["g1_tax"], o["g3_tx"],
             o["g3_tax"], o["diff_g1"], o["diff_g1_tax"], o["diff_g3"]] for o in snap["outward"]],
           num_cols=tuple(range(1, 10)))
    _sheet(wb, "Rate-wise", ["Rate", "Books", "GSTR-1", "Difference"],
           [[r["rate"], r["books"], r["gstr1"], r["diff"]] for r in snap["ratewise"]], num_cols=(1, 2, 3))
    _sheet(wb, "B2B outward diffs", ["Customer GSTIN", "Invoice (normalised)", "Books", "GSTR-1", "Difference"],
           [[d["gstin"], d["inv"], d["books"], d["gstr1"], d["diff"]] for d in snap["b2b_diff"]], num_cols=(2, 3, 4))
    _sheet(wb, "ITC", ["Period", "Books eligible", "GSTR-3B 4(A)", "GSTR-2B", "Diff Books-3B"],
           [[law.period_label(o["period"]), o["books"], o["g3b"], o["g2b"], o["diff_3b"]] for o in snap["itc"]],
           num_cols=(1, 2, 3, 4))
    bp = db.q("SELECT * FROM book_purchases WHERE claim_id=? ORDER BY supplier_gstin, inv_no", (claim["id"],))
    _sheet(wb, "Purchases vs 2B", ["Register", "Period", "Supplier GSTIN", "Supplier", "Document", "Doc type", "Date", "HSN",
                                   "Goods description", "Item in books", "Category", "Inward type", "Taxable", "IGST",
                                   "CGST", "SGST", "Trading", "Blocked", "2B status", "Note"],
           [[b["register"], b["tax_period"], b["supplier_gstin"], b["supplier_name"], b["inv_no"], b["doc_type"], b["inv_date"],
             b["hsn"], b.get("goods_desc") or "", b["description"], b["category"], b["inward_type"], b["txval"], b["igst"],
             b["cgst"], b["sgst"], "Y" if b["is_trading"] else "", "Y" if b["blocked_17_5"] else "", b["match_status"],
             b["match_note"]] for b in bp], num_cols=(12, 13, 14, 15))
    nb = db.q("SELECT * FROM gst_2b WHERE claim_id=? AND matched_book_id IS NULL ORDER BY ctin", (claim["id"],))
    _sheet(wb, "2B not in books", ["2B period", "Section", "Supplier GSTIN", "Trade name", "Document", "Date",
                                   "Taxable", "IGST", "CGST", "SGST", "ITC available"],
           [[r["tax_period"], r["section"], r["ctin"], r["trade_name"], r["inv_no"], r["inv_date"], r["txval"],
             r["igst"], r["cgst"], r["sgst"], r["itc_avl"]] for r in nb], num_cols=(6, 7, 8, 9))
    qs = db.q("SELECT * FROM queries WHERE claim_id=? ORDER BY id", (claim["id"],))
    _sheet(wb, "Queries", ["Code", "Category", "Reference", "Description", "Amount", "Status", "Response"],
           [[q["code"], q["category"], q["reference"], q["description"], q["amount"], q["status"], q["response"]]
            for q in qs], num_cols=(4,), widths={3: 70, 6: 50})
    wb.save(path)
    return path


TEMPLATES = {
    "Sales": ["Invoice No", "Invoice Date", "Party GSTIN", "Party Name", "HSN", "Description", "Rate",
              "Taxable Value", "IGST", "CGST", "SGST", "Cess", "Supply Type", "Document Type", "Trading"],
    "Purchase": ["Invoice No", "Invoice Date", "Supplier GSTIN", "Supplier Name", "HSN", "Description", "Rate",
                 "Taxable Value", "IGST", "CGST", "SGST", "Cess", "Invoice Value", "Category", "Inward Type",
                 "Document Type", "Trading", "Blocked 17(5)", "ITC Availed Date", "Port Code"],
}
TEMPLATE_NOTES = {
    "Supply Type": "Taxable / Zero Rated / Nil Rated / Exempt / Non-GST",
    "Document Type": "Invoice / Credit Note / Debit Note",
    "Trading": "Y if the goods are bought and sold as such",
    "Category": "Inputs / Input Services / Capital Goods",
    "Inward Type": "Regular / RCM / Import of Goods / Import of Services / ISD",
    "Blocked 17(5)": "Y if credit is blocked u/s 17(5)",
    "ITC Availed Date": "Date of availment in books/GSTR-3B (defaults to invoice date)",
    "Port Code": "6-character port code - only for Import of Goods (Bill of Entry number goes in Invoice No)",
    "HSN": "4, 6 or 8 digits (GST Annexure-B utility rule). One row per invoice per HSN",
    "Invoice No": "As per supplier invoice / GSTR-2B: max 16 characters, letters, digits, / and - only",
}


def register_template(path, kind):
    cols = TEMPLATES["Sales" if kind == "Sales" else "Purchase"]
    wb = Workbook()
    ws = _sheet(wb, f"{kind} Register", cols, [], first=True)
    ins = wb.create_sheet("Instructions")
    ins["A1"] = f"{kind} register template - Inverted Tax Duty Refund Application"
    ins["A1"].font = TITLE_FONT
    ins["A3"] = "Export the register from Tally (Display > Account Books > " + \
                ("Sales" if kind == "Sales" else "Purchase") + " Register > Alt+E, Excel), or paste data here."
    ins["A4"] = "The application also recognises most Tally column headings automatically; this template is the safest format."
    ins["A5"] = "One row per invoice per HSN/rate line. Credit notes may be given as negative values or with Document Type = Credit Note."
    r = 7
    for k, v in TEMPLATE_NOTES.items():
        if k in cols:
            ins.cell(r, 1, k).font = Font(bold=True)
            ins.cell(r, 2, v)
            r += 1
    ins.column_dimensions["A"].width = 22
    ins.column_dimensions["B"].width = 90
    wb.save(path)
    return path
