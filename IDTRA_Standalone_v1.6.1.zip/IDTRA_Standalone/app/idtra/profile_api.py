"""Fetch the client master (registration details) from the GST portal profile.

Clients > 'Add client from GST portal' (user ID + password only) or, in an existing client,
'Fetch details from GST portal'. The GST Portal Assistant logs in (user types the CAPTCHA), opens the
profile and sends what it reads; the user reviews the fetched details against the saved ones and applies them.
"""
import datetime as dt
import json
import secrets

from flask import abort, flash, jsonify, redirect, render_template, request, url_for

from . import db, gstprofile, parsers, security, storage
from .portal_api import ALPHABET, NOT_INSTALLED, VALID_HOURS, spawn_local
from .web import _uname, login_required

SCHEMA = """CREATE TABLE IF NOT EXISTS profile_jobs(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE, client_id INTEGER, username TEXT, password_enc TEXT,
  status TEXT DEFAULT 'waiting', log TEXT DEFAULT '', result_json TEXT, created_by TEXT, created_at TEXT, expires_at TEXT)"""

FIELDS = [("gstin", "GSTIN"), ("legal_name", "Legal name"), ("trade_name", "Trade name"), ("pan", "PAN"),
          ("state", "State"), ("constitution", "Constitution of business"), ("address", "Principal place of business"),
          ("email", "Email"), ("phone", "Mobile / phone")]


def _job(code, active=True):
    j = db.q1("SELECT * FROM profile_jobs WHERE code=?", ((code or "").strip().upper(),))
    if not j:
        abort(404)
    if active and (j["expires_at"] < db.now() or j["status"] in ("done", "cancelled", "applied")):
        abort(410)
    return j


def _log(jid, msg, status=None):
    j = db.q1("SELECT log FROM profile_jobs WHERE id=?", (jid,))
    line = f"{dt.datetime.now():%H:%M:%S}  {msg}\n"
    if status:
        db.x("UPDATE profile_jobs SET log=?, status=? WHERE id=?", ((j["log"] or "") + line, status, jid))
    else:
        db.x("UPDATE profile_jobs SET log=? WHERE id=?", ((j["log"] or "") + line, jid))


def register(app):
    db.conn().execute(SCHEMA)
    db.conn().commit()

    @app.route("/clients/fetch", methods=["GET", "POST"])
    @login_required
    def client_fetch():
        cid = request.values.get("client_id", type=int)
        client = db.q1("SELECT * FROM clients WHERE id=?", (cid,)) if cid else None
        if request.method == "POST":
            user = (request.form.get("gst_username") or (client or {}).get("gst_username") or "").strip()
            pw = request.form.get("gst_password") or (security.decrypt(client["gst_password_enc"]) if client else "")
            if not user or not pw:
                flash("Enter the GST portal user ID and password", "danger")
                return redirect(url_for("client_fetch", client_id=cid or ""))
            code = "".join(secrets.choice(ALPHABET) for _ in range(8))
            exp = (dt.datetime.now() + dt.timedelta(hours=VALID_HOURS)).strftime("%Y-%m-%d %H:%M:%S")
            jid = db.insert("profile_jobs", dict(code=code, client_id=cid, username=user, password_enc=security.encrypt(pw),
                                                 created_by=_uname(), created_at=db.now(), expires_at=exp))
            _log(jid, f"Job created by {_uname()}")
            db.audit(_uname(), "GST profile fetch started", None, f"{user} job {code}")
            cfg = app.config["IDTRA"]
            started = spawn_local(code, cfg["port"]) if cfg["host"] in ("127.0.0.1", "localhost") \
                and request.remote_addr in ("127.0.0.1", "::1") else False
            if started is None:
                flash(NOT_INSTALLED, "warning")
            elif started:
                flash("GST Portal Assistant started: the browser opens with the user ID and password filled in - type "
                      "the CAPTCHA and click LOGIN. The details appear here automatically.", "success")
            else:
                flash(f"Job code {code}: on your PC open 'GST Portal Assistant' and enter this code.", "info")
            return redirect(url_for("client_fetch_view", code=code))
        return render_template("client_fetch.html", client=client)

    @app.route("/clients/fetch/<code>")
    @login_required
    def client_fetch_view(code):
        j = _job(code, active=False)
        res = json.loads(j["result_json"]) if j["result_json"] else None
        client = db.q1("SELECT * FROM clients WHERE id=?", (j["client_id"],)) if j["client_id"] else None
        if not client and res and res.get("gstin"):
            client = db.q1("SELECT * FROM clients WHERE gstin=?", (res["gstin"],))
        sigs = db.q("SELECT * FROM client_signatories WHERE client_id=?", (client["id"],)) if client else []
        return render_template("client_fetch_view.html", j=j, res=res, client=client, fields=FIELDS, sigs=sigs)

    @app.route("/clients/fetch/<code>.json")
    @login_required
    def client_fetch_json(code):
        j = _job(code, active=False)
        return jsonify(status=j["status"], log=j["log"], ready=bool(j["result_json"]))

    @app.route("/clients/fetch/<code>/apply", methods=["POST"])
    @login_required
    def client_fetch_apply(code):
        j = _job(code, active=False)
        res = json.loads(j["result_json"] or "{}")
        f = request.form
        gstin = parsers.norm_gstin(f.get("v_gstin") or res.get("gstin"))
        if not parsers.valid_gstin(gstin):
            flash("A valid GSTIN was not fetched - complete it before saving.", "danger")
            return redirect(url_for("client_fetch_view", code=code))
        client = db.q1("SELECT * FROM clients WHERE id=?", (j["client_id"],)) if j["client_id"] else \
            db.q1("SELECT * FROM clients WHERE gstin=?", (gstin,))
        data = {}
        for k, _lab in FIELDS:
            if k == "gstin":
                continue
            col = "phone" if k == "phone" else k
            if f.get(f"use_{k}") or not client:
                v = (f.get(f"v_{k}") or "").strip()
                if v:
                    data[col] = v
        data.update(gstin=gstin, gst_username=j["username"], gst_password_enc=j["password_enc"], updated_at=db.now())
        if client:
            if data.get("legal_name") and data["legal_name"] != client["legal_name"]:
                nf = storage.client_folder_name(data["legal_name"], gstin, exclude_id=client["id"])
                if nf != client["folder_name"]:
                    storage.rename_client_folder(client["folder_name"], nf)
                    data["folder_name"] = nf
            db.update("clients", client["id"], data)
            cid = client["id"]
        else:
            data.setdefault("legal_name", gstin)
            data["pan"] = data.get("pan") or gstin[2:12]
            data["folder_name"] = storage.client_folder_name(data["legal_name"], gstin)
            data["filing_freq"] = "Monthly"
            data["created_at"] = db.now()
            cid = db.insert("clients", data)
            (storage.DATA_ROOT / data["folder_name"]).mkdir(parents=True, exist_ok=True)
        have = {s["name"].lower() for s in db.q("SELECT name FROM client_signatories WHERE client_id=?", (cid,))}
        first = not have
        for i, p in enumerate(res.get("people") or []):
            if f.get(f"person_{i}") and p["name"].lower() not in have:
                db.insert("client_signatories", dict(client_id=cid, name=p["name"], designation=p.get("designation") or "Partner",
                                                     pan=p.get("pan", ""), mobile=p.get("mobile", ""),
                                                     is_default=1 if first else 0))
                first = False
        db.x("UPDATE profile_jobs SET status='applied', client_id=? WHERE id=?", (cid, j["id"]))
        db.audit(_uname(), "Client master updated from GST portal", None, f"{gstin}")
        flash("Client master saved from the GST portal details. Check the remaining fields (filing frequency etc.).", "success")
        return redirect(url_for("client_form", cid=cid))

    # ------------------------------------------------ assistant API (auth = job code)
    @app.route("/api/profile-job/<code>")
    def api_profile_job(code):
        j = _job(code)
        db.x("UPDATE profile_jobs SET status='running' WHERE id=?", (j["id"],))
        _log(j["id"], f"Assistant connected from {request.remote_addr}")
        db.audit(j["created_by"], "Portal assistant read credentials (profile)", None, f"job {j['code']}")
        cl = db.q1("SELECT legal_name, gstin FROM clients WHERE id=?", (j["client_id"],)) if j["client_id"] else None
        return jsonify(kind="profile", client=(cl or {}).get("legal_name") or j["username"], gstin=(cl or {}).get("gstin") or "",
                       username=j["username"], password=security.decrypt(j["password_enc"]), months=[], returns=[])

    @app.route("/api/profile-job/<code>/log", methods=["POST"])
    def api_profile_log(code):
        j = _job(code)
        d = request.get_json(silent=True) or {}
        st = d.get("status") if d.get("status") in ("running", "failed") else None
        _log(j["id"], str(d.get("msg", ""))[:500], st)
        return jsonify(ok=True)

    @app.route("/api/profile-job/<code>/result", methods=["POST"])
    def api_profile_result(code):
        j = _job(code)
        d = request.get_json(silent=True) or {}
        texts = [str(t)[:200000] for t in (d.get("texts") or [])][:30]
        jsons = (d.get("jsons") or [])[:60]
        res = gstprofile.parse(texts, jsons)
        res["phone"] = res.pop("mobile", "") if res.get("mobile") else res.get("phone", "")
        got = [lab for k, lab in FIELDS if res.get(k)]
        ok = bool(res.get("gstin") and res.get("legal_name"))
        if ok or d.get("final"):
            db.x("UPDATE profile_jobs SET result_json=?, status='done' WHERE id=?", (json.dumps(res), j["id"]))
            _log(j["id"], f"Details received: {', '.join(got) or 'none'}; {len(res.get('people', []))} partner(s)/signatory(ies)")
        return jsonify(ok=ok, found=got, people=len(res.get("people", [])), gstin=res.get("gstin", ""),
                       legal_name=res.get("legal_name", ""))
