"""Law reference data: Rule 89(5) formula versions, restricted goods under
Notification 5/2017-CT(R) (as amended), time limits and period helpers.

Law position captured up to Notification 05/2026-Central Tax dated 26.10.2026.
The restricted goods table is editable from the "Law Library" screen so the
firm can keep it current without a code change.
"""
import calendar
import datetime as dt

from . import db

FORMULAS = {
    "V2018": {
        "label": "Rule 89(5) as amended by N/N 26/2018-CT (applications filed up to 04.07.2022)",
        "short": "Pre-July 2022 formula",
        "text": "Maximum Refund = (Inverted turnover x Net ITC / Adjusted Total Turnover) - Tax payable on inverted rated supply",
        "net_itc": "ITC availed on inputs (goods) only; input services and capital goods excluded",
        "valid_from": "2018-06-13", "valid_to": "2022-07-04",
    },
    "V2022": {
        "label": "Rule 89(5) as amended by N/N 14/2022-CT dt 05.07.2022 (applications filed 05.07.2022 to 31.10.2026)",
        "short": "July 2022 formula",
        "text": "Maximum Refund = (Inverted turnover x Net ITC / ATT) - {Tax payable on inverted rated supply x (Net ITC / ITC availed on inputs and input services)}",
        "net_itc": "ITC availed on inputs (goods) only; input services and capital goods excluded",
        "valid_from": "2022-07-05", "valid_to": "2026-10-31",
    },
    "V2026": {
        "label": "Rule 89(5) as substituted by N/N 05/2026-CT dt 26.10.2026 (applications filed on/after 01.11.2026)",
        "short": "November 2026 formula",
        "text": "Maximum Refund = (Inverted turnover x Net ITC / ATT) - Tax payable on inverted rated supply",
        "net_itc": "ITC on inputs + eligible input services (ITC availed on or after 01.11.2026); capital goods attributable to the relevant period (ITC availed on or after 01.04.2027, 1/60th per month)",
        "valid_from": "2026-11-01", "valid_to": "9999-12-31",
    },
}

INPUT_SERVICE_CUTOFF = "2026-11-01"   # Explanation (ii) to Rule 89(5) as substituted
CAPITAL_GOODS_CUTOFF = "2027-04-01"   # Rule 89(4)(B)/(G) w.e.f. 01.04.2027
PROSECUTION_DECL_FROM = "2026-12-01"  # Rule 89(2)(o) w.e.f. 01.12.2026
CG_DECL_FROM = "2027-04-01"           # Rule 89(2)(p) w.e.f. 01.04.2027
MIN_REFUND = 1000                     # Section 54(14)

LAW_NOTES = [
    "Section 54(3)(ii) CGST Act - refund of unutilised ITC where rate of tax on inputs is higher than rate on output supplies (other than nil rated / fully exempt).",
    "Rule 89(5) CGST Rules - formula; version applied depends on the date of filing (see Formula versions). N/N 05/2026-CT substituted Rule 89(5) w.e.f. 01.11.2026.",
    "Rule 89(4)(E) - Adjusted Total Turnover excludes exempt supplies (other than zero-rated) and turnover of supplies for which refund is claimed under Rule 89(4A)/(4B).",
    "Rule 89(3) as substituted by N/N 05/2026-CT - credit ledger debited first from IGST, then CGST and SGST/UTGST equally, shortfall in one head met from the other.",
    "Notification 5/2017-CT(R) as amended by 29/2017, 44/2017, 20/2018, 9/2022 and 20/2023 - goods on which IDS refund is not allowed.",
    "Notification 15/2017-CT(R) (as amended) - no IDS refund for the construction services notified therein (flagged as 'Warn' for SAC 9954 - verify the entry).",
    "Circular 135/05/2020-GST - no IDS refund where input and output supplies are the same; refund restricted to ITC on invoices reflected in GSTR-2A/2B. Annexure-B must carry HSN/SAC.",
    "Section 16(2)(aa) - ITC only on invoices furnished by supplier and communicated in GSTR-2B (from 01.01.2022).",
    "Circular 125/44/2019-GST - master refund circular; Annexure-B statement of inward invoices.",
    "Section 54(1) read with Explanation 2(e) - application within two years from the due date of the return u/s 39 for the period in which the claim arises.",
    "Section 54(6) / Rule 91(2) - 90% provisional refund for IDS claims (Instruction 6/2025-GST for claims filed on/after 01.10.2025; Section 54(6) amended by Finance Act 2026).",
    "Section 54(14) - no refund if amount is less than Rs 1,000.",
    "GSTN advisory (May 2026) - Annexure-B to be prepared in the offline utility and uploaded as JSON with additional fields (type of inward supply, document type, total / blocked u/s 17(5) / eligible / ineligible ITC, GSTR-2B return period).",
]

RESTRICTED_SEED = [
    # hsn_prefix, description, notification, eff_from, eff_to, action, note
    ("1507", "Soya-bean oil and its fractions", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1508", "Ground-nut oil and its fractions", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1509", "Olive oil and its fractions", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1510", "Other oils obtained solely from olives", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1511", "Palm oil and its fractions", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1512", "Sunflower-seed, safflower or cotton-seed oil", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1513", "Coconut, palm kernel or babassu oil", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1514", "Rape, colza or mustard oil", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1515", "Other fixed vegetable or microbial fats and oils", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1516", "Hydrogenated / interesterified vegetable fats and oils", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1517", "Edible mixtures or preparations of vegetable fats/oils", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("1518", "Chemically modified vegetable fats and oils", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("2701", "Coal; briquettes and similar solid fuels from coal", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("2702", "Lignite", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("2703", "Peat", "9/2022-CT(R)", "2022-07-18", "", "Exclude", ""),
    ("5605", "Imitation zari thread/yarn of metallised polyester/plastic film", "20/2023-CT(R)", "2023-10-20", "", "Exclude", ""),
    ("8601", "Rail locomotives (external electricity / accumulators)", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8602", "Other rail locomotives and tenders", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8603", "Self-propelled railway/tramway coaches, vans, trucks", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8604", "Railway/tramway maintenance or service vehicles", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8605", "Railway/tramway passenger and special purpose coaches", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8606", "Railway/tramway goods vans and wagons", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8607", "Parts of railway/tramway locomotives or rolling stock", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("8608", "Railway track fixtures, signalling and safety equipment", "5/2017-CT(R)", "2017-07-01", "", "Exclude", ""),
    ("5007", "Woven fabrics of silk", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", "Refund allowed for ITC on supplies received on/after 01.08.2018"),
    ("5111", "Woven fabrics of wool (5111-5113)", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", "Refund allowed from 01.08.2018"),
    ("5112", "Woven fabrics of wool", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", "Refund allowed from 01.08.2018"),
    ("5113", "Woven fabrics of animal hair", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", "Refund allowed from 01.08.2018"),
    ("5208", "Woven fabrics of cotton (5208-5212)", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", "Refund allowed from 01.08.2018"),
    ("5209", "Woven fabrics of cotton", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5210", "Woven fabrics of cotton", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5211", "Woven fabrics of cotton", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5212", "Woven fabrics of cotton", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5309", "Woven fabrics of flax", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5310", "Woven fabrics of jute", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5311", "Woven fabrics of other vegetable fibres", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5407", "Woven fabrics of synthetic filament yarn", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5408", "Woven fabrics of artificial filament yarn", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5512", "Woven fabrics of synthetic staple fibres (5512-5516)", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5513", "Woven fabrics of synthetic staple fibres", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5514", "Woven fabrics of synthetic staple fibres", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5515", "Other woven fabrics of synthetic staple fibres", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5516", "Woven fabrics of artificial staple fibres", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("5608", "Knotted netting; made up fishing nets", "5/2017-CT(R) proviso (20/2018)", "2017-11-15", "2018-07-31", "Exclude", ""),
    ("5801", "Corduroy fabrics", "5/2017-CT(R) proviso (20/2018)", "2017-11-15", "2018-07-31", "Exclude", ""),
    ("5806", "Narrow woven fabrics", "5/2017-CT(R) proviso (20/2018)", "2017-11-15", "2018-07-31", "Exclude", ""),
    ("60", "Knitted or crocheted fabrics (Chapter 60)", "5/2017-CT(R) proviso (20/2018)", "2017-07-01", "2018-07-31", "Exclude", ""),
    ("9954", "Construction services (only entries notified in N/N 15/2017-CT(R))", "15/2017-CT(R)", "2017-07-01", "", "Warn", "Check whether the service falls in the notified construction entries"),
]


def seed_restricted_goods():
    if db.q1("SELECT COUNT(*) AS n FROM restricted_goods")["n"]:
        return
    db.xmany("INSERT INTO restricted_goods(hsn_prefix,description,notification,effective_from,effective_to,applies_to,note) "
             "VALUES(?,?,?,?,?,?,?)", RESTRICTED_SEED)


def restricted_for(hsn, period_from, period_to):
    """Return restricted-goods row matching an HSN for a period, or None."""
    if not hsn:
        return None
    h = str(hsn).strip()
    for r in db.q("SELECT * FROM restricted_goods WHERE active=1 ORDER BY LENGTH(hsn_prefix) DESC"):
        if not h.startswith(r["hsn_prefix"]):
            continue
        ef = r["effective_from"] or "0000-00-00"
        et = r["effective_to"] or "9999-12-31"
        if ef <= period_to + "-31" and et >= period_from + "-01":
            return r
    return None


def formula_for_filing_date(filing_date: str) -> str:
    fd = filing_date or dt.date.today().isoformat()
    for k in ("V2026", "V2022", "V2018"):
        f = FORMULAS[k]
        if f["valid_from"] <= fd <= f["valid_to"]:
            return k
    return "V2018"


# ---------------- period helpers ----------------
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def months_between(p_from: str, p_to: str):
    y, m = map(int, p_from.split("-"))
    y2, m2 = map(int, p_to.split("-"))
    out = []
    while (y, m) <= (y2, m2):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def fy_of(period: str) -> str:
    y, m = map(int, period.split("-"))
    start = y if m >= 4 else y - 1
    return f"{start}-{str(start + 1)[-2:]}"


def fy_months(fy: str):
    start = int(fy[:4])
    return months_between(f"{start}-04", f"{start + 1}-03")


def period_label(p: str) -> str:
    y, m = map(int, p.split("-"))
    return f"{MONTHS[m - 1]}-{y}"


def gst_ret_period(p: str) -> str:
    """'2026-04' -> '042026' (format used in GST JSON)."""
    y, m = p.split("-")
    return f"{m}{y}"


def from_ret_period(rp: str) -> str:
    rp = str(rp).strip()
    if len(rp) == 6 and rp.isdigit():
        return f"{rp[2:]}-{rp[:2]}"
    return ""


def due_date_3b(period: str, freq: str = "Monthly") -> dt.date:
    y, m = map(int, period.split("-"))
    if freq.startswith("Quarterly"):
        qend = {1: 3, 2: 3, 3: 3, 4: 6, 5: 6, 6: 6, 7: 9, 8: 9, 9: 9, 10: 12, 11: 12, 12: 12}[m]
        ny, nm = (y + 1, 1) if qend == 12 else (y, qend + 1)
        day = 24 if "24" in freq else 22
        return dt.date(ny, nm, day)
    ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
    return dt.date(ny, nm, 20)


def add_years(d: dt.date, n: int) -> dt.date:
    try:
        return d.replace(year=d.year + n)
    except ValueError:
        return d.replace(year=d.year + n, day=28)


def time_limit(period_from: str, period_to: str, freq: str):
    """Last date to file for each month (2 years from relevant date)."""
    rows = []
    for p in months_between(period_from, period_to):
        rd = due_date_3b(p, freq)
        rows.append({"period": p, "relevant_date": rd.isoformat(),
                     "last_date": add_years(rd, 2).isoformat()})
    return rows


def month_end(p: str) -> str:
    y, m = map(int, p.split("-"))
    return f"{p}-{calendar.monthrange(y, m)[1]:02d}"
