"""SQLite database layer. The database file lives only on the server machine."""
import datetime as _dt
import json
import sqlite3
import threading
from pathlib import Path

_DB_PATH = None
_local = threading.local()

SCHEMA = r"""
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT,
  pw_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'staff', active INTEGER DEFAULT 1,
  created_at TEXT);

CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS ca_master(
  id INTEGER PRIMARY KEY, firm_name TEXT NOT NULL, frn TEXT, ca_name TEXT NOT NULL,
  membership_no TEXT NOT NULL, designation TEXT DEFAULT 'Partner', address TEXT, city TEXT,
  email TEXT, phone TEXT, active INTEGER DEFAULT 1, created_at TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS clients(
  id INTEGER PRIMARY KEY, legal_name TEXT NOT NULL, trade_name TEXT, gstin TEXT NOT NULL UNIQUE,
  pan TEXT, state TEXT, constitution TEXT, address TEXT, email TEXT, phone TEXT,
  filing_freq TEXT DEFAULT 'Monthly', gst_username TEXT, gst_password_enc TEXT,
  folder_name TEXT, notes TEXT, active INTEGER DEFAULT 1, created_at TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS client_signatories(
  id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL, designation TEXT DEFAULT 'Partner', pan TEXT, email TEXT, mobile TEXT,
  is_default INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS claims(
  id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
  fy TEXT NOT NULL, period_from TEXT NOT NULL, period_to TEXT NOT NULL,
  filing_date TEXT, status TEXT DEFAULT 'Draft', formula_version TEXT, formula_override_reason TEXT,
  signatory_id INTEGER, ca_id INTEGER, udin TEXT, udin_date TEXT,
  approved_by TEXT, approved_at TEXT, folder TEXT, notes TEXT, options_json TEXT DEFAULT '{}',
  created_by TEXT, created_at TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS portal_files(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  return_type TEXT NOT NULL, tax_period TEXT NOT NULL, file_path TEXT, summary_json TEXT,
  imported_by TEXT, imported_at TEXT);

CREATE TABLE IF NOT EXISTS gst_outward(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tax_period TEXT, section TEXT, ctin TEXT, inv_no TEXT, inv_norm TEXT, inv_date TEXT, inv_value REAL,
  pos TEXT, rate REAL, txval REAL, igst REAL, cgst REAL, sgst REAL, cess REAL);

CREATE TABLE IF NOT EXISTS gst_hsn(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tax_period TEXT, table_type TEXT, hsn TEXT, description TEXT, uqc TEXT, qty REAL, rate REAL,
  txval REAL, igst REAL, cgst REAL, sgst REAL, cess REAL);

CREATE TABLE IF NOT EXISTS gst_2b(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tax_period TEXT, section TEXT, doc_type TEXT, ctin TEXT, trade_name TEXT, inv_no TEXT, inv_norm TEXT,
  inv_date TEXT, inv_value REAL, rate REAL, txval REAL, igst REAL, cgst REAL, sgst REAL, cess REAL,
  itc_avl TEXT, rev TEXT, matched_book_id INTEGER);

CREATE TABLE IF NOT EXISTS gst_3b(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tax_period TEXT NOT NULL, source TEXT,
  osup_txval REAL DEFAULT 0, osup_igst REAL DEFAULT 0, osup_cgst REAL DEFAULT 0, osup_sgst REAL DEFAULT 0, osup_cess REAL DEFAULT 0,
  zero_txval REAL DEFAULT 0, zero_igst REAL DEFAULT 0, nil_exempt REAL DEFAULT 0, non_gst REAL DEFAULT 0,
  rcm_txval REAL DEFAULT 0,
  itc_igst REAL DEFAULT 0, itc_cgst REAL DEFAULT 0, itc_sgst REAL DEFAULT 0, itc_cess REAL DEFAULT 0,
  itcrev_igst REAL DEFAULT 0, itcrev_cgst REAL DEFAULT 0, itcrev_sgst REAL DEFAULT 0, itcrev_cess REAL DEFAULT 0,
  UNIQUE(claim_id, tax_period));

CREATE TABLE IF NOT EXISTS book_sales(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tax_period TEXT, inv_no TEXT, inv_norm TEXT, inv_date TEXT, party_gstin TEXT, party_name TEXT,
  hsn TEXT, description TEXT, rate REAL, txval REAL, igst REAL, cgst REAL, sgst REAL, cess REAL,
  supply_type TEXT DEFAULT 'Taxable', doc_type TEXT DEFAULT 'Invoice', is_trading INTEGER DEFAULT 0,
  src_row INTEGER);

CREATE TABLE IF NOT EXISTS book_purchases(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  register TEXT DEFAULT 'Purchase', tax_period TEXT, supplier_gstin TEXT, supplier_name TEXT,
  inv_no TEXT, inv_norm TEXT, inv_date TEXT, inv_value REAL, hsn TEXT, description TEXT, rate REAL,
  txval REAL, igst REAL, cgst REAL, sgst REAL, cess REAL,
  category TEXT DEFAULT 'Inputs', inward_type TEXT DEFAULT 'Regular', doc_type TEXT DEFAULT 'Invoice',
  itc_availed_date TEXT, blocked_17_5 INTEGER DEFAULT 0, is_trading INTEGER DEFAULT 0,
  match_status TEXT, match_2b_id INTEGER, match_note TEXT, src_row INTEGER);

CREATE TABLE IF NOT EXISTS ecl_balances(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  kind TEXT NOT NULL, igst REAL DEFAULT 0, cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, cess REAL DEFAULT 0,
  as_on TEXT, UNIQUE(claim_id, kind));

CREATE TABLE IF NOT EXISTS outward_flags(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  hsn TEXT, rate REAL, is_inverted INTEGER, note TEXT, UNIQUE(claim_id, hsn, rate));

CREATE TABLE IF NOT EXISTS trading_hsn(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  hsn TEXT NOT NULL, UNIQUE(claim_id, hsn));

CREATE TABLE IF NOT EXISTS queries(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  code TEXT, category TEXT, reference TEXT, description TEXT, amount REAL, status TEXT DEFAULT 'Open',
  response TEXT, raised_by TEXT, raised_at TEXT, resolved_by TEXT, resolved_at TEXT);

CREATE TABLE IF NOT EXISTS calculations(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  formula_version TEXT, result_json TEXT, is_final INTEGER DEFAULT 0, created_by TEXT, created_at TEXT);

CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  doc_type TEXT, file_path TEXT, sha256 TEXT, created_by TEXT, created_at TEXT);

CREATE TABLE IF NOT EXISTS restricted_goods(
  id INTEGER PRIMARY KEY, hsn_prefix TEXT NOT NULL, description TEXT, notification TEXT,
  effective_from TEXT, effective_to TEXT, applies_to TEXT DEFAULT 'All', note TEXT, active INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts TEXT, username TEXT, action TEXT, claim_id INTEGER, detail TEXT);

CREATE TABLE IF NOT EXISTS notices(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  notice_type TEXT, ref_no TEXT, notice_date TEXT, received_date TEXT, due_date TEXT, arn TEXT, arn_date TEXT,
  amount_claimed REAL, amount_proposed REAL, officer TEXT, file_path TEXT, notice_text TEXT,
  status TEXT DEFAULT 'Received', hearing_date TEXT, hearing_notes TEXT, reply_date TEXT, reply_ack TEXT,
  order_ref TEXT, order_date TEXT, order_result TEXT, amount_sanctioned REAL, amount_rejected REAL,
  notes TEXT, created_by TEXT, created_at TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS notice_grounds(
  id INTEGER PRIMARY KEY, notice_id INTEGER NOT NULL REFERENCES notices(id) ON DELETE CASCADE,
  code TEXT, title TEXT, allegation TEXT, reply_text TEXT, include INTEGER DEFAULT 1, auto INTEGER DEFAULT 1,
  sort INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS notice_files(
  id INTEGER PRIMARY KEY, notice_id INTEGER NOT NULL REFERENCES notices(id) ON DELETE CASCADE,
  kind TEXT, file_path TEXT, created_by TEXT, created_at TEXT);

CREATE TABLE IF NOT EXISTS book_files(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  src_reg TEXT, file_path TEXT, lines INTEGER, imported_by TEXT, imported_at TEXT);

CREATE TABLE IF NOT EXISTS line_overrides(
  id INTEGER PRIMARY KEY, claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  tbl TEXT, line_key TEXT, trade_override INTEGER, category TEXT, blocked INTEGER, hsn TEXT, goods_desc TEXT,
  updated_by TEXT, updated_at TEXT, UNIQUE(claim_id, tbl, line_key));

CREATE TABLE IF NOT EXISTS hsn_map(
  id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  desc_key TEXT, hsn TEXT, goods_desc TEXT, updated_by TEXT, updated_at TEXT, UNIQUE(client_id, desc_key));

CREATE INDEX IF NOT EXISTS ix_bp_claim ON book_purchases(claim_id);
CREATE INDEX IF NOT EXISTS ix_bs_claim ON book_sales(claim_id);
CREATE INDEX IF NOT EXISTS ix_2b_claim ON gst_2b(claim_id);
CREATE INDEX IF NOT EXISTS ix_out_claim ON gst_outward(claim_id);
"""


def now():
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def init(db_path):
    global _DB_PATH
    _DB_PATH = Path(db_path)
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(_DB_PATH)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    # ---- upgrades for databases created by earlier versions
    migrations = {
        "book_purchases": [("port_code", "TEXT"), ("src_reg", "TEXT"), ("ledger", "TEXT"), ("item", "TEXT"),
                           ("goods_desc", "TEXT"), ("hsn_src", "TEXT"), ("trading_manual", "INTEGER"),
                           ("trade_file", "INTEGER"), ("trade_override", "INTEGER"), ("line_key", "TEXT"),
                           ("books_hsn", "TEXT")],
        "book_sales": [("src_reg", "TEXT"), ("ledger", "TEXT"), ("item", "TEXT"), ("goods_desc", "TEXT"), ("hsn_src", "TEXT"),
                       ("trade_file", "INTEGER")],
        "gst_2b": [("port_code", "TEXT"), ("hsn", "TEXT"), ("hsn_desc", "TEXT")],
        "gst_outward": [("orig_inv", "TEXT"), ("orig_ctin", "TEXT"), ("orig_period", "TEXT"), ("amend_note", "TEXT")],
        "gst_3b": [("itcrevoth_igst", "REAL DEFAULT 0"), ("itcrevoth_cgst", "REAL DEFAULT 0"),
                   ("itcrevoth_sgst", "REAL DEFAULT 0"), ("itcrevoth_cess", "REAL DEFAULT 0")],
    }
    for table, cols in migrations.items():
        have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
        for col, typ in cols:
            if col not in have:
                con.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    con.commit()
    con.close()
    from . import law
    law.seed_restricted_goods()


def conn():
    c = getattr(_local, "con", None)
    if c is None:
        c = sqlite3.connect(_DB_PATH, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys = ON")
        c.execute("PRAGMA busy_timeout = 30000")
        _local.con = c
    return c


def q(sql, args=()):
    return [dict(r) for r in conn().execute(sql, args).fetchall()]


def q1(sql, args=()):
    r = conn().execute(sql, args).fetchone()
    return dict(r) if r else None


def x(sql, args=()):
    c = conn()
    cur = c.execute(sql, args)
    c.commit()
    return cur.lastrowid


def xmany(sql, rows):
    c = conn()
    c.executemany(sql, rows)
    c.commit()


def insert(table, data: dict):
    cols = ",".join(data.keys())
    ph = ",".join("?" for _ in data)
    return x(f"INSERT INTO {table}({cols}) VALUES({ph})", tuple(data.values()))


def update(table, row_id, data: dict):
    sets = ",".join(f"{k}=?" for k in data)
    x(f"UPDATE {table} SET {sets} WHERE id=?", tuple(data.values()) + (row_id,))


def get_setting(key, default=""):
    r = q1("SELECT value FROM settings WHERE key=?", (key,))
    return r["value"] if r else default


def set_setting(key, value):
    x("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
      (key, value))


def audit(username, action, claim_id=None, detail=""):
    x("INSERT INTO audit_log(ts,username,action,claim_id,detail) VALUES(?,?,?,?,?)",
      (now(), username, action, claim_id, detail if isinstance(detail, str) else json.dumps(detail)))
