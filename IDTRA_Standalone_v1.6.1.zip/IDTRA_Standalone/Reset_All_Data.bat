@echo off
echo This DELETES all data of the standalone trial (database, client folders, encryption key)
echo so that you can start again from scratch. The program itself is kept.
choice /M "Delete all trial data"
if errorlevel 2 exit /b
call "%~dp0Stop_IDTRA.bat"
rmdir /s /q "%~dp0IDTRA_Data" 2>nul
del /q "%~dp0config\idtra*.db" 2>nul
del /q "%~dp0config\secret.key" 2>nul
del /q "%~dp0config\config.ini" 2>nul
copy /y "%~dp0config_template.ini" "%~dp0config\config.ini" >nul
echo All trial data deleted.
pause
