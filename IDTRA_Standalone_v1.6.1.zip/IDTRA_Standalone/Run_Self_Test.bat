@echo off
title IDTRA - Self test on this computer
rem Runs the complete automated test suite on THIS Windows computer using the installed
rem Python environment. Uses temporary folders only - your real data is not touched.
cd /d "%~dp0selftest"
set PYTHONIOENCODING=utf-8
echo Running engine tests (refund formula, reconciliation, Annexure-B, Word/Excel output)...
"%~dp0venv\Scripts\python.exe" test_engine.py > "%TEMP%\idtra_selftest.log" 2>&1
if errorlevel 1 goto fail
echo Running full workflow tests through the web application...
"%~dp0venv\Scripts\python.exe" test_web.py >> "%TEMP%\idtra_selftest.log" 2>&1
if errorlevel 1 goto fail
echo.
echo   SELF TEST PASSED - the application works correctly on this computer.
echo.
if "%1"=="/quiet" exit /b 0
pause
exit /b 0
:fail
echo.
echo   SELF TEST FAILED. Details: %TEMP%\idtra_selftest.log
echo   Please send that log file to your developer.
echo.
if "%1"=="/quiet" exit /b 1
notepad "%TEMP%\idtra_selftest.log"
pause
exit /b 1
