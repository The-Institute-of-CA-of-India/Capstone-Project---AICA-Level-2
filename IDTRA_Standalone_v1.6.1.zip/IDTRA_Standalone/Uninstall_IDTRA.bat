@echo off
title Uninstall - Inverted Tax Duty Refund Application (Standalone)
echo This removes the standalone application in this folder:
echo   - stops the program, removes the desktop icon and the program files
echo   - asks whether your DATA (database, client folders) should also be deleted
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall_standalone.ps1" -Folder "%~dp0."
pause
