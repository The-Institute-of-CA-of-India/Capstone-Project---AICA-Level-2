@echo off
title Inverted Tax Duty Refund Application (Standalone)
cd /d "%~dp0"
set "IDTRA_CONFIG_DIR=%~dp0config"
set "IDTRA_DATA_ROOT=%~dp0IDTRA_Data"
set "URL=http://127.0.0.1:8765"

if not exist "%~dp0venv\installed_v1.6.1.txt" (
  echo Setting up / updating to version 1.6.1. This takes 2-5 minutes, only once.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_standalone.ps1"
  if errorlevel 1 (
    echo.
    echo Setup did not complete. Read the message above.
    pause
    exit /b 1
  )
)

rem already running? - only reuse it if it is THIS version; an older copy still running is stopped first
powershell -NoProfile -Command "try{$r=Invoke-WebRequest -UseBasicParsing '%URL%/health' -TimeoutSec 2; if($r.Content -match '\"1\.6\.1\"'){exit 0}else{exit 2}}catch{exit 1}" >nul 2>&1
if errorlevel 2 (
  echo An older version of the application is still running - stopping it...
  powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name like 'python%%'\" | Where-Object { $_.CommandLine -like '*idtra.server*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
  timeout /t 3 >nul
  goto start
)
if not errorlevel 1 goto open

:start

echo Starting the application...
start "" /d "%~dp0app" "%~dp0venv\Scripts\pythonw.exe" -m idtra.server
powershell -NoProfile -Command "for($i=0;$i -lt 30;$i++){try{$r=Invoke-WebRequest -UseBasicParsing '%URL%/health' -TimeoutSec 2; exit 0}catch{Start-Sleep -Milliseconds 700}}; exit 1" >nul 2>&1
if errorlevel 1 (
  echo The application did not start. Running it in this window to show the error:
  cd /d "%~dp0app"
  "%~dp0venv\Scripts\python.exe" -m idtra.server
  pause
  exit /b 1
)

:open
call "%~dp0Open_IDTRA.cmd"
exit /b 0
