"""
Core automated tests (no GUI). Run from the project folder:

    python -m unittest discover -s tests -v

Each test class uses a fresh temporary data folder (CA_PM_HOME), so your real
database is never touched.
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest
from datetime import date, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = tempfile.mkdtemp(prefix="ca_pm_test_")
os.environ["CA_PM_HOME"] = TMP
sys.path.insert(0, ROOT)

import config  # noqa: E402

config.BASE_DIR = TMP
config.DATA_DIR = os.path.join(TMP, "data")
config.LOG_DIR = os.path.join(TMP, "logs")
config.TEMPLATE_DIR = os.path.join(config.DATA_DIR, "templates")
config.EXPORT_DIR = os.path.join(TMP, "exports")
config.LOCAL_CONFIG_FILE = os.path.join(config.DATA_DIR, "app_config.json")
_defaults = {"db_path": os.path.join(TMP, "data", "ca_firm.db"),
             "documents_dir": os.path.join(TMP, "documents", "CA_Firm_Data"),
             "backup_dir": os.path.join(TMP, "backups")}
config.default_local_config = lambda: dict(_defaults)  # type: ignore[assignment]
config.ensure_dirs()

from app.database.db import init_database, session_scope  # noqa: E402
from app.services import (auth_service, backup_service, client_service, collection_service,  # noqa: E402
                          compliance_engine, document_service, notice_service, reminder_engine,
                          reporting_service, settings_service, task_service)
from app.utils import validators  # noqa: E402
from app.utils.date_utils import fy_of, generate_periods  # noqa: E402

init_database()
FY = "2026-27"


def make_gstin(state: str, pan: str) -> str:
    g14 = f"{state}{pan}1Z"
    return g14 + validators.gstin_checksum(g14)


def new_client(**kw) -> int:
    data = {"client_name": kw.pop("client_name", "Test Traders"), "entity_type": kw.pop("entity_type", "Proprietorship"),
            "pan": kw.pop("pan", "ABCPT1234K"), "status": "Active"}
    data.update(kw)
    return client_service.save_client(data)


class T01Validators(unittest.TestCase):
    def test_pan_tan_gstin(self):
        self.assertIsNone(validators.validate_pan("ABCDE1234F"))
        self.assertIsNotNone(validators.validate_pan("ABC123"))
        self.assertIsNone(validators.validate_tan("MUMA12345B"))
        g = make_gstin("27", "ABCDE1234F")
        self.assertIsNone(validators.validate_gstin(g))
        self.assertIsNotNone(validators.validate_gstin(g[:-1] + ("A" if g[-1] != "A" else "B")))


class T02Clients(unittest.TestCase):
    def test_client_creation(self):
        cid = new_client(client_name="Alpha Traders", pan="AAAPA1111A")
        c = client_service.get_client(cid)
        self.assertEqual(c["client_name"], "Alpha Traders")
        self.assertTrue(c["client_code"].startswith(config.CLIENT_CODE_PREFIX))
        self.assertTrue(os.path.isdir(document_service.client_folder(cid)))

    def test_duplicate_pan_detection(self):
        new_client(client_name="Dup One", pan="DUPPD1234D")
        d = client_service.find_duplicates("DUPPD1234D", None)
        self.assertEqual(len(d["pan"]), 1)
        with self.assertRaises(ValueError):
            client_service.save_client({"client_name": "Dup Two", "entity_type": "Individual", "pan": "DUPPD1234D"},
                                       allow_duplicate_pan=False)

    def test_duplicate_gstin_detection(self):
        g = make_gstin("08", "GSTPG1234G")
        new_client(client_name="G One", pan="GSTPG1234G", gstin=g, gst_registration_type="Normal Taxpayer",
                   gst_status="Active")
        self.assertEqual(len(client_service.find_duplicates(None, g)["gstin"]), 1)
        with self.assertRaises(ValueError):
            new_client(client_name="G Two", pan="GSTPG1234G", gstin=g)

    def test_delete_protection(self):
        cid = new_client(client_name="Linked Co", pan="LNKPL1234L", tds_applicable=True, tds_nonsalary=True,
                         tan="JPRL12345C")
        compliance_engine.generate_for_client(cid, FY)
        ok, _msg = client_service.delete_client(cid)
        self.assertFalse(ok)


class T03ComplianceEngine(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cid = new_client(client_name="Engine Pvt Ltd", entity_type="Private Limited Company", pan="ENGCE1234E",
                             gstin=make_gstin("27", "ENGCE1234E"), gst_registration_type="Normal Taxpayer",
                             gst_scheme="Regular", gst_frequency="Monthly", gst_status="Active",
                             tds_applicable=True, tds_nonsalary=True, tan="MUME12345E", itr_form="ITR-6",
                             tax_audit_applicable=True)

    def test_generation_and_no_duplicates(self):
        n1 = compliance_engine.generate_for_client(self.cid, FY)
        n2 = compliance_engine.generate_for_client(self.cid, FY)
        self.assertGreater(n1, 20)
        self.assertEqual(n2, 0)
        names = {r["compliance_name"] for r in compliance_engine.list_records({"client_id": self.cid})}
        self.assertIn("GSTR-3B (Monthly)", names)
        self.assertNotIn("GSTR-4 (Composition Annual)", names)   # not applicable to regular taxpayer
        self.assertNotIn("ITR-1 (Sahaj)", names)

    def test_due_date_calculations(self):
        compliance_engine.generate_for_client(self.cid, FY)
        recs = {(r["compliance_name"], r["period_key"]): r for r in compliance_engine.list_records({"client_id": self.cid})}
        self.assertEqual(recs[("GSTR-3B (Monthly)", "2026-04")]["original_due"], date(2026, 5, 20))
        self.assertEqual(recs[("TDS Payment", "2027-03")]["original_due"], date(2027, 4, 30))
        self.assertEqual(recs[("TDS Payment", "2026-05")]["original_due"], date(2026, 6, 7))
        self.assertEqual(recs[("Form 26Q (TDS Non-Salary)", f"FY{FY}-Q4")]["original_due"], date(2027, 5, 31))
        self.assertEqual(recs[("ITR-6", f"FY{FY}")]["original_due"], date(2027, 10, 31))

    def test_periods(self):
        self.assertEqual(len(generate_periods("Monthly", FY)), 12)
        self.assertEqual(generate_periods("Quarterly", FY)[3]["end"], date(2027, 3, 31))
        self.assertEqual(fy_of(date(2027, 2, 1)), "2026-27")

    def test_revised_due_date(self):
        compliance_engine.generate_for_client(self.cid, FY)
        r = compliance_engine.list_records({"client_id": self.cid, "category": "GST"})[0]
        new = r["original_due"] + timedelta(days=10)
        compliance_engine.revise_due_date([r["id"]], new, "Test notification 01/2026", "test")
        r2 = compliance_engine.get_record(r["id"])
        self.assertEqual(r2["due"], new)
        self.assertEqual(r2["original_due"], r["original_due"])
        self.assertTrue(any(h["action"] == "Due date revised" for h in compliance_engine.record_history(r["id"])))

    def test_completion(self):
        compliance_engine.generate_for_client(self.cid, FY)
        r = compliance_engine.list_records({"client_id": self.cid, "open_only": True})[0]
        compliance_engine.complete_record(r["id"], {"status": "Filed", "filing_date": date(2026, 5, 18),
                                                    "ack_number": "ACK123"})
        r2 = compliance_engine.get_record(r["id"])
        self.assertEqual(r2["status"], "Filed")
        self.assertEqual(r2["ack_number"], "ACK123")
        with self.assertRaises(ValueError):
            compliance_engine.complete_record(r["id"], {"status": "Filed"})

    def test_rule_version(self):
        m = next(x for x in compliance_engine.list_masters("GST") if x["code"] == "GST-GSTR1-M")
        compliance_engine.add_rule_version(m["id"], {"effective_from": date(2030, 4, 1), "offset_months": 1,
                                                     "due_day": 12, "notification_ref": "Test 99/2030"})
        rules = compliance_engine.list_rules(m["id"])
        self.assertEqual(len(rules), 2)
        self.assertEqual(rules[1]["effective_to"], date(2030, 3, 31))


class T04Notices(unittest.TestCase):
    def test_notice_aging_and_reminders(self):
        cid = new_client(client_name="Notice Client", pan="NTCPN1234N")
        nid = notice_service.create_notice({"client_id": cid, "department": "Income Tax",
                                            "category": "Income Tax Notice", "section": "143(2)",
                                            "receipt_date": date.today() - timedelta(days=40),
                                            "reply_due_date": date.today() + timedelta(days=3)})
        n = notice_service.get_notice(nid)
        self.assertEqual(n["aging"], 40)
        self.assertEqual(n["days_left"], 3)
        self.assertEqual(n["aging_bucket"], "31-60")
        self.assertIsNotNone(n["internal_deadline"])
        tasks = [t for t in task_service.list_tasks() if t["source_type"] == "notice" and t["source_id"] == nid]
        self.assertEqual(len(tasks), 1)
        reminder_engine.scan()
        rems = [r for r in reminder_engine.list_reminders() if r["ref_type"] == "notice" and r["ref_id"] == nid]
        self.assertTrue(rems)
        notice_service.record_reply(nid, date.today(), "ACK-N1")
        self.assertEqual(notice_service.get_notice(nid)["status"], "Reply Submitted")


class T05Tasks(unittest.TestCase):
    def test_task_assignment(self):
        uid = auth_service.save_user({"username": "tstaff", "full_name": "Test Staff", "role": "Junior",
                                      "is_active": True}, password="Staff@1234")
        tid = task_service.save_task({"title": "Prepare reconciliation", "assigned_to_id": uid,
                                      "due_date": date.today() + timedelta(days=1)})
        task_service.reassign(tid, uid)
        task_service.change_status(tid, "Completed")
        t = task_service.get_task(tid)
        self.assertEqual(t["status"], "Completed")
        self.assertEqual(t["assigned_to_id"], uid)
        self.assertTrue(task_service.history(tid))


class T06Documents(unittest.TestCase):
    def test_upload_retrieve_version(self):
        cid = new_client(client_name="Doc Client", pan="DOCPD1234D")
        src = os.path.join(TMP, "sample.txt")
        with open(src, "w") as fh:
            fh.write("hello")
        did = document_service.store_file(src, client_id=cid, area="GST", financial_year=FY, category="Bank Statements")
        d = document_service.get_document(did)
        self.assertTrue(os.path.isfile(document_service.abs_path(d["stored_path"])))
        self.assertIn(f"FY_{FY}", d["stored_path"])
        did2 = document_service.store_file(src, client_id=cid, area="GST", financial_year=FY, category="Bank Statements")
        self.assertEqual(did, did2)
        self.assertEqual(len(document_service.list_versions(did)), 2)
        document_service.soft_delete(did)
        self.assertFalse(document_service.list_documents(client_id=cid))
        document_service.restore(did)
        self.assertTrue(document_service.list_documents(client_id=cid))


class T07ExcelPdf(unittest.TestCase):
    def test_excel_import_export(self):
        from app.utils.excel_utils import write_client_template
        import openpyxl
        path = os.path.join(TMP, "import.xlsx")
        write_client_template(path, client_service.ENTITY_TYPES)
        wb = openpyxl.load_workbook(path)
        ws = wb["Clients"]
        ws.cell(row=2, column=1, value="Imported Co")
        ws.cell(row=2, column=4, value="IMPPI1234I")
        ws.cell(row=2, column=6, value=None)
        wb.save(path)
        rep = client_service.import_clients(path, allow_duplicate_pan=True)
        self.assertEqual(rep["imported"], 1, rep["errors"])
        out = os.path.join(TMP, "export.xlsx")
        client_service.export_clients(out)
        self.assertTrue(os.path.getsize(out) > 0)

    def test_pdf_report(self):
        out = os.path.join(TMP, "report.pdf")
        reporting_service.export_report("Overdue Compliance Report", out, {})
        with open(out, "rb") as fh:
            self.assertEqual(fh.read(4), b"%PDF")


class T08Backup(unittest.TestCase):
    def test_backup_and_restore(self):
        res = backup_service.create_backup(include_documents=True)
        self.assertTrue(res["ok"])
        ok, _ = backup_service.verify_backup(res["folder"])
        self.assertTrue(ok)
        new_client(client_name="After Backup", pan="AFTPA1234A")
        backup_service.restore_database(res["folder"])
        names = [c["client_name"] for c in client_service.list_clients()]
        self.assertNotIn("After Backup", names)
        self.assertGreaterEqual(len(backup_service.list_backups()), 2)   # original + safety backup


class T09StartupMigration(unittest.TestCase):
    def test_startup_and_migration(self):
        from app.database import migrations
        from app.database.db import get_db_path, get_engine
        migrations.run_migrations(get_engine(), get_db_path())   # idempotent
        self.assertFalse(migrations.pending_changes(get_engine())["tables"])
        compliance_engine.refresh_overdue()
        collection_service.ensure_upcoming(45)
        reminder_engine.scan()
        self.assertIn("total_clients", reporting_service.dashboard_counts())


@unittest.skipUnless(os.environ.get("CA_PM_GUI_TEST"), "Set CA_PM_GUI_TEST=1 to smoke-test the GUI")
class T10GuiSmoke(unittest.TestCase):
    def test_main_window(self):
        from app.qt import QApplication
        app = QApplication.instance() or QApplication([])
        auth_service.set_current_user({"id": 1, "username": "admin", "full_name": "Admin", "role": "Admin"})
        from app.ui.main_window import MainWindow
        w = MainWindow()
        for i in range(w.nav.count()):
            w.nav.setCurrentRow(i)
        w.close()


def tearDownModule():
    shutil.rmtree(TMP, ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
