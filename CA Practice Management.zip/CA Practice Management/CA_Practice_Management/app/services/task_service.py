"""Task management & staff allocation."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

from sqlalchemy import func, or_

from app.database.db import session_scope
from app.database.models import Client, ComplianceRecord, Notice, Task, TaskHistory, User
from app.services.audit_service import log_activity, log_audit, model_to_dict
from app.services.auth_service import current_user_id, current_username, scope_user_id
from app.services.compliance_engine import DONE_STATUSES, DUE_EXPR
from app.utils.date_utils import today

PRIORITIES = ["Critical", "High", "Medium", "Low"]
TASK_STATUSES = ["Pending", "In Progress", "Awaiting Client Documents", "Under Review", "Rework Required",
                 "Completed", "Cancelled"]
CLOSED = {"Completed", "Cancelled"}
TASK_CATEGORIES = ["GST", "Income Tax", "TDS", "ROC", "Notice", "Audit", "Document Collection", "Billing",
                   "General"]
TASK_FIELDS = ("client_id", "title", "description", "category", "financial_year", "assessment_year",
               "assigned_to_id", "reviewer_id", "start_date", "due_date", "priority", "status",
               "completion_date", "review_notes", "attachment_path", "source_type", "source_id")


def _hist(s, task_id: int, action: str, details: str = "") -> None:
    s.add(TaskHistory(task_id=task_id, action=action, details=details, user=current_username()))


def _next_code(s) -> str:
    n = (s.query(func.max(Task.id)).scalar() or 0) + 1
    while s.query(Task.id).filter(Task.task_code == f"T-{n:05d}").first():
        n += 1
    return f"T-{n:05d}"


def task_color(status: str, due: Optional[date]) -> str:
    if status in CLOSED:
        return "green"
    if due and due < today():
        return "red"
    if due and due <= today() + timedelta(days=2):
        return "yellow"
    if status in ("In Progress", "Under Review"):
        return "blue"
    return "grey"


def save_task(data: dict, task_id: Optional[int] = None) -> int:
    if not (data.get("title") or "").strip() and not task_id:
        raise ValueError("Task title is required.")
    with session_scope() as s:
        if task_id:
            t = s.get(Task, task_id)
            if not t:
                raise ValueError("Task not found.")
            old = model_to_dict(t)
        else:
            t = Task(task_code=_next_code(s), created_by_id=current_user_id(), created_date=today())
            s.add(t)
            old = None
        for k in TASK_FIELDS:
            if k in data:
                setattr(t, k, data[k])
        if not t.status:
            t.status = "Pending"
        if not t.priority:
            t.priority = "Medium"
        if t.status == "Completed" and not t.completion_date:
            t.completion_date = today()
        if t.status != "Completed":
            t.completion_date = None if not data.get("completion_date") else t.completion_date
        s.flush()
        new = model_to_dict(t)
        if old:
            changed = [k for k in new if old.get(k) != new.get(k)]
            if "status" in changed:
                _hist(s, t.id, "Status changed", f"{old['status']} -> {t.status}")
            if "assigned_to_id" in changed:
                _hist(s, t.id, "Reassigned", f"{old['assigned_to_id']} -> {t.assigned_to_id}")
            if changed:
                _hist(s, t.id, "Edited", ", ".join(changed))
        else:
            _hist(s, t.id, "Created", t.title)
            log_activity(s, "Tasks", "Created", f"{t.task_code}: {t.title}", t.client_id)
        log_audit(s, "UPDATE" if old else "CREATE", "tasks", t.id, old, new)
        return t.id


def change_status(task_id: int, status: str, notes: str = "") -> None:
    with session_scope() as s:
        t = s.get(Task, task_id)
        old = t.status
        t.status = status
        if status == "Completed":
            t.completion_date = today()
        if notes:
            t.review_notes = ((t.review_notes or "") + f"\n[{today():%d-%m-%Y} {current_username()}] {notes}").strip()
        _hist(s, t.id, "Status changed", f"{old} -> {status}. {notes}")
        if status == "Completed":
            log_activity(s, "Tasks", "Completed", f"{t.task_code}: {t.title}", t.client_id)


def reassign(task_id: int, staff_id: Optional[int], reviewer_id: Optional[int] = None) -> None:
    with session_scope() as s:
        t = s.get(Task, task_id)
        if staff_id:
            _hist(s, t.id, "Reassigned", f"{t.assigned_to_id} -> {staff_id}")
            t.assigned_to_id = staff_id
        if reviewer_id:
            _hist(s, t.id, "Reviewer changed", f"{t.reviewer_id} -> {reviewer_id}")
            t.reviewer_id = reviewer_id


def add_comment(task_id: int, text: str) -> None:
    if not text.strip():
        return
    with session_scope() as s:
        _hist(s, task_id, "Comment", text.strip())


def history(task_id: int) -> list[dict]:
    with session_scope() as s:
        return [{"_id": h.id, "when": h.created_at, "user": h.user, "action": h.action, "details": h.details or ""}
                for h in s.query(TaskHistory).filter_by(task_id=task_id).order_by(TaskHistory.created_at.desc())]


def open_task_exists(source_type: str, source_id: int) -> bool:
    with session_scope() as s:
        return s.query(Task).filter(Task.source_type == source_type, Task.source_id == source_id,
                                    ~Task.status.in_(CLOSED)).first() is not None


def _row(t: Task, c: Optional[Client], names: dict) -> dict:
    due = t.due_date
    is_open = t.status not in CLOSED
    return {"_id": t.id, "id": t.id, "task_code": t.task_code, "client_id": t.client_id,
            "client_name": c.client_name if c else "", "client_code": c.client_code if c else "",
            "title": t.title, "description": t.description or "", "category": t.category or "",
            "financial_year": t.financial_year or "", "assessment_year": t.assessment_year or "",
            "assigned_to": names.get(t.assigned_to_id, ""), "assigned_to_id": t.assigned_to_id,
            "reviewer": names.get(t.reviewer_id, ""), "reviewer_id": t.reviewer_id,
            "created_by": names.get(t.created_by_id, ""), "created_date": t.created_date,
            "start_date": t.start_date, "due_date": due, "priority": t.priority, "status": t.status,
            "completion_date": t.completion_date, "review_notes": t.review_notes or "",
            "aging": (today() - t.created_date).days if (is_open and t.created_date) else None,
            "overdue_days": (today() - due).days if (is_open and due and due < today()) else 0,
            "source_type": t.source_type or "manual", "source_id": t.source_id,
            "attachment_path": t.attachment_path, "_color": task_color(t.status, due)}


def list_tasks(filters: Optional[dict] = None) -> list[dict]:
    f = filters or {}
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = s.query(Task, Client).outerjoin(Client, Client.id == Task.client_id)
        if f.get("client_id"):
            q = q.filter(Task.client_id == f["client_id"])
        if f.get("assigned_to_id"):
            q = q.filter(Task.assigned_to_id == f["assigned_to_id"])
        if f.get("open_only"):
            q = q.filter(~Task.status.in_(CLOSED))
        if f.get("due_from"):
            q = q.filter(Task.due_date >= f["due_from"])
        if f.get("due_to"):
            q = q.filter(Task.due_date <= f["due_to"])
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(Task.assigned_to_id == uid, Task.reviewer_id == uid, Task.created_by_id == uid))
        return [_row(t, c, names) for t, c in q.order_by(Task.due_date.is_(None), Task.due_date).all()]


def get_task(task_id: int) -> Optional[dict]:
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        t = s.get(Task, task_id)
        if not t:
            return None
        return _row(t, s.get(Client, t.client_id) if t.client_id else None, names)


def workload() -> list[dict]:
    """Staff-wise dashboard: tasks + open compliances + notices."""
    t0 = today()
    out = []
    with session_scope() as s:
        users = s.query(User).filter(User.is_active.is_(True)).order_by(User.full_name).all()
        for u in users:
            tasks = s.query(Task).filter(Task.assigned_to_id == u.id)
            total = tasks.count()
            completed = tasks.filter(Task.status == "Completed").count()
            open_q = s.query(Task).filter(Task.assigned_to_id == u.id, ~Task.status.in_(CLOSED))
            pending = open_q.count()
            overdue = open_q.filter(Task.due_date < t0).count()
            due_today = open_q.filter(Task.due_date == t0).count()
            review = s.query(Task).filter(Task.reviewer_id == u.id, Task.status == "Under Review").count()
            comp_open = s.query(ComplianceRecord).filter(ComplianceRecord.assigned_staff_id == u.id,
                                                         ~ComplianceRecord.status.in_(DONE_STATUSES)).count()
            comp_over = s.query(ComplianceRecord).filter(ComplianceRecord.assigned_staff_id == u.id,
                                                         ~ComplianceRecord.status.in_(DONE_STATUSES),
                                                         DUE_EXPR < t0).count()
            notices = s.query(Notice).filter(Notice.assigned_staff_id == u.id, Notice.status != "Closed").count()
            out.append({"_id": u.id, "staff": u.full_name, "role": u.role, "total": total, "completed": completed,
                        "pending": pending, "overdue": overdue, "due_today": due_today, "awaiting_review": review,
                        "open_compliances": comp_open, "overdue_compliances": comp_over, "open_notices": notices,
                        "_color": "red" if (overdue or comp_over) else ("yellow" if due_today else None)})
    return out


def allocation(start: date, end: date) -> list[dict]:
    """Daily / weekly allocation: tasks and compliances due in window, per staff."""
    from app.services.compliance_engine import list_records
    rows = []
    for t in list_tasks({"open_only": True, "due_from": start, "due_to": end}):
        rows.append({"_id": t["id"], "_kind": "task", "staff": t["assigned_to"] or "(Unassigned)",
                     "type": "Task", "client_name": t["client_name"], "item": t["title"], "due": t["due_date"],
                     "priority": t["priority"], "status": t["status"], "_color": t["_color"]})
    for r in list_records({"open_only": True, "due_from": start, "due_to": end}):
        rows.append({"_id": r["id"], "_kind": "compliance", "staff": r["staff"] or "(Unassigned)",
                     "type": f"Compliance - {r['category']}", "client_name": r["client_name"],
                     "item": f"{r['compliance_name']} ({r['tax_period']})", "due": r["due"], "priority": "",
                     "status": r["status"], "_color": r["_color"]})
    return sorted(rows, key=lambda x: (x["staff"], x["due"] or date.max))


def priority_matrix() -> list[dict]:
    tasks = list_tasks({"open_only": True})
    out = []
    for p in PRIORITIES:
        row = {"_id": p, "priority": p}
        for st in TASK_STATUSES[:5]:
            row[st] = sum(1 for t in tasks if t["priority"] == p and t["status"] == st)
        row["overdue"] = sum(1 for t in tasks if t["priority"] == p and t["overdue_days"] > 0)
        row["total"] = sum(1 for t in tasks if t["priority"] == p)
        row["_color"] = "red" if p == "Critical" and row["total"] else None
        out.append(row)
    return out
