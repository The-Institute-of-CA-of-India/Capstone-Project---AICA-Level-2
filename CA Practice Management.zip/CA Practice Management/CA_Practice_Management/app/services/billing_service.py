"""Professional fee & billing tracker (not a full accounting system)."""
from __future__ import annotations

from datetime import date
from typing import Optional

from sqlalchemy import func, or_

from app.database.db import session_scope
from app.database.models import BillingRecord, Client, Payment
from app.services import settings_service
from app.services.audit_service import log_activity, log_audit, model_to_dict
from app.services.auth_service import scope_user_id
from app.utils.date_utils import MONTHS, fy_of, today

FEE_TYPES = ["Retainership", "Compliance", "Audit", "Notice / Litigation", "Advisory", "Registration", "Other"]
PAYMENT_MODES = ["NEFT", "RTGS", "IMPS", "UPI", "Cheque", "Cash", "Other"]
PAY_STATUSES = ["Unpaid", "Partially Paid", "Paid", "Cancelled"]


def next_invoice_no(s, fy: str) -> str:
    prefix = settings_service.get("invoice_prefix") or "NAC"
    base = f"{prefix}/{fy}/"
    n = s.query(BillingRecord).filter(BillingRecord.invoice_number.like(base + "%")).count() + 1
    while s.query(BillingRecord.id).filter(BillingRecord.invoice_number == f"{base}{n:04d}").first():
        n += 1
    return f"{base}{n:04d}"


def _paid(s, bid: int) -> float:
    return float(s.query(func.coalesce(func.sum(Payment.amount), 0.0)).filter(Payment.billing_id == bid).scalar() or 0)


def _refresh_status(s, b: BillingRecord) -> None:
    if b.status == "Cancelled":
        return
    paid = _paid(s, b.id)
    b.status = "Paid" if paid >= round(b.total_amount or 0, 2) - 0.5 else ("Partially Paid" if paid > 0 else "Unpaid")


def save_invoice(data: dict, billing_id: Optional[int] = None) -> int:
    if not data.get("client_id"):
        raise ValueError("Client is required.")
    amount = float(data.get("amount") or 0)
    if amount <= 0:
        raise ValueError("Invoice amount must be greater than zero.")
    rate = float(data.get("gst_rate") if data.get("gst_rate") is not None else settings_service.get("gst_rate_default") or 18)
    inv_date = data.get("invoice_date") or today()
    with session_scope() as s:
        if billing_id:
            b = s.get(BillingRecord, billing_id)
            old = model_to_dict(b)
        else:
            fy = data.get("financial_year") or fy_of(inv_date)
            no = (data.get("invoice_number") or "").strip() or next_invoice_no(s, fy)
            if s.query(BillingRecord.id).filter(BillingRecord.invoice_number == no).first():
                raise ValueError(f"Invoice number {no} already exists.")
            b = BillingRecord(invoice_number=no, financial_year=fy)
            s.add(b)
            old = None
        for k in ("client_id", "description", "fee_type", "compliance_record_id", "due_date", "remarks"):
            if k in data:
                setattr(b, k, data[k])
        b.invoice_date = inv_date
        b.amount = round(amount, 2)
        b.gst_rate = rate
        b.gst_amount = round(amount * rate / 100.0, 2)
        b.total_amount = round(b.amount + b.gst_amount, 2)
        s.flush()
        _refresh_status(s, b)
        log_audit(s, "UPDATE" if old else "CREATE", "billing_records", b.id, old, model_to_dict(b))
        if not old:
            log_activity(s, "Billing", "Invoice", f"Invoice {b.invoice_number} for {b.total_amount:,.2f}", b.client_id)
        return b.id


def record_payment(billing_id: int, data: dict) -> int:
    amt = float(data.get("amount") or 0)
    if amt <= 0:
        raise ValueError("Payment amount must be greater than zero.")
    with session_scope() as s:
        b = s.get(BillingRecord, billing_id)
        if b.status == "Cancelled":
            raise ValueError("Cannot record payment against a cancelled invoice.")
        outstanding = round((b.total_amount or 0) - _paid(s, b.id), 2)
        if amt > outstanding + 0.5:
            raise ValueError(f"Payment exceeds outstanding amount ({outstanding:,.2f}).")
        p = Payment(billing_id=billing_id, payment_date=data.get("payment_date") or today(), amount=round(amt, 2),
                    mode=data.get("mode"), reference=data.get("reference"), remarks=data.get("remarks"))
        s.add(p)
        s.flush()
        _refresh_status(s, b)
        log_activity(s, "Billing", "Payment", f"Payment {amt:,.2f} against {b.invoice_number}", b.client_id)
        return p.id


def cancel_invoice(billing_id: int, reason: str) -> None:
    with session_scope() as s:
        b = s.get(BillingRecord, billing_id)
        if _paid(s, b.id) > 0:
            raise ValueError("Invoice has payments recorded and cannot be cancelled.")
        b.status = "Cancelled"
        b.remarks = ((b.remarks or "") + f"\nCancelled: {reason}").strip()
        log_audit(s, "CANCEL", "billing_records", b.id, None, {"reason": reason})


def list_invoices(client_id: Optional[int] = None, fy: Optional[str] = None) -> list[dict]:
    t = today()
    with session_scope() as s:
        q = s.query(BillingRecord, Client).join(Client, Client.id == BillingRecord.client_id)
        if client_id:
            q = q.filter(BillingRecord.client_id == client_id)
        if fy:
            q = q.filter(BillingRecord.financial_year == fy)
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(Client.assigned_staff_id == uid, Client.assigned_manager_id == uid,
                             Client.assigned_partner_id == uid))
        paid_map = dict(s.query(Payment.billing_id, func.sum(Payment.amount)).group_by(Payment.billing_id).all())
        out = []
        for b, c in q.order_by(BillingRecord.invoice_date.desc()).all():
            paid = float(paid_map.get(b.id) or 0)
            outstanding = 0.0 if b.status == "Cancelled" else round((b.total_amount or 0) - paid, 2)
            age = (t - (b.due_date or b.invoice_date)).days if outstanding > 0 else 0
            out.append({"_id": b.id, "id": b.id, "client_id": c.id, "client_code": c.client_code,
                        "client_name": c.client_name, "invoice_number": b.invoice_number,
                        "invoice_date": b.invoice_date, "description": b.description or "", "fee_type": b.fee_type,
                        "financial_year": b.financial_year, "amount": b.amount, "gst_rate": b.gst_rate,
                        "gst_amount": b.gst_amount, "total_amount": b.total_amount, "paid": paid,
                        "outstanding": outstanding, "due_date": b.due_date, "status": b.status,
                        "age_days": max(0, age), "remarks": b.remarks or "",
                        "_color": {"Paid": "green", "Cancelled": "grey", "Partially Paid": "blue"}.get(
                            b.status, "red" if (b.due_date and b.due_date < t) else "yellow")})
        return out


def get_invoice(billing_id: int) -> Optional[dict]:
    for r in list_invoices():
        if r["id"] == billing_id:
            return r
    return None


def list_payments(billing_id: Optional[int] = None) -> list[dict]:
    with session_scope() as s:
        q = (s.query(Payment, BillingRecord, Client).join(BillingRecord, BillingRecord.id == Payment.billing_id)
             .join(Client, Client.id == BillingRecord.client_id))
        if billing_id:
            q = q.filter(Payment.billing_id == billing_id)
        return [{"_id": p.id, "payment_date": p.payment_date, "client_name": c.client_name,
                 "invoice_number": b.invoice_number, "amount": p.amount, "mode": p.mode or "",
                 "reference": p.reference or "", "remarks": p.remarks or ""}
                for p, b, c in q.order_by(Payment.payment_date.desc()).all()]


def outstanding_by_client() -> list[dict]:
    agg: dict[int, dict] = {}
    for r in list_invoices():
        if r["status"] == "Cancelled":
            continue
        a = agg.setdefault(r["client_id"], {"_id": r["client_id"], "client_code": r["client_code"],
                                            "client_name": r["client_name"], "invoices": 0, "billed": 0.0,
                                            "received": 0.0, "outstanding": 0.0, "b0_30": 0.0, "b31_60": 0.0,
                                            "b61_90": 0.0, "b90": 0.0})
        a["invoices"] += 1
        a["billed"] += r["total_amount"] or 0
        a["received"] += r["paid"]
        a["outstanding"] += r["outstanding"]
        if r["outstanding"] > 0:
            d = r["age_days"]
            key = "b0_30" if d <= 30 else "b31_60" if d <= 60 else "b61_90" if d <= 90 else "b90"
            a[key] += r["outstanding"]
    out = sorted(agg.values(), key=lambda x: -x["outstanding"])
    for a in out:
        a["_color"] = "red" if a["b90"] > 0 else ("yellow" if a["outstanding"] > 0 else "green")
    return out


def monthly_summary(fy: str) -> list[dict]:
    rows = {}
    s_year = int(fy[:4])
    for i in range(12):
        m = (3 + i) % 12 + 1
        y = s_year if m >= 4 else s_year + 1
        rows[(y, m)] = {"_id": f"{y}-{m}", "month": f"{MONTHS[m - 1]}-{y}", "invoices": 0, "billed": 0.0,
                        "gst": 0.0, "collected": 0.0}
    for r in list_invoices(fy=fy):
        if r["status"] == "Cancelled":
            continue
        k = (r["invoice_date"].year, r["invoice_date"].month)
        if k in rows:
            rows[k]["invoices"] += 1
            rows[k]["billed"] += r["total_amount"] or 0
            rows[k]["gst"] += r["gst_amount"] or 0
    for p in list_payments():
        k = (p["payment_date"].year, p["payment_date"].month)
        if k in rows:
            rows[k]["collected"] += p["amount"]
    return list(rows.values())


def annual_summary() -> list[dict]:
    agg: dict[str, dict] = {}
    for r in list_invoices():
        if r["status"] == "Cancelled":
            continue
        a = agg.setdefault(r["financial_year"], {"_id": r["financial_year"], "financial_year": r["financial_year"],
                                                 "invoices": 0, "billed": 0.0, "received": 0.0, "outstanding": 0.0})
        a["invoices"] += 1
        a["billed"] += r["total_amount"] or 0
        a["received"] += r["paid"]
        a["outstanding"] += r["outstanding"]
    return sorted(agg.values(), key=lambda x: x["financial_year"], reverse=True)
