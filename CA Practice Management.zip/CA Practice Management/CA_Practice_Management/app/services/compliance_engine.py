"""
Compliance engine
=================
* Applicability evaluation (rules in compliance_master.applicability + per-client overrides)
* Versioned due-date rules (effective from / to, notification reference, source)
* Recurring compliance generation per client & financial year (no duplicates)
* Revised due dates / extensions with history
* Completion workflow, overdue refresh, filing matrix

Applicability JSON keys
    entity_types   : [..]     client.entity_type must be in list
    requires_true  : [field]  boolean client fields that must be True
    requires_false : [field]  boolean client fields that must be False
    requires_value : [field]  client fields that must be non-empty (e.g. gstin)
    field_in       : {field: [allowed values]}
    manual         : true     never auto-applicable (switch on per client)
An empty rule is treated as NOT applicable - the engine never assumes that a
form applies to every client.
"""
from __future__ import annotations

import json
from datetime import date, timedelta
from typing import Any, Optional

from sqlalchemy import and_, func, or_
from sqlalchemy.orm import Session

from app.database.db import session_scope
from app.database.models import (Client, ClientComplianceApplicability, ComplianceDueDateRule,
                                 ComplianceHistory, ComplianceMaster, ComplianceRecord, Reminder, User)
from app.services import settings_service
from app.services.audit_service import log_activity, log_audit, model_to_dict
from app.services.auth_service import current_username, scope_user_id
from app.utils.date_utils import (add_months, ay_of_fy, fy_bounds, generate_periods, safe_date, today)
from app.utils.logger import get_logger

log = get_logger(__name__)

CATEGORIES = ["GST", "Income Tax", "TDS", "ROC", "Other"]
DONE_STATUSES = {"Filed", "Completed", "Not Applicable"}
PROGRESS_STATUSES = {"In Progress", "Under Review", "Ready for Filing", "Awaiting Documents"}
DUE_EXPR = func.coalesce(ComplianceRecord.revised_due_date, ComplianceRecord.original_due_date)


# ================================================================== helpers
def color_key(status: Optional[str], due: Optional[date], warn_days: int = 7) -> str:
    """Dashboard colour convention: green/blue/yellow/red/grey."""
    if status in DONE_STATUSES:
        return "green"
    t = today()
    if due and due < t:
        return "red"
    if due and due <= t + timedelta(days=warn_days):
        return "yellow"
    if status in PROGRESS_STATUSES:
        return "blue"
    return "grey"


def _json(text: Optional[str], default):
    try:
        return json.loads(text) if text else default
    except (TypeError, ValueError):
        return default


def _history(s: Session, record_id: int, action: str, old: Any = None, new: Any = None,
             details: str = "") -> None:
    s.add(ComplianceHistory(record_id=record_id, action=action,
                            old_value=None if old is None else str(old),
                            new_value=None if new is None else str(new),
                            details=details, user=current_username()))


def _deadlines(due: date, buffer_days: Optional[int]) -> tuple[date, date, date]:
    buf = buffer_days if buffer_days is not None else int(settings_service.get("internal_buffer_days") or 5)
    doc_buf = int(settings_service.get("doc_collection_buffer_days") or 10)
    rev_buf = int(settings_service.get("review_buffer_days") or 2)
    return (due - timedelta(days=buf), due - timedelta(days=max(doc_buf, buf + 1)),
            due - timedelta(days=min(rev_buf, buf)))


# ================================================================== master
def list_masters(category: Optional[str] = None, active_only: bool = False) -> list[dict]:
    with session_scope() as s:
        q = s.query(ComplianceMaster)
        if category:
            q = q.filter(ComplianceMaster.category == category)
        if active_only:
            q = q.filter(ComplianceMaster.is_active.is_(True))
        out = []
        for m in q.order_by(ComplianceMaster.category, ComplianceMaster.sort_order):
            rule = current_rule(s, m.id, today())
            out.append({"_id": m.id, "id": m.id, "code": m.code, "category": m.category, "name": m.name,
                        "form_number": m.form_number, "periodicity": m.periodicity,
                        "applicability": m.applicability, "description": m.description,
                        "internal_buffer_days": m.internal_buffer_days, "is_active": m.is_active,
                        "manual": bool(_json(m.applicability, {}).get("manual")),
                        "rule_text": describe_rule(rule, m.periodicity) if rule else "No rule",
                        "notification_ref": rule.notification_ref if rule else "",
                        "official_source": rule.official_source if rule else "",
                        "effective_from": rule.effective_from if rule else None})
        return out


def get_master(master_id: int) -> Optional[dict]:
    for m in list_masters():
        if m["id"] == master_id:
            return m
    return None


def save_master(data: dict, master_id: Optional[int] = None) -> int:
    appl = data.get("applicability") or "{}"
    if isinstance(appl, str):
        try:
            json.loads(appl)
        except ValueError as exc:
            raise ValueError(f"Applicability must be valid JSON: {exc}") from exc
    else:
        appl = json.dumps(appl)
    with session_scope() as s:
        if master_id:
            m = s.get(ComplianceMaster, master_id)
            old = model_to_dict(m)
        else:
            code = (data.get("code") or "").strip().upper()
            if not code:
                raise ValueError("Code is required.")
            if s.query(ComplianceMaster).filter_by(code=code).first():
                raise ValueError(f"Compliance code {code} already exists.")
            m = ComplianceMaster(code=code)
            s.add(m)
            old = None
        for k in ("category", "name", "form_number", "periodicity", "description", "internal_buffer_days"):
            if k in data:
                setattr(m, k, data[k])
        if not m.internal_buffer_days:
            m.internal_buffer_days = None   # 0 / blank -> firm default buffer
        m.is_active = bool(data.get("is_active", True))
        m.applicability = appl
        s.flush()
        if not master_id:
            s.add(ComplianceDueDateRule(master_id=m.id, offset_months=int(data.get("offset_months", 1)),
                                        due_day=int(data.get("due_day", 20)), effective_from=date(2000, 4, 1),
                                        notification_ref=data.get("notification_ref") or "User defined",
                                        official_source=data.get("official_source") or "",
                                        created_by=current_username(), is_current=True))
        log_audit(s, "UPDATE" if master_id else "CREATE", "compliance_master", m.id, old, model_to_dict(m))
        return m.id


def list_rules(master_id: int) -> list[dict]:
    with session_scope() as s:
        rows = (s.query(ComplianceDueDateRule).filter_by(master_id=master_id)
                .order_by(ComplianceDueDateRule.effective_from.desc()).all())
        per = s.get(ComplianceMaster, master_id).periodicity
        return [{"_id": r.id, "id": r.id, "effective_from": r.effective_from, "effective_to": r.effective_to,
                 "offset_months": r.offset_months, "due_day": r.due_day,
                 "period_overrides": r.period_overrides, "alt_rules": r.alt_rules,
                 "fixed_dates": r.fixed_dates, "notification_ref": r.notification_ref,
                 "official_source": r.official_source, "remarks": r.remarks,
                 "is_current": "Yes" if r.is_current else "No", "created_by": r.created_by,
                 "created_at": r.created_at, "rule_text": describe_rule(r, per)} for r in rows]


def current_rule(s: Session, master_id: int, on_date: date) -> Optional[ComplianceDueDateRule]:
    r = (s.query(ComplianceDueDateRule)
         .filter(ComplianceDueDateRule.master_id == master_id,
                 ComplianceDueDateRule.effective_from <= on_date,
                 or_(ComplianceDueDateRule.effective_to.is_(None), ComplianceDueDateRule.effective_to >= on_date))
         .order_by(ComplianceDueDateRule.effective_from.desc()).first())
    if r is None:
        r = (s.query(ComplianceDueDateRule).filter_by(master_id=master_id)
             .order_by(ComplianceDueDateRule.effective_from.desc()).first())
    return r


def add_rule_version(master_id: int, data: dict) -> int:
    """Add a new due-date rule version; the previous version is closed (kept as history)."""
    eff = data.get("effective_from")
    if not eff:
        raise ValueError("Effective-from date is required.")
    if not (data.get("notification_ref") or "").strip():
        raise ValueError("Notification / circular reference is required for a due-date change.")
    for key in ("period_overrides", "alt_rules", "fixed_dates"):
        val = data.get(key) or ("{}" if key == "period_overrides" else "[]")
        try:
            json.loads(val)
        except ValueError as exc:
            raise ValueError(f"{key} must be valid JSON: {exc}") from exc
        data[key] = val
    with session_scope() as s:
        prev = (s.query(ComplianceDueDateRule).filter(ComplianceDueDateRule.master_id == master_id,
                                                      ComplianceDueDateRule.effective_to.is_(None))
                .order_by(ComplianceDueDateRule.effective_from.desc()).first())
        if prev and prev.effective_from >= eff:
            raise ValueError("Effective date must be later than the current rule's effective date "
                             f"({prev.effective_from}).")
        if prev:
            prev.effective_to = eff - timedelta(days=1)
            prev.is_current = False
        r = ComplianceDueDateRule(master_id=master_id, offset_months=int(data.get("offset_months") or 0),
                                  due_day=int(data.get("due_day") or 1),
                                  period_overrides=data["period_overrides"], alt_rules=data["alt_rules"],
                                  fixed_dates=data["fixed_dates"], effective_from=eff,
                                  effective_to=data.get("effective_to"),
                                  notification_ref=data.get("notification_ref"),
                                  official_source=data.get("official_source"), remarks=data.get("remarks"),
                                  is_current=True, created_by=current_username())
        s.add(r)
        s.flush()
        log_audit(s, "RULE_VERSION", "compliance_due_date_rules", r.id, None, model_to_dict(r))
        log_activity(s, "Compliance Master", "Due date rule changed",
                     f"New rule version for master #{master_id} effective {eff} ({data.get('notification_ref')})")
        return r.id


def describe_rule(rule: Optional[ComplianceDueDateRule], periodicity: str) -> str:
    if rule is None:
        return ""
    fixed = _json(rule.fixed_dates, [])
    if periodicity == "Fixed Dates" and fixed:
        return "Fixed: " + ", ".join(f"{f['day']:02d}/{f['month']:02d}" for f in fixed)
    when = {0: "same month as period end"}.get(rule.offset_months, f"{rule.offset_months:+d} month(s) after period end")
    text = f"Day {rule.due_day}, {when}"
    ov = {k: v for k, v in _json(rule.period_overrides, {}).items() if k != "skip"}
    if ov:
        text += "; overrides " + ", ".join(f"{k}: day {v[1]} (+{v[0]}m)" for k, v in ov.items())
    if _json(rule.period_overrides, {}).get("skip"):
        text += "; skips " + ",".join(_json(rule.period_overrides, {})["skip"])
    for a in _json(rule.alt_rules, []):
        if "event_field" in a:
            text += f"; or {a['days']} days from {a['event_field']}"
        elif a.get("if_true"):
            text += f"; if {a['if_true']}: day {a['day']} (+{a['offset']}m)"
    return text


# ================================================================== applicability
def is_applicable(master, client, override: Optional[bool] = None) -> bool:
    if override is not None:
        return bool(override)
    rule = _json(master.applicability, {})
    if not rule or rule.get("manual"):
        return False
    if rule.get("entity_types") and client.entity_type not in rule["entity_types"]:
        return False
    for f in rule.get("requires_true", []):
        if not getattr(client, f, False):
            return False
    for f in rule.get("requires_false", []):
        if getattr(client, f, False):
            return False
    for f in rule.get("requires_value", []):
        if not getattr(client, f, None):
            return False
    for f, allowed in rule.get("field_in", {}).items():
        if getattr(client, f, None) not in allowed:
            return False
    return True


def applicability_preview(client_data: dict, client_id: Optional[int] = None) -> list[dict]:
    """For the client form: list every active master with auto result + saved override."""
    probe = Client(**{k: v for k, v in client_data.items() if hasattr(Client, k)})
    with session_scope() as s:
        overrides = {}
        if client_id:
            overrides = {o.master_id: o.applicable for o in
                         s.query(ClientComplianceApplicability).filter_by(client_id=client_id)}
        out = []
        for m in s.query(ComplianceMaster).filter(ComplianceMaster.is_active.is_(True)) \
                .order_by(ComplianceMaster.category, ComplianceMaster.sort_order):
            auto = is_applicable(m, probe)
            out.append({"master_id": m.id, "code": m.code, "category": m.category, "name": m.name,
                        "form": m.form_number, "periodicity": m.periodicity, "auto": auto,
                        "override": overrides.get(m.id)})
        return out


# ================================================================== due dates
def compute_due(rule: ComplianceDueDateRule, period: dict, client=None) -> Optional[date]:
    if period.get("fixed_due"):
        return period["fixed_due"]
    off, day = int(rule.offset_months or 0), int(rule.due_day or 1)
    for a in _json(rule.alt_rules, []):
        if "event_field" in a and client is not None:
            ev = getattr(client, a["event_field"], None)
            if ev and period["end"] < ev <= add_months(period["end"], 12):
                return ev + timedelta(days=int(a.get("days", 0)))
        elif a.get("if_true") and client is not None and getattr(client, a["if_true"], False):
            off, day = int(a["offset"]), int(a["day"])
            break
    ov = _json(rule.period_overrides, {})
    if period["tag"] in ov and period["tag"] != "skip":
        off, day = int(ov[period["tag"]][0]), int(ov[period["tag"]][1])
    base = add_months(date(period["end"].year, period["end"].month, 1), off)
    return safe_date(base.year, base.month, day)


# ================================================================== generation
def generate_for_client(client_id: int, fy: str, session: Optional[Session] = None) -> int:
    def _run(s: Session) -> int:
        client = s.get(Client, client_id)
        if not client or client.status != "Active":
            return 0
        overrides = {o.master_id: o.applicable for o in
                     s.query(ClientComplianceApplicability).filter_by(client_id=client_id)}
        existing = {(mid, pk) for mid, pk in
                    s.query(ComplianceRecord.master_id, ComplianceRecord.period_key)
                    .filter(ComplianceRecord.client_id == client_id)}
        skip_before = bool(settings_service.get("skip_periods_before_onboarding"))
        fy_end = fy_bounds(fy)[1]
        created = 0
        for m in s.query(ComplianceMaster).filter(ComplianceMaster.is_active.is_(True)):
            if m.periodicity == "One-Time" and overrides.get(m.id) is None:
                continue  # one-time items are only created when explicitly enabled/added
            if not is_applicable(m, client, overrides.get(m.id)):
                continue
            base_rule = current_rule(s, m.id, fy_end)
            if base_rule is None:
                continue
            for p in generate_periods(m.periodicity, fy, _json(base_rule.fixed_dates, [])):
                if (m.id, p["key"]) in existing:
                    continue
                rule = current_rule(s, m.id, p["end"]) or base_rule
                if p["tag"] in _json(rule.period_overrides, {}).get("skip", []):
                    continue
                if m.category == "GST" and client.gst_registration_date and p["end"] < client.gst_registration_date:
                    continue
                due = compute_due(rule, p, client)
                if due is None:
                    continue
                if skip_before and client.acquisition_date and due < client.acquisition_date:
                    continue
                internal, doc_dl, review = _deadlines(due, m.internal_buffer_days)
                s.add(ComplianceRecord(
                    client_id=client.id, master_id=m.id, category=m.category, compliance_name=m.name,
                    form_number=m.form_number, financial_year=fy, assessment_year=ay_of_fy(fy),
                    tax_period=p["label"], period_key=p["key"], period_start=p["start"], period_end=p["end"],
                    original_due_date=due, internal_target_date=internal, doc_collection_deadline=doc_dl,
                    review_deadline=review, assigned_staff_id=client.assigned_staff_id,
                    reviewer_id=client.assigned_manager_id or client.assigned_partner_id,
                    status="Not Started", due_rule_id=rule.id))
                existing.add((m.id, p["key"]))
                created += 1
        if created:
            log_activity(s, "Compliance", "Generated", f"{created} compliance records generated for FY {fy}",
                         client.id)
        return created

    if session is not None:
        return _run(session)
    with session_scope() as s:
        return _run(s)


def generate_for_all(fy: str) -> int:
    with session_scope() as s:
        ids = [c.id for c in s.query(Client.id).filter(Client.status == "Active")]
    total = 0
    for cid in ids:
        total += generate_for_client(cid, fy)
    log.info("Generated %s compliance records for FY %s", total, fy)
    return total


# ================================================================== queries
def _row(r: ComplianceRecord, c: Client, names: dict) -> dict:
    due = r.revised_due_date or r.original_due_date
    t = today()
    if r.status in DONE_STATUSES:
        end = r.filing_date or r.completion_date
        delay = max(0, (end - due).days) if (end and due) else 0
        days_left = None
    else:
        delay = max(0, (t - due).days) if due else 0
        days_left = (due - t).days if due else None
    return {"_id": r.id, "id": r.id, "client_id": c.id, "client_code": c.client_code, "client_name": c.client_name,
            "pan": c.pan, "gstin": c.gstin, "tan": c.tan, "cin": c.cin_llpin,
            "category": r.category, "compliance_name": r.compliance_name, "form_number": r.form_number,
            "master_id": r.master_id, "financial_year": r.financial_year, "assessment_year": r.assessment_year,
            "tax_period": r.tax_period, "period_key": r.period_key, "original_due": r.original_due_date,
            "revised_due": r.revised_due_date, "due": due, "internal_target": r.internal_target_date,
            "doc_deadline": r.doc_collection_deadline, "review_deadline": r.review_deadline,
            "status": r.status, "staff": names.get(r.assigned_staff_id, ""),
            "reviewer": names.get(r.reviewer_id, ""), "assigned_staff_id": r.assigned_staff_id,
            "reviewer_id": r.reviewer_id, "filing_date": r.filing_date, "completion_date": r.completion_date,
            "ack_number": r.ack_number, "challan_number": r.challan_number, "challan_amount": r.challan_amount,
            "srn": r.srn, "delay_days": delay, "days_left": days_left, "penalty_notes": r.penalty_notes,
            "remarks": r.remarks, "attachment_path": r.attachment_path, "updated_at": r.updated_at,
            "revision_reason": r.revision_reason, "revision_source": r.revision_source,
            "_color": color_key(r.status, due)}


def list_records(filters: Optional[dict] = None) -> list[dict]:
    f = filters or {}
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = s.query(ComplianceRecord, Client).join(Client, Client.id == ComplianceRecord.client_id)
        if f.get("category"):
            q = q.filter(ComplianceRecord.category == f["category"])
        if f.get("client_id"):
            q = q.filter(ComplianceRecord.client_id == f["client_id"])
        if f.get("fy"):
            q = q.filter(ComplianceRecord.financial_year == f["fy"])
        if f.get("master_id"):
            q = q.filter(ComplianceRecord.master_id == f["master_id"])
        if f.get("master_codes"):
            ids = [m.id for m in s.query(ComplianceMaster.id).filter(ComplianceMaster.code.in_(f["master_codes"]))]
            q = q.filter(ComplianceRecord.master_id.in_(ids or [-1]))
        if f.get("staff_id"):
            q = q.filter(ComplianceRecord.assigned_staff_id == f["staff_id"])
        if f.get("status"):
            q = q.filter(ComplianceRecord.status == f["status"])
        if f.get("open_only"):
            q = q.filter(~ComplianceRecord.status.in_(DONE_STATUSES))
        if f.get("done_only"):
            q = q.filter(ComplianceRecord.status.in_(DONE_STATUSES))
        if f.get("due_from"):
            q = q.filter(DUE_EXPR >= f["due_from"])
        if f.get("due_to"):
            q = q.filter(DUE_EXPR <= f["due_to"])
        if f.get("active_clients_only", True):
            q = q.filter(Client.status == "Active")
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(ComplianceRecord.assigned_staff_id == uid, ComplianceRecord.reviewer_id == uid,
                             Client.assigned_staff_id == uid))
        q = q.order_by(DUE_EXPR, Client.client_name)
        return [_row(r, c, names) for r, c in q.all()]


def get_record(record_id: int) -> Optional[dict]:
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        r = s.get(ComplianceRecord, record_id)
        if not r:
            return None
        return _row(r, s.get(Client, r.client_id), names)


def record_history(record_id: int) -> list[dict]:
    with session_scope() as s:
        return [{"_id": h.id, "when": h.created_at, "user": h.user, "action": h.action,
                 "old": h.old_value or "", "new": h.new_value or "", "details": h.details or ""}
                for h in s.query(ComplianceHistory).filter_by(record_id=record_id)
                .order_by(ComplianceHistory.created_at.desc())]


# ================================================================== updates
EDITABLE = ("tax_period", "original_due_date", "revised_due_date", "internal_target_date",
            "doc_collection_deadline", "review_deadline", "completion_date", "filing_date", "ack_number",
            "challan_number", "challan_amount", "srn", "assigned_staff_id", "reviewer_id", "status",
            "penalty_notes", "remarks", "assessment_year", "financial_year")


def save_record(data: dict, record_id: Optional[int] = None) -> int:
    """Create a manual compliance entry or edit an existing one."""
    with session_scope() as s:
        if record_id:
            r = s.get(ComplianceRecord, record_id)
            if not r:
                raise ValueError("Compliance record not found.")
            old = model_to_dict(r)
        else:
            m = s.get(ComplianceMaster, data.get("master_id"))
            if not m or not data.get("client_id"):
                raise ValueError("Client and compliance type are required.")
            if not data.get("original_due_date"):
                raise ValueError("Statutory due date is required.")
            fy = data.get("financial_year") or settings_service.current_fy()
            period_key = data.get("period_key") or f"MANUAL-{fy}-{(data.get('tax_period') or 'NA').strip()}"
            if s.query(ComplianceRecord).filter_by(client_id=data["client_id"], master_id=m.id,
                                                   period_key=period_key).first():
                raise ValueError("A compliance entry already exists for this client, form and period.")
            c = s.get(Client, data["client_id"])
            r = ComplianceRecord(client_id=c.id, master_id=m.id, category=m.category, compliance_name=m.name,
                                 form_number=m.form_number, financial_year=fy, assessment_year=ay_of_fy(fy),
                                 period_key=period_key, status="Not Started",
                                 assigned_staff_id=c.assigned_staff_id,
                                 reviewer_id=c.assigned_manager_id or c.assigned_partner_id)
            s.add(r)
            old = None
        for k in EDITABLE:
            if k in data:
                setattr(r, k, data[k])
        due = r.revised_due_date or r.original_due_date
        if due and not r.internal_target_date:
            r.internal_target_date, r.doc_collection_deadline, r.review_deadline = _deadlines(due, None)
        s.flush()
        new = model_to_dict(r)
        if old and old.get("status") != new.get("status"):
            _history(s, r.id, "Status changed", old.get("status"), new.get("status"))
        if not old:
            _history(s, r.id, "Created (manual)", None, r.status)
        else:
            _history(s, r.id, "Edited", None, None, ", ".join(k for k in new if old.get(k) != new.get(k)))
        log_audit(s, "UPDATE" if old else "CREATE", "compliance_records", r.id, old, new)
        return r.id


def complete_record(record_id: int, data: dict) -> None:
    """Workflow 2 - mark compliance as Filed / Completed with filing details."""
    status = data.get("status") or "Completed"
    if status not in DONE_STATUSES:
        raise ValueError("Completion status must be Filed, Completed or Not Applicable.")
    if status != "Not Applicable" and not data.get("filing_date"):
        raise ValueError("Filing / completion date is required.")
    attach = data.get("attachment")
    with session_scope() as s:
        r = s.get(ComplianceRecord, record_id)
        if not r:
            raise ValueError("Compliance record not found.")
        old = model_to_dict(r)
        r.status = status
        r.filing_date = data.get("filing_date") or r.filing_date
        r.completion_date = data.get("completion_date") or data.get("filing_date") or today()
        for k in ("ack_number", "challan_number", "challan_amount", "srn", "remarks", "penalty_notes"):
            if data.get(k) not in (None, ""):
                setattr(r, k, data[k])
        if data.get("assigned_staff_id"):
            r.assigned_staff_id = data["assigned_staff_id"]
        if data.get("reviewer_id"):
            r.reviewer_id = data["reviewer_id"]
        _history(s, r.id, "Completed", old.get("status"), status,
                 f"Filed on {r.filing_date}; Ack {r.ack_number or '-'}")
        log_audit(s, "COMPLETE", "compliance_records", r.id, old, model_to_dict(r))
        log_activity(s, "Compliance", "Completed", f"{r.compliance_name} ({r.tax_period}) marked {status}",
                     r.client_id)
        s.query(Reminder).filter(Reminder.ref_type == "compliance", Reminder.ref_id == r.id,
                                 Reminder.status.in_(["Pending", "Snoozed"])).update(
            {"status": "Completed"}, synchronize_session=False)
        client_id, cat, fy = r.client_id, r.category, r.financial_year
    if attach:
        from app.services import document_service
        doc_id = document_service.store_file(attach, client_id=client_id, area=cat, financial_year=fy,
                                             category="Acknowledgement", title=f"Acknowledgement - {old['compliance_name']}",
                                             compliance_record_id=record_id, remarks="Filing acknowledgement")
        with session_scope() as s:
            r = s.get(ComplianceRecord, record_id)
            r.attachment_path = document_service.get_document(doc_id)["stored_path"]


def bulk_update(ids: list[int], status: Optional[str] = None, staff_id: Optional[int] = None,
                reviewer_id: Optional[int] = None) -> int:
    n = 0
    with session_scope() as s:
        for r in s.query(ComplianceRecord).filter(ComplianceRecord.id.in_(ids)):
            if status and status != r.status:
                _history(s, r.id, "Status changed", r.status, status, "Bulk update")
                r.status = status
            if staff_id and staff_id != r.assigned_staff_id:
                _history(s, r.id, "Staff reassigned", r.assigned_staff_id, staff_id)
                r.assigned_staff_id = staff_id
            if reviewer_id and reviewer_id != r.reviewer_id:
                _history(s, r.id, "Reviewer changed", r.reviewer_id, reviewer_id)
                r.reviewer_id = reviewer_id
            n += 1
    return n


def revise_due_date(ids: list[int], new_date: date, reason: str, source: str = "") -> int:
    """Record a revised (extended) due date. Statutory original date is preserved."""
    if not new_date:
        raise ValueError("Revised due date is required.")
    if not (reason or "").strip():
        raise ValueError("Reason / notification reference is required.")
    n = 0
    with session_scope() as s:
        for r in s.query(ComplianceRecord).filter(ComplianceRecord.id.in_(ids)):
            old = r.revised_due_date or r.original_due_date
            r.revised_due_date = new_date
            r.revision_reason = reason
            r.revision_source = source
            m = s.get(ComplianceMaster, r.master_id)
            r.internal_target_date, r.doc_collection_deadline, r.review_deadline = _deadlines(
                new_date, m.internal_buffer_days if m else None)
            if r.status == "Overdue" and new_date >= today():
                r.status = "Not Started"
            _history(s, r.id, "Due date revised", old, new_date, f"{reason} | {source}")
            log_audit(s, "REVISE_DUE", "compliance_records", r.id, {"due": str(old)},
                      {"due": str(new_date), "reason": reason, "source": source})
            n += 1
    return n


def apply_extension(master_id: int, period_key: Optional[str], fy: Optional[str], new_date: date,
                    notification_ref: str, source: str = "") -> int:
    """Apply a government extension to all OPEN records of a form for a period (or whole FY)."""
    with session_scope() as s:
        q = s.query(ComplianceRecord.id).filter(ComplianceRecord.master_id == master_id,
                                                ~ComplianceRecord.status.in_(DONE_STATUSES))
        if period_key:
            q = q.filter(ComplianceRecord.period_key == period_key)
        if fy:
            q = q.filter(ComplianceRecord.financial_year == fy)
        ids = [i for (i,) in q]
    if not ids:
        return 0
    return revise_due_date(ids, new_date, notification_ref, source)


def recalc_open_records(master_id: int) -> int:
    """After adding a rule version, recompute statutory dates of open, un-revised records."""
    n = 0
    with session_scope() as s:
        m = s.get(ComplianceMaster, master_id)
        for r in s.query(ComplianceRecord).filter(ComplianceRecord.master_id == master_id,
                                                  ~ComplianceRecord.status.in_(DONE_STATUSES),
                                                  ComplianceRecord.revised_due_date.is_(None)):
            rule = current_rule(s, master_id, r.period_end or today())
            periods = {p["key"]: p for p in generate_periods(m.periodicity, r.financial_year,
                                                             _json(rule.fixed_dates, []))}
            p = periods.get(r.period_key)
            if not p:
                continue
            new_due = compute_due(rule, p, s.get(Client, r.client_id))
            if new_due and new_due != r.original_due_date:
                _history(s, r.id, "Statutory date recalculated", r.original_due_date, new_due,
                         f"Rule version #{rule.id} ({rule.notification_ref})")
                r.original_due_date = new_due
                r.due_rule_id = rule.id
                r.internal_target_date, r.doc_collection_deadline, r.review_deadline = _deadlines(
                    new_due, m.internal_buffer_days)
                n += 1
    return n


def refresh_overdue() -> int:
    """Startup check: mark not-started items past their due date as Overdue."""
    with session_scope() as s:
        n = (s.query(ComplianceRecord)
             .filter(ComplianceRecord.status.in_(["Not Started", "Awaiting Documents"]),
                     DUE_EXPR < today())
             .update({"status": "Overdue"}, synchronize_session=False))
    return n


def delete_record(record_id: int) -> None:
    """Only manual, not-started records without filing data may be deleted."""
    with session_scope() as s:
        r = s.get(ComplianceRecord, record_id)
        if not r:
            return
        if r.status in DONE_STATUSES or r.filing_date or r.ack_number:
            raise ValueError("Completed / filed compliance records cannot be deleted. "
                             "Use status 'Not Applicable' instead.")
        log_audit(s, "DELETE", "compliance_records", r.id, model_to_dict(r), None)
        s.delete(r)


# ================================================================== matrix
def filing_matrix(master_id: int, fy: str) -> tuple[list[tuple[str, str]], list[dict]]:
    """Client x period status grid for one form (GST monthly calendar etc.)."""
    with session_scope() as s:
        m = s.get(ComplianceMaster, master_id)
        rule = current_rule(s, master_id, fy_bounds(fy)[1])
        periods = generate_periods(m.periodicity, fy, _json(rule.fixed_dates, []) if rule else [])
    cols = [("client_code", "Client ID"), ("client_name", "Client")] + [(p["key"], p["label"]) for p in periods]
    rows: dict[int, dict] = {}
    for r in list_records({"master_id": master_id, "fy": fy}):
        row = rows.setdefault(r["client_id"], {"_id": r["client_id"], "client_code": r["client_code"],
                                               "client_name": r["client_name"], "_cell_colors": {}})
        label = r["status"]
        if r["status"] in DONE_STATUSES and r["filing_date"]:
            label = f"✔ {r['filing_date']:%d-%m}"
        row[r["period_key"]] = label
        row["_cell_colors"][r["period_key"]] = r["_color"]
    return cols, sorted(rows.values(), key=lambda x: x["client_name"])
