"""Dashboard metrics, drill-down lists and the report catalogue."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from typing import Callable, Optional

from app.services import (billing_service, client_service, collection_service, compliance_engine,
                          document_service, notice_service, settings_service, task_service)
from app.services.audit_service import recent_activities
from app.services.auth_service import list_users
from app.services.compliance_engine import DONE_STATUSES
from app.utils.date_utils import MONTHS, fy_bounds, fy_choices, today
from app.utils.excel_utils import export_rows
from app.utils.pdf_utils import export_table_pdf

COMP_COLS = [("client_code", "Client ID"), ("client_name", "Client"), ("category", "Category"),
             ("compliance_name", "Compliance"), ("tax_period", "Period"), ("due", "Due Date"),
             ("days_left", "Days Left"), ("status", "Status"), ("staff", "Staff"), ("reviewer", "Reviewer")]
DONE_COLS = [("client_code", "Client ID"), ("client_name", "Client"), ("category", "Category"),
             ("compliance_name", "Compliance"), ("tax_period", "Period"), ("due", "Due Date"),
             ("filing_date", "Filed On"), ("ack_number", "Ack No."), ("delay_days", "Delay Days"),
             ("status", "Status"), ("staff", "Staff")]
NOTICE_COLS = [("notice_code", "Notice ID"), ("client_name", "Client"), ("department", "Department"),
               ("category", "Category"), ("section", "Section"), ("notice_number", "Notice No."), ("din", "DIN"),
               ("receipt_date", "Received"), ("reply_due_date", "Reply Due"), ("days_left", "Days Left"),
               ("aging", "Aging (days)"), ("status", "Status"), ("staff", "Staff")]
TASK_COLS = [("task_code", "Task ID"), ("client_name", "Client"), ("title", "Task"), ("assigned_to", "Assigned To"),
             ("due_date", "Due Date"), ("priority", "Priority"), ("status", "Status"), ("aging", "Aging")]


# ================================================================== dashboard
def dashboard_counts() -> dict:
    t = today()
    fy = settings_service.current_fy()
    clients = client_service.list_clients()
    recs = compliance_engine.list_records({"fy": fy})
    all_open = compliance_engine.list_records({"open_only": True})
    notices = notice_service.list_notices({"open_only": True})
    tasks = task_service.list_tasks({"open_only": True})
    warn = int(settings_service.get("notice_warning_days") or 7)
    month_start = date(t.year, t.month, 1)
    done_month = [r for r in compliance_engine.list_records({"done_only": True})
                  if r["completion_date"] and r["completion_date"] >= month_start]
    applicable = [r for r in recs if r["status"] != "Not Applicable"]
    done_fy = [r for r in applicable if r["status"] in DONE_STATUSES]
    due_till_today = [r for r in applicable if r["due"] and r["due"] <= t]
    done_due = [r for r in due_till_today if r["status"] in DONE_STATUSES]
    return {
        "total_clients": len(clients),
        "active_clients": sum(1 for c in clients if c["status"] == "Active"),
        "inactive_clients": sum(1 for c in clients if c["status"] != "Active"),
        "due_today": sum(1 for r in all_open if r["due"] == t),
        "due_7": sum(1 for r in all_open if r["due"] and t <= r["due"] <= t + timedelta(days=7)),
        "due_15": sum(1 for r in all_open if r["due"] and t <= r["due"] <= t + timedelta(days=15)),
        "overdue": sum(1 for r in all_open if r["due"] and r["due"] < t),
        "notices_pending": sum(1 for n in notices if n["status"] in notice_service.PRE_REPLY),
        "notices_near": sum(1 for n in notices if n["status"] in notice_service.PRE_REPLY and n["reply_due_date"]
                            and n["reply_due_date"] <= t + timedelta(days=warn)),
        "tasks_pending": len(tasks),
        "tasks_overdue": sum(1 for x in tasks if x["due_date"] and x["due_date"] < t),
        "docs_pending": collection_service.pending_count(),
        "completed_month": len(done_month),
        "completion_pct": round(100.0 * len(done_fy) / len(applicable), 1) if applicable else 0.0,
        "ontime_pct": round(100.0 * len(done_due) / len(due_till_today), 1) if due_till_today else 100.0,
    }


def drilldown(key: str) -> tuple[str, list, list, str]:
    """Return (title, columns, rows, record_kind) for a dashboard KPI."""
    t = today()
    warn = int(settings_service.get("notice_warning_days") or 7)
    ccols = [("client_code", "Client ID"), ("client_name", "Client"), ("entity_type", "Entity"), ("pan", "PAN"),
             ("gstin", "GSTIN"), ("staff", "Staff"), ("status", "Status"), ("pending_compliances", "Pending")]
    if key in ("total_clients", "active_clients", "inactive_clients"):
        rows = client_service.list_clients()
        if key == "active_clients":
            rows = [r for r in rows if r["status"] == "Active"]
        elif key == "inactive_clients":
            rows = [r for r in rows if r["status"] != "Active"]
        return ({"total_clients": "All Clients", "active_clients": "Active Clients",
                 "inactive_clients": "Inactive Clients"}[key], ccols, rows, "client")
    if key in ("due_today", "due_7", "due_15", "overdue"):
        rows = compliance_engine.list_records({"open_only": True})
        if key == "due_today":
            rows, title = [r for r in rows if r["due"] == t], "Compliance Due Today"
        elif key == "due_7":
            rows, title = [r for r in rows if r["due"] and t <= r["due"] <= t + timedelta(days=7)], "Due within 7 Days"
        elif key == "due_15":
            rows, title = [r for r in rows if r["due"] and t <= r["due"] <= t + timedelta(days=15)], "Due within 15 Days"
        else:
            rows, title = [r for r in rows if r["due"] and r["due"] < t], "Overdue Compliances"
        return title, COMP_COLS + [("delay_days", "Delay")], rows, "compliance"
    if key in ("notices_pending", "notices_near"):
        rows = [n for n in notice_service.list_notices({"open_only": True}) if n["status"] in notice_service.PRE_REPLY]
        if key == "notices_near":
            rows = [n for n in rows if n["reply_due_date"] and n["reply_due_date"] <= t + timedelta(days=warn)]
        return ("Notices Pending Reply" if key == "notices_pending" else f"Notice Deadlines within {warn} Days",
                NOTICE_COLS, rows, "notice")
    if key in ("tasks_pending", "tasks_overdue"):
        rows = task_service.list_tasks({"open_only": True})
        if key == "tasks_overdue":
            rows = [x for x in rows if x["due_date"] and x["due_date"] < t]
        return ("Pending Tasks" if key == "tasks_pending" else "Overdue Tasks", TASK_COLS, rows, "task")
    if key == "docs_pending":
        return ("Documents Pending from Clients",
                [("client_name", "Client"), ("compliance", "Compliance"), ("period", "Period"),
                 ("document_name", "Document"), ("follow_up_staff", "Follow-up By"),
                 ("follow_up_date", "Follow-up Date"), ("due", "Compliance Due")],
                collection_service.list_status(pending_only=True), "collection")
    if key in ("completed_month", "completion_pct"):
        if key == "completed_month":
            ms = date(t.year, t.month, 1)
            rows = [r for r in compliance_engine.list_records({"done_only": True})
                    if r["completion_date"] and r["completion_date"] >= ms]
            return "Compliance Completed This Month", DONE_COLS, rows, "compliance"
        return ("Compliance Status - Current FY", COMP_COLS,
                compliance_engine.list_records({"fy": settings_service.current_fy()}), "compliance")
    return key, [], [], ""


def monthly_completion(fy: str) -> tuple[list[str], list[int], list[int]]:
    """Chart data: per month of FY - compliances due vs completed."""
    s_year = int(fy[:4])
    labels, due, done = [], [], []
    recs = compliance_engine.list_records({"fy": fy})
    for i in range(12):
        m = (3 + i) % 12 + 1
        y = s_year if m >= 4 else s_year + 1
        labels.append(MONTHS[m - 1])
        month_recs = [r for r in recs if r["due"] and r["due"].year == y and r["due"].month == m
                      and r["status"] != "Not Applicable"]
        due.append(len(month_recs))
        done.append(sum(1 for r in month_recs if r["status"] in DONE_STATUSES))
    return labels, due, done


def client_pending_work(limit: int = 15) -> list[dict]:
    agg: dict[int, dict] = {}
    t = today()
    for r in compliance_engine.list_records({"open_only": True}):
        a = agg.setdefault(r["client_id"], {"_id": r["client_id"], "client_name": r["client_name"],
                                            "pending": 0, "overdue": 0, "next_due": None})
        a["pending"] += 1
        if r["due"] and r["due"] < t:
            a["overdue"] += 1
        if r["due"] and r["due"] >= t and (a["next_due"] is None or r["due"] < a["next_due"]):
            a["next_due"] = r["due"]
    for n in notice_service.list_notices({"open_only": True}):
        a = agg.setdefault(n["client_id"], {"_id": n["client_id"], "client_name": n["client_name"],
                                            "pending": 0, "overdue": 0, "next_due": None})
        a["notices"] = a.get("notices", 0) + 1
    out = sorted(agg.values(), key=lambda x: (-x["overdue"], -x["pending"]))[:limit]
    for a in out:
        a.setdefault("notices", 0)
        a["_color"] = "red" if a["overdue"] else ("yellow" if a["pending"] > 5 else None)
    return out


# ================================================================== reports
def _fy(p): return p.get("fy") or settings_service.current_fy()


def r_client_compliance_status(p):
    agg: dict[int, dict] = {}
    t = today()
    for r in compliance_engine.list_records({"fy": _fy(p), "category": p.get("category")}):
        a = agg.setdefault(r["client_id"], {"_id": r["client_id"], "client_code": r["client_code"],
                                            "client_name": r["client_name"], "total": 0, "completed": 0,
                                            "pending": 0, "overdue": 0, "na": 0})
        a["total"] += 1
        if r["status"] == "Not Applicable":
            a["na"] += 1
        elif r["status"] in DONE_STATUSES:
            a["completed"] += 1
        else:
            a["pending"] += 1
            if r["due"] and r["due"] < t:
                a["overdue"] += 1
    rows = []
    for a in agg.values():
        base = a["total"] - a["na"]
        a["pct"] = f"{(100.0 * a['completed'] / base if base else 100):.1f}%"
        a["_color"] = "red" if a["overdue"] else ("green" if a["pending"] == 0 else None)
        rows.append(a)
    cols = [("client_code", "Client ID"), ("client_name", "Client"), ("total", "Total"), ("completed", "Completed"),
            ("pending", "Pending"), ("overdue", "Overdue"), ("na", "N/A"), ("pct", "Completion %")]
    return cols, sorted(rows, key=lambda x: x["client_name"]), []


def _pending_cat(cat):
    def fn(p):
        return COMP_COLS + [("delay_days", "Delay")], compliance_engine.list_records(
            {"fy": p.get("fy"), "category": cat, "open_only": True, "staff_id": p.get("staff_id"),
             "client_id": p.get("client_id")}), []
    return fn


def r_overdue(p):
    t = today()
    rows = [r for r in compliance_engine.list_records({"open_only": True, "category": p.get("category"),
                                                       "staff_id": p.get("staff_id"), "client_id": p.get("client_id")})
            if r["due"] and r["due"] < t]
    return COMP_COLS + [("delay_days", "Delay Days")], rows, []


def r_completion(p):
    return DONE_COLS, compliance_engine.list_records({"fy": _fy(p), "done_only": True, "category": p.get("category"),
                                                      "staff_id": p.get("staff_id"), "client_id": p.get("client_id")}), []


def r_monthly_summary(p):
    fy = _fy(p)
    s_year = int(fy[:4])
    recs = compliance_engine.list_records({"fy": fy, "category": p.get("category")})
    rows = []
    for i in range(12):
        m = (3 + i) % 12 + 1
        y = s_year if m >= 4 else s_year + 1
        mr = [r for r in recs if r["due"] and r["due"].year == y and r["due"].month == m and r["status"] != "Not Applicable"]
        done = [r for r in mr if r["status"] in DONE_STATUSES]
        ontime = [r for r in done if r["delay_days"] == 0]
        rows.append({"_id": i, "month": f"{MONTHS[m - 1]}-{y}", "due": len(mr), "completed": len(done),
                     "on_time": len(ontime), "late": len(done) - len(ontime), "pending": len(mr) - len(done),
                     "pct": f"{(100.0 * len(done) / len(mr) if mr else 0):.1f}%"})
    return [("month", "Month"), ("due", "Due"), ("completed", "Completed"), ("on_time", "On Time"),
            ("late", "Late"), ("pending", "Pending"), ("pct", "Completion %")], rows, []


def r_fy_summary(p):
    rows = []
    for fy in fy_choices(back=3, fwd=0):
        recs = compliance_engine.list_records({"fy": fy})
        if not recs:
            continue
        for cat in compliance_engine.CATEGORIES:
            cr = [r for r in recs if r["category"] == cat and r["status"] != "Not Applicable"]
            if not cr:
                continue
            done = sum(1 for r in cr if r["status"] in DONE_STATUSES)
            rows.append({"_id": f"{fy}{cat}", "fy": fy, "category": cat, "total": len(cr), "completed": done,
                         "pending": len(cr) - done, "pct": f"{100.0 * done / len(cr):.1f}%"})
    return [("fy", "FY"), ("category", "Category"), ("total", "Total"), ("completed", "Completed"),
            ("pending", "Pending"), ("pct", "Completion %")], rows, []


def r_notice_aging(p):
    rows = notice_service.list_notices({"open_only": True, "client_id": p.get("client_id")})
    return NOTICE_COLS + [("aging_bucket", "Aging Bucket"), ("demand_amount", "Demand")], \
        sorted(rows, key=lambda r: -(r["aging"] or 0)), ["demand_amount"]


def r_notice_dept(p):
    agg = defaultdict(lambda: defaultdict(int))
    for n in notice_service.list_notices():
        agg[n["department"] or "Other"][n["status"]] += 1
        agg[n["department"] or "Other"]["total"] += 1
    rows = []
    for dep, d in agg.items():
        row = {"_id": dep, "department": dep, "total": d["total"]}
        row["open"] = d["total"] - d.get("Closed", 0)
        row["closed"] = d.get("Closed", 0)
        row["reply_submitted"] = d.get("Reply Submitted", 0)
        row["hearing"] = d.get("Hearing Pending", 0)
        row["appeal"] = d.get("Appeal Pending", 0)
        rows.append(row)
    return [("department", "Department"), ("total", "Total"), ("open", "Open"), ("reply_submitted", "Reply Submitted"),
            ("hearing", "Hearing Pending"), ("appeal", "Appeal Pending"), ("closed", "Closed")], rows, []


def r_notice_deadline(p):
    rows = [n for n in notice_service.list_notices({"open_only": True}) if n["reply_due_date"]]
    return NOTICE_COLS + [("internal_deadline", "Internal Deadline"), ("hearing_date", "Hearing"),
                          ("next_hearing_date", "Next Hearing")], rows, []


def r_pending_reply(p):
    rows = [n for n in notice_service.list_notices({"open_only": True}) if n["status"] in notice_service.PRE_REPLY]
    return NOTICE_COLS, rows, []


def r_appeal(p):
    rows = [n for n in notice_service.list_notices() if n["appeal_deadline"]]
    for r in rows:
        r["appeal_days_left"] = (r["appeal_deadline"] - today()).days
    return [("notice_code", "Notice ID"), ("client_name", "Client"), ("department", "Department"),
            ("category", "Category"), ("section", "Section"), ("demand_amount", "Demand"),
            ("appeal_deadline", "Appeal Deadline"), ("appeal_days_left", "Days Left"), ("status", "Status"),
            ("reviewer", "Reviewing Partner")], rows, ["demand_amount"]


def r_staff_allocation(p):
    rows = task_service.workload()
    clients = client_service.list_clients(status="Active")
    for r in rows:
        r["clients"] = sum(1 for c in clients if c["staff"] == r["staff"])
    return [("staff", "Staff"), ("role", "Role"), ("clients", "Clients"), ("open_compliances", "Open Compliances"),
            ("overdue_compliances", "Overdue Compliances"), ("pending", "Open Tasks"), ("overdue", "Overdue Tasks"),
            ("due_today", "Due Today"), ("awaiting_review", "Awaiting Review"), ("open_notices", "Open Notices")], rows, []


def r_staff_pending(p):
    rows = []
    for r in compliance_engine.list_records({"open_only": True, "staff_id": p.get("staff_id")}):
        rows.append({"_id": f"c{r['id']}", "staff": r["staff"], "type": "Compliance", "client_name": r["client_name"],
                     "item": f"{r['compliance_name']} ({r['tax_period']})", "due": r["due"], "status": r["status"],
                     "_color": r["_color"]})
    for t in task_service.list_tasks({"open_only": True, "assigned_to_id": p.get("staff_id")}):
        rows.append({"_id": f"t{t['id']}", "staff": t["assigned_to"], "type": "Task", "client_name": t["client_name"],
                     "item": t["title"], "due": t["due_date"], "status": t["status"], "_color": t["_color"]})
    for n in notice_service.list_notices({"open_only": True}):
        if p.get("staff_id") and n["assigned_staff_id"] != p.get("staff_id"):
            continue
        rows.append({"_id": f"n{n['id']}", "staff": n["staff"], "type": "Notice", "client_name": n["client_name"],
                     "item": f"{n['category']} {n['notice_code']}", "due": n["reply_due_date"], "status": n["status"],
                     "_color": n["_color"]})
    rows.sort(key=lambda x: (x["staff"] or "", x["due"] or date.max))
    return [("staff", "Staff"), ("type", "Type"), ("client_name", "Client"), ("item", "Work Item"),
            ("due", "Due"), ("status", "Status")], rows, []


def r_staff_overdue_tasks(p):
    rows = [t for t in task_service.list_tasks({"open_only": True, "assigned_to_id": p.get("staff_id")})
            if t["overdue_days"] > 0]
    return TASK_COLS + [("overdue_days", "Overdue Days")], sorted(rows, key=lambda x: x["assigned_to"]), []


def r_staff_productivity(p):
    fy = _fy(p)
    recs = compliance_engine.list_records({"fy": fy, "done_only": True})
    tasks = task_service.list_tasks()
    rows = []
    for u in list_users(active_only=True):
        mine = [r for r in recs if r["assigned_staff_id"] == u["id"] and r["status"] != "Not Applicable"]
        ontime = sum(1 for r in mine if r["delay_days"] == 0)
        tdone = [t for t in tasks if t["assigned_to_id"] == u["id"] and t["status"] == "Completed"]
        rows.append({"_id": u["id"], "staff": u["full_name"], "role": u["role"], "compliances_done": len(mine),
                     "on_time": ontime, "late": len(mine) - ontime,
                     "ontime_pct": f"{(100.0 * ontime / len(mine) if mine else 0):.1f}%",
                     "avg_delay": round(sum(r["delay_days"] for r in mine) / len(mine), 1) if mine else 0,
                     "tasks_done": len(tdone)})
    return [("staff", "Staff"), ("role", "Role"), ("compliances_done", "Compliances Completed"),
            ("on_time", "On Time"), ("late", "Late"), ("ontime_pct", "On-time %"), ("avg_delay", "Avg Delay (days)"),
            ("tasks_done", "Tasks Completed")], rows, []


def r_client_history(p):
    cols = [("financial_year", "FY")] + DONE_COLS + [("remarks", "Remarks")]
    return cols, compliance_engine.list_records({"client_id": p.get("client_id"), "active_clients_only": False}), []


def r_client_pending(p):
    rows = compliance_engine.list_records({"open_only": True, "client_id": p.get("client_id")})
    return COMP_COLS + [("delay_days", "Delay")], rows, []


def r_client_notice_summary(p):
    agg = {}
    for n in notice_service.list_notices({"client_id": p.get("client_id")}):
        a = agg.setdefault(n["client_id"], {"_id": n["client_id"], "client_name": n["client_name"], "total": 0,
                                            "open": 0, "closed": 0, "demand": 0.0, "disputed": 0.0})
        a["total"] += 1
        a["closed" if n["status"] == "Closed" else "open"] += 1
        if n["status"] != "Closed":
            a["demand"] += n["demand_amount"] or 0
            a["disputed"] += n["amount_disputed"] or 0
    return [("client_name", "Client"), ("total", "Total Notices"), ("open", "Open"), ("closed", "Closed"),
            ("demand", "Open Demand"), ("disputed", "Amount Disputed")], list(agg.values()), ["demand", "disputed"]


def r_client_documents(p):
    prog = {r["_id"]: r for r in collection_service.progress_by_client()}
    docs = defaultdict(int)
    for d in document_service.list_documents(client_id=p.get("client_id")):
        docs[d["client_id"]] += 1
    rows = []
    for c in client_service.list_clients(status="Active"):
        if p.get("client_id") and c["id"] != p["client_id"]:
            continue
        pr = prog.get(c["id"], {})
        rows.append({"_id": c["id"], "client_code": c["client_code"], "client_name": c["client_name"],
                     "documents": docs.get(c["id"], 0), "checklist_total": pr.get("total", 0),
                     "received": pr.get("received", 0), "pending": pr.get("pending", 0),
                     "progress": pr.get("progress_text", "-"), "_color": pr.get("_color")})
    return [("client_code", "Client ID"), ("client_name", "Client"), ("documents", "Documents in Repository"),
            ("checklist_total", "Checklist Items"), ("received", "Received"), ("pending", "Pending"),
            ("progress", "Collection %")], rows, []


def r_fee_outstanding(p):
    rows = billing_service.outstanding_by_client()
    if p.get("client_id"):
        rows = [r for r in rows if r["_id"] == p["client_id"]]
    return [("client_code", "Client ID"), ("client_name", "Client"), ("invoices", "Invoices"), ("billed", "Billed"),
            ("received", "Received"), ("outstanding", "Outstanding"), ("b0_30", "0-30 days"), ("b31_60", "31-60 days"),
            ("b61_90", "61-90 days"), ("b90", "90+ days")], rows, \
        ["billed", "received", "outstanding", "b0_30", "b31_60", "b61_90", "b90"]


def r_monthly_billing(p):
    return [("month", "Month"), ("invoices", "Invoices"), ("billed", "Billed (incl. GST)"), ("gst", "GST"),
            ("collected", "Collected")], billing_service.monthly_summary(_fy(p)), ["billed", "gst", "collected"]


def r_annual_billing(p):
    return [("financial_year", "FY"), ("invoices", "Invoices"), ("billed", "Billed"), ("received", "Received"),
            ("outstanding", "Outstanding")], billing_service.annual_summary(), ["billed", "received", "outstanding"]


def r_collection(p):
    return [("payment_date", "Date"), ("client_name", "Client"), ("invoice_number", "Invoice"), ("amount", "Amount"),
            ("mode", "Mode"), ("reference", "Reference")], billing_service.list_payments(), ["amount"]


# group, name, function, needs (fy, category, staff, client)
REPORTS: list[tuple[str, str, Callable, set]] = [
    ("Compliance", "Client-wise Compliance Status", r_client_compliance_status, {"fy", "category"}),
    ("Compliance", "GST Pending Compliance", _pending_cat("GST"), {"fy", "staff", "client"}),
    ("Compliance", "Income Tax Pending Compliance", _pending_cat("Income Tax"), {"fy", "staff", "client"}),
    ("Compliance", "TDS Pending Compliance", _pending_cat("TDS"), {"fy", "staff", "client"}),
    ("Compliance", "ROC Pending Compliance", _pending_cat("ROC"), {"fy", "staff", "client"}),
    ("Compliance", "Overdue Compliance Report", r_overdue, {"category", "staff", "client"}),
    ("Compliance", "Compliance Completion Report", r_completion, {"fy", "category", "staff", "client"}),
    ("Compliance", "Monthly Compliance Summary", r_monthly_summary, {"fy", "category"}),
    ("Compliance", "Financial Year-wise Compliance Summary", r_fy_summary, set()),
    ("Notices", "Notice Aging Report", r_notice_aging, {"client"}),
    ("Notices", "Department-wise Notice Report", r_notice_dept, set()),
    ("Notices", "Notice Deadline Report", r_notice_deadline, set()),
    ("Notices", "Pending Reply Report", r_pending_reply, set()),
    ("Notices", "Appeal Limitation Report", r_appeal, set()),
    ("Staff", "Staff-wise Work Allocation", r_staff_allocation, set()),
    ("Staff", "Staff-wise Pending Work", r_staff_pending, {"staff"}),
    ("Staff", "Staff-wise Overdue Tasks", r_staff_overdue_tasks, {"staff"}),
    ("Staff", "Staff Productivity Report", r_staff_productivity, {"fy"}),
    ("Client", "Client Compliance History", r_client_history, {"client"}),
    ("Client", "Client Pending Work", r_client_pending, {"client"}),
    ("Client", "Client Notice Summary", r_client_notice_summary, {"client"}),
    ("Client", "Client Document Status", r_client_documents, {"client"}),
    ("Client", "Client Professional Fee Outstanding", r_fee_outstanding, {"client"}),
    ("Billing", "Monthly Billing", r_monthly_billing, {"fy"}),
    ("Billing", "Annual Billing", r_annual_billing, set()),
    ("Billing", "Outstanding Aging", r_fee_outstanding, {"client"}),
    ("Billing", "Fee Collection Report", r_collection, set()),
]


def run_report(name: str, params: Optional[dict] = None) -> tuple[list, list, list]:
    for _g, n, fn, _need in REPORTS:
        if n == name:
            return fn(params or {})
    raise KeyError(name)


def export_report(name: str, path: str, params: Optional[dict] = None) -> str:
    cols, rows, money = run_report(name, params)
    firm = settings_service.firm_name()
    if path.lower().endswith(".pdf"):
        return export_table_pdf(path, name, cols, rows, firm=firm, money=money)
    return export_rows(path, cols, rows, title=name, firm=firm)
