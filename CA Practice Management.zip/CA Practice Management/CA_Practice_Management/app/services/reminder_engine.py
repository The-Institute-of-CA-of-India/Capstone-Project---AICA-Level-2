"""
Reminder engine.

* scan() creates reminder records for compliances, notices, tasks and pending
  client documents according to the configured schedule
  (default: 15, 7, 3, 1 days before, on due date, after due date + weekly while overdue).
* Works fully offline (in-app + desktop notifications).
* Email / WhatsApp are OPTIONAL and only used when the user explicitly enables
  them in Settings and triggers sending. Nothing is sent automatically.
"""
from __future__ import annotations

import smtplib
import ssl
import urllib.parse
from datetime import date, timedelta
from email.message import EmailMessage
from typing import Callable, Optional

from sqlalchemy import or_

from app.database.db import session_scope
from app.database.models import (Client, ComplianceRecord, DocumentCollectionStatus, Notice, Reminder,
                                 ReminderHistory, Task, User)
from app.services import settings_service
from app.services.auth_service import current_user_id, current_username, has_perm
from app.services.compliance_engine import DONE_STATUSES, DUE_EXPR
from app.utils.date_utils import fmt_date, today
from app.utils.logger import get_logger

log = get_logger(__name__)

REMINDER_TYPES = ["Compliance Due Reminder", "Compliance Overdue Reminder", "Notice Reply Deadline",
                  "Notice Hearing", "Appeal Limitation", "Client Document Pending", "Task Deadline",
                  "Review Pending", "GST Filing Reminder", "Income Tax Filing Reminder", "TDS Filing Reminder",
                  "ROC Filing Reminder"]
CATEGORY_TYPE = {"GST": "GST Filing Reminder", "Income Tax": "Income Tax Filing Reminder",
                 "TDS": "TDS Filing Reminder", "ROC": "ROC Filing Reminder"}
OPEN = ("Pending", "Snoozed")


def milestone(due: date, offsets: list[int], t: date) -> Optional[date]:
    """Latest reminder date (<= today) according to the schedule; weekly repeats when overdue."""
    cands = []
    for off in offsets:
        d = due - timedelta(days=off) if off >= 0 else due + timedelta(days=-off)
        if d <= t:
            cands.append(d)
    if t > due and any(o < 0 for o in offsets):
        k = (t - due).days
        cands.append(due + timedelta(days=1 + ((k - 1) // 7) * 7))
    return max(cands) if cands else None


def _add(s, existing: set, rtype: str, ref_type: str, ref_id: int, client_id: Optional[int], title: str,
         message: str, due: Optional[date], remind_on: date, recipient: Optional[int]) -> int:
    key = (ref_type, ref_id, rtype, remind_on)
    if key in existing:
        return 0
    existing.add(key)
    s.add(Reminder(reminder_type=rtype, ref_type=ref_type, ref_id=ref_id, client_id=client_id, title=title,
                   message=message, due_date=due, remind_on=remind_on, recipient_id=recipient, status="Pending"))
    return 1


def scan() -> int:
    """Create due reminders. Idempotent - safe to run at any time."""
    t = today()
    offsets = [int(x) for x in (settings_service.get("reminder_offsets") or [15, 7, 3, 1, 0, -1])]
    horizon = t + timedelta(days=max([o for o in offsets if o >= 0] or [0]))
    created = 0
    with session_scope() as s:
        existing = {(r.ref_type, r.ref_id, r.reminder_type, r.remind_on) for r in
                    s.query(Reminder.ref_type, Reminder.ref_id, Reminder.reminder_type, Reminder.remind_on)
                    .filter(Reminder.remind_on >= t - timedelta(days=120))}
        # ---- compliances
        q = (s.query(ComplianceRecord, Client).join(Client, Client.id == ComplianceRecord.client_id)
             .filter(Client.status == "Active", ~ComplianceRecord.status.in_(DONE_STATUSES),
                     DUE_EXPR <= horizon, DUE_EXPR >= t - timedelta(days=90)))
        for r, c in q.all():
            due = r.revised_due_date or r.original_due_date
            m = milestone(due, offsets, t)
            if not m:
                continue
            overdue = m > due
            rtype = "Compliance Overdue Reminder" if overdue else CATEGORY_TYPE.get(r.category, "Compliance Due Reminder")
            days = (due - t).days
            msg = (f"{c.client_name}: {r.compliance_name} ({r.tax_period}) "
                   + (f"is OVERDUE by {-days} day(s) (due {fmt_date(due)})." if days < 0 else
                      f"is due on {fmt_date(due)} ({days} day(s) left). Status: {r.status}."))
            created += _add(s, existing, rtype, "compliance", r.id, c.id, f"{r.compliance_name} - {c.client_name}",
                            msg, due, m, r.assigned_staff_id)
            if r.status == "Under Review" and r.reviewer_id:
                created += _add(s, existing, "Review Pending", "compliance", r.id, c.id,
                                f"Review: {r.compliance_name} - {c.client_name}",
                                f"Compliance awaiting your review. Due {fmt_date(due)}.", due, t, r.reviewer_id)
        # ---- notices
        warn = int(settings_service.get("notice_warning_days") or 7)
        n_offsets = sorted(set(offsets + [warn]), reverse=True)
        for n, c in (s.query(Notice, Client).join(Client, Client.id == Notice.client_id)
                     .filter(Notice.status != "Closed").all()):
            if n.reply_due_date and n.status in ("Received", "Under Review", "Documents Awaited", "Drafting Reply",
                                                 "Reply Under Review", "Ready for Submission"):
                m = milestone(n.reply_due_date, n_offsets, t)
                if m:
                    days = (n.reply_due_date - t).days
                    created += _add(s, existing, "Notice Reply Deadline", "notice", n.id, c.id,
                                    f"Notice {n.notice_code} - {c.client_name}",
                                    f"{n.category} {n.section or ''}: reply due {fmt_date(n.reply_due_date)} "
                                    + (f"(OVERDUE {-days} days)" if days < 0 else f"({days} days left)"),
                                    n.reply_due_date, m, n.assigned_staff_id)
            hd = n.next_hearing_date or n.hearing_date
            if hd and hd >= t:
                m = milestone(hd, [7, 3, 1, 0], t)
                if m:
                    created += _add(s, existing, "Notice Hearing", "notice", n.id, c.id,
                                    f"Hearing {n.notice_code} - {c.client_name}",
                                    f"Hearing scheduled on {fmt_date(hd)}.", hd, m, n.assigned_staff_id)
            if n.appeal_deadline and n.appeal_deadline >= t - timedelta(days=1):
                m = milestone(n.appeal_deadline, [15, 7, 3, 1, 0], t)
                if m:
                    created += _add(s, existing, "Appeal Limitation", "notice", n.id, c.id,
                                    f"Appeal limitation {n.notice_code} - {c.client_name}",
                                    f"Appeal must be filed by {fmt_date(n.appeal_deadline)}.", n.appeal_deadline, m,
                                    n.reviewer_id or n.assigned_staff_id)
        # ---- tasks
        for tk in s.query(Task).filter(~Task.status.in_(["Completed", "Cancelled"]), Task.due_date.isnot(None),
                                       Task.due_date <= t + timedelta(days=3)).all():
            m = milestone(tk.due_date, [3, 1, 0, -1], t)
            if m:
                days = (tk.due_date - t).days
                created += _add(s, existing, "Task Deadline", "task", tk.id, tk.client_id, f"Task {tk.task_code}",
                                f"{tk.title} - due {fmt_date(tk.due_date)} "
                                + (f"(OVERDUE {-days} days)" if days < 0 else f"({days} days left)"),
                                tk.due_date, m, tk.assigned_to_id)
            if tk.status == "Under Review" and tk.reviewer_id:
                created += _add(s, existing, "Review Pending", "task", tk.id, tk.client_id, f"Review task {tk.task_code}",
                                f"{tk.title} is awaiting your review.", tk.due_date, t, tk.reviewer_id)
        # ---- pending client documents (follow-up date reached)
        rows = (s.query(DocumentCollectionStatus, ComplianceRecord, Client)
                .join(ComplianceRecord, ComplianceRecord.id == DocumentCollectionStatus.compliance_record_id)
                .join(Client, Client.id == DocumentCollectionStatus.client_id)
                .filter(DocumentCollectionStatus.received.is_(False), DocumentCollectionStatus.follow_up_date <= t,
                        ~ComplianceRecord.status.in_(DONE_STATUSES)).all())
        grouped: dict[int, list] = {}
        for d, r, c in rows:
            grouped.setdefault(r.id, []).append((d, r, c))
        for rid, items in grouped.items():
            d, r, c = items[0]
            created += _add(s, existing, "Client Document Pending", "collection", rid, c.id,
                            f"Documents pending - {c.client_name}",
                            f"{len(items)} document(s) pending for {r.compliance_name} ({r.tax_period}): "
                            + ", ".join(i[0].document_name for i in items[:6]), r.revised_due_date or r.original_due_date,
                            t, d.follow_up_staff_id)
        # ---- auto-complete reminders whose underlying item is closed
        open_rem = s.query(Reminder).filter(Reminder.status.in_(OPEN)).all()
        done_comp = {i for (i,) in s.query(ComplianceRecord.id).filter(ComplianceRecord.status.in_(DONE_STATUSES))}
        done_task = {i for (i,) in s.query(Task.id).filter(Task.status.in_(["Completed", "Cancelled"]))}
        closed_notice = {i for (i,) in s.query(Notice.id).filter(Notice.status == "Closed")}
        for rem in open_rem:
            if ((rem.ref_type in ("compliance", "collection") and rem.ref_id in done_comp) or
                    (rem.ref_type == "task" and rem.ref_id in done_task) or
                    (rem.ref_type == "notice" and rem.ref_id in closed_notice)):
                rem.status = "Completed"
                s.add(ReminderHistory(reminder_id=rem.id, action="Auto-completed", channel="System",
                                      details="Underlying item closed", user="system"))
    if created:
        log.info("Reminder scan created %s reminders", created)
    return created


def _rem_row(r: Reminder, c: Optional[Client], names: dict) -> dict:
    return {"_id": r.id, "id": r.id, "reminder_type": r.reminder_type, "ref_type": r.ref_type, "ref_id": r.ref_id,
            "client_name": c.client_name if c else "", "client_id": r.client_id, "title": r.title,
            "message": r.message, "due_date": r.due_date, "remind_on": r.remind_on,
            "recipient": names.get(r.recipient_id, ""), "recipient_id": r.recipient_id, "status": r.status,
            "snooze_until": r.snooze_until, "channel": r.channel, "created_at": r.created_at,
            "_color": {"Completed": "green", "Dismissed": "grey", "Snoozed": "blue"}.get(
                r.status, "red" if (r.due_date and r.due_date < today()) else "yellow")}


def list_reminders(status: Optional[str] = None, mine_only: bool = False, active_only: bool = False) -> list[dict]:
    t = today()
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = s.query(Reminder, Client).outerjoin(Client, Client.id == Reminder.client_id)
        if status:
            q = q.filter(Reminder.status == status)
        if active_only:
            q = q.filter(or_(Reminder.status == "Pending",
                             (Reminder.status == "Snoozed") & (Reminder.snooze_until <= t)))
        uid = current_user_id()
        if uid and (mine_only or not has_perm("view_all_clients")):
            q = q.filter(or_(Reminder.recipient_id == uid, Reminder.recipient_id.is_(None)))
        return [_rem_row(r, c, names) for r, c in q.order_by(Reminder.remind_on.desc(), Reminder.id.desc()).all()]


def active_for_current_user() -> list[dict]:
    return list_reminders(active_only=True, mine_only=True)


def _set(ids: list[int], status: str, action: str, details: str = "", snooze: Optional[date] = None) -> int:
    with session_scope() as s:
        n = 0
        for r in s.query(Reminder).filter(Reminder.id.in_(ids)):
            r.status = status
            r.snooze_until = snooze
            s.add(ReminderHistory(reminder_id=r.id, action=action, channel="In-App", details=details,
                                  user=current_username()))
            n += 1
        return n


def snooze(ids: list[int], days: int) -> int:
    until = today() + timedelta(days=max(1, days))
    return _set(ids, "Snoozed", "Snoozed", f"Until {fmt_date(until)}", until)


def complete(ids: list[int]) -> int:
    return _set(ids, "Completed", "Marked completed")


def dismiss(ids: list[int]) -> int:
    return _set(ids, "Dismissed", "Dismissed")


def log_displayed(ids: list[int], channel: str = "Desktop") -> None:
    with session_scope() as s:
        for i in ids:
            s.add(ReminderHistory(reminder_id=i, action="Displayed", channel=channel, user=current_username()))


def history(limit: int = 3000) -> list[dict]:
    with session_scope() as s:
        rows = (s.query(ReminderHistory, Reminder).join(Reminder, Reminder.id == ReminderHistory.reminder_id)
                .order_by(ReminderHistory.created_at.desc()).limit(limit).all())
        return [{"_id": h.id, "when": h.created_at, "reminder": r.title, "type": r.reminder_type,
                 "action": h.action, "channel": h.channel or "", "details": h.details or "", "user": h.user or ""}
                for h, r in rows]


# ------------------------------------------------------------------ optional channels
def send_email(ids: list[int], smtp_password: str, to_client: bool = False) -> tuple[int, list[str]]:
    """Send selected reminders by email. Only when enabled in settings; password is
    supplied at send time and never stored or logged."""
    if not settings_service.get("email_enabled"):
        raise RuntimeError("Email reminders are disabled. Enable and configure them in Settings > Email.")
    host, port = settings_service.get("smtp_host"), int(settings_service.get("smtp_port") or 587)
    user, sender = settings_service.get("smtp_user"), settings_service.get("email_from") or settings_service.get("smtp_user")
    if not host or not user:
        raise RuntimeError("SMTP host / user not configured.")
    sent, errors = 0, []
    with session_scope() as s:
        rems = s.query(Reminder).filter(Reminder.id.in_(ids)).all()
        jobs = []
        for r in rems:
            to = None
            if to_client and r.client_id:
                c = s.get(Client, r.client_id)
                to = c.email if c else None
            elif r.recipient_id:
                u = s.get(User, r.recipient_id)
                to = u.email if u else None
            jobs.append((r.id, to, r.title, r.message))
    ctx = ssl.create_default_context()
    try:
        server = smtplib.SMTP(host, port, timeout=20)
        if settings_service.get("smtp_use_tls"):
            server.starttls(context=ctx)
        server.login(user, smtp_password)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Could not connect to the mail server: {exc}") from exc
    try:
        for rid, to, title, message in jobs:
            if not to:
                errors.append(f"{title}: no email address")
                continue
            msg = EmailMessage()
            msg["Subject"] = f"[{settings_service.firm_name()}] Reminder: {title}"
            msg["From"] = sender
            msg["To"] = to
            msg.set_content(f"{message}\n\n-- \n{settings_service.firm_name()}\nThis is a reminder from our "
                            f"practice management system.")
            try:
                server.send_message(msg)
                sent += 1
                with session_scope() as s:
                    s.add(ReminderHistory(reminder_id=rid, action="Email sent", channel="Email",
                                          details=f"To {to}", user=current_username()))
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{title}: {exc}")
    finally:
        try:
            server.quit()
        except Exception:
            pass
    return sent, errors


def whatsapp_url(reminder_id: int) -> str:
    """Build a click-to-chat link (user opens it manually - no automatic sending)."""
    if not settings_service.get("whatsapp_enabled"):
        raise RuntimeError("WhatsApp integration is disabled. Enable it in Settings > Email & WhatsApp.")
    with session_scope() as s:
        r = s.get(Reminder, reminder_id)
        c = s.get(Client, r.client_id) if r and r.client_id else None
        if not c or not c.mobile:
            raise RuntimeError("Client mobile number not available.")
        digits = "".join(ch for ch in c.mobile if ch.isdigit())[-10:]
        text = f"Dear {c.contact_person or c.client_name},\n{r.message}\n- {settings_service.firm_name()}"
        s.add(ReminderHistory(reminder_id=r.id, action="WhatsApp link opened", channel="WhatsApp",
                              details=f"+91{digits}", user=current_username()))
    return f"https://wa.me/91{digits}?text={urllib.parse.quote(text)}"


# ------------------------------------------------------------------ scheduler
class ReminderScheduler:
    """Runs `callback` periodically using APScheduler (falls back to caller's QTimer)."""

    def __init__(self) -> None:
        self._sched = None

    def start(self, callback: Callable[[], None], minutes: int) -> bool:
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
        except ImportError:
            return False
        try:
            self._sched = BackgroundScheduler(daemon=True)
            self._sched.add_job(callback, "interval", minutes=max(5, int(minutes)), id="reminder_scan",
                                replace_existing=True, max_instances=1, coalesce=True)
            self._sched.start()
            return True
        except Exception as exc:  # noqa: BLE001
            log.error("APScheduler failed to start: %s", exc)
            self._sched = None
            return False

    def stop(self) -> None:
        if self._sched:
            try:
                self._sched.shutdown(wait=False)
            except Exception:
                pass
            self._sched = None
