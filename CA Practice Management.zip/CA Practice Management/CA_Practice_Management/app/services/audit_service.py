"""Audit trail and activity log."""
from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.database.db import session_scope
from app.database.models import Activity, AuditLog, Client
from app.utils.logger import get_logger

log = get_logger(__name__)
EXCLUDED = {"password_hash", "updated_at", "created_at"}


def _ser(v: Any) -> Any:
    if isinstance(v, (date, datetime)):
        return v.isoformat()
    return v


def model_to_dict(obj) -> dict:
    return {c.name: _ser(getattr(obj, c.name)) for c in obj.__table__.columns if c.name not in EXCLUDED}


def _user() -> str:
    from app.services.auth_service import current_username
    return current_username()


def log_audit(s: Session, action: str, table: str, record_id: Optional[int],
              old: Optional[dict] = None, new: Optional[dict] = None) -> None:
    """Record only changed keys for updates."""
    if old and new:
        changed = {k for k in set(old) | set(new) if old.get(k) != new.get(k)}
        if not changed:
            return
        old = {k: old.get(k) for k in changed}
        new = {k: new.get(k) for k in changed}
    s.add(AuditLog(user=_user(), table_name=table, record_id=record_id, action=action,
                   old_values=json.dumps(old, default=str) if old else None,
                   new_values=json.dumps(new, default=str) if new else None))


def log_activity(s: Session, module: str, action: str, description: str,
                 client_id: Optional[int] = None) -> None:
    s.add(Activity(user=_user(), module=module, action=action, description=description,
                   client_id=client_id))


def log_activity_standalone(module: str, action: str, description: str,
                            client_id: Optional[int] = None) -> None:
    try:
        with session_scope() as s:
            log_activity(s, module, action, description, client_id)
    except Exception as exc:  # noqa: BLE001
        log.error("Activity log failed: %s", exc)


def recent_activities(limit: int = 50) -> list[dict]:
    with session_scope() as s:
        rows = (s.query(Activity, Client.client_name).outerjoin(Client, Client.id == Activity.client_id)
                .order_by(Activity.created_at.desc()).limit(limit).all())
        return [{"_id": a.id, "when": a.created_at, "user": a.user, "module": a.module,
                 "action": a.action, "description": a.description, "client": cname or ""}
                for a, cname in rows]


def list_audit(limit: int = 2000) -> list[dict]:
    with session_scope() as s:
        rows = s.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
        return [{"_id": a.id, "when": a.created_at, "user": a.user, "table": a.table_name,
                 "record_id": a.record_id, "action": a.action, "old": a.old_values or "",
                 "new": a.new_values or ""} for a in rows]
