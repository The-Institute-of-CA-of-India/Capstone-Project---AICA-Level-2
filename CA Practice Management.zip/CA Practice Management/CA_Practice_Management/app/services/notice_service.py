"""Notice management - Workflow 3 (notice received -> reply -> hearing -> appeal -> closure)."""
from __future__ import annotations

import os
from datetime import date, timedelta
from typing import Optional

from sqlalchemy import func, or_

from app.database.db import session_scope
from app.database.models import Client, Notice, NoticeHistory, Reminder, User
from app.services import settings_service
from app.services.audit_service import log_activity, log_audit, model_to_dict
from app.services.auth_service import current_username, scope_user_id
from app.utils.date_utils import fmt_date, today
from app.utils.logger import get_logger

log = get_logger(__name__)

NOTICE_CATEGORIES = ["Income Tax Notice", "Income Tax Assessment", "Income Tax Appeal", "GST Notice",
                     "GST Assessment", "GST Audit", "GST Appeal", "TDS Notice", "ROC Notice", "MCA Notice",
                     "Other Departmental Notice"]
DEPARTMENTS = ["Income Tax", "GST", "TDS", "ROC", "MCA", "Other"]
NOTICE_STATUSES = ["Received", "Under Review", "Documents Awaited", "Drafting Reply", "Reply Under Review",
                   "Ready for Submission", "Reply Submitted", "Hearing Pending", "Appeal Pending", "Closed"]
PRE_REPLY = {"Received", "Under Review", "Documents Awaited", "Drafting Reply", "Reply Under Review",
             "Ready for Submission"}
FIELDS = ("client_id", "category", "department", "notice_type", "section", "notice_number", "din",
          "notice_date", "receipt_date", "assessment_year", "financial_year", "reply_due_date",
          "internal_deadline", "assigned_staff_id", "reviewer_id", "status", "reply_date", "ack_number",
          "hearing_date", "next_hearing_date", "appeal_deadline", "amount_disputed", "demand_amount", "remarks")


def _hist(s, notice_id: int, action: str, status: str = "", details: str = "",
          version: Optional[int] = None, doc: Optional[str] = None) -> None:
    s.add(NoticeHistory(notice_id=notice_id, action=action, status=status, details=details,
                        version_no=version, doc_path=doc, user=current_username()))


def _next_code(s) -> str:
    n = (s.query(func.max(Notice.id)).scalar() or 0) + 1
    while s.query(Notice.id).filter(Notice.notice_code == f"N-{n:05d}").first():
        n += 1
    return f"N-{n:05d}"


def notice_color(n: Notice) -> str:
    if n.status == "Closed":
        return "green"
    warn = int(settings_service.get("notice_warning_days") or 7)
    key_date = n.reply_due_date if n.status in PRE_REPLY else (n.next_hearing_date or n.hearing_date or n.appeal_deadline)
    if key_date and key_date < today():
        return "red"
    if key_date and key_date <= today() + timedelta(days=warn):
        return "yellow"
    return "blue" if n.status not in ("Received",) else "grey"


def _row(n: Notice, c: Client, names: dict) -> dict:
    t = today()
    start = n.receipt_date or n.notice_date
    aging = (t - start).days if start else None
    days_left = (n.reply_due_date - t).days if (n.reply_due_date and n.status in PRE_REPLY) else None
    bucket = ""
    if aging is not None:
        bucket = "0-30" if aging <= 30 else "31-60" if aging <= 60 else "61-90" if aging <= 90 else "90+"
    return {"_id": n.id, "id": n.id, "notice_code": n.notice_code, "client_id": c.id, "client_code": c.client_code,
            "client_name": c.client_name, "pan": c.pan, "category": n.category, "department": n.department,
            "notice_type": n.notice_type, "section": n.section, "notice_number": n.notice_number, "din": n.din,
            "notice_date": n.notice_date, "receipt_date": n.receipt_date, "assessment_year": n.assessment_year,
            "financial_year": n.financial_year, "reply_due_date": n.reply_due_date,
            "internal_deadline": n.internal_deadline, "staff": names.get(n.assigned_staff_id, ""),
            "reviewer": names.get(n.reviewer_id, ""), "assigned_staff_id": n.assigned_staff_id,
            "reviewer_id": n.reviewer_id, "status": n.status, "reply_date": n.reply_date,
            "ack_number": n.ack_number, "hearing_date": n.hearing_date, "next_hearing_date": n.next_hearing_date,
            "appeal_deadline": n.appeal_deadline, "amount_disputed": n.amount_disputed or 0.0,
            "demand_amount": n.demand_amount or 0.0, "remarks": n.remarks or "", "aging": aging,
            "aging_bucket": bucket, "days_left": days_left, "notice_doc_path": n.notice_doc_path,
            "reply_doc_path": n.reply_doc_path, "closed_date": n.closed_date,
            "closure_remarks": n.closure_remarks or "", "_color": notice_color(n)}


def list_notices(filters: Optional[dict] = None) -> list[dict]:
    f = filters or {}
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = s.query(Notice, Client).join(Client, Client.id == Notice.client_id)
        if f.get("client_id"):
            q = q.filter(Notice.client_id == f["client_id"])
        if f.get("open_only"):
            q = q.filter(Notice.status != "Closed")
        if f.get("department"):
            q = q.filter(Notice.department == f["department"])
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(Notice.assigned_staff_id == uid, Notice.reviewer_id == uid))
        return [_row(n, c, names) for n, c in q.order_by(Notice.reply_due_date.is_(None), Notice.reply_due_date).all()]


def get_notice(notice_id: int) -> Optional[dict]:
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        n = s.get(Notice, notice_id)
        return _row(n, s.get(Client, n.client_id), names) if n else None


def create_notice(data: dict, notice_doc: Optional[str] = None) -> int:
    """Workflow 3: record notice, internal deadline, reply task, reminders."""
    from app.services import reminder_engine, task_service
    if not data.get("client_id"):
        raise ValueError("Client is required.")
    if not data.get("receipt_date") and not data.get("notice_date"):
        raise ValueError("Date of notice or date of receipt is required.")
    buf = int(settings_service.get("notice_internal_buffer_days") or 3)
    with session_scope() as s:
        n = Notice(notice_code=_next_code(s), status="Received")
        s.add(n)
        for k in FIELDS:
            if k in data and data[k] not in (None, ""):
                setattr(n, k, data[k])
        if not n.receipt_date:
            n.receipt_date = n.notice_date
        if n.reply_due_date and not n.internal_deadline:
            n.internal_deadline = max(n.receipt_date or today(), n.reply_due_date - timedelta(days=buf))
        s.flush()
        _hist(s, n.id, "Notice received", n.status, f"{n.category} {n.section or ''} No. {n.notice_number or '-'}")
        log_audit(s, "CREATE", "notices", n.id, None, model_to_dict(n))
        log_activity(s, "Notices", "Received", f"{n.notice_code} {n.category} - reply due {fmt_date(n.reply_due_date)}",
                     n.client_id)
        nid, code, client_id = n.id, n.notice_code, n.client_id
        staff, reviewer, idl, rdd, cat = n.assigned_staff_id, n.reviewer_id, n.internal_deadline, n.reply_due_date, n.category
    if notice_doc:
        attach_document(nid, notice_doc, kind="notice")
    critical = bool(rdd and rdd <= today() + timedelta(days=int(settings_service.get("notice_warning_days") or 7)))
    task_service.save_task({"client_id": client_id, "title": f"Reply to {cat} {code}",
                            "description": f"Prepare and submit reply. Statutory reply due: {fmt_date(rdd)}",
                            "category": "Notice", "assigned_to_id": staff, "reviewer_id": reviewer,
                            "start_date": today(), "due_date": idl or rdd,
                            "priority": "Critical" if critical else "High", "status": "Pending",
                            "source_type": "notice", "source_id": nid})
    reminder_engine.scan()
    return nid


def update_notice(notice_id: int, data: dict) -> None:
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        old = model_to_dict(n)
        for k in FIELDS:
            if k in data:
                setattr(n, k, data[k])
        new = model_to_dict(n)
        if old["status"] != n.status:
            _hist(s, n.id, "Status changed", n.status, f"{old['status']} -> {n.status}")
        else:
            _hist(s, n.id, "Updated", n.status, ", ".join(k for k in new if old.get(k) != new.get(k)))
        log_audit(s, "UPDATE", "notices", n.id, old, new)


def attach_document(notice_id: int, path: str, kind: str = "notice", remarks: str = "") -> int:
    """kind = notice | reply. Reply documents are versioned in notice history."""
    from app.services import document_service
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        client_id, fy = n.client_id, n.financial_year
    doc_id = document_service.store_file(path, client_id=client_id, area="Notices", financial_year=None,
                                         category="Notice Reply" if kind == "reply" else
                                         ("Income Tax Notices" if "Income" in (get_notice(notice_id)["category"] or "") else "GST Notices"),
                                         title=os.path.basename(path), notice_id=notice_id, remarks=remarks)
    rel = document_service.get_document(doc_id)["stored_path"]
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        if kind == "reply":
            ver = s.query(NoticeHistory).filter(NoticeHistory.notice_id == notice_id,
                                                NoticeHistory.action == "Reply version").count() + 1
            n.reply_doc_path = rel
            _hist(s, n.id, "Reply version", n.status, remarks or f"Reply draft v{ver}", ver, rel)
        else:
            n.notice_doc_path = rel
            _hist(s, n.id, "Notice document attached", n.status, os.path.basename(path), None, rel)
    return doc_id


def record_reply(notice_id: int, reply_date: date, ack: str = "", reply_doc: Optional[str] = None,
                 remarks: str = "", next_status: str = "Reply Submitted") -> None:
    if not reply_date:
        raise ValueError("Reply submission date is required.")
    if reply_doc:
        attach_document(notice_id, reply_doc, kind="reply", remarks="Final reply submitted")
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        n.reply_date = reply_date
        n.ack_number = ack or n.ack_number
        n.status = next_status
        _hist(s, n.id, "Reply submitted", n.status, f"Ack {ack or '-'} on {fmt_date(reply_date)}. {remarks}")
        log_activity(s, "Notices", "Reply submitted", f"{n.notice_code} reply submitted", n.client_id)
        s.query(Reminder).filter(Reminder.ref_type == "notice", Reminder.ref_id == n.id,
                                 Reminder.reminder_type == "Notice Reply Deadline",
                                 Reminder.status.in_(["Pending", "Snoozed"])).update({"status": "Completed"},
                                                                                     synchronize_session=False)
    from app.services import task_service
    for t in task_service.list_tasks():
        if t["source_type"] == "notice" and t["source_id"] == notice_id and t["status"] not in ("Completed", "Cancelled"):
            task_service.change_status(t["id"], "Completed", "Reply submitted")


def add_hearing(notice_id: int, hearing_date: Optional[date], next_hearing: Optional[date] = None,
                appeal_deadline: Optional[date] = None, remarks: str = "") -> None:
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        if hearing_date:
            n.hearing_date = hearing_date
        n.next_hearing_date = next_hearing
        if appeal_deadline:
            n.appeal_deadline = appeal_deadline
            if n.status != "Closed":
                n.status = "Appeal Pending"
        elif next_hearing and n.status != "Closed":
            n.status = "Hearing Pending"
        _hist(s, n.id, "Hearing / appeal update", n.status,
              f"Hearing {fmt_date(hearing_date)}; next {fmt_date(next_hearing)}; appeal by {fmt_date(appeal_deadline)}. {remarks}")


def close_notice(notice_id: int, remarks: str, closed_on: Optional[date] = None) -> None:
    if not (remarks or "").strip():
        raise ValueError("Closure remarks are required.")
    with session_scope() as s:
        n = s.get(Notice, notice_id)
        n.status = "Closed"
        n.closed_date = closed_on or today()
        n.closure_remarks = remarks
        _hist(s, n.id, "Closed", "Closed", remarks)
        log_activity(s, "Notices", "Closed", f"{n.notice_code} closed", n.client_id)
        s.query(Reminder).filter(Reminder.ref_type == "notice", Reminder.ref_id == n.id,
                                 Reminder.status.in_(["Pending", "Snoozed"])).update({"status": "Completed"},
                                                                                     synchronize_session=False)


def history(notice_id: int) -> list[dict]:
    with session_scope() as s:
        return [{"_id": h.id, "when": h.created_at, "user": h.user, "action": h.action, "status": h.status or "",
                 "version": h.version_no or "", "details": h.details or "", "doc_path": h.doc_path or ""}
                for h in s.query(NoticeHistory).filter_by(notice_id=notice_id).order_by(NoticeHistory.created_at.desc())]


def generate_reply_draft(notice_id: int, path: str) -> str:
    """Create a Word reply skeleton (python-docx) for the notice."""
    try:
        from docx import Document as Docx
        from docx.shared import Pt
    except ImportError as exc:
        raise RuntimeError("python-docx is not installed. Run: pip install python-docx") from exc
    n = get_notice(notice_id)
    firm = settings_service.firm_name()
    doc = Docx()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(11)
    doc.add_heading(firm, level=1)
    doc.add_paragraph(settings_service.get("firm_address") or "Chartered Accountants")
    doc.add_paragraph(f"Date: {fmt_date(today())}")
    doc.add_paragraph("To,\nThe Assessing / Proper Officer,\n" + (n["department"] or "") + " Department")
    doc.add_paragraph(f"Subject: Reply to {n['category']} u/s {n['section'] or '-'} - Notice No. "
                      f"{n['notice_number'] or '-'} dated {fmt_date(n['notice_date'])} (DIN: {n['din'] or '-'})")
    doc.add_paragraph(f"Assessee: {n['client_name']}   PAN: {n['pan'] or '-'}   AY: {n['assessment_year'] or '-'}")
    doc.add_paragraph("Respected Sir / Madam,")
    doc.add_paragraph("1. With reference to the above notice, on behalf of our client, we submit as under:")
    doc.add_paragraph("2. [Point-wise reply to be drafted here]")
    doc.add_paragraph("3. Documents enclosed: [list]")
    doc.add_paragraph("We request you to kindly take the above submissions on record.")
    doc.add_paragraph(f"\nFor {firm}\nChartered Accountants\n\n\n(Authorised Signatory)")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    doc.save(path)
    return path
