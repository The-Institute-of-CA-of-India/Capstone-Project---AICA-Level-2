"""Client document collection tracker (checklists per compliance) - Workflow 4."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

from sqlalchemy import or_

from app.database.db import session_scope
from app.database.models import (Client, ComplianceMaster, ComplianceRecord, DocumentChecklist,
                                 DocumentCollectionStatus, User)
from app.services.audit_service import log_activity
from app.services.auth_service import scope_user_id
from app.services.compliance_engine import DONE_STATUSES, DUE_EXPR
from app.utils.date_utils import today


# ------------------------------------------------------------------ templates
def list_checklist(master_id: int, client_id: Optional[int] = None) -> list[dict]:
    with session_scope() as s:
        q = s.query(DocumentChecklist).filter(DocumentChecklist.master_id == master_id)
        q = q.filter(DocumentChecklist.client_id == client_id) if client_id else \
            q.filter(DocumentChecklist.client_id.is_(None))
        return [{"_id": c.id, "id": c.id, "document_name": c.document_name, "is_mandatory": c.is_mandatory,
                 "sort_order": c.sort_order} for c in q.order_by(DocumentChecklist.sort_order)]


def save_checklist(master_id: int, items: list[dict], client_id: Optional[int] = None) -> None:
    """Replace the checklist template (firm-wide or client-specific)."""
    with session_scope() as s:
        q = s.query(DocumentChecklist).filter(DocumentChecklist.master_id == master_id)
        q = q.filter(DocumentChecklist.client_id == client_id) if client_id else \
            q.filter(DocumentChecklist.client_id.is_(None))
        q.delete(synchronize_session=False)
        for i, it in enumerate(items, start=1):
            name = (it.get("document_name") or "").strip()
            if name:
                s.add(DocumentChecklist(master_id=master_id, client_id=client_id, document_name=name,
                                        is_mandatory=bool(it.get("is_mandatory", True)), sort_order=i))


def _template_for(s, master_id: int, client_id: int) -> list[DocumentChecklist]:
    own = (s.query(DocumentChecklist).filter_by(master_id=master_id, client_id=client_id)
           .order_by(DocumentChecklist.sort_order).all())
    if own:
        return own
    return (s.query(DocumentChecklist).filter(DocumentChecklist.master_id == master_id,
                                              DocumentChecklist.client_id.is_(None))
            .order_by(DocumentChecklist.sort_order).all())


def ensure_for_record(s, record: ComplianceRecord) -> int:
    have = {n for (n,) in s.query(DocumentCollectionStatus.document_name)
            .filter_by(compliance_record_id=record.id)}
    n = 0
    for t in _template_for(s, record.master_id, record.client_id):
        if t.document_name in have:
            continue
        s.add(DocumentCollectionStatus(compliance_record_id=record.id, client_id=record.client_id,
                                       document_name=t.document_name, is_mandatory=t.is_mandatory,
                                       follow_up_staff_id=record.assigned_staff_id,
                                       follow_up_date=record.doc_collection_deadline))
        n += 1
    return n


def ensure_upcoming(days: int = 45, client_id: Optional[int] = None) -> int:
    """Create checklist rows for open compliances due within `days` (and overdue ones)."""
    n = 0
    with session_scope() as s:
        q = s.query(ComplianceRecord).filter(~ComplianceRecord.status.in_(DONE_STATUSES),
                                             DUE_EXPR <= today() + timedelta(days=days),
                                             DUE_EXPR >= today() - timedelta(days=60))
        if client_id:
            q = q.filter(ComplianceRecord.client_id == client_id)
        for r in q.all():
            n += ensure_for_record(s, r)
    return n


def ensure_for_record_id(record_id: int) -> int:
    with session_scope() as s:
        r = s.get(ComplianceRecord, record_id)
        return ensure_for_record(s, r) if r else 0


# ------------------------------------------------------------------ status
def list_status(client_id: Optional[int] = None, record_id: Optional[int] = None,
                pending_only: bool = False, include_closed: bool = False) -> list[dict]:
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = (s.query(DocumentCollectionStatus, ComplianceRecord, Client)
             .join(ComplianceRecord, ComplianceRecord.id == DocumentCollectionStatus.compliance_record_id)
             .join(Client, Client.id == DocumentCollectionStatus.client_id))
        if client_id:
            q = q.filter(DocumentCollectionStatus.client_id == client_id)
        if record_id:
            q = q.filter(DocumentCollectionStatus.compliance_record_id == record_id)
        if pending_only:
            q = q.filter(DocumentCollectionStatus.received.is_(False))
        if not include_closed and not record_id:
            q = q.filter(~ComplianceRecord.status.in_(DONE_STATUSES))
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(DocumentCollectionStatus.follow_up_staff_id == uid, Client.assigned_staff_id == uid))
        out = []
        t = today()
        for d, r, c in q.order_by(DocumentCollectionStatus.follow_up_date, Client.client_name).all():
            overdue = (not d.received) and d.follow_up_date and d.follow_up_date < t
            out.append({"_id": d.id, "id": d.id, "client_id": c.id, "client_code": c.client_code,
                        "client_name": c.client_name, "record_id": r.id, "compliance": r.compliance_name,
                        "period": r.tax_period, "due": r.revised_due_date or r.original_due_date,
                        "document_name": d.document_name, "mandatory": d.is_mandatory,
                        "received": "Received" if d.received else "Not Received", "received_bool": d.received,
                        "received_date": d.received_date, "follow_up_staff": names.get(d.follow_up_staff_id, ""),
                        "follow_up_staff_id": d.follow_up_staff_id, "follow_up_date": d.follow_up_date,
                        "remarks": d.remarks or "",
                        "_color": "green" if d.received else ("red" if overdue else "yellow")})
        return out


def mark_received(ids: list[int], received: bool = True, received_date: Optional[date] = None,
                  remarks: str = "") -> int:
    with session_scope() as s:
        n = 0
        for d in s.query(DocumentCollectionStatus).filter(DocumentCollectionStatus.id.in_(ids)):
            d.received = received
            d.received_date = (received_date or today()) if received else None
            if remarks:
                d.remarks = remarks
            n += 1
        # Auto-move compliance from "Awaiting Documents" when all mandatory docs are in
        rec_ids = {d.compliance_record_id for d in
                   s.query(DocumentCollectionStatus).filter(DocumentCollectionStatus.id.in_(ids))}
        for rid in rec_ids:
            pending = s.query(DocumentCollectionStatus).filter_by(compliance_record_id=rid, received=False,
                                                                  is_mandatory=True).count()
            r = s.get(ComplianceRecord, rid)
            if pending == 0 and r.status in ("Awaiting Documents", "Not Started", "Overdue"):
                r.status = "In Progress"
            elif pending and r.status == "Not Started":
                r.status = "Awaiting Documents"
        return n


def set_follow_up(ids: list[int], staff_id: Optional[int], follow_date: Optional[date],
                  remarks: str = "") -> int:
    with session_scope() as s:
        n = 0
        for d in s.query(DocumentCollectionStatus).filter(DocumentCollectionStatus.id.in_(ids)):
            if staff_id:
                d.follow_up_staff_id = staff_id
            if follow_date:
                d.follow_up_date = follow_date
            if remarks:
                d.remarks = remarks
            n += 1
        return n


def progress_by_client() -> list[dict]:
    agg: dict[int, dict] = {}
    for r in list_status():
        a = agg.setdefault(r["client_id"], {"_id": r["client_id"], "client_code": r["client_code"],
                                            "client_name": r["client_name"], "total": 0, "received": 0})
        a["total"] += 1
        a["received"] += 1 if r["received_bool"] else 0
    out = []
    for a in agg.values():
        a["pending"] = a["total"] - a["received"]
        a["progress"] = round(100.0 * a["received"] / a["total"], 1) if a["total"] else 100.0
        a["progress_text"] = f"{a['progress']:.0f}%"
        a["_color"] = "green" if a["progress"] >= 100 else ("yellow" if a["progress"] >= 50 else "red")
        out.append(a)
    return sorted(out, key=lambda x: x["progress"])


def generate_followup_tasks(ids: Optional[list[int]] = None, follow_date: Optional[date] = None) -> int:
    """Workflow 4: one follow-up task per client+compliance for missing documents."""
    from app.services import task_service
    rows = [r for r in list_status(pending_only=True) if not ids or r["id"] in ids]
    groups: dict[tuple, list] = {}
    for r in rows:
        groups.setdefault((r["client_id"], r["record_id"]), []).append(r)
    created = 0
    for (client_id, record_id), items in groups.items():
        if task_service.open_task_exists("doc_followup", record_id):
            continue
        first = items[0]
        task_service.save_task({
            "client_id": client_id, "title": f"Follow up: pending documents for {first['compliance']} ({first['period']})",
            "description": "Pending documents:\n- " + "\n- ".join(i["document_name"] for i in items),
            "category": "Document Collection", "assigned_to_id": first["follow_up_staff_id"],
            "start_date": today(), "due_date": follow_date or first["follow_up_date"] or today() + timedelta(days=2),
            "priority": "High" if (first["due"] and first["due"] <= today() + timedelta(days=7)) else "Medium",
            "status": "Pending", "source_type": "doc_followup", "source_id": record_id})
        created += 1
    if created:
        with session_scope() as s:
            log_activity(s, "Doc Collection", "Follow-up tasks", f"{created} follow-up tasks generated")
    return created


def pending_count() -> int:
    return sum(1 for r in list_status(pending_only=True))
