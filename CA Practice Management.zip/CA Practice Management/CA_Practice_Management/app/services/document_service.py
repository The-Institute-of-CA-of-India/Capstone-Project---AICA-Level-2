"""
Client-wise document repository on disk; only relative paths are stored in SQLite.

    CA_Firm_Data/Clients/<CLIENT_CODE>/GST/FY_2026-27/...
                                      /Income_Tax/AY_2027-28/...
                                      /TDS/FY_2026-27/  /ROC/FY_2026-27/
                                      /Notices/  /Audit/  /General_Documents/
Documents are never hard-deleted from the UI: "delete" moves them to recycle
status (file stays on disk) and can be restored. Re-uploading the same file
name creates a new version; earlier versions are kept.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from typing import Optional

from sqlalchemy import or_

import config
from app.database.db import session_scope
from app.database.models import Client, Document, DocumentVersion
from app.services.audit_service import log_activity, log_audit
from app.services.auth_service import current_username, scope_user_id
from app.utils.date_utils import ay_of_fy
from app.utils.logger import get_logger

log = get_logger(__name__)

DOCUMENT_CATEGORIES = ["PAN Card", "Aadhaar", "GST Registration", "TAN", "Incorporation Certificate",
                       "Partnership Deed", "LLP Agreement", "Financial Statements", "Trial Balance",
                       "Bank Statements", "Sales Register", "Purchase Register", "GST Returns", "TDS Returns",
                       "Tax Audit Documents", "Income Tax Returns", "Income Tax Notices", "GST Notices",
                       "ROC Documents", "Audit Working Papers", "Engagement Letters", "Acknowledgement",
                       "Notice Reply", "Other Documents"]
AREAS = {"GST": "GST", "Income Tax": "Income_Tax", "TDS": "TDS", "ROC": "ROC", "Notices": "Notices",
         "Audit": "Audit", "General": "General_Documents", "Other": "General_Documents"}
ALLOWED_EXT = {".pdf", ".xlsx", ".xls", ".xlsm", ".csv", ".doc", ".docx", ".jpg", ".jpeg", ".png",
               ".txt", ".zip", ".xml", ".json"}


def docs_root() -> str:
    root = config.get_path("documents_dir")
    os.makedirs(root, exist_ok=True)
    return root


def abs_path(stored_path: str) -> str:
    if not stored_path:
        return ""
    return stored_path if os.path.isabs(stored_path) else os.path.join(docs_root(), stored_path)


def _safe(name: str) -> str:
    return re.sub(r"[^\w\-. ()&]", "_", name).strip() or "file"


def _client_code(client_id: int) -> str:
    with session_scope() as s:
        c = s.get(Client, client_id)
        if not c:
            raise ValueError("Client not found.")
        return c.client_code


def client_folder(client_id: int) -> str:
    return os.path.join(docs_root(), "Clients", _client_code(client_id))


def ensure_client_folders(client_id: int) -> str:
    base = client_folder(client_id)
    for sub in set(AREAS.values()):
        os.makedirs(os.path.join(base, sub), exist_ok=True)
    return base


def _rel_folder(client_id: int, area: str, fy: Optional[str]) -> str:
    sub = AREAS.get(area, "General_Documents")
    parts = ["Clients", _client_code(client_id), sub]
    if fy and sub in ("GST", "TDS", "ROC", "Audit"):
        parts.append(f"FY_{fy}")
    elif fy and sub == "Income_Tax":
        parts.append(f"AY_{ay_of_fy(fy)}")
    return os.path.join(*parts)


def _unique_dest(folder_abs: str, file_name: str) -> str:
    base, ext = os.path.splitext(file_name)
    cand, n = file_name, 2
    while os.path.exists(os.path.join(folder_abs, cand)):
        cand = f"{base}_v{n}{ext}"
        n += 1
    return cand


def store_file(src: str, client_id: int, area: str = "General", financial_year: Optional[str] = None,
               category: str = "Other Documents", title: Optional[str] = None, tags: str = "",
               remarks: str = "", compliance_record_id: Optional[int] = None,
               notice_id: Optional[int] = None, task_id: Optional[int] = None) -> int:
    """Copy a file into the repository. Same file name in the same folder -> new version."""
    if not src or not os.path.isfile(src):
        raise ValueError(f"File not found: {src}")
    ext = os.path.splitext(src)[1].lower()
    if ext not in ALLOWED_EXT:
        raise ValueError(f"File type {ext} is not allowed.")
    file_name = _safe(os.path.basename(src))
    rel_folder = _rel_folder(client_id, area, financial_year)
    folder_abs = os.path.join(docs_root(), rel_folder)
    os.makedirs(folder_abs, exist_ok=True)
    dest_name = _unique_dest(folder_abs, file_name)
    shutil.copy2(src, os.path.join(folder_abs, dest_name))
    rel = os.path.join(rel_folder, dest_name)
    size = os.path.getsize(os.path.join(folder_abs, dest_name))
    with session_scope() as s:
        existing = (s.query(Document).filter(Document.client_id == client_id, Document.file_name == file_name,
                                             Document.area == area, Document.financial_year == financial_year,
                                             Document.is_deleted.is_(False)).first())
        if existing:
            existing.current_version = (existing.current_version or 1) + 1
            existing.stored_path = rel
            existing.file_size = size
            existing.uploaded_by = current_username()
            existing.uploaded_at = datetime.now()
            if remarks:
                existing.remarks = remarks
            s.add(DocumentVersion(document_id=existing.id, version_no=existing.current_version, stored_path=rel,
                                  file_size=size, uploaded_by=current_username(), remarks=remarks))
            log_activity(s, "Documents", "New version",
                         f"{file_name} - version {existing.current_version}", client_id)
            return existing.id
        d = Document(client_id=client_id, category=category, area=area, financial_year=financial_year,
                     compliance_record_id=compliance_record_id, notice_id=notice_id, task_id=task_id,
                     title=title or os.path.splitext(file_name)[0], file_name=file_name, stored_path=rel,
                     file_type=ext.lstrip("."), file_size=size, tags=tags, remarks=remarks, current_version=1,
                     uploaded_by=current_username())
        s.add(d)
        s.flush()
        s.add(DocumentVersion(document_id=d.id, version_no=1, stored_path=rel, file_size=size,
                              uploaded_by=current_username(), remarks=remarks))
        log_audit(s, "UPLOAD", "documents", d.id, None, {"file": rel})
        log_activity(s, "Documents", "Uploaded", f"{file_name} ({category})", client_id)
        return d.id


def add_version(doc_id: int, src: str, remarks: str = "") -> int:
    with session_scope() as s:
        d = s.get(Document, doc_id)
        if not d:
            raise ValueError("Document not found.")
        client_id, area, fy = d.client_id, d.area, d.financial_year
        orig_name = d.file_name
    ext = os.path.splitext(src)[1].lower()
    if ext not in ALLOWED_EXT:
        raise ValueError(f"File type {ext} is not allowed.")
    folder_rel = _rel_folder(client_id, area, fy)
    folder_abs = os.path.join(docs_root(), folder_rel)
    os.makedirs(folder_abs, exist_ok=True)
    base = os.path.splitext(orig_name)[0]
    dest_name = _unique_dest(folder_abs, f"{base}{ext}")
    shutil.copy2(src, os.path.join(folder_abs, dest_name))
    rel = os.path.join(folder_rel, dest_name)
    size = os.path.getsize(os.path.join(folder_abs, dest_name))
    with session_scope() as s:
        d = s.get(Document, doc_id)
        d.current_version = (d.current_version or 1) + 1
        d.stored_path = rel
        d.file_size = size
        d.uploaded_by = current_username()
        d.uploaded_at = datetime.now()
        s.add(DocumentVersion(document_id=d.id, version_no=d.current_version, stored_path=rel, file_size=size,
                              uploaded_by=current_username(), remarks=remarks))
        log_activity(s, "Documents", "New version", f"{d.file_name} - version {d.current_version}", d.client_id)
        return d.current_version


def _doc_dict(d: Document, c: Client) -> dict:
    return {"_id": d.id, "id": d.id, "client_id": d.client_id, "client_code": c.client_code,
            "client_name": c.client_name, "category": d.category, "area": d.area,
            "financial_year": d.financial_year or "", "title": d.title, "file_name": d.file_name,
            "file_type": (d.file_type or "").upper(), "size_kb": round((d.file_size or 0) / 1024, 1),
            "version": d.current_version, "tags": d.tags or "", "remarks": d.remarks or "",
            "uploaded_by": d.uploaded_by, "uploaded_at": d.uploaded_at, "stored_path": d.stored_path,
            "compliance_record_id": d.compliance_record_id, "notice_id": d.notice_id,
            "is_deleted": d.is_deleted, "_color": "grey" if d.is_deleted else None}


def list_documents(client_id: Optional[int] = None, area: Optional[str] = None, fy: Optional[str] = None,
                   include_deleted: bool = False, search: str = "", notice_id: Optional[int] = None,
                   compliance_record_id: Optional[int] = None) -> list[dict]:
    with session_scope() as s:
        q = s.query(Document, Client).join(Client, Client.id == Document.client_id)
        if client_id:
            q = q.filter(Document.client_id == client_id)
        if area:
            q = q.filter(Document.area == area)
        if fy:
            q = q.filter(Document.financial_year == fy)
        if notice_id:
            q = q.filter(Document.notice_id == notice_id)
        if compliance_record_id:
            q = q.filter(Document.compliance_record_id == compliance_record_id)
        if not include_deleted:
            q = q.filter(Document.is_deleted.is_(False))
        if search:
            like = f"%{search}%"
            q = q.filter(or_(Document.file_name.ilike(like), Document.title.ilike(like),
                             Document.tags.ilike(like), Document.remarks.ilike(like)))
        uid = scope_user_id()
        if uid:
            q = q.filter(or_(Client.assigned_staff_id == uid, Client.assigned_manager_id == uid,
                             Client.assigned_partner_id == uid))
        return [_doc_dict(d, c) for d, c in q.order_by(Document.uploaded_at.desc()).all()]


def get_document(doc_id: int) -> Optional[dict]:
    with session_scope() as s:
        d = s.get(Document, doc_id)
        return _doc_dict(d, s.get(Client, d.client_id)) if d else None


def list_versions(doc_id: int) -> list[dict]:
    with session_scope() as s:
        return [{"_id": v.id, "version": v.version_no, "stored_path": v.stored_path,
                 "size_kb": round((v.file_size or 0) / 1024, 1), "uploaded_by": v.uploaded_by,
                 "uploaded_at": v.uploaded_at, "remarks": v.remarks or ""}
                for v in s.query(DocumentVersion).filter_by(document_id=doc_id)
                .order_by(DocumentVersion.version_no.desc())]


def update_metadata(doc_id: int, data: dict) -> None:
    with session_scope() as s:
        d = s.get(Document, doc_id)
        for k in ("title", "category", "tags", "remarks"):
            if k in data:
                setattr(d, k, data[k])


def soft_delete(doc_id: int) -> None:
    with session_scope() as s:
        d = s.get(Document, doc_id)
        d.is_deleted = True
        log_audit(s, "SOFT_DELETE", "documents", d.id, None, {"file": d.stored_path})
        log_activity(s, "Documents", "Moved to recycle", d.file_name, d.client_id)


def restore(doc_id: int) -> None:
    with session_scope() as s:
        d = s.get(Document, doc_id)
        d.is_deleted = False
        log_activity(s, "Documents", "Restored", d.file_name, d.client_id)


def open_path(path: str) -> None:
    """Open a file / folder with the default Windows (or OS) application."""
    path = abs_path(path) if not os.path.isabs(path) else path
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def copy_to(doc_id: int, dest_folder: str, version_path: Optional[str] = None) -> str:
    d = get_document(doc_id)
    src = abs_path(version_path or d["stored_path"])
    os.makedirs(dest_folder, exist_ok=True)
    dest = os.path.join(dest_folder, os.path.basename(src))
    shutil.copy2(src, dest)
    return dest


def client_tree() -> dict:
    """{client: {area: set(fy)}} for the repository tree."""
    tree: dict = {}
    for d in list_documents():
        tree.setdefault((d["client_id"], d["client_name"], d["client_code"]), {}) \
            .setdefault(d["area"] or "General", set()).add(d["financial_year"] or "")
    return tree
