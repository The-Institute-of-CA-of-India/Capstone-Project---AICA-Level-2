"""Client master business logic, onboarding workflow, Excel import/export."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

from sqlalchemy import func, or_

import config
from app.database.db import session_scope
from app.database.models import (BillingRecord, Client, ClientComplianceApplicability, ClientContact,
                                 ComplianceRecord, Document, Notice, Task, User)
from app.services import settings_service
from app.services.audit_service import log_activity, log_audit, model_to_dict
from app.services.auth_service import current_user_id, scope_user_id
from app.utils.date_utils import parse_date, today
from app.utils.excel_utils import BOOL_FIELDS, DATE_FIELDS, export_rows, read_client_import
from app.utils.formatters import to_float, yes_no
from app.utils.logger import get_logger
from app.utils.validators import clean_id, validate_client

log = get_logger(__name__)

ENTITY_TYPES = ["Individual", "Proprietorship", "Partnership Firm", "LLP", "Private Limited Company",
                "Public Limited Company", "HUF", "Trust", "Society", "Association of Persons", "Other"]
CLIENT_STATUSES = ["Active", "Inactive"]
RISK_CATEGORIES = ["Low", "Medium", "High"]
BILLING_FREQUENCIES = ["Monthly", "Quarterly", "Half-Yearly", "Annual", "Per Assignment", "One-Time"]
GST_REG_TYPES = ["Not Registered", "Normal Taxpayer", "Input Service Distributor", "TDS Deductor (GST)",
                 "TCS Collector (GST)", "Casual Taxable Person", "Non-Resident Taxable Person"]
GST_SCHEMES = ["Regular", "Composition"]
GST_FREQUENCIES = ["Monthly", "Quarterly"]
GST_STATUSES = ["Active", "Suspended", "Cancelled", "Not Applicable"]
ITR_FORMS = ["", "ITR-1", "ITR-2", "ITR-3", "ITR-4", "ITR-5", "ITR-6", "ITR-7"]
INDUSTRIES = ["Trading", "Manufacturing", "IT Services", "Real Estate", "Construction", "Healthcare",
              "Education", "Textiles", "Hospitality", "Logistics", "Professional Services", "Agriculture",
              "Financial Services", "Retail", "Salaried", "NGO / Charitable", "Other"]
DEFAULT_ITR = {"Individual": "ITR-2", "Proprietorship": "ITR-3", "HUF": "ITR-2", "Partnership Firm": "ITR-5",
               "LLP": "ITR-5", "Private Limited Company": "ITR-6", "Public Limited Company": "ITR-6",
               "Trust": "ITR-7", "Society": "ITR-7", "Association of Persons": "ITR-5", "Other": "ITR-5"}
ID_FIELDS = ("pan", "tan", "gstin", "cin_llpin")
CLIENT_FIELDS = [c.name for c in Client.__table__.columns
                 if c.name not in ("id", "client_code", "created_at", "updated_at")]


def next_client_code(s) -> str:
    last = s.query(func.max(Client.id)).scalar() or 0
    n = last + 1
    while True:
        code = f"{config.CLIENT_CODE_PREFIX}-{n:04d}"
        if not s.query(Client.id).filter(Client.client_code == code).first():
            return code
        n += 1


def _scope(q):
    uid = scope_user_id()
    if uid:
        q = q.filter(or_(Client.assigned_staff_id == uid, Client.assigned_manager_id == uid,
                         Client.assigned_partner_id == uid))
    return q


def client_to_dict(c: Client, names: Optional[dict] = None) -> dict:
    d = {k: getattr(c, k) for k in [col.name for col in Client.__table__.columns]}
    d["_id"] = c.id
    if names is not None:
        d["partner"] = names.get(c.assigned_partner_id, "")
        d["manager"] = names.get(c.assigned_manager_id, "")
        d["staff"] = names.get(c.assigned_staff_id, "")
    return d


def list_clients(status: Optional[str] = None) -> list[dict]:
    with session_scope() as s:
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        q = _scope(s.query(Client))
        if status:
            q = q.filter(Client.status == status)
        pending = dict(s.query(ComplianceRecord.client_id, func.count(ComplianceRecord.id))
                       .filter(~ComplianceRecord.status.in_(["Filed", "Completed", "Not Applicable"]))
                       .group_by(ComplianceRecord.client_id).all())
        out = []
        for c in q.order_by(Client.client_name):
            d = client_to_dict(c, names)
            d["pending_compliances"] = pending.get(c.id, 0)
            d["_color"] = "grey" if c.status != "Active" else None
            d["_search"] = f"{c.legal_name or ''} {c.contact_person or ''}"
            out.append(d)
        return out


def client_choices(active_only: bool = True) -> list[tuple[str, int]]:
    with session_scope() as s:
        q = _scope(s.query(Client.id, Client.client_name, Client.client_code))
        if active_only:
            q = q.filter(Client.status == "Active")
        return [(f"{n} [{code}]", i) for i, n, code in q.order_by(Client.client_name)]


def get_client(client_id: int) -> Optional[dict]:
    with session_scope() as s:
        c = s.get(Client, client_id)
        if not c:
            return None
        names = {u.id: u.full_name for u in s.query(User.id, User.full_name)}
        d = client_to_dict(c, names)
        d["contacts"] = [{"id": x.id, "name": x.name, "designation": x.designation, "mobile": x.mobile,
                          "email": x.email, "is_primary": x.is_primary} for x in c.contacts]
        return d


def find_duplicates(pan: Optional[str], gstin: Optional[str], tan: Optional[str] = None,
                    exclude_id: Optional[int] = None) -> dict:
    out = {"pan": [], "gstin": [], "tan": []}
    with session_scope() as s:
        for key, val in (("pan", clean_id(pan)), ("gstin", clean_id(gstin)), ("tan", clean_id(tan))):
            if not val:
                continue
            q = s.query(Client).filter(getattr(Client, key) == val)
            if exclude_id:
                q = q.filter(Client.id != exclude_id)
            out[key] = [f"{c.client_name} [{c.client_code}]" for c in q]
    return out


def save_client(data: dict, client_id: Optional[int] = None,
                applicability_overrides: Optional[dict] = None,
                contacts: Optional[list[dict]] = None, allow_duplicate_pan: bool = True) -> int:
    """Create / update a client. Raises ValueError on validation / duplicate GSTIN errors."""
    data = dict(data)
    for k in ID_FIELDS:
        data[k] = clean_id(data.get(k))
    errors, _warn = validate_client(data)
    if errors:
        raise ValueError("\n".join(errors))
    dups = find_duplicates(data.get("pan"), data.get("gstin"), None, client_id)
    if dups["gstin"]:
        raise ValueError(f"Duplicate GSTIN - already used by: {', '.join(dups['gstin'])}")
    if dups["pan"] and not allow_duplicate_pan:
        raise ValueError(f"Duplicate PAN - already used by: {', '.join(dups['pan'])}")
    if not data.get("itr_form"):
        data["itr_form"] = DEFAULT_ITR.get(data.get("entity_type"), "")
    if data.get("gstin") and not data.get("gst_state"):
        from app.utils.validators import GST_STATE_CODES
        data["gst_state"] = GST_STATE_CODES.get(data["gstin"][:2])
    with session_scope() as s:
        if client_id:
            c = s.get(Client, client_id)
            if not c:
                raise ValueError("Client not found.")
            old = model_to_dict(c)
        else:
            c = Client(client_code=next_client_code(s))
            s.add(c)
            old = None
        for k in CLIENT_FIELDS:
            if k in data:
                v = data[k]
                if isinstance(v, str):
                    v = v.strip() or None
                setattr(c, k, v)
        if not c.status:
            c.status = "Active"
        if not c.acquisition_date and not client_id:
            c.acquisition_date = today()
        if not c.financial_year:
            c.financial_year = settings_service.current_fy()
        s.flush()
        if applicability_overrides is not None:
            s.query(ClientComplianceApplicability).filter_by(client_id=c.id).delete()
            for mid, val in applicability_overrides.items():
                s.add(ClientComplianceApplicability(client_id=c.id, master_id=int(mid), applicable=bool(val)))
        if contacts is not None:
            s.query(ClientContact).filter_by(client_id=c.id).delete()
            for ct in contacts:
                if (ct.get("name") or "").strip():
                    s.add(ClientContact(client_id=c.id, name=ct["name"].strip(), designation=ct.get("designation"),
                                        mobile=ct.get("mobile"), email=ct.get("email"),
                                        is_primary=bool(ct.get("is_primary"))))
        new = model_to_dict(c)
        log_audit(s, "UPDATE" if old else "CREATE", "clients", c.id, old, new)
        log_activity(s, "Clients", "Updated" if old else "Created",
                     f"Client {c.client_name} [{c.client_code}] {'updated' if old else 'created'}", c.id)
        cid = c.id
    from app.services import document_service
    document_service.ensure_client_folders(cid)
    return cid


def onboard_client(client_id: int, fy: Optional[str] = None) -> dict:
    """Workflow 1: generate compliances, checklists, onboarding task and reminders."""
    from app.services import collection_service, compliance_engine, reminder_engine, task_service
    fy = fy or settings_service.current_fy()
    n = compliance_engine.generate_for_client(client_id, fy)
    compliance_engine.refresh_overdue()
    checklists = collection_service.ensure_upcoming(int(settings_service.get("checklist_upcoming_days") or 45),
                                                    client_id=client_id)
    c = get_client(client_id)
    task_id = task_service.save_task({
        "client_id": client_id, "title": "Client onboarding - collect KYC & engagement documents",
        "description": "Collect PAN, Aadhaar/incorporation documents, GST registration, engagement letter "
                       "and previous year returns. Verify compliance applicability.",
        "category": "General", "financial_year": fy, "assigned_to_id": c.get("assigned_staff_id"),
        "reviewer_id": c.get("assigned_manager_id") or c.get("assigned_partner_id"),
        "start_date": today(), "due_date": today() + timedelta(days=7), "priority": "High",
        "status": "Pending", "source_type": "onboarding", "source_id": client_id})
    reminders = reminder_engine.scan()
    return {"compliances": n, "checklist_items": checklists, "task_id": task_id, "reminders": reminders}


def set_status(client_id: int, status: str) -> None:
    with session_scope() as s:
        c = s.get(Client, client_id)
        old = c.status
        c.status = status
        log_audit(s, "STATUS", "clients", c.id, {"status": old}, {"status": status})
        log_activity(s, "Clients", "Status", f"{c.client_name} marked {status}", c.id)


def link_counts(client_id: int) -> dict:
    with session_scope() as s:
        return {
            "compliances": s.query(ComplianceRecord).filter_by(client_id=client_id).count(),
            "documents": s.query(Document).filter_by(client_id=client_id).count(),
            "notices": s.query(Notice).filter_by(client_id=client_id).count(),
            "tasks": s.query(Task).filter_by(client_id=client_id).count(),
            "invoices": s.query(BillingRecord).filter_by(client_id=client_id).count(),
        }


def delete_client(client_id: int) -> tuple[bool, str]:
    """Permanently delete only if nothing is linked; otherwise refuse (deactivate instead)."""
    counts = link_counts(client_id)
    if any(counts.values()):
        detail = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
        return False, f"Client has linked records ({detail}). It cannot be deleted - deactivate it instead."
    with session_scope() as s:
        c = s.get(Client, client_id)
        log_audit(s, "DELETE", "clients", c.id, model_to_dict(c), None)
        log_activity(s, "Clients", "Deleted", f"Client {c.client_name} [{c.client_code}] deleted")
        s.query(ClientComplianceApplicability).filter_by(client_id=client_id).delete()
        s.delete(c)
    return True, "Client deleted."


# ------------------------------------------------------------------ import / export
def import_clients(path: str, allow_duplicate_pan: bool = False, onboard: bool = True) -> dict:
    rows = read_client_import(path)
    from app.services.auth_service import get_user_id
    report = {"imported": 0, "skipped": 0, "errors": [], "ids": []}
    for i, raw in enumerate(rows, start=2):
        data = {}
        for k, v in raw.items():
            if k in BOOL_FIELDS:
                data[k] = yes_no(v)
            elif k in DATE_FIELDS:
                data[k] = parse_date(v)
            elif k == "professional_fee":
                data[k] = to_float(v)
            elif k.endswith("_username"):
                continue
            else:
                data[k] = v
        for src, dst in (("partner_username", "assigned_partner_id"), ("manager_username", "assigned_manager_id"),
                         ("staff_username", "assigned_staff_id")):
            if raw.get(src):
                data[dst] = get_user_id(raw[src])
        if data.get("entity_type") not in ENTITY_TYPES:
            report["skipped"] += 1
            report["errors"].append(f"Row {i}: invalid Entity Type '{data.get('entity_type')}'")
            continue
        data.setdefault("status", "Active")
        if data.get("gstin") and not data.get("gst_registration_type"):
            data["gst_registration_type"] = "Normal Taxpayer"
            data.setdefault("gst_status", "Active")
        try:
            cid = save_client(data, allow_duplicate_pan=allow_duplicate_pan)
            report["imported"] += 1
            report["ids"].append(cid)
        except Exception as exc:  # noqa: BLE001
            report["skipped"] += 1
            report["errors"].append(f"Row {i} ({data.get('client_name')}): {exc}")
    if onboard:
        from app.services import compliance_engine
        fy = settings_service.current_fy()
        for cid in report["ids"]:
            compliance_engine.generate_for_client(cid, fy)
    with session_scope() as s:
        log_activity(s, "Clients", "Import", f"Imported {report['imported']} clients, skipped {report['skipped']}")
    return report


EXPORT_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client Name"), ("legal_name", "Legal Name"),
                  ("entity_type", "Entity Type"), ("pan", "PAN"), ("tan", "TAN"), ("gstin", "GSTIN"),
                  ("cin_llpin", "CIN / LLPIN"), ("date_of_incorporation", "Date of Incorporation"),
                  ("address", "Address"), ("city", "City"), ("state", "State"), ("pin_code", "PIN"),
                  ("contact_person", "Contact Person"), ("mobile", "Mobile"), ("email", "Email"),
                  ("alternate_contact", "Alternate Contact"), ("industry", "Industry"),
                  ("nature_of_business", "Nature of Business"), ("acquisition_date", "Acquisition Date"),
                  ("partner", "Partner"), ("manager", "Manager"), ("staff", "Staff"), ("status", "Status"),
                  ("risk_category", "Risk"), ("professional_fee", "Professional Fee"),
                  ("billing_frequency", "Billing Frequency"), ("engagement_start", "Engagement Start"),
                  ("engagement_end", "Engagement End"), ("gst_registration_type", "GST Reg. Type"),
                  ("gst_scheme", "GST Scheme"), ("gst_frequency", "GST Frequency"), ("gst_status", "GST Status"),
                  ("itr_form", "ITR Form"), ("tax_audit_applicable", "Tax Audit"), ("tds_applicable", "TDS"),
                  ("notes", "Notes")]


def export_clients(path: str) -> str:
    return export_rows(path, EXPORT_COLUMNS, list_clients(), title="Client Master",
                       firm=settings_service.firm_name(), sheet_name="Clients")
