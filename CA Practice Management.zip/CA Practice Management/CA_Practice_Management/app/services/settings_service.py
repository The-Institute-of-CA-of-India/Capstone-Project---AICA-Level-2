"""Key/value application settings stored as JSON in the `settings` table."""
from __future__ import annotations

import json
from typing import Any

import config
from app.database.db import session_scope
from app.database.models import Setting
from app.services.permissions import DEFAULT_ROLE_PERMS
from app.utils.date_utils import fy_of

DEFAULT_COMPLIANCE_STATUSES = ["Not Started", "Awaiting Documents", "In Progress", "Under Review",
                               "Ready for Filing", "Filed", "Completed", "On Hold", "Overdue",
                               "Not Applicable"]

DEFAULT_SETTINGS: dict[str, Any] = {
    "firm_name": config.DEFAULT_FIRM_NAME,
    "firm_address": "",
    "firm_phone": "",
    "firm_email": "",
    "firm_frn": "",
    "firm_logo": "",
    "current_fy": fy_of(),
    "reminder_offsets": [15, 7, 3, 1, 0, -1],
    "internal_buffer_days": 5,
    "doc_collection_buffer_days": 10,
    "review_buffer_days": 2,
    "notice_warning_days": 7,
    "notice_internal_buffer_days": 3,
    "task_warning_days": 2,
    "compliance_statuses": DEFAULT_COMPLIANCE_STATUSES,
    "theme": "light",
    "date_format": "%d-%m-%Y",
    "currency_symbol": "₹",
    "session_lock_minutes": 15,
    "auto_backup_daily": True,
    "backup_include_documents_daily": False,
    "backup_retention": 30,
    "email_enabled": False,
    "smtp_host": "",
    "smtp_port": 587,
    "smtp_user": "",
    "smtp_use_tls": True,
    "email_from": "",
    "whatsapp_enabled": False,
    "desktop_notifications": True,
    "reminder_scan_minutes": 30,
    "skip_periods_before_onboarding": False,
    "checklist_upcoming_days": 45,
    "gst_rate_default": 18.0,
    "invoice_prefix": "NAC",
    "role_permissions": DEFAULT_ROLE_PERMS,
    "saved_filters": {},
    "last_generated_fy": "",
}

_cache: dict[str, Any] = {}


def get(key: str, default: Any = None) -> Any:
    if key in _cache:
        return _cache[key]
    with session_scope() as s:
        row = s.get(Setting, key)
        raw = row.value if row else None
    if raw is None:
        return default if default is not None else DEFAULT_SETTINGS.get(key)
    try:
        val = json.loads(raw)
    except (TypeError, ValueError):
        val = raw
    _cache[key] = val
    return val


def set(key: str, value: Any) -> None:  # noqa: A001 - intentional API name
    with session_scope() as s:
        row = s.get(Setting, key)
        payload = json.dumps(value, default=str)
        if row:
            row.value = payload
        else:
            s.add(Setting(key=key, value=payload))
    _cache[key] = value


def set_many(values: dict) -> None:
    for k, v in values.items():
        set(k, v)


def clear_cache() -> None:
    _cache.clear()


def firm_name() -> str:
    return get("firm_name") or config.DEFAULT_FIRM_NAME


def current_fy() -> str:
    return get("current_fy") or fy_of()


def compliance_statuses() -> list[str]:
    statuses = list(get("compliance_statuses") or DEFAULT_COMPLIANCE_STATUSES)
    for must in ("Not Started", "Completed", "Filed", "Overdue", "Not Applicable"):
        if must not in statuses:
            statuses.append(must)
    return statuses
