"""
Backup & restore.

* Each backup goes to its own timestamped folder - existing backups are never overwritten.
* SQLite online-backup API (consistent copy while the app is running).
* Optional ZIP of the document repository.
* Verification: PRAGMA integrity_check + SHA-256 recorded in manifest.json.
* Retention deletes only old *automatic* backups and never the only remaining one.
* Restore always takes a safety backup of the current state first.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import zipfile
from datetime import datetime
from typing import Optional

import config
from app.database import db as dbmod
from app.utils.logger import get_logger

log = get_logger(__name__)


def backup_root() -> str:
    root = config.get_path("backup_dir")
    os.makedirs(root, exist_ok=True)
    return root


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _integrity(db_file: str) -> tuple[bool, str]:
    try:
        con = sqlite3.connect(db_file)
        res = con.execute("PRAGMA integrity_check").fetchone()[0]
        tables = con.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
        has_clients = con.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='clients'").fetchone()[0]
        con.close()
        if res != "ok":
            return False, f"Integrity check failed: {res}"
        if not has_clients:
            return False, "File is not a CA Practice Management database."
        return True, f"OK ({tables} tables)"
    except Exception as exc:  # noqa: BLE001
        return False, f"Cannot open database: {exc}"


def create_backup(include_documents: bool = False, dest_root: Optional[str] = None, kind: str = "Manual",
                  note: str = "") -> dict:
    from app.services.auth_service import current_username
    root = dest_root or backup_root()
    os.makedirs(root, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = os.path.join(root, f"backup_{stamp}_{kind.lower()}")
    n = 2
    while os.path.exists(folder):
        folder = os.path.join(root, f"backup_{stamp}_{kind.lower()}_{n}")
        n += 1
    os.makedirs(folder)
    db_src = dbmod.get_db_path()
    db_dst = os.path.join(folder, "ca_firm.db")
    src = sqlite3.connect(db_src)
    dst = sqlite3.connect(db_dst)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    ok, msg = _integrity(db_dst)
    docs_zip = None
    if include_documents:
        docs_dir = config.get_path("documents_dir")
        if os.path.isdir(docs_dir):
            docs_zip = shutil.make_archive(os.path.join(folder, "documents"), "zip", docs_dir)
    size = sum(os.path.getsize(os.path.join(folder, f)) for f in os.listdir(folder))
    manifest = {"created_at": datetime.now().isoformat(timespec="seconds"), "kind": kind, "note": note,
                "app_version": config.APP_VERSION, "schema_version": config.SCHEMA_VERSION,
                "db_sha256": _sha256(db_dst), "documents_zip": os.path.basename(docs_zip) if docs_zip else None,
                "documents_sha256": _sha256(docs_zip) if docs_zip else None, "verified": ok,
                "verify_message": msg, "user": current_username()}
    with open(os.path.join(folder, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    _record(kind, folder, include_documents, size, ok, "Success" if ok else "Failed", msg)
    if ok:
        from app.services import settings_service
        settings_service.set("last_backup_at", manifest["created_at"])
        if kind == "Auto":
            _apply_retention(root)
    log.info("Backup %s -> %s (%s)", kind, folder, msg)
    return {"folder": folder, "ok": ok, "message": msg, "size": size}


def _record(kind, folder, docs, size, verified, status, message) -> None:
    try:
        from app.database.models import BackupHistory
        from app.services.auth_service import current_username
        with dbmod.session_scope() as s:
            s.add(BackupHistory(kind=kind, location=folder, include_documents=docs, size_bytes=size,
                                verified=verified, status=status, message=message, user=current_username()))
    except Exception as exc:  # noqa: BLE001
        log.error("Could not record backup history: %s", exc)


def _apply_retention(root: str) -> None:
    from app.services import settings_service
    keep = max(3, int(settings_service.get("backup_retention") or 30))
    autos = sorted([b for b in list_backups(root) if b["kind"] == "Auto" and b["verified"]],
                   key=lambda b: b["created_at"], reverse=True)
    total = len(list_backups(root))
    for b in autos[keep:]:
        if total <= 1:
            break
        try:
            shutil.rmtree(b["folder"])
            total -= 1
        except OSError as exc:
            log.warning("Retention could not remove %s: %s", b["folder"], exc)


def list_backups(root: Optional[str] = None) -> list[dict]:
    root = root or backup_root()
    out = []
    if not os.path.isdir(root):
        return out
    for name in os.listdir(root):
        folder = os.path.join(root, name)
        mpath = os.path.join(folder, "manifest.json")
        dbf = os.path.join(folder, "ca_firm.db")
        if not os.path.isfile(dbf):
            continue
        man = {}
        if os.path.isfile(mpath):
            try:
                with open(mpath, "r", encoding="utf-8") as fh:
                    man = json.load(fh)
            except Exception:
                man = {}
        created = man.get("created_at") or datetime.fromtimestamp(os.path.getmtime(dbf)).isoformat(timespec="seconds")
        out.append({"_id": folder, "folder": folder, "name": name, "created_at": created,
                    "kind": man.get("kind", "Pre-Migration" if name.startswith("pre_migration") else "Unknown"),
                    "documents": "Yes" if man.get("documents_zip") else "No", "verified": bool(man.get("verified")),
                    "verified_text": "Yes" if man.get("verified") else "Unverified",
                    "size_mb": round(sum(os.path.getsize(os.path.join(folder, f)) for f in os.listdir(folder)
                                         if os.path.isfile(os.path.join(folder, f))) / 1048576, 2),
                    "note": man.get("note", ""), "_color": "green" if man.get("verified") else "yellow"})
    return sorted(out, key=lambda b: b["created_at"], reverse=True)


def last_backup() -> Optional[datetime]:
    items = [b for b in list_backups() if b["verified"]]
    if not items:
        return None
    try:
        return datetime.fromisoformat(items[0]["created_at"])
    except ValueError:
        return None


def verify_backup(folder: str) -> tuple[bool, str]:
    dbf = os.path.join(folder, "ca_firm.db") if os.path.isdir(folder) else folder
    if not os.path.isfile(dbf):
        return False, "Backup database file not found."
    ok, msg = _integrity(dbf)
    mpath = os.path.join(os.path.dirname(dbf), "manifest.json")
    if ok and os.path.isfile(mpath):
        with open(mpath, "r", encoding="utf-8") as fh:
            man = json.load(fh)
        if man.get("db_sha256") and man["db_sha256"] != _sha256(dbf):
            return False, "Checksum mismatch - backup file has been modified or is corrupt."
        if man.get("documents_zip"):
            z = os.path.join(os.path.dirname(dbf), man["documents_zip"])
            if not os.path.isfile(z):
                return False, "Documents archive missing."
            if man.get("documents_sha256") and man["documents_sha256"] != _sha256(z):
                return False, "Documents archive checksum mismatch."
            with zipfile.ZipFile(z) as zf:
                bad = zf.testzip()
                if bad:
                    return False, f"Documents archive corrupt at {bad}"
        msg += ", checksum verified"
    return ok, msg


def restore_database(backup_db: str) -> str:
    """Restore the database from a backup file/folder (safety backup taken first)."""
    from app.database import migrations
    from app.services import settings_service
    dbf = os.path.join(backup_db, "ca_firm.db") if os.path.isdir(backup_db) else backup_db
    ok, msg = _integrity(dbf)
    if not ok:
        raise ValueError(f"Selected backup is not valid: {msg}")
    safety = create_backup(include_documents=False, kind="PreRestore", note="Automatic safety backup before restore")
    if not safety["ok"]:
        raise RuntimeError("Safety backup failed - restore aborted.")
    target = dbmod.get_db_path()
    dbmod.dispose_engine()
    tmp = target + ".restore_tmp"
    shutil.copy2(dbf, tmp)
    for ext in ("-wal", "-shm", "-journal"):
        if os.path.exists(target + ext):
            os.remove(target + ext)
    os.replace(tmp, target)
    dbmod.init_engine(target)
    migrations.run_migrations(dbmod.get_engine(), target)
    settings_service.clear_cache()
    log.warning("Database restored from %s (safety backup at %s)", dbf, safety["folder"])
    return safety["folder"]


def restore_documents(zip_path: str) -> str:
    """Restore the document repository from a backup ZIP (current docs zipped first)."""
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("Selected file is not a valid ZIP archive.")
    docs_dir = config.get_path("documents_dir")
    os.makedirs(docs_dir, exist_ok=True)
    safety_dir = os.path.join(backup_root(), f"pre_restore_documents_{datetime.now():%Y%m%d_%H%M%S}")
    os.makedirs(safety_dir, exist_ok=True)
    if os.listdir(docs_dir):
        shutil.make_archive(os.path.join(safety_dir, "documents"), "zip", docs_dir)
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.namelist():
            dest = os.path.abspath(os.path.join(docs_dir, member))
            if not dest.startswith(os.path.abspath(docs_dir)):
                raise ValueError("Archive contains unsafe paths - restore aborted.")
        zf.extractall(docs_dir)
    return safety_dir


def auto_daily_backup() -> Optional[dict]:
    from app.services import settings_service
    if not settings_service.get("auto_backup_daily"):
        return None
    last = last_backup()
    if last and last.date() == datetime.now().date():
        return None
    try:
        return create_backup(include_documents=bool(settings_service.get("backup_include_documents_daily")),
                             kind="Auto", note="Daily automatic backup")
    except Exception as exc:  # noqa: BLE001
        log.error("Daily backup failed: %s", exc)
        return {"ok": False, "message": str(exc)}
