"""Authentication, password hashing (PBKDF2-SHA256), session & permissions."""
from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import datetime
from typing import Optional

from app.database.db import session_scope
from app.database.models import User
from app.services.permissions import DEFAULT_ROLE_PERMS, PERMISSIONS, ROLES
from app.utils.logger import get_logger

log = get_logger(__name__)
ITERATIONS = 260_000
MAX_FAILED = 5

_current: Optional[dict] = None
_failed: dict[str, int] = {}


# ------------------------------------------------------------------ hashing
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _algo, iters, salt, digest = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(dk.hex(), digest)
    except Exception:
        return False


def password_policy(pw: str) -> Optional[str]:
    if len(pw or "") < 8:
        return "Password must be at least 8 characters."
    if not any(c.isalpha() for c in pw) or not any(c.isdigit() for c in pw):
        return "Password must contain letters and numbers."
    return None


def _user_dict(u: User) -> dict:
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role,
            "email": u.email, "mobile": u.mobile, "designation": u.designation,
            "is_active": u.is_active, "must_change_password": u.must_change_password,
            "last_login": u.last_login}


# ------------------------------------------------------------------ session
def authenticate(username: str, password: str) -> tuple[Optional[dict], str]:
    global _current
    uname = (username or "").strip().lower()
    if _failed.get(uname, 0) >= MAX_FAILED:
        return None, "Account temporarily locked after repeated failed attempts. Restart the application or ask Admin."
    with session_scope() as s:
        u = s.query(User).filter(User.username == uname).first()
        if not u or not verify_password(password or "", u.password_hash):
            _failed[uname] = _failed.get(uname, 0) + 1
            log.warning("Failed login attempt for user '%s'", uname)
            return None, "Invalid username or password."
        if not u.is_active:
            return None, "This user account is deactivated."
        u.last_login = datetime.now()
        info = _user_dict(u)
    _failed.pop(uname, None)
    _current = info
    from app.services.audit_service import log_activity_standalone
    log_activity_standalone("Security", "Login", f"{info['full_name']} logged in")
    return info, "OK"


def auto_login() -> Optional[dict]:
    """Start the session without any sign-in screen: use the Administrator account."""
    global _current
    with session_scope() as s:
        q = s.query(User).filter(User.is_active.is_(True))
        u = (q.filter(User.username == "admin").first()
             or q.filter(User.role == "Admin").order_by(User.id).first()
             or q.order_by(User.id).first())
        if not u:
            return None
        u.last_login = datetime.now()
        info = _user_dict(u)
    _current = info
    return info


def logout() -> None:
    global _current
    if _current:
        from app.services.audit_service import log_activity_standalone
        log_activity_standalone("Security", "Logout", f"{_current['full_name']} logged out")
    _current = None


def set_current_user(info: Optional[dict]) -> None:
    """Used by tests / background jobs."""
    global _current
    _current = info


def current_user() -> Optional[dict]:
    return _current


def current_user_id() -> Optional[int]:
    return _current["id"] if _current else None


def current_username() -> str:
    return _current["username"] if _current else "system"


def role_permissions() -> dict:
    from app.services import settings_service
    perms = settings_service.get("role_permissions") or {}
    merged = {r: list(DEFAULT_ROLE_PERMS.get(r, [])) for r in ROLES}
    merged.update({k: list(v) for k, v in perms.items()})
    return merged


def has_perm(perm: str) -> bool:
    if not _current:
        return True  # background/system context
    if _current["role"] in ("Admin", "Partner") and perm in ("users.manage", "settings.edit"):
        return True  # never lock the firm out of administration
    return perm in role_permissions().get(_current["role"], [])


def scope_user_id() -> Optional[int]:
    """None when the user may see all clients; otherwise the user's own id."""
    if not _current or has_perm("view_all_clients"):
        return None
    return _current["id"]


# ------------------------------------------------------------------ users
def list_users(active_only: bool = False) -> list[dict]:
    with session_scope() as s:
        q = s.query(User)
        if active_only:
            q = q.filter(User.is_active.is_(True))
        return [_user_dict(u) for u in q.order_by(User.full_name)]


def user_choices(active_only: bool = True) -> list[tuple[str, int]]:
    return [(f"{u['full_name']} ({u['role']})", u["id"]) for u in list_users(active_only)]


def user_name_map() -> dict[int, str]:
    with session_scope() as s:
        return {u.id: u.full_name for u in s.query(User.id, User.full_name)}


def get_user_id(username: str) -> Optional[int]:
    with session_scope() as s:
        u = s.query(User).filter(User.username == (username or "").strip().lower()).first()
        return u.id if u else None


def get_user(user_id: int) -> Optional[dict]:
    with session_scope() as s:
        u = s.get(User, user_id)
        return _user_dict(u) if u else None


def save_user(data: dict, user_id: Optional[int] = None, password: Optional[str] = None) -> int:
    from app.services.audit_service import log_audit
    uname = (data.get("username") or "").strip().lower()
    if not uname:
        raise ValueError("Username is required.")
    if data.get("role") not in ROLES:
        raise ValueError("Invalid role.")
    with session_scope() as s:
        dup = s.query(User).filter(User.username == uname, User.id != (user_id or 0)).first()
        if dup:
            raise ValueError(f"Username '{uname}' already exists.")
        if user_id:
            u = s.get(User, user_id)
            if not u:
                raise ValueError("User not found.")
            action = "UPDATE"
        else:
            if not password:
                raise ValueError("Password is required for a new user.")
            u = User(password_hash="")
            s.add(u)
            action = "CREATE"
        u.username = uname
        u.full_name = (data.get("full_name") or uname).strip()
        u.role = data["role"]
        u.email = data.get("email")
        u.mobile = data.get("mobile")
        u.designation = data.get("designation")
        u.is_active = bool(data.get("is_active", True))
        if password:
            err = password_policy(password)
            if err:
                raise ValueError(err)
            u.password_hash = hash_password(password)
            u.must_change_password = bool(data.get("must_change_password", False))
        s.flush()
        log_audit(s, action, "users", u.id, None, {"username": u.username, "role": u.role,
                                                    "is_active": u.is_active})
        return u.id


def change_password(user_id: int, old: str, new: str) -> None:
    err = password_policy(new)
    if err:
        raise ValueError(err)
    with session_scope() as s:
        u = s.get(User, user_id)
        if not u or not verify_password(old, u.password_hash):
            raise ValueError("Current password is incorrect.")
        if verify_password(new, u.password_hash):
            raise ValueError("New password must differ from the current password.")
        u.password_hash = hash_password(new)
        u.must_change_password = False
    if _current and _current["id"] == user_id:
        _current["must_change_password"] = False


def reset_password(user_id: int, new: str) -> None:
    err = password_policy(new)
    if err:
        raise ValueError(err)
    with session_scope() as s:
        u = s.get(User, user_id)
        if not u:
            raise ValueError("User not found.")
        u.password_hash = hash_password(new)
        u.must_change_password = True
        from app.services.audit_service import log_audit
        log_audit(s, "RESET_PASSWORD", "users", u.id, None, {"username": u.username})


def verify_current_password(password: str) -> bool:
    if not _current:
        return False
    with session_scope() as s:
        u = s.get(User, _current["id"])
        return bool(u and verify_password(password, u.password_hash))


__all__ = ["PERMISSIONS", "ROLES"]
