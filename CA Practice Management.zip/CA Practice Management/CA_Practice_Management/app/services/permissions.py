"""Role-based access control definitions (editable in Settings > Roles & Permissions)."""

ROLES = ["Partner", "Manager", "Senior", "Junior", "Admin"]

PERMISSIONS = {
    "view_all_clients": "View all clients & work (otherwise only assigned)",
    "clients.edit": "Add / edit clients",
    "clients.delete": "Deactivate / delete clients",
    "clients.import": "Import / export clients",
    "compliance.edit": "Update compliance records",
    "compliance.review": "Review, complete & revise compliances",
    "compliance.master": "Edit compliance master & due-date rules",
    "notices.edit": "Create / update notices",
    "tasks.edit": "Create / update tasks",
    "tasks.assign": "Assign / reassign tasks to any staff",
    "documents.edit": "Upload / edit documents",
    "documents.delete": "Delete (move to recycle) documents",
    "billing.view": "View billing",
    "billing.edit": "Create invoices & record payments",
    "reports.view": "View & export reports",
    "settings.edit": "Edit application settings",
    "users.manage": "Manage users & role permissions",
    "backup.manage": "Backup & restore",
    "audit.view": "View audit trail",
}

_ALL = list(PERMISSIONS.keys())

DEFAULT_ROLE_PERMS = {
    "Partner": _ALL,
    "Admin": _ALL,
    "Manager": [p for p in _ALL if p not in ("users.manage", "settings.edit")],
    "Senior": ["view_all_clients", "clients.edit", "compliance.edit", "compliance.review",
               "notices.edit", "tasks.edit", "documents.edit", "reports.view"],
    "Junior": ["compliance.edit", "tasks.edit", "documents.edit"],
}
