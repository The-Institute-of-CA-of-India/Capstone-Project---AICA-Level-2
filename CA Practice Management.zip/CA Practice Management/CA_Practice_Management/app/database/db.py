"""SQLAlchemy engine / session management (SQLite, offline)."""
from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Iterator, Optional

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

import config
from app.utils.logger import get_logger

log = get_logger(__name__)
_engine: Optional[Engine] = None
_SessionFactory: Optional[sessionmaker] = None
_db_path: Optional[str] = None


def get_db_path() -> str:
    return _db_path or config.get_path("db_path")


def init_engine(db_path: Optional[str] = None) -> Engine:
    """(Re)create the engine. Safe to call again after a restore."""
    global _engine, _SessionFactory, _db_path
    if _engine is not None:
        _engine.dispose()
    _db_path = db_path or config.get_path("db_path")
    os.makedirs(os.path.dirname(os.path.abspath(_db_path)), exist_ok=True)
    _engine = create_engine(f"sqlite:///{_db_path}",
                            connect_args={"check_same_thread": False, "timeout": 30},
                            future=True)

    @event.listens_for(_engine, "connect")
    def _on_connect(dbapi_conn, _record):  # enforce foreign keys on every connection
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()

    _SessionFactory = sessionmaker(bind=_engine, expire_on_commit=False, future=True)
    log.info("Database engine initialised: %s", _db_path)
    return _engine


def get_engine() -> Engine:
    if _engine is None:
        init_engine()
    return _engine  # type: ignore[return-value]


def dispose_engine() -> None:
    global _engine
    if _engine is not None:
        _engine.dispose()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope: commit on success, rollback on error."""
    if _SessionFactory is None:
        init_engine()
    s: Session = _SessionFactory()  # type: ignore[misc]
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def init_database(db_path: Optional[str] = None) -> None:
    """Create / migrate schema and seed default master data (idempotent)."""
    from app.database import migrations, seed_data

    init_engine(db_path)
    migrations.run_migrations(get_engine(), get_db_path())
    with session_scope() as s:
        seed_data.seed_defaults(s)
