"""
Seed data: default admin user, settings and the SAMPLE compliance master.

IMPORTANT: The due-date rules below are editable starting defaults based on the
general statutory framework. They are NOT authoritative. Every rule carries the
note "Seed default - verify" and must be verified/updated by the firm against
the latest CBDT / CBIC / MCA notifications (Settings > Compliance Master).
Extensions are recorded as new rule versions or revised due dates, never by
overwriting history.

Demo data (random clients, notices, tasks, invoices) is loaded ONLY on request
(demo mode) via load_demo_data().
"""
from __future__ import annotations

import json
import random
from datetime import date, timedelta

from sqlalchemy.orm import Session

from app.database.models import (ComplianceDueDateRule, ComplianceMaster, DocumentChecklist, Setting,
                                 User)
from app.utils.logger import get_logger

log = get_logger(__name__)

COMPANIES = ["Private Limited Company", "Public Limited Company"]
NON_COMPANY = ["Individual", "Proprietorship", "Partnership Firm", "LLP", "HUF", "Trust", "Society",
               "Association of Persons", "Other"]
GST_NORMAL = {"requires_value": ["gstin"],
              "field_in": {"gst_registration_type": ["Normal Taxpayer"], "gst_status": ["Active"]}}


def _gst(scheme=None, freq=None, reg_type="Normal Taxpayer", extra_true=None):
    rule = {"requires_value": ["gstin"],
            "field_in": {"gst_registration_type": [reg_type], "gst_status": ["Active"]}}
    if scheme:
        rule["field_in"]["gst_scheme"] = [scheme]
    if freq:
        rule["field_in"]["gst_frequency"] = [freq]
    if extra_true:
        rule["requires_true"] = extra_true
    return rule


MANUAL = {"manual": True}   # only applicable when switched on for a client
SRC_GST = "CBIC / GST portal - verify latest notification"
SRC_IT = "CBDT / Income-tax Act, 1961 - verify latest notification"
SRC_MCA = "MCA / Companies Act, 2013 & LLP Act, 2008 - verify latest notification"
SRC_INT = "Internal office deadline (not statutory)"

# code, category, name, form, periodicity, applicability, rule, buffer_days, source
MASTER = [
    # ----------------------------------------------------------------- GST
    ("GST-GSTR1-M", "GST", "GSTR-1 (Monthly)", "GSTR-1", "Monthly", _gst("Regular", "Monthly"), {"o": 1, "d": 11}, None, SRC_GST),
    ("GST-GSTR1-Q", "GST", "GSTR-1 (Quarterly - QRMP)", "GSTR-1", "Quarterly", _gst("Regular", "Quarterly"), {"o": 1, "d": 13}, None, SRC_GST),
    ("GST-GSTR1A", "GST", "GSTR-1A (Amendment)", "GSTR-1A", "Monthly", MANUAL, {"o": 1, "d": 20}, None, SRC_GST),
    ("GST-GSTR3B-M", "GST", "GSTR-3B (Monthly)", "GSTR-3B", "Monthly", _gst("Regular", "Monthly"), {"o": 1, "d": 20}, None, SRC_GST),
    ("GST-GSTR3B-Q", "GST", "GSTR-3B (Quarterly - QRMP)", "GSTR-3B", "Quarterly", _gst("Regular", "Quarterly"), {"o": 1, "d": 22, "r": "22nd or 24th depending on State - verify"}, None, SRC_GST),
    ("GST-PMT06", "GST", "GST Payment (PMT-06 - QRMP)", "PMT-06", "Monthly", _gst("Regular", "Quarterly"), {"o": 1, "d": 25, "ov": {"skip": ["M06", "M09", "M12", "M03"]}}, None, SRC_GST),
    ("GST-PAY", "GST", "GST Payment (Monthly)", "PMT / Challan", "Monthly", _gst("Regular", "Monthly"), {"o": 1, "d": 20}, None, SRC_GST),
    ("GST-GSTR9", "GST", "GSTR-9 Annual Return", "GSTR-9", "Annual", _gst("Regular"), {"o": 9, "d": 31}, 15, SRC_GST),
    ("GST-GSTR9C", "GST", "GSTR-9C Reconciliation Statement", "GSTR-9C", "Annual", _gst("Regular", extra_true=["gst_9c_applicable"]), {"o": 9, "d": 31}, 15, SRC_GST),
    ("GST-GSTR4", "GST", "GSTR-4 (Composition Annual)", "GSTR-4", "Annual", _gst("Composition"), {"o": 1, "d": 30}, None, SRC_GST),
    ("GST-CMP08", "GST", "CMP-08 (Composition Quarterly)", "CMP-08", "Quarterly", _gst("Composition"), {"o": 1, "d": 18}, None, SRC_GST),
    ("GST-GSTR6", "GST", "GSTR-6 (ISD Return)", "GSTR-6", "Monthly", _gst(reg_type="Input Service Distributor"), {"o": 1, "d": 13}, None, SRC_GST),
    ("GST-GSTR7", "GST", "GSTR-7 (GST TDS Return)", "GSTR-7", "Monthly", _gst(reg_type="TDS Deductor (GST)"), {"o": 1, "d": 10}, None, SRC_GST),
    ("GST-GSTR8", "GST", "GSTR-8 (GST TCS Return)", "GSTR-8", "Monthly", _gst(reg_type="TCS Collector (GST)"), {"o": 1, "d": 10}, None, SRC_GST),
    ("GST-ANNUAL", "GST", "GST Annual Return (Other)", "Annual", "Annual", MANUAL, {"o": 9, "d": 31}, None, SRC_GST),
    ("GST-RECON", "GST", "GST Reconciliation (GSTR-2B vs Books)", "Reconciliation", "Monthly", MANUAL, {"o": 1, "d": 10, "r": "Internal"}, 2, SRC_INT),
    ("GST-REFUND", "GST", "GST Refund", "RFD-01", "One-Time", MANUAL, {"o": 12, "d": 31}, None, SRC_GST),
    ("GST-REG", "GST", "GST Registration", "REG-01", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_GST),
    ("GST-AMEND", "GST", "GST Amendment of Registration", "REG-14", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_GST),
    ("GST-LUT", "GST", "LUT Renewal", "RFD-11", "Annual", _gst("Regular", extra_true=["gst_exporter_lut"]), {"o": -12, "d": 31, "r": "Before start of FY"}, 10, SRC_GST),
    ("GST-OTHER", "GST", "Other GST Compliance", "", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_GST),
    # ----------------------------------------------------------------- Income Tax
    ("IT-ITR1", "Income Tax", "ITR-1 (Sahaj)", "ITR-1", "Annual", {"field_in": {"itr_form": ["ITR-1"]}}, {"o": 4, "d": 31}, 10, SRC_IT),
    ("IT-ITR2", "Income Tax", "ITR-2", "ITR-2", "Annual", {"field_in": {"itr_form": ["ITR-2"]}}, {"o": 4, "d": 31, "alt": [{"if_true": "tax_audit_applicable", "offset": 7, "day": 31}]}, 10, SRC_IT),
    ("IT-ITR3", "Income Tax", "ITR-3", "ITR-3", "Annual", {"field_in": {"itr_form": ["ITR-3"]}}, {"o": 4, "d": 31, "alt": [{"if_true": "transfer_pricing_applicable", "offset": 8, "day": 30}, {"if_true": "tax_audit_applicable", "offset": 7, "day": 31}]}, 10, SRC_IT),
    ("IT-ITR4", "Income Tax", "ITR-4 (Sugam)", "ITR-4", "Annual", {"field_in": {"itr_form": ["ITR-4"]}}, {"o": 4, "d": 31}, 10, SRC_IT),
    ("IT-ITR5", "Income Tax", "ITR-5", "ITR-5", "Annual", {"field_in": {"itr_form": ["ITR-5"]}}, {"o": 4, "d": 31, "alt": [{"if_true": "transfer_pricing_applicable", "offset": 8, "day": 30}, {"if_true": "tax_audit_applicable", "offset": 7, "day": 31}]}, 10, SRC_IT),
    ("IT-ITR6", "Income Tax", "ITR-6", "ITR-6", "Annual", {"field_in": {"itr_form": ["ITR-6"]}}, {"o": 7, "d": 31, "alt": [{"if_true": "transfer_pricing_applicable", "offset": 8, "day": 30}]}, 10, SRC_IT),
    ("IT-ITR7", "Income Tax", "ITR-7", "ITR-7", "Annual", {"field_in": {"itr_form": ["ITR-7"]}}, {"o": 7, "d": 31}, 10, SRC_IT),
    ("IT-TAXAUDIT", "Income Tax", "Tax Audit u/s 44AB", "Sec 44AB", "Annual", {"requires_true": ["tax_audit_applicable"]}, {"o": 6, "d": 30}, 15, SRC_IT),
    ("IT-3CA", "Income Tax", "Form 3CA-3CD", "3CA-3CD", "Annual", {"requires_true": ["tax_audit_applicable"], "entity_types": COMPANIES}, {"o": 6, "d": 30}, 15, SRC_IT),
    ("IT-3CB", "Income Tax", "Form 3CB-3CD", "3CB-3CD", "Annual", {"requires_true": ["tax_audit_applicable"], "entity_types": NON_COMPANY}, {"o": 6, "d": 30}, 15, SRC_IT),
    ("IT-3CEB", "Income Tax", "Form 3CEB (Transfer Pricing)", "3CEB", "Annual", {"requires_true": ["transfer_pricing_applicable"]}, {"o": 7, "d": 31}, 15, SRC_IT),
    ("IT-10B", "Income Tax", "Form 10B (Audit of Trust)", "10B", "Annual", {"requires_true": ["charitable_registration"]}, {"o": 6, "d": 30}, 15, SRC_IT),
    ("IT-10BB", "Income Tax", "Form 10BB", "10BB", "Annual", MANUAL, {"o": 6, "d": 30}, 15, SRC_IT),
    ("IT-10A", "Income Tax", "Form 10A (Registration)", "10A", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_IT),
    ("IT-10AB", "Income Tax", "Form 10AB (Re-registration)", "10AB", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_IT),
    ("IT-ADVTAX", "Income Tax", "Advance Tax", "Challan 280", "Fixed Dates", {"requires_true": ["advance_tax_applicable"]},
     {"o": 0, "d": 15, "fx": [{"month": 6, "day": 15, "label": "1st Instalment (15%)"}, {"month": 9, "day": 15, "label": "2nd Instalment (45%)"},
                              {"month": 12, "day": 15, "label": "3rd Instalment (75%)"}, {"month": 3, "day": 15, "label": "4th Instalment (100%)"}]}, 3, SRC_IT),
    ("IT-TDSRECON", "Income Tax", "TDS Credit Reconciliation (26AS / AIS)", "26AS / AIS", "Annual", {"requires_value": ["pan"]}, {"o": 3, "d": 30, "r": "Internal"}, 3, SRC_INT),
    ("IT-TAXPAY", "Income Tax", "Tax Payment (Self-Assessment)", "Challan 280", "Annual", MANUAL, {"o": 4, "d": 31}, None, SRC_IT),
    ("IT-VERIFY", "Income Tax", "Return Verification (e-Verify)", "ITR-V", "Annual", MANUAL, {"o": 5, "d": 30, "r": "Within prescribed days of filing - verify"}, None, SRC_IT),
    ("IT-REFUND", "Income Tax", "Refund Tracking", "Refund", "Annual", MANUAL, {"o": 12, "d": 31}, None, SRC_IT),
    ("IT-OTHER", "Income Tax", "Other Income Tax Compliance", "", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_IT),
    # ----------------------------------------------------------------- TDS / TCS
    ("TDS-PAY", "TDS", "TDS Payment", "Challan 281", "Monthly", {"requires_true": ["tds_applicable"]}, {"o": 1, "d": 7, "ov": {"M03": [1, 30]}}, 2, SRC_IT),
    ("TCS-PAY", "TDS", "TCS Payment", "Challan 281", "Monthly", {"requires_true": ["tcs_applicable"]}, {"o": 1, "d": 7}, 2, SRC_IT),
    ("TDS-24Q", "TDS", "Form 24Q (TDS on Salary)", "24Q", "Quarterly", {"requires_true": ["tds_applicable", "tds_salary"]}, {"o": 1, "d": 31, "ov": {"Q4": [2, 31]}}, 5, SRC_IT),
    ("TDS-26Q", "TDS", "Form 26Q (TDS Non-Salary)", "26Q", "Quarterly", {"requires_true": ["tds_applicable", "tds_nonsalary"]}, {"o": 1, "d": 31, "ov": {"Q4": [2, 31]}}, 5, SRC_IT),
    ("TDS-27Q", "TDS", "Form 27Q (TDS Non-Resident)", "27Q", "Quarterly", {"requires_true": ["tds_applicable", "tds_nonresident"]}, {"o": 1, "d": 31, "ov": {"Q4": [2, 31]}}, 5, SRC_IT),
    ("TDS-27EQ", "TDS", "Form 27EQ (TCS Return)", "27EQ", "Quarterly", {"requires_true": ["tcs_applicable"]}, {"o": 1, "d": 15, "ov": {"Q4": [2, 15]}}, 5, SRC_IT),
    ("TDS-RQ1", "TDS", "TDS Return Q1 (Generic)", "TDS Return", "Annual", MANUAL, {"o": -8, "d": 31}, 5, SRC_IT),
    ("TDS-RQ2", "TDS", "TDS Return Q2 (Generic)", "TDS Return", "Annual", MANUAL, {"o": -5, "d": 31}, 5, SRC_IT),
    ("TDS-RQ3", "TDS", "TDS Return Q3 (Generic)", "TDS Return", "Annual", MANUAL, {"o": -2, "d": 31}, 5, SRC_IT),
    ("TDS-RQ4", "TDS", "TDS Return Q4 (Generic)", "TDS Return", "Annual", MANUAL, {"o": 2, "d": 31}, 5, SRC_IT),
    ("TDS-16", "TDS", "Form 16 Issuance", "Form 16", "Annual", {"requires_true": ["tds_applicable", "tds_salary"]}, {"o": 3, "d": 15}, 5, SRC_IT),
    ("TDS-16A", "TDS", "Form 16A Issuance", "Form 16A", "Quarterly", {"requires_true": ["tds_applicable", "tds_nonsalary"]}, {"o": 2, "d": 15, "ov": {"Q4": [3, 15]}}, 3, SRC_IT),
    ("TDS-27D", "TDS", "Form 27D Issuance (TCS)", "Form 27D", "Quarterly", {"requires_true": ["tcs_applicable"]}, {"o": 2, "d": 15, "ov": {"Q4": [3, 15]}}, 3, SRC_IT),
    ("TDS-15CACB", "TDS", "Form 15CA / 15CB", "15CA/15CB", "One-Time", MANUAL, {"o": 0, "d": 31, "r": "Before remittance"}, None, SRC_IT),
    ("TDS-RECON", "TDS", "TDS Reconciliation", "Reconciliation", "Quarterly", MANUAL, {"o": 1, "d": 20, "r": "Internal"}, 2, SRC_INT),
    ("TDS-CORR", "TDS", "TRACES Correction Return", "Correction", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_IT),
    ("TDS-OTHER", "TDS", "Other TDS Compliance", "", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_IT),
    # ----------------------------------------------------------------- ROC / MCA
    ("ROC-AOC4", "ROC", "AOC-4 (Financial Statements)", "AOC-4", "Annual", {"entity_types": COMPANIES, "requires_false": ["xbrl_applicable"]}, {"o": 7, "d": 30, "alt": [{"event_field": "agm_date", "days": 30}], "r": "30 days from AGM"}, 10, SRC_MCA),
    ("ROC-AOC4X", "ROC", "AOC-4 XBRL", "AOC-4 XBRL", "Annual", {"entity_types": COMPANIES, "requires_true": ["xbrl_applicable"]}, {"o": 7, "d": 30, "alt": [{"event_field": "agm_date", "days": 30}], "r": "30 days from AGM"}, 10, SRC_MCA),
    ("ROC-MGT7", "ROC", "MGT-7 (Annual Return)", "MGT-7", "Annual", {"entity_types": COMPANIES, "requires_false": ["small_company"]}, {"o": 8, "d": 29, "alt": [{"event_field": "agm_date", "days": 60}], "r": "60 days from AGM"}, 10, SRC_MCA),
    ("ROC-MGT7A", "ROC", "MGT-7A (Small Co. / OPC)", "MGT-7A", "Annual", {"entity_types": COMPANIES, "requires_true": ["small_company"]}, {"o": 8, "d": 29, "alt": [{"event_field": "agm_date", "days": 60}], "r": "60 days from AGM"}, 10, SRC_MCA),
    ("ROC-ADT1", "ROC", "ADT-1 (Auditor Appointment)", "ADT-1", "Annual", MANUAL, {"o": 7, "d": 14, "alt": [{"event_field": "agm_date", "days": 15}], "r": "15 days from AGM"}, 5, SRC_MCA),
    ("ROC-DIR3KYC", "ROC", "DIR-3 KYC (Directors / Partners)", "DIR-3 KYC", "Annual", {"entity_types": COMPANIES + ["LLP"]}, {"o": 6, "d": 30}, 10, SRC_MCA),
    ("ROC-MSME1", "ROC", "MSME-1 (Half-Yearly)", "MSME-1", "Half-Yearly", {"entity_types": COMPANIES, "requires_true": ["msme_payables"]}, {"o": 1, "d": 31, "ov": {"H2": [1, 30]}}, 5, SRC_MCA),
    ("ROC-DPT3", "ROC", "DPT-3 (Return of Deposits)", "DPT-3", "Annual", {"entity_types": COMPANIES}, {"o": 3, "d": 30}, 10, SRC_MCA),
    ("ROC-PAS6", "ROC", "PAS-6 (Share Capital Reconciliation)", "PAS-6", "Half-Yearly", MANUAL, {"o": 2, "d": 29, "ov": {"H2": [2, 30]}}, 5, SRC_MCA),
    ("ROC-BEN2", "ROC", "BEN-2 (Significant Beneficial Owner)", "BEN-2", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_MCA),
    ("ROC-LLP8", "ROC", "LLP Form 8 (Statement of Account & Solvency)", "LLP Form 8", "Annual", {"entity_types": ["LLP"]}, {"o": 7, "d": 30}, 10, SRC_MCA),
    ("ROC-LLP11", "ROC", "LLP Form 11 (Annual Return)", "LLP Form 11", "Annual", {"entity_types": ["LLP"]}, {"o": 2, "d": 30}, 10, SRC_MCA),
    ("ROC-LLP3", "ROC", "LLP Form 3 (LLP Agreement)", "LLP Form 3", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_MCA),
    ("ROC-AGM", "ROC", "Annual General Meeting", "AGM", "Annual", {"entity_types": COMPANIES}, {"o": 6, "d": 30}, 15, SRC_MCA),
    ("ROC-BM", "ROC", "Board Meeting", "Board Meeting", "Quarterly", {"entity_types": COMPANIES}, {"o": 0, "d": 31, "r": "Internal target per quarter"}, 5, SRC_INT),
    ("ROC-STATAUDIT", "ROC", "Statutory Audit", "Audit Report", "Annual", {"requires_true": ["statutory_audit_applicable"]}, {"o": 5, "d": 31, "r": "Internal target before AGM"}, 15, SRC_INT),
    ("ROC-AFS", "ROC", "Annual Financial Statements", "Financials", "Annual", {"entity_types": COMPANIES + ["LLP"]}, {"o": 5, "d": 15, "r": "Internal target"}, 15, SRC_INT),
    ("ROC-OTHER", "ROC", "Other ROC Compliance", "", "One-Time", MANUAL, {"o": 0, "d": 31}, None, SRC_MCA),
]

CHECKLISTS = {
    "GST_RETURN": ["Sales Register", "Purchase Register", "Credit Notes", "Debit Notes",
                   "E-commerce Statements", "Bank Statements", "Previous Return"],
    "GST_ANNUAL": ["Audited Financial Statements", "GSTR-1 & GSTR-3B Summary", "GSTR-2B Annual Summary",
                   "ITC Reconciliation", "HSN Summary"],
    "ITR": ["Form 16", "Bank Statements", "AIS", "TIS", "Form 26AS", "Investment Proofs",
            "Capital Gain Statements", "Loan Statements"],
    "ITR_BUSINESS": ["Trial Balance", "Financial Statements", "Bank Statements", "AIS", "TIS", "Form 26AS",
                     "Fixed Asset Register", "Loan Statements"],
    "TAX_AUDIT": ["Trial Balance", "Ledger Accounts", "Fixed Asset Register", "Stock Statement",
                  "GST Returns", "TDS Returns", "Loan Confirmations", "Previous Year Tax Audit Report"],
    "TDS": ["Salary / Payment Details", "Challan Details (CIN)", "PAN of Deductees", "Lower Deduction Certificates"],
    "ROC_ANNUAL": ["Audited Financial Statements", "Directors' Report", "Shareholding Pattern",
                   "AGM Notice & Minutes", "Auditor's Report", "List of Directors / KMP"],
    "ADV_TAX": ["Estimated Income Computation", "Bank Statement", "TDS Details"],
}
CHECKLIST_MAP = {
    "GST-GSTR1-M": "GST_RETURN", "GST-GSTR1-Q": "GST_RETURN", "GST-GSTR3B-M": "GST_RETURN",
    "GST-GSTR3B-Q": "GST_RETURN", "GST-CMP08": "GST_RETURN", "GST-GSTR9": "GST_ANNUAL",
    "GST-GSTR9C": "GST_ANNUAL", "GST-GSTR4": "GST_ANNUAL",
    "IT-ITR1": "ITR", "IT-ITR2": "ITR", "IT-ITR4": "ITR", "IT-ITR3": "ITR_BUSINESS",
    "IT-ITR5": "ITR_BUSINESS", "IT-ITR6": "ITR_BUSINESS", "IT-ITR7": "ITR_BUSINESS",
    "IT-TAXAUDIT": "TAX_AUDIT", "IT-ADVTAX": "ADV_TAX",
    "TDS-24Q": "TDS", "TDS-26Q": "TDS", "TDS-27Q": "TDS", "TDS-27EQ": "TDS",
    "ROC-AOC4": "ROC_ANNUAL", "ROC-AOC4X": "ROC_ANNUAL", "ROC-MGT7": "ROC_ANNUAL", "ROC-MGT7A": "ROC_ANNUAL",
    "ROC-LLP8": "ROC_ANNUAL", "ROC-LLP11": "ROC_ANNUAL",
}


def seed_compliance_master(s: Session) -> int:
    """Insert master rows that do not exist yet (never overwrites user edits)."""
    existing = {m.code for m in s.query(ComplianceMaster.code)}
    added = 0
    for order, (code, cat, name, form, per, appl, rule, buf, src) in enumerate(MASTER, start=1):
        if code in existing:
            continue
        m = ComplianceMaster(code=code, category=cat, name=name, form_number=form, periodicity=per,
                             applicability=json.dumps(appl), internal_buffer_days=buf, is_active=True,
                             sort_order=order, description=rule.get("r", ""))
        s.add(m)
        s.flush()
        s.add(ComplianceDueDateRule(
            master_id=m.id, offset_months=rule.get("o", 1), due_day=rule.get("d", 20),
            period_overrides=json.dumps(rule.get("ov", {})), alt_rules=json.dumps(rule.get("alt", [])),
            fixed_dates=json.dumps(rule.get("fx", [])),
            effective_from=date(2017, 7, 1) if cat == "GST" else date(2000, 4, 1),
            notification_ref="Seed default - verify before use", official_source=src,
            remarks=rule.get("r", ""), is_current=True, created_by="system"))
        for i, doc in enumerate(CHECKLISTS.get(CHECKLIST_MAP.get(code, ""), []), start=1):
            s.add(DocumentChecklist(master_id=m.id, client_id=None, document_name=doc,
                                    is_mandatory=True, sort_order=i))
        added += 1
    return added


def seed_defaults(s: Session) -> None:
    from app.services.auth_service import hash_password
    from app.services.settings_service import DEFAULT_SETTINGS

    if not s.query(User).count():
        s.add(User(username="admin", full_name="Administrator", role="Admin",
                   password_hash=hash_password("Admin@123"), is_active=True,
                   must_change_password=True, designation="System Administrator"))
        log.info("Default admin user created (password change forced on first login).")
    for key, value in DEFAULT_SETTINGS.items():
        if s.get(Setting, key) is None:
            s.add(Setting(key=key, value=json.dumps(value)))
    s.flush()
    n = seed_compliance_master(s)
    if n:
        log.info("Seeded %s compliance master entries", n)


# =====================================================================
# DEMO MODE - random sample data (only loaded on explicit request)
# =====================================================================
FIRST = ["Rahul", "Priya", "Amit", "Sneha", "Vikas", "Neha", "Rohit", "Anjali", "Suresh", "Kavita",
         "Manoj", "Pooja", "Arun", "Deepa", "Sanjay", "Ritu"]
LAST = ["Sharma", "Agrawal", "Gupta", "Mehta", "Jain", "Patel", "Singh", "Verma", "Bansal", "Khandelwal"]
BIZ = ["Shree Ganesh", "Om Sai", "Balaji", "Laxmi", "Krishna", "Mahalaxmi", "Sunrise", "Galaxy",
       "Royal", "Prime", "Apex", "Vardhman", "Jai Ambe", "Siddhi Vinayak", "Tirupati", "Everest"]
SUFFIX = {"Proprietorship": "Traders", "Partnership Firm": "Enterprises", "LLP": "Consultants LLP",
          "Private Limited Company": "Industries Private Limited", "Public Limited Company": "Infra Limited",
          "Trust": "Charitable Trust", "Society": "Welfare Society", "Association of Persons": "Associates AOP",
          "HUF": "HUF"}
CITIES = [("Mumbai", "Maharashtra", "27"), ("Pune", "Maharashtra", "27"), ("Jaipur", "Rajasthan", "08"),
          ("Delhi", "Delhi", "07"), ("Ahmedabad", "Gujarat", "24"), ("Indore", "Madhya Pradesh", "23"),
          ("Kolkata", "West Bengal", "19"), ("Bengaluru", "Karnataka", "29")]
INDUSTRIES = ["Trading", "Manufacturing", "IT Services", "Real Estate", "Healthcare", "Education",
              "Textiles", "Hospitality", "Logistics", "Professional Services"]


def _rand_pan(ch: str) -> str:
    L = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return "".join(random.choice(L) for _ in range(3)) + ch + random.choice(L) + \
        f"{random.randint(1000, 9999)}" + random.choice(L)


def load_demo_data(n_clients: int = 30) -> dict:
    """Populate the database with random but valid-looking sample data."""
    from app.services import (auth_service, billing_service, client_service, compliance_engine,
                              notice_service, task_service, collection_service, reminder_engine)
    from app.utils.validators import ENTITY_PAN_CHAR, gstin_checksum
    from app.services.settings_service import current_fy

    random.seed()
    summary = {}
    staff_defs = [("niraj", "CA Niraj Agrawal", "Partner"), ("meena", "CA Meena Joshi", "Manager"),
                  ("rakesh", "Rakesh Kumar", "Senior"), ("sonal", "Sonal Verma", "Senior"),
                  ("ajay", "Ajay Yadav", "Junior"), ("komal", "Komal Shah", "Junior")]
    users = {}
    for uname, full, role in staff_defs:
        uid = auth_service.get_user_id(uname)
        if uid is None:
            uid = auth_service.save_user({"username": uname, "full_name": full, "role": role,
                                          "email": f"{uname}@nirajagrawal.example", "is_active": True,
                                          "designation": role}, password="Demo@1234")
        users[role] = users.get(role, []) + [uid]
    partners, managers = users["Partner"], users["Manager"]
    staff = users["Senior"] + users["Junior"]

    fy = current_fy()
    entity_pool = (["Individual"] * 6 + ["Proprietorship"] * 5 + ["Partnership Firm"] * 4 + ["LLP"] * 3 +
                   ["Private Limited Company"] * 6 + ["Public Limited Company"] + ["HUF"] * 2 +
                   ["Trust"] + ["Society"] + ["Association of Persons"])
    itr_map = {"Individual": "ITR-2", "Proprietorship": "ITR-3", "HUF": "ITR-2", "Partnership Firm": "ITR-5",
               "LLP": "ITR-5", "Private Limited Company": "ITR-6", "Public Limited Company": "ITR-6",
               "Trust": "ITR-7", "Society": "ITR-7", "Association of Persons": "ITR-5"}
    client_ids = []
    for i in range(n_clients):
        et = random.choice(entity_pool)
        city, state, sc = random.choice(CITIES)
        if et in ("Individual",):
            name = f"{random.choice(FIRST)} {random.choice(LAST)}"
        elif et == "HUF":
            name = f"{random.choice(FIRST)} {random.choice(LAST)} HUF"
        else:
            name = f"{random.choice(BIZ)} {SUFFIX.get(et, 'Associates')}"
        name = f"{name} {i + 1:02d}" if random.random() < 0.15 else name
        pan = _rand_pan(ENTITY_PAN_CHAR.get(et, "P"))
        has_gst = et not in ("Individual", "HUF", "Trust", "Society") or random.random() < 0.2
        g14 = f"{sc}{pan}{random.randint(1, 9)}Z"
        gstin = g14 + gstin_checksum(g14) if has_gst else None
        is_co = "Company" in et
        data = {
            "client_name": name, "legal_name": name.upper(), "entity_type": et, "pan": pan,
            "gstin": gstin,
            "tan": "".join(random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(4))
            + f"{random.randint(10000, 99999)}" + random.choice("ABCDEFGHJK"),
            "cin_llpin": (f"U{random.randint(10000, 99999)}{['MH', 'RJ', 'DL', 'GJ'][random.randint(0, 3)]}"
                          f"{random.randint(2005, 2022)}PTC{random.randint(100000, 999999)}") if is_co else
            (f"AA{random.choice('ABCDEFG')}-{random.randint(1000, 9999)}" if et == "LLP" else None),
            "city": city, "state": state, "pin_code": str(random.randint(110001, 799999)),
            "address": f"{random.randint(1, 400)}, {random.choice(['MG Road', 'Station Road', 'Ring Road', 'Civil Lines', 'Industrial Area'])}",
            "contact_person": f"{random.choice(FIRST)} {random.choice(LAST)}",
            "mobile": f"9{random.randint(100000000, 999999999)}", "email": f"client{i + 1}@example.com",
            "industry": random.choice(INDUSTRIES), "nature_of_business": "Demo business activity",
            "acquisition_date": date.today() - timedelta(days=random.randint(400, 2500)),
            "date_of_incorporation": date.today() - timedelta(days=random.randint(1500, 9000)),
            "assigned_partner_id": random.choice(partners), "assigned_manager_id": random.choice(managers),
            "assigned_staff_id": random.choice(staff), "status": "Active",
            "risk_category": random.choice(["Low", "Medium", "Medium", "High"]),
            "professional_fee": float(random.choice([15000, 25000, 40000, 60000, 100000, 150000])),
            "billing_frequency": random.choice(["Annual", "Quarterly", "Monthly"]),
            "engagement_start": date.today() - timedelta(days=random.randint(300, 2000)),
            "gst_registration_type": "Normal Taxpayer" if has_gst else "Not Registered",
            "gst_scheme": "Composition" if has_gst and random.random() < 0.15 else "Regular",
            "gst_frequency": random.choice(["Monthly", "Monthly", "Quarterly"]) if has_gst else "Monthly",
            "gst_state": state if has_gst else None, "gst_status": "Active" if has_gst else "Not Applicable",
            "gst_registration_date": date(2017, 7, 1) if has_gst else None,
            "gst_9c_applicable": has_gst and is_co and random.random() < 0.5,
            "gst_exporter_lut": has_gst and random.random() < 0.15,
            "itr_form": itr_map.get(et, "ITR-3"),
            "tax_audit_applicable": et not in ("Individual", "HUF") and random.random() < 0.6,
            "transfer_pricing_applicable": is_co and random.random() < 0.2,
            "advance_tax_applicable": random.random() < 0.7,
            "charitable_registration": et in ("Trust", "Society"),
            "tds_applicable": et not in ("Individual", "HUF"),
            "tds_salary": et not in ("Individual", "HUF") and random.random() < 0.7,
            "tds_nonsalary": et not in ("Individual", "HUF"),
            "tds_nonresident": is_co and random.random() < 0.2, "tcs_applicable": random.random() < 0.1,
            "statutory_audit_applicable": is_co or et == "LLP" and random.random() < 0.5,
            "small_company": et == "Private Limited Company" and random.random() < 0.5,
            "msme_payables": is_co and random.random() < 0.4, "xbrl_applicable": False,
        }
        if not data["tds_applicable"]:
            data["tan"] = None
        try:
            cid = client_service.save_client(data)
            client_ids.append(cid)
        except Exception as exc:  # noqa: BLE001
            log.warning("Demo client skipped: %s", exc)
    summary["clients"] = len(client_ids)
    summary["compliances"] = compliance_engine.generate_for_all(fy)

    # Randomly progress compliances that are already due
    recs = compliance_engine.list_records({"fy": fy})
    done = 0
    for r in recs:
        due = r["due"]
        if due and due < date.today() and random.random() < 0.82:
            fdate = due - timedelta(days=random.randint(0, 6)) if random.random() < 0.85 else due + timedelta(days=random.randint(1, 20))
            compliance_engine.complete_record(r["id"], {
                "status": random.choice(["Filed", "Completed"]), "filing_date": fdate, "completion_date": fdate,
                "ack_number": f"AA{random.randint(10 ** 11, 10 ** 12 - 1)}",
                "challan_number": f"CIN{random.randint(10 ** 9, 10 ** 10 - 1)}" if random.random() < 0.5 else None})
            done += 1
        elif due and due <= date.today() + timedelta(days=20) and random.random() < 0.5:
            compliance_engine.bulk_update([r["id"]], status=random.choice(
                ["In Progress", "Awaiting Documents", "Under Review", "Ready for Filing"]))
    summary["completed"] = done

    # Notices
    dep_cat = [("Income Tax", "Income Tax Notice", "143(2)"), ("Income Tax", "Income Tax Assessment", "148A(b)"),
               ("GST", "GST Notice", "ASMT-10 / Sec 61"), ("GST", "GST Notice", "DRC-01 / Sec 73"),
               ("TDS", "TDS Notice", "Default Intimation"), ("ROC", "ROC Notice", "Sec 92 / 137")]
    n_notices = 0
    for _ in range(12):
        dep, cat, sec = random.choice(dep_cat)
        rec_date = date.today() - timedelta(days=random.randint(2, 90))
        reply_due = rec_date + timedelta(days=random.choice([15, 30]))
        notice_service.create_notice({
            "client_id": random.choice(client_ids), "department": dep, "category": cat,
            "notice_type": cat, "section": sec, "notice_number": f"NTC/{random.randint(10000, 99999)}",
            "din": f"ITBA/{random.randint(10 ** 9, 10 ** 10 - 1)}" if dep == "Income Tax" else f"DIN{random.randint(10 ** 9, 10 ** 10 - 1)}",
            "notice_date": rec_date - timedelta(days=random.randint(0, 3)), "receipt_date": rec_date,
            "assessment_year": "2025-26", "financial_year": "2024-25", "reply_due_date": reply_due,
            "assigned_staff_id": random.choice(staff), "reviewer_id": random.choice(partners + managers),
            "status": random.choice(["Received", "Under Review", "Documents Awaited", "Drafting Reply"]),
            "demand_amount": float(random.choice([0, 25000, 150000, 480000])),
            "amount_disputed": float(random.choice([0, 25000, 150000])), "remarks": "Demo notice"})
        n_notices += 1
    summary["notices"] = n_notices

    # Tasks
    titles = ["Collect bank statements", "Prepare GST reconciliation", "Finalise books of accounts",
              "Draft engagement letter", "Follow up for TDS challans", "Review financial statements",
              "Prepare computation of income", "Board meeting minutes", "Update fixed asset register"]
    for _ in range(25):
        task_service.save_task({
            "client_id": random.choice(client_ids), "title": random.choice(titles),
            "description": "Demo task", "category": random.choice(["GST", "Income Tax", "TDS", "ROC", "General"]),
            "financial_year": fy, "assigned_to_id": random.choice(staff),
            "reviewer_id": random.choice(managers + partners),
            "start_date": date.today() - timedelta(days=random.randint(0, 20)),
            "due_date": date.today() + timedelta(days=random.randint(-10, 20)),
            "priority": random.choice(["Critical", "High", "Medium", "Medium", "Low"]),
            "status": random.choice(["Pending", "In Progress", "Awaiting Client Documents", "Under Review", "Completed"])})
    summary["tasks"] = 25

    # Invoices & payments
    n_inv = 0
    for cid in random.sample(client_ids, min(len(client_ids), 20)):
        amt = float(random.choice([10000, 15000, 25000, 50000, 75000]))
        inv_date = date.today() - timedelta(days=random.randint(5, 200))
        bid = billing_service.save_invoice({"client_id": cid, "invoice_date": inv_date,
                                            "description": "Professional fees - compliance services",
                                            "fee_type": random.choice(["Retainership", "Compliance", "Audit"]),
                                            "financial_year": fy, "amount": amt, "gst_rate": 18.0,
                                            "due_date": inv_date + timedelta(days=30)})
        r = random.random()
        if r < 0.45:
            billing_service.record_payment(bid, {"payment_date": inv_date + timedelta(days=random.randint(5, 40)),
                                                 "amount": round(amt * 1.18, 2), "mode": "NEFT", "reference": "DEMO"})
        elif r < 0.7:
            billing_service.record_payment(bid, {"payment_date": inv_date + timedelta(days=15),
                                                 "amount": round(amt * 0.5, 2), "mode": "UPI", "reference": "DEMO"})
        n_inv += 1
    summary["invoices"] = n_inv
    summary["checklists"] = collection_service.ensure_upcoming(60)
    compliance_engine.refresh_overdue()
    summary["reminders"] = reminder_engine.scan()
    from app.services import settings_service
    settings_service.set("last_generated_fy", fy)
    return summary
