"""
Lightweight, non-destructive schema migration.

* New tables are created automatically.
* New columns added to models are appended with ALTER TABLE ADD COLUMN.
* Versioned data migrations can be registered in MIGRATIONS.
* A verified backup is taken BEFORE any change to an existing database.
Existing client data is never dropped or overwritten.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from typing import Callable

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine

import config
from app.database.models import Base
from app.utils.logger import get_logger

log = get_logger(__name__)

# version -> function(connection). Add future data migrations here.
MIGRATIONS: dict[int, Callable] = {}


def _read_version(engine: Engine) -> int:
    try:
        with engine.connect() as conn:
            row = conn.execute(text("SELECT value FROM settings WHERE key='schema_version'")).fetchone()
            return int(json.loads(row[0])) if row else 0
    except Exception:
        return 0


def _pre_migration_backup(db_path: str) -> str:
    folder = os.path.join(config.get_path("backup_dir"),
                          f"pre_migration_{datetime.now():%Y%m%d_%H%M%S}")
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, "ca_firm.db")
    src = sqlite3.connect(db_path)
    dst = sqlite3.connect(dest)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    log.info("Pre-migration backup created at %s", dest)
    return dest


def pending_changes(engine: Engine) -> dict:
    insp = inspect(engine)
    existing = set(insp.get_table_names())
    missing_tables, missing_cols = [], {}
    for table in Base.metadata.sorted_tables:
        if table.name not in existing:
            missing_tables.append(table.name)
            continue
        cols = {c["name"] for c in insp.get_columns(table.name)}
        miss = [c.name for c in table.columns if c.name not in cols]
        if miss:
            missing_cols[table.name] = miss
    return {"existing": existing, "tables": missing_tables, "columns": missing_cols}


def run_migrations(engine: Engine, db_path: str) -> None:
    changes = pending_changes(engine)
    is_new = not changes["existing"]
    version = 0 if is_new else _read_version(engine)
    needs_change = bool(changes["tables"] or changes["columns"] or version < config.SCHEMA_VERSION)
    if not is_new and needs_change and os.path.exists(db_path):
        try:
            _pre_migration_backup(db_path)
        except Exception as exc:  # noqa: BLE001
            log.error("Pre-migration backup failed: %s", exc)
            raise RuntimeError(f"Could not back up database before migration: {exc}") from exc

    Base.metadata.create_all(engine)

    with engine.begin() as conn:
        for table_name, cols in changes["columns"].items():
            table = Base.metadata.tables[table_name]
            for col_name in cols:
                col = table.columns[col_name]
                col_type = col.type.compile(dialect=engine.dialect)
                default_sql = ""
                if col.default is not None and getattr(col.default, "is_scalar", False):
                    val = col.default.arg
                    if isinstance(val, bool):
                        default_sql = f" DEFAULT {1 if val else 0}"
                    elif isinstance(val, (int, float)):
                        default_sql = f" DEFAULT {val}"
                    elif isinstance(val, str):
                        default_sql = " DEFAULT '" + val.replace("'", "''") + "'"
                conn.execute(text(f'ALTER TABLE "{table_name}" ADD COLUMN "{col_name}" {col_type}{default_sql}'))
                log.info("Migration: added column %s.%s", table_name, col_name)
        for v in range(version + 1, config.SCHEMA_VERSION + 1):
            fn = MIGRATIONS.get(v)
            if fn:
                log.info("Running data migration v%s", v)
                fn(conn)
        conn.execute(text("INSERT OR REPLACE INTO settings(key, value) VALUES ('schema_version', :v)"),
                     {"v": json.dumps(config.SCHEMA_VERSION)})
