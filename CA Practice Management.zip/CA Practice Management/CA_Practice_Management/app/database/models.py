"""
Normalised SQLite schema (SQLAlchemy ORM).

Large files are never stored in the database - only relative paths to the
document repository on disk.
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (Boolean, Column, Date, DateTime, Float, ForeignKey, Index, Integer,
                        String, Text, UniqueConstraint)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class TimestampMixin:
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


# ------------------------------------------------------------------ users
class User(Base, TimestampMixin):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    full_name = Column(String(120), nullable=False)
    role = Column(String(30), nullable=False, default="Junior")
    email = Column(String(120))
    mobile = Column(String(20))
    designation = Column(String(80))
    password_hash = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    must_change_password = Column(Boolean, default=False)
    last_login = Column(DateTime)


# ------------------------------------------------------------------ clients
class Client(Base, TimestampMixin):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True)
    client_code = Column(String(20), unique=True, nullable=False, index=True)
    client_name = Column(String(200), nullable=False, index=True)
    legal_name = Column(String(200))
    pan = Column(String(10), index=True)
    tan = Column(String(10), index=True)
    gstin = Column(String(15), unique=True, index=True)
    cin_llpin = Column(String(21), index=True)
    entity_type = Column(String(50), nullable=False, default="Individual")
    date_of_incorporation = Column(Date)
    address = Column(Text)
    city = Column(String(80))
    state = Column(String(80))
    pin_code = Column(String(10))
    contact_person = Column(String(120))
    mobile = Column(String(20))
    email = Column(String(120))
    alternate_contact = Column(String(120))
    industry = Column(String(120))
    nature_of_business = Column(Text)
    accounting_year = Column(String(30), default="April-March")
    financial_year = Column(String(10))
    acquisition_date = Column(Date)
    assigned_partner_id = Column(Integer, ForeignKey("users.id"))
    assigned_manager_id = Column(Integer, ForeignKey("users.id"))
    assigned_staff_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(20), default="Active", index=True)
    risk_category = Column(String(20), default="Medium")
    professional_fee = Column(Float, default=0.0)
    billing_frequency = Column(String(30), default="Annual")
    engagement_start = Column(Date)
    engagement_end = Column(Date)
    notes = Column(Text)
    # GST profile
    gst_registration_type = Column(String(50), default="Not Registered")
    gst_scheme = Column(String(20), default="Regular")
    gst_frequency = Column(String(20), default="Monthly")
    gst_state = Column(String(80))
    gst_registration_date = Column(Date)
    gst_status = Column(String(30), default="Not Applicable")
    gst_9c_applicable = Column(Boolean, default=False)
    gst_exporter_lut = Column(Boolean, default=False)
    # Income tax / TDS profile
    itr_form = Column(String(10))
    tax_audit_applicable = Column(Boolean, default=False)
    transfer_pricing_applicable = Column(Boolean, default=False)
    advance_tax_applicable = Column(Boolean, default=False)
    charitable_registration = Column(Boolean, default=False)
    tds_applicable = Column(Boolean, default=False)
    tds_salary = Column(Boolean, default=False)
    tds_nonsalary = Column(Boolean, default=False)
    tds_nonresident = Column(Boolean, default=False)
    tcs_applicable = Column(Boolean, default=False)
    # ROC profile
    agm_date = Column(Date)
    statutory_audit_applicable = Column(Boolean, default=False)
    small_company = Column(Boolean, default=False)
    xbrl_applicable = Column(Boolean, default=False)
    msme_payables = Column(Boolean, default=False)

    contacts = relationship("ClientContact", back_populates="client", cascade="all, delete-orphan")


class ClientContact(Base, TimestampMixin):
    __tablename__ = "client_contacts"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(120), nullable=False)
    designation = Column(String(80))
    mobile = Column(String(20))
    email = Column(String(120))
    is_primary = Column(Boolean, default=False)
    client = relationship("Client", back_populates="contacts")


class ClientComplianceApplicability(Base):
    """Per-client manual override of the automatic applicability rules."""
    __tablename__ = "client_compliance_applicability"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id", ondelete="CASCADE"), nullable=False, index=True)
    master_id = Column(Integer, ForeignKey("compliance_master.id"), nullable=False)
    applicable = Column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("client_id", "master_id", name="uq_client_master_applic"),)


# ------------------------------------------------------------------ compliance
class ComplianceMaster(Base, TimestampMixin):
    __tablename__ = "compliance_master"
    id = Column(Integer, primary_key=True)
    code = Column(String(40), unique=True, nullable=False)
    category = Column(String(30), nullable=False, index=True)       # GST / Income Tax / TDS / ROC / Other
    name = Column(String(150), nullable=False)
    form_number = Column(String(60))
    periodicity = Column(String(20), nullable=False, default="Annual")
    applicability = Column(Text, default="{}")                     # JSON rule
    description = Column(Text)
    internal_buffer_days = Column(Integer)                          # None -> firm default
    is_active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=100)


class ComplianceDueDateRule(Base):
    """Versioned due-date rule. A new version is added (never overwritten) when a
    notification changes the due date - preserving revision history."""
    __tablename__ = "compliance_due_date_rules"
    id = Column(Integer, primary_key=True)
    master_id = Column(Integer, ForeignKey("compliance_master.id", ondelete="CASCADE"), nullable=False, index=True)
    offset_months = Column(Integer, default=1)       # months after period end
    due_day = Column(Integer, default=20)
    period_overrides = Column(Text, default="{}")    # {"M03": [1, 30], "Q4": [2, 31], "skip": ["M06"]}
    alt_rules = Column(Text, default="[]")           # [{"if_true": "tax_audit_applicable", "offset": 7, "day": 31}]
    fixed_dates = Column(Text, default="[]")         # [{"month": 6, "day": 15, "label": "1st instalment"}]
    effective_from = Column(Date, nullable=False, default=date(2000, 4, 1))
    effective_to = Column(Date)
    notification_ref = Column(String(200))
    official_source = Column(String(250))
    remarks = Column(Text)
    is_current = Column(Boolean, default=True)
    created_by = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)


class ComplianceRecord(Base):
    __tablename__ = "compliance_records"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False, index=True)
    master_id = Column(Integer, ForeignKey("compliance_master.id"), nullable=False, index=True)
    category = Column(String(30), index=True)
    compliance_name = Column(String(150))
    form_number = Column(String(60))
    financial_year = Column(String(10), index=True)
    assessment_year = Column(String(10))
    tax_period = Column(String(60))
    period_key = Column(String(40), nullable=False)
    period_start = Column(Date)
    period_end = Column(Date)
    original_due_date = Column(Date, index=True)
    revised_due_date = Column(Date, index=True)
    internal_target_date = Column(Date)
    doc_collection_deadline = Column(Date)
    review_deadline = Column(Date)
    completion_date = Column(Date)
    filing_date = Column(Date)
    ack_number = Column(String(100))
    challan_number = Column(String(100))
    challan_amount = Column(Float)
    srn = Column(String(60))
    assigned_staff_id = Column(Integer, ForeignKey("users.id"))
    reviewer_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(40), default="Not Started", index=True)
    penalty_notes = Column(Text)
    remarks = Column(Text)
    attachment_path = Column(String(500))
    due_rule_id = Column(Integer, ForeignKey("compliance_due_date_rules.id"))
    revision_reason = Column(String(250))
    revision_source = Column(String(250))
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    __table_args__ = (UniqueConstraint("client_id", "master_id", "period_key", name="uq_compliance_period"),)

    @property
    def applicable_due_date(self):
        return self.revised_due_date or self.original_due_date


class ComplianceHistory(Base):
    __tablename__ = "compliance_history"
    id = Column(Integer, primary_key=True)
    record_id = Column(Integer, ForeignKey("compliance_records.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(60))
    old_value = Column(Text)
    new_value = Column(Text)
    details = Column(Text)
    user = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)


# ------------------------------------------------------------------ notices
class Notice(Base, TimestampMixin):
    __tablename__ = "notices"
    id = Column(Integer, primary_key=True)
    notice_code = Column(String(20), unique=True, nullable=False)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False, index=True)
    category = Column(String(60))
    department = Column(String(40), index=True)
    notice_type = Column(String(120))
    section = Column(String(120))
    notice_number = Column(String(100), index=True)
    din = Column(String(100), index=True)
    notice_date = Column(Date)
    receipt_date = Column(Date)
    assessment_year = Column(String(10))
    financial_year = Column(String(10))
    reply_due_date = Column(Date, index=True)
    internal_deadline = Column(Date)
    assigned_staff_id = Column(Integer, ForeignKey("users.id"))
    reviewer_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(40), default="Received", index=True)
    reply_date = Column(Date)
    ack_number = Column(String(100))
    hearing_date = Column(Date)
    next_hearing_date = Column(Date)
    appeal_deadline = Column(Date)
    amount_disputed = Column(Float, default=0.0)
    demand_amount = Column(Float, default=0.0)
    remarks = Column(Text)
    notice_doc_path = Column(String(500))
    reply_doc_path = Column(String(500))
    closed_date = Column(Date)
    closure_remarks = Column(Text)


class NoticeHistory(Base):
    __tablename__ = "notice_history"
    id = Column(Integer, primary_key=True)
    notice_id = Column(Integer, ForeignKey("notices.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(60))
    status = Column(String(40))
    details = Column(Text)
    version_no = Column(Integer)
    doc_path = Column(String(500))
    user = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)


# ------------------------------------------------------------------ tasks
class Task(Base, TimestampMixin):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True)
    task_code = Column(String(20), unique=True, nullable=False)
    client_id = Column(Integer, ForeignKey("clients.id"), index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    category = Column(String(40))
    financial_year = Column(String(10))
    assessment_year = Column(String(10))
    assigned_to_id = Column(Integer, ForeignKey("users.id"), index=True)
    reviewer_id = Column(Integer, ForeignKey("users.id"))
    created_by_id = Column(Integer, ForeignKey("users.id"))
    created_date = Column(Date, default=date.today)
    start_date = Column(Date)
    due_date = Column(Date, index=True)
    priority = Column(String(20), default="Medium")
    status = Column(String(40), default="Pending", index=True)
    completion_date = Column(Date)
    review_notes = Column(Text)
    attachment_path = Column(String(500))
    source_type = Column(String(30))   # manual / notice / compliance / doc_followup / onboarding
    source_id = Column(Integer)


class TaskHistory(Base):
    __tablename__ = "task_history"
    id = Column(Integer, primary_key=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(60))
    details = Column(Text)
    user = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)


# ------------------------------------------------------------------ documents
class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False, index=True)
    category = Column(String(60))
    area = Column(String(40))                 # GST / Income Tax / TDS / ROC / Notices / Audit / General
    financial_year = Column(String(10))
    compliance_record_id = Column(Integer, ForeignKey("compliance_records.id"))
    notice_id = Column(Integer, ForeignKey("notices.id"))
    task_id = Column(Integer, ForeignKey("tasks.id"))
    title = Column(String(250))
    file_name = Column(String(250), index=True)
    stored_path = Column(String(500), nullable=False)   # relative to document root
    file_type = Column(String(20))
    file_size = Column(Integer)
    tags = Column(String(250))
    remarks = Column(Text)
    current_version = Column(Integer, default=1)
    uploaded_by = Column(String(50))
    uploaded_at = Column(DateTime, default=datetime.now)
    is_deleted = Column(Boolean, default=False, index=True)


class DocumentVersion(Base):
    __tablename__ = "document_versions"
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True)
    version_no = Column(Integer, nullable=False)
    stored_path = Column(String(500), nullable=False)
    file_size = Column(Integer)
    uploaded_by = Column(String(50))
    uploaded_at = Column(DateTime, default=datetime.now)
    remarks = Column(Text)
    __table_args__ = (UniqueConstraint("document_id", "version_no", name="uq_doc_version"),)


# ------------------------------------------------------------------ reminders
class Reminder(Base):
    __tablename__ = "reminders"
    id = Column(Integer, primary_key=True)
    reminder_type = Column(String(60), index=True)
    ref_type = Column(String(30))     # compliance / notice / task / collection
    ref_id = Column(Integer)
    client_id = Column(Integer, ForeignKey("clients.id"))
    title = Column(String(250))
    message = Column(Text)
    due_date = Column(Date)
    remind_on = Column(Date, index=True)
    recipient_id = Column(Integer, ForeignKey("users.id"))
    status = Column(String(20), default="Pending", index=True)   # Pending/Snoozed/Completed/Dismissed
    snooze_until = Column(Date)
    channel = Column(String(30), default="In-App")
    created_at = Column(DateTime, default=datetime.now)
    __table_args__ = (UniqueConstraint("ref_type", "ref_id", "reminder_type", "remind_on", name="uq_reminder"),)


class ReminderHistory(Base):
    __tablename__ = "reminder_history"
    id = Column(Integer, primary_key=True)
    reminder_id = Column(Integer, ForeignKey("reminders.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(60))
    channel = Column(String(30))
    details = Column(Text)
    user = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)


# ------------------------------------------------------------------ document collection
class DocumentChecklist(Base):
    """Checklist template. client_id NULL = firm-wide template for the compliance;
    client-specific rows replace the firm-wide list for that client."""
    __tablename__ = "document_checklists"
    id = Column(Integer, primary_key=True)
    master_id = Column(Integer, ForeignKey("compliance_master.id", ondelete="CASCADE"), index=True)
    client_id = Column(Integer, ForeignKey("clients.id", ondelete="CASCADE"), index=True)
    document_name = Column(String(150), nullable=False)
    is_mandatory = Column(Boolean, default=True)
    sort_order = Column(Integer, default=10)


class DocumentCollectionStatus(Base):
    __tablename__ = "document_collection_status"
    id = Column(Integer, primary_key=True)
    compliance_record_id = Column(Integer, ForeignKey("compliance_records.id", ondelete="CASCADE"),
                                  nullable=False, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False, index=True)
    document_name = Column(String(150), nullable=False)
    is_mandatory = Column(Boolean, default=True)
    received = Column(Boolean, default=False, index=True)
    received_date = Column(Date)
    follow_up_staff_id = Column(Integer, ForeignKey("users.id"))
    follow_up_date = Column(Date)
    remarks = Column(Text)
    document_id = Column(Integer, ForeignKey("documents.id"))
    __table_args__ = (UniqueConstraint("compliance_record_id", "document_name", name="uq_collection_doc"),)


# ------------------------------------------------------------------ billing
class BillingRecord(Base, TimestampMixin):
    __tablename__ = "billing_records"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False, index=True)
    invoice_number = Column(String(40), unique=True, nullable=False)
    invoice_date = Column(Date, nullable=False)
    description = Column(Text)
    fee_type = Column(String(40), default="Compliance")
    compliance_record_id = Column(Integer, ForeignKey("compliance_records.id"))
    financial_year = Column(String(10), index=True)
    amount = Column(Float, default=0.0)
    gst_rate = Column(Float, default=18.0)
    gst_amount = Column(Float, default=0.0)
    total_amount = Column(Float, default=0.0)
    due_date = Column(Date)
    status = Column(String(20), default="Unpaid", index=True)
    remarks = Column(Text)


class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True)
    billing_id = Column(Integer, ForeignKey("billing_records.id", ondelete="CASCADE"), nullable=False, index=True)
    payment_date = Column(Date, nullable=False)
    amount = Column(Float, nullable=False)
    mode = Column(String(30))
    reference = Column(String(100))
    remarks = Column(Text)
    created_at = Column(DateTime, default=datetime.now)


# ------------------------------------------------------------------ system
class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=datetime.now, index=True)
    user = Column(String(50))
    module = Column(String(40))
    action = Column(String(60))
    description = Column(Text)
    client_id = Column(Integer, ForeignKey("clients.id"))


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(Text)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=datetime.now, index=True)
    user = Column(String(50))
    table_name = Column(String(60))
    record_id = Column(Integer)
    action = Column(String(30))
    old_values = Column(Text)
    new_values = Column(Text)


class BackupHistory(Base):
    __tablename__ = "backup_history"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=datetime.now)
    kind = Column(String(20))
    location = Column(String(500))
    include_documents = Column(Boolean, default=False)
    size_bytes = Column(Integer)
    verified = Column(Boolean, default=False)
    status = Column(String(20))
    message = Column(Text)
    user = Column(String(50))


Index("ix_cr_due_status", ComplianceRecord.original_due_date, ComplianceRecord.status)
