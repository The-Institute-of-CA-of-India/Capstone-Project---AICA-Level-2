"""Application bootstrap: logging, database, theme, main window (no sign-in screen)."""
from __future__ import annotations

import sys
import traceback

import config
from app.utils.logger import get_logger, setup_logging

log = get_logger(__name__)


def _app_icon():
    from app.qt import QColor, QFont, QIcon, QLinearGradient, QPainter, QPixmap, Qt, QRectF
    pm = QPixmap(128, 128)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, 128, 128)
    g.setColorAt(0, QColor("#2563EB"))
    g.setColorAt(0.5, QColor("#7C3AED"))
    g.setColorAt(1, QColor("#EC4899"))
    p.setBrush(g)
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(4, 4, 120, 120), 28, 28)
    p.setPen(QColor("white"))
    f = QFont("Segoe UI", 40)
    f.setBold(True)
    p.setFont(f)
    p.drawText(QRectF(0, 0, 128, 128), int(Qt.AlignmentFlag.AlignCenter), "NA")
    p.end()
    return QIcon(pm)


def _excepthook(exc_type, exc, tb):
    log.critical("Unhandled exception:\n%s", "".join(traceback.format_exception(exc_type, exc, tb)))
    try:
        from app.qt import QMessageBox
        QMessageBox.critical(None, "Unexpected Error",
                             f"An unexpected error occurred:\n\n{exc}\n\nDetails were written to logs/app.log. "
                             "Your data is safe; please retry the operation.")
    except Exception:
        pass


def run(demo: bool = False) -> int:
    setup_logging()
    config.ensure_dirs()
    sys.excepthook = _excepthook
    from app.qt import QApplication, QMessageBox, QT_API
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(config.APP_NAME)
    app.setOrganizationName(config.DEFAULT_FIRM_NAME)
    app.setWindowIcon(_app_icon())
    app.setQuitOnLastWindowClosed(True)
    log.info("Starting %s v%s (Qt binding: %s)", config.APP_NAME, config.APP_VERSION, QT_API)

    from app.database.db import init_database
    try:
        init_database()
    except Exception as exc:  # noqa: BLE001
        log.exception("Database initialisation failed")
        QMessageBox.critical(None, "Database Error", f"Could not open / initialise the database:\n{exc}")
        return 1

    from app.services import settings_service
    from app.utils.date_utils import set_date_format
    set_date_format(settings_service.get("date_format") or "%d-%m-%Y")
    from app.ui.styles import stylesheet
    app.setStyleSheet(stylesheet(settings_service.get("theme") or "light"))

    # Daily automatic backup (before anyone edits data today)
    try:
        from app.services import backup_service
        backup_service.auto_daily_backup()
    except Exception as exc:  # noqa: BLE001
        log.error("Auto backup error: %s", exc)

    from app.services import auth_service
    from app.ui.main_window import MainWindow
    if not auth_service.auto_login():
        QMessageBox.critical(None, "Startup Error", "No user account found in the database.")
        return 1
    _maybe_demo(demo)
    win = MainWindow()
    win.show()
    return app.exec()


def _maybe_demo(force: bool) -> None:
    """Demo data only on --demo flag or explicit first-run consent (empty database)."""
    from app.qt import QMessageBox
    from app.database.db import session_scope
    from app.database.models import Client
    from app.services import auth_service
    with session_scope() as s:
        empty = s.query(Client).count() == 0
    if not empty or not auth_service.has_perm("settings.edit"):
        return
    if not force:
        from app.services import settings_service
        if settings_service.get("demo_prompt_done"):
            return
        settings_service.set("demo_prompt_done", True)
        ans = QMessageBox.question(
            None, "Start Mode",
            "The database is empty.\n\nYES  = Load random DEMO data (sample clients, compliances, notices, tasks, "
            "invoices) to explore the application.\nNO   = Start with an empty production database.\n\n"
            "(Demo data can also be loaded later from Settings > Data & Demo.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if ans != QMessageBox.StandardButton.Yes:
            return
    from app.qt import QApplication, Qt
    from app.database.seed_data import load_demo_data
    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
    try:
        summary = load_demo_data()
    finally:
        QApplication.restoreOverrideCursor()
    QMessageBox.information(None, "Demo Data Loaded",
                            "\n".join(f"{k.title()}: {v}" for k, v in summary.items()) +
                            "\n\nDemo staff logins use password Demo@1234 (e.g. niraj, meena, rakesh).")
