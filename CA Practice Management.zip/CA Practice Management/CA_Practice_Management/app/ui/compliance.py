"""Compliance tracker UI (shared by All / GST / Income Tax / TDS / ROC pages)."""
from __future__ import annotations

from datetime import timedelta
from typing import Optional

from app.qt import *  # noqa: F401,F403
from app.services import (auth_service, client_service, collection_service, compliance_engine, document_service,
                          settings_service)
from app.services.compliance_engine import CATEGORIES, DONE_STATUSES
from app.ui.widgets import (BasePage, DataTable, DateField, Field, FormDialog, button, confirm, error, info,
                            notify_changed, run_safely, section_label)
from app.utils.date_utils import fy_choices, today

COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("category", "Category"),
           ("compliance_name", "Compliance"), ("form_number", "Form"), ("tax_period", "Period"),
           ("financial_year", "FY"), ("assessment_year", "AY"), ("original_due", "Statutory Due"),
           ("revised_due", "Revised Due"), ("due", "Applicable Due"), ("internal_target", "Internal Target"),
           ("days_left", "Days Left"), ("status", "Status"), ("staff", "Staff"), ("reviewer", "Reviewer"),
           ("filing_date", "Filed On"), ("ack_number", "Ack No."), ("challan_number", "Challan / CIN"),
           ("srn", "SRN"), ("delay_days", "Delay Days"), ("remarks", "Remarks")]

QUICK = [("all", "All"), ("today", "Due Today"), ("7", "Due ≤ 7 days"), ("15", "Due ≤ 15 days"),
         ("overdue", "Overdue"), ("pending", "Pending"), ("done", "Completed")]


# ------------------------------------------------------------------ dialogs
def _record_fields(new: bool, category: Optional[str]) -> list:
    statuses = settings_service.compliance_statuses()
    fields = []
    if new:
        masters = [(f"{m['category']} - {m['name']}", m["id"]) for m in compliance_engine.list_masters(category, True)]
        fields += [Field("client_id", "Client", "client", required=True),
                   Field("master_id", "Compliance Type", "combo", masters, required=True),
                   Field("financial_year", "Financial Year", "combo", fy_choices(), default=settings_service.current_fy()),
                   Field("tax_period", "Tax Period (label)", required=True, placeholder="e.g. Apr-2026 / Q1 / FY 2026-27")]
    else:
        fields += [Field("client_name", "Client", "label"), Field("compliance_name", "Compliance", "label"),
                   Field("tax_period", "Tax Period"), Field("financial_year", "Financial Year", "label"),
                   Field("assessment_year", "Assessment Year", "label")]
    fields += [Field("original_due_date", "Statutory Due Date", "date", required=new),
               Field("revised_due_date", "Revised Due Date", "date", tooltip="Use 'Revise Due Date' to record source"),
               Field("internal_target_date", "Internal Target Date", "date"),
               Field("doc_collection_deadline", "Client Document Deadline", "date"),
               Field("review_deadline", "Review Deadline", "date"),
               Field("status", "Status", "combo", statuses, default="Not Started"),
               Field("assigned_staff_id", "Assigned Staff", "user"), Field("reviewer_id", "Reviewer", "user"),
               Field("completion_date", "Date of Completion", "date"), Field("filing_date", "Filing Date", "date"),
               Field("ack_number", "Acknowledgment No."), Field("challan_number", "Challan No. / CIN"),
               Field("challan_amount", "Challan Amount", "money"), Field("srn", "SRN (MCA)"),
               Field("penalty_notes", "Penalty / Interest Notes", "multiline"), Field("remarks", "Remarks", "multiline")]
    return fields


def edit_compliance(parent, record_id: Optional[int], category: Optional[str] = None) -> bool:
    if not auth_service.has_perm("compliance.edit"):
        error(parent, "You do not have permission to edit compliance records.")
        return False
    rec = compliance_engine.get_record(record_id) if record_id else None
    values = None
    if rec:
        values = dict(rec)
        values.update({"original_due_date": rec["original_due"], "revised_due_date": rec["revised_due"],
                       "internal_target_date": rec["internal_target"], "doc_collection_deadline": rec["doc_deadline"],
                       "review_deadline": rec["review_deadline"]})
    hist = None
    extra = []
    if rec:
        hist = DataTable([("when", "When"), ("user", "User"), ("action", "Action"), ("old", "Old"), ("new", "New"),
                          ("details", "Details")], export_title="Compliance History", page_size=50)
        hist.set_rows(compliance_engine.record_history(record_id))
        extra.append(("History", hist))
        info_lbl = QLabel(f"<b>Revision:</b> {rec.get('revision_reason') or '-'}<br><b>Source:</b> "
                          f"{rec.get('revision_source') or '-'}<br><b>Attachment:</b> {rec.get('attachment_path') or '-'}")
        info_lbl.setWordWrap(True)
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(info_lbl)
        docs = DataTable([("title", "Title"), ("file_name", "File"), ("uploaded_at", "Uploaded")], page_size=50,
                         show_toolbar=False)
        docs.set_rows(document_service.list_documents(compliance_record_id=record_id))
        docs.activated.connect(lambda i: run_safely(parent, document_service.open_path,
                                                    document_service.get_document(i)["stored_path"]))
        lay.addWidget(section_label("Linked documents (double-click to open)"))
        lay.addWidget(docs, 1)
        extra.append(("Documents & Revision", w))
    title = f"Compliance - {rec['compliance_name']} ({rec['tax_period']})" if rec else "Add Manual Compliance Entry"
    dlg = FormDialog(parent, title, [("Details", _record_fields(not rec, category))], values, extra_tabs=extra or None,
                     width=780)
    dlg.resize(820, 720)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    vals = {k: v for k, v in dlg.values.items() if k not in ("client_name", "compliance_name")}
    if rec:
        vals.pop("financial_year", None)
        vals.pop("assessment_year", None)
        if vals.get("status") in DONE_STATUSES and vals.get("status") != "Not Applicable" and not vals.get("filing_date"):
            error(parent, "Filing date is required to mark a compliance Filed / Completed. Use 'Mark Complete'.")
            return False
    res = run_safely(parent, compliance_engine.save_record, vals, record_id)
    if res:
        notify_changed("compliance")
    return bool(res)


def complete_dialog(parent, ids: list[int]) -> bool:
    if not auth_service.has_perm("compliance.review"):
        error(parent, "You do not have permission to complete compliances.")
        return False
    fields = [Field("status", "Completion Status", "combo", ["Filed", "Completed", "Not Applicable"], default="Filed"),
              Field("filing_date", "Filing Date", "date", default=today()),
              Field("completion_date", "Completion Date", "date", default=today()),
              Field("ack_number", "Acknowledgment No."), Field("challan_number", "Challan No. / CIN"),
              Field("challan_amount", "Challan Amount", "money"), Field("srn", "SRN (MCA)"),
              Field("assigned_staff_id", "Prepared By (Staff)", "user"), Field("reviewer_id", "Reviewed By", "user"),
              Field("penalty_notes", "Late Fee / Interest Notes", "multiline"), Field("remarks", "Remarks", "multiline")]
    if len(ids) == 1:
        fields.append(Field("attachment", "Acknowledgment File", "file"))
        rec = compliance_engine.get_record(ids[0])
        defaults = {"assigned_staff_id": rec["assigned_staff_id"], "reviewer_id": rec["reviewer_id"],
                    "status": "Filed", "filing_date": today(), "completion_date": today()}
        title = f"Mark Complete - {rec['client_name']} / {rec['compliance_name']} ({rec['tax_period']})"
    else:
        defaults = {"status": "Filed", "filing_date": today(), "completion_date": today()}
        title = f"Mark {len(ids)} Compliances Complete"

    def validate(v):
        if v["status"] != "Not Applicable" and not v.get("filing_date"):
            return "Filing date is required."
        if v["status"] == "Filed" and not v.get("ack_number") and len(ids) == 1:
            if not confirm(parent, "No acknowledgment number entered. Continue without it?"):
                return "Please enter the acknowledgment number."
        return None

    dlg = FormDialog(parent, title, [("Completion", fields)], defaults, on_validate=validate, save_text="✔ Complete")
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    done = 0
    for i in ids:
        data = dict(dlg.values)
        if run_safely(parent, compliance_engine.complete_record, i, data) is None:
            pass
        done += 1
    notify_changed("compliance")
    return True


def revise_dialog(parent, ids: list[int]) -> bool:
    if not auth_service.has_perm("compliance.review"):
        error(parent, "You do not have permission to revise due dates.")
        return False
    dlg = FormDialog(parent, f"Revise Due Date ({len(ids)} record(s))", [("Revision", [
        Field("new_date", "Revised Due Date", "date", required=True),
        Field("reason", "Notification / Order / Reason", required=True,
              placeholder="e.g. CBDT Circular No. xx/2026 dated dd-mm-yyyy"),
        Field("source", "Official Source / URL"),
    ])], save_text="Apply Revision")
    lbl = QLabel("The statutory (original) due date is preserved. The revised date and its source are recorded "
                 "in the compliance history.")
    lbl.setWordWrap(True)
    dlg.layout().insertWidget(1, lbl)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    v = dlg.values
    n = run_safely(parent, compliance_engine.revise_due_date, ids, v["new_date"], v["reason"], v.get("source") or "")
    if n:
        info(parent, f"Due date revised for {n} record(s).")
        notify_changed("compliance")
    return bool(n)


def bulk_dialog(parent, ids: list[int]) -> None:
    statuses = ["(no change)"] + settings_service.compliance_statuses()
    dlg = FormDialog(parent, f"Bulk Update ({len(ids)} record(s))", [("Update", [
        Field("status", "Status", "combo", statuses),
        Field("staff_id", "Assign Staff", "user"), Field("reviewer_id", "Reviewer", "user")])], save_text="Apply")
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return
    v = dlg.values
    st = v["status"] if v["status"] != "(no change)" else None
    if st in DONE_STATUSES and st != "Not Applicable":
        error(parent, "Use 'Mark Complete' to set Filed / Completed (filing date and acknowledgment are captured).")
        return
    n = run_safely(parent, compliance_engine.bulk_update, ids, st, v.get("staff_id"), v.get("reviewer_id"))
    if n:
        notify_changed("compliance")


class ChecklistDialog(QDialog):
    """Document checklist for one compliance record (received / pending)."""

    def __init__(self, parent, record_id: int):
        super().__init__(parent)
        rec = compliance_engine.get_record(record_id)
        self.record_id = record_id
        self.setWindowTitle(f"Document Checklist - {rec['client_name']} / {rec['compliance_name']} ({rec['tax_period']})")
        self.resize(900, 520)
        collection_service.ensure_for_record_id(record_id)
        v = QVBoxLayout(self)
        v.addWidget(section_label(self.windowTitle()))
        self.table = DataTable([("document_name", "Document"), ("mandatory", "Mandatory"), ("received", "Status"),
                                ("received_date", "Received On"), ("follow_up_staff", "Follow-up By"),
                                ("follow_up_date", "Follow-up Date"), ("remarks", "Remarks")],
                               export_title="Document Checklist", page_size=100)
        v.addWidget(self.table, 1)
        h = QHBoxLayout()
        h.addWidget(button("✔ Mark Received", "success", lambda: self._mark(True)))
        h.addWidget(button("✖ Mark Not Received", "ghost", lambda: self._mark(False)))
        h.addWidget(button("✎ Customise checklist for this client", "ghost", self._customise))
        h.addStretch(1)
        h.addWidget(button("Close", "ghost", self.accept))
        v.addLayout(h)
        self.load()

    def load(self):
        self.table.set_rows(collection_service.list_status(record_id=self.record_id))

    def _mark(self, received: bool):
        ids = self.table.selected_ids()
        if not ids:
            return info(self, "Select one or more documents.")
        collection_service.mark_received(ids, received)
        self.load()
        notify_changed("collection")

    def _customise(self):
        from app.ui.collection import ChecklistEditor
        rec = compliance_engine.get_record(self.record_id)
        if ChecklistEditor(self, rec["master_id"], rec["client_id"]).exec():
            collection_service.ensure_for_record_id(self.record_id)
            self.load()


# ------------------------------------------------------------------ panel
class CompliancePanel(QWidget):
    def __init__(self, main, category: Optional[str] = None, master_codes: Optional[list[str]] = None,
                 title: str = "Compliance Tracker"):
        super().__init__()
        self.main = main
        self.category = category
        self.master_codes = master_codes
        self.quick = "all"
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        top = QHBoxLayout()
        self.chips = QButtonGroup(self)
        for key, label in QUICK:
            b = QPushButton(label)
            b.setProperty("kind", "chip")
            b.setCheckable(True)
            b.setChecked(key == "all")
            b.clicked.connect(lambda _=False, k=key: self._set_quick(k))
            self.chips.addButton(b)
            top.addWidget(b)
        top.addStretch(1)
        top.addWidget(QLabel("FY"))
        self.fy = QComboBox()
        self.fy.addItem("All years", None)
        for f in fy_choices(settings_service.current_fy()):
            self.fy.addItem(f, f)
        self.fy.setCurrentIndex(max(0, self.fy.findData(settings_service.current_fy())))
        self.fy.currentIndexChanged.connect(lambda _: self.refresh())
        top.addWidget(self.fy)
        v.addLayout(top)
        bar = QHBoxLayout()
        can_edit = auth_service.has_perm("compliance.edit")
        can_rev = auth_service.has_perm("compliance.review")
        for text, slot, kind, en in [("✏ Open / Edit", self.edit, "", can_edit), ("✔ Mark Complete", self.complete, "success", can_rev),
                                     ("📅 Revise Due Date", self.revise, "ghost", can_rev),
                                     ("⚡ Bulk Update", self.bulk, "ghost", can_edit),
                                     ("📋 Doc Checklist", self.checklist, "ghost", True),
                                     ("📎 Attach Document", self.attach, "ghost", auth_service.has_perm("documents.edit")),
                                     ("＋ Manual Entry", self.add, "ghost", can_edit),
                                     ("⚙ Generate FY", self.generate, "pink", can_rev)]:
            b = button(text, kind, slot)
            b.setEnabled(en)
            bar.addWidget(b)
        bar.addStretch(1)
        v.addLayout(bar)
        filters = (["category"] if not category else []) + ["compliance_name", "status", "staff"]
        self.table = DataTable(COLUMNS, table_key=f"compliance_{category or 'all'}", filters=filters,
                               money=["challan_amount"], export_title=title)
        self.table.extra_filter = self._quick_filter
        self.table.activated.connect(lambda i: (edit_compliance(self, i, self.category)))
        self.table.add_action("Open / edit", self.edit)
        self.table.add_action("Mark complete", self.complete)
        self.table.add_action("Revise due date", self.revise)
        self.table.add_action("Document checklist", self.checklist)
        self.table.add_action("Open client profile", self.open_client)
        self.table.add_action(None)
        self.table.add_action("Delete manual entry", self.delete)
        v.addWidget(self.table, 1)

    def _set_quick(self, k):
        self.quick = k
        self.table.reapply()

    def _quick_filter(self, r) -> bool:
        t = today()
        q = self.quick
        d = r.get("due")
        is_done = r["status"] in DONE_STATUSES
        if q == "all":
            return True
        if q == "done":
            return is_done
        if is_done:
            return False
        if q == "pending":
            return True
        if q == "overdue":
            return bool(d and d < t)
        if q == "today":
            return d == t
        days = int(q)
        return bool(d and t <= d <= t + timedelta(days=days))

    def refresh(self):
        f = {"fy": self.fy.currentData(), "category": self.category}
        if self.master_codes:
            f["master_codes"] = self.master_codes
        self.table.set_rows(compliance_engine.list_records(f))

    def preset(self, quick: Optional[str] = None, status: Optional[str] = None):
        if quick:
            for b in self.chips.buttons():
                b.setChecked(b.text() == dict(QUICK).get(quick))
            self.quick = quick
        if status:
            self.table.set_filter("status", status)
        self.table.reapply()

    def _ids(self, single=False):
        ids = self.table.selected_ids()
        if not ids:
            info(self, "Please select one or more compliance records.")
            return []
        return ids[:1] if single else ids

    def edit(self):
        ids = self._ids(True)
        if ids:
            edit_compliance(self, ids[0], self.category)

    def add(self):
        edit_compliance(self, None, self.category)

    def complete(self):
        ids = self._ids()
        if ids:
            complete_dialog(self, ids)

    def revise(self):
        ids = self._ids()
        if ids:
            revise_dialog(self, ids)

    def bulk(self):
        ids = self._ids()
        if ids:
            bulk_dialog(self, ids)

    def checklist(self):
        ids = self._ids(True)
        if ids:
            ChecklistDialog(self, ids[0]).exec()

    def open_client(self):
        r = self.table.current_row()
        if r:
            self.main.open_record("client", r["client_id"])

    def attach(self):
        r = self.table.current_row()
        if not r:
            return info(self, "Select a compliance record first.")
        from app.ui.widgets import open_file_dialog
        p = open_file_dialog(self, "Attach Document")
        if not p:
            return
        if run_safely(self, document_service.store_file, p, client_id=r["client_id"], area=r["category"],
                      financial_year=r["financial_year"], category=f"{r['category']} Returns" if r["category"] in ("GST", "TDS") else "Other Documents",
                      title=f"{r['compliance_name']} {r['tax_period']}", compliance_record_id=r["id"]):
            info(self, "Document attached to the compliance record.")
            notify_changed("documents")

    def delete(self):
        ids = self._ids(True)
        if ids and confirm(self, "Delete this compliance entry? (Only allowed for not-started entries without filing data.)"):
            run_safely(self, compliance_engine.delete_record, ids[0])
            notify_changed("compliance")

    def generate(self):
        fy = self.fy.currentData() or settings_service.current_fy()
        if confirm(self, f"Generate recurring compliance records for all active clients for FY {fy}?\n"
                         "Only applicable compliances are created; existing entries are never duplicated."):
            n = run_safely(self, compliance_engine.generate_for_all, fy)
            if n is not None:
                info(self, f"{n} new compliance record(s) generated.")
                notify_changed("compliance")


class MatrixPanel(QWidget):
    """Client x period filing status matrix for a chosen form (monthly / quarterly calendar)."""

    def __init__(self, main, category: str):
        super().__init__()
        self.main = main
        self.category = category
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        h = QHBoxLayout()
        h.addWidget(QLabel("Form"))
        self.master = QComboBox()
        self.master.setMinimumWidth(320)
        h.addWidget(self.master)
        h.addWidget(QLabel("FY"))
        self.fy = QComboBox()
        self.fy.addItems(fy_choices(settings_service.current_fy()))
        self.fy.setCurrentText(settings_service.current_fy())
        h.addWidget(self.fy)
        h.addStretch(1)
        lg = QLabel("✔ = filed (date) • colours: green done, yellow due soon, red overdue, blue in progress, grey not started")
        lg.setObjectName("Muted")
        h.addWidget(lg)
        v.addLayout(h)
        self.table = DataTable([("client_name", "Client")], export_title=f"{category} Filing Matrix")
        self.table.activated.connect(lambda cid: self.main.open_record("client", cid))
        v.addWidget(self.table, 1)
        self.master.currentIndexChanged.connect(lambda _: self.refresh())
        self.fy.currentIndexChanged.connect(lambda _: self.refresh())
        self._loaded = False

    def refresh(self):
        if not self._loaded:
            self.master.blockSignals(True)
            for m in compliance_engine.list_masters(self.category, True):
                if m["periodicity"] in ("Monthly", "Quarterly", "Half-Yearly", "Fixed Dates", "Annual"):
                    self.master.addItem(f"{m['name']} [{m['periodicity']}]", m["id"])
            self.master.blockSignals(False)
            self._loaded = True
        mid = self.master.currentData()
        if not mid:
            return
        cols, rows = compliance_engine.filing_matrix(mid, self.fy.currentText())
        old = self.table
        self.table = DataTable(cols, export_title=f"{self.master.currentText()} - FY {self.fy.currentText()}")
        self.table.activated.connect(lambda cid: self.main.open_record("client", cid))
        self.layout().replaceWidget(old, self.table)
        old.deleteLater()
        self.table.set_rows(rows)


class ClientInfoPanel(QWidget):
    """Category-specific client registration view (GSTIN-wise, TAN-wise, CIN-wise)."""

    def __init__(self, main, columns: list, row_filter, title: str):
        super().__init__()
        self.main = main
        self.row_filter = row_filter
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        self.table = DataTable(columns, export_title=title)
        self.table.activated.connect(lambda cid: self.main.open_record("client", cid))
        v.addWidget(self.table, 1)

    def refresh(self):
        self.table.set_rows([c for c in client_service.list_clients() if self.row_filter(c)])


class CategoryPage(BasePage):
    """Base for GST / Income Tax / TDS / ROC pages."""
    CATEGORY = "GST"
    TITLE = "GST Compliance"
    CLIENT_COLUMNS: list = []
    EXTRA_TABS: list = []        # (tab title, [master codes])

    def client_filter(self, c) -> bool:
        return True

    def __init__(self, main):
        super().__init__(main, self.TITLE, self.TITLE)
        self.tabs = QTabWidget()
        self.panels = []
        self.tracker = CompliancePanel(main, self.CATEGORY, title=f"{self.TITLE} Tracker")
        self.tabs.addTab(self.tracker, "Tracker")
        self.panels.append(self.tracker)
        for title, codes in self.EXTRA_TABS:
            p = CompliancePanel(main, self.CATEGORY, codes, title=title)
            self.tabs.addTab(p, title)
            self.panels.append(p)
        self.matrix = MatrixPanel(main, self.CATEGORY)
        self.tabs.addTab(self.matrix, "Filing Status Matrix / Calendar")
        self.panels.append(self.matrix)
        if self.CLIENT_COLUMNS:
            self.clients = ClientInfoPanel(main, self.CLIENT_COLUMNS, self.client_filter, f"{self.TITLE} - Clients")
            self.tabs.addTab(self.clients, "Clients")
            self.panels.append(self.clients)
        self.tabs.currentChanged.connect(lambda _: self.refresh())
        self.root.addWidget(self.tabs, 1)

    def refresh(self):
        w = self.tabs.currentWidget()
        if w is not None:
            w.refresh()

    def apply_preset(self, **kw):
        self.tabs.setCurrentIndex(0)
        self.tracker.preset(kw.get("quick"), kw.get("status"))


class CompliancePage(BasePage):
    """All compliances across categories."""

    def __init__(self, main):
        super().__init__(main, "All Compliances", "Compliance")
        self.panel = CompliancePanel(main, None, title="All Compliances")
        self.root.addWidget(self.panel, 1)

    def refresh(self):
        self.panel.refresh()

    def apply_preset(self, **kw):
        self.panel.preset(kw.get("quick"), kw.get("status"))
