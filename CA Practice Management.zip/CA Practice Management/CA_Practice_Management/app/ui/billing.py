"""Professional fee & billing tracker UI."""
from __future__ import annotations

from datetime import timedelta

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, billing_service, settings_service
from app.services.billing_service import FEE_TYPES, PAYMENT_MODES
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, ask_text, button, confirm, error, info,
                            notify_changed, run_safely)
from app.utils.date_utils import fy_choices, today
from app.utils.formatters import inr

INV_COLS = [("invoice_number", "Invoice No."), ("invoice_date", "Date"), ("client_name", "Client"),
            ("fee_type", "Fee Type"), ("description", "Description"), ("financial_year", "FY"), ("amount", "Amount"),
            ("gst_amount", "GST"), ("total_amount", "Total"), ("paid", "Received"), ("outstanding", "Outstanding"),
            ("due_date", "Payment Due"), ("age_days", "Age (days)"), ("status", "Status")]
MONEY = ["amount", "gst_amount", "total_amount", "paid", "outstanding", "billed", "received", "b0_30", "b31_60",
         "b61_90", "b90", "gst", "collected"]


def edit_invoice(parent, billing_id) -> bool:
    if not auth_service.has_perm("billing.edit"):
        error(parent, "You do not have permission to edit invoices.")
        return False
    rec = billing_service.get_invoice(billing_id) if billing_id else None
    fields = [Field("client_id", "Client", "client", required=True),
              Field("invoice_number", "Invoice Number", placeholder="Blank = auto", readonly=bool(rec)),
              Field("invoice_date", "Invoice Date", "date", required=True, default=today()),
              Field("fee_type", "Fee Type", "combo", FEE_TYPES, default="Compliance"),
              Field("financial_year", "Financial Year", "combo", fy_choices(), default=settings_service.current_fy()),
              Field("description", "Description", "multiline"),
              Field("amount", "Professional Fee (excl. GST)", "money", required=True, extra={"nonzero": True}),
              Field("gst_rate", "GST Rate %", "float", default=float(settings_service.get("gst_rate_default") or 18)),
              Field("due_date", "Payment Due Date", "date", default=today() + timedelta(days=30)),
              Field("remarks", "Remarks", "multiline")]
    defaults = rec or {"invoice_date": today(), "due_date": today() + timedelta(days=30), "fee_type": "Compliance",
                       "financial_year": settings_service.current_fy(),
                       "gst_rate": float(settings_service.get("gst_rate_default") or 18)}
    dlg = FormDialog(parent, f"Invoice {rec['invoice_number']}" if rec else "New Invoice", [("Invoice", fields)], defaults)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    v = dlg.values
    if rec:
        v.pop("invoice_number", None)
    res = run_safely(parent, billing_service.save_invoice, v, billing_id)
    if res:
        notify_changed("billing")
    return bool(res)


class BillingPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Professional Fee & Billing", "Billing")
        can = auth_service.has_perm("billing.edit")
        self.add_header_button("＋ New Invoice", lambda: edit_invoice(self, None), "pink", "", can)
        self.summary = QLabel("")
        self.summary.setObjectName("SectionTitle")
        self.root.addWidget(self.summary)
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)
        w = QWidget()
        v = QVBoxLayout(w)
        bar = QHBoxLayout()
        for text, slot, kind in [("✏ Edit", self.edit, ""), ("💵 Record Payment", self.pay, "success"),
                                 ("🧾 Payments", self.payments, "ghost"), ("✖ Cancel Invoice", self.cancel, "ghost")]:
            b = button(text, kind, slot)
            b.setEnabled(can or text.startswith("🧾"))
            bar.addWidget(b)
        bar.addStretch(1)
        v.addLayout(bar)
        self.inv = DataTable(INV_COLS, table_key="invoices", filters=["status", "fee_type", "financial_year", "client_name"],
                             money=MONEY, export_title="Invoice Register")
        self.inv.activated.connect(lambda i: edit_invoice(self, i))
        v.addWidget(self.inv, 1)
        self.tabs.addTab(w, "Invoices")
        self.pays = DataTable([("payment_date", "Date"), ("client_name", "Client"), ("invoice_number", "Invoice"),
                               ("amount", "Amount"), ("mode", "Mode"), ("reference", "Reference"), ("remarks", "Remarks")],
                              filters=["mode"], money=MONEY, export_title="Fee Collection Report")
        self.tabs.addTab(self.pays, "Fee Collection")
        self.out = DataTable([("client_code", "Client ID"), ("client_name", "Client"), ("invoices", "Invoices"),
                              ("billed", "Billed"), ("received", "Received"), ("outstanding", "Outstanding"),
                              ("b0_30", "0-30 days"), ("b31_60", "31-60 days"), ("b61_90", "61-90 days"),
                              ("b90", "90+ days")], money=MONEY, export_title="Client-wise Outstanding & Aging")
        self.out.activated.connect(lambda cid: self.main.open_record("client", cid))
        self.tabs.addTab(self.out, "Outstanding & Aging")
        mw = QWidget()
        mv = QVBoxLayout(mw)
        mh = QHBoxLayout()
        mh.addWidget(QLabel("FY"))
        self.fy = QComboBox()
        self.fy.addItems(fy_choices(settings_service.current_fy()))
        self.fy.setCurrentText(settings_service.current_fy())
        self.fy.currentIndexChanged.connect(lambda _: self.refresh())
        mh.addWidget(self.fy)
        mh.addStretch(1)
        mv.addLayout(mh)
        self.month = DataTable([("month", "Month"), ("invoices", "Invoices"), ("billed", "Billed (incl. GST)"),
                                ("gst", "GST"), ("collected", "Collected")], money=MONEY, export_title="Monthly Billing")
        mv.addWidget(self.month, 1)
        self.tabs.addTab(mw, "Monthly Billing")
        self.annual = DataTable([("financial_year", "FY"), ("invoices", "Invoices"), ("billed", "Billed"),
                                 ("received", "Received"), ("outstanding", "Outstanding")], money=MONEY,
                                export_title="Annual Billing")
        self.tabs.addTab(self.annual, "Annual Billing")
        self.tabs.currentChanged.connect(lambda _: self.refresh())

    def refresh(self):
        rows = billing_service.list_invoices()
        live = [r for r in rows if r["status"] != "Cancelled"]
        self.summary.setText(f"Billed: {inr(sum(r['total_amount'] or 0 for r in live))}    •    "
                             f"Received: {inr(sum(r['paid'] for r in live))}    •    "
                             f"Outstanding: {inr(sum(r['outstanding'] for r in live))}")
        i = self.tabs.currentIndex()
        if i == 0:
            self.inv.set_rows(rows)
        elif i == 1:
            self.pays.set_rows(billing_service.list_payments())
        elif i == 2:
            self.out.set_rows(billing_service.outstanding_by_client())
        elif i == 3:
            self.month.set_rows(billing_service.monthly_summary(self.fy.currentText()))
        else:
            self.annual.set_rows(billing_service.annual_summary())

    def _id(self):
        i = self.inv.current_id()
        if i is None:
            info(self, "Please select an invoice.")
        return i

    def edit(self):
        i = self._id()
        if i:
            edit_invoice(self, i)

    def pay(self):
        i = self._id()
        if not i:
            return
        inv = billing_service.get_invoice(i)
        dlg = FormDialog(self, f"Record Payment - {inv['invoice_number']} (Outstanding {inr(inv['outstanding'])})",
                         [("Payment", [Field("payment_date", "Payment Date", "date", required=True, default=today()),
                                       Field("amount", "Amount Received", "money", required=True, extra={"nonzero": True}),
                                       Field("mode", "Mode", "combo", PAYMENT_MODES),
                                       Field("reference", "Reference / UTR / Cheque No."),
                                       Field("remarks", "Remarks")])],
                         {"payment_date": today(), "amount": inv["outstanding"]}, save_text="💵 Record")
        if dlg.exec() == QDialog.DialogCode.Accepted:
            if run_safely(self, billing_service.record_payment, i, dlg.values):
                notify_changed("billing")

    def payments(self):
        i = self._id()
        if not i:
            return
        from app.ui.widgets import DrillDownDialog
        DrillDownDialog(self, "Payments", [("payment_date", "Date"), ("amount", "Amount"), ("mode", "Mode"),
                                           ("reference", "Reference"), ("remarks", "Remarks")],
                        billing_service.list_payments(i), money=["amount"]).exec()

    def cancel(self):
        i = self._id()
        if not i:
            return
        reason = ask_text(self, "Cancel Invoice", "Reason for cancellation:")
        if reason and confirm(self, "Cancel this invoice? This cannot be undone."):
            run_safely(self, billing_service.cancel_invoice, i, reason)
            notify_changed("billing")
