"""Reports & analytics: catalogue, parameters, view, export Excel/PDF/CSV, print."""
from __future__ import annotations

from app.qt import *  # noqa: F401,F403
from app.services import client_service, reporting_service, settings_service
from app.services.auth_service import user_choices
from app.services.compliance_engine import CATEGORIES
from app.ui.widgets import BasePage, DataTable, SearchCombo, button, error, section_label
from app.utils.date_utils import fy_choices


class ReportsPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Reports & Analytics", "Reports")
        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.addWidget(section_label("Report Catalogue"))
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        groups: dict[str, QTreeWidgetItem] = {}
        for g, name, _fn, _need in reporting_service.REPORTS:
            if g not in groups:
                groups[g] = QTreeWidgetItem([f"📂 {g} Reports"])
                self.tree.addTopLevelItem(groups[g])
            it = QTreeWidgetItem([name])
            it.setData(0, Qt.ItemDataRole.UserRole, name)
            groups[g].addChild(it)
        self.tree.expandAll()
        self.tree.itemClicked.connect(self._select)
        self.tree.itemDoubleClicked.connect(lambda *_: self.run())
        lv.addWidget(self.tree, 1)
        split.addWidget(left)
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        self.title = section_label("Select a report")
        rv.addWidget(self.title)
        bar = QHBoxLayout()
        self.lbl_fy = QLabel("FY")
        self.fy = QComboBox()
        self.fy.addItems(fy_choices(settings_service.current_fy()))
        self.fy.setCurrentText(settings_service.current_fy())
        self.lbl_cat = QLabel("Category")
        self.cat = QComboBox()
        self.cat.addItem("All", None)
        for c in CATEGORIES:
            self.cat.addItem(c, c)
        self.lbl_staff = QLabel("Staff")
        self.staff = SearchCombo(user_choices(), "All staff")
        self.lbl_client = QLabel("Client")
        self.client = SearchCombo(client_service.client_choices(active_only=False), "All clients")
        self.client.setMinimumWidth(240)
        for w in (self.lbl_fy, self.fy, self.lbl_cat, self.cat, self.lbl_staff, self.staff, self.lbl_client, self.client):
            bar.addWidget(w)
        bar.addWidget(button("▶ Run Report", "pink", self.run))
        bar.addStretch(1)
        rv.addLayout(bar)
        self.holder = QVBoxLayout()
        self.table = DataTable([("info", "Report")], export_title="Report")
        self.holder.addWidget(self.table)
        rv.addLayout(self.holder, 1)
        hint = QLabel("Use '⬇ Export / Print' above the table to export to Excel, PDF, CSV or print.")
        hint.setObjectName("Muted")
        rv.addWidget(hint)
        split.addWidget(right)
        split.setSizes([300, 1000])
        self.root.addWidget(split, 1)
        self.current = None
        self._show_params(set())

    def _show_params(self, need: set) -> None:
        for flag, ws in (("fy", (self.lbl_fy, self.fy)), ("category", (self.lbl_cat, self.cat)),
                         ("staff", (self.lbl_staff, self.staff)), ("client", (self.lbl_client, self.client))):
            for w in ws:
                w.setVisible(flag in need)

    def _select(self, item, _col=0):
        name = item.data(0, Qt.ItemDataRole.UserRole)
        if not name:
            return
        self.current = name
        self.title.setText(f"📈 {name}")
        need = next(n for _g, nm, _f, n in reporting_service.REPORTS if nm == name)
        self._show_params(need)

    def refresh(self):
        self.client.set_items(client_service.client_choices(active_only=False))

    def run(self):
        if not self.current:
            it = self.tree.currentItem()
            if it:
                self._select(it)
        if not self.current:
            return error(self, "Select a report from the catalogue.")
        need = next(n for _g, nm, _f, n in reporting_service.REPORTS if nm == self.current)
        params = {}
        if "fy" in need:
            params["fy"] = self.fy.currentText()
        if "category" in need:
            params["category"] = self.cat.currentData()
        if "staff" in need:
            params["staff_id"] = self.staff.value()
        if "client" in need:
            params["client_id"] = self.client.value()
        if self.current == "Client Compliance History" and not params.get("client_id"):
            return error(self, "Please select a client for this report.")
        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            cols, rows, money = reporting_service.run_report(self.current, params)
        except Exception as exc:  # noqa: BLE001
            QApplication.restoreOverrideCursor()
            return error(self, f"Report failed: {exc}")
        QApplication.restoreOverrideCursor()
        old = self.table
        self.table = DataTable(cols, money=money, export_title=self.current,
                               filters=[k for k, _ in cols if k in ("category", "status", "staff", "department")][:3])
        self.holder.replaceWidget(old, self.table)
        old.deleteLater()
        self.table.set_rows(rows)
