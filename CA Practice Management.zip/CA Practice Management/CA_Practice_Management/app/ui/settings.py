"""Settings: firm profile, preferences, statuses, compliance master & due-date rules,
users, role permissions, email/WhatsApp, storage, backup & restore, audit trail, demo data."""
from __future__ import annotations

import json
import os

import config
from app.qt import *  # noqa: F401,F403
from app.services import (auth_service, backup_service, compliance_engine, settings_service)
from app.services.permissions import PERMISSIONS, ROLES
from app.ui.styles import stylesheet
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, button, confirm, error, info, notify_changed,
                            open_file_dialog, run_safely, section_label)
from app.utils.date_utils import PERIODICITIES, QT_FORMATS, fy_choices, set_date_format, today


def _form_tab(fields: list, values: dict, on_save, enabled: bool) -> QWidget:
    """Embed a FormDialog-like form inside a tab."""
    w = QWidget()
    v = QVBoxLayout(w)
    dlg = FormDialog(w, "", [("x", fields)], values)
    dlg.setWindowFlags(Qt.WindowType.Widget)
    dlg.btn_cancel.hide()
    dlg.btn_save.setEnabled(enabled)
    dlg.layout().itemAt(0).widget().hide()  # hide title label
    dlg.accept = lambda: on_save(dlg.values)  # type: ignore[assignment]
    dlg.reject = lambda: None  # Esc must not hide an embedded form  # type: ignore[assignment]
    v.addWidget(dlg)
    return w


class MasterDialog(QDialog):
    """Compliance master entry + versioned due-date rules + extensions."""

    def __init__(self, parent, master_id=None):
        super().__init__(parent)
        self.master_id = master_id
        self.setWindowTitle("Compliance Master")
        self.resize(1050, 700)
        v = QVBoxLayout(self)
        m = compliance_engine.get_master(master_id) if master_id else {}
        self.form = FormDialog(self, "", [("Master", [
            Field("code", "Code", readonly=bool(master_id), required=True, upper=True),
            Field("category", "Category", "combo", compliance_engine.CATEGORIES),
            Field("name", "Compliance Name", required=True), Field("form_number", "Form Number"),
            Field("periodicity", "Periodicity", "combo", PERIODICITIES),
            Field("internal_buffer_days", "Internal buffer days (0 = firm default)", "int", (0, 120)),
            Field("is_active", "Active", "bool", default=True),
            Field("applicability", "Applicability rule (JSON)", "multiline", extra={"height": 90},
                  tooltip='Keys: entity_types, requires_true, requires_false, requires_value, field_in, manual'),
            Field("description", "Description / notes", "multiline")] +
            ([] if master_id else [Field("offset_months", "Initial rule: months after period end", "int", (-24, 24), default=1),
                                   Field("due_day", "Initial rule: due day of month", "int", (1, 31), default=20),
                                   Field("notification_ref", "Notification reference"),
                                   Field("official_source", "Official source")]))], m or {"is_active": True,
                                                                                         "applicability": '{"manual": true}',
                                                                                         "offset_months": 1, "due_day": 20})
        self.form.setWindowFlags(Qt.WindowType.Widget)
        self.form.btn_cancel.hide()
        self.form.layout().itemAt(0).widget().hide()
        self.form.accept = self._save_master  # type: ignore[assignment]
        self.form.reject = lambda: None  # type: ignore[assignment]
        tabs = QTabWidget()
        tabs.addTab(self.form, "Master Details")
        if master_id:
            rw = QWidget()
            rv = QVBoxLayout(rw)
            note = QLabel("Due-date rules are versioned. To record a change notified by CBDT / CBIC / MCA, add a NEW "
                          "version with its effective date, notification reference and source. Previous versions are "
                          "retained as revision history. For one-off extensions of a specific period use 'Apply Extension'.")
            note.setWordWrap(True)
            rv.addWidget(note)
            self.rules = DataTable([("effective_from", "Effective From"), ("effective_to", "Effective To"),
                                    ("rule_text", "Rule"), ("notification_ref", "Notification Ref."),
                                    ("official_source", "Official Source"), ("is_current", "Current"),
                                    ("created_by", "By"), ("created_at", "Recorded On"), ("remarks", "Remarks")],
                                   export_title="Due Date Rule History", page_size=50)
            rv.addWidget(self.rules, 1)
            h = QHBoxLayout()
            can = auth_service.has_perm("compliance.master")
            for text, slot in [("＋ New Rule Version", self.new_rule), ("⏩ Apply Extension to Open Records", self.extension),
                               ("⟳ Recalculate Open Records", self.recalc)]:
                b = button(text, "", slot)
                b.setEnabled(can)
                h.addWidget(b)
            h.addStretch(1)
            rv.addLayout(h)
            tabs.addTab(rw, "Due Date Rules & Revision History")
            self.load_rules()
        v.addWidget(tabs, 1)
        v.addWidget(button("Close", "ghost", self.accept), 0, Qt.AlignmentFlag.AlignRight)

    def load_rules(self):
        self.rules.set_rows(compliance_engine.list_rules(self.master_id))

    def _save_master(self):
        vals = self.form.get_values()
        if not vals.get("name"):
            self.form.err.setText("Name is required.")
            return
        mid = run_safely(self, compliance_engine.save_master, vals, self.master_id)
        if mid:
            self.master_id = mid
            info(self, "Compliance master saved.")

    def new_rule(self):
        cur = compliance_engine.list_rules(self.master_id)[0] if compliance_engine.list_rules(self.master_id) else {}
        dlg = FormDialog(self, "New Due-Date Rule Version", [("Rule", [
            Field("effective_from", "Effective From", "date", required=True, default=today()),
            Field("offset_months", "Months after period end", "int", (-24, 24)),
            Field("due_day", "Due day of month", "int", (1, 31)),
            Field("period_overrides", "Period overrides (JSON)", "multiline",
                  tooltip='e.g. {"M03": [1, 30], "Q4": [2, 31], "skip": ["M06"]}'),
            Field("alt_rules", "Conditional rules (JSON)", "multiline",
                  tooltip='e.g. [{"if_true": "tax_audit_applicable", "offset": 7, "day": 31}] or '
                          '[{"event_field": "agm_date", "days": 30}]'),
            Field("fixed_dates", "Fixed dates (JSON, for Fixed Dates periodicity)", "multiline",
                  tooltip='e.g. [{"month": 6, "day": 15, "label": "1st instalment"}]'),
            Field("notification_ref", "Notification / Circular Reference", required=True),
            Field("official_source", "Official Source (URL / gazette)"),
            Field("remarks", "Remarks", "multiline")])],
            {"effective_from": today(), "offset_months": cur.get("offset_months", 1), "due_day": cur.get("due_day", 20),
             "period_overrides": cur.get("period_overrides") or "{}", "alt_rules": cur.get("alt_rules") or "[]",
             "fixed_dates": cur.get("fixed_dates") or "[]"}, save_text="Add Version")
        if dlg.exec() == QDialog.DialogCode.Accepted:
            if run_safely(self, compliance_engine.add_rule_version, self.master_id, dlg.values):
                self.load_rules()
                if confirm(self, "Rule version added.\n\nRecalculate statutory due dates of OPEN records that fall "
                                 "under the new rule (records with revised dates are not touched)?"):
                    self.recalc()

    def recalc(self):
        n = run_safely(self, compliance_engine.recalc_open_records, self.master_id)
        if n is not None:
            info(self, f"{n} open record(s) recalculated.")
            notify_changed("compliance")

    def extension(self):
        dlg = FormDialog(self, "Apply Extension", [("Extension", [
            Field("fy", "Financial Year", "combo", fy_choices(), default=settings_service.current_fy()),
            Field("period_key", "Period key (blank = all periods of FY)",
                  placeholder="e.g. 2026-04 or FY2026-27-Q1 or FY2026-27"),
            Field("new_date", "Extended Due Date", "date", required=True),
            Field("ref", "Notification Reference", required=True), Field("source", "Official Source")])],
            {"fy": settings_service.current_fy()}, save_text="Apply")
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.values
            n = run_safely(self, compliance_engine.apply_extension, self.master_id, v.get("period_key"), v["fy"],
                           v["new_date"], v["ref"], v.get("source") or "")
            if n is not None:
                info(self, f"Extension applied to {n} open record(s). Original statutory dates are preserved.")
                notify_changed("compliance")


class SettingsPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Settings", "Settings")
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)
        can_set = auth_service.has_perm("settings.edit")
        g = settings_service.get
        # ---- firm
        self.tabs.addTab(_form_tab([
            Field("firm_name", "Firm Name", required=True), Field("firm_frn", "Firm Registration No. (FRN)"),
            Field("firm_address", "Firm Address", "multiline"), Field("firm_phone", "Contact Phone"),
            Field("firm_email", "Contact Email"), Field("firm_logo", "Logo file", "file",
                                                        extra={"filter": "Images (*.png *.jpg *.jpeg)"}),
            Field("invoice_prefix", "Invoice number prefix")],
            {k: g(k) for k in ("firm_name", "firm_frn", "firm_address", "firm_phone", "firm_email", "firm_logo", "invoice_prefix")},
            self.save_firm, can_set), "Firm Profile")
        # ---- preferences
        self.tabs.addTab(_form_tab([
            Field("current_fy", "Current Financial Year", "combo", fy_choices()),
            Field("internal_buffer_days", "Default internal deadline buffer (days)", "int", (0, 60)),
            Field("doc_collection_buffer_days", "Client document deadline (days before due)", "int", (0, 90)),
            Field("review_buffer_days", "Review deadline (days before due)", "int", (0, 30)),
            Field("notice_warning_days", "Notice warning period (days)", "int", (1, 60)),
            Field("notice_internal_buffer_days", "Notice internal reply buffer (days)", "int", (0, 30)),
            Field("checklist_upcoming_days", "Build document checklists for items due within (days)", "int", (7, 180)),
            Field("skip_periods_before_onboarding", "Skip compliance periods due before client acquisition date", "bool"),
            Field("session_lock_minutes", "Auto-lock after inactivity (minutes, 0 = never)", "int", (0, 240)),
            Field("theme", "Theme", "combo", [("Light (vibrant)", "light"), ("Dark", "dark")]),
            Field("date_format", "Date format", "combo", list(QT_FORMATS.keys())),
            Field("currency_symbol", "Currency symbol", "text"),
            Field("gst_rate_default", "Default GST rate on fees (%)", "float")],
            {k: g(k) for k in ("current_fy", "internal_buffer_days", "doc_collection_buffer_days", "review_buffer_days",
                               "notice_warning_days", "notice_internal_buffer_days", "checklist_upcoming_days",
                               "skip_periods_before_onboarding", "session_lock_minutes", "theme", "date_format",
                               "currency_symbol", "gst_rate_default")}, self.save_prefs, can_set), "Preferences")
        self.tabs.addTab(self._statuses_tab(can_set), "Compliance Statuses")
        self.tabs.addTab(self._master_tab(), "Compliance Master")
        self.tabs.addTab(self._users_tab(), "Users")
        self.tabs.addTab(self._roles_tab(), "Roles & Permissions")
        self.tabs.addTab(_form_tab([
            Field("email_enabled", "Enable email reminders (optional, needs internet)", "bool"),
            Field("smtp_host", "SMTP host", placeholder="smtp.gmail.com"), Field("smtp_port", "SMTP port", "int", (1, 65535)),
            Field("smtp_use_tls", "Use STARTTLS", "bool"), Field("smtp_user", "SMTP username"),
            Field("email_from", "From address"),
            Field("whatsapp_enabled", "Enable WhatsApp click-to-chat links (optional)", "bool")],
            {k: g(k) for k in ("email_enabled", "smtp_host", "smtp_port", "smtp_use_tls", "smtp_user", "email_from",
                               "whatsapp_enabled")}, self.save_email, can_set), "Email & WhatsApp")
        self.tabs.addTab(self._storage_tab(can_set), "Storage Locations")
        self.tabs.addTab(self._backup_tab(), "Backup & Restore")
        self.tabs.addTab(self._audit_tab(), "Audit Trail")
        self.tabs.addTab(self._demo_tab(can_set), "Data & Demo")
        self.tabs.currentChanged.connect(lambda _: self.refresh())

    # ------------------------------------------------------------------ saves
    def save_firm(self, v):
        if not v.get("firm_name"):
            return error(self, "Firm name is required.")
        settings_service.set_many(v)
        info(self, "Firm profile saved.")

    def save_prefs(self, v):
        settings_service.set_many(v)
        set_date_format(v["date_format"])
        QApplication.instance().setStyleSheet(stylesheet(v["theme"]))
        info(self, "Preferences saved. Some changes (date format in open screens) apply after reopening pages.")
        notify_changed("settings")

    def save_email(self, v):
        settings_service.set_many(v)
        info(self, "Email & WhatsApp settings saved.\nThe SMTP password is never stored - you will be asked for it "
                   "each time you send.")

    # ------------------------------------------------------------------ statuses
    def _statuses_tab(self, can) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel("One status per line. Core statuses (Not Started, Filed, Completed, Overdue, Not Applicable) "
                           "are always available."))
        self.status_edit = QPlainTextEdit("\n".join(settings_service.compliance_statuses()))
        v.addWidget(self.status_edit, 1)
        b = button("💾 Save Statuses", "", self.save_statuses)
        b.setEnabled(can)
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        return w

    def save_statuses(self):
        sts = [s.strip() for s in self.status_edit.toPlainText().splitlines() if s.strip()]
        settings_service.set("compliance_statuses", list(dict.fromkeys(sts)))
        self.status_edit.setPlainText("\n".join(settings_service.compliance_statuses()))
        info(self, "Compliance statuses saved.")

    # ------------------------------------------------------------------ master
    def _master_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        warn = QLabel("⚠ Statutory due dates in this master are editable defaults and are NOT authoritative. Verify each "
                      "rule with the latest CBDT / CBIC / MCA notification and record changes as new rule versions.")
        warn.setWordWrap(True)
        warn.setStyleSheet("color: #BE185D; font-weight: 600;")
        v.addWidget(warn)
        h = QHBoxLayout()
        can = auth_service.has_perm("compliance.master")
        for text, slot in [("＋ New Compliance Type", lambda: self.open_master(None)),
                           ("✏ Open / Edit", self.edit_master), ("✎ Edit Document Checklist", self.edit_checklist)]:
            b = button(text, "", slot)
            b.setEnabled(can)
            h.addWidget(b)
        h.addStretch(1)
        v.addLayout(h)
        self.masters = DataTable([("code", "Code"), ("category", "Category"), ("name", "Compliance"),
                                  ("form_number", "Form"), ("periodicity", "Periodicity"), ("rule_text", "Current Due Rule"),
                                  ("effective_from", "Effective From"), ("notification_ref", "Notification Ref."),
                                  ("official_source", "Source"), ("manual", "Manual Only"), ("is_active", "Active")],
                                 filters=["category", "periodicity"], export_title="Compliance Master")
        self.masters.activated.connect(lambda i: self.open_master(i))
        v.addWidget(self.masters, 1)
        return w

    def open_master(self, mid):
        MasterDialog(self, mid).exec()
        self.masters.set_rows(compliance_engine.list_masters())

    def edit_master(self):
        mid = self.masters.current_id()
        if mid:
            self.open_master(mid)

    def edit_checklist(self):
        from app.ui.collection import ChecklistEditor
        ChecklistEditor(self, self.masters.current_id()).exec()

    # ------------------------------------------------------------------ users
    def _users_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        h = QHBoxLayout()
        can = auth_service.has_perm("users.manage")
        for text, slot in [("＋ Add User", lambda: self.edit_user(None)), ("✏ Edit User", self._edit_sel_user),
                           ("🔑 Reset Password", self.reset_pw)]:
            b = button(text, "", slot)
            b.setEnabled(can)
            h.addWidget(b)
        h.addStretch(1)
        v.addLayout(h)
        self.users = DataTable([("username", "Username"), ("full_name", "Full Name"), ("role", "Role"),
                                ("designation", "Designation"), ("email", "Email"), ("mobile", "Mobile"),
                                ("is_active", "Active"), ("last_login", "Last Login")], filters=["role"],
                               export_title="Users")
        self.users.activated.connect(lambda i: can and self.edit_user(i))
        v.addWidget(self.users, 1)
        return w

    def _edit_sel_user(self):
        uid = self.users.current_id()
        if uid:
            self.edit_user(uid)

    def edit_user(self, uid):
        rec = auth_service.get_user(uid) if uid else None
        fields = [Field("username", "Username", required=True, readonly=bool(rec)),
                  Field("full_name", "Full Name", required=True), Field("role", "Role", "combo", ROLES),
                  Field("designation", "Designation"), Field("email", "Email"), Field("mobile", "Mobile"),
                  Field("is_active", "Active", "bool", default=True)]
        if not rec:
            fields += [Field("password", "Initial Password", "password", required=True),
                       Field("must_change_password", "Force password change at first login", "bool", default=True)]
        dlg = FormDialog(self, "Edit User" if rec else "Add User", [("User", fields)],
                         rec or {"is_active": True, "must_change_password": True, "role": "Junior"})
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.values
            pw = v.pop("password", None)
            if rec:
                v["username"] = rec["username"]
                if rec["id"] == auth_service.current_user_id() and not v.get("is_active"):
                    return error(self, "You cannot deactivate your own account.")
            if run_safely(self, auth_service.save_user, v, uid, pw):
                self.users.set_rows(auth_service.list_users())

    def reset_pw(self):
        uid = self.users.current_id()
        if not uid:
            return info(self, "Select a user.")
        pw, ok = QInputDialog.getText(self, "Reset Password", "New temporary password (user must change it):",
                                      QLineEdit.EchoMode.Password)
        if ok and pw:
            if run_safely(self, auth_service.reset_password, uid, pw) is None:
                pass
            info(self, "Password reset (if no error was shown). The user must change it at next login.")

    # ------------------------------------------------------------------ roles
    def _roles_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel("Tick the permissions granted to each role. Partner/Admin always retain user & settings "
                           "administration to prevent lock-out."))
        perms = auth_service.role_permissions()
        self.role_table = QTableWidget(len(PERMISSIONS), len(ROLES))
        self.role_table.setHorizontalHeaderLabels(ROLES)
        self.role_table.setVerticalHeaderLabels(list(PERMISSIONS.values()))
        self.role_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        for r, p in enumerate(PERMISSIONS):
            for c, role in enumerate(ROLES):
                it = QTableWidgetItem()
                it.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
                it.setCheckState(Qt.CheckState.Checked if p in perms.get(role, []) else Qt.CheckState.Unchecked)
                self.role_table.setItem(r, c, it)
        v.addWidget(self.role_table, 1)
        b = button("💾 Save Role Permissions", "", self.save_roles)
        b.setEnabled(auth_service.has_perm("users.manage"))
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        return w

    def save_roles(self):
        out = {}
        for c, role in enumerate(ROLES):
            out[role] = [p for r, p in enumerate(PERMISSIONS)
                         if self.role_table.item(r, c).checkState() == Qt.CheckState.Checked]
        settings_service.set("role_permissions", out)
        info(self, "Role permissions saved. Users get the new permissions at their next login.")

    # ------------------------------------------------------------------ storage
    def _storage_tab(self, can) -> QWidget:
        w = QWidget()
        f = QFormLayout(w)
        cfg = config.load_local_config()
        self.st_docs = QLineEdit(cfg["documents_dir"])
        self.st_backup = QLineEdit(cfg["backup_dir"])
        for le, label in ((self.st_docs, "Document storage folder"), (self.st_backup, "Backup folder (local / external / pen drive)")):
            row = QHBoxLayout()
            row.addWidget(le, 1)
            row.addWidget(button("Browse…", "ghost", lambda le=le: self._pick(le)))
            box = QWidget()
            box.setLayout(row)
            f.addRow(label, box)
        f.addRow("Database file", QLabel(cfg["db_path"]))
        b = button("💾 Save Locations", "", self.save_storage)
        b.setEnabled(can)
        f.addRow("", b)
        note = QLabel("Changing the document folder does not move existing files - copy the old folder contents to "
                      "the new location first.")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        f.addRow("", note)
        return w

    def _pick(self, le):
        d = QFileDialog.getExistingDirectory(self, "Select folder", le.text())
        if d:
            le.setText(d)

    def save_storage(self):
        for p in (self.st_docs.text(), self.st_backup.text()):
            try:
                os.makedirs(p, exist_ok=True)
            except OSError as exc:
                return error(self, f"Cannot use folder {p}: {exc}")
        config.save_local_config({"documents_dir": self.st_docs.text(), "backup_dir": self.st_backup.text()})
        info(self, "Storage locations saved.")

    # ------------------------------------------------------------------ backup
    def _backup_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        self.lbl_last = QLabel("")
        self.lbl_last.setStyleSheet("font-size: 12pt; font-weight: 800; color: #15803D;")
        v.addWidget(self.lbl_last)
        h = QHBoxLayout()
        can = auth_service.has_perm("backup.manage")
        self.chk_auto = QCheckBox("Daily automatic backup at startup")
        self.chk_auto.setChecked(bool(settings_service.get("auto_backup_daily")))
        self.chk_docs = QCheckBox("Include documents in daily backup")
        self.chk_docs.setChecked(bool(settings_service.get("backup_include_documents_daily")))
        for wdg in (self.chk_auto, self.chk_docs):
            wdg.setEnabled(can)
            wdg.toggled.connect(lambda _: settings_service.set_many({
                "auto_backup_daily": self.chk_auto.isChecked(),
                "backup_include_documents_daily": self.chk_docs.isChecked()}))
            h.addWidget(wdg)
        h.addStretch(1)
        v.addLayout(h)
        h2 = QHBoxLayout()
        for text, slot, kind in [("💾 Backup Database Now", lambda: self.backup(False, None), ""),
                                 ("💾 Backup DB + Documents", lambda: self.backup(True, None), ""),
                                 ("📀 Backup to Folder / Drive…", self.backup_to, "pink"),
                                 ("✔ Verify Selected", self.verify, "ghost"),
                                 ("↩ Restore Database…", self.restore_db, "danger"),
                                 ("↩ Restore Documents…", self.restore_docs, "danger"),
                                 ("📂 Open Backup Folder", lambda: self._open_backup_folder(), "ghost")]:
            b = button(text, kind, slot)
            b.setEnabled(can)
            h2.addWidget(b)
        h2.addStretch(1)
        v.addLayout(h2)
        v.addWidget(section_label("Backup History"))
        self.backups = DataTable([("created_at", "Created"), ("kind", "Type"), ("documents", "Documents"),
                                  ("verified_text", "Verified"), ("size_mb", "Size (MB)"), ("note", "Note"),
                                  ("folder", "Location")], filters=["kind"], export_title="Backup History")
        v.addWidget(self.backups, 1)
        return w

    def _open_backup_folder(self):
        from app.services.document_service import open_path
        run_safely(self, open_path, backup_service.backup_root())

    def backup(self, docs: bool, dest):
        res = run_safely(self, backup_service.create_backup, docs, dest, "Manual")
        if res:
            (info if res["ok"] else error)(self, f"Backup {'completed and verified' if res['ok'] else 'FAILED'}:\n"
                                                 f"{res['folder']}\n{res['message']}")
            self.refresh()
            self.main.update_backup_label()

    def backup_to(self):
        d = QFileDialog.getExistingDirectory(self, "Select backup destination (external drive / pen drive / folder)")
        if d:
            self.backup(confirm(self, "Include documents in this backup?"), d)

    def verify(self):
        r = self.backups.current_row()
        if not r:
            return info(self, "Select a backup.")
        ok, msg = backup_service.verify_backup(r["folder"])
        (info if ok else error)(self, f"Verification {'passed' if ok else 'FAILED'}: {msg}")

    def restore_db(self):
        r = self.backups.current_row()
        path = r["folder"] if r else None
        if not path:
            path = open_file_dialog(self, "Select backup database (ca_firm.db)", "SQLite DB (*.db)")
        if not path:
            return
        if not confirm(self, f"RESTORE the database from:\n{path}\n\nA safety backup of the current database is taken "
                             "first. The application will close after restore and must be restarted.\n\nContinue?"):
            return
        safety = run_safely(self, backup_service.restore_database, path)
        if safety:
            info(self, f"Database restored successfully.\nSafety backup of previous data: {safety}\n\n"
                       "The application will now close. Please start it again.")
            QApplication.instance().quit()

    def restore_docs(self):
        r = self.backups.current_row()
        z = None
        if r and r["documents"] == "Yes":
            z = os.path.join(r["folder"], "documents.zip")
        if not z:
            z = open_file_dialog(self, "Select documents backup (documents.zip)", "ZIP (*.zip)")
        if z and confirm(self, f"Restore documents from:\n{z}\n\nCurrent documents are zipped as a safety copy first. Continue?"):
            safety = run_safely(self, backup_service.restore_documents, z)
            if safety:
                info(self, f"Documents restored.\nSafety copy: {safety}")

    # ------------------------------------------------------------------ audit / demo
    def _audit_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        self.audit = DataTable([("when", "When"), ("user", "User"), ("table", "Table"), ("record_id", "Record"),
                                ("action", "Action"), ("old", "Old Values"), ("new", "New Values")],
                               filters=["user", "table", "action"], export_title="Audit Trail")
        v.addWidget(self.audit, 1)
        return w

    def _demo_tab(self, can) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(section_label("Demo Mode"))
        lbl = QLabel("Loads ~30 random sample clients with compliances, notices, tasks and invoices for training / "
                     "testing. Use only on a separate demo copy - not on production data.")
        lbl.setWordWrap(True)
        v.addWidget(lbl)
        b = button("🎲 Load Random Demo Data", "pink", self.load_demo)
        b.setEnabled(can)
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        v.addWidget(section_label("Compliance Generation"))
        g = button("⚙ Generate compliances for current FY (all clients)", "", self.gen_all)
        g.setEnabled(auth_service.has_perm("compliance.review"))
        v.addWidget(g, 0, Qt.AlignmentFlag.AlignLeft)
        v.addWidget(section_label("Templates"))
        t = button("📄 Save Client Import Template…", "ghost", self.template)
        v.addWidget(t, 0, Qt.AlignmentFlag.AlignLeft)
        v.addWidget(section_label("Disclaimer"))
        d = QLabel("This application is a compliance tracking and practice management tool. It does not file GST, "
                   "Income-tax, TDS or MCA returns. All statutory due dates and applicability rules are configurable and "
                   "must be verified against official notifications. Due date changes are recorded with source and "
                   "effective date.")
        d.setWordWrap(True)
        d.setObjectName("Muted")
        v.addWidget(d)
        v.addStretch(1)
        return w

    def load_demo(self):
        if not confirm(self, "Load random DEMO data into the current database?\n\nRecommended only for a demo / training copy."):
            return
        from app.database.seed_data import load_demo_data
        s = run_safely(self, load_demo_data)
        if s:
            info(self, "Demo data loaded:\n" + "\n".join(f"{k.title()}: {v}" for k, v in s.items()) +
                 "\n\nDemo staff password: Demo@1234")
            notify_changed("all")

    def gen_all(self):
        fy = settings_service.current_fy()
        n = run_safely(self, compliance_engine.generate_for_all, fy)
        if n is not None:
            settings_service.set("last_generated_fy", fy)
            info(self, f"{n} compliance record(s) generated for FY {fy}.")
            notify_changed("compliance")

    def template(self):
        from app.services.client_service import ENTITY_TYPES
        from app.utils.excel_utils import write_client_template
        from app.ui.widgets import save_file_dialog
        p = save_file_dialog(self, "Save Template", "Client_Import_Template.xlsx", "Excel (*.xlsx)")
        if p and run_safely(self, write_client_template, p, ENTITY_TYPES):
            info(self, f"Template saved:\n{p}")

    # ------------------------------------------------------------------ refresh
    def refresh(self):
        name = self.tabs.tabText(self.tabs.currentIndex())
        if name == "Compliance Master":
            self.masters.set_rows(compliance_engine.list_masters())
        elif name == "Users":
            self.users.set_rows(auth_service.list_users())
        elif name == "Backup & Restore":
            last = backup_service.last_backup()
            self.lbl_last.setText(f"Last successful backup: {last:%d-%m-%Y %H:%M}" if last else
                                  "⚠ No verified backup found - please take a backup now.")
            self.backups.set_rows(backup_service.list_backups())
        elif name == "Audit Trail":
            if auth_service.has_perm("audit.view"):
                from app.services.audit_service import list_audit
                self.audit.set_rows(list_audit())

    def apply_preset(self, **kw):
        tab = kw.get("tab")
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == tab:
                self.tabs.setCurrentIndex(i)
                break
