"""Main window: sidebar navigation, top bar, pages, startup workflow, reminders,
idle session lock and global record dispatcher."""
from __future__ import annotations

import importlib
from datetime import datetime
from typing import Optional

import config
from app.qt import *  # noqa: F401,F403
from app.services import (auth_service, backup_service, collection_service, compliance_engine,
                          reminder_engine, settings_service)
from app.ui.widgets import bus, button, confirm, error, info, notify_changed
from app.utils.date_utils import fmt_datetime, fy_choices
from app.utils.logger import get_logger

log = get_logger(__name__)

NAV = [
    ("dashboard", "📊  Dashboard", "app.ui.dashboard", "DashboardPage", None),
    ("clients", "👥  Clients", "app.ui.clients", "ClientsPage", None),
    ("calendar", "📅  Compliance Calendar", "app.ui.calendar", "CalendarPage", None),
    ("compliance", "✅  All Compliances", "app.ui.compliance", "CompliancePage", None),
    ("gst", "🧾  GST", "app.ui.gst", "GSTPage", None),
    ("it", "💼  Income Tax", "app.ui.income_tax", "IncomeTaxPage", None),
    ("tds", "🏦  TDS / TCS", "app.ui.tds", "TDSPage", None),
    ("roc", "🏛  ROC / MCA", "app.ui.roc", "ROCPage", None),
    ("notices", "📨  Notices", "app.ui.notices", "NoticesPage", None),
    ("tasks", "📝  Tasks", "app.ui.tasks", "TasksPage", None),
    ("documents", "📁  Documents", "app.ui.documents", "DocumentsPage", None),
    ("collection", "📋  Doc Collection", "app.ui.collection", "CollectionPage", None),
    ("reminders", "🔔  Reminders", "app.ui.reminders", "RemindersPage", None),
    ("billing", "💰  Billing", "app.ui.billing", "BillingPage", "billing.view"),
    ("reports", "📈  Reports", "app.ui.reports", "ReportsPage", "reports.view"),
    ("settings", "⚙  Settings", "app.ui.settings", "SettingsPage", None),
]


class _ReminderBridge(QObject):
    tick = Signal()


class _IdleFilter(QObject):
    def __init__(self, win):
        super().__init__(win)
        self.win = win

    def eventFilter(self, obj, ev):  # noqa: N802
        if ev.type() in (QEvent.Type.KeyPress, QEvent.Type.MouseButtonPress, QEvent.Type.MouseMove,
                         QEvent.Type.Wheel):
            self.win.last_activity = datetime.now()
        return False


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.user = auth_service.current_user() or {}
        self.logout_requested = False
        self.locked = False
        self.last_activity = datetime.now()
        self.pages: dict[str, QWidget] = {}
        self.keys: list[str] = []
        self.setWindowTitle(f"{config.APP_NAME}  —  {settings_service.firm_name()}")
        self.resize(1440, 880)
        self.setMinimumSize(1100, 680)

        central = QWidget()
        self.setCentralWidget(central)
        h = QHBoxLayout(central)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        h.addWidget(self._build_sidebar())
        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(0)
        right.addWidget(self._build_topbar())
        self.stack = QStackedWidget()
        right.addWidget(self.stack, 1)
        h.addLayout(right, 1)
        self._build_statusbar()
        self._shortcuts()

        bus().changed.connect(self._on_data_changed)
        self.nav.setCurrentRow(0)

        # idle lock
        self._idle = _IdleFilter(self)
        QApplication.instance().installEventFilter(self._idle)
        self.idle_timer = QTimer(self)
        self.idle_timer.timeout.connect(self._check_idle)

        # reminders: APScheduler (background) -> Qt signal -> UI thread
        self.bridge = _ReminderBridge()
        self.bridge.tick.connect(self.periodic_scan)
        self.scheduler = reminder_engine.ReminderScheduler()
        minutes = int(settings_service.get("reminder_scan_minutes") or 30)
        if not self.scheduler.start(self.bridge.tick.emit, minutes):
            self.scan_timer = QTimer(self)
            self.scan_timer.timeout.connect(self.periodic_scan)
            self.scan_timer.start(max(5, minutes) * 60_000)

        self.tray = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray = QSystemTrayIcon(QApplication.instance().windowIcon(), self)
            self.tray.setToolTip(config.APP_NAME)
            self.tray.activated.connect(lambda *_: (self.showNormal(), self.activateWindow()))
            self.tray.show()
        QTimer.singleShot(400, self.startup_checks)

    # ------------------------------------------------------------------ layout
    def _build_sidebar(self) -> QWidget:
        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(238)
        v = QVBoxLayout(side)
        v.setContentsMargins(0, 18, 0, 12)
        brand = QLabel("  ₹ ✓  " + settings_service.firm_name())
        brand.setObjectName("Brand")
        brand.setWordWrap(True)
        v.addWidget(brand)
        sub = QLabel("      CA Practice & Compliance Tracker")
        sub.setObjectName("BrandSub")
        v.addWidget(sub)
        v.addSpacing(14)
        self.nav = QListWidget()
        self.nav.setObjectName("Nav")
        self.nav.setCursor(Qt.CursorShape.PointingHandCursor)
        for key, label, _m, _c, perm in NAV:
            if perm and not auth_service.has_perm(perm):
                continue
            self.nav.addItem(QListWidgetItem(label))
            self.keys.append(key)
        self.nav.currentRowChanged.connect(self._nav_changed)
        v.addWidget(self.nav, 1)
        role = QLabel(f"   👤 {self.user.get('full_name', '')}\n      {self.user.get('role', '')}")
        role.setStyleSheet("color: #FBCFE8; font-size: 9pt;")
        v.addWidget(role)
        return side

    def _build_topbar(self) -> QWidget:
        top = QFrame()
        top.setObjectName("TopBar")
        top.setFixedHeight(62)
        h = QHBoxLayout(top)
        h.setContentsMargins(16, 8, 16, 8)
        self.search = QLineEdit()
        self.search.setObjectName("GlobalSearch")
        self.search.setPlaceholderText("🔍  Search client, PAN, GSTIN, TAN, CIN, notice no., DIN, task, document…  (Ctrl+F)")
        self.search.returnPressed.connect(self.global_search)
        h.addWidget(self.search, 2)
        h.addSpacing(10)
        h.addWidget(QLabel("FY"))
        self.fy = QComboBox()
        self.fy.addItems(fy_choices(settings_service.current_fy(), back=4, fwd=1))
        self.fy.setCurrentText(settings_service.current_fy())
        self.fy.currentTextChanged.connect(self._fy_changed)
        self.fy.setToolTip("Current financial year (April-March)")
        h.addWidget(self.fy)
        h.addStretch(1)
        self.btn_add_client = button("＋ Client", "pink", self.quick_add_client, "Quick add client (Ctrl+N)")
        self.btn_add_client.setEnabled(auth_service.has_perm("clients.edit"))
        h.addWidget(self.btn_add_client)
        h.addWidget(button("＋ Task", "", self.quick_add_task, "Quick add task (Ctrl+T)"))
        self.btn_bell = QToolButton()
        self.btn_bell.setText("🔔 0")
        self.btn_bell.setToolTip("Notifications / reminders")
        self.btn_bell.clicked.connect(self.show_notifications)
        h.addWidget(self.btn_bell)
        self.btn_user = QToolButton()
        self.btn_user.setText(f"👤 {self.user.get('full_name', '')} ▾")
        self.btn_user.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        m = QMenu(self.btn_user)
        m.addAction(f"Role: {self.user.get('role', '')}").setEnabled(False)
        m.addSeparator()
        m.addAction("About", self.about)
        self.btn_user.setMenu(m)
        h.addWidget(self.btn_user)
        return top

    def _build_statusbar(self) -> None:
        sb = QStatusBar()
        self.setStatusBar(sb)
        self.lbl_backup = QLabel("")
        sb.addPermanentWidget(self.lbl_backup)
        self.update_backup_label()

    def _shortcuts(self) -> None:
        def sc(seq, fn):
            s = QShortcut(QKeySequence(seq), self)
            s.activated.connect(fn)
        sc("Ctrl+F", lambda: (self.search.setFocus(), self.search.selectAll()))
        sc("Ctrl+N", self.quick_add_client)
        sc("Ctrl+T", self.quick_add_task)
        sc("F5", self.refresh_current)
        sc("Ctrl+B", lambda: self.navigate("settings", tab="Backup & Restore"))
        for i in range(min(9, len(self.keys))):
            sc(f"Ctrl+{i + 1}", lambda i=i: self.nav.setCurrentRow(i))

    # ------------------------------------------------------------------ navigation
    def page(self, key: str) -> QWidget:
        if key not in self.pages:
            for k, _label, mod, cls, _p in NAV:
                if k == key:
                    module = importlib.import_module(mod)
                    w = getattr(module, cls)(self)
                    self.pages[key] = w
                    self.stack.addWidget(w)
                    break
        return self.pages[key]

    def _nav_changed(self, row: int) -> None:
        if row < 0:
            return
        key = self.keys[row]
        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            w = self.page(key)
            self.stack.setCurrentWidget(w)
            w.refresh()
        except Exception as exc:  # noqa: BLE001
            log.exception("Page load failed")
            error(self, f"Could not open page: {exc}")
        finally:
            QApplication.restoreOverrideCursor()

    def navigate(self, key: str, **preset) -> None:
        if key not in self.keys:
            return
        self.nav.setCurrentRow(self.keys.index(key))
        if preset:
            self.page(key).apply_preset(**preset)

    def refresh_current(self) -> None:
        w = self.stack.currentWidget()
        if w is not None and hasattr(w, "refresh"):
            w.refresh()
        self.update_bell()

    def _on_data_changed(self, _what: str) -> None:
        self.refresh_current()
        for key, w in self.pages.items():
            if w is not self.stack.currentWidget():
                w.setProperty("dirty", True)

    def _fy_changed(self, fy: str) -> None:
        if not fy:
            return
        settings_service.set("current_fy", fy)
        if settings_service.get("last_generated_fy") != fy and auth_service.has_perm("compliance.review"):
            if confirm(self, f"Generate compliance records for all active clients for FY {fy}?\n"
                             "(Existing records are never duplicated.)"):
                n = compliance_engine.generate_for_all(fy)
                settings_service.set("last_generated_fy", fy)
                self.statusBar().showMessage(f"{n} compliance records generated for FY {fy}", 8000)
        notify_changed("fy")

    # ------------------------------------------------------------------ record dispatcher
    def open_record(self, kind: str, rid) -> None:
        """Open any record (used by dashboard, search, calendar, reminders)."""
        try:
            if kind == "client":
                from app.ui.clients import open_client_profile
                open_client_profile(self, rid)
            elif kind == "compliance":
                from app.ui.compliance import edit_compliance
                edit_compliance(self, rid)
            elif kind == "notice":
                from app.ui.notices import edit_notice
                edit_notice(self, rid)
            elif kind == "task":
                from app.ui.tasks import edit_task
                edit_task(self, rid)
            elif kind == "document":
                from app.ui.documents import preview_document
                preview_document(self, rid)
            elif kind == "collection":
                self.navigate("collection")
            elif kind == "invoice":
                from app.ui.billing import edit_invoice
                edit_invoice(self, rid)
        except Exception as exc:  # noqa: BLE001
            log.exception("open_record failed")
            error(self, str(exc))

    # ------------------------------------------------------------------ actions
    def quick_add_client(self) -> None:
        if not auth_service.has_perm("clients.edit"):
            return error(self, "You do not have permission to add clients.")
        from app.ui.clients import add_client
        add_client(self)

    def quick_add_task(self) -> None:
        from app.ui.tasks import edit_task
        edit_task(self, None)

    def global_search(self) -> None:
        text = self.search.text().strip()
        if len(text) < 2:
            self.statusBar().showMessage("Type at least 2 characters to search.", 4000)
            return
        from app.ui.search import GlobalSearchDialog
        GlobalSearchDialog(self, text).exec()

    def change_password(self) -> None:
        from app.ui.login import ChangePasswordDialog
        if ChangePasswordDialog(self).exec() == QDialog.DialogCode.Accepted:
            info(self, "Password changed successfully.")

    def about(self) -> None:
        info(self, f"<h3>{config.APP_NAME}</h3><p>Version {config.APP_VERSION}<br>"
                   f"Developed for <b>{settings_service.firm_name()}</b>, Chartered Accountants.</p>"
                   "<p>This is a compliance tracking and practice-management tool. It does not file returns "
                   "with GSTN / Income-tax / TRACES / MCA portals. Statutory due dates are user-configurable and "
                   "must be verified with the latest official notifications.</p>", "About")

    def lock_session(self) -> None:
        if self.locked:
            return
        self.locked = True
        from app.ui.login import LockDialog
        dlg = LockDialog(self)
        dlg.exec()
        self.locked = False
        self.last_activity = datetime.now()
        if dlg.logout_requested:
            self.logout(confirm_first=False)

    def _check_idle(self) -> None:
        return  # idle session lock disabled (no sign-in)

    def logout(self, confirm_first: bool = True) -> None:
        if confirm_first and not confirm(self, "Log out of the application?"):
            return
        self.logout_requested = True
        auth_service.logout()
        self.close()

    def closeEvent(self, e) -> None:  # noqa: N802
        try:
            self.scheduler.stop()
            QApplication.instance().removeEventFilter(self._idle)
            if self.tray:
                self.tray.hide()
        except Exception:
            pass
        if not self.logout_requested:
            auth_service.logout()
        super().closeEvent(e)

    # ------------------------------------------------------------------ startup / reminders
    def startup_checks(self) -> None:
        """Workflow 5 - daily startup checks."""
        try:
            fy = settings_service.current_fy()
            if settings_service.get("last_generated_fy") != fy:
                n = compliance_engine.generate_for_all(fy)
                settings_service.set("last_generated_fy", fy)
                log.info("Startup generation for FY %s: %s", fy, n)
            over = compliance_engine.refresh_overdue()
            collection_service.ensure_upcoming(int(settings_service.get("checklist_upcoming_days") or 45))
            reminder_engine.scan()
            self.statusBar().showMessage(f"Startup checks complete - {over} item(s) newly marked overdue.", 8000)
        except Exception as exc:  # noqa: BLE001
            log.exception("Startup checks failed")
            self.statusBar().showMessage(f"Startup checks error: {exc}", 10000)
        self.update_bell()
        self.refresh_current()
        active = reminder_engine.active_for_current_user()
        if active:
            self.notify_desktop(active)
            self.show_notifications()

    def periodic_scan(self) -> None:
        try:
            before = {r["id"] for r in reminder_engine.active_for_current_user()}
            reminder_engine.scan()
            new = [r for r in reminder_engine.active_for_current_user() if r["id"] not in before]
            if new:
                self.notify_desktop(new)
            self.update_bell()
        except Exception as exc:  # noqa: BLE001
            log.error("Periodic scan failed: %s", exc)

    def notify_desktop(self, rems: list[dict]) -> None:
        if not settings_service.get("desktop_notifications") or not self.tray:
            return
        overdue = sum(1 for r in rems if "OVERDUE" in (r["message"] or ""))
        text = f"You have {len(rems)} reminder(s)" + (f", {overdue} overdue" if overdue else "") + "."
        self.tray.showMessage(config.APP_NAME, text, QSystemTrayIcon.MessageIcon.Information, 8000)
        reminder_engine.log_displayed([r["id"] for r in rems[:200]], "Desktop")

    def update_bell(self) -> None:
        try:
            n = len(reminder_engine.active_for_current_user())
        except Exception:
            n = 0
        self.btn_bell.setText(f"🔔 {n}")
        self.btn_bell.setStyleSheet("QToolButton { color: white; background: #EC4899; border: none; }" if n else "")
        self.update_backup_label()

    def update_backup_label(self) -> None:
        last = backup_service.last_backup()
        if last:
            age = (datetime.now() - last).days
            self.lbl_backup.setText(f"💾 Last successful backup: {fmt_datetime(last)}")
            self.lbl_backup.setObjectName("BackupOk" if age < 2 else "BackupWarn")
        else:
            self.lbl_backup.setText("💾 No verified backup yet - take a backup in Settings › Backup & Restore")
            self.lbl_backup.setObjectName("BackupWarn")
        self.lbl_backup.setStyleSheet(self.lbl_backup.styleSheet())
        self.lbl_backup.style().unpolish(self.lbl_backup)
        self.lbl_backup.style().polish(self.lbl_backup)

    def show_notifications(self) -> None:
        from app.ui.reminders import NotificationsDialog
        NotificationsDialog(self).exec()
        self.update_bell()
