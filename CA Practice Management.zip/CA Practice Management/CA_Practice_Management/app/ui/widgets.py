"""Reusable UI components: data table (search/filter/sort/paginate/export), form
dialog framework, date field, KPI card, bar chart, message helpers."""
from __future__ import annotations

import os
from dataclasses import dataclass, field as dc_field
from datetime import date, datetime
from typing import Any, Callable, Optional

import config
from app.qt import *  # noqa: F401,F403
from app.qt import print_document
from app.ui.styles import KPI_GRADIENTS, STATUS_COLORS, STATUS_TINTS
from app.utils.date_utils import fmt_date, fmt_datetime, parse_date, qt_date_format
from app.utils.formatters import inr
from app.utils.logger import get_logger

log = get_logger(__name__)


# ================================================================== event bus
class _Bus(QObject):
    changed = Signal(str)


_bus: Optional[_Bus] = None


def bus() -> _Bus:
    global _bus
    if _bus is None:
        _bus = _Bus()
    return _bus


def notify_changed(what: str = "all") -> None:
    bus().changed.emit(what)


# ================================================================== messages
def confirm(parent, text: str, title: str = "Please Confirm") -> bool:
    return QMessageBox.question(parent, title, text, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes


def info(parent, text: str, title: str = "Information") -> None:
    QMessageBox.information(parent, title, text)


def error(parent, text: str, title: str = "Error") -> None:
    QMessageBox.critical(parent, title, str(text))


def warn(parent, text: str, title: str = "Warning") -> None:
    QMessageBox.warning(parent, title, text)


def ask_text(parent, title: str, label: str, default: str = "", multiline: bool = False) -> Optional[str]:
    if multiline:
        txt, ok = QInputDialog.getMultiLineText(parent, title, label, default)
    else:
        txt, ok = QInputDialog.getText(parent, title, label, QLineEdit.EchoMode.Normal, default)
    return txt if ok else None


def run_safely(parent, fn: Callable, *args, success: Optional[str] = None, **kwargs):
    """Execute fn, showing a clear error dialog on failure. Returns result or None."""
    try:
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = fn(*args, **kwargs)
        finally:
            QApplication.restoreOverrideCursor()
        if success:
            info(parent, success)
        return res
    except Exception as exc:  # noqa: BLE001
        log.exception("Operation failed")
        error(parent, str(exc))
        return None


def button(text: str, kind: str = "", slot: Optional[Callable] = None, tip: str = "") -> QPushButton:
    b = QPushButton(text)
    if kind:
        b.setProperty("kind", kind)
    if slot:
        b.clicked.connect(lambda _=False: slot())
    if tip:
        b.setToolTip(tip)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b


def section_label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("SectionTitle")
    return lbl


def save_file_dialog(parent, title: str, default_name: str, filters: str) -> Optional[str]:
    os.makedirs(config.EXPORT_DIR, exist_ok=True)
    path, _ = QFileDialog.getSaveFileName(parent, title, os.path.join(config.EXPORT_DIR, default_name), filters)
    return path or None


def open_file_dialog(parent, title: str, filters: str = "All files (*.*)") -> Optional[str]:
    path, _ = QFileDialog.getOpenFileName(parent, title, "", filters)
    return path or None


def to_qdate(d: date) -> QDate:
    return QDate(d.year, d.month, d.day)


def from_qdate(q: QDate) -> date:
    return date(q.year(), q.month(), q.day())


# ================================================================== inputs
class DateField(QWidget):
    """Date picker with optional 'blank' state (checkbox)."""
    changed = Signal()

    def __init__(self, parent=None, allow_blank: bool = True, value: Optional[date] = None):
        super().__init__(parent)
        self.allow_blank = allow_blank
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        self.chk = QCheckBox()
        self.chk.setToolTip("Tick to set a date")
        self.edit = QDateEdit()
        self.edit.setCalendarPopup(True)
        self.edit.setDisplayFormat(qt_date_format())
        self.edit.setDate(QDate.currentDate())
        self.edit.setMinimumWidth(120)
        if allow_blank:
            lay.addWidget(self.chk)
            self.chk.toggled.connect(self.edit.setEnabled)
            self.chk.toggled.connect(lambda _: self.changed.emit())
            self.edit.setEnabled(False)
        lay.addWidget(self.edit, 1)
        self.edit.dateChanged.connect(lambda _: self.changed.emit())
        self.setValue(value)

    def value(self) -> Optional[date]:
        if self.allow_blank and not self.chk.isChecked():
            return None
        return from_qdate(self.edit.date())

    def setValue(self, v: Any) -> None:
        d = parse_date(v)
        if d:
            self.chk.setChecked(True)
            self.edit.setEnabled(True)
            self.edit.setDate(to_qdate(d))
        elif self.allow_blank:
            self.chk.setChecked(False)
            self.edit.setEnabled(False)


class SearchCombo(QComboBox):
    """Searchable combo box (type to filter, contains-match)."""

    def __init__(self, items: list[tuple[str, Any]] | None = None, blank: str = "", parent=None):
        super().__init__(parent)
        self.setEditable(True)
        self.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        comp = self.completer()
        comp.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        comp.setFilterMode(Qt.MatchFlag.MatchContains)
        comp.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.blank = blank
        self.set_items(items or [])

    def set_items(self, items: list[tuple[str, Any]]) -> None:
        cur = self.value()
        self.blockSignals(True)
        self.clear()
        self.addItem(self.blank, None)
        for text, data in items:
            self.addItem(text, data)
        self.blockSignals(False)
        self.setValue(cur)

    def value(self) -> Any:
        idx = self.findText(self.currentText(), Qt.MatchFlag.MatchExactly)
        return self.itemData(idx) if idx >= 0 else None

    def setValue(self, v: Any) -> None:
        idx = self.findData(v) if v is not None else 0
        self.setCurrentIndex(idx if idx >= 0 else 0)


@dataclass
class Field:
    key: str
    label: str
    kind: str = "text"          # text|password|multiline|int|money|float|date|combo|ecombo|user|client|bool|file|label
    options: Any = None
    required: bool = False
    default: Any = None
    readonly: bool = False
    placeholder: str = ""
    validator: Optional[Callable[[Any], Optional[str]]] = None
    tooltip: str = ""
    upper: bool = False
    extra: dict = dc_field(default_factory=dict)


def _choices(kind: str):
    if kind == "user":
        from app.services.auth_service import user_choices
        return user_choices()
    if kind == "client":
        from app.services.client_service import client_choices
        return client_choices()
    return []


class FormDialog(QDialog):
    """Generic tabbed form. Errors are shown inline (no popup storms)."""

    def __init__(self, parent, title: str, tabs: list[tuple[str, list[Field]]], values: Optional[dict] = None,
                 on_validate: Optional[Callable[[dict], list[str] | str | None]] = None,
                 extra_tabs: Optional[list[tuple[str, QWidget]]] = None, width: int = 760,
                 save_text: str = "💾  Save"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(width)
        self.on_validate = on_validate
        self.widgets: dict[str, tuple[Field, QWidget]] = {}
        self.values: dict = {}
        root = QVBoxLayout(self)
        head = QLabel(title)
        head.setObjectName("PageTitle")
        head.setStyleSheet("font-size: 14pt;")
        root.addWidget(head)
        container: QWidget
        if len(tabs) > 1 or extra_tabs:
            self.tabs = QTabWidget()
            for name, fields in tabs:
                self.tabs.addTab(self._build(fields), name)
            for name, w in extra_tabs or []:
                self.tabs.addTab(w, name)
            container = self.tabs
        else:
            self.tabs = None
            container = self._build(tabs[0][1])
        root.addWidget(container, 1)
        self.err = QLabel("")
        self.err.setObjectName("ErrorLabel")
        self.err.setWordWrap(True)
        root.addWidget(self.err)
        bb = QHBoxLayout()
        bb.addStretch(1)
        self.btn_cancel = button("Cancel", "ghost", self.reject)
        self.btn_save = button(save_text, "", self._accept)
        self.btn_save.setDefault(True)
        bb.addWidget(self.btn_cancel)
        bb.addWidget(self.btn_save)
        root.addLayout(bb)
        if values:
            self.set_values(values)
        else:
            self.set_values({f.key: f.default for _, fs in tabs for f in fs if f.default is not None})

    def _build(self, fields: list[Field]) -> QWidget:
        w = QWidget()
        form = QFormLayout(w)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(8)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(w)
        for f in fields:
            widget = self._make(f)
            if f.tooltip:
                widget.setToolTip(f.tooltip)
            label = f.label + (" *" if f.required else "")
            form.addRow(label, widget)
            self.widgets[f.key] = (f, widget)
        return scroll

    def _make(self, f: Field) -> QWidget:
        k = f.kind
        if k in ("text", "password"):
            w = QLineEdit()
            w.setPlaceholderText(f.placeholder)
            if k == "password":
                w.setEchoMode(QLineEdit.EchoMode.Password)
            w.setReadOnly(f.readonly)
            return w
        if k == "multiline":
            w = QPlainTextEdit()
            w.setMaximumHeight(f.extra.get("height", 80))
            w.setReadOnly(f.readonly)
            return w
        if k == "int":
            w = QSpinBox()
            lo, hi = f.options or (0, 1_000_000)
            w.setRange(lo, hi)
            return w
        if k in ("money", "float"):
            w = QDoubleSpinBox()
            w.setRange(0, 1e12)
            w.setDecimals(2)
            w.setGroupSeparatorShown(True)
            if k == "money":
                w.setPrefix("₹ ")
            return w
        if k == "date":
            return DateField(allow_blank=not f.required)
        if k in ("combo", "ecombo"):
            w = QComboBox()
            w.setEditable(k == "ecombo")
            for o in f.options or []:
                if isinstance(o, tuple):
                    w.addItem(o[0], o[1])
                else:
                    w.addItem(str(o), o)
            return w
        if k in ("user", "client"):
            w = SearchCombo(f.options if f.options is not None else _choices(k))
            w.setEnabled(not f.readonly)
            return w
        if k == "bool":
            return QCheckBox()
        if k == "file":
            box = QWidget()
            h = QHBoxLayout(box)
            h.setContentsMargins(0, 0, 0, 0)
            le = QLineEdit()
            le.setPlaceholderText(f.placeholder or "Select a file (optional)")
            b = button("Browse…", "ghost")
            b.clicked.connect(lambda: self._browse(le, f))
            h.addWidget(le, 1)
            h.addWidget(b)
            box.line = le  # type: ignore[attr-defined]
            return box
        if k == "label":
            lbl = QLabel("")
            lbl.setObjectName("Muted")
            lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            return lbl
        return QLineEdit()

    def _browse(self, le: QLineEdit, f: Field) -> None:
        p = open_file_dialog(self, f"Select {f.label}", f.extra.get("filter", "Documents (*.pdf *.xlsx *.xls *.csv *.doc *.docx *.jpg *.jpeg *.png *.txt *.zip);;All files (*.*)"))
        if p:
            le.setText(p)

    def widget(self, key: str) -> QWidget:
        return self.widgets[key][1]

    def get_value(self, key: str) -> Any:
        f, w = self.widgets[key]
        k = f.kind
        if k in ("text", "password"):
            v = w.text().strip()
            return (v.upper() if f.upper else v) or None
        if k == "multiline":
            return w.toPlainText().strip() or None
        if k == "int":
            return w.value()
        if k in ("money", "float"):
            return float(w.value())
        if k == "date":
            return w.value()
        if k == "combo":
            return w.currentData() if w.currentData() is not None else w.currentText()
        if k == "ecombo":
            return w.currentText().strip() or None
        if k in ("user", "client"):
            return w.value()
        if k == "bool":
            return w.isChecked()
        if k == "file":
            return w.line.text().strip() or None
        if k == "label":
            return None
        return None

    def get_values(self) -> dict:
        return {k: self.get_value(k) for k in self.widgets if self.widgets[k][0].kind != "label"}

    def set_value(self, key: str, v: Any) -> None:
        if key not in self.widgets:
            return
        f, w = self.widgets[key]
        k = f.kind
        if k in ("text", "password"):
            w.setText("" if v is None else str(v))
        elif k == "multiline":
            w.setPlainText("" if v is None else str(v))
        elif k == "int":
            w.setValue(int(v or 0))
        elif k in ("money", "float"):
            w.setValue(float(v or 0))
        elif k == "date":
            w.setValue(v)
        elif k in ("combo", "ecombo"):
            idx = w.findData(v)
            if idx < 0:
                idx = w.findText("" if v is None else str(v))
            if idx >= 0:
                w.setCurrentIndex(idx)
            elif k == "ecombo" and v:
                w.setEditText(str(v))
        elif k in ("user", "client"):
            w.setValue(v)
        elif k == "bool":
            w.setChecked(bool(v))
        elif k == "file":
            w.line.setText(v or "")
        elif k == "label":
            if isinstance(v, (date, datetime)):
                v = fmt_datetime(v) if isinstance(v, datetime) else fmt_date(v)
            w.setText("" if v is None else str(v))

    def set_values(self, values: dict) -> None:
        for k, v in (values or {}).items():
            self.set_value(k, v)

    def _accept(self) -> None:
        vals = self.get_values()
        errors = []
        for key, (f, _w) in self.widgets.items():
            if f.kind == "label":
                continue
            v = vals.get(key)
            if f.required and (v is None or v == "" or (f.kind in ("money",) and v == 0 and f.extra.get("nonzero"))):
                errors.append(f"{f.label} is required.")
            elif f.validator and v not in (None, ""):
                e = f.validator(v)
                if e:
                    errors.append(e)
        if not errors and self.on_validate:
            res = self.on_validate(vals)
            if isinstance(res, str) and res:
                errors.append(res)
            elif isinstance(res, list):
                errors.extend(res)
        if errors:
            self.err.setText("⚠ " + "\n⚠ ".join(errors))
            return
        self.values = vals
        self.accept()


# ================================================================== data table
STATUS_KEYS = {"status", "received", "progress_text", "verified_text"}


class DataTable(QWidget):
    """Table with search, column filters, saved filters, sort, pagination, export & print."""
    activated = Signal(object)
    selectionChanged = Signal()

    def __init__(self, columns: list[tuple[str, str]], parent=None, table_key: Optional[str] = None,
                 filters: Optional[list[str]] = None, money: Optional[list[str]] = None, page_size: int = 200,
                 export_title: str = "Report", show_toolbar: bool = True, compact: bool = False):
        super().__init__(parent)
        self.columns = list(columns)
        self.table_key = table_key
        self.filter_keys = list(filters or [])
        self.money = set(money or [])
        self.export_title = export_title
        self._all: list[dict] = []
        self._view: list[dict] = []
        self._page = 0
        self._page_size = page_size
        self._sort_key: Optional[str] = None
        self._sort_desc = False
        self._actions: list = []
        self.extra_filter: Optional[Callable[[dict], bool]] = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self.toolbar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("🔍  Search…")
        self.search.setClearButtonEnabled(True)
        self.search.setMinimumWidth(200)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self.reapply)
        self.search.textChanged.connect(lambda _: self._timer.start())
        self.toolbar.addWidget(self.search)
        titles = dict(self.columns)
        self.filter_combos: dict[str, QComboBox] = {}
        for key in self.filter_keys:
            cb = QComboBox()
            cb.setMinimumWidth(120)
            cb.addItem(f"All {titles.get(key, key)}", None)
            cb.currentIndexChanged.connect(lambda _=0: self.reapply())
            self.filter_combos[key] = cb
            self.toolbar.addWidget(cb)
        self.toolbar.addStretch(1)
        if table_key:
            self.saved = QComboBox()
            self.saved.setMinimumWidth(130)
            self.saved.setToolTip("Saved filters")
            self.saved.activated.connect(self._load_saved)
            self.toolbar.addWidget(self.saved)
            sb = QToolButton()
            sb.setText("☆ Save filter")
            sb.clicked.connect(self._save_filter)
            self.toolbar.addWidget(sb)
            self._refresh_saved()
        self.btn_export = QToolButton()
        self.btn_export.setText("⬇ Export / Print")
        self.btn_export.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        m = QMenu(self.btn_export)
        m.addAction("Excel (.xlsx)", lambda: self.export("xlsx"))
        m.addAction("CSV (.csv)", lambda: self.export("csv"))
        m.addAction("PDF (.pdf)", lambda: self.export("pdf"))
        m.addSeparator()
        m.addAction("Print…", self.print_table)
        self.btn_export.setMenu(m)
        self.toolbar.addWidget(self.btn_export)
        if show_toolbar:
            lay.addLayout(self.toolbar)
        else:
            for i in range(self.toolbar.count()):
                w = self.toolbar.itemAt(i).widget()
                if w:
                    w.hide()

        self.table = QTableWidget()
        self.table.setColumnCount(len(self.columns))
        self.table.setHorizontalHeaderLabels([t for _, t in self.columns])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(26 if compact else 30)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hh.setStretchLastSection(True)
        hh.setSectionsClickable(True)
        hh.sectionClicked.connect(self._sort_by)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.cellDoubleClicked.connect(lambda r, c: self._emit_activated(r))
        self.table.itemSelectionChanged.connect(self.selectionChanged.emit)
        lay.addWidget(self.table, 1)

        foot = QHBoxLayout()
        self.lbl_count = QLabel("")
        self.lbl_count.setObjectName("Muted")
        foot.addWidget(self.lbl_count)
        foot.addStretch(1)
        foot.addWidget(QLabel("Rows/page"))
        self.cb_page = QComboBox()
        for n in (50, 100, 200, 500, 0):
            self.cb_page.addItem("All" if n == 0 else str(n), n)
        self.cb_page.setCurrentIndex(max(0, self.cb_page.findData(page_size)))
        self.cb_page.currentIndexChanged.connect(self._page_size_changed)
        foot.addWidget(self.cb_page)
        self.btn_prev = QToolButton()
        self.btn_prev.setText("◀")
        self.btn_prev.clicked.connect(lambda: self._goto(self._page - 1))
        self.lbl_page = QLabel("")
        self.btn_next = QToolButton()
        self.btn_next.setText("▶")
        self.btn_next.clicked.connect(lambda: self._goto(self._page + 1))
        foot.addWidget(self.btn_prev)
        foot.addWidget(self.lbl_page)
        foot.addWidget(self.btn_next)
        lay.addLayout(foot)
        sc = QShortcut(QKeySequence("Return"), self.table)
        sc.setContext(Qt.ShortcutContext.WidgetShortcut)
        sc.activated.connect(lambda: self._emit_activated(self.table.currentRow()))

    # ---------------------------------------------------------- data
    def set_rows(self, rows: list[dict]) -> None:
        self._all = rows or []
        for key, cb in self.filter_combos.items():
            cur = cb.currentData()
            vals = sorted({str(r.get(key)) for r in self._all if r.get(key) not in (None, "")})
            cb.blockSignals(True)
            first = cb.itemText(0)
            cb.clear()
            cb.addItem(first, None)
            for v in vals:
                cb.addItem(v, v)
            idx = cb.findData(cur) if cur is not None else 0
            cb.setCurrentIndex(idx if idx >= 0 else 0)
            cb.blockSignals(False)
        self.reapply(keep_page=True)

    def rows(self) -> list[dict]:
        return self._all

    def filtered_rows(self) -> list[dict]:
        return self._view

    def fmt(self, key: str, v: Any) -> str:
        if v is None:
            return ""
        if isinstance(v, bool):
            return "Yes" if v else "No"
        if isinstance(v, datetime):
            return fmt_datetime(v)
        if isinstance(v, date):
            return fmt_date(v)
        if key in self.money and isinstance(v, (int, float)):
            return inr(v)
        if isinstance(v, float):
            return f"{v:,.2f}"
        return str(v)

    def reapply(self, keep_page: bool = False) -> None:
        terms = self.search.text().strip().lower().split()
        out = []
        for r in self._all:
            ok = True
            for key, cb in self.filter_combos.items():
                val = cb.currentData()
                if val is not None and str(r.get(key) if r.get(key) is not None else "") != val:
                    ok = False
                    break
            if not ok:
                continue
            if self.extra_filter and not self.extra_filter(r):
                continue
            if terms:
                hay = r.get("_hay")
                if hay is None:
                    hay = (" ".join(self.fmt(k, r.get(k)) for k, _ in self.columns) + " " +
                           str(r.get("_search", ""))).lower()
                    r["_hay"] = hay
                if not all(t in hay for t in terms):
                    continue
            out.append(r)
        if self._sort_key:
            k = self._sort_key

            def sk(row):
                v = row.get(k)
                if v is None or v == "":
                    return (1, 0, "")
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    return (0, 0, v)
                if isinstance(v, datetime):
                    return (0, 1, v.isoformat())
                if isinstance(v, date):
                    return (0, 1, v.isoformat())
                return (0, 2, str(v).lower())
            try:
                out.sort(key=sk, reverse=self._sort_desc)
            except TypeError:
                out.sort(key=lambda row: str(row.get(k)), reverse=self._sort_desc)
        self._view = out
        if not keep_page:
            self._page = 0
        self._render()

    def _page_size_changed(self) -> None:
        self._page_size = self.cb_page.currentData()
        self._page = 0
        self._render()

    def _goto(self, p: int) -> None:
        self._page = p
        self._render()

    def _render(self) -> None:
        n = len(self._view)
        ps = self._page_size or max(1, n)
        pages = max(1, (n + ps - 1) // ps)
        self._page = max(0, min(self._page, pages - 1))
        rows = self._view[self._page * ps: (self._page + 1) * ps]
        self.table.setUpdatesEnabled(False)
        self.table.clearContents()
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            color = r.get("_color")
            cells = r.get("_cell_colors") or {}
            for c, (key, _t) in enumerate(self.columns):
                v = r.get(key)
                it = QTableWidgetItem(self.fmt(key, v))
                if c == 0:
                    it.setData(Qt.ItemDataRole.UserRole, r.get("_id"))
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    it.setTextAlignment(int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter))
                ck = cells.get(key)
                if ck:
                    it.setBackground(QColor(STATUS_TINTS.get(ck, "#FFFFFF")))
                    it.setForeground(QColor(STATUS_COLORS.get(ck, "#111827")))
                    f = it.font()
                    f.setBold(True)
                    it.setFont(f)
                elif color:
                    it.setBackground(QColor(STATUS_TINTS.get(color, "#FFFFFF")))
                    it.setForeground(QColor("#111827"))
                    if key in STATUS_KEYS:
                        it.setForeground(QColor(STATUS_COLORS.get(color, "#111827")))
                        f = it.font()
                        f.setBold(True)
                        it.setFont(f)
                self.table.setItem(i, c, it)
        self.table.setUpdatesEnabled(True)
        if rows and not getattr(self, "_sized", False):
            self.table.resizeColumnsToContents()
            for c in range(self.table.columnCount()):
                if self.table.columnWidth(c) > 320:
                    self.table.setColumnWidth(c, 320)
            self._sized = True
        self.lbl_count.setText(f"{n} record(s)" + (f"  (of {len(self._all)})" if n != len(self._all) else ""))
        self.lbl_page.setText(f" Page {self._page + 1} / {pages} ")
        self.btn_prev.setEnabled(self._page > 0)
        self.btn_next.setEnabled(self._page < pages - 1)

    def _sort_by(self, col: int) -> None:
        key = self.columns[col][0]
        if self._sort_key == key:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_key, self._sort_desc = key, False
        self.table.horizontalHeader().setSortIndicatorShown(True)
        self.table.horizontalHeader().setSortIndicator(
            col, Qt.SortOrder.DescendingOrder if self._sort_desc else Qt.SortOrder.AscendingOrder)
        self.reapply(keep_page=True)

    # ---------------------------------------------------------- selection
    def _row_id(self, row: int):
        it = self.table.item(row, 0)
        return it.data(Qt.ItemDataRole.UserRole) if it else None

    def _emit_activated(self, row: int) -> None:
        if row is not None and row >= 0:
            rid = self._row_id(row)
            if rid is not None:
                self.activated.emit(rid)

    def selected_ids(self) -> list:
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [rid for rid in (self._row_id(r) for r in rows) if rid is not None]

    def current_id(self):
        ids = self.selected_ids()
        return ids[0] if ids else None

    def selected_rows(self) -> list[dict]:
        ids = set(self.selected_ids())
        return [r for r in self._view if r.get("_id") in ids]

    def current_row(self) -> Optional[dict]:
        rows = self.selected_rows()
        return rows[0] if rows else None

    # ---------------------------------------------------------- context menu
    def add_action(self, label: Optional[str], callback: Optional[Callable] = None) -> None:
        self._actions.append((label, callback))

    def _context_menu(self, pos) -> None:
        m = QMenu(self)
        for label, cb in self._actions:
            if label is None:
                m.addSeparator()
            else:
                m.addAction(label, cb)
        if self._actions:
            m.addSeparator()
        it = self.table.itemAt(pos)
        if it:
            m.addAction("Copy cell", lambda: QApplication.clipboard().setText(it.text()))
        m.addAction("Export to Excel", lambda: self.export("xlsx"))
        m.addAction("Print…", self.print_table)
        m.exec(self.table.viewport().mapToGlobal(pos))

    # ---------------------------------------------------------- filters
    def get_state(self) -> dict:
        return {"search": self.search.text(), "filters": {k: cb.currentData() for k, cb in self.filter_combos.items()}}

    def set_state(self, st: dict) -> None:
        self.search.setText(st.get("search", ""))
        for k, v in (st.get("filters") or {}).items():
            cb = self.filter_combos.get(k)
            if cb is not None:
                idx = cb.findData(v) if v is not None else 0
                cb.setCurrentIndex(idx if idx >= 0 else 0)
        self.reapply()

    def set_filter(self, key: str, value: Optional[str]) -> None:
        cb = self.filter_combos.get(key)
        if cb is not None:
            idx = cb.findData(value) if value is not None else 0
            cb.setCurrentIndex(idx if idx >= 0 else 0)

    def _refresh_saved(self) -> None:
        from app.services import settings_service
        allf = settings_service.get("saved_filters") or {}
        mine = allf.get(self.table_key, {})
        self.saved.blockSignals(True)
        self.saved.clear()
        self.saved.addItem("Saved filters…", None)
        for name in sorted(mine):
            self.saved.addItem(name, name)
        if mine:
            self.saved.addItem("✖ Delete a saved filter…", "__delete__")
        self.saved.blockSignals(False)

    def _save_filter(self) -> None:
        name = ask_text(self, "Save Filter", "Name for this filter:")
        if not name:
            return
        from app.services import settings_service
        allf = dict(settings_service.get("saved_filters") or {})
        mine = dict(allf.get(self.table_key, {}))
        mine[name.strip()] = self.get_state()
        allf[self.table_key] = mine
        settings_service.set("saved_filters", allf)
        self._refresh_saved()

    def _load_saved(self) -> None:
        name = self.saved.currentData()
        from app.services import settings_service
        allf = dict(settings_service.get("saved_filters") or {})
        mine = dict(allf.get(self.table_key, {}))
        if name == "__delete__":
            if mine:
                item, ok = QInputDialog.getItem(self, "Delete Saved Filter", "Filter:", sorted(mine), 0, False)
                if ok and item:
                    mine.pop(item, None)
                    allf[self.table_key] = mine
                    settings_service.set("saved_filters", allf)
            self._refresh_saved()
            return
        if name and name in mine:
            self.set_state(mine[name])

    # ---------------------------------------------------------- export / print
    def export(self, fmt: str) -> None:
        from app.services import settings_service
        from app.utils.excel_utils import export_rows
        from app.utils.pdf_utils import export_table_pdf
        safe = "".join(ch if ch.isalnum() else "_" for ch in self.export_title)
        default = f"{safe}_{date.today():%Y%m%d}.{fmt}"
        filt = {"xlsx": "Excel (*.xlsx)", "csv": "CSV (*.csv)", "pdf": "PDF (*.pdf)"}[fmt]
        path = save_file_dialog(self, "Export", default, filt)
        if not path:
            return
        if not path.lower().endswith("." + fmt):
            path += "." + fmt
        try:
            if fmt == "pdf":
                export_table_pdf(path, self.export_title, self.columns, self._view,
                                 firm=settings_service.firm_name(), money=self.money)
            else:
                export_rows(path, self.columns, self._view, title=self.export_title,
                            firm=settings_service.firm_name())
        except Exception as exc:  # noqa: BLE001
            error(self, f"Export failed: {exc}")
            return
        if confirm(self, f"Exported {len(self._view)} record(s) to:\n{path}\n\nOpen the file now?", "Export Complete"):
            try:
                from app.services.document_service import open_path
                open_path(path)
            except Exception as exc:  # noqa: BLE001
                error(self, str(exc))

    def to_html(self) -> str:
        from html import escape
        from app.services import settings_service
        head = "".join(f"<th>{escape(t)}</th>" for _, t in self.columns)
        body = "".join("<tr>" + "".join(f"<td>{escape(self.fmt(k, r.get(k)))}</td>" for k, _ in self.columns) + "</tr>"
                       for r in self._view)
        return (f"<h2 style='color:#5B21B6'>{escape(settings_service.firm_name())}</h2>"
                f"<h3 style='color:#1E40AF'>{escape(self.export_title)}</h3>"
                f"<p style='color:#6B7280'>Printed on {fmt_datetime(datetime.now())} - {len(self._view)} record(s)</p>"
                f"<table border='1' cellspacing='0' cellpadding='3' style='font-size:8pt;border-collapse:collapse'>"
                f"<tr style='background:#EDE9FE'>{head}</tr>{body}</table>")

    def print_table(self) -> None:
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        try:
            printer.setPageOrientation(QPageLayout.Orientation.Landscape)
        except Exception:
            pass
        dlg = QPrintDialog(printer, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            doc = QTextDocument()
            doc.setHtml(self.to_html())
            print_document(doc, printer)


# ================================================================== cards & charts
class KpiCard(QFrame):
    clicked = Signal(str)

    def __init__(self, key: str, title: str, icon: str = "", idx: int = 0, parent=None):
        super().__init__(parent)
        self.key = key
        self.setObjectName("KpiCard")
        a, b = KPI_GRADIENTS[idx % len(KPI_GRADIENTS)]
        self.setStyleSheet(f"QFrame#KpiCard {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {a}, stop:1 {b}); "
                           f"border-radius: 16px; }} QFrame#KpiCard QLabel {{ color: white; background: transparent; }}")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(92)
        self.setToolTip("Click to open the detailed list")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        top = QHBoxLayout()
        t = QLabel(title)
        t.setStyleSheet("font-size: 9.5pt; font-weight: 600;")
        t.setWordWrap(True)
        ic = QLabel(icon)
        ic.setStyleSheet("font-size: 16pt;")
        top.addWidget(t, 1)
        top.addWidget(ic)
        lay.addLayout(top)
        self.value = QLabel("–")
        self.value.setStyleSheet("font-size: 22pt; font-weight: 800;")
        lay.addWidget(self.value)
        eff = QGraphicsDropShadowEffect(self)
        eff.setBlurRadius(18)
        eff.setOffset(0, 4)
        eff.setColor(QColor(124, 58, 237, 90))
        self.setGraphicsEffect(eff)

    def set_value(self, v: Any) -> None:
        self.value.setText(str(v))

    def mousePressEvent(self, e) -> None:  # noqa: N802
        self.clicked.emit(self.key)
        super().mousePressEvent(e)


class BarChart(QWidget):
    """Lightweight grouped bar chart drawn with QPainter (no extra dependency)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.labels: list[str] = []
        self.series: list[tuple[str, list[float], str]] = []
        self.setMinimumHeight(230)

    def set_data(self, labels: list[str], series: list[tuple[str, list[float], str]]) -> None:
        self.labels, self.series = labels, series
        self.update()

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        left, right, top, bottom = 40, 12, 26, 30
        cw, ch = max(10, w - left - right), max(10, h - top - bottom)
        maxv = max([max(s[1]) if s[1] else 0 for s in self.series] + [1])
        p.setPen(QColor("#C4B5FD"))
        for i in range(5):
            y = top + ch - ch * i / 4
            p.drawLine(left, int(y), left + cw, int(y))
            p.setPen(QColor("#6B7280"))
            p.drawText(2, int(y) + 4, f"{maxv * i / 4:.0f}")
            p.setPen(QColor("#E9D5FF"))
        n = max(1, len(self.labels))
        group_w = cw / n
        ns = max(1, len(self.series))
        bar_w = max(3, group_w * 0.7 / ns)
        for gi, lab in enumerate(self.labels):
            gx = left + gi * group_w + group_w * 0.15
            for si, (_name, vals, color) in enumerate(self.series):
                v = vals[gi] if gi < len(vals) else 0
                bh = ch * v / maxv
                rect = QRectF(gx + si * bar_w, top + ch - bh, bar_w - 2, bh)
                grad = QLinearGradient(rect.topLeft(), rect.bottomLeft())
                grad.setColorAt(0, QColor(color))
                grad.setColorAt(1, QColor(color).lighter(150))
                p.setBrush(QBrush(grad))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawRoundedRect(rect, 3, 3)
            p.setPen(QColor("#4C1D95"))
            p.drawText(QRectF(left + gi * group_w, top + ch + 4, group_w, 18), int(Qt.AlignmentFlag.AlignCenter), lab)
        lx = left
        for name, _vals, color in self.series:
            p.setBrush(QColor(color))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(QRectF(lx, 6, 12, 12), 3, 3)
            p.setPen(QColor("#374151"))
            p.drawText(int(lx + 16), 17, name)
            lx += 30 + len(name) * 7
        p.end()


class DrillDownDialog(QDialog):
    def __init__(self, parent, title: str, columns: list, rows: list, on_open: Optional[Callable] = None,
                 money: Optional[list] = None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1100, 600)
        lay = QVBoxLayout(self)
        t = QLabel(title)
        t.setObjectName("PageTitle")
        t.setStyleSheet("font-size: 14pt;")
        lay.addWidget(t)
        self.table = DataTable(columns, self, export_title=title, money=money)
        self.table.set_rows(rows)
        if on_open:
            self.table.activated.connect(on_open)
            hint = QLabel("Double-click a row to open the record.")
            hint.setObjectName("Muted")
            lay.addWidget(hint)
        lay.addWidget(self.table, 1)
        lay.addWidget(button("Close", "ghost", self.accept), 0, Qt.AlignmentFlag.AlignRight)


class BasePage(QWidget):
    """Base for every main page: title, breadcrumb, refresh() contract."""

    def __init__(self, main, title: str, crumb: str = ""):
        super().__init__()
        self.main = main
        self.setObjectName("Page")
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(20, 14, 20, 14)
        self.root.setSpacing(10)
        bc = QLabel(f"Home  ›  {crumb or title}")
        bc.setObjectName("Breadcrumb")
        self.root.addWidget(bc)
        head = QHBoxLayout()
        lbl = QLabel(title)
        lbl.setObjectName("PageTitle")
        head.addWidget(lbl)
        head.addStretch(1)
        self.header_actions = head
        self.root.addLayout(head)

    def add_header_button(self, text: str, slot: Callable, kind: str = "", tip: str = "",
                          enabled: bool = True) -> QPushButton:
        b = button(text, kind, slot, tip)
        b.setEnabled(enabled)
        self.header_actions.addWidget(b)
        return b

    def refresh(self) -> None:  # pragma: no cover - overridden
        pass

    def apply_preset(self, **kwargs) -> None:  # optional navigation filters
        pass


def panel(title: Optional[str] = None) -> tuple[QFrame, QVBoxLayout]:
    f = QFrame()
    f.setObjectName("Panel")
    lay = QVBoxLayout(f)
    lay.setContentsMargins(12, 10, 12, 12)
    if title:
        lay.addWidget(section_label(title))
    return f, lay
