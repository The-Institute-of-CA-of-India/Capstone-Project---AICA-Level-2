"""Task management & staff allocation UI."""
from __future__ import annotations

from datetime import timedelta

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, settings_service, task_service
from app.services.task_service import PRIORITIES, TASK_CATEGORIES, TASK_STATUSES
from app.ui.widgets import (BasePage, DataTable, DateField, Field, FormDialog, SearchCombo, ask_text, button,
                            confirm, error, info, notify_changed, run_safely)
from app.utils.date_utils import fy_choices, today, week_bounds

COLUMNS = [("task_code", "Task ID"), ("client_name", "Client"), ("title", "Task"), ("category", "Category"),
           ("financial_year", "FY"), ("assigned_to", "Assigned To"), ("reviewer", "Reviewer"),
           ("created_by", "Created By"), ("created_date", "Created"), ("start_date", "Start"),
           ("due_date", "Internal Due"), ("priority", "Priority"), ("status", "Status"),
           ("completion_date", "Completed"), ("aging", "Aging"), ("overdue_days", "Overdue Days"),
           ("source_type", "Source")]
QUICK = [("open", "Open"), ("mine", "My Tasks"), ("today", "Due Today"), ("week", "This Week"),
         ("overdue", "Overdue"), ("review", "Awaiting Review"), ("done", "Completed"), ("all", "All")]


def edit_task(parent, task_id) -> bool:
    if not auth_service.has_perm("tasks.edit"):
        error(parent, "You do not have permission to edit tasks.")
        return False
    rec = task_service.get_task(task_id) if task_id else None
    can_assign = auth_service.has_perm("tasks.assign")
    fields = [Field("client_id", "Client", "client"), Field("title", "Task Title", required=True),
              Field("description", "Task Description", "multiline", extra={"height": 100}),
              Field("category", "Compliance Category", "combo", TASK_CATEGORIES, default="General"),
              Field("financial_year", "Financial Year", "ecombo", [""] + fy_choices(), default=settings_service.current_fy()),
              Field("assessment_year", "Assessment Year", "ecombo", [""] + fy_choices(back=6, fwd=2)),
              Field("assigned_to_id", "Assigned Staff", "user", readonly=not can_assign),
              Field("reviewer_id", "Reviewer", "user", readonly=not can_assign),
              Field("start_date", "Start Date", "date", default=today()),
              Field("due_date", "Internal Due Date", "date", required=True, default=today() + timedelta(days=3)),
              Field("priority", "Priority", "combo", PRIORITIES, default="Medium"),
              Field("status", "Task Status", "combo", TASK_STATUSES, default="Pending"),
              Field("completion_date", "Completion Date", "date"),
              Field("review_notes", "Review Notes", "multiline")]
    extra = None
    if rec:
        hist = DataTable([("when", "When"), ("user", "User"), ("action", "Action"), ("details", "Details")],
                         export_title="Task History", page_size=50)
        hist.set_rows(task_service.history(task_id))
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(hist, 1)
        h = QHBoxLayout()
        ed = QLineEdit()
        ed.setPlaceholderText("Add a comment…")
        h.addWidget(ed, 1)

        def add_comment():
            if ed.text().strip():
                task_service.add_comment(task_id, ed.text())
                ed.clear()
                hist.set_rows(task_service.history(task_id))
        h.addWidget(button("Add Comment", "", add_comment))
        lay.addLayout(h)
        extra = [("Comments & History", w)]
    defaults = None if rec else {"assigned_to_id": auth_service.current_user_id()}
    dlg = FormDialog(parent, f"Task {rec['task_code']}" if rec else "New Task", [("Task", fields)],
                     rec or defaults, extra_tabs=extra, width=760)
    if not rec:
        dlg.set_values({"start_date": today(), "due_date": today() + timedelta(days=3), "priority": "Medium",
                        "status": "Pending", "category": "General", "financial_year": settings_service.current_fy(),
                        "assigned_to_id": auth_service.current_user_id()})
    dlg.resize(800, 700)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    res = run_safely(parent, task_service.save_task, dlg.values, task_id)
    if res:
        notify_changed("tasks")
    return bool(res)


class TasksPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Tasks & Staff Allocation", "Tasks")
        self.add_header_button("＋ New Task", lambda: edit_task(self, None), "pink", "Ctrl+T",
                               auth_service.has_perm("tasks.edit"))
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)
        # ---- tasks tab
        w = QWidget()
        v = QVBoxLayout(w)
        top = QHBoxLayout()
        self.quick = "open"
        self.group = QButtonGroup(self)
        for k, label in QUICK:
            b = QPushButton(label)
            b.setProperty("kind", "chip")
            b.setCheckable(True)
            b.setChecked(k == "open")
            b.clicked.connect(lambda _=False, k=k: self._q(k))
            self.group.addButton(b)
            top.addWidget(b)
        top.addStretch(1)
        v.addLayout(top)
        bar = QHBoxLayout()
        can = auth_service.has_perm("tasks.edit")
        for text, slot, kind, en in [("✏ Open / Edit", self.edit, "", can), ("🔄 Change Status", self.status, "ghost", can),
                                     ("✔ Complete", self.complete, "success", can),
                                     ("👥 Reassign", self.reassign, "ghost", auth_service.has_perm("tasks.assign")),
                                     ("💬 Comment", self.comment, "ghost", can)]:
            b = button(text, kind, slot)
            b.setEnabled(en)
            bar.addWidget(b)
        bar.addStretch(1)
        v.addLayout(bar)
        self.table = DataTable(COLUMNS, table_key="tasks", filters=["status", "priority", "assigned_to", "category"],
                               export_title="Task List")
        self.table.extra_filter = self._filter
        self.table.activated.connect(lambda i: edit_task(self, i))
        self.table.add_action("Open / edit", self.edit)
        self.table.add_action("Complete", self.complete)
        self.table.add_action("Reassign", self.reassign)
        v.addWidget(self.table, 1)
        self.tabs.addTab(w, "Tasks")
        # ---- workload
        self.work = DataTable([("staff", "Staff"), ("role", "Role"), ("total", "Total Assigned"),
                               ("completed", "Completed"), ("pending", "Pending"), ("overdue", "Overdue"),
                               ("due_today", "Due Today"), ("awaiting_review", "Awaiting Review"),
                               ("open_compliances", "Open Compliances"), ("overdue_compliances", "Overdue Compliances"),
                               ("open_notices", "Open Notices")], export_title="Staff Workload")
        self.tabs.addTab(self.work, "Staff-wise Dashboard")
        # ---- allocation
        aw = QWidget()
        av = QVBoxLayout(aw)
        ah = QHBoxLayout()
        self.alloc_mode = QComboBox()
        self.alloc_mode.addItems(["Daily", "Weekly"])
        self.alloc_date = DateField(allow_blank=False, value=today())
        ah.addWidget(QLabel("Allocation"))
        ah.addWidget(self.alloc_mode)
        ah.addWidget(self.alloc_date)
        ah.addWidget(button("Show", "", self.load_alloc))
        ah.addStretch(1)
        av.addLayout(ah)
        self.alloc = DataTable([("staff", "Staff"), ("type", "Type"), ("client_name", "Client"), ("item", "Work Item"),
                                ("due", "Due"), ("priority", "Priority"), ("status", "Status")],
                               filters=["staff", "type"], export_title="Work Allocation")
        self.alloc.activated.connect(self._open_alloc)
        av.addWidget(self.alloc, 1)
        self.tabs.addTab(aw, "Daily / Weekly Allocation")
        # ---- priority
        self.prio = DataTable([("priority", "Priority")] + [(s, s) for s in TASK_STATUSES[:5]] +
                              [("overdue", "Overdue"), ("total", "Total Open")], export_title="Task Priority Dashboard")
        self.tabs.addTab(self.prio, "Priority Dashboard")
        self.tabs.currentChanged.connect(lambda _: self.refresh())

    def _q(self, k):
        self.quick = k
        self.table.reapply()

    def _filter(self, r) -> bool:
        t = today()
        q = self.quick
        is_open = r["status"] not in ("Completed", "Cancelled")
        if q == "all":
            return True
        if q == "done":
            return r["status"] == "Completed"
        if not is_open:
            return False
        if q == "open":
            return True
        if q == "mine":
            return r["assigned_to_id"] == auth_service.current_user_id()
        if q == "today":
            return r["due_date"] == t
        if q == "week":
            a, b = week_bounds(t)
            return bool(r["due_date"] and a <= r["due_date"] <= b)
        if q == "overdue":
            return bool(r["due_date"] and r["due_date"] < t)
        if q == "review":
            return r["status"] == "Under Review"
        return True

    def refresh(self):
        i = self.tabs.currentIndex()
        if i == 0:
            self.table.set_rows(task_service.list_tasks())
        elif i == 1:
            self.work.set_rows(task_service.workload())
        elif i == 2:
            self.load_alloc()
        else:
            self.prio.set_rows(task_service.priority_matrix())

    def apply_preset(self, **kw):
        if kw.get("quick"):
            self._q(kw["quick"])

    def load_alloc(self):
        d = self.alloc_date.value() or today()
        a, b = (d, d) if self.alloc_mode.currentText() == "Daily" else week_bounds(d)
        rows = task_service.allocation(a, b)
        for i, r in enumerate(rows):
            r["_key"] = (r["_kind"], r["_id"])
            r["_id"] = i
        self._alloc_rows = rows
        self.alloc.set_rows(rows)

    def _open_alloc(self, idx):
        r = self._alloc_rows[int(idx)]
        self.main.open_record(*r["_key"])
        self.load_alloc()

    def _id(self):
        i = self.table.current_id()
        if i is None:
            info(self, "Please select a task.")
        return i

    def edit(self):
        i = self._id()
        if i:
            edit_task(self, i)

    def status(self):
        i = self._id()
        if not i:
            return
        cur = task_service.get_task(i)["status"]
        st, ok = QInputDialog.getItem(self, "Change Status", "New status:", TASK_STATUSES, TASK_STATUSES.index(cur), False)
        if ok and st != cur:
            notes = ask_text(self, "Notes", "Notes / review comments (optional):") or ""
            run_safely(self, task_service.change_status, i, st, notes)
            notify_changed("tasks")

    def complete(self):
        ids = self.table.selected_ids()
        if not ids:
            return info(self, "Select one or more tasks.")
        if confirm(self, f"Mark {len(ids)} task(s) as Completed?"):
            for i in ids:
                task_service.change_status(i, "Completed")
            notify_changed("tasks")

    def reassign(self):
        ids = self.table.selected_ids()
        if not ids:
            return info(self, "Select one or more tasks.")
        dlg = FormDialog(self, f"Reassign {len(ids)} task(s)", [("Assign", [
            Field("staff", "Assign to", "user"), Field("reviewer", "Reviewer", "user")])], save_text="Reassign")
        if dlg.exec() == QDialog.DialogCode.Accepted:
            for i in ids:
                task_service.reassign(i, dlg.values.get("staff"), dlg.values.get("reviewer"))
            notify_changed("tasks")

    def comment(self):
        i = self._id()
        if i:
            txt = ask_text(self, "Task Comment", "Comment:", multiline=True)
            if txt:
                task_service.add_comment(i, txt)
                info(self, "Comment added to task history.")
