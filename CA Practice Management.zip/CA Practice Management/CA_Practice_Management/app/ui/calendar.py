"""Centralised compliance calendar: daily / weekly / monthly / quarterly / annual / FY
views, colour-coded, filterable, drag-and-drop rescheduling (with confirmation)."""
from __future__ import annotations

from datetime import date, timedelta

from app.qt import *  # noqa: F401,F403
from app.services import (auth_service, client_service, compliance_engine, notice_service, settings_service,
                          task_service)
from app.services.compliance_engine import CATEGORIES
from app.ui.styles import STATUS_COLORS, STATUS_TINTS
from app.ui.widgets import (BasePage, DataTable, DrillDownDialog, SearchCombo, ask_text, button, confirm, error,
                            info, notify_changed, run_safely)
from app.utils.date_utils import (MONTHS, add_months, fmt_date, fy_bounds, month_bounds, quarter_bounds, today,
                                  week_bounds)

VIEWS = ["Monthly", "Daily", "Weekly", "Quarterly", "Annual", "Financial Year"]
SEVERITY = {"red": 4, "yellow": 3, "blue": 2, "grey": 1, "green": 0}
LIST_COLS = [("date", "Date"), ("date_type", "Date Type"), ("type", "Type"), ("client_name", "Client"),
             ("item", "Item"), ("period", "Period"), ("status", "Status"), ("staff", "Staff")]


class CalendarGrid(QTableWidget):
    """6x7 month grid. Press on a day and release on another day to reschedule."""
    moved = Signal(object, object)
    dayOpened = Signal(object)

    def __init__(self):
        super().__init__(6, 7)
        self.setHorizontalHeaderLabels(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setWordWrap(True)
        self.setShowGrid(True)
        self._src = None
        self.cellDoubleClicked.connect(self._dbl)

    def _date_at(self, pos):
        it = self.itemAt(pos)
        return it.data(Qt.ItemDataRole.UserRole) if it else None

    def mousePressEvent(self, e):  # noqa: N802
        self._src = self._date_at(e.position().toPoint() if hasattr(e, "position") else e.pos())
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._src is not None:
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):  # noqa: N802
        self.unsetCursor()
        dst = self._date_at(e.position().toPoint() if hasattr(e, "position") else e.pos())
        src, self._src = self._src, None
        super().mouseReleaseEvent(e)
        if src and dst and src != dst:
            self.moved.emit(src, dst)

    def _dbl(self, r, c):
        it = self.item(r, c)
        if it and it.data(Qt.ItemDataRole.UserRole):
            self.dayOpened.emit(it.data(Qt.ItemDataRole.UserRole))


class CalendarPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Compliance Calendar", "Compliance Calendar")
        self.anchor = today()
        bar = QHBoxLayout()
        self.view = QComboBox()
        self.view.addItems(VIEWS)
        self.view.currentIndexChanged.connect(lambda _: self.refresh())
        bar.addWidget(QLabel("View"))
        bar.addWidget(self.view)
        bar.addWidget(button("◀", "ghost", lambda: self.shift(-1)))
        bar.addWidget(button("Today", "ghost", self.go_today))
        bar.addWidget(button("▶", "ghost", lambda: self.shift(1)))
        self.lbl = QLabel("")
        self.lbl.setObjectName("SectionTitle")
        bar.addWidget(self.lbl)
        bar.addStretch(1)
        self.client = SearchCombo(client_service.client_choices(), "All clients")
        self.client.setMinimumWidth(220)
        self.client.currentIndexChanged.connect(lambda _: self.refresh())
        bar.addWidget(self.client)
        self.cat = QComboBox()
        self.cat.addItem("All categories", None)
        for c in CATEGORIES:
            self.cat.addItem(c, c)
        self.cat.currentIndexChanged.connect(lambda _: self.refresh())
        bar.addWidget(self.cat)
        from app.services.auth_service import user_choices
        self.staff = SearchCombo(user_choices(), "All staff")
        self.staff.currentIndexChanged.connect(lambda _: self.refresh())
        bar.addWidget(self.staff)
        self.root.addLayout(bar)
        bar2 = QHBoxLayout()
        self.chk_notices = QCheckBox("Show notices")
        self.chk_notices.setChecked(True)
        self.chk_tasks = QCheckBox("Show tasks")
        self.chk_internal = QCheckBox("Show internal target dates")
        for chk in (self.chk_notices, self.chk_tasks, self.chk_internal):
            chk.toggled.connect(lambda _: self.refresh())
            bar2.addWidget(chk)
        bar2.addStretch(1)
        hint = QLabel("Tip: drag a compliance from one day to another to reschedule (confirmation required). "
                      "Double-click a day to open its items.")
        hint.setObjectName("Muted")
        bar2.addWidget(hint)
        self.root.addLayout(bar2)
        self.stack = QStackedWidget()
        self.grid = CalendarGrid()
        self.grid.moved.connect(self.reschedule)
        self.grid.dayOpened.connect(self.open_day)
        self.stack.addWidget(self.grid)
        self.list = DataTable(LIST_COLS, filters=["type", "status", "date_type"], export_title="Compliance Calendar")
        self.list.activated.connect(self._open_item)
        self.stack.addWidget(self.list)
        self.root.addWidget(self.stack, 1)
        self.items: list[dict] = []

    # ------------------------------------------------------------------ data
    def _range(self) -> tuple[date, date]:
        v = self.view.currentText()
        a = self.anchor
        if v == "Daily":
            return a, a
        if v == "Weekly":
            return week_bounds(a)
        if v == "Monthly":
            return month_bounds(a)
        if v == "Quarterly":
            return quarter_bounds(a)
        if v == "Annual":
            return date(a.year, 1, 1), date(a.year, 12, 31)
        from app.utils.date_utils import fy_of
        return fy_bounds(fy_of(a))

    def shift(self, n: int) -> None:
        v = self.view.currentText()
        step = {"Daily": None, "Weekly": None, "Monthly": 1, "Quarterly": 3, "Annual": 12, "Financial Year": 12}[v]
        if v == "Daily":
            self.anchor += timedelta(days=n)
        elif v == "Weekly":
            self.anchor += timedelta(days=7 * n)
        else:
            self.anchor = add_months(date(self.anchor.year, self.anchor.month, 1), step * n)
        self.refresh()

    def go_today(self):
        self.anchor = today()
        self.refresh()

    def _collect(self, start: date, end: date) -> list[dict]:
        items = []
        cid, cat, sid = self.client.value(), self.cat.currentData(), self.staff.value()
        for r in compliance_engine.list_records({"due_from": start - timedelta(days=0), "due_to": end,
                                                 "client_id": cid, "category": cat, "staff_id": sid}):
            items.append({"_key": ("compliance", r["id"]), "date": r["due"],
                          "date_type": "Revised Due" if r["revised_due"] else "Statutory Due",
                          "type": f"Compliance - {r['category']}", "client_name": r["client_name"],
                          "item": r["compliance_name"], "period": r["tax_period"], "status": r["status"],
                          "staff": r["staff"], "_color": r["_color"], "_rid": r["id"]})
        if self.chk_internal.isChecked():
            for r in compliance_engine.list_records({"open_only": True, "client_id": cid, "category": cat, "staff_id": sid}):
                d = r["internal_target"]
                if d and start <= d <= end:
                    items.append({"_key": ("compliance", r["id"]), "date": d, "date_type": "Internal Target",
                                  "type": f"Internal - {r['category']}", "client_name": r["client_name"],
                                  "item": r["compliance_name"], "period": r["tax_period"], "status": r["status"],
                                  "staff": r["staff"], "_color": "blue", "_rid": None})
        if self.chk_notices.isChecked() and not cat:
            for n in notice_service.list_notices({"open_only": True, "client_id": cid}):
                if sid and n["assigned_staff_id"] != sid:
                    continue
                for d, label in ((n["reply_due_date"], "Notice Reply Due"), (n["next_hearing_date"] or n["hearing_date"], "Hearing"),
                                 (n["appeal_deadline"], "Appeal Deadline")):
                    if d and start <= d <= end:
                        items.append({"_key": ("notice", n["id"]), "date": d, "date_type": label, "type": "Notice",
                                      "client_name": n["client_name"], "item": f"{n['category']} {n['section'] or ''}",
                                      "period": n["assessment_year"] or "", "status": n["status"], "staff": n["staff"],
                                      "_color": n["_color"], "_rid": None})
        if self.chk_tasks.isChecked() and not cat:
            for t in task_service.list_tasks({"open_only": True, "client_id": cid, "assigned_to_id": sid,
                                              "due_from": start, "due_to": end}):
                items.append({"_key": ("task", t["id"]), "date": t["due_date"], "date_type": "Task Due", "type": "Task",
                              "client_name": t["client_name"], "item": t["title"], "period": "", "status": t["status"],
                              "staff": t["assigned_to"], "_color": t["_color"], "_rid": None})
        items.sort(key=lambda x: (x["date"], -SEVERITY.get(x["_color"], 0)))
        for i, x in enumerate(items):
            x["_id"] = i
        return items

    def refresh(self) -> None:
        start, end = self._range()
        v = self.view.currentText()
        if v == "Monthly":
            self.lbl.setText(f"{MONTHS[self.anchor.month - 1]} {self.anchor.year}")
            grid_start = start - timedelta(days=start.weekday())
            self.items = self._collect(grid_start, grid_start + timedelta(days=41))
            self._render_month(start, grid_start)
            self.stack.setCurrentWidget(self.grid)
        else:
            self.lbl.setText(f"{fmt_date(start)}  →  {fmt_date(end)}")
            self.items = self._collect(start, end)
            self.list.export_title = f"Compliance Calendar {fmt_date(start)} to {fmt_date(end)}"
            self.list.set_rows(self.items)
            self.stack.setCurrentWidget(self.list)

    def _render_month(self, month_start: date, grid_start: date) -> None:
        by_day: dict[date, list] = {}
        for it in self.items:
            by_day.setdefault(it["date"], []).append(it)
        t = today()
        for i in range(42):
            d = grid_start + timedelta(days=i)
            day_items = by_day.get(d, [])
            lines = [f"{d.day}" + ("  • TODAY" if d == t else "")]
            for it in day_items[:5]:
                icon = {"red": "🔴", "yellow": "🟡", "blue": "🔵", "grey": "⚪", "green": "🟢"}.get(it["_color"], "•")
                lines.append(f"{icon} {it['item'][:22]} – {it['client_name'][:16]}")
            if len(day_items) > 5:
                lines.append(f"+{len(day_items) - 5} more…")
            cell = QTableWidgetItem("\n".join(lines))
            cell.setData(Qt.ItemDataRole.UserRole, d)
            cell.setTextAlignment(int(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft))
            worst = max((SEVERITY.get(x["_color"], 0) for x in day_items), default=-1)
            colour = {4: "red", 3: "yellow", 2: "blue", 1: "grey", 0: "green"}.get(worst)
            if d.month != month_start.month:
                cell.setForeground(QColor("#9CA3AF"))
                cell.setBackground(QColor("#F9FAFB"))
            elif colour:
                cell.setBackground(QColor(STATUS_TINTS[colour]))
                cell.setForeground(QColor("#111827"))
            if d == t:
                f = cell.font()
                f.setBold(True)
                cell.setFont(f)
            cell.setToolTip("\n".join(f"{x['date_type']}: {x['item']} – {x['client_name']} ({x['status']})"
                                      for x in day_items) or "No items")
            self.grid.setItem(i // 7, i % 7, cell)

    # ------------------------------------------------------------------ interactions
    def open_day(self, d: date) -> None:
        day = [x for x in self.items if x["date"] == d]
        rows = [dict(x, _id=i) for i, x in enumerate(day)]

        def _open(i):
            self._open_key(day[int(i)]["_key"])
        DrillDownDialog(self, f"Calendar items on {fmt_date(d)}", LIST_COLS, rows, _open).exec()
        self.refresh()

    def _open_item(self, idx) -> None:
        try:
            self._open_key(self.items[int(idx)]["_key"])
        except (IndexError, ValueError, TypeError):
            pass

    def _open_key(self, key) -> None:
        self.main.open_record(key[0], key[1])
        self.refresh()

    def reschedule(self, src: date, dst: date) -> None:
        cands = [x for x in self.items if x["date"] == src and x["_rid"]]
        if not cands:
            return
        if not auth_service.has_perm("compliance.edit"):
            return error(self, "You do not have permission to reschedule compliances.")
        if len(cands) > 1:
            labels = [f"{c['item']} ({c['period']}) – {c['client_name']}" for c in cands]
            choice, ok = QInputDialog.getItem(self, "Reschedule", f"Which item on {fmt_date(src)} should move to "
                                                                  f"{fmt_date(dst)}?", labels, 0, False)
            if not ok:
                return
            item = cands[labels.index(choice)]
        else:
            item = cands[0]
        box = QMessageBox(self)
        box.setWindowTitle("Confirm Rescheduling")
        box.setText(f"Move <b>{item['item']}</b> ({item['period']}) for <b>{item['client_name']}</b><br>"
                    f"from {fmt_date(src)} to <b>{fmt_date(dst)}</b>?<br><br>"
                    "Choose which date to change. The statutory due date is never overwritten.")
        b_int = box.addButton("Internal Target Date", QMessageBox.ButtonRole.AcceptRole)
        b_rev = box.addButton("Revised Due Date (extension)", QMessageBox.ButtonRole.ActionRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        if clicked == b_int:
            run_safely(self, compliance_engine.save_record, {"internal_target_date": dst}, item["_rid"])
        elif clicked == b_rev:
            if not auth_service.has_perm("compliance.review"):
                return error(self, "Only reviewers can record revised statutory due dates.")
            reason = ask_text(self, "Revised Due Date", "Notification / reason for the extension:")
            if not reason:
                return
            run_safely(self, compliance_engine.revise_due_date, [item["_rid"]], dst, reason, "Calendar reschedule")
        else:
            return
        notify_changed("compliance")
