"""Vibrant blue / violet / pink theme (light + optional dark). Drop a custom.qss
into app/resources/styles/ to append your own overrides."""
from __future__ import annotations

import os

import config

PALETTE = {
    "violet": "#7C3AED", "violet_dark": "#5B21B6", "blue": "#2563EB", "pink": "#EC4899",
    "indigo": "#4338CA", "bg": "#F5F3FF", "card": "#FFFFFF", "text": "#1F2937", "muted": "#6B7280",
}
STATUS_COLORS = {"green": "#16A34A", "blue": "#2563EB", "yellow": "#CA8A04", "red": "#DC2626", "grey": "#6B7280"}
STATUS_TINTS = {"green": "#DCFCE7", "blue": "#DBEAFE", "yellow": "#FEF9C3", "red": "#FEE2E2", "grey": "#F3F4F6"}
KPI_GRADIENTS = [("#2563EB", "#7C3AED"), ("#EC4899", "#8B5CF6"), ("#06B6D4", "#3B82F6"), ("#F43F5E", "#EC4899"),
                 ("#8B5CF6", "#D946EF"), ("#10B981", "#3B82F6"), ("#F59E0B", "#EF4444"), ("#6366F1", "#EC4899")]

LIGHT = """
* { font-family: "Segoe UI", "Inter", Arial; font-size: 10pt; }
QMainWindow, QDialog { background: #F5F3FF; }
QWidget#Page { background: #F5F3FF; }
QLabel { color: #1F2937; }
QLabel#PageTitle { font-size: 18pt; font-weight: 700; color: #4C1D95; }
QLabel#Breadcrumb { color: #8B5CF6; font-size: 9pt; }
QLabel#SectionTitle { font-size: 11.5pt; font-weight: 700; color: #5B21B6; padding: 2px 0; }
QLabel#Muted { color: #6B7280; }
QLabel#ErrorLabel { color: #DC2626; font-weight: 600; }
QLabel#BackupOk { color: #15803D; font-weight: 700; }
QLabel#BackupWarn { color: #DC2626; font-weight: 700; }

QFrame#Sidebar { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1E1B4B, stop:0.55 #4C1D95, stop:1 #831843); }
QLabel#Brand { color: white; font-size: 13pt; font-weight: 800; }
QLabel#BrandSub { color: #F9A8D4; font-size: 8.5pt; }
QListWidget#Nav { background: transparent; border: none; color: #E9D5FF; font-size: 10.5pt; outline: 0; }
QListWidget#Nav::item { padding: 9px 12px; border-radius: 10px; margin: 2px 8px; }
QListWidget#Nav::item:hover { background: rgba(255,255,255,0.12); color: white; }
QListWidget#Nav::item:selected { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #EC4899, stop:1 #8B5CF6); color: white; font-weight: 700; }

QFrame#TopBar { background: white; border-bottom: 3px solid qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563EB, stop:0.5 #7C3AED, stop:1 #EC4899); }
QFrame#TopBar QLabel { color: #4C1D95; }
QFrame#Panel { background: white; border: 1px solid #E9D5FF; border-radius: 14px; }
QFrame#KpiCard { border-radius: 16px; }
QFrame#KpiCard QLabel { color: white; background: transparent; }

QPushButton { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563EB, stop:1 #7C3AED); color: white;
  border: none; border-radius: 8px; padding: 7px 14px; font-weight: 600; }
QPushButton:hover { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7C3AED, stop:1 #EC4899); }
QPushButton:pressed { background: #5B21B6; }
QPushButton:disabled { background: #D1D5DB; color: #6B7280; }
QPushButton[kind="pink"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #EC4899, stop:1 #F43F5E); }
QPushButton[kind="ghost"] { background: white; color: #5B21B6; border: 1px solid #C4B5FD; }
QPushButton[kind="ghost"]:hover { background: #F5F3FF; border-color: #8B5CF6; }
QPushButton[kind="danger"] { background: #DC2626; }
QPushButton[kind="success"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #059669, stop:1 #10B981); }
QPushButton[kind="chip"] { background: #EDE9FE; color: #5B21B6; border-radius: 13px; padding: 4px 12px; font-weight: 600; }
QPushButton[kind="chip"]:checked { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #EC4899, stop:1 #8B5CF6); color: white; }
QToolButton { background: white; color: #5B21B6; border: 1px solid #C4B5FD; border-radius: 8px; padding: 6px 10px; font-weight: 600; }
QToolButton:hover { background: #F5F3FF; }
QToolButton::menu-indicator { image: none; }

QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit {
  background: white; border: 1px solid #D8B4FE; border-radius: 7px; padding: 5px 8px; color: #1F2937;
  selection-background-color: #8B5CF6; }
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 2px solid #8B5CF6; }
QLineEdit:disabled, QDateEdit:disabled { background: #F3F4F6; color: #9CA3AF; }
QLineEdit#GlobalSearch { border-radius: 16px; padding: 6px 14px; background: #F5F3FF; border: 1px solid #C4B5FD; min-width: 320px; }
QComboBox QAbstractItemView { background: white; selection-background-color: #EDE9FE; selection-color: #4C1D95; }

QTableWidget, QTableView, QTreeWidget, QListWidget#Plain { background: white; alternate-background-color: #FAF5FF;
  border: 1px solid #E9D5FF; border-radius: 10px; gridline-color: #F3E8FF; selection-background-color: #C4B5FD; selection-color: #1F2937; }
QHeaderView::section { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #EDE9FE, stop:1 #DDD6FE); color: #4C1D95;
  padding: 6px; border: none; border-right: 1px solid #E9D5FF; font-weight: 700; }
QTabWidget::pane { border: 1px solid #E9D5FF; border-radius: 10px; background: white; top: -1px; }
QTabBar::tab { background: #EDE9FE; color: #5B21B6; padding: 7px 16px; border-top-left-radius: 9px; border-top-right-radius: 9px; margin-right: 3px; font-weight: 600; }
QTabBar::tab:selected { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563EB, stop:1 #EC4899); color: white; }
QGroupBox { border: 1px solid #E9D5FF; border-radius: 10px; margin-top: 12px; padding-top: 8px; font-weight: 700; color: #5B21B6; background: white; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 4px; }
QScrollArea { border: none; background: transparent; }
QStatusBar { background: white; color: #4C1D95; border-top: 1px solid #E9D5FF; }
QMenu { background: white; border: 1px solid #C4B5FD; }
QMenu::item { padding: 6px 22px; color: #1F2937; }
QMenu::item:selected { background: #EDE9FE; color: #4C1D95; }
QCheckBox { color: #1F2937; }
QCheckBox::indicator:checked { background: #8B5CF6; border: 1px solid #7C3AED; border-radius: 3px; }
QCheckBox::indicator:unchecked { background: white; border: 1px solid #C4B5FD; border-radius: 3px; }
QToolTip { background: #4C1D95; color: white; border: none; padding: 4px; }
QCalendarWidget QAbstractItemView { selection-background-color: #EC4899; }
"""

DARK = LIGHT.replace("#F5F3FF", "#17142B").replace("background: white", "background: #221E3D") \
    .replace("color: #1F2937", "color: #EDE9FE").replace("#FAF5FF", "#2A2548").replace("#F3E8FF", "#2E2850") \
    .replace("QLabel { color: #1F2937; }", "QLabel { color: #EDE9FE; }").replace("#4C1D95; }", "#E9D5FF; }") \
    .replace("QFrame#TopBar QLabel { color: #4C1D95; }", "QFrame#TopBar QLabel { color: #E9D5FF; }")


def stylesheet(theme: str = "light") -> str:
    qss = DARK if theme == "dark" else LIGHT
    custom = os.path.join(config.RESOURCE_DIR, "app", "resources", "styles", "custom.qss")
    if os.path.isfile(custom):
        try:
            with open(custom, "r", encoding="utf-8") as fh:
                qss += "\n" + fh.read()
        except OSError:
            pass
    return qss
