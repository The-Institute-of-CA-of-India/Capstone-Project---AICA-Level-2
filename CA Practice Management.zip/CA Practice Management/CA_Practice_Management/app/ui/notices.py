"""Notice management UI (Workflow 3)."""
from __future__ import annotations

from datetime import timedelta

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, document_service, notice_service, settings_service
from app.services.notice_service import DEPARTMENTS, NOTICE_CATEGORIES, NOTICE_STATUSES, PRE_REPLY
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, button, confirm, error, info, notify_changed,
                            open_file_dialog, run_safely, save_file_dialog, section_label)
from app.utils.date_utils import fy_choices, today

COLUMNS = [("notice_code", "Notice ID"), ("client_name", "Client"), ("department", "Department"),
           ("category", "Category"), ("notice_type", "Type"), ("section", "Section"), ("notice_number", "Notice No."),
           ("din", "DIN"), ("notice_date", "Notice Date"), ("receipt_date", "Received"),
           ("assessment_year", "AY"), ("reply_due_date", "Reply Due"), ("internal_deadline", "Internal Deadline"),
           ("days_left", "Days Left"), ("aging", "Aging (days)"), ("status", "Status"), ("staff", "Staff"),
           ("reviewer", "Reviewing Partner"), ("hearing_date", "Hearing"), ("next_hearing_date", "Next Hearing"),
           ("appeal_deadline", "Appeal Deadline"), ("demand_amount", "Demand"), ("amount_disputed", "Disputed")]
QUICK = [("open", "Open"), ("pending", "Pending Reply"), ("warn", "Due ≤ warning days"), ("overdue", "Reply Overdue"),
         ("hearing", "Hearings / Appeals"), ("closed", "Closed"), ("all", "All")]
DEPT_FOR_CAT = {"Income Tax": "Income Tax", "GST": "GST", "TDS": "TDS", "ROC": "ROC", "MCA": "MCA"}


def _fields(new: bool) -> list:
    ays = [""] + fy_choices(back=8, fwd=2)
    f = [Field("client_id", "Client", "client", required=True, readonly=not new),
         Field("category", "Notice Category", "combo", NOTICE_CATEGORIES, required=True),
         Field("department", "Department", "combo", DEPARTMENTS, required=True),
         Field("notice_type", "Notice Type", "ecombo", ["", "Scrutiny", "Intimation u/s 143(1)", "Show Cause Notice",
                                                        "Demand Notice", "Reassessment", "Penalty", "Defective Return",
                                                        "Information Request", "Summons", "Other"]),
         Field("section", "Section / Provision", placeholder="e.g. 143(2), 148A, Sec 73 CGST"),
         Field("notice_number", "Notice / Reference No."), Field("din", "DIN"),
         Field("notice_date", "Date of Notice", "date"), Field("receipt_date", "Date of Receipt", "date", required=True),
         Field("assessment_year", "Assessment Year", "ecombo", ays), Field("financial_year", "Financial Year", "ecombo", ays),
         Field("reply_due_date", "Statutory Reply Due Date", "date"),
         Field("internal_deadline", "Internal Reply Deadline", "date", tooltip="Blank = auto (reply due - buffer)"),
         Field("assigned_staff_id", "Assigned Staff", "user"), Field("reviewer_id", "Reviewing Partner", "user"),
         Field("status", "Notice Status", "combo", NOTICE_STATUSES, default="Received"),
         Field("demand_amount", "Demand Amount", "money"), Field("amount_disputed", "Amount in Dispute", "money"),
         Field("remarks", "Remarks", "multiline")]
    if new:
        f.append(Field("notice_doc", "Notice Document", "file"))
    else:
        f += [Field("reply_date", "Reply Submission Date", "date"), Field("ack_number", "Acknowledgment No."),
              Field("hearing_date", "Hearing Date", "date"), Field("next_hearing_date", "Next Hearing Date", "date"),
              Field("appeal_deadline", "Appeal Deadline", "date")]
    return f


def edit_notice(parent, notice_id) -> bool:
    can = auth_service.has_perm("notices.edit")
    rec = notice_service.get_notice(notice_id) if notice_id else None
    extra = None
    if rec:
        hist = DataTable([("when", "When"), ("user", "User"), ("action", "Action"), ("status", "Status"),
                          ("version", "Reply Ver."), ("details", "Details"), ("doc_path", "Document")],
                         export_title="Notice History", page_size=50)
        hist.set_rows(notice_service.history(notice_id))
        hist.activated.connect(lambda i: _open_hist_doc(parent, hist))
        docs = DataTable([("category", "Category"), ("title", "Title"), ("file_name", "File"), ("version", "Ver"),
                          ("uploaded_at", "Uploaded")], page_size=50, show_toolbar=False)
        docs.set_rows(document_service.list_documents(notice_id=notice_id))
        docs.activated.connect(lambda i: run_safely(parent, document_service.open_path,
                                                    document_service.get_document(i)["stored_path"]))
        extra = [("History & Reply Versions", hist), ("Documents", docs)]
    if not can and not rec:
        error(parent, "You do not have permission to create notices.")
        return False
    dlg = FormDialog(parent, f"Notice {rec['notice_code']} - {rec['client_name']}" if rec else "Record New Notice",
                     [("Notice Details", _fields(not rec))], rec, extra_tabs=extra, width=820)
    dlg.btn_save.setEnabled(can)
    dlg.resize(860, 760)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    v = dict(dlg.values)
    if rec:
        res = run_safely(parent, notice_service.update_notice, notice_id, v)
        ok = res is not None or True
    else:
        doc = v.pop("notice_doc", None)
        nid = run_safely(parent, notice_service.create_notice, v, doc)
        ok = bool(nid)
        if nid:
            n = notice_service.get_notice(nid)
            warn = int(settings_service.get("notice_warning_days") or 7)
            msg = (f"Notice {n['notice_code']} recorded.\n\n• Internal deadline: {n['internal_deadline'] or '-'}\n"
                   f"• Reply task created and assigned\n• Reminders generated")
            if n["days_left"] is not None and n["days_left"] <= warn:
                msg += f"\n\n⚠ WARNING: Reply is due in {n['days_left']} day(s)!"
            info(parent, msg)
    notify_changed("notices")
    return ok


def _open_hist_doc(parent, table):
    r = table.current_row()
    if r and r.get("doc_path"):
        run_safely(parent, document_service.open_path, r["doc_path"])


class NoticesPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Notice Management", "Notices")
        can = auth_service.has_perm("notices.edit")
        self.add_header_button("＋ New Notice", lambda: edit_notice(self, None), "pink", "", can)
        top = QHBoxLayout()
        self.quick = "open"
        self.group = QButtonGroup(self)
        for k, label in QUICK:
            b = QPushButton(label)
            b.setProperty("kind", "chip")
            b.setCheckable(True)
            b.setChecked(k == "open")
            b.clicked.connect(lambda _=False, k=k: self._q(k))
            self.group.addButton(b)
            top.addWidget(b)
        top.addStretch(1)
        self.root.addLayout(top)
        bar = QHBoxLayout()
        for text, slot, kind in [("✏ Open / Edit", self.edit, ""), ("🔄 Update Status", self.status, "ghost"),
                                 ("📎 Attach Notice Doc", lambda: self.attach("notice"), "ghost"),
                                 ("📝 Reply Draft (Word)", self.draft, "ghost"),
                                 ("📤 Upload Reply Version", lambda: self.attach("reply"), "ghost"),
                                 ("✔ Record Reply Submission", self.reply, "success"),
                                 ("⚖ Hearing / Appeal", self.hearing, "ghost"), ("🔒 Close Notice", self.close_notice, "ghost"),
                                 ("📂 Open Notice Doc", self.open_doc, "ghost")]:
            b = button(text, kind, slot)
            b.setEnabled(can or text.startswith(("✏", "📂")))
            bar.addWidget(b)
        bar.addStretch(1)
        self.root.addLayout(bar)
        self.table = DataTable(COLUMNS, table_key="notices", filters=["department", "category", "status", "staff"],
                               money=["demand_amount", "amount_disputed"], export_title="Notice Register")
        self.table.extra_filter = self._filter
        self.table.activated.connect(lambda i: edit_notice(self, i))
        self.table.add_action("Open / edit", self.edit)
        self.table.add_action("Record reply", self.reply)
        self.table.add_action("Hearing / appeal", self.hearing)
        self.table.add_action("Open client profile", lambda: self._client())
        self.root.addWidget(self.table, 1)

    def _q(self, k):
        self.quick = k
        self.table.reapply()

    def _filter(self, r) -> bool:
        t = today()
        q = self.quick
        warn = int(settings_service.get("notice_warning_days") or 7)
        if q == "all":
            return True
        if q == "closed":
            return r["status"] == "Closed"
        if r["status"] == "Closed":
            return False
        if q == "open":
            return True
        if q == "pending":
            return r["status"] in PRE_REPLY
        if q == "warn":
            return r["status"] in PRE_REPLY and r["reply_due_date"] is not None and r["reply_due_date"] <= t + timedelta(days=warn)
        if q == "overdue":
            return r["status"] in PRE_REPLY and r["reply_due_date"] is not None and r["reply_due_date"] < t
        if q == "hearing":
            return bool(r["hearing_date"] or r["next_hearing_date"] or r["appeal_deadline"])
        return True

    def refresh(self):
        self.table.set_rows(notice_service.list_notices())

    def _id(self):
        i = self.table.current_id()
        if i is None:
            info(self, "Please select a notice.")
        return i

    def _client(self):
        r = self.table.current_row()
        if r:
            self.main.open_record("client", r["client_id"])

    def edit(self):
        i = self._id()
        if i:
            edit_notice(self, i)

    def status(self):
        i = self._id()
        if not i:
            return
        cur = notice_service.get_notice(i)["status"]
        st, ok = QInputDialog.getItem(self, "Update Status", "New status:", NOTICE_STATUSES,
                                      NOTICE_STATUSES.index(cur) if cur in NOTICE_STATUSES else 0, False)
        if ok and st != cur:
            if st == "Closed":
                return self.close_notice()
            run_safely(self, notice_service.update_notice, i, {"status": st})
            notify_changed("notices")

    def attach(self, kind):
        i = self._id()
        if not i:
            return
        p = open_file_dialog(self, "Select notice document" if kind == "notice" else "Select reply draft / version")
        if p:
            remarks = ""
            if kind == "reply":
                remarks = QInputDialog.getText(self, "Reply Version", "Version remarks (optional):")[0]
            if run_safely(self, notice_service.attach_document, i, p, kind, remarks):
                info(self, "Document attached." + (" Reply version recorded in history." if kind == "reply" else ""))
                notify_changed("notices")

    def draft(self):
        i = self._id()
        if not i:
            return
        n = notice_service.get_notice(i)
        path = save_file_dialog(self, "Save Reply Draft", f"Reply_{n['notice_code']}.docx", "Word (*.docx)")
        if path and run_safely(self, notice_service.generate_reply_draft, i, path):
            if confirm(self, "Reply draft created. Open it now?\n\nAfter editing, use 'Upload Reply Version' to "
                             "store it as a version."):
                run_safely(self, document_service.open_path, path)

    def reply(self):
        i = self._id()
        if not i:
            return
        dlg = FormDialog(self, "Record Reply Submission", [("Reply", [
            Field("reply_date", "Reply Submission Date", "date", required=True, default=today()),
            Field("ack", "Acknowledgment No."), Field("next_status", "Status after submission", "combo",
                                                      ["Reply Submitted", "Hearing Pending", "Appeal Pending", "Closed"]),
            Field("reply_doc", "Final Reply Document", "file"), Field("remarks", "Remarks", "multiline")])],
            {"reply_date": today()}, save_text="✔ Record Reply")
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.values
            if v["next_status"] == "Closed":
                v["next_status"] = "Reply Submitted"
            run_safely(self, notice_service.record_reply, i, v["reply_date"], v.get("ack") or "", v.get("reply_doc"),
                       v.get("remarks") or "", v["next_status"])
            notify_changed("notices")

    def hearing(self):
        i = self._id()
        if not i:
            return
        n = notice_service.get_notice(i)
        dlg = FormDialog(self, "Hearing / Appeal Tracking", [("Hearing", [
            Field("hearing_date", "Hearing Date", "date"), Field("next_hearing", "Next Hearing Date", "date"),
            Field("appeal_deadline", "Appeal Limitation Deadline", "date"), Field("remarks", "Remarks", "multiline")])],
            {"hearing_date": n["hearing_date"], "next_hearing": n["next_hearing_date"], "appeal_deadline": n["appeal_deadline"]})
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.values
            run_safely(self, notice_service.add_hearing, i, v.get("hearing_date"), v.get("next_hearing"),
                       v.get("appeal_deadline"), v.get("remarks") or "")
            notify_changed("notices")

    def close_notice(self):
        i = self._id()
        if not i:
            return
        dlg = FormDialog(self, "Close Notice", [("Closure", [
            Field("closed_on", "Closure Date", "date", required=True, default=today()),
            Field("remarks", "Closure Remarks / Outcome", "multiline", required=True)])], {"closed_on": today()},
            save_text="🔒 Close Notice")
        if dlg.exec() == QDialog.DialogCode.Accepted and confirm(self, "Close this notice? It will move to closure history."):
            run_safely(self, notice_service.close_notice, i, dlg.values["remarks"], dlg.values["closed_on"])
            notify_changed("notices")

    def open_doc(self):
        i = self._id()
        if not i:
            return
        n = notice_service.get_notice(i)
        if not n["notice_doc_path"]:
            return info(self, "No notice document attached yet.")
        run_safely(self, document_service.open_path, n["notice_doc_path"])
