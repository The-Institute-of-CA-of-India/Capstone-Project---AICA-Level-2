"""ROC / MCA compliance tracker (CIN/LLPIN-wise, AGM & board meetings, SRN tracking)."""
from app.ui.compliance import CategoryPage


class ROCPage(CategoryPage):
    CATEGORY = "ROC"
    TITLE = "ROC / MCA Compliance"
    CLIENT_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("cin_llpin", "CIN / LLPIN"),
                      ("entity_type", "Entity Type"), ("date_of_incorporation", "Incorporated"),
                      ("agm_date", "AGM Date"), ("statutory_audit_applicable", "Stat. Audit"),
                      ("small_company", "Small Co."), ("msme_payables", "MSME-1"), ("staff", "Staff")]
    EXTRA_TABS = [("Annual Filings", ["ROC-AOC4", "ROC-AOC4X", "ROC-MGT7", "ROC-MGT7A", "ROC-ADT1", "ROC-LLP8",
                                      "ROC-LLP11", "ROC-DPT3", "ROC-DIR3KYC"]),
                  ("AGM, Board Meetings & Audit", ["ROC-AGM", "ROC-BM", "ROC-STATAUDIT", "ROC-AFS"])]

    def client_filter(self, c) -> bool:
        return c.get("entity_type") in ("Private Limited Company", "Public Limited Company", "LLP") or bool(c.get("cin_llpin"))
