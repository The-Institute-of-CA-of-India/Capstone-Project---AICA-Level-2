"""Reminders & notifications UI (in-app, desktop, optional email / WhatsApp)."""
from __future__ import annotations

import webbrowser

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, reminder_engine, settings_service
from app.services.reminder_engine import REMINDER_TYPES
from app.ui.widgets import (BasePage, DataTable, button, confirm, error, info, notify_changed, run_safely,
                            section_label)

COLUMNS = [("remind_on", "Remind On"), ("reminder_type", "Type"), ("client_name", "Client"), ("title", "Title"),
           ("message", "Message"), ("due_date", "Due Date"), ("recipient", "Recipient"), ("status", "Status"),
           ("snooze_until", "Snoozed Until")]


def _open_ref(main, r: dict) -> None:
    kind = {"compliance": "compliance", "notice": "notice", "task": "task", "collection": "collection"}.get(r["ref_type"])
    if kind:
        main.open_record(kind, r["ref_id"])


class NotificationsDialog(QDialog):
    """Popup listing the current user's active reminders (startup + bell)."""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("🔔 Notifications")
        self.resize(1000, 520)
        v = QVBoxLayout(self)
        v.addWidget(section_label("Your active reminders"))
        self.table = DataTable(COLUMNS[:8], export_title="Active Reminders", page_size=100)
        self.table.activated.connect(self._open)
        v.addWidget(self.table, 1)
        h = QHBoxLayout()
        h.addWidget(button("Open related record", "", self._open_sel))
        h.addWidget(button("Snooze 1 day", "ghost", lambda: self._snooze(1)))
        h.addWidget(button("Snooze 3 days", "ghost", lambda: self._snooze(3)))
        h.addWidget(button("✔ Mark completed", "success", self._complete))
        h.addWidget(button("Dismiss", "ghost", self._dismiss))
        h.addStretch(1)
        h.addWidget(button("All reminders…", "ghost", lambda: (self.accept(), main.navigate("reminders"))))
        h.addWidget(button("Close", "ghost", self.accept))
        v.addLayout(h)
        self.load()

    def load(self):
        self.rows = reminder_engine.active_for_current_user()
        self.table.set_rows(self.rows)

    def _open(self, rid):
        r = next((x for x in self.rows if x["id"] == rid), None)
        if r:
            _open_ref(self.main, r)
            self.load()

    def _open_sel(self):
        rid = self.table.current_id()
        if rid:
            self._open(rid)

    def _snooze(self, d):
        ids = self.table.selected_ids()
        if ids:
            reminder_engine.snooze(ids, d)
            self.load()

    def _complete(self):
        ids = self.table.selected_ids()
        if ids:
            reminder_engine.complete(ids)
            self.load()

    def _dismiss(self):
        ids = self.table.selected_ids()
        if ids:
            reminder_engine.dismiss(ids)
            self.load()


class RemindersPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Reminders & Notifications", "Reminders")
        self.add_header_button("⟳ Run Reminder Scan Now", self.scan, "pink")
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)
        w = QWidget()
        v = QVBoxLayout(w)
        bar = QHBoxLayout()
        self.chk_active = QCheckBox("Active only")
        self.chk_active.setChecked(True)
        self.chk_active.toggled.connect(lambda _: self.refresh())
        bar.addWidget(self.chk_active)
        self.chk_mine = QCheckBox("Only mine")
        self.chk_mine.toggled.connect(lambda _: self.refresh())
        bar.addWidget(self.chk_mine)
        for text, slot, kind in [("Open Record", self.open_sel, ""), ("Snooze 1d", lambda: self.snooze(1), "ghost"),
                                 ("Snooze 3d", lambda: self.snooze(3), "ghost"), ("Snooze 7d", lambda: self.snooze(7), "ghost"),
                                 ("✔ Completed", self.complete, "success"), ("Dismiss", self.dismiss, "ghost"),
                                 ("✉ Send Email", self.email, "ghost"), ("💬 WhatsApp", self.whatsapp, "ghost")]:
            bar.addWidget(button(text, kind, slot))
        bar.addStretch(1)
        v.addLayout(bar)
        self.table = DataTable(COLUMNS, table_key="reminders", filters=["reminder_type", "status", "recipient"],
                               export_title="Reminders")
        self.table.activated.connect(lambda i: self.open_sel())
        v.addWidget(self.table, 1)
        self.tabs.addTab(w, "Reminders")
        self.hist = DataTable([("when", "When"), ("reminder", "Reminder"), ("type", "Type"), ("action", "Action"),
                               ("channel", "Channel"), ("details", "Details"), ("user", "User")],
                              filters=["action", "channel"], export_title="Reminder History")
        self.tabs.addTab(self.hist, "Reminder History")
        self.tabs.addTab(self._config_tab(), "Reminder Configuration")
        self.tabs.currentChanged.connect(lambda _: self.refresh())

    def _config_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(section_label("Reminder schedule (relative to due date)"))
        self.offset_checks = {}
        current = set(int(x) for x in settings_service.get("reminder_offsets") or [])
        grid = QHBoxLayout()
        for off, label in [(15, "15 days before"), (7, "7 days before"), (3, "3 days before"), (1, "1 day before"),
                           (0, "On due date"), (-1, "After due date (then weekly)")]:
            c = QCheckBox(label)
            c.setChecked(off in current)
            self.offset_checks[off] = c
            grid.addWidget(c)
        grid.addStretch(1)
        v.addLayout(grid)
        f = QFormLayout()
        self.notice_warn = QSpinBox()
        self.notice_warn.setRange(1, 60)
        self.notice_warn.setValue(int(settings_service.get("notice_warning_days") or 7))
        f.addRow("Notice warning period (days)", self.notice_warn)
        self.scan_min = QSpinBox()
        self.scan_min.setRange(5, 720)
        self.scan_min.setValue(int(settings_service.get("reminder_scan_minutes") or 30))
        f.addRow("Background scan interval (minutes)", self.scan_min)
        self.desktop = QCheckBox("Show Windows desktop notifications")
        self.desktop.setChecked(bool(settings_service.get("desktop_notifications")))
        f.addRow("", self.desktop)
        v.addLayout(f)
        note = QLabel("Email and WhatsApp are optional channels configured in Settings › Email & WhatsApp. "
                      "Messages are never sent automatically - only when you click Send.")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        v.addWidget(note)
        b = button("💾 Save Reminder Configuration", "", self.save_config)
        b.setEnabled(auth_service.has_perm("settings.edit"))
        v.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
        v.addStretch(1)
        return w

    def save_config(self):
        offs = sorted([o for o, c in self.offset_checks.items() if c.isChecked()], reverse=True)
        if not offs:
            return error(self, "Select at least one reminder point.")
        settings_service.set_many({"reminder_offsets": offs, "notice_warning_days": self.notice_warn.value(),
                                   "reminder_scan_minutes": self.scan_min.value(),
                                   "desktop_notifications": self.desktop.isChecked()})
        info(self, "Reminder configuration saved. (Scan interval applies after restart.)")

    def refresh(self):
        i = self.tabs.currentIndex()
        if i == 0:
            if self.chk_active.isChecked():
                rows = reminder_engine.list_reminders(active_only=True, mine_only=self.chk_mine.isChecked())
            else:
                rows = reminder_engine.list_reminders(mine_only=self.chk_mine.isChecked())
            self.rows = rows
            self.table.set_rows(rows)
        elif i == 1:
            self.hist.set_rows(reminder_engine.history())

    def scan(self):
        n = run_safely(self, reminder_engine.scan)
        if n is not None:
            info(self, f"Reminder scan complete. {n} new reminder(s) created.")
            notify_changed("reminders")

    def _ids(self):
        ids = self.table.selected_ids()
        if not ids:
            info(self, "Select one or more reminders.")
        return ids

    def open_sel(self):
        r = self.table.current_row()
        if r:
            _open_ref(self.main, r)

    def snooze(self, d):
        ids = self._ids()
        if ids:
            reminder_engine.snooze(ids, d)
            notify_changed("reminders")

    def complete(self):
        ids = self._ids()
        if ids:
            reminder_engine.complete(ids)
            notify_changed("reminders")

    def dismiss(self):
        ids = self._ids()
        if ids:
            reminder_engine.dismiss(ids)
            notify_changed("reminders")

    def email(self):
        ids = self._ids()
        if not ids:
            return
        if not settings_service.get("email_enabled"):
            return error(self, "Email reminders are disabled. Enable and configure SMTP in Settings › Email & WhatsApp.")
        to_client = confirm(self, "Send to the CLIENT's email address?\n\nYes = client email\nNo = assigned staff email")
        pw, ok = QInputDialog.getText(self, "SMTP Password", "Enter the SMTP / app password (not stored):",
                                      QLineEdit.EchoMode.Password)
        if not ok or not pw:
            return
        res = run_safely(self, reminder_engine.send_email, ids, pw, to_client)
        if res:
            sent, errs = res
            info(self, f"Emails sent: {sent}" + ("\n\nNot sent:\n" + "\n".join(errs[:20]) if errs else ""))

    def whatsapp(self):
        r = self.table.current_row()
        if not r:
            return info(self, "Select a reminder.")
        url = run_safely(self, reminder_engine.whatsapp_url, r["id"])
        if url and confirm(self, "Open WhatsApp with a pre-filled message to the client?\n(You review and send it yourself.)"):
            webbrowser.open(url)
