"""Document repository UI: client/area/FY tree, drag-and-drop upload, preview,
versions, tagging, recycle (no hard delete)."""
from __future__ import annotations

import os

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, document_service, settings_service
from app.services.document_service import AREAS, DOCUMENT_CATEGORIES
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, button, confirm, error, info, notify_changed,
                            open_file_dialog, run_safely, section_label)
from app.utils.date_utils import fy_choices

COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("category", "Category"), ("area", "Area"),
           ("financial_year", "FY"), ("title", "Title"), ("file_name", "File Name"), ("file_type", "Type"),
           ("version", "Version"), ("size_kb", "Size (KB)"), ("tags", "Tags"), ("uploaded_by", "Uploaded By"),
           ("uploaded_at", "Uploaded On"), ("remarks", "Remarks")]
IMG = {".png", ".jpg", ".jpeg"}
TXT = {".txt", ".csv", ".xml", ".json"}


def upload_dialog(parent, files: list[str], client_id=None) -> int:
    if not auth_service.has_perm("documents.edit"):
        error(parent, "You do not have permission to upload documents.")
        return 0
    dlg = FormDialog(parent, f"Upload {len(files)} Document(s)" if files else "Upload Document", [("Upload", [
        Field("client_id", "Client", "client", required=True),
        Field("category", "Document Category", "combo", DOCUMENT_CATEGORIES, default="Other Documents"),
        Field("area", "Folder (Compliance Area)", "combo", list(AREAS.keys())[:7], default="General"),
        Field("financial_year", "Financial Year", "combo", [""] + fy_choices(back=6), default=settings_service.current_fy()),
        Field("title", "Title (blank = file name)"), Field("tags", "Tags (comma separated)"),
        Field("remarks", "Remarks", "multiline")] + ([] if files else [Field("file", "File", "file", required=True)]))],
        {"client_id": client_id, "category": "Other Documents", "area": "General",
         "financial_year": settings_service.current_fy()}, save_text="⬆ Upload")
    lbl = QLabel("Files: " + ", ".join(os.path.basename(f) for f in files)) if files else None
    if lbl:
        lbl.setWordWrap(True)
        dlg.layout().insertWidget(1, lbl)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return 0
    v = dlg.values
    paths = files or [v["file"]]
    n = 0
    for p in paths:
        res = run_safely(parent, document_service.store_file, p, client_id=v["client_id"], area=v["area"],
                         financial_year=v["financial_year"] or None, category=v["category"],
                         title=(v.get("title") if len(paths) == 1 else None), tags=v.get("tags") or "",
                         remarks=v.get("remarks") or "")
        n += 1 if res else 0
    if n:
        notify_changed("documents")
    return n


class PreviewDialog(QDialog):
    def __init__(self, parent, doc_id: int):
        super().__init__(parent)
        d = document_service.get_document(doc_id)
        self.d = d
        self.setWindowTitle(f"Preview - {d['file_name']}")
        self.resize(900, 700)
        v = QVBoxLayout(self)
        v.addWidget(section_label(f"{d['title']}  (v{d['version']})  •  {d['client_name']}  •  {d['category']}"))
        path = document_service.abs_path(d["stored_path"])
        ext = os.path.splitext(path)[1].lower()
        if not os.path.exists(path):
            w = QLabel("⚠ File not found on disk. Restore documents from backup.")
        elif ext in IMG:
            w = QScrollArea()
            lbl = QLabel()
            pm = QPixmap(path)
            if pm.width() > 1600:
                pm = pm.scaledToWidth(1600, Qt.TransformationMode.SmoothTransformation)
            lbl.setPixmap(pm)
            w.setWidget(lbl)
        elif ext in TXT:
            w = QPlainTextEdit()
            w.setReadOnly(True)
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    w.setPlainText(fh.read(200_000))
            except OSError as exc:
                w.setPlainText(str(exc))
        else:
            w = QLabel(f"Preview for .{ext.lstrip('.')} files opens in the default Windows application.\n\n{path}")
            w.setWordWrap(True)
        v.addWidget(w, 1)
        h = QHBoxLayout()
        h.addWidget(button("Open in default application", "", lambda: run_safely(self, document_service.open_path, path)))
        h.addStretch(1)
        h.addWidget(button("Close", "ghost", self.accept))
        v.addLayout(h)


def preview_document(parent, doc_id) -> None:
    PreviewDialog(parent, doc_id).exec()


class DropArea(QFrame):
    dropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setObjectName("Panel")
        self.setMinimumHeight(70)
        lay = QVBoxLayout(self)
        lbl = QLabel("⬇  Drag & drop PDF / Excel / Word / JPG / PNG files here to upload")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet("color: #7C3AED; font-weight: 700; font-size: 11pt;")
        lay.addWidget(lbl)
        self.setStyleSheet("QFrame#Panel { border: 2px dashed #C084FC; background: #FAF5FF; border-radius: 14px; }")

    def dragEnterEvent(self, e):  # noqa: N802
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):  # noqa: N802
        files = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile() and os.path.isfile(u.toLocalFile())]
        if files:
            self.dropped.emit(files)


class DocumentsPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Document Management", "Documents")
        can = auth_service.has_perm("documents.edit")
        self.add_header_button("⬆ Upload", lambda: upload_dialog(self, [], self._tree_client()), "pink", "", can)
        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.addWidget(section_label("Client Folders"))
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(lambda *_: self.load_docs())
        lv.addWidget(self.tree, 1)
        lv.addWidget(button("Show all documents", "ghost", self._clear_tree))
        split.addWidget(left)
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        self.drop = DropArea()
        self.drop.dropped.connect(lambda files: upload_dialog(self, files, self._tree_client()))
        self.drop.setEnabled(can)
        rv.addWidget(self.drop)
        bar = QHBoxLayout()
        for text, slot, kind, en in [("👁 Preview", self.preview, "", True), ("📂 Open", self.open, "ghost", True),
                                     ("⬆ New Version", self.new_version, "ghost", can),
                                     ("🕘 Versions", self.versions, "ghost", True),
                                     ("🏷 Tags / Remarks", self.meta, "ghost", can),
                                     ("💾 Download Copy", self.download, "ghost", True),
                                     ("🗑 Move to Recycle", self.delete, "danger", auth_service.has_perm("documents.delete")),
                                     ("♻ Restore", self.restore, "ghost", auth_service.has_perm("documents.delete")),
                                     ("📁 Open Client Folder", self.open_folder, "ghost", True)]:
            b = button(text, kind, slot)
            b.setEnabled(en)
            bar.addWidget(b)
        bar.addStretch(1)
        self.chk_deleted = QCheckBox("Show recycled")
        self.chk_deleted.toggled.connect(lambda _: self.load_docs())
        bar.addWidget(self.chk_deleted)
        rv.addLayout(bar)
        self.table = DataTable(COLUMNS, table_key="documents", filters=["category", "area", "financial_year", "file_type"],
                               export_title="Document Register")
        self.table.activated.connect(lambda i: preview_document(self, i))
        self.table.add_action("Preview", self.preview)
        self.table.add_action("Open in default app", self.open)
        self.table.add_action("Upload new version", self.new_version)
        self.table.add_action("Version history", self.versions)
        rv.addWidget(self.table, 1)
        split.addWidget(right)
        split.setSizes([260, 1000])
        self.root.addWidget(split, 1)

    def refresh(self):
        sel = self._tree_sel()
        self.tree.clear()
        tree = document_service.client_tree()
        from app.services import client_service
        known = {k[0] for k in tree}
        for label, cid in client_service.client_choices(active_only=False):
            if cid not in known:
                tree[(cid, label.rsplit(" [", 1)[0], label.rsplit("[", 1)[-1].rstrip("]"))] = {}
        for (cid, name, code), areas in sorted(tree.items(), key=lambda kv: kv[0][1]):
            top = QTreeWidgetItem([f"📁 {name} [{code}]"])
            top.setData(0, Qt.ItemDataRole.UserRole, (cid, None, None))
            for area, fys in sorted(areas.items()):
                a = QTreeWidgetItem([f"📂 {area}"])
                a.setData(0, Qt.ItemDataRole.UserRole, (cid, area, None))
                for fy in sorted(f for f in fys if f):
                    f = QTreeWidgetItem([f"🗂 FY {fy}"])
                    f.setData(0, Qt.ItemDataRole.UserRole, (cid, area, fy))
                    a.addChild(f)
                top.addChild(a)
            self.tree.addTopLevelItem(top)
        self.load_docs(sel)

    def _tree_sel(self):
        it = self.tree.currentItem()
        return it.data(0, Qt.ItemDataRole.UserRole) if it else None

    def _tree_client(self):
        s = self._tree_sel()
        return s[0] if s else None

    def _clear_tree(self):
        self.tree.setCurrentItem(None)
        self.tree.clearSelection()
        self.load_docs((None, None, None))

    def load_docs(self, sel=None):
        cid, area, fy = sel if sel else (self._tree_sel() or (None, None, None))
        rows = document_service.list_documents(client_id=cid, area=area, fy=fy,
                                               include_deleted=self.chk_deleted.isChecked())
        if self.chk_deleted.isChecked():
            rows = [r for r in rows if r["is_deleted"]]
        self.table.set_rows(rows)

    def _id(self):
        i = self.table.current_id()
        if i is None:
            info(self, "Please select a document.")
        return i

    def preview(self):
        i = self._id()
        if i:
            preview_document(self, i)

    def open(self):
        i = self._id()
        if i:
            run_safely(self, document_service.open_path, document_service.get_document(i)["stored_path"])

    def new_version(self):
        i = self._id()
        if not i:
            return
        p = open_file_dialog(self, "Select new version")
        if p:
            remarks = QInputDialog.getText(self, "Version Remarks", "Remarks for this version (optional):")[0]
            v = run_safely(self, document_service.add_version, i, p, remarks)
            if v:
                info(self, f"Version {v} uploaded. Earlier versions are preserved.")
                self.load_docs()

    def versions(self):
        i = self._id()
        if not i:
            return
        rows = document_service.list_versions(i)
        from app.ui.widgets import DrillDownDialog
        DrillDownDialog(self, "Version History", [("version", "Version"), ("uploaded_at", "Uploaded"),
                                                  ("uploaded_by", "By"), ("size_kb", "Size (KB)"),
                                                  ("remarks", "Remarks"), ("stored_path", "Path")], rows,
                        lambda vid: run_safely(self, document_service.open_path,
                                               next(r["stored_path"] for r in rows if r["_id"] == vid))).exec()

    def meta(self):
        i = self._id()
        if not i:
            return
        d = document_service.get_document(i)
        dlg = FormDialog(self, "Edit Document Details", [("Details", [
            Field("title", "Title"), Field("category", "Category", "combo", DOCUMENT_CATEGORIES),
            Field("tags", "Tags"), Field("remarks", "Remarks", "multiline")])], d)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            document_service.update_metadata(i, dlg.values)
            self.load_docs()

    def download(self):
        i = self._id()
        if not i:
            return
        folder = QFileDialog.getExistingDirectory(self, "Save a copy to folder")
        if folder:
            p = run_safely(self, document_service.copy_to, i, folder)
            if p:
                info(self, f"Copied to:\n{p}")

    def delete(self):
        i = self._id()
        if i and confirm(self, "Move this document to the recycle list?\n\nThe file is NOT erased from disk and can be "
                               "restored at any time ('Show recycled' → Restore)."):
            document_service.soft_delete(i)
            self.load_docs()

    def restore(self):
        i = self._id()
        if i:
            document_service.restore(i)
            self.load_docs()

    def open_folder(self):
        cid = self._tree_client()
        if not cid:
            r = self.table.current_row()
            cid = r["client_id"] if r else None
        if not cid:
            return run_safely(self, document_service.open_path, document_service.docs_root())
        run_safely(self, lambda: document_service.open_path(document_service.ensure_client_folders(cid)))
