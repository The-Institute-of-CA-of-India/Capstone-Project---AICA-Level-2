"""Client master UI: list, add/edit (with compliance applicability & contacts),
profile with full history, import/export, deactivate / safe delete."""
from __future__ import annotations

import os

import config
from app.qt import *  # noqa: F401,F403
from app.services import (auth_service, billing_service, client_service, collection_service, compliance_engine,
                          document_service, notice_service, settings_service, task_service)
from app.services.client_service import (BILLING_FREQUENCIES, ENTITY_TYPES, GST_FREQUENCIES, GST_REG_TYPES,
                                         GST_SCHEMES, GST_STATUSES, INDUSTRIES, ITR_FORMS, RISK_CATEGORIES)
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, button, confirm, error, info,
                            notify_changed, open_file_dialog, run_safely, save_file_dialog)
from app.utils.date_utils import fmt_date, fy_choices
from app.utils.formatters import inr
from app.utils.validators import (INDIAN_STATES, validate_cin_llpin, validate_client, validate_email,
                                  validate_gstin, validate_mobile, validate_pan, validate_pin, validate_tan)

LIST_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client Name"), ("entity_type", "Entity Type"),
                ("pan", "PAN"), ("gstin", "GSTIN"), ("tan", "TAN"), ("cin_llpin", "CIN / LLPIN"),
                ("city", "City"), ("mobile", "Mobile"), ("partner", "Partner"), ("manager", "Manager"),
                ("staff", "Staff"), ("risk_category", "Risk"), ("pending_compliances", "Pending"),
                ("status", "Status")]


def client_tabs() -> list:
    return [
        ("Basic Details", [
            Field("client_code", "Client ID", "label"),
            Field("client_name", "Client Name", required=True),
            Field("legal_name", "Legal Name"),
            Field("entity_type", "Entity Type", "combo", ENTITY_TYPES, required=True),
            Field("pan", "PAN", upper=True, validator=validate_pan, placeholder="ABCDE1234F"),
            Field("tan", "TAN", upper=True, validator=validate_tan, placeholder="ABCD12345E"),
            Field("gstin", "GSTIN", upper=True, validator=validate_gstin, placeholder="27ABCDE1234F1Z5"),
            Field("cin_llpin", "CIN / LLPIN", upper=True, validator=validate_cin_llpin),
            Field("date_of_incorporation", "Date of Incorporation / Birth", "date"),
            Field("industry", "Industry", "ecombo", [""] + INDUSTRIES),
            Field("nature_of_business", "Nature of Business", "multiline"),
            Field("status", "Client Status", "combo", ["Active", "Inactive"], default="Active"),
            Field("risk_category", "Risk Category", "combo", RISK_CATEGORIES, default="Medium"),
        ]),
        ("Address & Contact", [
            Field("address", "Registered Address", "multiline"),
            Field("city", "City"), Field("state", "State", "ecombo", [""] + INDIAN_STATES),
            Field("pin_code", "PIN Code", validator=validate_pin),
            Field("contact_person", "Contact Person"),
            Field("mobile", "Mobile Number", validator=validate_mobile),
            Field("email", "Email Address", validator=validate_email),
            Field("alternate_contact", "Alternate Contact"),
        ]),
        ("Engagement & Team", [
            Field("accounting_year", "Accounting Year", "ecombo", ["April-March", "January-December", "Other"],
                  default="April-March"),
            Field("financial_year", "Financial Year", "ecombo", fy_choices(), default=settings_service.current_fy()),
            Field("acquisition_date", "Client Acquisition Date", "date"),
            Field("assigned_partner_id", "Assigned Partner", "user"),
            Field("assigned_manager_id", "Assigned Manager", "user"),
            Field("assigned_staff_id", "Assigned Staff", "user"),
            Field("professional_fee", "Professional Fee (Annual)", "money"),
            Field("billing_frequency", "Billing Frequency", "combo", BILLING_FREQUENCIES, default="Annual"),
            Field("engagement_start", "Engagement Start Date", "date"),
            Field("engagement_end", "Engagement End Date", "date"),
            Field("notes", "Notes", "multiline"),
        ]),
        ("GST Profile", [
            Field("gst_registration_type", "GST Registration Type", "combo", GST_REG_TYPES, default="Not Registered"),
            Field("gst_scheme", "Regular / Composition", "combo", GST_SCHEMES, default="Regular"),
            Field("gst_frequency", "Monthly / Quarterly Filing", "combo", GST_FREQUENCIES, default="Monthly"),
            Field("gst_state", "GST State", "ecombo", [""] + INDIAN_STATES),
            Field("gst_registration_date", "GST Registration Date", "date"),
            Field("gst_status", "GST Status", "combo", GST_STATUSES, default="Not Applicable"),
            Field("gst_9c_applicable", "GSTR-9C applicable", "bool"),
            Field("gst_exporter_lut", "Exporter - LUT required", "bool"),
        ]),
        ("Income Tax & TDS", [
            Field("itr_form", "ITR Form", "combo", ITR_FORMS, tooltip="Blank = auto by entity type"),
            Field("tax_audit_applicable", "Tax Audit u/s 44AB applicable", "bool"),
            Field("transfer_pricing_applicable", "Transfer Pricing (3CEB) applicable", "bool"),
            Field("advance_tax_applicable", "Advance Tax applicable", "bool"),
            Field("charitable_registration", "Charitable Trust / Institution (10B etc.)", "bool"),
            Field("tds_applicable", "TDS applicable (has TAN)", "bool"),
            Field("tds_salary", "TDS on Salary (24Q)", "bool"),
            Field("tds_nonsalary", "TDS Non-Salary (26Q)", "bool"),
            Field("tds_nonresident", "TDS Non-Resident (27Q)", "bool"),
            Field("tcs_applicable", "TCS applicable (27EQ)", "bool"),
        ]),
        ("ROC / MCA", [
            Field("agm_date", "AGM Date (latest FY)", "date",
                  tooltip="Used for AOC-4 / MGT-7 / ADT-1 due dates when set"),
            Field("statutory_audit_applicable", "Statutory Audit applicable", "bool"),
            Field("small_company", "Small Company / OPC (MGT-7A)", "bool"),
            Field("xbrl_applicable", "XBRL filing applicable", "bool"),
            Field("msme_payables", "MSME payables > 45 days (MSME-1)", "bool"),
        ]),
    ]


class ApplicabilityWidget(QWidget):
    """Shows auto-applicability per compliance with manual override checkboxes."""

    def __init__(self, get_values, client_id=None):
        super().__init__()
        self.get_values = get_values
        self.client_id = client_id
        self.auto: dict[int, bool] = {}
        v = QVBoxLayout(self)
        note = QLabel("Ticked = applicable. The engine pre-selects compliances using the client profile "
                      "(entity type, GST registration, tax audit, TDS…). Tick / untick to override for this client. "
                      "Overrides are shown in <b style='color:#BE185D'>pink</b>.")
        note.setWordWrap(True)
        v.addWidget(note)
        h = QHBoxLayout()
        h.addWidget(button("⟳ Re-evaluate from profile", "ghost", self.reload))
        h.addWidget(button("Clear all overrides", "ghost", self.clear_overrides))
        h.addStretch(1)
        v.addLayout(h)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Compliance", "Form", "Periodicity", "Auto rule"])
        self.tree.setColumnWidth(0, 330)
        self.tree.itemChanged.connect(self._changed)
        v.addWidget(self.tree, 1)
        self._loaded = False
        self.overrides: dict[int, bool] = {}

    def showEvent(self, e):  # noqa: N802
        if not self._loaded:
            self.reload(initial=True)
        super().showEvent(e)

    def reload(self, initial: bool = False) -> None:
        vals = self.get_values()
        items = compliance_engine.applicability_preview(vals, self.client_id)
        if initial:
            self.overrides = {i["master_id"]: i["override"] for i in items if i["override"] is not None}
        self.tree.blockSignals(True)
        self.tree.clear()
        cats: dict[str, QTreeWidgetItem] = {}
        for it in items:
            parent = cats.get(it["category"])
            if parent is None:
                parent = QTreeWidgetItem([it["category"]])
                f = parent.font(0)
                f.setBold(True)
                parent.setFont(0, f)
                self.tree.addTopLevelItem(parent)
                cats[it["category"]] = parent
            self.auto[it["master_id"]] = it["auto"]
            state = self.overrides.get(it["master_id"], it["auto"])
            node = QTreeWidgetItem([it["name"], it["form"] or "", it["periodicity"], "Yes" if it["auto"] else "No"])
            node.setFlags(node.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            node.setCheckState(0, Qt.CheckState.Checked if state else Qt.CheckState.Unchecked)
            node.setData(0, Qt.ItemDataRole.UserRole, it["master_id"])
            self._paint(node)
            parent.addChild(node)
        self.tree.expandAll()
        self.tree.blockSignals(False)
        self._loaded = True

    def _paint(self, node) -> None:
        mid = node.data(0, Qt.ItemDataRole.UserRole)
        is_override = mid in self.overrides and self.overrides[mid] != self.auto.get(mid)
        node.setForeground(0, QColor("#BE185D" if is_override else "#1F2937"))

    def _changed(self, node, col) -> None:
        mid = node.data(0, Qt.ItemDataRole.UserRole)
        if mid is None:
            return
        checked = node.checkState(0) == Qt.CheckState.Checked
        if checked == self.auto.get(mid):
            self.overrides.pop(mid, None)
        else:
            self.overrides[mid] = checked
        self.tree.blockSignals(True)
        self._paint(node)
        self.tree.blockSignals(False)

    def clear_overrides(self) -> None:
        self.overrides = {}
        self.reload()

    def result(self) -> dict:
        if not self._loaded:
            self.reload(initial=True)
        return {mid: val for mid, val in self.overrides.items() if val != self.auto.get(mid)}


class ContactsWidget(QWidget):
    def __init__(self, contacts=None):
        super().__init__()
        v = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Name", "Designation", "Mobile", "Email", "Primary (Y/N)"])
        self.table.horizontalHeader().setStretchLastSection(True)
        v.addWidget(self.table, 1)
        h = QHBoxLayout()
        h.addWidget(button("＋ Add contact", "ghost", self.add_row))
        h.addWidget(button("✖ Remove selected", "ghost", self.remove_row))
        h.addStretch(1)
        v.addLayout(h)
        for c in contacts or []:
            self.add_row(c)

    def add_row(self, c=None) -> None:
        c = c or {}
        r = self.table.rowCount()
        self.table.insertRow(r)
        for i, k in enumerate(("name", "designation", "mobile", "email")):
            self.table.setItem(r, i, QTableWidgetItem(c.get(k) or ""))
        self.table.setItem(r, 4, QTableWidgetItem("Y" if c.get("is_primary") else "N"))

    def remove_row(self) -> None:
        for r in sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True):
            self.table.removeRow(r)

    def result(self) -> list[dict]:
        out = []
        for r in range(self.table.rowCount()):
            get = lambda c: (self.table.item(r, c).text().strip() if self.table.item(r, c) else "")  # noqa: E731
            out.append({"name": get(0), "designation": get(1), "mobile": get(2), "email": get(3),
                        "is_primary": get(4).upper().startswith("Y")})
        return out


def _client_dialog(parent, client_id=None) -> bool:
    values = client_service.get_client(client_id) if client_id else None
    holder = {}
    appl = ApplicabilityWidget(lambda: holder["dlg"].get_values(), client_id)
    contacts = ContactsWidget(values.get("contacts") if values else [])
    pan_confirmed = {"ok": False}

    def validate(vals):
        errs, warns = validate_client(vals)
        if errs:
            return errs
        d = client_service.find_duplicates(vals.get("pan"), vals.get("gstin"), vals.get("tan"), client_id)
        if d["gstin"]:
            return [f"Duplicate GSTIN - already used by {', '.join(d['gstin'])}."]
        msgs = []
        if d["pan"]:
            msgs.append(f"PAN already exists for: {', '.join(d['pan'])}")
        if d["tan"]:
            msgs.append(f"TAN already exists for: {', '.join(d['tan'])}")
        msgs += warns
        if msgs and not pan_confirmed["ok"]:
            if not confirm(holder["dlg"], "Please review:\n\n• " + "\n• ".join(msgs) + "\n\nSave anyway?"):
                return ["Save cancelled - please review the warnings."]
            pan_confirmed["ok"] = True
        return None

    dlg = FormDialog(parent, "Edit Client" if client_id else "Add New Client", client_tabs(), values,
                     on_validate=validate, extra_tabs=[("Applicable Compliances", appl), ("Contacts", contacts)],
                     width=900)
    holder["dlg"] = dlg
    dlg.resize(940, 680)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return False
    vals = dlg.values
    try:
        cid = client_service.save_client(vals, client_id, applicability_overrides=appl.result(),
                                         contacts=contacts.result(), allow_duplicate_pan=True)
    except Exception as exc:  # noqa: BLE001
        error(parent, str(exc))
        return False
    if not client_id:
        summary = run_safely(parent, client_service.onboard_client, cid)
        if summary:
            info(parent, f"Client saved and onboarded.\n\n• {summary['compliances']} compliance records generated\n"
                         f"• {summary['checklist_items']} document checklist items created\n"
                         f"• Onboarding task created\n• {summary['reminders']} reminders activated")
    else:
        if confirm(parent, "Client updated.\n\nGenerate any newly applicable compliance records for the current FY now?"):
            n = run_safely(parent, compliance_engine.generate_for_client, cid, settings_service.current_fy())
            if n is not None:
                info(parent, f"{n} new compliance record(s) generated.")
    notify_changed("clients")
    return True


def add_client(parent) -> bool:
    return _client_dialog(parent, None)


def edit_client(parent, client_id) -> bool:
    return _client_dialog(parent, client_id)


# ------------------------------------------------------------------ profile
class ClientProfileDialog(QDialog):
    def __init__(self, main, client_id: int):
        super().__init__(main)
        self.main = main
        self.client_id = client_id
        self.resize(1250, 760)
        v = QVBoxLayout(self)
        self.header = QLabel()
        self.header.setTextFormat(Qt.TextFormat.RichText)
        self.header.setWordWrap(True)
        v.addWidget(self.header)
        bar = QHBoxLayout()
        b = button("✏ Edit Client", "", self.edit)
        b.setEnabled(auth_service.has_perm("clients.edit"))
        bar.addWidget(b)
        bar.addWidget(button("⚙ Generate Compliances (FY)", "ghost", self.generate))
        bar.addWidget(button("📁 Open Client Folder", "ghost", self.open_folder))
        bar.addWidget(button("📄 Export Profile PDF", "pink", self.export_pdf))
        bar.addWidget(button("📝 Export Profile Word", "ghost", self.export_word))
        bar.addStretch(1)
        bar.addWidget(button("Close", "ghost", self.accept))
        v.addLayout(bar)
        self.tabs = QTabWidget()
        v.addWidget(self.tabs, 1)
        self.overview = QTextBrowser()
        self.tabs.addTab(self.overview, "Overview")
        self.t_comp = DataTable([("financial_year", "FY"), ("category", "Category"), ("compliance_name", "Compliance"),
                                 ("tax_period", "Period"), ("due", "Due"), ("status", "Status"),
                                 ("filing_date", "Filed On"), ("ack_number", "Ack No."), ("delay_days", "Delay"),
                                 ("staff", "Staff")], filters=["financial_year", "category", "status"],
                                export_title="Client Compliance History")
        self.t_comp.activated.connect(lambda i: self._open("compliance", i))
        self.tabs.addTab(self.t_comp, "Compliance History")
        self.t_not = DataTable([("notice_code", "ID"), ("category", "Category"), ("section", "Section"),
                                ("notice_number", "Notice No."), ("receipt_date", "Received"),
                                ("reply_due_date", "Reply Due"), ("status", "Status"), ("demand_amount", "Demand")],
                               money=["demand_amount"], export_title="Client Notices")
        self.t_not.activated.connect(lambda i: self._open("notice", i))
        self.tabs.addTab(self.t_not, "Notices")
        self.t_docs = DataTable([("category", "Category"), ("area", "Area"), ("financial_year", "FY"),
                                 ("title", "Title"), ("file_name", "File"), ("version", "Ver"),
                                 ("uploaded_at", "Uploaded")], export_title="Client Documents")
        self.t_docs.activated.connect(lambda i: self._open("document", i))
        self.tabs.addTab(self.t_docs, "Documents")
        self.t_tasks = DataTable([("task_code", "ID"), ("title", "Task"), ("assigned_to", "Staff"),
                                  ("due_date", "Due"), ("priority", "Priority"), ("status", "Status")],
                                 export_title="Client Tasks")
        self.t_tasks.activated.connect(lambda i: self._open("task", i))
        self.tabs.addTab(self.t_tasks, "Tasks")
        self.t_bill = DataTable([("invoice_number", "Invoice"), ("invoice_date", "Date"), ("total_amount", "Total"),
                                 ("paid", "Paid"), ("outstanding", "Outstanding"), ("status", "Status")],
                                money=["total_amount", "paid", "outstanding"], export_title="Client Billing")
        self.tabs.addTab(self.t_bill, "Billing")
        self.t_col = DataTable([("compliance", "Compliance"), ("period", "Period"), ("document_name", "Document"),
                                ("received", "Status"), ("received_date", "Received On"),
                                ("follow_up_date", "Follow-up")], export_title="Client Document Collection")
        self.tabs.addTab(self.t_col, "Document Collection")
        self.load()

    def _open(self, kind, rid):
        self.main.open_record(kind, rid)
        self.load()

    def load(self) -> None:
        c = client_service.get_client(self.client_id)
        self.c = c
        self.setWindowTitle(f"Client Profile - {c['client_name']}")
        badge = "#16A34A" if c["status"] == "Active" else "#6B7280"
        self.header.setText(
            f"<span style='font-size:18pt;font-weight:800;color:#4C1D95'>{c['client_name']}</span> "
            f"&nbsp;<span style='background:{badge};color:white;padding:2px 8px;border-radius:8px'>&nbsp;{c['status']}&nbsp;</span>"
            f"<br><span style='color:#6B7280'>{c['client_code']} • {c['entity_type']} • PAN {c['pan'] or '-'} • "
            f"GSTIN {c['gstin'] or '-'} • TAN {c['tan'] or '-'} • CIN/LLPIN {c['cin_llpin'] or '-'}</span>")
        pairs = self._pairs(c)
        html = "<table cellpadding='5' style='font-size:10pt'>" + "".join(
            f"<tr><td style='color:#6D28D9;font-weight:600'>{k}</td><td>{v}</td></tr>" for k, v in pairs) + "</table>"
        if c.get("contacts"):
            html += "<h3 style='color:#BE185D'>Contacts</h3><ul>" + "".join(
                f"<li>{x['name']} ({x['designation'] or '-'}) {x['mobile'] or ''} {x['email'] or ''}"
                f"{' ★' if x['is_primary'] else ''}</li>" for x in c["contacts"]) + "</ul>"
        self.overview.setHtml(html)
        self.t_comp.set_rows(compliance_engine.list_records({"client_id": self.client_id, "active_clients_only": False}))
        self.t_not.set_rows(notice_service.list_notices({"client_id": self.client_id}))
        self.t_docs.set_rows(document_service.list_documents(client_id=self.client_id))
        self.t_tasks.set_rows(task_service.list_tasks({"client_id": self.client_id}))
        self.t_bill.set_rows(billing_service.list_invoices(client_id=self.client_id) if auth_service.has_perm("billing.view") else [])
        self.t_col.set_rows(collection_service.list_status(client_id=self.client_id, include_closed=True))

    @staticmethod
    def _pairs(c):
        yn = lambda b: "Yes" if b else "No"  # noqa: E731
        return [("Legal Name", c["legal_name"] or ""), ("Date of Incorporation", fmt_date(c["date_of_incorporation"])),
                ("Address", f"{c['address'] or ''}, {c['city'] or ''}, {c['state'] or ''} {c['pin_code'] or ''}"),
                ("Contact", f"{c['contact_person'] or ''} • {c['mobile'] or ''} • {c['email'] or ''}"),
                ("Industry", f"{c['industry'] or ''} - {c['nature_of_business'] or ''}"),
                ("Team", f"Partner: {c['partner']} • Manager: {c['manager']} • Staff: {c['staff']}"),
                ("Engagement", f"{fmt_date(c['engagement_start'])} to {fmt_date(c['engagement_end'])} • "
                               f"Fee {inr(c['professional_fee'])} ({c['billing_frequency'] or '-'})"),
                ("Risk Category", c["risk_category"] or ""),
                ("GST", f"{c['gst_registration_type']} • {c['gst_scheme']} • {c['gst_frequency']} • {c['gst_status']}"),
                ("Income Tax", f"{c['itr_form'] or '-'} • Tax audit: {yn(c['tax_audit_applicable'])} • "
                               f"Advance tax: {yn(c['advance_tax_applicable'])} • TP: {yn(c['transfer_pricing_applicable'])}"),
                ("TDS / TCS", f"TDS: {yn(c['tds_applicable'])} (24Q {yn(c['tds_salary'])}, 26Q {yn(c['tds_nonsalary'])}, "
                              f"27Q {yn(c['tds_nonresident'])}) • TCS: {yn(c['tcs_applicable'])}"),
                ("ROC", f"AGM: {fmt_date(c['agm_date'])} • Stat audit: {yn(c['statutory_audit_applicable'])} • "
                        f"Small co.: {yn(c['small_company'])}"), ("Notes", c["notes"] or "")]

    def edit(self):
        if edit_client(self, self.client_id):
            self.load()

    def generate(self):
        n = run_safely(self, compliance_engine.generate_for_client, self.client_id, settings_service.current_fy())
        if n is not None:
            info(self, f"{n} new compliance record(s) generated for FY {settings_service.current_fy()}.")
            self.load()

    def open_folder(self):
        run_safely(self, lambda: document_service.open_path(document_service.ensure_client_folders(self.client_id)))

    def export_pdf(self):
        from app.utils.pdf_utils import export_sections_pdf
        path = save_file_dialog(self, "Export Client Profile", f"Client_Profile_{self.c['client_code']}.pdf", "PDF (*.pdf)")
        if not path:
            return
        secs = [("Compliance History", self.t_comp.columns, self.t_comp.rows()),
                ("Notices", self.t_not.columns, self.t_not.rows()),
                ("Tasks", self.t_tasks.columns, self.t_tasks.rows()),
                ("Billing", self.t_bill.columns, self.t_bill.rows())]
        pairs = [("Client ID", self.c["client_code"]), ("Entity", self.c["entity_type"]), ("PAN", self.c["pan"]),
                 ("GSTIN", self.c["gstin"]), ("TAN", self.c["tan"]), ("CIN/LLPIN", self.c["cin_llpin"])] + self._pairs(self.c)
        if run_safely(self, export_sections_pdf, path, f"Client Profile - {self.c['client_name']}",
                      settings_service.firm_name(), pairs, secs, ["total_amount", "paid", "outstanding", "demand_amount"]):
            if confirm(self, "PDF created. Open it now?"):
                run_safely(self, document_service.open_path, path)

    def export_word(self):
        try:
            from docx import Document as Docx
        except ImportError:
            return error(self, "python-docx is not installed. Run: pip install python-docx")
        path = save_file_dialog(self, "Export Client Profile", f"Client_Profile_{self.c['client_code']}.docx", "Word (*.docx)")
        if not path:
            return
        doc = Docx()
        doc.add_heading(settings_service.firm_name(), 1)
        doc.add_heading(f"Client Profile - {self.c['client_name']}", 2)
        t = doc.add_table(rows=0, cols=2)
        t.style = "Light Grid Accent 1"
        for k, v in [("Client ID", self.c["client_code"]), ("PAN", self.c["pan"]), ("GSTIN", self.c["gstin"])] + self._pairs(self.c):
            row = t.add_row().cells
            row[0].text, row[1].text = str(k), str(v or "")
        doc.add_heading("Pending Compliances", 3)
        pend = [r for r in self.t_comp.rows() if r["status"] not in compliance_engine.DONE_STATUSES]
        tb = doc.add_table(rows=1, cols=4)
        tb.style = "Light Grid Accent 1"
        for i, h in enumerate(["Compliance", "Period", "Due", "Status"]):
            tb.rows[0].cells[i].text = h
        for r in pend[:200]:
            cells = tb.add_row().cells
            cells[0].text, cells[1].text, cells[2].text, cells[3].text = (
                r["compliance_name"], r["tax_period"] or "", fmt_date(r["due"]), r["status"])
        if run_safely(self, doc.save, path) is None and os.path.exists(path):
            if confirm(self, "Word document created. Open it now?"):
                run_safely(self, document_service.open_path, path)


def open_client_profile(main, client_id) -> None:
    ClientProfileDialog(main, client_id).exec()
    notify_changed("clients")


# ------------------------------------------------------------------ page
class ClientsPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Client Master", "Clients")
        can_edit = auth_service.has_perm("clients.edit")
        can_imp = auth_service.has_perm("clients.import")
        self.add_header_button("＋ Add Client", lambda: add_client(self), "pink", "Ctrl+N", can_edit)
        self.add_header_button("⬆ Import Excel", self.import_excel, "ghost", "", can_imp)
        self.add_header_button("⬇ Export Excel", self.export_excel, "ghost", "", can_imp)
        self.add_header_button("📄 Import Template", self.template, "ghost", "", can_imp)
        bar = QHBoxLayout()
        self.b_edit = button("✏ Edit", "", self.edit)
        self.b_edit.setEnabled(can_edit)
        bar.addWidget(self.b_edit)
        bar.addWidget(button("👁 Profile", "", self.profile))
        self.b_status = button("⏯ Activate / Deactivate", "ghost", self.toggle_status)
        self.b_status.setEnabled(auth_service.has_perm("clients.delete"))
        bar.addWidget(self.b_status)
        self.b_del = button("🗑 Delete", "danger", self.delete)
        self.b_del.setEnabled(auth_service.has_perm("clients.delete"))
        bar.addWidget(self.b_del)
        b = button("⚙ Generate Compliances", "ghost", self.generate)
        b.setEnabled(auth_service.has_perm("compliance.review"))
        bar.addWidget(b)
        bar.addStretch(1)
        self.root.addLayout(bar)
        self.table = DataTable(LIST_COLUMNS, table_key="clients",
                               filters=["entity_type", "status", "staff", "manager", "risk_category"],
                               export_title="Client Master")
        self.table.activated.connect(lambda i: open_client_profile(self.main, i))
        self.table.add_action("Open profile", self.profile)
        self.table.add_action("Edit client", self.edit)
        self.table.add_action("Activate / Deactivate", self.toggle_status)
        self.table.add_action("Open client folder", self.open_folder)
        self.root.addWidget(self.table, 1)

    def refresh(self) -> None:
        self.table.set_rows(client_service.list_clients())

    def apply_preset(self, **kw) -> None:
        if kw.get("status"):
            self.table.set_filter("status", kw["status"])

    def _cid(self):
        cid = self.table.current_id()
        if cid is None:
            info(self, "Please select a client first.")
        return cid

    def edit(self):
        cid = self._cid()
        if cid:
            edit_client(self, cid)

    def profile(self):
        cid = self._cid()
        if cid:
            open_client_profile(self.main, cid)

    def open_folder(self):
        cid = self._cid()
        if cid:
            run_safely(self, lambda: document_service.open_path(document_service.ensure_client_folders(cid)))

    def toggle_status(self):
        cid = self._cid()
        if not cid:
            return
        c = client_service.get_client(cid)
        new = "Inactive" if c["status"] == "Active" else "Active"
        if confirm(self, f"Mark '{c['client_name']}' as {new}?\n\nInactive clients are hidden from new compliance "
                         "generation; all history is preserved."):
            run_safely(self, client_service.set_status, cid, new)
            notify_changed("clients")

    def delete(self):
        cid = self._cid()
        if not cid:
            return
        c = client_service.get_client(cid)
        if not confirm(self, f"Permanently delete '{c['client_name']}'?\n\nThis is only allowed when no compliance, "
                             "document, notice, task or invoice is linked. Otherwise deactivate the client."):
            return
        ok, msg = client_service.delete_client(cid)
        (info if ok else error)(self, msg)
        notify_changed("clients")

    def generate(self):
        fy = settings_service.current_fy()
        ids = self.table.selected_ids()
        if ids:
            total = sum(compliance_engine.generate_for_client(i, fy) for i in ids)
        elif confirm(self, f"No client selected. Generate compliances for ALL active clients for FY {fy}?"):
            total = run_safely(self, compliance_engine.generate_for_all, fy) or 0
        else:
            return
        info(self, f"{total} new compliance record(s) generated for FY {fy}.\nExisting entries are never duplicated.")
        notify_changed("compliance")

    def import_excel(self):
        path = open_file_dialog(self, "Import Clients", "Excel / CSV (*.xlsx *.xls *.csv)")
        if not path:
            return
        allow = confirm(self, "Allow importing clients whose PAN already exists?\n\n(Duplicate GSTINs are always rejected.)")
        rep = run_safely(self, client_service.import_clients, path, allow, True)
        if rep:
            msg = f"Imported: {rep['imported']}\nSkipped: {rep['skipped']}"
            if rep["errors"]:
                msg += "\n\nDetails:\n" + "\n".join(rep["errors"][:30])
            info(self, msg, "Import Result")
            notify_changed("clients")

    def export_excel(self):
        path = save_file_dialog(self, "Export Clients", "Client_Master.xlsx", "Excel (*.xlsx)")
        if path and run_safely(self, client_service.export_clients, path):
            if confirm(self, "Client master exported. Open the file now?"):
                run_safely(self, document_service.open_path, path)

    def template(self):
        from app.utils.excel_utils import write_client_template
        path = save_file_dialog(self, "Save Import Template", "Client_Import_Template.xlsx", "Excel (*.xlsx)")
        if path and run_safely(self, write_client_template, path, ENTITY_TYPES):
            if confirm(self, "Template saved. Open it now?"):
                run_safely(self, document_service.open_path, path)
