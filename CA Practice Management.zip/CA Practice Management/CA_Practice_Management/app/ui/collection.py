"""Client document collection tracker UI (Workflow 4) and checklist editor."""
from __future__ import annotations

from datetime import timedelta

from app.qt import *  # noqa: F401,F403
from app.services import auth_service, collection_service, compliance_engine, settings_service
from app.ui.widgets import (BasePage, DataTable, Field, FormDialog, SearchCombo, button, confirm, info,
                            notify_changed, run_safely, section_label)
from app.utils.date_utils import today

COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("compliance", "Compliance"), ("period", "Period"),
           ("due", "Compliance Due"), ("document_name", "Document"), ("mandatory", "Mandatory"),
           ("received", "Status"), ("received_date", "Received On"), ("follow_up_staff", "Follow-up Staff"),
           ("follow_up_date", "Follow-up Date"), ("remarks", "Remarks")]


class ChecklistEditor(QDialog):
    """Edit firm-wide or client-specific required documents for a compliance type."""

    def __init__(self, parent, master_id=None, client_id=None):
        super().__init__(parent)
        self.setWindowTitle("Customise Document Checklist")
        self.resize(720, 560)
        v = QVBoxLayout(self)
        f = QFormLayout()
        self.master = QComboBox()
        for m in compliance_engine.list_masters(active_only=True):
            self.master.addItem(f"{m['category']} - {m['name']}", m["id"])
        if master_id:
            self.master.setCurrentIndex(max(0, self.master.findData(master_id)))
        from app.services.client_service import client_choices
        self.client = SearchCombo(client_choices(active_only=False), "(Firm-wide template - all clients)")
        self.client.setValue(client_id)
        f.addRow("Compliance", self.master)
        f.addRow("Applies to", self.client)
        v.addLayout(f)
        note = QLabel("A client-specific checklist replaces the firm-wide template for that client. "
                      "Leave the client blank to edit the firm-wide template.")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        v.addWidget(note)
        self.list = QTableWidget(0, 2)
        self.list.setHorizontalHeaderLabels(["Document Name", "Mandatory (Y/N)"])
        self.list.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.list, 1)
        h = QHBoxLayout()
        h.addWidget(button("＋ Add", "ghost", lambda: self._add({})))
        h.addWidget(button("✖ Remove", "ghost", self._remove))
        h.addWidget(button("Copy firm-wide template", "ghost", self._copy_firm))
        h.addStretch(1)
        h.addWidget(button("Cancel", "ghost", self.reject))
        h.addWidget(button("💾 Save Checklist", "", self._save))
        v.addLayout(h)
        self.master.currentIndexChanged.connect(lambda _: self._load())
        self.client.currentIndexChanged.connect(lambda _: self._load())
        self._load()

    def _add(self, it):
        r = self.list.rowCount()
        self.list.insertRow(r)
        self.list.setItem(r, 0, QTableWidgetItem(it.get("document_name", "")))
        self.list.setItem(r, 1, QTableWidgetItem("Y" if it.get("is_mandatory", True) else "N"))

    def _remove(self):
        for r in sorted({i.row() for i in self.list.selectedIndexes()}, reverse=True):
            self.list.removeRow(r)

    def _load(self):
        self.list.setRowCount(0)
        for it in collection_service.list_checklist(self.master.currentData(), self.client.value()):
            self._add(it)

    def _copy_firm(self):
        self.list.setRowCount(0)
        for it in collection_service.list_checklist(self.master.currentData(), None):
            self._add(it)

    def _save(self):
        items = []
        for r in range(self.list.rowCount()):
            name = self.list.item(r, 0).text().strip() if self.list.item(r, 0) else ""
            mand = self.list.item(r, 1).text().strip().upper() if self.list.item(r, 1) else "Y"
            if name:
                items.append({"document_name": name, "is_mandatory": not mand.startswith("N")})
        run_safely(self, collection_service.save_checklist, self.master.currentData(), items, self.client.value())
        self.accept()


class CollectionPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Client Document Collection", "Document Collection")
        self.add_header_button("✎ Customise Checklists", lambda: ChecklistEditor(self).exec(), "ghost", "",
                               auth_service.has_perm("compliance.review"))
        self.tabs = QTabWidget()
        self.root.addWidget(self.tabs, 1)
        w = QWidget()
        v = QVBoxLayout(w)
        top = QHBoxLayout()
        self.pending_only = QCheckBox("Pending only")
        self.pending_only.setChecked(True)
        self.pending_only.toggled.connect(lambda _: self.refresh())
        top.addWidget(self.pending_only)
        for text, slot, kind in [("✔ Mark Received", lambda: self.mark(True), "success"),
                                 ("✖ Mark Not Received", lambda: self.mark(False), "ghost"),
                                 ("📅 Set Follow-up", self.follow, "ghost"),
                                 ("⚙ Generate Follow-up Tasks", self.tasks, "pink"),
                                 ("⟳ Build Checklists (upcoming)", self.build, "ghost")]:
            top.addWidget(button(text, kind, slot))
        top.addStretch(1)
        v.addLayout(top)
        self.table = DataTable(COLUMNS, table_key="collection",
                               filters=["client_name", "compliance", "received", "follow_up_staff"],
                               export_title="Pending Documents from Clients")
        self.table.activated.connect(lambda i: self.mark(True))
        self.table.add_action("Mark received", lambda: self.mark(True))
        self.table.add_action("Set follow-up", self.follow)
        v.addWidget(self.table, 1)
        self.tabs.addTab(w, "Checklist Status")
        self.progress = DataTable([("client_code", "Client ID"), ("client_name", "Client"), ("total", "Required"),
                                   ("received", "Received"), ("pending", "Pending"), ("progress_text", "Progress")],
                                  export_title="Document Collection Progress")
        self.progress.activated.connect(lambda cid: self.main.open_record("client", cid))
        self.tabs.addTab(self.progress, "Client-wise Progress %")
        self.tabs.currentChanged.connect(lambda _: self.refresh())

    def refresh(self):
        if self.tabs.currentIndex() == 0:
            self.table.set_rows(collection_service.list_status(pending_only=self.pending_only.isChecked()))
        else:
            self.progress.set_rows(collection_service.progress_by_client())

    def _ids(self):
        ids = self.table.selected_ids()
        if not ids:
            info(self, "Select one or more documents.")
        return ids

    def mark(self, received: bool):
        ids = self._ids()
        if not ids:
            return
        d = today()
        if received:
            dlg = FormDialog(self, "Mark Received", [("Received", [
                Field("date", "Received Date", "date", required=True, default=today()),
                Field("remarks", "Remarks")])], {"date": today()}, save_text="✔ Mark Received")
            if dlg.exec() != QDialog.DialogCode.Accepted:
                return
            d = dlg.values["date"]
            collection_service.mark_received(ids, True, d, dlg.values.get("remarks") or "")
        else:
            collection_service.mark_received(ids, False)
        notify_changed("collection")

    def follow(self):
        ids = self._ids()
        if not ids:
            return
        dlg = FormDialog(self, "Set Follow-up", [("Follow-up", [
            Field("staff", "Staff responsible", "user"),
            Field("date", "Follow-up Date", "date", default=today() + timedelta(days=2)),
            Field("remarks", "Remarks")])], {"date": today() + timedelta(days=2)})
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.values
            collection_service.set_follow_up(ids, v.get("staff"), v.get("date"), v.get("remarks") or "")
            notify_changed("collection")

    def tasks(self):
        ids = self.table.selected_ids()
        scope = f"{len(ids)} selected item(s)" if ids else "ALL pending documents"
        if confirm(self, f"Generate follow-up tasks for {scope}?\nOne task is created per client & compliance "
                         "(skipped if an open follow-up task already exists)."):
            n = run_safely(self, collection_service.generate_followup_tasks, ids or None)
            if n is not None:
                info(self, f"{n} follow-up task(s) created and assigned.")
                notify_changed("tasks")

    def build(self):
        days = int(settings_service.get("checklist_upcoming_days") or 45)
        n = run_safely(self, collection_service.ensure_upcoming, days)
        if n is not None:
            info(self, f"{n} checklist item(s) created for compliances due within {days} days.")
            self.refresh()
