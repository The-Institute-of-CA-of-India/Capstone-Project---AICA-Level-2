"""Interactive dashboard: KPI cards (click to drill down), schedules, chart."""
from __future__ import annotations

from datetime import timedelta

from app.qt import *  # noqa: F401,F403
from app.services import (compliance_engine, notice_service, reporting_service, settings_service,
                          task_service)
from app.services.audit_service import recent_activities
from app.ui.widgets import BarChart, BasePage, DataTable, DrillDownDialog, KpiCard, panel
from app.utils.date_utils import today

KPIS = [
    ("total_clients", "Total Clients", "👥"), ("active_clients", "Active Clients", "✅"),
    ("inactive_clients", "Inactive Clients", "💤"), ("due_today", "Compliance Due Today", "⏰"),
    ("due_7", "Due within 7 Days", "📆"), ("due_15", "Due within 15 Days", "🗓"),
    ("overdue", "Overdue Compliances", "🚨"), ("notices_pending", "Notices Pending Reply", "📨"),
    ("notices_near", "Notice Deadlines Near", "⚠"), ("tasks_pending", "Tasks Pending", "📝"),
    ("tasks_overdue", "Tasks Overdue", "⛔"), ("docs_pending", "Documents Pending", "📂"),
    ("completed_month", "Completed This Month", "🏆"), ("completion_pct", "FY Completion %", "📈"),
]


class DashboardPage(BasePage):
    def __init__(self, main):
        super().__init__(main, "Dashboard", "Dashboard")
        self.add_header_button("⟳ Refresh", self.refresh, "ghost", "Refresh (F5)")
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        body.setObjectName("Page")
        v = QVBoxLayout(body)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(14)
        legend = QLabel("<span style='color:#16A34A'>■ Completed</span> &nbsp; <span style='color:#2563EB'>■ In Progress"
                        "</span> &nbsp; <span style='color:#CA8A04'>■ Due Soon</span> &nbsp; <span style='color:#DC2626'>"
                        "■ Overdue</span> &nbsp; <span style='color:#6B7280'>■ Not Started</span>")
        v.addWidget(legend)
        grid = QGridLayout()
        grid.setSpacing(12)
        self.cards: dict[str, KpiCard] = {}
        for i, (key, title, icon) in enumerate(KPIS):
            c = KpiCard(key, title, icon, i)
            c.clicked.connect(self.drill)
            self.cards[key] = c
            grid.addWidget(c, i // 7, i % 7)
        v.addLayout(grid)

        row1 = QHBoxLayout()
        p, lay = panel("⏰ Today's Compliance Schedule")
        self.t_today = DataTable([("client_name", "Client"), ("compliance_name", "Compliance"), ("tax_period", "Period"),
                                  ("status", "Status"), ("staff", "Staff")], export_title="Today's Schedule",
                                 page_size=50, compact=True)
        self.t_today.activated.connect(lambda i: self._open("compliance", i))
        lay.addWidget(self.t_today)
        row1.addWidget(p, 1)
        p, lay = panel("📆 Upcoming Deadlines (15 days)")
        self.t_up = DataTable([("due", "Due"), ("client_name", "Client"), ("compliance_name", "Compliance"),
                               ("tax_period", "Period"), ("days_left", "Days"), ("status", "Status")],
                              export_title="Upcoming Deadlines", page_size=50, compact=True)
        self.t_up.activated.connect(lambda i: self._open("compliance", i))
        lay.addWidget(self.t_up)
        row1.addWidget(p, 1)
        v.addLayout(row1)

        row2 = QHBoxLayout()
        p, lay = panel("🚨 Overdue Compliance")
        self.t_over = DataTable([("due", "Due"), ("client_name", "Client"), ("compliance_name", "Compliance"),
                                 ("tax_period", "Period"), ("delay_days", "Delay"), ("staff", "Staff")],
                                export_title="Overdue Compliance", page_size=50, compact=True)
        self.t_over.activated.connect(lambda i: self._open("compliance", i))
        lay.addWidget(self.t_over)
        row2.addWidget(p, 1)
        p, lay = panel("📊 Monthly Compliance Completion (FY)")
        self.chart = BarChart()
        lay.addWidget(self.chart)
        row2.addWidget(p, 1)
        v.addLayout(row2)

        row3 = QHBoxLayout()
        p, lay = panel("📝 Pending Tasks")
        self.t_tasks = DataTable([("due_date", "Due"), ("title", "Task"), ("client_name", "Client"),
                                  ("priority", "Priority"), ("status", "Status"), ("assigned_to", "Staff")],
                                 export_title="Pending Tasks", page_size=50, compact=True)
        self.t_tasks.activated.connect(lambda i: self._open("task", i))
        lay.addWidget(self.t_tasks)
        row3.addWidget(p, 1)
        p, lay = panel("📨 Notice Tracker")
        self.t_notice = DataTable([("reply_due_date", "Reply Due"), ("days_left", "Days"), ("client_name", "Client"),
                                   ("category", "Notice"), ("section", "Section"), ("status", "Status")],
                                  export_title="Notice Tracker", page_size=50, compact=True)
        self.t_notice.activated.connect(lambda i: self._open("notice", i))
        lay.addWidget(self.t_notice)
        row3.addWidget(p, 1)
        v.addLayout(row3)

        row4 = QHBoxLayout()
        p, lay = panel("👥 Client-wise Pending Work")
        self.t_client = DataTable([("client_name", "Client"), ("pending", "Pending"), ("overdue", "Overdue"),
                                   ("notices", "Open Notices"), ("next_due", "Next Due")],
                                  export_title="Client-wise Pending Work", page_size=50, compact=True)
        self.t_client.activated.connect(lambda i: self._open("client", i))
        lay.addWidget(self.t_client)
        row4.addWidget(p, 1)
        p, lay = panel("🕘 Recent Activities")
        self.t_act = DataTable([("when", "When"), ("user", "User"), ("module", "Module"), ("description", "Activity"),
                                ("client", "Client")], export_title="Recent Activities", page_size=50, compact=True)
        lay.addWidget(self.t_act)
        row4.addWidget(p, 1)
        v.addLayout(row4)
        for t in (self.t_today, self.t_up, self.t_over, self.t_tasks, self.t_notice, self.t_client, self.t_act):
            t.setMinimumHeight(250)
        scroll.setWidget(body)
        self.root.addWidget(scroll, 1)

    def _open(self, kind: str, rid) -> None:
        self.main.open_record(kind, rid)

    def drill(self, key: str) -> None:
        title, cols, rows, kind = reporting_service.drilldown(key)
        DrillDownDialog(self, title, cols, rows, (lambda i: self._open(kind, i)) if kind else None).exec()
        self.refresh()

    def refresh(self) -> None:
        c = reporting_service.dashboard_counts()
        for k, card in self.cards.items():
            v = c.get(k, 0)
            card.set_value(f"{v}%" if k == "completion_pct" else v)
        t = today()
        open_recs = compliance_engine.list_records({"open_only": True})
        self.t_today.set_rows([r for r in compliance_engine.list_records({"due_from": t, "due_to": t})])
        self.t_up.set_rows([r for r in open_recs if r["due"] and t <= r["due"] <= t + timedelta(days=15)])
        self.t_over.set_rows([r for r in open_recs if r["due"] and r["due"] < t])
        self.t_tasks.set_rows(task_service.list_tasks({"open_only": True}))
        self.t_notice.set_rows(notice_service.list_notices({"open_only": True}))
        self.t_client.set_rows(reporting_service.client_pending_work(25))
        self.t_act.set_rows(recent_activities(60))
        labels, due, done = reporting_service.monthly_completion(settings_service.current_fy())
        self.chart.set_data(labels, [("Due", due, "#8B5CF6"), ("Completed", done, "#EC4899")])
