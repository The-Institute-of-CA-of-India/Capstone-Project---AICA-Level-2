"""Global search across clients, compliances, notices, tasks and documents."""
from __future__ import annotations

from app.qt import *  # noqa: F401,F403
from app.services import client_service, compliance_engine, document_service, notice_service, task_service
from app.ui.widgets import DataTable, button, section_label


def search_all(text: str) -> list[dict]:
    q = text.strip().lower()
    out: list[dict] = []

    def hit(*vals) -> bool:
        return any(q in str(v or "").lower() for v in vals)

    for c in client_service.list_clients():
        if hit(c["client_name"], c["legal_name"], c["pan"], c["gstin"], c["tan"], c["cin_llpin"], c["client_code"],
               c["mobile"], c["email"]):
            out.append({"kind": "client", "ref": c["id"], "type": "Client", "title": c["client_name"],
                        "detail": f"{c['client_code']} • PAN {c['pan'] or '-'} • GSTIN {c['gstin'] or '-'} • TAN {c['tan'] or '-'}",
                        "status": c["status"]})
    for r in compliance_engine.list_records({"active_clients_only": False}):
        if hit(r["compliance_name"], r["form_number"], r["ack_number"], r["challan_number"], r["srn"]):
            out.append({"kind": "compliance", "ref": r["id"], "type": f"Compliance ({r['category']})",
                        "title": f"{r['compliance_name']} - {r['client_name']}",
                        "detail": f"{r['tax_period']} • Due {r['due']} • Ack {r['ack_number'] or '-'}", "status": r["status"]})
        if len(out) > 1500:
            break
    for n in notice_service.list_notices():
        if hit(n["notice_number"], n["din"], n["notice_code"], n["section"], n["client_name"], n["category"]):
            out.append({"kind": "notice", "ref": n["id"], "type": "Notice", "title": f"{n['category']} - {n['client_name']}",
                        "detail": f"{n['notice_code']} • No. {n['notice_number'] or '-'} • DIN {n['din'] or '-'}",
                        "status": n["status"]})
    for t in task_service.list_tasks():
        if hit(t["title"], t["task_code"], t["description"], t["client_name"]):
            out.append({"kind": "task", "ref": t["id"], "type": "Task", "title": t["title"],
                        "detail": f"{t['task_code']} • {t['client_name']} • Due {t['due_date']}", "status": t["status"]})
    for d in document_service.list_documents(search=text.strip()):
        out.append({"kind": "document", "ref": d["id"], "type": "Document", "title": d["title"],
                    "detail": f"{d['file_name']} • {d['client_name']} • {d['category']}", "status": f"v{d['version']}"})
    for i, r in enumerate(out):
        r["_id"] = i
    return out


class GlobalSearchDialog(QDialog):
    def __init__(self, main, text: str):
        super().__init__(main)
        self.main = main
        self.setWindowTitle(f"Search results - '{text}'")
        self.resize(1100, 600)
        v = QVBoxLayout(self)
        self.rows = search_all(text)
        v.addWidget(section_label(f"🔍 {len(self.rows)} result(s) for '{text}'  —  double-click to open"))
        self.table = DataTable([("type", "Type"), ("title", "Title"), ("detail", "Details"), ("status", "Status")],
                               filters=["type"], export_title=f"Search {text}")
        self.table.set_rows(self.rows)
        self.table.activated.connect(self._open)
        v.addWidget(self.table, 1)
        v.addWidget(button("Close", "ghost", self.accept), 0, Qt.AlignmentFlag.AlignRight)

    def _open(self, idx):
        r = self.rows[int(idx)]
        self.main.open_record(r["kind"], r["ref"])
