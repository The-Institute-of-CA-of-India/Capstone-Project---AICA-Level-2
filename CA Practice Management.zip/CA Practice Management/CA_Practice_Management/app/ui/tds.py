"""TDS / TCS compliance tracker (TAN-wise, quarterly returns, challans, certificates)."""
from app.ui.compliance import CategoryPage


class TDSPage(CategoryPage):
    CATEGORY = "TDS"
    TITLE = "TDS / TCS Compliance"
    CLIENT_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("tan", "TAN"), ("pan", "PAN"),
                      ("tds_applicable", "TDS"), ("tds_salary", "24Q"), ("tds_nonsalary", "26Q"),
                      ("tds_nonresident", "27Q"), ("tcs_applicable", "TCS / 27EQ"), ("staff", "Staff")]
    EXTRA_TABS = [("Challan Payments", ["TDS-PAY", "TCS-PAY"]),
                  ("Quarterly Returns", ["TDS-24Q", "TDS-26Q", "TDS-27Q", "TDS-27EQ", "TDS-RQ1", "TDS-RQ2",
                                         "TDS-RQ3", "TDS-RQ4", "TDS-CORR"]),
                  ("Certificates (16 / 16A / 27D)", ["TDS-16", "TDS-16A", "TDS-27D"])]

    def client_filter(self, c) -> bool:
        return bool(c.get("tan")) or bool(c.get("tds_applicable")) or bool(c.get("tcs_applicable"))
