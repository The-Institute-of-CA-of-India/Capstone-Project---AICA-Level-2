"""GST compliance tracker (GSTIN-wise, monthly/quarterly matrix, filing history)."""
from app.ui.compliance import CategoryPage


class GSTPage(CategoryPage):
    CATEGORY = "GST"
    TITLE = "GST Compliance"
    CLIENT_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("gstin", "GSTIN"),
                      ("gst_registration_type", "Registration Type"), ("gst_scheme", "Regular / Composition"),
                      ("gst_frequency", "Filing Frequency"), ("gst_state", "State"),
                      ("gst_registration_date", "Registration Date"), ("gst_status", "GST Status"),
                      ("staff", "Staff"), ("pending_compliances", "Pending (all)")]
    EXTRA_TABS = [("GST Payments & Challans", ["GST-PAY", "GST-PMT06", "GST-CMP08"]),
                  ("Annual Return & Reconciliation", ["GST-GSTR9", "GST-GSTR9C", "GST-GSTR4", "GST-RECON", "GST-ANNUAL"])]

    def client_filter(self, c) -> bool:
        return bool(c.get("gstin")) or c.get("gst_registration_type") not in (None, "", "Not Registered")
