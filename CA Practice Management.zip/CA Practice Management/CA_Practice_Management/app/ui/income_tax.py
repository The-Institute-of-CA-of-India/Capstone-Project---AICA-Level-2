"""Income Tax compliance tracker (AY/FY-wise ITR, tax audit, advance tax)."""
from app.ui.compliance import CategoryPage


class IncomeTaxPage(CategoryPage):
    CATEGORY = "Income Tax"
    TITLE = "Income Tax Compliance"
    CLIENT_COLUMNS = [("client_code", "Client ID"), ("client_name", "Client"), ("pan", "PAN"),
                      ("entity_type", "Entity Type"), ("itr_form", "ITR Form"),
                      ("tax_audit_applicable", "Tax Audit"), ("transfer_pricing_applicable", "Transfer Pricing"),
                      ("advance_tax_applicable", "Advance Tax"), ("charitable_registration", "Charitable"),
                      ("staff", "Staff")]
    EXTRA_TABS = [("ITR Filing", ["IT-ITR1", "IT-ITR2", "IT-ITR3", "IT-ITR4", "IT-ITR5", "IT-ITR6", "IT-ITR7",
                                  "IT-VERIFY", "IT-REFUND"]),
                  ("Tax Audit & Forms", ["IT-TAXAUDIT", "IT-3CA", "IT-3CB", "IT-3CEB", "IT-10B", "IT-10BB",
                                         "IT-10A", "IT-10AB"]),
                  ("Advance Tax & Payments", ["IT-ADVTAX", "IT-TAXPAY", "IT-TDSRECON"])]

    def client_filter(self, c) -> bool:
        return bool(c.get("pan"))
