"""Login, forced password change and session lock dialogs."""
from __future__ import annotations

import config
from app.qt import *  # noqa: F401,F403
from app.services import auth_service, settings_service
from app.ui.widgets import button, error


class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{config.APP_NAME} - Login")
        self.setFixedSize(820, 470)
        self.user = None
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        banner = QFrame()
        banner.setStyleSheet("QFrame { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1E3A8A, "
                             "stop:0.5 #6D28D9, stop:1 #DB2777); } QLabel { color: white; background: transparent; }")
        bl = QVBoxLayout(banner)
        bl.setContentsMargins(34, 40, 34, 34)
        logo = QLabel("₹ ✓")
        logo.setStyleSheet("font-size: 40pt; font-weight: 900;")
        bl.addWidget(logo)
        firm = QLabel(settings_service.firm_name())
        firm.setStyleSheet("font-size: 20pt; font-weight: 800;")
        firm.setWordWrap(True)
        bl.addWidget(firm)
        sub = QLabel("Chartered Accountants")
        sub.setStyleSheet("font-size: 11pt; color: #FBCFE8;")
        bl.addWidget(sub)
        bl.addStretch(1)
        app = QLabel(config.APP_NAME)
        app.setWordWrap(True)
        app.setStyleSheet("font-size: 12.5pt; font-weight: 700;")
        bl.addWidget(app)
        ver = QLabel(f"Version {config.APP_VERSION}  •  Offline-first  •  Secure")
        ver.setStyleSheet("font-size: 8.5pt; color: #E9D5FF;")
        bl.addWidget(ver)
        root.addWidget(banner, 11)

        form = QFrame()
        form.setStyleSheet("QFrame { background: white; }")
        fl = QVBoxLayout(form)
        fl.setContentsMargins(40, 50, 40, 30)
        t = QLabel("Welcome back 👋")
        t.setStyleSheet("font-size: 18pt; font-weight: 800; color: #4C1D95;")
        fl.addWidget(t)
        s = QLabel("Sign in to continue")
        s.setObjectName("Muted")
        fl.addWidget(s)
        fl.addSpacing(18)
        fl.addWidget(QLabel("Username"))
        self.ed_user = QLineEdit()
        self.ed_user.setPlaceholderText("e.g. admin")
        fl.addWidget(self.ed_user)
        fl.addSpacing(6)
        fl.addWidget(QLabel("Password"))
        self.ed_pass = QLineEdit()
        self.ed_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.ed_pass.returnPressed.connect(self._login)
        self.ed_user.returnPressed.connect(self.ed_pass.setFocus)
        fl.addWidget(self.ed_pass)
        self.err = QLabel("")
        self.err.setObjectName("ErrorLabel")
        self.err.setWordWrap(True)
        fl.addWidget(self.err)
        fl.addSpacing(8)
        b = button("Sign In  →", "", self._login)
        b.setMinimumHeight(38)
        fl.addWidget(b)
        fl.addStretch(1)
        hint = QLabel("First run: username <b>admin</b>, password <b>Admin@123</b> (you will be asked to change it).")
        hint.setWordWrap(True)
        hint.setObjectName("Muted")
        hint.setStyleSheet("font-size: 8.5pt; color: #6B7280;")
        fl.addWidget(hint)
        root.addWidget(form, 9)
        self.ed_user.setFocus()

    def _login(self) -> None:
        user, msg = auth_service.authenticate(self.ed_user.text(), self.ed_pass.text())
        self.ed_pass.clear()
        if not user:
            self.err.setText(msg)
            return
        if user.get("must_change_password"):
            dlg = ChangePasswordDialog(self, forced=True)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                auth_service.logout()
                self.err.setText("Password change is required before first use.")
                return
        self.user = user
        self.accept()


class ChangePasswordDialog(QDialog):
    def __init__(self, parent=None, forced: bool = False):
        super().__init__(parent)
        self.setWindowTitle("Change Password")
        self.setMinimumWidth(420)
        lay = QFormLayout(self)
        if forced:
            note = QLabel("For security, please set a new password now (min. 8 characters, letters & numbers).")
            note.setWordWrap(True)
            lay.addRow(note)
        self.old = QLineEdit()
        self.new = QLineEdit()
        self.new2 = QLineEdit()
        for w in (self.old, self.new, self.new2):
            w.setEchoMode(QLineEdit.EchoMode.Password)
        lay.addRow("Current password", self.old)
        lay.addRow("New password", self.new)
        lay.addRow("Confirm new password", self.new2)
        self.err = QLabel("")
        self.err.setObjectName("ErrorLabel")
        self.err.setWordWrap(True)
        lay.addRow(self.err)
        lay.addRow(button("Change Password", "", self._save))

    def _save(self) -> None:
        if self.new.text() != self.new2.text():
            self.err.setText("New passwords do not match.")
            return
        try:
            auth_service.change_password(auth_service.current_user_id(), self.old.text(), self.new.text())
        except ValueError as exc:
            self.err.setText(str(exc))
            return
        self.accept()


class LockDialog(QDialog):
    """Shown after inactivity. Requires the current user's password."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Session Locked")
        self.setModal(True)
        self.setFixedSize(420, 250)
        self.logout_requested = False
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
        lay = QVBoxLayout(self)
        u = auth_service.current_user() or {}
        t = QLabel(f"🔒  Locked - {u.get('full_name', '')}")
        t.setStyleSheet("font-size: 14pt; font-weight: 800; color: #5B21B6;")
        lay.addWidget(t)
        lay.addWidget(QLabel("Your session was locked due to inactivity. Enter your password to continue."))
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.EchoMode.Password)
        self.pw.returnPressed.connect(self._unlock)
        lay.addWidget(self.pw)
        self.err = QLabel("")
        self.err.setObjectName("ErrorLabel")
        lay.addWidget(self.err)
        row = QHBoxLayout()
        row.addWidget(button("Log out", "ghost", self._logout))
        row.addStretch(1)
        row.addWidget(button("Unlock", "", self._unlock))
        lay.addLayout(row)

    def _unlock(self) -> None:
        if auth_service.verify_current_password(self.pw.text()):
            self.accept()
        else:
            self.pw.clear()
            self.err.setText("Incorrect password.")

    def _logout(self) -> None:
        self.logout_requested = True
        self.accept()

    def keyPressEvent(self, e) -> None:  # noqa: N802 - block Esc
        if e.key() == Qt.Key.Key_Escape:
            return
        super().keyPressEvent(e)
