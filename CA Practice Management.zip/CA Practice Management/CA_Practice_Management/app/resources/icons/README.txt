The application icon is generated at runtime (gradient "NA" badge). Place a firm logo here
and select it in Settings > Firm Profile if desired.
