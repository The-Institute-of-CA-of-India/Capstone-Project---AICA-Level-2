The application theme (vibrant blue / violet / pink, light + dark) is defined in app/ui/styles.py
so it is always bundled inside the .exe.
To customise colours without touching code, create a file named custom.qss in this folder;
its rules are appended after the built-in stylesheet.
