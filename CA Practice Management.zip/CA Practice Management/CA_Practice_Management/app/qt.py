"""
Qt compatibility layer.

The application is written against the Qt for Python API. PySide6 is used when
available; PyQt6 is used as an automatic fallback. Every UI module simply does
`from app.qt import *`.
"""
try:
    from PySide6.QtCore import *      # noqa: F401,F403
    from PySide6.QtGui import *       # noqa: F401,F403
    from PySide6.QtWidgets import *   # noqa: F401,F403
    from PySide6.QtPrintSupport import QPrinter, QPrintDialog  # noqa: F401
    QT_API = "PySide6"
except ImportError:  # pragma: no cover - fallback binding
    from PyQt6.QtCore import *        # noqa: F401,F403
    from PyQt6.QtGui import *         # noqa: F401,F403
    from PyQt6.QtWidgets import *     # noqa: F401,F403
    from PyQt6.QtPrintSupport import QPrinter, QPrintDialog  # noqa: F401
    from PyQt6.QtCore import pyqtSignal as Signal, pyqtSlot as Slot  # noqa: F401
    QT_API = "PyQt6"


def print_document(doc, printer) -> None:
    """QTextDocument.print_ (PySide6) vs QTextDocument.print (PyQt6)."""
    fn = getattr(doc, "print_", None) or getattr(doc, "print")
    fn(printer)
