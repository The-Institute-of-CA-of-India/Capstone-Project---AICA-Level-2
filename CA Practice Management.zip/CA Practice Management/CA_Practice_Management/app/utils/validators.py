"""Validation of Indian statutory identifiers and client master data."""
from __future__ import annotations

import re
from typing import Optional

PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
TAN_RE = re.compile(r"^[A-Z]{4}[0-9]{5}[A-Z]$")
GSTIN_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
CIN_RE = re.compile(r"^[LU][0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}$")
LLPIN_RE = re.compile(r"^[A-Z]{3}-[0-9]{4}$")
MOBILE_RE = re.compile(r"^(\+?91[\-\s]?)?[6-9][0-9]{9}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
PIN_RE = re.compile(r"^[1-9][0-9]{5}$")
_GST_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

GST_STATE_CODES = {
    "01": "Jammu and Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh",
    "05": "Uttarakhand", "06": "Haryana", "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh",
    "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur",
    "15": "Mizoram", "16": "Tripura", "17": "Meghalaya", "18": "Assam", "19": "West Bengal",
    "20": "Jharkhand", "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh",
    "24": "Gujarat", "26": "Dadra and Nagar Haveli and Daman and Diu", "27": "Maharashtra",
    "29": "Karnataka", "30": "Goa", "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu",
    "34": "Puducherry", "35": "Andaman and Nicobar Islands", "36": "Telangana",
    "37": "Andhra Pradesh", "38": "Ladakh", "97": "Other Territory",
}
INDIAN_STATES = sorted(set(GST_STATE_CODES.values()))

# PAN 4th character -> holder status
PAN_HOLDER_TYPES = {"P": "Individual", "C": "Company", "H": "HUF", "F": "Firm / LLP",
                    "A": "AOP", "T": "Trust", "B": "BOI", "L": "Local Authority",
                    "J": "Artificial Juridical Person", "G": "Government"}
ENTITY_PAN_CHAR = {"Individual": "P", "Proprietorship": "P", "HUF": "H",
                   "Partnership Firm": "F", "LLP": "F", "Private Limited Company": "C",
                   "Public Limited Company": "C", "Trust": "T", "Association of Persons": "A"}


def clean_id(value: Optional[str]) -> Optional[str]:
    """Upper-case and strip an identifier; blank -> None (keeps UNIQUE constraints valid)."""
    if value is None:
        return None
    v = str(value).strip().upper().replace(" ", "")
    return v or None


def gstin_checksum(first14: str) -> str:
    total = 0
    for i, ch in enumerate(first14):
        value = _GST_CHARS.index(ch)
        product = value * (2 if i % 2 else 1)
        total += product // 36 + product % 36
    return _GST_CHARS[(36 - total % 36) % 36]


def validate_pan(v: Optional[str]) -> Optional[str]:
    v = clean_id(v)
    if v and not PAN_RE.match(v):
        return "PAN must be 10 characters: 5 letters, 4 digits, 1 letter (e.g. ABCDE1234F)."
    return None


def validate_tan(v: Optional[str]) -> Optional[str]:
    v = clean_id(v)
    if v and not TAN_RE.match(v):
        return "TAN must be 10 characters: 4 letters, 5 digits, 1 letter (e.g. MUMA12345B)."
    return None


def validate_gstin(v: Optional[str], check_checksum: bool = True) -> Optional[str]:
    v = clean_id(v)
    if not v:
        return None
    if not GSTIN_RE.match(v):
        return "GSTIN format is invalid (15 characters, e.g. 27ABCDE1234F1Z5)."
    if v[:2] not in GST_STATE_CODES:
        return f"GSTIN state code '{v[:2]}' is not a valid GST state code."
    if check_checksum and gstin_checksum(v[:14]) != v[14]:
        return "GSTIN check digit is invalid - please re-check the number."
    return None


def validate_cin_llpin(v: Optional[str]) -> Optional[str]:
    v = clean_id(v)
    if v and not (CIN_RE.match(v) or LLPIN_RE.match(v)):
        return "CIN must be 21 characters (e.g. U74999MH2015PTC123456) or LLPIN like AAB-1234."
    return None


def validate_mobile(v: Optional[str]) -> Optional[str]:
    if v and str(v).strip() and not MOBILE_RE.match(str(v).strip().replace(" ", "")):
        return "Mobile number must be a valid 10-digit Indian mobile number."
    return None


def validate_email(v: Optional[str]) -> Optional[str]:
    if v and str(v).strip() and not EMAIL_RE.match(str(v).strip()):
        return "Email address format is invalid."
    return None


def validate_pin(v: Optional[str]) -> Optional[str]:
    if v and str(v).strip() and not PIN_RE.match(str(v).strip()):
        return "PIN code must be 6 digits."
    return None


def validate_client(data: dict) -> tuple[list[str], list[str]]:
    """Return (errors, warnings) for a client master record."""
    errors: list[str] = []
    warnings: list[str] = []
    if not str(data.get("client_name") or "").strip():
        errors.append("Client Name is required.")
    if not data.get("entity_type"):
        errors.append("Entity Type is required.")
    for fn, key in ((validate_pan, "pan"), (validate_tan, "tan"), (validate_gstin, "gstin"),
                    (validate_cin_llpin, "cin_llpin"), (validate_mobile, "mobile"),
                    (validate_email, "email"), (validate_pin, "pin_code")):
        err = fn(data.get(key))
        if err:
            errors.append(err)
    pan, gstin = clean_id(data.get("pan")), clean_id(data.get("gstin"))
    if pan and gstin and not errors and gstin[2:12] != pan:
        warnings.append("PAN embedded in GSTIN (characters 3-12) does not match the client PAN.")
    exp = ENTITY_PAN_CHAR.get(data.get("entity_type") or "")
    if pan and exp and PAN_RE.match(pan) and pan[3] != exp:
        warnings.append(f"PAN 4th character '{pan[3]}' ({PAN_HOLDER_TYPES.get(pan[3], 'unknown')}) "
                        f"is unusual for entity type '{data.get('entity_type')}'.")
    if gstin and data.get("gst_registration_type") in (None, "", "Not Registered"):
        warnings.append("GSTIN entered but GST Registration Type is 'Not Registered'.")
    return errors, warnings
