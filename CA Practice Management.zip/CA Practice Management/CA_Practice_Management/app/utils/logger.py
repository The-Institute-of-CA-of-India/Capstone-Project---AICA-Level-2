"""Application logging (rotating file + console). Never log passwords/OTPs."""
from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler

import config

_CONFIGURED = False
SENSITIVE_WORDS = ("password", "passwd", "otp", "secret", "token")


class _RedactFilter(logging.Filter):
    """Defensive filter: masks any log line that looks like it holds a credential."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = str(record.getMessage()).lower()
        except Exception:
            return True
        if any(word + "=" in msg or word + ":" in msg for word in SENSITIVE_WORDS):
            record.msg = "[redacted: message contained credential-like content]"
            record.args = ()
        return True


def setup_logging(level: int = logging.INFO) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    os.makedirs(config.LOG_DIR, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
    root = logging.getLogger()
    root.setLevel(level)
    fh = RotatingFileHandler(os.path.join(config.LOG_DIR, "app.log"),
                             maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.addFilter(_RedactFilter())
    root.addHandler(fh)
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    ch.addFilter(_RedactFilter())
    ch.setLevel(logging.WARNING)
    root.addHandler(ch)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
