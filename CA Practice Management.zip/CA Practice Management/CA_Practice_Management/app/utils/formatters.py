"""Indian currency / number formatting."""
from __future__ import annotations

from typing import Any


def inr(value: Any, symbol: bool = True, decimals: int = 2) -> str:
    """Format a number in Indian digit grouping, e.g. 1234567.5 -> ₹ 12,34,567.50"""
    try:
        v = float(value or 0)
    except (TypeError, ValueError):
        return str(value)
    neg = v < 0
    s = f"{abs(v):.{decimals}f}"
    ip, _, dp = s.partition(".")
    if len(ip) > 3:
        last3, rest = ip[-3:], ip[:-3]
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        ip = ",".join(groups) + "," + last3
    out = ip + ("." + dp if dp else "")
    return f"{'-' if neg else ''}{'₹ ' if symbol else ''}{out}"


def to_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or str(value).strip() == "":
            return default
        return float(str(value).replace(",", "").replace("₹", "").strip())
    except (TypeError, ValueError):
        return default


def yes_no(value: Any) -> bool:
    return str(value).strip().lower() in ("yes", "y", "true", "1", "applicable")
