"""Date helpers: Indian financial year (April-March), periods, formatting."""
from __future__ import annotations

import calendar
from datetime import date, datetime, timedelta
from typing import Any, Optional

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

_DATE_FORMAT = "%d-%m-%Y"
QT_FORMATS = {"%d-%m-%Y": "dd-MM-yyyy", "%d/%m/%Y": "dd/MM/yyyy",
              "%Y-%m-%d": "yyyy-MM-dd", "%d-%b-%Y": "dd-MMM-yyyy"}
PERIODICITIES = ["Monthly", "Quarterly", "Half-Yearly", "Annual", "Fixed Dates", "One-Time"]


def set_date_format(fmt: str) -> None:
    global _DATE_FORMAT
    if fmt in QT_FORMATS:
        _DATE_FORMAT = fmt


def get_date_format() -> str:
    return _DATE_FORMAT


def qt_date_format() -> str:
    return QT_FORMATS.get(_DATE_FORMAT, "dd-MM-yyyy")


def today() -> date:
    return date.today()


def month_last_day(year: int, month: int) -> int:
    return calendar.monthrange(year, month)[1]


def safe_date(year: int, month: int, day: int) -> date:
    """Build a date, clipping the day to the month's last day (e.g. 31 Jun -> 30 Jun)."""
    return date(year, month, max(1, min(int(day), month_last_day(year, month))))


def add_months(d: date, n: int) -> date:
    y, m = divmod(d.month - 1 + n, 12)
    year, month = d.year + y, m + 1
    return safe_date(year, month, d.day)


# ---------------------------------------------------------------- FY helpers
def fy_of(d: Optional[date] = None) -> str:
    d = d or today()
    start = d.year if d.month >= 4 else d.year - 1
    return f"{start}-{str(start + 1)[-2:]}"


def fy_start_year(fy: str) -> int:
    return int(str(fy).strip()[:4])


def fy_bounds(fy: str) -> tuple[date, date]:
    s = fy_start_year(fy)
    return date(s, 4, 1), date(s + 1, 3, 31)


def ay_of_fy(fy: str) -> str:
    s = fy_start_year(fy) + 1
    return f"{s}-{str(s + 1)[-2:]}"


def fy_of_ay(ay: str) -> str:
    s = fy_start_year(ay) - 1
    return f"{s}-{str(s + 1)[-2:]}"


def fy_choices(center: Optional[str] = None, back: int = 4, fwd: int = 1) -> list[str]:
    s = fy_start_year(center or fy_of())
    return [f"{y}-{str(y + 1)[-2:]}" for y in range(s + fwd, s - back - 1, -1)]


def generate_periods(periodicity: str, fy: str, fixed_dates: Optional[list] = None) -> list[dict]:
    """Return compliance periods of a financial year.

    Each period: key (unique within master), label, tag (for due-date overrides),
    start, end, and fixed_due (only for 'Fixed Dates' periodicity).
    """
    s = fy_start_year(fy)
    fy_start = date(s, 4, 1)
    out: list[dict] = []
    if periodicity == "Monthly":
        for i in range(12):
            d = add_months(fy_start, i)
            out.append({"key": f"{d.year}-{d.month:02d}", "label": f"{MONTHS[d.month - 1]}-{d.year}",
                        "tag": f"M{d.month:02d}", "start": d,
                        "end": safe_date(d.year, d.month, 31)})
    elif periodicity == "Quarterly":
        for q in range(1, 5):
            st = add_months(fy_start, 3 * (q - 1))
            en_m = add_months(st, 2)
            out.append({"key": f"FY{fy}-Q{q}",
                        "label": f"Q{q} {fy} ({MONTHS[st.month - 1]}-{MONTHS[en_m.month - 1]})",
                        "tag": f"Q{q}", "start": st, "end": safe_date(en_m.year, en_m.month, 31)})
    elif periodicity == "Half-Yearly":
        for h in (1, 2):
            st = add_months(fy_start, 6 * (h - 1))
            en_m = add_months(st, 5)
            out.append({"key": f"FY{fy}-H{h}",
                        "label": f"H{h} {fy} ({MONTHS[st.month - 1]}-{MONTHS[en_m.month - 1]})",
                        "tag": f"H{h}", "start": st, "end": safe_date(en_m.year, en_m.month, 31)})
    elif periodicity == "Fixed Dates":
        for i, fd in enumerate(fixed_dates or [], start=1):
            month, day = int(fd.get("month", 3)), int(fd.get("day", 15))
            due = safe_date(s if month >= 4 else s + 1, month, day)
            out.append({"key": f"FY{fy}-I{i}", "label": f"{fd.get('label', 'Instalment ' + str(i))} {fy}",
                        "tag": f"I{i}", "start": fy_start, "end": due, "fixed_due": due})
    else:  # Annual / One-Time
        st, en = fy_bounds(fy)
        out.append({"key": f"FY{fy}", "label": f"FY {fy}", "tag": "A", "start": st, "end": en})
    return out


# ---------------------------------------------------------------- formatting
def fmt_date(d: Any) -> str:
    d = parse_date(d)
    return d.strftime(_DATE_FORMAT) if d else ""


def fmt_datetime(dt: Any) -> str:
    if not dt:
        return ""
    if isinstance(dt, datetime):
        return dt.strftime(_DATE_FORMAT + " %H:%M")
    return fmt_date(dt)


def parse_date(v: Any) -> Optional[date]:
    """Accepts date/datetime/pandas Timestamp/Excel serial/strings in common formats."""
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)):
        try:
            if v != v:  # NaN
                return None
            if 1 < float(v) < 80000:
                return date(1899, 12, 30) + timedelta(days=int(v))
        except Exception:
            return None
        return None
    s = str(v).strip()
    if not s or s.lower() in ("nan", "nat", "none", "null", "-"):
        return None
    for fmt in (_DATE_FORMAT, "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d-%b-%Y", "%d.%m.%Y",
                "%Y-%m-%d %H:%M:%S", "%d-%m-%y", "%d/%m/%y", "%d %b %Y", "%d-%B-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def days_from_today(d: Any) -> Optional[int]:
    d = parse_date(d)
    return (d - today()).days if d else None


def week_bounds(d: date) -> tuple[date, date]:
    start = d - timedelta(days=d.weekday())
    return start, start + timedelta(days=6)


def month_bounds(d: date) -> tuple[date, date]:
    return date(d.year, d.month, 1), safe_date(d.year, d.month, 31)


def quarter_bounds(d: date) -> tuple[date, date]:
    """Financial-year quarter (Apr-Jun, Jul-Sep, Oct-Dec, Jan-Mar) containing d."""
    k = (d.month - 4) % 12
    st = add_months(date(fy_start_year(fy_of(d)), 4, 1), 3 * (k // 3))
    en_m = add_months(st, 2)
    return st, safe_date(en_m.year, en_m.month, 31)
