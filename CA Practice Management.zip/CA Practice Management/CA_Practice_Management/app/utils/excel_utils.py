"""Excel / CSV import-export helpers (OpenPyXL + Pandas)."""
from __future__ import annotations

import csv
import os
from datetime import date, datetime
from typing import Any, Iterable, Optional

from app.utils.date_utils import fmt_date, fmt_datetime

# (Excel header, client field)
CLIENT_TEMPLATE_COLUMNS = [
    ("Client Name*", "client_name"), ("Legal Name", "legal_name"), ("Entity Type*", "entity_type"),
    ("PAN", "pan"), ("TAN", "tan"), ("GSTIN", "gstin"), ("CIN / LLPIN", "cin_llpin"),
    ("Date of Incorporation (DD-MM-YYYY)", "date_of_incorporation"),
    ("Registered Address", "address"), ("City", "city"), ("State", "state"), ("PIN Code", "pin_code"),
    ("Contact Person", "contact_person"), ("Mobile", "mobile"), ("Email", "email"),
    ("Alternate Contact", "alternate_contact"), ("Industry", "industry"),
    ("Nature of Business", "nature_of_business"), ("Client Acquisition Date", "acquisition_date"),
    ("Assigned Partner (username)", "partner_username"),
    ("Assigned Manager (username)", "manager_username"),
    ("Assigned Staff (username)", "staff_username"),
    ("Risk Category (Low/Medium/High)", "risk_category"), ("Professional Fee", "professional_fee"),
    ("Billing Frequency", "billing_frequency"), ("Engagement Start Date", "engagement_start"),
    ("Engagement End Date", "engagement_end"),
    ("GST Registration Type", "gst_registration_type"),
    ("GST Scheme (Regular/Composition)", "gst_scheme"),
    ("GST Filing Frequency (Monthly/Quarterly)", "gst_frequency"),
    ("GST Registration Date", "gst_registration_date"), ("GST Status", "gst_status"),
    ("ITR Form", "itr_form"), ("Tax Audit Applicable (Yes/No)", "tax_audit_applicable"),
    ("Transfer Pricing (Yes/No)", "transfer_pricing_applicable"),
    ("Advance Tax (Yes/No)", "advance_tax_applicable"),
    ("TDS Applicable (Yes/No)", "tds_applicable"), ("TDS Salary 24Q (Yes/No)", "tds_salary"),
    ("TDS Non-Salary 26Q (Yes/No)", "tds_nonsalary"),
    ("TDS Non-Resident 27Q (Yes/No)", "tds_nonresident"), ("TCS Applicable (Yes/No)", "tcs_applicable"),
    ("Statutory Audit (Yes/No)", "statutory_audit_applicable"),
    ("Small Company (Yes/No)", "small_company"), ("MSME Payables (Yes/No)", "msme_payables"),
    ("XBRL Applicable (Yes/No)", "xbrl_applicable"), ("Notes", "notes"),
]
BOOL_FIELDS = {"tax_audit_applicable", "transfer_pricing_applicable", "advance_tax_applicable",
               "tds_applicable", "tds_salary", "tds_nonsalary", "tds_nonresident", "tcs_applicable",
               "statutory_audit_applicable", "small_company", "msme_payables", "xbrl_applicable",
               "gst_9c_applicable", "gst_exporter_lut", "charitable_registration"}
DATE_FIELDS = {"date_of_incorporation", "acquisition_date", "engagement_start", "engagement_end",
               "gst_registration_date", "agm_date"}


def _norm(h: Any) -> str:
    s = str(h or "").lower()
    if "(" in s:
        s = s[: s.index("(")]
    return "".join(ch for ch in s if ch.isalnum())


def _cell_value(v: Any) -> Any:
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, (int, float, date, datetime)) or v is None:
        return v
    return str(v)


def export_rows(path: str, columns: list[tuple[str, str]], rows: Iterable[dict],
                title: Optional[str] = None, firm: Optional[str] = None,
                sheet_name: str = "Report") -> str:
    """Export dict rows to .xlsx (styled) or .csv depending on extension."""
    rows = list(rows)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if path.lower().endswith(".csv"):
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow([t for _, t in columns])
            for r in rows:
                out = []
                for k, _ in columns:
                    v = r.get(k)
                    if isinstance(v, datetime):
                        v = fmt_datetime(v)
                    elif isinstance(v, date):
                        v = fmt_date(v)
                    elif isinstance(v, bool):
                        v = "Yes" if v else "No"
                    out.append("" if v is None else v)
                w.writerow(out)
        return path

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]
    r0 = 1
    if title:
        ws.cell(row=1, column=1, value=firm or "").font = Font(bold=True, size=14, color="5B21B6")
        ws.cell(row=2, column=1, value=title).font = Font(bold=True, size=12, color="1E40AF")
        ws.cell(row=3, column=1, value=f"Generated on {fmt_datetime(datetime.now())}").font = Font(
            italic=True, size=9, color="6B7280")
        r0 = 5
    header_fill = PatternFill("solid", fgColor="6D28D9")
    for c, (_, t) in enumerate(columns, start=1):
        cell = ws.cell(row=r0, column=c, value=t)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    widths = [len(t) + 2 for _, t in columns]
    for i, r in enumerate(rows, start=r0 + 1):
        for c, (k, _) in enumerate(columns, start=1):
            v = _cell_value(r.get(k))
            cell = ws.cell(row=i, column=c, value=v)
            if isinstance(v, datetime):
                cell.number_format = "DD-MM-YYYY HH:MM"
            elif isinstance(v, date):
                cell.number_format = "DD-MM-YYYY"
            elif isinstance(v, float):
                cell.number_format = "#,##,##0.00"
            widths[c - 1] = min(60, max(widths[c - 1], len(str(v if v is not None else "")) + 2))
    for c, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c)].width = max(10, w)
    ws.freeze_panes = ws.cell(row=r0 + 1, column=1)
    if rows:
        ws.auto_filter.ref = f"A{r0}:{get_column_letter(len(columns))}{r0 + len(rows)}"
    wb.save(path)
    return path


def write_client_template(path: str, entity_types: list[str]) -> str:
    """Create the Excel client import template with instructions."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Clients"
    fill = PatternFill("solid", fgColor="2563EB")
    for c, (h, _) in enumerate(CLIENT_TEMPLATE_COLUMNS, start=1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = fill
        ws.column_dimensions[get_column_letter(c)].width = max(14, len(h) + 2)
    example = {"client_name": "Sample Traders", "legal_name": "Sample Traders",
               "entity_type": "Proprietorship", "pan": "ABCPS1234K", "city": "Mumbai",
               "state": "Maharashtra", "mobile": "9876543210", "email": "sample@example.com",
               "gst_registration_type": "Normal Taxpayer", "gst_scheme": "Regular",
               "gst_frequency": "Monthly", "gst_status": "Active", "itr_form": "ITR-3",
               "tax_audit_applicable": "No", "professional_fee": 25000,
               "billing_frequency": "Annual", "risk_category": "Low"}
    for c, (_, f) in enumerate(CLIENT_TEMPLATE_COLUMNS, start=1):
        ws.cell(row=2, column=c, value=example.get(f))
    ws.freeze_panes = "A2"
    info = wb.create_sheet("Instructions")
    lines = [
        "CLIENT IMPORT TEMPLATE - INSTRUCTIONS",
        "1. Fill one client per row on the 'Clients' sheet. Delete the sample row before import.",
        "2. Columns marked * are mandatory.",
        "3. Dates: DD-MM-YYYY. Yes/No columns accept Yes / No.",
        "4. Staff columns take the login username of the staff member.",
        "5. Duplicate GSTINs are rejected. Duplicate PANs are skipped unless you allow them.",
        "6. Compliance records are generated automatically after import.",
        "", "Valid Entity Types:",
    ] + [f"   - {e}" for e in entity_types]
    for i, line in enumerate(lines, start=1):
        info.cell(row=i, column=1, value=line).font = Font(bold=(i == 1))
    info.column_dimensions["A"].width = 100
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    wb.save(path)
    return path


def read_client_import(path: str) -> list[dict]:
    """Read an Excel/CSV client import file into dicts keyed by client field names."""
    import pandas as pd

    if path.lower().endswith(".csv"):
        df = pd.read_csv(path, dtype=str)
    else:
        df = pd.read_excel(path, sheet_name=0, dtype=str)
    header_map = {}
    lookup = {_norm(h): f for h, f in CLIENT_TEMPLATE_COLUMNS}
    lookup.update({_norm(f): f for _, f in CLIENT_TEMPLATE_COLUMNS})
    for col in df.columns:
        f = lookup.get(_norm(col))
        if f:
            header_map[col] = f
    out = []
    for _, row in df.iterrows():
        rec = {}
        for col, f in header_map.items():
            v = row[col]
            if v is None or (isinstance(v, float) and v != v) or str(v).strip().lower() in ("nan", ""):
                v = None
            else:
                v = str(v).strip()
            rec[f] = v
        if any(rec.values()):
            out.append(rec)
    return out
