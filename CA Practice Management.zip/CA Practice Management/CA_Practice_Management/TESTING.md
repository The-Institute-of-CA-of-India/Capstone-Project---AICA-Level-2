# Testing Documentation

## 1. Automated tests
```bat
python -m unittest discover -s tests -v      (or run_tests.bat)
```
Tests run against a temporary folder (`CA_PM_HOME`), never your real data.
Optional GUI smoke test: `set CA_PM_GUI_TEST=1` before running.

| # | Area | Test |
|---|---|---|
| T01 | Validators | PAN, TAN, GSTIN format + check digit |
| T02 | Clients | client creation & folder structure; duplicate PAN; duplicate GSTIN; delete protection when linked |
| T03 | Compliance | generation & no duplicates; applicability (GSTR-4/ITR-1 not created for regular company); due dates (GSTR-3B 20th, TDS March → 30 Apr, 26Q Q4 → 31 May, ITR-6 → 31 Oct); FY periods; revised due date + history; completion & validation; rule versioning |
| T04 | Notices | aging, days left, aging bucket, internal deadline, auto reply task, reminders, reply submission |
| T05 | Tasks | assignment, reassignment, status change, history |
| T06 | Documents | upload, FY folder, retrieval, versioning, soft delete & restore |
| T07 | Excel / PDF | template → import; export; PDF report signature |
| T08 | Backup | backup with documents, verification, restore, safety backup |
| T09 | Startup / migration | idempotent migration, startup checks, dashboard metrics |
| T10 | GUI (optional) | main window and every page open |

## 2. Manual test checklist (demo mode)
Start with `python main.py --demo` on a copy of the folder.

| Step | Expected |
|---|---|
| Login admin / Admin@123 | forced password change, then main window |
| Dashboard cards | numbers shown; clicking each opens a matching list; double-click opens record |
| Clients › Add client with GSTIN wrong check digit | inline error, not saved |
| Add client duplicate GSTIN | blocked; duplicate PAN → warning with “save anyway” |
| Add Pvt Ltd client with GST monthly + TDS | onboarding summary; GSTR-1/3B monthly, 24Q/26Q, AOC-4, MGT-7, ITR-6 generated |
| Applicable Compliances tab: untick GSTR-1 | override saved (pink); not generated |
| GST › Mark Complete with acknowledgment file | status Filed, green; file appears in Documents › client › GST › FY |
| Revise Due Date | revised column filled; history shows reason/source |
| Settings › Compliance Master › Apply Extension | open records of that period get revised date |
| Calendar monthly › drag item to another day | confirmation dialog; internal target or revised date updated |
| Notices › New notice with reply due in 3 days | warning shown; task + reminder created |
| Upload reply version, record reply, add hearing, close | history lists every step |
| Tasks › Staff-wise dashboard | counts per staff |
| Documents › drag-drop 2 files, upload same name again | version 2 created; Versions dialog lists both |
| Move to recycle / restore | file stays on disk; restore works |
| Doc Collection › Generate follow-up tasks | tasks created once per client+compliance |
| Reminders › Run scan, snooze, complete | status updates; history tab logs actions |
| Billing › invoice, partial payment | status Partially Paid; aging buckets |
| Reports › each report › Export PDF / Excel | files open correctly |
| Settings › Backup DB + Documents, Verify | verified; status bar date updated |
| Restore database | safety backup created; app closes; data restored after restart |
| Login as Junior (demo user ajay / Demo@1234) | sees only assigned work; no Billing/Reports/Settings editing |
| Leave idle > lock time | lock dialog requires password |
| Build exe (`build_exe.bat`) and run on a PC without Python | starts without installing anything |
