"""
Global configuration for CA Practice Management & Compliance Tracker.

Bootstrap paths (database file, document root, backup folder) are kept in a
small local JSON file (data/app_config.json) so they survive a database restore.
All other business settings are stored in the SQLite `settings` table.
"""
from __future__ import annotations

import json
import os
import sys

APP_NAME = "CA Practice Management & Compliance Tracker"
APP_SHORT = "CA Practice Tracker"
APP_VERSION = "1.0.0"
DEFAULT_FIRM_NAME = "Niraj Agrawal & Co."
CLIENT_CODE_PREFIX = "NAC"
SCHEMA_VERSION = 1


def _base_dir() -> str:
    """Folder that holds data/, documents/, backups/ and logs/."""
    if os.environ.get("CA_PM_HOME"):
        return os.environ["CA_PM_HOME"]
    if getattr(sys, "frozen", False):          # running as PyInstaller .exe
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


BASE_DIR = _base_dir()
RESOURCE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
TEMPLATE_DIR = os.path.join(DATA_DIR, "templates")
EXPORT_DIR = os.path.join(BASE_DIR, "exports")
LOCAL_CONFIG_FILE = os.path.join(DATA_DIR, "app_config.json")


def default_local_config() -> dict:
    return {
        "db_path": os.path.join(DATA_DIR, "ca_firm.db"),
        "documents_dir": os.path.join(BASE_DIR, "documents", "CA_Firm_Data"),
        "backup_dir": os.path.join(BASE_DIR, "backups"),
    }


def load_local_config() -> dict:
    cfg = default_local_config()
    try:
        if os.path.exists(LOCAL_CONFIG_FILE):
            with open(LOCAL_CONFIG_FILE, "r", encoding="utf-8") as fh:
                stored = json.load(fh)
            for key, value in stored.items():
                if value:
                    cfg[key] = value
    except Exception:
        pass  # a corrupt config file must never stop the application
    return cfg


def save_local_config(updates: dict) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    stored = {}
    if os.path.exists(LOCAL_CONFIG_FILE):
        try:
            with open(LOCAL_CONFIG_FILE, "r", encoding="utf-8") as fh:
                stored = json.load(fh)
        except Exception:
            stored = {}
    stored.update(updates)
    with open(LOCAL_CONFIG_FILE, "w", encoding="utf-8") as fh:
        json.dump(stored, fh, indent=2)


def get_path(key: str) -> str:
    return load_local_config()[key]


def ensure_dirs() -> None:
    cfg = load_local_config()
    for folder in (DATA_DIR, LOG_DIR, TEMPLATE_DIR, EXPORT_DIR,
                   os.path.dirname(cfg["db_path"]), cfg["documents_dir"], cfg["backup_dir"]):
        try:
            os.makedirs(folder, exist_ok=True)
        except OSError:
            pass
