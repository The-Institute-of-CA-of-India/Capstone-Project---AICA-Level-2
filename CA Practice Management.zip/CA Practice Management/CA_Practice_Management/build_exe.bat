@echo off
REM ============================================================
REM  Build Windows .exe for CA Practice Management & Compliance Tracker
REM  Run from the project folder in a Command Prompt.
REM ============================================================
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
pyinstaller --noconfirm --clean --windowed ^
  --name "CA_Practice_Tracker" ^
  --add-data "app\resources;app\resources" ^
  --hidden-import "apscheduler.schedulers.background" ^
  --hidden-import "apscheduler.triggers.interval" ^
  --hidden-import "sqlalchemy.dialects.sqlite" ^
  --collect-submodules "app" ^
  main.py
echo.
echo Build finished. Your application is in:  dist\CA_Practice_Tracker\CA_Practice_Tracker.exe
echo Copy the whole dist\CA_Practice_Tracker folder to the office PC.
echo data\, documents\, backups\ and logs\ folders are created next to the .exe on first run.
pause
