# CA Practice Management & Compliance Tracker
**Niraj Agrawal & Co., Chartered Accountants** — offline-first Windows desktop application

A central operational system for an Indian CA firm: client master, recurring GST / Income-tax / TDS / ROC
compliance engine, compliance calendar, notices, tasks & staff allocation, document repository, client
document collection, reminders, professional-fee billing, reports, backup & restore, audit trail and
role-based security.

> **Disclaimer** – This is a compliance *tracking* and practice-management tool. It does **not** file returns
> on the GSTN, Income-tax, TRACES or MCA portals. All statutory due dates and applicability rules are editable
> defaults; verify them against the latest CBDT / CBIC / MCA notifications (Settings › Compliance Master).

---

## 1. Quick start (run as a Python script)

1. Install **Python 3.12+** from python.org (tick *“Add Python to PATH”*).
2. Unzip this folder, e.g. to `D:\CA_Practice_Management`.
3. Start the application in **any** of these ways:
   * double-click `main.py`, or
   * open `main.py` in **IDLE** and press **F5**, or
   * in Command Prompt: `python main.py`
4. **First run:** missing libraries are installed automatically with pip (internet needed only once).
5. Log in with **admin / Admin@123** – you will be asked to set a new password.
6. On an empty database you are offered **Demo mode** (random sample data) or an empty production start.
   Demo can also be started with `python main.py --demo`.

Manual install (optional): `pip install -r requirements.txt`

## 2. Build the Windows .exe (for staff PCs without Python)

```bat
build_exe.bat
```
or manually:
```bat
pip install -r requirements.txt
pyinstaller --noconfirm --clean --windowed --name CA_Practice_Tracker ^
  --add-data "app\resources;app\resources" ^
  --hidden-import apscheduler.schedulers.background --hidden-import apscheduler.triggers.interval ^
  --hidden-import sqlalchemy.dialects.sqlite --collect-submodules app main.py
```
Output: `dist\CA_Practice_Tracker\CA_Practice_Tracker.exe`. Copy the whole `dist\CA_Practice_Tracker` folder.
In the .exe the auto-install step is skipped (everything is bundled). `data\`, `documents\`, `backups\`,
`logs\` are created next to the .exe. Use `--onefile` only if you accept a slower start-up.

## 3. Folder structure
```
CA_Practice_Management/
├── main.py                 entry point (auto-installs libraries in script mode)
├── config.py               paths & constants
├── requirements.txt  build_exe.bat  run_tests.bat
├── app/
│   ├── app_runner.py       bootstrap, login loop, demo prompt
│   ├── qt.py               PySide6 / PyQt6 compatibility layer
│   ├── database/           db.py, models.py, migrations.py, seed_data.py
│   ├── services/           compliance_engine, client, notice, task, document, collection,
│   │                       billing, reminder_engine, reporting, backup, audit, auth, settings, permissions
│   ├── ui/                 main_window, dashboard, clients, compliance, calendar, gst, income_tax, tds, roc,
│   │                       notices, tasks, documents, collection, reminders, billing, reports, settings,
│   │                       search, login, widgets, styles
│   ├── utils/              validators, excel_utils, pdf_utils, date_utils, formatters, logger
│   └── resources/          icons/ images/ styles/
├── data/ca_firm.db         SQLite database (created on first run)
├── documents/CA_Firm_Data/Clients/<CLIENT_ID>/GST/FY_2026-27 …
├── backups/  logs/  exports/
├── sample_data/            import template, sample clients, sample compliance master
└── tests/                  automated tests
```

## 4. Key design points
* **SQLite + SQLAlchemy**, normalised schema with FKs, unique constraints (no duplicate compliance for the
  same client + form + period; unique GSTIN), indexes on PAN / GSTIN / TAN / CIN.
* **Migrations** – new tables/columns are added automatically; a verified backup is taken before any change.
* **Compliance engine** – applicability JSON per form + per-client overrides; versioned due-date rules with
  effective dates, notification reference & source; revised due dates never overwrite the statutory date.
* **Security** – PBKDF2-SHA256 password hashing, forced first-login password change, role permissions
  (Partner / Manager / Senior / Junior / Admin, editable), auto session lock, audit log, no credentials logged.
  SMTP passwords are requested at send time and never stored.
* **Documents** are stored on disk; only relative paths are in the database. No hard delete from the UI.
* **Backups** – timestamped folders, SQLite online backup, SHA-256 + integrity check, optional documents ZIP,
  daily automatic backup, retention never removes the only backup, safety backup before every restore.

## 5. Testing
See `TESTING.md`. Quick run: `python -m unittest discover -s tests -v` (uses a temporary database).

## 6. User manual
See `USER_MANUAL.md`.

## 7. Troubleshooting
| Problem | Fix |
|---|---|
| Auto-install fails | Connect to internet, run `python -m pip install -r requirements.txt` |
| “No module named PySide6” in IDLE | IDLE uses a different Python – run `py -m pip install PySide6` for that Python |
| Forgot admin password | Another Partner/Admin can reset it in Settings › Users |
| Errors | See `logs/app.log` |
