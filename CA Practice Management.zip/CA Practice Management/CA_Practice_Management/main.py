"""
CA Practice Management & Compliance Tracker
Niraj Agrawal & Co., Chartered Accountants

HOW TO RUN
    * Double-click / run:   python main.py
    * Or open this file in IDLE and press F5.
    * Optional:             python main.py --demo   (loads random demo data)

On the first run as a .py script, missing libraries are installed automatically
with pip (internet needed only for that one-time step).
When packaged with PyInstaller (.exe), all libraries are already bundled and
the install step is skipped completely.
"""
from __future__ import annotations

import importlib
import importlib.util
import os
import subprocess
import sys

APP_DIR = os.path.dirname(os.path.abspath(
    sys.executable if getattr(sys, "frozen", False) else __file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

# (import name, pip package, mandatory?)
REQUIRED_PACKAGES = [
    ("PySide6", "PySide6", True),
    ("sqlalchemy", "SQLAlchemy", True),
    ("pandas", "pandas", True),
    ("openpyxl", "openpyxl", True),
    ("reportlab", "reportlab", True),
    ("docx", "python-docx", False),
    ("apscheduler", "APScheduler", False),
]


def _python_for_pip() -> str:
    """IDLE on Windows runs under pythonw.exe; prefer python.exe for pip."""
    exe = sys.executable or "python"
    if exe.lower().endswith("pythonw.exe"):
        candidate = exe[: -len("pythonw.exe")] + "python.exe"
        if os.path.exists(candidate):
            return candidate
    return exe


def ensure_dependencies() -> bool:
    """Install missing libraries once (script mode only). Returns False if a
    mandatory library could not be installed."""
    if getattr(sys, "frozen", False):
        return True  # PyInstaller build: everything is bundled already
    missing = []
    for module, pip_name, mandatory in REQUIRED_PACKAGES:
        if module == "PySide6":
            # Either Qt binding is acceptable (PySide6 preferred, PyQt6 fallback)
            if importlib.util.find_spec("PySide6") or importlib.util.find_spec("PyQt6"):
                continue
        elif importlib.util.find_spec(module) is not None:
            continue
        missing.append((pip_name, mandatory))
    if not missing:
        return True

    print("=" * 70)
    print(" First-run setup: installing required libraries. Please wait...")
    print(" Packages:", ", ".join(p for p, _ in missing))
    print("=" * 70)
    python = _python_for_pip()
    ok = True
    for pip_name, mandatory in missing:
        try:
            subprocess.check_call([python, "-m", "pip", "install",
                                   "--disable-pip-version-check", pip_name])
        except Exception as exc:  # noqa: BLE001
            print(f"  ! Could not install {pip_name}: {exc}")
            if mandatory:
                ok = False
    importlib.invalidate_caches()
    return ok


def main() -> int:
    if not ensure_dependencies():
        print("\nSome mandatory libraries could not be installed.\n"
              "Please connect to the internet and run again, or install manually:\n"
              "    pip install -r requirements.txt")
        return 1
    from app.app_runner import run
    return run(demo="--demo" in sys.argv)


if __name__ == "__main__":
    exit_code = main()
    # Calling sys.exit inside IDLE shows a noisy traceback - skip it there.
    if "idlelib" not in sys.modules:
        sys.exit(exit_code or 0)
