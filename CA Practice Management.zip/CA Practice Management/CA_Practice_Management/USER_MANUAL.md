# User Manual — CA Practice Management & Compliance Tracker
Niraj Agrawal & Co., Chartered Accountants

## 1. Logging in
* Enter your username and password. First login with `admin / Admin@123` forces a password change.
* The session locks automatically after the configured idle time (default 15 min). Press **Ctrl+L** to lock manually.

## 2. Screen layout
* **Left sidebar** – Dashboard, Clients, Compliance Calendar, All Compliances, GST, Income Tax, TDS/TCS, ROC/MCA,
  Notices, Tasks, Documents, Doc Collection, Reminders, Billing, Reports, Settings.
* **Top bar** – Global search (Ctrl+F), current Financial Year, **＋ Client** (Ctrl+N), **＋ Task** (Ctrl+T),
  🔔 notifications, user menu (change password, lock, log out).
* **Status bar** – last successful backup date (green = recent, red = old / none).
* Colours everywhere: 🟢 Completed · 🔵 In progress · 🟡 Due soon · 🔴 Overdue · ⚪ Not started.

### Keyboard shortcuts
| Key | Action |
|---|---|
| Ctrl+F | Global search | 
| Ctrl+N / Ctrl+T | Quick add client / task |
| Ctrl+1 … Ctrl+9 | Jump to sidebar page |
| F5 | Refresh page |
| Ctrl+L | Lock session |
| Ctrl+B | Backup & Restore |
| Enter / double-click | Open selected record |

## 3. Tables (all screens)
Search box, column filters, **☆ Save filter** (saved filters), click a column header to sort, rows-per-page and
page navigation, **⬇ Export / Print** (Excel, CSV, PDF, Print), right-click context menu.

## 4. Dashboard
14 KPI cards – click any card to open the detailed list; double-click a row to open the record. Widgets: today’s
schedule, upcoming 15 days, overdue list, pending tasks, notice tracker, client-wise pending work, recent
activities, monthly completion chart.

## 5. Clients
* **＋ Add Client** – tabs: Basic, Address & Contact, Engagement & Team, GST profile, Income Tax & TDS, ROC,
  **Applicable Compliances** (auto-selected from the profile; tick/untick to override – overrides shown in pink),
  Contacts.
* PAN / TAN / GSTIN / CIN are validated (GSTIN check-digit). Duplicate GSTIN is blocked; duplicate PAN/TAN warns.
* Saving a new client runs **onboarding**: compliance records for the current FY, document checklists,
  onboarding task, reminders.
* **Profile** – full compliance history, notices, documents, tasks, billing, document collection; export PDF/Word.
* **Deactivate** keeps all history. **Delete** works only when nothing is linked.
* **Import Excel** – use *Import Template* (or `sample_data/Client_Import_Template.xlsx`). **Export Excel** exports the master.

## 6. Compliance (All / GST / Income Tax / TDS / ROC)
* Quick filters: All, Due Today, ≤7 days, ≤15 days, Overdue, Pending, Completed; FY selector.
* **✔ Mark Complete** – status Filed/Completed, filing date, acknowledgment no., challan/CIN, SRN, staff & reviewer,
  attach acknowledgment file (stored in the client repository).
* **📅 Revise Due Date** – records an extension with notification reference and source; statutory date preserved.
* **⚡ Bulk Update** – status / staff / reviewer for many records.
* **📋 Doc Checklist** – required documents for that compliance (received / pending).
* **＋ Manual Entry** – one-off compliances (refunds, registrations, 15CA/CB, corrections…).
* **⚙ Generate FY** – creates recurring entries for all active clients (never duplicates).
* Category pages add focused tabs (payments, annual returns, ITR, tax audit, advance tax, quarterly returns,
  certificates, AGM/board meetings), a **Filing Status Matrix** (client × month/quarter) and a registration list
  (GSTIN-wise / PAN-wise / TAN-wise / CIN-wise).

## 7. Compliance Calendar
Views: Monthly grid, Daily, Weekly, Quarterly, Annual, Financial Year. Filter by client, category, staff; show
notices, tasks and internal target dates. **Drag** an item to another day to reschedule – you choose whether to
change the *internal target date* or record a *revised due date* (needs a reason). Double-click a day for its list.
Export/print from the list views.

## 8. Notices
* **＋ New Notice** – department, category, section, notice no., DIN, dates, reply due date, staff, reviewing partner,
  demand / disputed amount, notice document. The system calculates the internal deadline, creates a reply task and
  reminders, and warns when the reply is due within the warning period (default 7 days).
* Columns show **Days Left** and **Aging**. Quick filters for pending reply, near deadline, overdue, hearings, closed.
* **Reply Draft (Word)** creates a reply skeleton; **Upload Reply Version** stores versions; **Record Reply Submission**
  captures date/ack; **Hearing / Appeal** tracks hearing dates and appeal limitation; **Close Notice** records outcome.

## 9. Tasks
Tabs: Tasks (quick filters My/Today/Week/Overdue/Review), **Staff-wise Dashboard** (assigned, completed, pending,
overdue, due today, awaiting review + compliance & notice load), **Daily/Weekly Allocation**, **Priority Dashboard**.
Comments and full history are inside each task.

## 10. Documents
Folder tree by client › area › FY. Drag-and-drop files onto the drop zone or use **Upload**. Re-uploading the same
file name creates a new version. Preview images/text, open any file in its Windows application, edit tags/remarks,
download a copy. **Move to Recycle** never erases files; use *Show recycled* › **Restore**.

## 11. Doc Collection
Checklist status per compliance: mark received (with date), set follow-up staff/date, **Generate Follow-up Tasks**
for missing documents, client-wise progress %. **Customise Checklists** edits firm-wide or client-specific lists.

## 12. Reminders
Generated automatically at startup and in the background (15/7/3/1 days before, on due date, after due date then
weekly – configurable). Snooze, complete, dismiss, open the related record. Optional **Send Email** (SMTP configured in
Settings; password asked each time) and **WhatsApp** click-to-chat links – nothing is sent automatically.

## 13. Billing
Invoices (auto-numbered NAC/FY/0001, GST computed), payments (partial allowed), outstanding & aging (0-30, 31-60,
61-90, 90+), monthly and annual billing, fee collection.

## 14. Reports
Compliance, Notice, Staff, Client and Billing report catalogue with FY / category / staff / client parameters.
Export to Excel, PDF, CSV or print.

## 15. Settings
Firm profile · Preferences (FY, buffers, warning periods, auto-lock, theme light/dark, date format) · Compliance
statuses · **Compliance Master** (forms, periodicity, applicability JSON, versioned due-date rules with notification
reference & source, extensions, recalculation, checklists) · Users · Roles & Permissions · Email & WhatsApp ·
Storage locations · **Backup & Restore** · Audit trail · Data & Demo.

### Updating a statutory due date (e.g. CBDT extends ITR due date)
1. *One-time extension for a period:* Settings › Compliance Master › open the form › **Apply Extension** – choose FY
   and period, new date, notification reference. Open records get a revised due date; statutory date kept.
2. *Permanent rule change:* **New Rule Version** with effective date + notification → optionally **Recalculate Open Records**.

### Backup routine
* Daily automatic backup at first start each day (DB; documents optional).
* **Backup to Folder / Drive…** for external hard disk / pen drive – recommended weekly with documents.
* Restore always makes a safety backup first; the app closes after a database restore.
