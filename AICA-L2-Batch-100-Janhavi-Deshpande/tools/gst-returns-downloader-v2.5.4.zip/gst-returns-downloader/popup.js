const $ = id => document.getElementById(id);
const send = msg => chrome.runtime.sendMessage(msg);

const TYPE_LABEL = { GSTR1: "GSTR-1", GSTR3B: "GSTR-3B", GSTR2B: "GSTR-2B", GSTR2A: "GSTR-2A" };
const TYPE_ORDER = ["GSTR1", "GSTR3B", "GSTR2B", "GSTR2A"];

function fillYears() {
  const now = new Date();
  const curStart = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  const sel = $("fy");
  for (let y = curStart; y >= 2017; y--) {
    const fy = `${y}-${String((y + 1) % 100).padStart(2, "0")}`;
    sel.add(new Option(fy, fy));
  }
  if (sel.options.length > 1) sel.selectedIndex = 1; // last completed FY
}

const PHASE_TEXT = {
  login: "Waiting for you to log in…",
  running: "Downloading…",
  done: "Finished",
  stopped: "Stopped"
};

const CELL = {
  downloaded: ["✓", "downloaded", "Downloaded"],
  skipped: ["–", "skipped", "Skipped"],
  failed: ["✕", "failed", "Failed"],
  waiting: ["⏳", "waiting", "Being prepared on the portal"],
  generating: ["⏳", "waiting", "The portal is building the Excel"],
  requested: ["⏳", "waiting", "Requested on the portal"],
  current: ["…", "current", "Working"],
  pending: ["·", "pending", "Pending"]
};

function render(job) {
  const active = !!job;
  $("form").hidden = active;
  $("progress").hidden = !active;
  if (!active) return;

  const recheck = job.pass === "recheck" && job.phase === "running";
  $("phase").textContent = (recheck ? "Waiting for GSTR-2A/2B files…" : (PHASE_TEXT[job.phase] || job.phase)) +
    (job.stopReason ? " — " + job.stopReason : "");
  const res = Object.values(job.results);
  const n = s => res.filter(r => r.status === s).length;
  const waiting = n("waiting") + n("requested") + n("generating");
  $("tally").textContent = `FY ${job.fy}${job.scope ? " " + job.scope : ""} · ${n("downloaded")} ✓ · ` +
    `${n("skipped")} skipped · ${n("failed")} failed${waiting ? ` · ${waiting} ⏳` : ""}`;
  const logoutText = !job.logoutAfter ? "" :
    job.logout === "done" ? " · Logged out of GST ✓" :
    job.logout === "in_progress" ? " · Logging out of GST…" :
    (job.phase === "done" || job.phase === "stopped") && job.loggedIn ? " · Not yet logged out" : "";
  $("dest").textContent = `Saving to Downloads/${job.folder}` + logoutText;

  // month × return grid
  const types = TYPE_ORDER.filter(t => job.types.includes(t));
  const current = job.phase === "running"
    ? (job.pass === "recheck" ? job.recheckQueue[0] : job.tasks[job.index]?.key) : null;
  const grid = $("grid");
  grid.innerHTML = "";
  const head = grid.insertRow();
  head.insertCell().textContent = "";
  for (const t of types) { const th = document.createElement("th"); th.textContent = TYPE_LABEL[t]; head.append(th); }
  for (const p of job.periods) {
    const row = grid.insertRow();
    const c0 = row.insertCell();
    c0.textContent = p.label;
    c0.className = "m";
    for (const t of types) {
      const key = `${t}_${p.key}`;
      const r = job.results[key];
      const state = key === current ? "current" : (r ? r.status : "pending");
      const [icon, cls, text] = CELL[state] || CELL.pending;
      const cell = row.insertCell();
      cell.className = "c " + cls;
      cell.textContent = icon;
      const files = (job.files?.[key] || []).length;
      cell.title = `${TYPE_LABEL[t]} · ${p.label}\n${text}${r && r.note ? "\n" + r.note : ""}${files > 1 ? `\n${files} files` : ""}`;
    }
  }

  const finished = job.phase === "done" || job.phase === "stopped";
  $("stop").hidden = finished;
  $("focus").hidden = finished;
  $("skip2a").hidden = !recheck;
  $("folderBtn").hidden = !finished;
  $("again").hidden = !finished;
  $("zip").hidden = !(finished && Object.values(job.files || {}).some(a => a.length));
  $("retry").hidden = !(finished && n("failed") > 0);
  $("retry").textContent = `Retry ${n("failed")} failed`;
}

function folderProblem(v) {
  if (!v.trim()) return "";
  if (/^[a-z]:/i.test(v.trim()) || /^[\\/]/.test(v.trim()) || /^~/.test(v.trim())) {
    return "Enter a folder name inside Downloads (like Clients/ABC), not a full path such as D:\\GST. " +
           "To save on another drive, change Chrome's download location in Settings → Downloads.";
  }
  if (/(^|[\\/])\.\.([\\/]|$)/.test(v)) return "“..” isn't allowed in the folder name.";
  return "";
}

const typeBoxes = () => [...document.querySelectorAll("input.rt")];
const selectedTypes = () => typeBoxes().filter(b => b.checked).map(b => b.value);
function syncTypeUi() {
  const t = selectedTypes();
  $("tErr").hidden = t.length > 0;
  $("wait2aRow").hidden = !(t.includes("GSTR2A") || t.includes("GSTR2B"));
  $("wait2aNote").hidden = $("wait2aRow").hidden;
  $("wait2bRow").hidden = !t.includes("GSTR2B");
}

async function init() {
  fillYears();
  const saved = await chrome.storage.local.get(["savedUserId", "savedFolder", "savedLogoutAfter", "savedTypes", "savedWait2a", "savedWait2b", "seen2b"]);
  if (saved.savedWait2b != null) $("wait2b").value = String(saved.savedWait2b);
  // Upgrading from v2.4: the saved return list predates GSTR-2B, so tick it once
  if (Array.isArray(saved.savedTypes) && !saved.seen2b && !saved.savedTypes.includes("GSTR2B")) saved.savedTypes.push("GSTR2B");
  await chrome.storage.local.set({ seen2b: true });
  if (saved.savedLogoutAfter === false) $("logoutAfter").checked = false;
  if (saved.savedUserId) { $("userId").value = saved.savedUserId; $("password").focus(); }
  if (saved.savedFolder) $("folder").value = saved.savedFolder;
  if (Array.isArray(saved.savedTypes)) typeBoxes().forEach(b => { b.checked = saved.savedTypes.includes(b.value); });
  if (saved.savedWait2a != null) $("wait2a").value = String(saved.savedWait2a);
  syncTypeUi();
  const { job } = await chrome.storage.local.get("job");
  render(job && job.tasks ? job : null);   // ignore a leftover job from v1.x
}

// ----- quarter selection -----
const qBoxes = () => [...document.querySelectorAll("input.q")];
const selectedQuarters = () => qBoxes().filter(b => b.checked).map(b => Number(b.value));
function syncQuarterUi() {
  const n = selectedQuarters().length;
  $("qAll").checked = n === 4;
  $("qAll").indeterminate = n > 0 && n < 4;
  $("qErr").hidden = n > 0;
}
qBoxes().forEach(b => b.addEventListener("change", syncQuarterUi));
$("qAll").addEventListener("change", e => {
  qBoxes().forEach(b => { b.checked = e.target.checked; });
  syncQuarterUi();
});
typeBoxes().forEach(b => b.addEventListener("change", syncTypeUi));

$("skipLogin").addEventListener("change", e => { $("password").disabled = e.target.checked; });
$("folder").addEventListener("input", () => {
  const p = folderProblem($("folder").value);
  $("folderErr").hidden = !p;
  $("folderErr").textContent = p;
});

$("form").addEventListener("submit", async e => {
  e.preventDefault();
  const userId = $("userId").value.trim();
  const password = $("password").value;
  const skipLogin = $("skipLogin").checked;
  const folder = $("folder").value.trim();
  const quarters = selectedQuarters();
  const types = selectedTypes();
  const wait2aMin = Number($("wait2a").value);
  const wait2bEachMin = Number($("wait2b").value);
  if (!userId) return;
  if (!skipLogin && !password) { $("password").focus(); return; }
  if (!types.length) { $("tErr").hidden = false; return; }
  if (!quarters.length) { $("qErr").hidden = false; return; }
  const fp = folderProblem(folder);
  if (fp) { $("folderErr").hidden = false; $("folderErr").textContent = fp; $("folder").focus(); return; }

  if ($("remember").checked) {
    await chrome.storage.local.set({ savedUserId: userId, savedFolder: folder });
  } else {
    await chrome.storage.local.remove(["savedUserId", "savedFolder"]);
  }
  $("password").value = "";
  const logoutAfter = $("logoutAfter").checked;
  await chrome.storage.local.set({ savedLogoutAfter: logoutAfter, savedTypes: types, savedWait2a: wait2aMin, savedWait2b: wait2bEachMin });
  const res = await send({ type: "start", userId, password, fy: $("fy").value, quarters, types, wait2aMin, wait2bEachMin,
                           skipLogin, folder, logoutAfter });
  if (res && res.ok === false) {
    $("qErr").textContent = res.error;
    $("qErr").hidden = false;
  }
});

$("stop").addEventListener("click", () => send({ type: "stop" }));
$("focus").addEventListener("click", () => send({ type: "focusTab" }));
$("skip2a").addEventListener("click", () => send({ type: "skipWaiting" }));
$("folderBtn").addEventListener("click", () => chrome.downloads.showDefaultFolder());
$("zip").addEventListener("click", () => send({ type: "openFinish" }));
$("retry").addEventListener("click", async () => {
  const r = await send({ type: "retryFailed" });
  if (r && r.ok === false && r.error) $("phase").textContent = r.error;
});
$("again").addEventListener("click", () => send({ type: "clear" }));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "job" in changes) {
    const j = changes.job.newValue;
    render(j && j.tasks ? j : null);
  }
});

init();
