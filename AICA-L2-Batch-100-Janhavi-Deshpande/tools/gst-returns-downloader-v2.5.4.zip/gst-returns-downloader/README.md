# GST Returns Bulk Downloader (Chrome extension) — v2.5.4

Built on GSTR-1 Bulk Downloader v1.4. This extension:
- opens the GST portal and fills in your username and password,
- waits for you to type the captcha,
- goes month by month through the Returns Dashboard and downloads every filed **GSTR-1** (PDF),
  **GSTR-3B** (PDF), **GSTR-2B** (Excel) and, if ticked, **GSTR-2A** (Excel) for the financial year,
- saves them in separate **GSTR-1 / GSTR-3B / GSTR-2B / GSTR-2A** folders, and
- puts everything into **one ZIP file** with the same folders, plus a month-wise status sheet.

Emailing has been removed — the ZIP is simply saved in your folder.

## Install
1. Unzip `gst-returns-downloader.zip`.
2. Go to `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and choose the `gst-returns-downloader` folder. Pin it from the puzzle-piece menu.
4. **Recommended:** on the extension's card, click **Details** and turn on **Allow access to file URLs**.
   This lets the extension read the files it saved, so zipping is fully automatic. If you leave it off,
   Chrome asks you to pick the folder once at the ZIP step.

If you used v1.4, remove it first (or load this one alongside it — they are separate extensions).

## Allow automatic downloads for the GST portal (one time — important)
Each run downloads many files from the portal. After the first file, Chrome blocks further automatic
downloads from a site until you allow them. When Chrome shows **"This site is trying to download multiple
files"**, click **Allow**. To set it in advance:
1. Open `chrome://settings/content/automaticDownloads`.
2. Under **Allowed to automatically download multiple files**, click **Add** and enter `https://return.gst.gov.in`.
3. Click **Add** again and enter `https://gstr2b.gst.gov.in` (GSTR-2B files are downloaded from this address).

If this isn't allowed, the first file downloads and later months fail with "Clicked download but no file arrived".

## Use
1. Click the extension icon and fill in:
   - **Username**, **password** and **financial year**.
   - **Returns**: tick GSTR-1, GSTR-3B, GSTR-2B and/or GSTR-2A (GSTR-2A is unticked by default — GSTR-2B is the
     statement ITC is claimed on).
   - **GSTR-2A / 2B: wait for the portal to prepare files** (see below). Default: up to 45 minutes.
   - **Quarter(s)**: tick Q1–Q4, or **Full year**.
   - **Folder inside Downloads**, for example `Clients/ABC Traders/FY {fy}`. `{user}`, `{fy}` and `{q}`
     are filled in automatically. Leave it blank to use `GST Returns/{user}/FY {fy}`.
2. Click **Start**. On the GST login tab, **type the captcha and click LOGIN**.
3. The extension works through each month and return. Leave the GST tab open. The popup shows a
   month × return grid (hover a cell for details).
4. When it finishes, a **Create ZIP** tab opens. It collects the files, builds the ZIP and saves it in the same folder.
   You can redo this any time from the popup with **Create ZIP**.

Example result:
```
Downloads/Clients/ABC Traders/FY 2024-25/
  GSTR-1/   GSTR1_abc_2024-04_Apr.pdf …
  GSTR-3B/  GSTR3B_abc_2024-04_Apr.pdf …
  GSTR-2B/  GSTR2B_abc_2024-04_Apr.xlsx …
  GSTR-2A/  GSTR2A_abc_2024-04_Apr.zip …   (large months may have _part2, _part3 …)
  GST_Returns_abc_FY2024-25.zip            (same folders inside + Download_Status.csv)
```

## How each return is downloaded
- **GSTR-1:** GSTR-1 tile → **VIEW** → **DOWNLOAD (PDF)** (unchanged from v1.4).
- **GSTR-3B:** the same route you use by hand — GSTR-3B tile → **VIEW GSTR3B** → on the GSTR-3B page,
  **DOWNLOAD FILED GSTR-3B** (at the bottom). It never clicks **SYSTEM GENERATED GSTR-3B**, and it does
  not use the tile's plain **DOWNLOAD**, which isn't the filed PDF. A month is only skipped when the tile
  says it isn't filed; hover a cell in the popup to see what the tile showed.
- **GSTR-2B:** GSTR-2B tile → **DOWNLOAD** → "Offline Download for GSTR-2B" page → **GENERATE EXCEL FILE TO DOWNLOAD**
  (or, if the tile only offers VIEW, VIEW → **DOWNLOAD GSTR-2B DETAILS (EXCEL)**). The portal then builds the Excel, which
  takes from a few seconds to several minutes for big months; the extension clicks once and waits. If the portal instead says the file is being prepared (very large months) or shows
  "Click here to download – File N" links, the month is handled like GSTR-2A below. If the portal says GSTR-2B is
  not generated for the period, the month is **Skipped** with the portal's words in the note.
- **GSTR-2A:** GSTR-2A tile → **DOWNLOAD** → **GENERATE EXCEL FILE TO DOWNLOAD**. The portal prepares
  the file in the background, usually within 20 minutes. So the extension:
  1. requests the file for every month during the main pass (and downloads it at once if the portal
     already has one ready),
  2. after the last month, waits on the dashboard and **comes back every 5 minutes** for the months
     still being prepared, clicking each "Click here to download – File N" link,
  3. stops waiting after the limit you chose. Months not ready by then are marked **Failed** with a note.
     Run again later for just GSTR-2A — the portal keeps the generated files, so they download straight away.
  - Choose **Don't wait** to only request the files; run again later to collect them.
  - **Stop waiting for GSTR-2A** in the popup ends the wait early and goes to the ZIP step.

## Logging out
**Log out of the GST portal when finished** is ticked by default. Once everything is processed (including
the GSTR-2A wait), the extension clicks the portal's own **Logout** link, or opens
`services.gst.gov.in/services/logout`. **Stop** mid-run also logs you out, and closing the GST tab ends
the session in the background. Untick the option to stay logged in.

## Skipped months
Marked **Skipped** (–) and listed in `Download_Status.csv`:
- GSTR-1 / GSTR-3B not filed for that month,
- months with no tile (e.g. the first two months of a quarter for QRMP filers),
- GSTR-2A months where the portal reports no records,
- future months.

## What's new in v2.5.3 / v2.5.4 (checked on the live portal)
- v2.5.4: the BACK-button return is used only on the GSTR-2B site; GSTR-1 and GSTR-3B return to the dashboard exactly as in v2.4.
- **After each GSTR-2B month the extension now clicks the page's own BACK button** to return to the Returns Dashboard.
  Opening the dashboard address directly from the GSTR-2B site could end the portal session ("Access Denied").
- **If the session does end, the extension no longer opens the login page by itself.** It asks you (banner) to click
  "here" on the Access Denied page and log in; the run then carries on. This stops a run in one tab from logging out
  a session you are using in another tab.
- A run left over from more than 8 hours ago stops itself instead of acting when you next open the portal.
- Live check (Q1 FY 2025-26): tile DOWNLOAD → gstr2b.gst.gov.in/gstr2b/auth/gstr2bdwld → GENERATE EXCEL FILE TO DOWNLOAD
  → the portal fetches the month's 2B and saves the Excel within seconds → BACK → next month.
- Tip: the GST portal allows one session per login. Don't log in on another tab or run two clients at once in the
  same Chrome profile while a run is going.

## What's new in v2.5.2
- **Fix: GSTR-2B stayed on "Working" and nothing happened.** The GSTR-2B download page opens on its own address
  (`gstr2b.gst.gov.in/gstr2b/auth/gstr2bdwld`), where v2.5/v2.5.1 did not run. Checked on the live portal: GENERATE EXCEL
  FILE TO DOWNLOAD fetches the month's 2B and builds the Excel in the page, usually within seconds.
- Allow automatic downloads for `https://gstr2b.gst.gov.in` too (see above), or only the first GSTR-2B month is saved. The extension now runs on every
  `*.gst.gov.in` page (it still acts only in the tab of your run), so it finds GENERATE EXCEL FILE TO DOWNLOAD there.

## What's new in v2.5.1
- **GSTR-2B no longer gets stuck on slow months.** After **GENERATE EXCEL FILE TO DOWNLOAD** the portal can take several
  minutes to build the Excel (the page may even look frozen). The extension now clicks **once** and waits — up to the time
  you choose in the popup (**GSTR-2B: time the portal may take to build each month's Excel**, default 10 minutes), and
  longer while the portal's loader is still showing. It never clicks again while a file may still be on its way (v2.5
  re-clicked after 60 seconds, which restarted the portal's work), also not after a page reload.
- The banner shows how long the portal has been working. Please keep the GST tab open and don't click while it waits.
- A file that arrives after the month was given up on is still saved under the right name and marked downloaded.
- If a month still has no file after the wait, it goes to the re-check round instead of failing straight away.

## What's new in v2.5
- **GSTR-2B download** (Excel), in its own **GSTR-2B** folder and in the ZIP. Ticked by default; GSTR-2A is now unticked
  by default (tick it when you also want 2A).
- The "wait for the portal" setting and **Stop waiting** button now cover GSTR-2A and GSTR-2B.
- The ZIP opens directly in the **GST Reconciliation** page (step 1), which reads GSTR-2B as well.
- First run after upgrading from v2.4 ticks GSTR-2B once, even if your saved choice was GSTR-1/3B/2A.

## What's new in v2.4
- **GSTR-3B: no more "Clicked DOWNLOAD FILED GSTR-3B but no file arrived" on some months.** The extension
  now waits for the GSTR-3B page to finish loading before clicking, and tries up to 3 times if the
  portal doesn't respond. If the portal shows a message, the note quotes it.
- **Retry failed** button in the popup: after a run, it reruns only the months marked ✕ (log in again if
  the portal asks), then rebuilds the ZIP.
- A slow file from an earlier click is saved under the right name instead of landing loose in Downloads.

## What's new in v2.3
- **GSTR-3B tile is now found by its own VIEW GSTR3B button**, and its status is read from the
  "Status-" line just above that button. v2.2 searched from the tile's heading and, on the live portal,
  reported "No GSTR-3B tile" for every month.
- Special hyphen characters (e.g. "GSTR‑3B" written with a non-breaking hyphen) no longer stop any return's
  tile from being found.
- If the GSTR-3B button can't be found while GSTR-3B is shown on the page, the month is marked **Failed**
  (not silently skipped), and the note lists the buttons the extension saw.

## What's new in v2.2
- **GSTR-3B now follows the portal's route for the filed PDF:** VIEW GSTR3B → DOWNLOAD FILED GSTR-3B.
  v2.1 clicked the tile's plain DOWNLOAD first, which doesn't give the filed return.
- Waits for DOWNLOAD FILED GSTR-3B to become clickable while the return loads.

## What's new in v2.1
- **GSTR-3B fixed.** v2.0 could mark every GSTR-3B month as "not filed" when the tile's status loaded a
  moment late, or when a notice mentioning GSTR-3B was on the dashboard. Both are handled now.
- Skipped/failed GSTR-3B notes now quote the portal's tile text, so the reason is visible on hover.
- To fetch only the missing GSTR-3B for a client, tick just **GSTR-3B** and run again.

## Good to know
- **Captcha is manual by design.** The extension never tries to read or solve it.
- **Password handling:** your password stays in Chrome's in-memory session storage only until login
  succeeds, then it's wiped. It is never written to disk. **Remember** stores only the username and folder.
- **"I'm already logged in"** skips the login step.
- If your session expires mid-run (for example during a long GSTR-2A wait), log in again and the run carries on.
- **GSTR-2B labels:** the GSTR-2B steps look for the portal's usual labels ("GENERATE EXCEL FILE TO DOWNLOAD",
  "DOWNLOAD GSTR-2B DETAILS (EXCEL)"). If a month fails, the note lists the buttons the extension saw — send that
  line and the label can be added.
- The extension finds the portal's controls by their visible labels. The GSTR-3B and GSTR-2A steps follow
  the portal's usual labels; if the portal words a button differently, that month is marked **Failed** with
  the reason and the run continues. Watch your first run.

## Files
- `manifest.json`: permissions are `storage`, `downloads`, `unlimitedStorage`, and access to
  `*.gst.gov.in` (login, returns dashboard and the separate GSTR-2B site) and local files (only used to read the files this extension saved, for the ZIP).
- `background.js`: run state (month × return tasks, GSTR-2A/2B re-check pass), password in memory, download naming.
- `content.js`: login fill, dashboard navigation and the GSTR-1 / GSTR-3B / GSTR-2B / GSTR-2A download steps.
- `finish.html` / `finish.js`: collects the files, builds and saves the ZIP with a status sheet.
- `zip.js`: small built-in ZIP writer, with no external libraries.
- `popup.*`: start form and progress grid.
