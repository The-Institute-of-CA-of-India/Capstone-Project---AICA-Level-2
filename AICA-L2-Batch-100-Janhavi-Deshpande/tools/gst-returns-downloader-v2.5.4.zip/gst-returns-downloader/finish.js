const $ = id => document.getElementById(id);

let job, zipBlob, zipName, zipDownloadId;

const TYPE_LABEL = { GSTR1: "GSTR-1", GSTR3B: "GSTR-3B", GSTR2B: "GSTR-2B", GSTR2A: "GSTR-2A" };
const TYPE_FOLDER = { GSTR1: "GSTR-1", GSTR3B: "GSTR-3B", GSTR2B: "GSTR-2B", GSTR2A: "GSTR-2A" };

const STEPS = [
  ["collect", "Collect downloaded returns"],
  ["zip", "Create ZIP"],
  ["save", "Save ZIP in your folder"]
];
const stepState = {};
function setStep(id, state, text) {
  stepState[id] = { state, text };
  const ul = $("steps");
  ul.innerHTML = "";
  for (const [sid, label] of STEPS) {
    const s = stepState[sid] || { state: "idle" };
    const li = document.createElement("li");
    const ico = document.createElement("span");
    ico.className = "ico " + s.state;
    ico.textContent = { ok: "✓", bad: "✕", wait: "…", idle: "○", skip: "–" }[s.state] || "○";
    const body = document.createElement("span");
    body.textContent = label + (s.text ? " — " + s.text : "");
    li.append(ico, body);
    ul.append(li);
  }
}
const log = t => { $("log").textContent += t + "\n"; };

// ---------- reading the downloaded files ----------
function toFileUrl(path) {
  const p = path.replace(/\\/g, "/");
  const withSlash = p.startsWith("/") ? p : "/" + p;      // Windows: C:/… → /C:/…
  return "file://" + withSlash.split("/").map((s, i) => (i === 1 && /^[A-Za-z]:$/.test(s)) ? s : encodeURIComponent(s)).join("/");
}

function readViaFileUrl(path) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", toFileUrl(path));
    xhr.responseType = "arraybuffer";
    xhr.onload = () => (xhr.response && xhr.response.byteLength)
      ? resolve(new Uint8Array(xhr.response)) : reject(new Error("empty"));
    xhr.onerror = () => reject(new Error("blocked"));
    xhr.send();
  });
}

const typeOfKey = key => key.split("_")[0];

async function downloadedItems() {
  const items = [];
  for (const [key, ids] of Object.entries(job.files || {})) {
    for (const id of [].concat(ids)) {
      const [item] = await chrome.downloads.search({ id });
      if (item && item.state === "complete" && item.exists !== false) items.push({ key, type: typeOfKey(key), item });
    }
  }
  items.sort((a, b) => a.type.localeCompare(b.type) || baseName(a.item.filename).localeCompare(baseName(b.item.filename)));
  return items;
}

const baseName = p => p.split(/[\\/]/).pop();
const dirName = p => p.slice(0, p.length - baseName(p).length - 1);
const zipPath = it => `${TYPE_FOLDER[it.type] || it.type}/${baseName(it.item.filename)}`;

async function collectAutomatically(items) {
  const allowed = await chrome.extension.isAllowedFileSchemeAccess();
  if (!allowed) return null;
  const out = [];
  for (const it of items) {
    out.push({ name: zipPath(it), data: await readViaFileUrl(it.item.filename),
               date: new Date(it.item.endTime || Date.now()) });
  }
  return out;
}

async function collectViaPicker(items) {
  const root = await window.showDirectoryPicker({ id: "gstreturns", startIn: "downloads", mode: "read" });
  const out = [];
  const missing = [];
  for (const it of items) {
    const name = baseName(it.item.filename);
    const sub = TYPE_FOLDER[it.type];
    try {
      // The chosen folder may be the run folder (with GSTR-x subfolders) or one of the subfolders
      let dir = root;
      try { dir = await root.getDirectoryHandle(sub); } catch { /* files may be directly in root */ }
      const f = await (await dir.getFileHandle(name)).getFile();
      out.push({ name: zipPath(it), data: new Uint8Array(await f.arrayBuffer()), date: new Date(f.lastModified) });
    } catch { missing.push(`${sub}/${name}`); }
  }
  if (missing.length) {
    throw new Error(`These files weren't in the folder you picked: ${missing.join(", ")}`);
  }
  return out;
}

// ---------- month-wise status sheet (included in the ZIP) ----------
function statusCsv() {
  const cell = v => { const s = String(v ?? ""); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const rows = [["GST username", "Financial year", "Return", "Month", "Status", "Files", "Note"]];
  for (const t of job.tasks) {
    const p = job.periods.find(x => x.key === t.period);
    const r = job.results[t.key];
    rows.push([job.userId, job.fy, TYPE_LABEL[t.type], p ? p.label : t.period,
               r ? r.status : "not processed", (job.files?.[t.key] || []).length, r?.note || ""]);
  }
  return "\uFEFF" + rows.map(r => r.map(cell).join(",")).join("\r\n");
}

// ---------- pipeline ----------
async function build(files) {
  setStep("collect", "ok", `${files.length} file(s)`);
  setStep("zip", "wait");
  files.push({ name: "Download_Status.csv", data: new TextEncoder().encode(statusCsv()), date: new Date() });
  zipName = `GST_Returns_${job.userId}_FY${job.fy}${job.scope ? "_" + job.scope : ""}.zip`.replace(/[\\/:*?"<>|]/g, "_");
  zipBlob = makeZip(files);
  setStep("zip", "ok", `${zipName} (${(zipBlob.size / 1024 / 1024).toFixed(2)} MB)`);

  setStep("save", "wait");
  const url = URL.createObjectURL(zipBlob);
  await chrome.storage.session.set({ ownDownload: `${job.folder}/${zipName}` });
  zipDownloadId = await chrome.downloads.download({
    url, filename: `${job.folder}/${zipName}`, conflictAction: "overwrite"
  });
  setTimeout(() => URL.revokeObjectURL(url), 120000);
  setStep("save", "ok", `Downloads/${job.folder}/${zipName}`);
  $("showZip").hidden = false;
}

async function run() {
  $("retry").hidden = true;
  const items = await downloadedItems();
  if (!items.length) {
    setStep("collect", "bad", "no downloaded return files found for this run");
    STEPS.slice(1).forEach(([id]) => setStep(id, "skip"));
    return;
  }
  setStep("collect", "wait", `${items.length} file(s)`);
  $("folderPath").textContent = `Downloads/${job.folder}`;

  try {
    const files = await collectAutomatically(items);
    if (files) return await build(files);
  } catch (e) {
    log("Couldn't read files directly (" + e.message + "). Using the folder picker instead.");
  }
  // Fallback: the user points Chrome at the folder (needs a click)
  setStep("collect", "wait", "choose the folder below");
  $("pickBox").hidden = false;
  $("pick").onclick = async () => {
    try {
      const files = await collectViaPicker(items);
      $("pickBox").hidden = true;
      await build(files);
    } catch (e) {
      if (e.name === "AbortError") return;
      setStep("collect", "bad", e.message);
      $("retry").hidden = false;
    }
  };
}

$("retry").onclick = () => { $("log").textContent = ""; run(); };
$("showZip").onclick = () => zipDownloadId && chrome.downloads.show(zipDownloadId);

(async () => {
  job = (await chrome.storage.local.get("job")).job;
  if (!job || !job.tasks) { $("summary").textContent = "No completed run found."; return; }
  const by = t => Object.entries(job.results).filter(([k, r]) => k.startsWith(t + "_") && r.status === "downloaded").length;
  const parts = job.types.map(t => `${TYPE_LABEL[t]} ${by(t)}`).join(" · ");
  $("summary").textContent = `GST user ${job.userId} · FY ${job.fy}${job.scope ? " " + job.scope : ""} · downloaded: ${parts} · saved in Downloads/${job.folder}`;
  STEPS.forEach(([id]) => setStep(id, "idle"));
  run();
})();
