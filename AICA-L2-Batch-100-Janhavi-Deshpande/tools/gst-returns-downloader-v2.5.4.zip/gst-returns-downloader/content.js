// Runs on every *.gst.gov.in page (the GSTR-2B download page lives on its own address, e.g. gstr2b.gst.gov.in).
// Only acts in the tab the run was started in.
// For each task (month × return type) it selects the month on the Returns Dashboard, finds that
// return's tile and clicks the portal's own buttons; background.js catches and names the file.

const DASHBOARD_URL = "https://return.gst.gov.in/returns/auth/dashboard";
const DOWNLOAD_LABELS = ["DOWNLOAD (PDF)", "DOWNLOAD PDF", "DOWNLOAD SUMMARY (PDF)", "DOWNLOAD SUMMARY"];
const GENERATE_2A_LABELS = ["GENERATE EXCEL FILE TO DOWNLOAD", "GENERATE EXCEL FILE", "GENERATE EXCEL"];
// GSTR-2B: the tile's DOWNLOAD page offers "Generate Excel file to download"; the VIEW (summary) page
// offers "Download GSTR-2B details (Excel)". Either gives the same Excel workbook.
const EXCEL_2B_LABELS = ["GENERATE EXCEL FILE TO DOWNLOAD", "DOWNLOAD GSTR-2B DETAILS (EXCEL)", "DOWNLOAD GSTR2B DETAILS (EXCEL)",
  "DOWNLOAD DETAILS (EXCEL)", "DOWNLOAD GSTR-2B (EXCEL)", "DOWNLOAD EXCEL", "GENERATE EXCEL FILE", "GENERATE EXCEL"];
const QUARTER_HINT = { 1: "apr", 2: "jul", 3: "oct", 4: "jan" };

const sleep = ms => new Promise(r => setTimeout(r, ms));
const norm = s => (s || "").replace(/\s+/g, " ").trim().toLowerCase();
const send = msg => chrome.runtime.sendMessage(msg);
const isVisible = el => !!el && el.getClientRects().length > 0 &&
  getComputedStyle(el).visibility !== "hidden";

let stopped = false;
let isJobTab = false;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.job) return;
  const j = changes.job.newValue;
  const before = changes.job.oldValue;
  if (!j) { stopped = true; removeBanner(); return; }
  if (j.phase === "stopped" && (!before || before.phase !== "stopped")) {
    stopped = true;
    removeBanner();
    // Stopped mid-run: still log out, so the portal session isn't left open
    if (isJobTab) maybeLogout(j);
  }
});

// ---------- logout ----------
const LOGOUT_URL = "https://services.gst.gov.in/services/logout";
const isLogoutPage = () => location.host === "services.gst.gov.in" && /\/services\/logout/i.test(location.pathname);

function summaryText(job) {
  const n = Object.values(job.results || {}).filter(r => r.status === "downloaded").length;
  return `${job.phase === "stopped" ? "Stopped" : "Finished"} — ${n} return file(s) downloaded.`;
}

async function maybeLogout(job) {
  if (!job.logoutAfter || !job.loggedIn || job.logout === "done") return false;

  // Second visit: we are on the logout page (or were sent back to login) → confirm and finish
  if (job.logout === "in_progress" && (isLogoutPage() || isLoginPage() || !/\/auth\//i.test(location.pathname))) {
    await send({ type: "loggedOut" });
    banner(`${summaryText(job)} Logged out of the GST portal.`, "ok");
    return true;
  }

  const { proceed } = await send({ type: "loggingOut" });
  if (!proceed) return true;
  banner(`${summaryText(job)} Logging out of the GST portal…`);
  await sleep(800);

  // Prefer the portal's own Logout link (it runs the portal's own clean-up first)
  const link = [...document.querySelectorAll("a, button")].find(el =>
    isVisible(el) && /^log\s*-?\s*out$/i.test((el.innerText || el.textContent || "").trim()));
  if (link) {
    link.click();
    await sleep(4000);
    // Still here after the click (e.g. a confirmation dialog)? Use the portal's logout address directly.
    if (/\/auth\//i.test(location.pathname)) location.assign(LOGOUT_URL);
  } else {
    location.assign(LOGOUT_URL);
  }
  return true;
}

async function waitFor(fn, timeout = 20000, interval = 400) {
  const end = Date.now() + timeout;
  while (Date.now() < end && !stopped) {
    try { const v = fn(); if (v) return v; } catch { /* keep polling */ }
    await sleep(interval);
  }
  return null;
}

function findButton(labels, root = document) {
  const els = [...root.querySelectorAll("button, a, input[type=button], input[type=submit]")]
    .filter(e => isVisible(e) && !e.disabled);
  const text = e => norm(e.innerText || e.value || "");
  for (const l of labels) { const h = els.find(e => text(e) === norm(l)); if (h) return h; }
  for (const l of labels) { const h = els.find(e => text(e).includes(norm(l))); if (h) return h; }
  return null;
}

function setInputValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
  input.focus();
  setter.call(input, value);
  for (const t of ["input", "change", "keyup", "blur"]) {
    input.dispatchEvent(new Event(t, { bubbles: true }));
  }
}

function labelFor(sel) {
  let t = `${sel.name || ""} ${sel.id || ""} ${sel.getAttribute("ng-model") || ""}`;
  if (sel.id) {
    const l = document.querySelector(`label[for="${CSS.escape(sel.id)}"]`);
    if (l) t += " " + l.innerText;
  }
  const grp = sel.closest(".form-group, [class*='col-']");
  if (grp) { const l = grp.querySelector("label"); if (l) t += " " + l.innerText; }
  return norm(t);
}

function findSelect(words, fallbackIndex, exclude = []) {
  const sels = [...document.querySelectorAll("select")].filter(s => isVisible(s) && !exclude.includes(s));
  const hit = sels.find(s => words.some(w => labelFor(s).includes(w)));
  if (hit) return hit;
  const all = [...document.querySelectorAll("select")].filter(isVisible);
  const fb = all[fallbackIndex];
  return fb && !exclude.includes(fb) ? fb : null;
}

async function chooseOption(sel, matcher, timeout = 10000) {
  const opt = await waitFor(() =>
    [...sel.options].find(o => o.value !== "" && !/^select/i.test(o.text.trim()) && matcher(norm(o.text))),
    timeout);
  if (!opt) return false;
  if (sel.value !== opt.value) {
    sel.value = opt.value;
    sel.dispatchEvent(new Event("change", { bubbles: true }));
    sel.dispatchEvent(new Event("input", { bubbles: true }));
  }
  return true;
}

// Dashboard tiles. GSTR-1 must not match GSTR-1A; GSTR-3B, GSTR-2A and GSTR-2B must not match each other.
const TILE_RE = {
  GSTR1:  /gstr\s*-?\s*1(?![0-9a-z])/i,
  GSTR3B: /gstr\s*-?\s*3\s*b(?![0-9a-z])/i,
  GSTR2A: /gstr\s*-?\s*2\s*a(?![0-9a-z])/i,
  GSTR2B: /gstr\s*-?\s*2\s*b(?![0-9a-z])/i
};
function findTile(type) {
  const re = TILE_RE[type];
  const cands = [...document.querySelectorAll("div, section, li, td")]
    .filter(el => isVisible(el) && re.test(String(el.innerText || "").replace(/[\u2010-\u2015\u2212\u00ad]/g, "-")) &&
                  findButton(["VIEW", "DOWNLOAD"], el));
  if (!cands.length) return null;
  // smallest container that still holds the heading and its buttons
  cands.sort((a, b) => a.innerText.length - b.innerText.length);
  return cands[0];
}

const isDashboard = () =>
  location.host === "return.gst.gov.in" && /\/returns\/auth\/dashboard/i.test(location.pathname + location.hash);
const isLoginPage = () =>
  location.host === "services.gst.gov.in" && /\/services\/login/i.test(location.pathname);

function go(url) { location.assign(url); }

// ---------- on-page status banner ----------
let bannerHost;
function banner(text, tone = "info") {
  if (!bannerHost) {
    bannerHost = document.createElement("div");
    bannerHost.style.cssText = "position:fixed;z-index:2147483647;left:50%;top:12px;transform:translateX(-50%);";
    const root = bannerHost.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        .b{font:13px/1.4 system-ui,sans-serif;display:flex;gap:12px;align-items:center;
           padding:10px 14px;border-radius:8px;box-shadow:0 4px 18px rgba(0,0,0,.25);
           background:#123c69;color:#fff;max-width:640px}
        .b.warn{background:#9a5b00}.b.ok{background:#1b6e3a}
        button{font:inherit;background:rgba(255,255,255,.18);color:#fff;border:0;
               border-radius:5px;padding:4px 10px;cursor:pointer}
      </style>
      <div class="b"><span id="t"></span><button id="s">Stop</button></div>`;
    root.getElementById("s").onclick = () => { send({ type: "stop" }); };
    document.documentElement.appendChild(bannerHost);
  }
  const root = bannerHost.shadowRoot;
  root.querySelector(".b").className = "b " + tone;
  root.getElementById("t").textContent = "GST Downloader: " + text;
}
function removeBanner() { if (bannerHost) { bannerHost.remove(); bannerHost = null; } }

// ---------- login ----------
// The GST login form contains a hidden decoy <input type="password" name="user_pass">
// placed before the real one, so always target the real, visible field by id.
const firstVisible = sels => {
  for (const s of sels) {
    const el = [...document.querySelectorAll(s)].find(isVisible);
    if (el) return el;
  }
  return null;
};
const getUserField = () => firstVisible(["#username", "input[name=user_name]"]);
const getPassField = () => firstVisible(["#user_pass", "input[type=password][data-ng-model]", "input[type=password]"]);
const getCaptchaField = () => firstVisible(["#captcha", "input[name=captcha]", "input[id*=captcha i]"]);

async function doLogin() {
  const { userId, password } = await send({ type: "getCredentials" });

  const user = await waitFor(getUserField, 20000);
  const pass = await waitFor(getPassField, 20000);
  if (!user || !pass) {
    banner("Couldn't find the login fields. Please log in manually; downloads will start after login.", "warn");
    return;
  }

  // Wait until AngularJS has compiled the form, otherwise it resets the values we set
  await waitFor(() => /\bng-(pristine|dirty)\b/.test(pass.className), 10000, 200);

  if (userId) setInputValue(user, userId);
  if (password) {
    if (password.length > 15) {
      banner("Your password is longer than the 15 characters the portal accepts. Please check it.", "warn");
    }
    setInputValue(pass, password);
  }

  // Confirm both values reached the page's form model (it marks filled fields "ng-not-empty")
  await sleep(400);
  if (userId && user.value !== userId) setInputValue(user, userId);
  if (password && pass.value !== password) setInputValue(pass, password);
  const passOk = !password || (pass.value === password.slice(0, 15) && /ng-not-empty/.test(pass.className));

  banner(!password
    ? "Please enter your password and the captcha, then click LOGIN."
    : passOk
      ? "Username and password filled. Type the captcha and click LOGIN; downloads start automatically."
      : "Couldn't fill the password automatically. Please type it, then the captcha, and click LOGIN.",
    "warn");

  // The captcha box is added after the page loads; focus it as soon as it appears
  const captcha = await waitFor(getCaptchaField, 30000);
  if (captcha) captcha.focus();

  // After a wrong captcha the portal clears the password; put it back so only the captcha needs retyping
  if (password && passOk) keepPasswordFilled(password);
}

function keepPasswordFilled(password) {
  let userTyped = false;
  const watch = async () => {
    while (!stopped && isLoginPage()) {
      const pass = getPassField();
      if (pass && !pass.dataset.gstrWatch) {
        pass.dataset.gstrWatch = "1";
        pass.addEventListener("keydown", () => { userTyped = true; });
      }
      if (pass && !userTyped && pass.value === "" && document.activeElement !== pass) {
        setInputValue(pass, password);
        const c = getCaptchaField();
        if (c) c.focus();
        banner("Login didn't go through (likely a wrong captcha). Password re-filled; type the new captcha and click LOGIN.", "warn");
      }
      await sleep(800);
    }
  };
  watch();
}

// ---------- one task (month × return type) on the Returns Dashboard ----------
const TYPE_LABEL = { GSTR1: "GSTR-1", GSTR3B: "GSTR-3B", GSTR2A: "GSTR-2A", GSTR2B: "GSTR-2B" };
const periodOf = (job, task) => job.periods.find(p => p.key === task.period);

function position(job) {
  if (job.pass === "recheck") return `GSTR-2A/2B re-check, ${job.recheckQueue.length} left`;
  return `${job.index + 1}/${job.tasks.length}`;
}

async function finish(task, status, note) {
  await send({ type: "taskDone", key: task.key, status, note });
  await sleep(1200); // be gentle with the portal
  // The GSTR-2B page (gstr2b.gst.gov.in) must be left with its own BACK button: opening the dashboard address
  // directly from there ends the portal session ("Access Denied"). Checked on the live portal.
  // (GSTR-1 / GSTR-3B pages: unchanged from v2.4 — straight to the dashboard address.)
  if (location.host === "gstr2b.gst.gov.in") {
    const back = findButton(["BACK"]);
    if (back) { back.click(); await sleep(6000); if (location.host === "gstr2b.gst.gov.in" && findButton(["BACK"])) history.back(); return; }
    history.back();
    return;
  }
  go(DASHBOARD_URL);
}

// Wait for background.js to confirm that `count` file(s) for this task were caught and renamed
async function waitForFiles(key, count = 1, timeout = 90000) {
  const end = Date.now() + timeout;
  while (Date.now() < end && !stopped) {
    const { job: j } = await send({ type: "hello" });
    if ((j?.files?.[key] || []).length >= count) return true;
    await sleep(1000);
  }
  return false;
}

async function selectMonth(job, p) {
  const fySel = await waitFor(() => findSelect(["financial year", "fin"], 0), 30000);
  if (!fySel) return "Couldn't find the Financial Year dropdown";
  const fyAlt = job.fy.slice(0, 5) + "20" + job.fy.slice(5); // 2023-24 → 2023-2024
  if (!(await chooseOption(fySel, t => t.includes(job.fy) || t.includes(fyAlt)))) {
    return `FY ${job.fy} isn't offered on the dashboard`;
  }
  await sleep(700);

  const qSel = findSelect(["quarter"], 1, [fySel]);
  if (qSel) {
    await chooseOption(qSel, t =>
      new RegExp(`quarter\\s*-?\\s*${p.quarter}(?!\\d)`).test(t) || t.includes(QUARTER_HINT[p.quarter]));
    await sleep(700);
  }

  const mSel = findSelect(["period", "month"], 2, [fySel, qSel].filter(Boolean));
  if (!mSel) return "Couldn't find the Period dropdown";
  if (!(await chooseOption(mSel, t => t.startsWith(p.month.toLowerCase()) || t.startsWith(p.short.toLowerCase())))) {
    return "skip:Month not offered for this FY";
  }
  await sleep(500);

  const search = findButton(["SEARCH"]);
  if (!search) return "Search button not found";
  search.click();
  return "";
}

async function dashboardStage(job, task) {
  const p = periodOf(job, task);
  const label = TYPE_LABEL[task.type];
  banner(`(${position(job)}) Selecting ${p.label} for ${label}…`);

  const problem = await selectMonth(job, p);
  if (problem.startsWith("skip:")) return finish(task, "skipped", problem.slice(5));
  if (problem) return finish(task, "failed", problem);

  banner(`(${position(job)}) Looking for ${label} for ${p.label}…`);
  if (task.type === "GSTR3B") {
    await waitFor(() => find3b(), 25000);
    return gstr3bFromTile(job, task);
  }
  const tile = await waitFor(() => findTile(task.type), 20000);
  if (!tile) {
    return finish(task, "skipped", task.type === "GSTR2A" || task.type === "GSTR2B"
      ? `No ${label} tile for this period${task.type === "GSTR2B" ? " (for quarterly filers GSTR-2B may be quarterly)" : ""}`
      : `No ${label} tile (quarterly filer, or not applicable for this month)`);
  }

  if (task.type === "GSTR1") return gstr1FromTile(job, task, tile);
  if (task.type === "GSTR2B") return gstr2bFromTile(job, task, tile);
  return gstr2aFromTile(job, task, tile);
}

function filedOrSkip(tile) {
  const t = norm(tile.innerText);
  return /not filed|to be filed|not yet filed/.test(t) || !/filed/.test(t);
}

// ----- GSTR-1: tile VIEW → DOWNLOAD (PDF)   (unchanged from v1.4) -----
async function gstr1FromTile(job, task, tile) {
  if (filedOrSkip(tile)) return finish(task, "skipped", "GSTR-1 not filed for this period");
  const view = findButton(["VIEW"], tile);
  if (!view) return finish(task, "failed", "VIEW button not found on the GSTR-1 tile");
  await send({ type: "setStep", step: "page", attempt: (job.attempt || 0) + 1 });
  view.click();

  // The portal may change route in-page or do a full page load; handle the in-page case here.
  const moved = await waitFor(() => !isDashboard() || findButton([...DOWNLOAD_LABELS, "VIEW SUMMARY"]), 20000);
  if (moved && !stopped) return gstr1Page((await send({ type: "hello" })).job, task);
  return finish(task, "failed", "GSTR-1 page didn't open");
}

async function gstr1Page(job, task) {
  const p = periodOf(job, task);
  banner(`(${position(job)}) Downloading GSTR-1 for ${p.label}…`);
  let btn = await waitFor(() => findButton(DOWNLOAD_LABELS) || findButton(["VIEW SUMMARY"]), 25000);
  if (btn && /view summary/.test(norm(btn.innerText))) {
    btn.click();
    btn = await waitFor(() => findButton(DOWNLOAD_LABELS), 25000);
  }
  if (!btn) btn = findButton(["PREVIEW"]);
  if (!btn) return finish(task, "failed", "Download (PDF) button not found");

  await send({ type: "expectDownload", key: task.key });
  btn.click();
  const got = await waitForFiles(task.key);
  return finish(task, got ? "downloaded" : "failed", got ? "" : "Clicked download but no file arrived");
}

// ----- GSTR-3B -----
// The real GSTR-3B tile can (a) show its status line a moment after the tile itself appears,
// (b) sit next to notices that also mention GSTR-3B, and (c) offer "DOWNLOAD", "DOWNLOAD FILED
// GSTR-3B" or only "VIEW". So: anchor on the tile's own heading, let the status settle, never
// skip unless the portal clearly says "not filed", and try every route to the filed PDF.

// ---- locate the GSTR-3B tile by its own "VIEW GSTR3B" button (structure-independent) ----
const dashes = s => String(s || "").replace(/[\u2010-\u2015\u2212\u00ad]/g, "-");
const RE_3B = /gstr\s*-?\s*3\s*b(?![0-9a-z])/i;
const clickables = () => [...document.querySelectorAll("button, a, input[type=button], input[type=submit], [role=button]")]
  .filter(e => isVisible(e));
const btnText = e => norm(dashes(e.innerText || e.value || e.getAttribute("aria-label") || ""));
const rectOf = e => e.getBoundingClientRect();

/** Returns { view, filedBtn, download, status, statusText } for the GSTR-3B tile, or null. */
function find3b() {
  const all = clickables();
  // 1) the tile's own buttons
  let view = all.find(e => /^view\s*gstr\s*-?\s*3\s*b$/.test(btnText(e))) ||
             all.find(e => /\bview\b/.test(btnText(e)) && RE_3B.test(btnText(e)) && !/system|generated/.test(btnText(e)));
  const filedBtn = all.find(e => /download filed|filed gstr\s*-?\s*3\s*b/.test(btnText(e)) && !/system|generated/.test(btnText(e)));
  // 2) no named button: the "GSTR-3B" heading, then the nearest VIEW button below it in the same column
  if (!view && !filedBtn) {
    const head = [...document.querySelectorAll("body *")]
      .filter(el => isVisible(el) && !el.closest("button, a, select, option") && el.children.length < 4)
      .filter(el => { const t = dashes(el.innerText || ""); return RE_3B.test(t) && t.trim().length < 40; })
      .sort((x, y) => (x.innerText || "").length - (y.innerText || "").length)[0];
    if (head) {
      const h = rectOf(head);
      const cx = (h.left + h.right) / 2;
      view = all.filter(e => /^view$/.test(btnText(e)))
        .map(e => ({ e, r: rectOf(e) }))
        .filter(({ r }) => r.top >= h.bottom - 5 && r.top - h.bottom < 400 && r.left < cx + 260 && r.right > cx - 260)
        .sort((p, q) => (p.r.top - h.bottom) - (q.r.top - h.bottom))[0]?.e || null;
    }
  }
  const anchor = view || filedBtn;
  if (!anchor) return null;
  const a = rectOf(anchor);
  // the tile's plain DOWNLOAD sits on the same row as VIEW
  const download = all.find(e => e !== anchor && /^download$/.test(btnText(e)) &&
    Math.abs(rectOf(e).top - a.top) < 25 && Math.abs(rectOf(e).left - a.right) < 400);
  // "Status- Filed": the nearest status line above the button, in the same column
  const statusEl = [...document.querySelectorAll("body *")]
    .filter(el => isVisible(el) && el.children.length < 6 && /^\s*status\s*[-:]/i.test(el.innerText || "") && (el.innerText || "").length < 60)
    .map(el => ({ el, r: rectOf(el) }))
    .filter(({ r }) => r.bottom <= a.top + 5 && a.top - r.bottom < 160 && r.left < a.right + 200 && r.right > a.left - 200)
    .map(o => ({ ...o, hasValue: /status\s*[-:]\s*\S/i.test(o.el.innerText || "") }))
    .sort((p, q) => (q.hasValue - p.hasValue) || ((a.top - p.r.bottom) - (a.top - q.r.bottom)))[0]?.el;
  const statusText = statusEl ? (statusEl.innerText || "").replace(/\s+/g, " ").trim() : "";
  const st = norm(statusText).replace(/^status\s*[-:]\s*/, "");
  let status = "unknown";
  if (filedBtn) status = "filed";
  else if (/not filed|not yet filed|to be filed|ready to file|submitted|saved|draft/.test(st)) status = "notfiled";
  else if (/\bfiled\b/.test(st)) status = "filed";
  return { view, filedBtn, download, status, statusText };
}

function dashboardDiagnostics() {
  const labels = clickables().map(e => (e.innerText || e.value || "").replace(/\s+/g, " ").trim())
    .filter(t => t && t.length < 40);
  const uniq = [...new Set(labels)].slice(0, 14);
  const has3b = RE_3B.test(dashes(document.body.innerText || ""));
  return `GSTR-3B text on page: ${has3b ? "yes" : "no"}. Buttons seen: ${uniq.join(" | ")}`;
}

async function gstr3bFromTile(job, task) {
  const p = periodOf(job, task);
  // Let the tile and its status line settle (status can arrive a little after the tile)
  let t = null;
  const end = Date.now() + 20000;
  while (Date.now() < end && !stopped) {
    t = find3b();
    if (t && t.status === "filed") break;
    if (t && t.status === "notfiled") {
      await sleep(1500);
      t = find3b() || t;
      if (t.status !== "unknown") break;
    }
    await sleep(700);
  }
  if (!t) {
    const has3b = RE_3B.test(dashes(document.body.innerText || ""));
    if (!has3b) return finish(task, "skipped", "No GSTR-3B tile for this period (quarterly filer, or not applicable)");
    return finish(task, "failed", `Couldn't find the VIEW GSTR3B button. ${dashboardDiagnostics()}`);
  }
  if (t.status === "notfiled") return finish(task, "skipped", `GSTR-3B not filed — portal shows "${t.statusText}"`);

  // Route confirmed on the live portal: VIEW GSTR3B → GSTR-3B page → DOWNLOAD FILED GSTR-3B
  if (t.filedBtn && !t.view) {
    banner(`(${position(job)}) Downloading GSTR-3B for ${p.label}…`);
    await send({ type: "setStep", step: "page", attempt: (job.attempt || 0) + 1 });
    await send({ type: "expectDownload", key: task.key });
    t.filedBtn.click();
    const r = await after3bClick(task, t.filedBtn.parentElement);
    if (r === "downloaded") return finish(task, "downloaded", "");
    if (r === "page") return gstr3bPage((await send({ type: "hello" })).job, task);
    return finish(task, "failed", "Clicked DOWNLOAD FILED GSTR-3B on the dashboard but no file arrived");
  }
  banner(`(${position(job)}) Opening GSTR-3B for ${p.label} (VIEW GSTR3B)…`);
  await send({ type: "setStep", step: "page", attempt: (job.attempt || 0) + 1 });
  t.view.scrollIntoView({ block: "center" });
  await sleep(300);
  t.view.click();
  const moved = await waitFor(() => !isDashboard() || find3bPageButton(true), 30000);
  if (moved && !stopped) return gstr3bPage((await send({ type: "hello" })).job, task);
  return finish(task, "failed", `GSTR-3B page didn't open after VIEW GSTR3B (status: "${t.statusText || "not shown"}")`);
}

// After clicking a download button: file arrives, a choice dialog appears, or a 3B page opens.
async function after3bClick(task, clickedIn = null) {
  const end = Date.now() + 25000;
  const start = Date.now();
  let dialogDone = false;
  while (Date.now() < end && !stopped) {
    const { job: j } = await send({ type: "hello" });
    if ((j?.files?.[task.key] || []).length) return "downloaded";
    if (!dialogDone) {
      const dlg = [...document.querySelectorAll(".modal, [role=dialog], .modal-dialog, .popup")].find(isVisible);
      if (dlg) {
        const btns = [...dlg.querySelectorAll("button, a, input[type=button]")].filter(e => isVisible(e) && !e.disabled);
        const pick = btns.find(e => /filed|final/i.test(e.innerText || e.value || "") && !/system|generated/i.test(e.innerText || "")) ||
                     btns.find(e => /download|pdf|ok|proceed|yes/i.test(e.innerText || e.value || "") && !/system|generated|cancel|close/i.test(e.innerText || ""));
        if (pick) { pick.click(); dialogDone = true; }
      }
    }
    if (!isDashboard()) return "page";
    const pb = find3bPageButton();
    if (pb && clickedIn && !clickedIn.contains(pb) && !pb.closest(".modal, [role=dialog], .modal-dialog, .popup") &&
        Date.now() - start > 2500) return "page";
    await sleep(800);
  }
  return "none";
}

function find3bPageButton(includeDisabled = false) {
  const els = [...document.querySelectorAll("button, a, input[type=button]")]
    .filter(e => isVisible(e) && (includeDisabled || !e.disabled));
  const t = e => norm(e.innerText || e.value || "");
  return els.find(e => /download filed gstr-?\s*3b|download filed return|download filed/.test(t(e)) && !/system|generated/.test(t(e))) ||
         els.find(e => /download (gstr-?\s*3b|pdf|\(pdf\))/.test(t(e)) && !/system|generated/.test(t(e))) || null;
}

// Loading indicators the portal shows while it fetches the return
const SPINNER_SEL = '.loader, .loading, .spinner, .fa-spinner, .fa-spin, [class*="spinner"], [class*="loader"], .dimmer, .blockUI, .overlay';
const busy = () => [...document.querySelectorAll(SPINNER_SEL)]
  .some(el => isVisible(el) && el.getBoundingClientRect().width > 4 && el.getBoundingClientRect().height > 4);

// Wait until no spinner is showing and the button has stayed enabled for a moment
async function waitPageSettled(timeout = 25000) {
  const end = Date.now() + timeout;
  let quietSince = 0;
  while (Date.now() < end && !stopped) {
    const ok = !busy() && find3bPageButton(false);
    if (ok) { if (!quietSince) quietSince = Date.now(); if (Date.now() - quietSince > 2000) return true; }
    else quietSince = 0;
    await sleep(400);
  }
  return false;
}

// Messages the portal shows in pop-ups / alerts (to explain a failure)
const MSG_SEL = '.modal, [role=dialog], .modal-dialog, [role=alert], .alert-danger, .alert-warning, .toast, .err, .error, .text-danger';
const visibleMessages = () => [...document.querySelectorAll(MSG_SEL)].filter(isVisible)
  .map(el => (el.innerText || "").replace(/\s+/g, " ").trim()).filter(t => t && t.length < 400);

async function gstr3bPage(job, task) {
  const p = periodOf(job, task);
  banner(`(${position(job)}) GSTR-3B for ${p.label}: waiting for DOWNLOAD FILED GSTR-3B…`);
  if ((job.files?.[task.key] || []).length) return finish(task, "downloaded", "");
  const first = await waitFor(() => find3bPageButton(false), 45000);
  if (!first) {
    const labels = [...document.querySelectorAll("button, a.btn, input[type=button]")].filter(isVisible)
      .map(b => `${(b.innerText || b.value || "").trim()}${b.disabled ? " (disabled)" : ""}`).filter(Boolean).slice(0, 10);
    return finish(task, "failed", `"DOWNLOAD FILED GSTR-3B" not found on the GSTR-3B page. Buttons seen: ${labels.join(" | ") || "none"}`);
  }

  let portalSaid = "";
  for (let attempt = 1; attempt <= 3 && !stopped; attempt++) {
    // The button can be clickable before the portal has finished loading the return
    await waitPageSettled(attempt === 1 ? 25000 : 15000);
    const btn = find3bPageButton(false) || first;
    btn.scrollIntoView({ block: "center" });
    await sleep(800);
    banner(`(${position(job)}) Downloading filed GSTR-3B for ${p.label}${attempt > 1 ? ` (try ${attempt} of 3)` : ""}…`);
    const before = new Set(visibleMessages());
    await send({ type: "expectDownload", key: task.key });
    btn.click();

    // Wait for the PDF; answer a "which copy" question with the filed copy, dismiss an error pop-up
    const end = Date.now() + (attempt === 3 ? 75000 : 35000);
    let answered = false;
    while (Date.now() < end && !stopped) {
      const { job: j } = await send({ type: "hello" });
      if ((j?.files?.[task.key] || []).length) {
        return finish(task, "downloaded", attempt > 1 ? `Downloaded on try ${attempt}` : "");
      }
      const fresh = visibleMessages().filter(t => !before.has(t) && !/important message/i.test(t));
      if (fresh.length) portalSaid = fresh[0].slice(0, 160);
      if (!answered) {
        const dlg = [...document.querySelectorAll(".modal, [role=dialog], .modal-dialog")].find(isVisible);
        const btns = dlg ? [...dlg.querySelectorAll("button, a, input[type=button]")].filter(e => isVisible(e) && !e.disabled) : [];
        const pick = btns.find(e => /filed|download|proceed|yes/i.test(e.innerText || e.value || "") && !/system|generated|cancel|close|no\b/i.test(e.innerText || "")) ||
                     btns.find(e => /^\s*(ok|close)\s*$/i.test(e.innerText || e.value || ""));
        if (pick) { pick.click(); answered = true; }
      }
      await sleep(1000);
    }
  }
  return finish(task, "failed", "Clicked DOWNLOAD FILED GSTR-3B 3 times but no file arrived" +
    (portalSaid ? ` — portal said: "${portalSaid}"` : " — the portal may be slow; use Retry failed"));
}

// ----- GSTR-2A: tile DOWNLOAD → "Generate Excel file to download" → later, the file link(s) -----
const LINK_2A_RE = /click here to download|download\s*-?\s*file\s*\d|^\s*file\s*-?\s*\d+\s*$/i;
const NO_DATA_2A_RE = /no (record|data|invoice|document)s? (is |are )?(found|available)|nothing to download|no data to (download|generate)/i;

function find2aLinks() {
  return [...document.querySelectorAll("a, button")]
    .filter(e => isVisible(e) && !e.disabled)
    .filter(e => LINK_2A_RE.test((e.innerText || e.textContent || "").trim()))
    .filter(e => !/generate/i.test(e.innerText || ""));
}

async function gstr2aFromTile(job, task, tile) {
  const dl = findButton(["DOWNLOAD"], tile);
  if (!dl) return finish(task, "failed", "DOWNLOAD button not found on the GSTR-2A tile");
  await send({ type: "setStep", step: "page", attempt: (job.attempt || 0) + 1 });
  dl.click();
  const moved = await waitFor(() => !isDashboard() || findButton(GENERATE_2A_LABELS) || find2aLinks().length, 20000);
  if (moved && !stopped) return gstr2aPage((await send({ type: "hello" })).job, task);
  return finish(task, "failed", "GSTR-2A download page didn't open");
}

async function gstr2aPage(job, task) {
  const p = periodOf(job, task);
  const prev = job.results?.[task.key];
  banner(`(${position(job)}) GSTR-2A for ${p.label}: checking for the file…`);
  const ready = await waitFor(() => find2aLinks().length || findButton(GENERATE_2A_LABELS), 25000);
  if (!ready) return finish(task, "failed", "GSTR-2A download page didn't load");

  // 1) Links already there (generated earlier) → download every part
  const links = find2aLinks();
  if (links.length) return download2aLinks(job, task, links);

  // 2) Already requested in this run (also after the portal reloads the page) → still being generated
  if (prev?.status === "waiting") {
    if (NO_DATA_2A_RE.test(document.body.innerText || "")) return finish(task, "skipped", "No GSTR-2A data for this period");
    return finish(task, "waiting", "Still being generated on the portal");
  }

  // 3) Ask the portal to generate the Excel file (recorded first, in case the click reloads the page)
  const gen = findButton(GENERATE_2A_LABELS);
  if (!gen) return finish(task, "failed", "\"Generate Excel file to download\" button not found");
  banner(`(${position(job)}) GSTR-2A for ${p.label}: asking the portal to generate the Excel file…`);
  await send({ type: "markRequested", key: task.key });
  gen.click();
  await sleep(3000);
  // A confirmation box may appear — accept only the portal's own OK/Proceed inside a dialog
  const dlg = [...document.querySelectorAll(".modal, [role=dialog], .modal-dialog")].find(isVisible);
  if (dlg) { const ok = findButton(["OK", "PROCEED", "YES"], dlg); if (ok) { ok.click(); await sleep(2500); } }

  if (NO_DATA_2A_RE.test(document.body.innerText || "")) return finish(task, "skipped", "No GSTR-2A data for this period");
  const after = find2aLinks();
  if (after.length) return download2aLinks(job, task, after);
  return finish(task, "waiting", "File requested — the portal is generating it");
}

async function download2aLinks(job, task, links) {
  const p = periodOf(job, task);
  banner(`(${position(job)}) Downloading GSTR-2A for ${p.label} (${links.length} file${links.length > 1 ? "s" : ""})…`);
  await send({ type: "expectDownload", key: task.key, multi: true });
  const already = (job.files?.[task.key] || []).length;
  let got = 0;
  for (let i = 0; i < links.length && !stopped; i++) {
    links[i].click();
    if (await waitForFiles(task.key, already + i + 1, 90000)) got++;
    await sleep(1500);
  }
  await send({ type: "endExpect" });
  if (got === links.length) return finish(task, "downloaded", links.length > 1 ? `${got} files` : "");
  if (got) return finish(task, "downloaded", `Only ${got} of ${links.length} files arrived`);
  return finish(task, "failed", "Clicked the download link but no file arrived");
}

// ----- GSTR-2B: tile DOWNLOAD → "Generate Excel file to download" (or VIEW → "Download GSTR-2B details (Excel)") -----
// GSTR-2B is computed by the portal ahead of time, so the Excel usually downloads straight away.
// For very large months the portal may instead prepare it in the background and show
// "Click here to download – File N" links later; that case reuses the GSTR-2A re-check pass.
const NOT_READY_2B_RE = /gstr\s*-?\s*2\s*b\s*(is|has)?\s*(not|yet to be|been not)\s*(yet\s*)?(been\s*)?generated|not been generated|no (record|data|invoice|document)s? (is |are )?(found|available)|is not available for the (selected|said)|will be generated on|nothing to download/i;
const BEING_PREPARED_RE = /being (prepared|generated|processed)|request (has been|is) (accepted|received|submitted|placed)|available (for download )?(shortly|in some time|after)|will be available|try (again )?after some time/i;

// How often a message pattern occurs in the page text (to spot a message that appeared after a click,
// even when the page's own help text already uses similar words)
const countOf = (re, text) => (String(text || "").match(new RegExp(re.source, "gi")) || []).length;

function buttonsSeen(limit = 12) {
  const labels = clickables().map(e => `${(e.innerText || e.value || "").replace(/\s+/g, " ").trim()}${e.disabled ? " (disabled)" : ""}`)
    .filter(t => t && t.length < 60);
  return [...new Set(labels)].slice(0, limit).join(" | ") || "none";
}

async function gstr2bFromTile(job, task, tile) {
  // Prefer the tile's DOWNLOAD (goes to the Excel/JSON page); fall back to VIEW (summary page with an Excel button)
  const btn = findButton(["DOWNLOAD"], tile) || findButton(["VIEW"], tile);
  if (!btn) return finish(task, "failed", "Neither DOWNLOAD nor VIEW was found on the GSTR-2B tile");
  await send({ type: "setStep", step: "page", attempt: (job.attempt || 0) + 1 });
  btn.click();
  const moved = await waitFor(() => !isDashboard() || findButton(EXCEL_2B_LABELS) || find2aLinks().length ||
                                    NOT_READY_2B_RE.test(document.body.innerText || ""), 25000);
  if (moved && !stopped) return gstr2bPage((await send({ type: "hello" })).job, task);
  return finish(task, "failed", `GSTR-2B page didn't open after clicking ${norm(btn.innerText).toUpperCase()}`);
}

async function gstr2bPage(job, task) {
  const p = periodOf(job, task);
  const prev = job.results?.[task.key];
  banner(`(${position(job)}) GSTR-2B for ${p.label}: looking for the Excel download…`);
  if ((job.files?.[task.key] || []).length && prev?.status !== "waiting") return finish(task, "downloaded", "");

  const ready = await waitFor(() => find2aLinks().length || findButton(EXCEL_2B_LABELS) ||
                                    NOT_READY_2B_RE.test(document.body.innerText || ""), 45000);
  // Let a late "not generated" notice or the portal's loader settle
  await sleep(1200);
  const pageText = () => document.body.innerText || "";
  if (!ready) return finish(task, "failed", `GSTR-2B Excel button not found. Buttons seen: ${buttonsSeen()}`);

  // 1) Files prepared earlier → download every part
  const links = find2aLinks();
  if (links.length) return download2aLinks(job, task, links);

  const btn = findButton(EXCEL_2B_LABELS);
  if (!btn) {
    const m = (pageText().match(NOT_READY_2B_RE) || [""])[0];
    return finish(task, "skipped", `GSTR-2B not available for this period${m ? ` — portal says "${m}"` : ""}`);
  }

  // 2) Click the Excel button ONCE and wait for the portal to build the file. For big months this takes
  //    minutes (the page may even freeze while it works); clicking again would restart the job, so we
  //    never re-click while a generation may still be running — also not after a page reload.
  const eachMin = job.wait2bEachMin || 10;
  const running = prev?.status === "generating" && Date.now() - (prev.startedAt || 0) < eachMin * 60000;
  const beforeText = pageText();
  const before = new Set(visibleMessages());
  const already = (job.files?.[task.key] || []).length;
  await send({ type: "expectDownload", key: task.key, ttl: (eachMin + 5) * 60000 });
  let startedAt = running ? prev.startedAt : Date.now();
  if (!running) {
    await send({ type: "markGenerating", key: task.key, startedAt });
    (findButton(EXCEL_2B_LABELS) || btn).click();
    await sleep(2500);
    // A confirmation box may appear — accept only the portal's own OK/Proceed/Yes inside a dialog
    const dlg = [...document.querySelectorAll(".modal, [role=dialog], .modal-dialog")].find(isVisible);
    if (dlg) { const ok = findButton(["OK", "PROCEED", "YES"], dlg); if (ok) { ok.click(); await sleep(2000); } }
  }
  let deadline = startedAt + eachMin * 60000, extended = false;
  const took = () => { const s = Math.round((Date.now() - startedAt) / 1000); return s >= 60 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${s} s`; };
  const gotFile = async () => ((await send({ type: "hello" })).job?.files?.[task.key] || []).length > already;
  while (!stopped) {
    if (await gotFile()) return finish(task, "downloaded", Date.now() - startedAt > 60000 ? `Portal took ${took()} to build the Excel` : "");
    const later = find2aLinks();
    if (later.length) { await send({ type: "endExpect" }); return download2aLinks((await send({ type: "hello" })).job, task, later); }
    const t = pageText();
    // Only react to messages that appeared after the click (the page has static help text too)
    if (countOf(BEING_PREPARED_RE, t) > countOf(BEING_PREPARED_RE, beforeText)) {
      await send({ type: "markRequested", key: task.key });
      return finish(task, "waiting", "The portal is preparing the GSTR-2B Excel file");
    }
    if (countOf(NOT_READY_2B_RE, t) > countOf(NOT_READY_2B_RE, beforeText)) {
      return finish(task, "skipped", `GSTR-2B not available — portal says "${(t.match(NOT_READY_2B_RE) || [""])[0]}"`);
    }
    if (Date.now() >= deadline) {
      // Still showing the portal's loader? It is working — leaving the page would throw that work away, so allow one more period
      if (!extended && busy()) { extended = true; deadline = Date.now() + eachMin * 60000; continue; }
      break;
    }
    const left = Math.max(0, Math.round((deadline - Date.now()) / 60000));
    banner(`(${position(job)}) GSTR-2B for ${p.label}: the portal is building the Excel — ${took()} so far. ` +
           `Large months can take several minutes; waiting up to ${left} more min. Please keep this tab open and don't click.`, "warn");
    await sleep(1500);
  }
  if (await gotFile()) return finish(task, "downloaded", `Portal took ${took()} to build the Excel`);   // arrived while the page was busy
  const said = visibleMessages().filter(t => !before.has(t) && !/important message/i.test(t))[0];
  if (said) return finish(task, "failed", `Clicked GENERATE EXCEL FILE TO DOWNLOAD but no file arrived — portal said: "${said.slice(0, 160)}"`);
  // Not ready yet: come back in the re-check round (a file that arrives meanwhile is still saved under this month)
  await send({ type: "markRequested", key: task.key });
  return finish(task, "waiting", `No file after ${took()} — will try again in the re-check round. If this repeats, choose a longer GSTR-2B time in the popup`);
}

// ---------- waiting between GSTR-2A / GSTR-2B re-checks ----------
async function waitForRecheck(job) {
  const n = job.recheckQueue.length;
  while (!stopped) {
    const left = job.nextCheckAt - Date.now();
    if (left <= 0) return true;
    const mm = Math.floor(left / 60000), ss = Math.floor((left % 60000) / 1000);
    banner(`Waiting for the portal to prepare ${n} GSTR-2A/2B file${n > 1 ? "s" : ""} — next check in ${mm}:${String(ss).padStart(2, "0")}. Keep this tab open.`, "warn");
    await sleep(1000);
  }
  return false;
}

// ---------- main ----------
async function main() {
  const res = await send({ type: "hello" }).catch(() => null);
  if (!res || !res.job || !res.isJobTab) return;
  isJobTab = true;
  const job = res.job;

  if ((job.phase === "running" || job.phase === "login") && Date.now() - (job.startedAt || 0) > 8 * 3600 * 1000) {
    await send({ type: "stop" });
    return;
  }

  if (job.phase === "stopped" || job.phase === "done") {
    if (await maybeLogout(job)) return;
    if (job.phase === "done" || job.logout === "done") {
      banner(`${summaryText(job)}${job.logout === "done" ? " Logged out of the GST portal." : ""} Open the extension for the full list.`, "ok");
    }
    return;
  }

  if (isLoginPage()) {
    if (job.phase === "running") await send({ type: "needLogin" }); // session expired mid-run
    return doLogin();
  }

  if (job.phase === "login") {
    if (/\/auth\//i.test(location.pathname)) {
      await send({ type: "loggedIn" });
      banner("Logged in. Opening Returns Dashboard…");
      go(DASHBOARD_URL);
    }
    return;
  }

  // Portal session ended ("Access Denied" / logged out) while running. Don't open the login page ourselves:
  // that would also end a session the user may have in another tab. Ask the user instead.
  if (location.host === "services.gst.gov.in" && /accessdenied|\/services\/logout/i.test(location.pathname)) {
    await send({ type: "needLogin" });
    banner("Your GST session has ended. Click 'here' on this page to log in again — the run continues after login. (Or click Stop.)", "warn");
    return;
  }

  // phase === "running"
  const task = res.task;
  if (!task) return;

  if (job.step === "page" && !isDashboard()) {
    if (task.type === "GSTR1") return gstr1Page(job, task);
    if (task.type === "GSTR3B") return gstr3bPage(job, task);
    if (task.type === "GSTR2B") return gstr2bPage(job, task);
    return gstr2aPage(job, task);
  }
  if (!isDashboard()) return go(DASHBOARD_URL);

  if (job.step === "page" && (job.attempt || 0) >= 2) {
    return finish(task, "failed", `Couldn't reach the ${TYPE_LABEL[task.type]} download page`);
  }
  if (job.pass === "recheck" && job.recheckQueue[0] === task.key && Date.now() < job.nextCheckAt) {
    if (!(await waitForRecheck(job))) return;
    const fresh = await send({ type: "hello" });
    if (fresh.job.phase !== "running" || !fresh.task) return main();
    return dashboardStage(fresh.job, fresh.task);
  }
  return dashboardStage(job, task);
}

main();
