DEMO DATA — entirely made up, for trying the tool and recording the capstone video without client data.
Client: "Kaveri Foods Private Limited" (fictional). GSTINs are generated with valid check digits from invented PANs.

1) Q1_quick_demo  — 3 months of GSTR-2B + a purchase register with planted differences (steps 1, 4, 5).
   45 exact, 1 invoice no. written differently (still Matched), 3 Likely (date / number / both differ),
   amount and tax differences, 1 wrong GSTIN, 3 not in 2B, 3 not in books, 1 row without GSTIN.

2) Full_year_FY2024-25 — for the returns reconciliation (steps 2–3) and the GSTR-9 working paper (step 6):
   GSTR-2B Apr-2024 … Nov-2025 (20 files), GSTR-3B PDFs Apr-2024 … Mar-2025 (12), GSTR-1 PDFs Apr-2024 … Mar-2025 (12), purchase register for the year
   with HSN/SAC, Description, Ledger Head, Reverse Charge, ITC Claimed in GSTR-3B (Month) and Payment Date. Planted:
   - 2 invoices of March-2024 (last year) claimed in April-2024 3B          → Table 6A1 (₹9,000)
   - December-2024 3B claims ₹10,000 more than the books                    → "Books vs 3B monthly" sheet
   - 3 March-2025 invoices reported by suppliers in April-2025 2B          → Table 8C
   - 1 February-2025 invoice reported in November-2025 2B, claimed Dec-2025 → Section 16(4) flag
   - 2 invoices in 2B but not in books                                     → 8E
   - 12 canteen bills (Staff welfare — canteen)                            → blocked u/s 17(5), 8F
   - 2 invoices paid after 180 days, 2 unpaid                              → Rule 37 flags (set "as on" to 30-11-2025)
   - Machine purchases split over Plant & Machinery + freight lines        → capital goods in 6B
   - GTA freight under reverse charge; August-2024 RCM ITC not taken in 3B → RCM check
   - Advocate's fees under RCM without GSTIN                               → suggested 6C
   - 1 import (IMPG, Sept-2024)                                            → 8G / 6E
   - 1 invoice with "ITC Availability: No" in 2B, 2 invoices missing from 2B
   - October-2024: GSTR-1 shows ₹1,00,000 more sales (₹5,000 tax) than 3B   → "3B lower than GSTR-1" (steps 2–3)

   For steps 2–3 (returns reconciliation and combined GSTR-2B for the year), drop only the GSTR-1, GSTR-3B and the
   April-2024 … March-2025 GSTR-2B files. The April … November-2025 GSTR-2B files are for GSTR-9 (8A / 8C) in step 6.
   Results of steps 2–3 on this data are in sample-outputs of the GitHub folder.

Steps: open GST_Reconciliation.html → drop all files of a folder in step 1 → choose the purchase register in step 4 →
Reconcile → step 5 vendor e-mails → step 6 GSTR-9 working paper.
