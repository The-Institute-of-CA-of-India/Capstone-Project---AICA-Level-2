-- DEMO ONLY: BG Tracker training app. No login; permissive policies allow anonymous read/write.
-- Never use these policies in production.

CREATE TABLE public.bank_guarantees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bg_number text NOT NULL UNIQUE,
  bg_type text NOT NULL,
  bank_name text NOT NULL,
  branch text,
  applicant_name text NOT NULL,
  beneficiary_name text NOT NULL,
  contract_ref text,
  amount numeric NOT NULL DEFAULT 0,
  margin_percent numeric NOT NULL DEFAULT 0,
  margin_type text NOT NULL DEFAULT 'FDR lien',
  fdr_number text,
  commission_rate_percent numeric NOT NULL DEFAULT 1,
  next_commission_due date,
  issue_date date NOT NULL,
  expiry_date date NOT NULL,
  claim_expiry_date date NOT NULL,
  original_returned boolean NOT NULL DEFAULT false,
  release_letter_received boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'Active',
  applicant_email text,
  beneficiary_email text,
  bank_email text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.bg_amendments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bg_id uuid NOT NULL REFERENCES public.bank_guarantees(id) ON DELETE CASCADE,
  amended_on date NOT NULL DEFAULT current_date,
  old_expiry date, new_expiry date, old_amount numeric, new_amount numeric, remarks text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bg_id uuid NOT NULL REFERENCES public.bank_guarantees(id) ON DELETE CASCADE,
  reminder_type text NOT NULL,
  recipient_role text NOT NULL,
  recipient_email text,
  subject text NOT NULL,
  body text NOT NULL,
  due_date date NOT NULL DEFAULT current_date,
  status text NOT NULL DEFAULT 'Draft/Pending Approval',
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz
);
CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bg_id uuid REFERENCES public.bank_guarantees(id) ON DELETE CASCADE,
  action text NOT NULL,
  details text,
  performed_by text NOT NULL DEFAULT 'Demo User',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.bank_guarantees, public.bg_amendments, public.reminders, public.audit_log TO anon, authenticated;
GRANT ALL ON public.bank_guarantees, public.bg_amendments, public.reminders, public.audit_log TO service_role;

ALTER TABLE public.bank_guarantees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bg_amendments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- DEMO ONLY permissive policies
CREATE POLICY "demo all bg" ON public.bank_guarantees FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "demo all amend" ON public.bg_amendments FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "demo all rem" ON public.reminders FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "demo all audit" ON public.audit_log FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- Demo seed: wipes everything and re-inserts fictional data with dates relative to today.
CREATE OR REPLACE FUNCTION public.reset_demo_data()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE d date := current_date;
BEGIN
  DELETE FROM public.audit_log WHERE true;
  DELETE FROM public.reminders WHERE true;
  DELETE FROM public.bg_amendments WHERE true;
  DELETE FROM public.bank_guarantees WHERE true;

  INSERT INTO public.bank_guarantees (bg_number,bg_type,bank_name,branch,applicant_name,beneficiary_name,contract_ref,amount,margin_percent,margin_type,fdr_number,commission_rate_percent,next_commission_due,issue_date,expiry_date,claim_expiry_date,original_returned,release_letter_received,status,applicant_email,beneficiary_email,bank_email,notes,created_at)
  SELECT v.num, v.typ, b.name, v.branch, c.name, bn.name, v.cref, v.amt, v.mp, v.mt, v.fdr, v.comm,
         CASE WHEN v.ncd IS NULL THEN NULL ELSE d + v.ncd END, d + v.iss, d + v.exp, d + v.clm, v.ret, v.rel, v.st,
         c.email, bn.email, b.email, v.notes, (d + v.iss)::timestamptz
  FROM (VALUES
   ('BG/SBI/24/0011','Performance','SBI','Ahmedabad Main','C1','B1','BUMC/CIV/2023/114',85000000,25,'FDR lien','FDR-SBI-778812',1.25,6,-358,2,62,false,false,'Active','Civil works Package C-4.'),
   ('BG/HDFC/25/1042','Bid/EMD','HDFC','Mumbai Fort','C2','B4','SWB/TND/2025/88',1500000,100,'Cash margin',NULL,0.75,40,-88,5,35,false,false,'Active','EMD for pipeline tender.'),
   ('BG/ICICI/24/3307','Advance Payment','ICICI','Vadodara Alkapuri','C3','B2','WGPL/ADV/2024/19',42500000,20,'Mixed','FDR-ICI-201145',1.5,10,-360,7,97,false,false,'Active','Mobilisation advance 10%.'),
   ('BG/AXIS/23/0558','Performance','AXIS','Surat Ring Road','C4','B3','DHA/PKG-7/2024',120000000,10,'FDR lien','FDR-AXS-55120',1.1,12,-720,12,192,false,false,'Active','Highway package 7, 5% PBG.'),
   ('BG/KOTAK/24/0217','Retention Money','KOTAK','Pune Camp','C5','B6','GSCM/RET/2023/07',7500000,50,'Cash margin',NULL,1.0,45,-540,18,78,false,false,'Active',NULL),
   ('BG/BOB/24/7781','Financial','BOB','Ahmedabad CG Road','C6','B5','NRFC/FIN/2024/42',65000000,30,'FDR lien','FDR-BOB-990013',1.75,3,-340,24,84,false,false,'Active',NULL),
   ('BG/PNB/24/4410','Performance','PNB','Rajkot Main','C1','B6','GSCM/ICT/2024/21',23000000,15,'Mixed','FDR-PNB-41207',1.25,60,-330,29,89,false,false,'Active',NULL),
   ('BG/CAN/25/0093','Bid/EMD','CAN','Bengaluru MG Road','C3','B5','NRFC/TND/2025/310',500000,100,'Cash margin',NULL,0.75,70,-150,35,65,false,false,'Active',NULL),
   ('BG/SBI/24/0187','Advance Payment','SBI','Gandhinagar Sector 10','C2','B3','DHA/ADV/2025/03',98000000,25,'FDR lien','FDR-SBI-801233',2.0,14,-320,42,132,false,false,'Active',NULL),
   ('BG/HDFC/24/0990','Performance','HDFC','Ahmedabad Navrangpura','C5','B4','SWB/PIPE/2024/16',34000000,10,'FDR lien','FDR-HDF-66218',1.0,90,-400,50,140,false,false,'Active',NULL),
   ('BG/ICICI/22/1188','Retention Money','ICICI','Mumbai BKC','C6','B1','BUMC/RET/2022/51',18500000,40,'Mixed','FDR-ICI-209981',1.25,22,-900,58,118,false,false,'Active',NULL),
   ('BG/AXIS/24/0662','Performance','AXIS','Vadodara Race Course','C4','B2','WGPL/SUB/2024/77',56000000,15,'FDR lien','FDR-AXS-55788',1.5,8,-300,65,155,false,false,'Active',NULL),
   ('BG/KOTAK/25/0031','Financial','KOTAK','Mumbai Nariman Point','C3','B6','GSCM/FIN/2025/11',27500000,5,'FDR lien','FDR-KOT-12091',2.0,33,-290,78,138,false,false,'Active',NULL),
   ('BG/BOB/25/0412','Bid/EMD','BOB','Surat Athwa','C1','B5','NRFC/TND/2025/402',2500000,100,'Cash margin',NULL,0.75,85,-95,88,118,false,false,'Active',NULL),
   ('BG/PNB/22/0905','Performance','PNB','Ahmedabad Ashram Road','C2','B1','BUMC/EM/2022/09',47500000,20,'FDR lien','FDR-PNB-40011',1.25,20,-1100,-5,25,false,false,'Active','Project completed; awaiting original.'),
   ('BG/CAN/23/0318','Advance Payment','CAN','Pune Shivajinagar','C5','B3','DHA/ADV/2023/18',31000000,25,'Mixed','FDR-CAN-77341',1.5,15,-735,-12,10,false,false,'Active','Advance fully recovered.'),
   ('BG/SBI/23/0222','Retention Money','SBI','Rajkot Kalawad Road','C4','B4','SWB/RET/2023/02',9500000,50,'Cash margin',NULL,1.0,50,-760,-25,35,false,false,'Active',NULL),
   ('BG/HDFC/22/0333','Performance','HDFC','Vadodara Akota','C6','B2','WGPL/CIV/2022/33',72500000,15,'FDR lien','FDR-HDF-66001',1.75,5,-1135,-40,50,false,false,'Active',NULL),
   ('BG/ICICI/21/0703','Performance','ICICI','Surat Ghod Dod Road','C1','B3','DHA/PKG-3/2021',52000000,20,'FDR lien','FDR-ICI-198822',1.25,18,-1215,-120,-30,false,false,'Active','CRITICAL: claim period over, original still with beneficiary.'),
   ('BG/AXIS/23/0105','Performance','AXIS','Ahmedabad SG Highway','C3','B2','WGPL/TRF/2023/05',110000000,15,'FDR lien','FDR-AXS-54001',1.5,11,-800,140,230,false,false,'Extended','Extended twice due to project delay.'),
   ('BG/SBI/23/0927','Advance Payment','SBI','Mumbai Main','C6','B5','NRFC/ADV/2023/27',64000000,20,'Mixed','FDR-SBI-779945',1.25,26,-700,200,290,false,false,'Extended',NULL),
   ('BG/BOB/23/1414','Performance','BOB','Vadodara Main','C2','B6','GSCM/ROAD/2023/14',15500000,100,'Cash margin',NULL,1.0,NULL,-500,40,100,false,false,'Invoked','Invoked by beneficiary citing delay; dispute under review.'),
   ('BG/KOTAK/24/0061','Bid/EMD','KOTAK','Ahmedabad Prahladnagar','C5','B4','SWB/TND/2024/61',1000000,100,'Cash margin',NULL,0.75,NULL,-400,-60,-30,true,true,'Discharged',NULL),
   ('BG/PNB/21/1212','Performance','PNB','Mumbai Andheri','C4','B1','BUMC/ARCH/2021/12',38000000,20,'FDR lien','FDR-PNB-38870',1.25,NULL,-1300,-200,-110,true,true,'Discharged',NULL),
   ('BG/CAN/23/0404','Financial','CAN','Surat Adajan','C6','B6','GSCM/FIN/2023/04',22000000,30,'Mixed','FDR-CAN-75520',1.5,NULL,-900,-150,-90,true,true,'Discharged',NULL),
   ('BG/HDFC/23/0909','Retention Money','HDFC','Pune Baner','C3','B3','DHA/RET/2023/09',12500000,50,'FDR lien','FDR-HDF-65410',1.0,9,-750,-15,45,true,true,'Release Requested',NULL),
   ('BG/SBI/22/1818','Performance','SBI','Vadodara Sayajigunj','C1','B4','SWB/STP/2022/18',28500000,25,'FDR lien','FDR-SBI-776510',1.5,28,-1110,-30,60,true,true,'Release Requested',NULL)
  ) AS v(num,typ,bk,branch,cc,bc,cref,amt,mp,mt,fdr,comm,ncd,iss,exp,clm,ret,rel,st,notes)
  JOIN (VALUES
   ('SBI','State Bank of India','bg.desk@sbi.example.com'),('HDFC','HDFC Bank','tradeops@hdfc.example.com'),
   ('ICICI','ICICI Bank','guarantees@icici.example.com'),('AXIS','Axis Bank','bgcell@axis.example.com'),
   ('KOTAK','Kotak Mahindra Bank','trade@kotak.example.com'),('BOB','Bank of Baroda','bg.ops@bob.example.com'),
   ('PNB','Punjab National Bank','bgdept@pnb.example.com'),('CAN','Canara Bank','guarantee@canara.example.com')
  ) AS b(code,name,email) ON b.code = v.bk
  JOIN (VALUES
   ('C1','Sejpal Infra Projects Pvt Ltd','accounts@sejpalinfra.example.com'),
   ('C2','Navkar Engineering Works','finance@navkareng.example.com'),
   ('C3','Orbit Power Systems Ltd','treasury@orbitpower.example.com'),
   ('C4','Meghdoot Constructions LLP','accounts@meghdoot.example.com'),
   ('C5','Shivalik Pharma Equipments Pvt Ltd','finance@shivalikpharma.example.com'),
   ('C6','Tapi Riverfront Developers Ltd','cfo@tapiriverfront.example.com')
  ) AS c(code,name,email) ON c.code = v.cc
  JOIN (VALUES
   ('B1','Bharat Urban Metro Corp (fictional)','contracts@bumc.example.com'),
   ('B2','Western Grid Power Ltd (fictional)','procurement@westerngrid.example.com'),
   ('B3','Deccan Highways Authority (fictional)','ee.contracts@deccanhighways.example.com'),
   ('B4','Sabarmati Water Board (fictional)','tenders@sabarmatiwater.example.com'),
   ('B5','National Rail Freight Corp (fictional)','finance@nrfc.example.com'),
   ('B6','Gujarat Smart City Mission (fictional)','procurement@gscm.example.com')
  ) AS bn(code,name,email) ON bn.code = v.bc;

  INSERT INTO public.bg_amendments (bg_id,amended_on,old_expiry,new_expiry,old_amount,new_amount,remarks)
  SELECT g.id, d + a.on_, d + a.oe, d + a.ne, a.oa, a.na, a.rm
  FROM (VALUES
   ('BG/AXIS/23/0105',-400,-395,-30,100000000,100000000,'Extension sought by beneficiary due to land acquisition delay.'),
   ('BG/AXIS/23/0105',-60,-30,60,100000000,100000000,'Second extension - revised completion schedule.'),
   ('BG/AXIS/23/0105',-20,60,140,100000000,110000000,'Extended with enhancement for variation order VO-3.'),
   ('BG/SBI/23/0927',-300,-330,-30,58000000,58000000,'Extension per contract clause 14.2.'),
   ('BG/SBI/23/0927',-40,-30,200,58000000,64000000,'Extended and enhanced for additional advance tranche.')
  ) AS a(num,on_,oe,ne,oa,na,rm) JOIN public.bank_guarantees g ON g.bg_number = a.num;

  INSERT INTO public.audit_log (bg_id,action,details,performed_by,created_at)
  SELECT id,'BG created','BG '||bg_number||' recorded for '||applicant_name,'Demo User',created_at FROM public.bank_guarantees;
  INSERT INTO public.audit_log (bg_id,action,details,performed_by,created_at)
  SELECT g.id,'Extension recorded','Expiry extended from '||to_char(a.old_expiry,'DD Mon YYYY')||' to '||to_char(a.new_expiry,'DD Mon YYYY'),'Demo User',a.amended_on::timestamptz
  FROM public.bg_amendments a JOIN public.bank_guarantees g ON g.id=a.bg_id;
  INSERT INTO public.audit_log (bg_id,action,details,performed_by,created_at)
  SELECT id, CASE status WHEN 'Discharged' THEN 'Marked discharged' WHEN 'Invoked' THEN 'BG invoked' ELSE 'Release requested' END,
         'Status changed to '||status,'Demo User', (expiry_date + 10)::timestamptz
  FROM public.bank_guarantees WHERE status IN ('Discharged','Invoked','Release Requested');

  INSERT INTO public.reminders (bg_id,reminder_type,recipient_role,recipient_email,subject,body,due_date,status,created_at,sent_at)
  SELECT g.id, r.typ, r.role,
    CASE r.role WHEN 'Client' THEN g.applicant_email WHEN 'Beneficiary' THEN g.beneficiary_email WHEN 'Bank' THEN g.bank_email ELSE 'bg-desk@bgtracker.example.com' END,
    r.subj || ' - ' || g.bg_number,
    'Dear Sir/Madam,'||E'\n\n'||'This is with reference to Bank Guarantee No. '||g.bg_number||' issued by '||g.bank_name||' on behalf of '||g.applicant_name||' in favour of '||g.beneficiary_name||'. '||r.line||E'\n\n'||'Thanking you,'||E'\n'||'Yours faithfully,'||E'\n'||'BG Desk',
    d + r.due, r.st, (d + r.due)::timestamptz, CASE WHEN r.st='Approved & Sent' THEN (d + r.due)::timestamptz + interval '3 hours' END
  FROM (VALUES
   ('BG/SBI/23/0222','Expiry T-30','Client','Reminder: BG expiring in 30 days','The guarantee was due to expire shortly; kindly confirm whether an extension is required.',-55,'Approved & Sent'),
   ('BG/SBI/23/0222','Expiry T-30','Internal Team','Internal alert: BG expiring in 30 days','Please review renewal requirement with the client.',-55,'Approved & Sent'),
   ('BG/PNB/22/0905','Expiry T-7','Client','Reminder: BG expiring in 7 days','The guarantee expires in seven days.',-12,'Approved & Sent'),
   ('BG/AXIS/23/0558','Expiry T-15','Client','Reminder: BG expiring in 15 days','The guarantee expires in fifteen days. Kindly advise on extension or release.',-3,'Approved & Sent'),
   ('BG/HDFC/22/0333','Beneficiary release request','Beneficiary','Request for return of original BG','We request you to kindly return the original guarantee or issue a release letter.',-20,'Dismissed'),
   ('BG/HDFC/23/0909','Bank cancellation request','Bank','Request for cancellation of BG and release of margin','The beneficiary has issued its release letter. We request cancellation and release of the FDR lien.',-5,'Approved & Sent')
  ) AS r(num,typ,role,subj,line,due,st) JOIN public.bank_guarantees g ON g.bg_number = r.num;

  INSERT INTO public.audit_log (bg_id,action,details,performed_by,created_at)
  SELECT bg_id,'Reminder sent (simulated)',subject||' to '||recipient_role,'Demo User',sent_at FROM public.reminders WHERE sent_at IS NOT NULL;
  INSERT INTO public.audit_log (bg_id,action,details,performed_by,created_at)
  VALUES (NULL,'Demo data seeded','Fictional demo dataset loaded relative to '||to_char(d,'DD Mon YYYY'),'System',now());
END $$;

GRANT EXECUTE ON FUNCTION public.reset_demo_data() TO anon, authenticated;

SELECT public.reset_demo_data();