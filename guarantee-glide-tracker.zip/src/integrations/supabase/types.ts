export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          bg_id: string | null
          created_at: string
          details: string | null
          id: string
          performed_by: string
        }
        Insert: {
          action: string
          bg_id?: string | null
          created_at?: string
          details?: string | null
          id?: string
          performed_by?: string
        }
        Update: {
          action?: string
          bg_id?: string | null
          created_at?: string
          details?: string | null
          id?: string
          performed_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_bg_id_fkey"
            columns: ["bg_id"]
            isOneToOne: false
            referencedRelation: "bank_guarantees"
            referencedColumns: ["id"]
          },
        ]
      }
      bank_guarantees: {
        Row: {
          amount: number
          applicant_email: string | null
          applicant_name: string
          bank_email: string | null
          bank_name: string
          beneficiary_email: string | null
          beneficiary_name: string
          bg_number: string
          bg_type: string
          branch: string | null
          claim_expiry_date: string
          commission_rate_percent: number
          contract_ref: string | null
          created_at: string
          expiry_date: string
          fdr_number: string | null
          id: string
          issue_date: string
          margin_percent: number
          margin_type: string
          next_commission_due: string | null
          notes: string | null
          original_returned: boolean
          release_letter_received: boolean
          status: string
        }
        Insert: {
          amount?: number
          applicant_email?: string | null
          applicant_name: string
          bank_email?: string | null
          bank_name: string
          beneficiary_email?: string | null
          beneficiary_name: string
          bg_number: string
          bg_type: string
          branch?: string | null
          claim_expiry_date: string
          commission_rate_percent?: number
          contract_ref?: string | null
          created_at?: string
          expiry_date: string
          fdr_number?: string | null
          id?: string
          issue_date: string
          margin_percent?: number
          margin_type?: string
          next_commission_due?: string | null
          notes?: string | null
          original_returned?: boolean
          release_letter_received?: boolean
          status?: string
        }
        Update: {
          amount?: number
          applicant_email?: string | null
          applicant_name?: string
          bank_email?: string | null
          bank_name?: string
          beneficiary_email?: string | null
          beneficiary_name?: string
          bg_number?: string
          bg_type?: string
          branch?: string | null
          claim_expiry_date?: string
          commission_rate_percent?: number
          contract_ref?: string | null
          created_at?: string
          expiry_date?: string
          fdr_number?: string | null
          id?: string
          issue_date?: string
          margin_percent?: number
          margin_type?: string
          next_commission_due?: string | null
          notes?: string | null
          original_returned?: boolean
          release_letter_received?: boolean
          status?: string
        }
        Relationships: []
      }
      bg_amendments: {
        Row: {
          amended_on: string
          bg_id: string
          created_at: string
          id: string
          new_amount: number | null
          new_expiry: string | null
          old_amount: number | null
          old_expiry: string | null
          remarks: string | null
        }
        Insert: {
          amended_on?: string
          bg_id: string
          created_at?: string
          id?: string
          new_amount?: number | null
          new_expiry?: string | null
          old_amount?: number | null
          old_expiry?: string | null
          remarks?: string | null
        }
        Update: {
          amended_on?: string
          bg_id?: string
          created_at?: string
          id?: string
          new_amount?: number | null
          new_expiry?: string | null
          old_amount?: number | null
          old_expiry?: string | null
          remarks?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bg_amendments_bg_id_fkey"
            columns: ["bg_id"]
            isOneToOne: false
            referencedRelation: "bank_guarantees"
            referencedColumns: ["id"]
          },
        ]
      }
      reminders: {
        Row: {
          bg_id: string
          body: string
          created_at: string
          due_date: string
          id: string
          recipient_email: string | null
          recipient_role: string
          reminder_type: string
          sent_at: string | null
          status: string
          subject: string
        }
        Insert: {
          bg_id: string
          body: string
          created_at?: string
          due_date?: string
          id?: string
          recipient_email?: string | null
          recipient_role: string
          reminder_type: string
          sent_at?: string | null
          status?: string
          subject: string
        }
        Update: {
          bg_id?: string
          body?: string
          created_at?: string
          due_date?: string
          id?: string
          recipient_email?: string | null
          recipient_role?: string
          reminder_type?: string
          sent_at?: string | null
          status?: string
          subject?: string
        }
        Relationships: [
          {
            foreignKeyName: "reminders_bg_id_fkey"
            columns: ["bg_id"]
            isOneToOne: false
            referencedRelation: "bank_guarantees"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      reset_demo_data: { Args: never; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
