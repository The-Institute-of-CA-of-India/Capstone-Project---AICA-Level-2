import { cn } from "@/lib/utils";

const MAP: Record<string, string> = {
  Active: "bg-st-green-bg text-st-green",
  "Expiring Soon": "bg-st-amber-bg text-st-amber",
  "Overdue Release": "bg-st-red-bg text-st-red",
  Expired: "bg-st-red-bg text-st-red",
  Discharged: "bg-st-grey-bg text-st-grey",
  Invoked: "bg-st-purple-bg text-st-purple",
  Extended: "bg-st-blue-bg text-st-blue",
  "Release Requested": "bg-st-teal-bg text-st-teal",
  "Draft/Pending Approval": "bg-st-amber-bg text-st-amber",
  "Approved & Sent": "bg-st-green-bg text-st-green",
  Dismissed: "bg-st-grey-bg text-st-grey",
};

export function StatusChip({ status, className }: { status: string; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium", MAP[status] ?? MAP["Discharged"], className)}>
      <span className="size-1.5 rounded-full bg-current opacity-70" />
      {status}
    </span>
  );
}

export function DaysBadge({ days }: { days: number }) {
  const tone = days < 0 ? "bg-st-red-bg text-st-red" : days <= 7 ? "bg-st-red-bg text-st-red" : days <= 30 ? "bg-st-amber-bg text-st-amber" : "bg-st-green-bg text-st-green";
  const label = days < 0 ? `${-days}d overdue` : days === 0 ? "Today" : `${days}d left`;
  return <span className={cn("tabular inline-flex rounded-md px-2 py-0.5 text-xs font-semibold", tone)}>{label}</span>;
}
