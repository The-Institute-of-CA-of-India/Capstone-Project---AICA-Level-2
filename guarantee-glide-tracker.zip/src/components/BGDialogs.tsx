import { useForm, type FieldPath, type FieldValues, type UseFormReturn } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { BANKS, BG_STATUSES, BG_TYPES, MARGIN_TYPES, type BG } from "@/lib/bg";
import { bgDefaults, bgSchema, extensionSchema, uniqueBGNumber, type BGValues, type ExtensionValues } from "@/lib/bg-validation";
import { addDays, fmtDate } from "@/lib/format";
import { logAudit, useInvalidateAll } from "@/lib/queries";

function Field<T extends FieldValues>({ form, name, label, type = "text", options }: { form: UseFormReturn<T>; name: FieldPath<T>; label: string; type?: string | undefined; options?: readonly string[] | undefined }) {
  return <FormField control={form.control} name={name} render={({ field }) => <FormItem className="min-w-0">
    <FormLabel>{label}</FormLabel>
    {options ? <Select value={field.value} onValueChange={field.onChange}><FormControl><SelectTrigger className="w-full"><SelectValue /></SelectTrigger></FormControl><SelectContent>{options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
      : type === "checkbox" ? <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
      : type === "textarea" ? <FormControl><Textarea {...field} /></FormControl>
      : <FormControl><Input {...field} type={type} step={type === "number" ? "any" : undefined} value={field.value ?? ""} onChange={(e) => field.onChange(type === "number" ? (e.target.value === "" ? undefined : Number(e.target.value)) : e.target.value)} /></FormControl>}
    <FormMessage />
  </FormItem>} />;
}

export function BGFormDialog({ bg, rows, onClose }: { bg?: BG; rows: BG[]; onClose: () => void }) {
  const form = useForm<BGValues>({ resolver: zodResolver(bgSchema), defaultValues: bgDefaults(bg) });
  const invalidate = useInvalidateAll();
  const save = async (values: BGValues) => {
    try {
      // Query again on submit: the register's cached rows may be stale.
      const { data: existing, error: readError } = await supabase.from("bank_guarantees").select("id,bg_number");
      if (readError) throw readError;
      if (!uniqueBGNumber(existing ?? rows, values.bg_number, bg?.id)) {
        form.setError("bg_number", { message: "BG number already exists" }); return;
      }
      const payload = { ...values, branch: values.branch || null, contract_ref: values.contract_ref || null, fdr_number: values.fdr_number || null, next_commission_due: values.next_commission_due || null, applicant_email: values.applicant_email || null, beneficiary_email: values.beneficiary_email || null, bank_email: values.bank_email || null, notes: values.notes || null };
      const query = bg ? supabase.from("bank_guarantees").update(payload).eq("id", bg.id) : supabase.from("bank_guarantees").insert(payload);
      const { data: saved, error } = await query.select().single();
      if (error) { if (error.code === "23505") { form.setError("bg_number", { message: "BG number already exists" }); return; } throw error; }
      const changes = bg ? Object.keys(values).filter((k) => String(bg[k as keyof BG] ?? "") !== String(values[k as keyof BGValues])).map((k) => `${k}: ${String(bg[k as keyof BG] ?? "—")} → ${String(values[k as keyof BGValues])}`).join("; ") : `BG ${saved.bg_number} recorded for ${saved.applicant_name}`;
      await logAudit(saved.id, bg ? "BG edited" : "BG created", changes || "Saved without field changes");
      await invalidate(); toast.success(bg ? "BG updated" : "BG created"); onClose();
    } catch (error) { toast.error(error instanceof Error ? error.message : String((error as { message?: string }).message ?? error)); }
  };
  const f = (name: keyof BGValues, label: string, type?: string, options?: readonly string[]) => <Field form={form} name={name} label={label} type={type} options={options} />;
  return <Dialog open onOpenChange={(open) => !open && !form.formState.isSubmitting && onClose()}><DialogContent className="max-h-[90dvh] max-w-3xl overflow-y-auto">
    <DialogHeader><DialogTitle>{bg ? "Edit BG" : "Add BG"}</DialogTitle><DialogDescription>{bg ? bg.bg_number : "New bank guarantee"}</DialogDescription></DialogHeader>
    <Form {...form}><form onSubmit={form.handleSubmit(save)} noValidate className="space-y-5">
      {bg && <dl className="grid grid-cols-1 gap-2 text-xs text-muted-foreground sm:grid-cols-2"><div><dt>Record ID</dt><dd className="break-all">{bg.id}</dd></div><div><dt>Created at</dt><dd>{bg.created_at}</dd></div></dl>}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {f("bg_number", "BG number")}{f("bg_type", "BG type", undefined, BG_TYPES)}
        {f("bank_name", "Bank", undefined, BANKS)}{f("branch", "Branch")}
        {f("applicant_name", "Applicant name")}{f("beneficiary_name", "Beneficiary name")}
        {f("contract_ref", "Contract reference")}{f("amount", "Amount (₹)", "number")}
        {f("margin_percent", "Margin (%)", "number")}{f("margin_type", "Margin type", undefined, MARGIN_TYPES)}
        {f("fdr_number", "FDR number")}{f("commission_rate_percent", "Commission rate (% p.a.)", "number")}
        {f("next_commission_due", "Next commission due", "date")}{f("status", "Status", undefined, BG_STATUSES)}
        {f("issue_date", "Issue date", "date")}{f("expiry_date", "Expiry date", "date")}{f("claim_expiry_date", "Claim expiry date", "date")}
        {f("applicant_email", "Applicant email", "email")}{f("beneficiary_email", "Beneficiary email", "email")}{f("bank_email", "Bank email", "email")}
        {f("original_returned", "Original returned", "checkbox")}{f("release_letter_received", "Release letter received", "checkbox")}
      </div>{f("notes", "Notes", "textarea")}
      <DialogFooter className="gap-2"><Button type="button" variant="outline" disabled={form.formState.isSubmitting} onClick={onClose}>Cancel</Button><Button type="submit" disabled={form.formState.isSubmitting}>{form.formState.isSubmitting ? "Saving…" : "Save BG"}</Button></DialogFooter>
    </form></Form>
  </DialogContent></Dialog>;
}

export function ExtensionDialog({ bg, onClose }: { bg: BG; onClose: () => void }) {
  const expiry = addDays(bg.expiry_date, 180);
  const form = useForm<ExtensionValues>({ resolver: zodResolver(extensionSchema(bg.expiry_date)), defaultValues: { new_expiry: expiry, claim_expiry_date: addDays(expiry, 90), new_amount: undefined, remarks: "" } });
  const invalidate = useInvalidateAll();
  const save = async (v: ExtensionValues) => {
    try {
      const amount = v.new_amount ?? bg.amount;
      const { data: amendment, error: amendmentError } = await supabase.from("bg_amendments").insert({ bg_id: bg.id, old_expiry: bg.expiry_date, new_expiry: v.new_expiry, old_amount: bg.amount, new_amount: amount, remarks: v.remarks || null }).select().single();
      if (amendmentError) throw amendmentError;
      const { error } = await supabase.from("bank_guarantees").update({ expiry_date: v.new_expiry, claim_expiry_date: v.claim_expiry_date, amount, status: "Extended" }).eq("id", bg.id);
      if (error) { await supabase.from("bg_amendments").delete().eq("id", amendment.id); throw error; }
      await logAudit(bg.id, "Extension recorded", `Expiry ${fmtDate(bg.expiry_date)} → ${fmtDate(v.new_expiry)}; amount ${bg.amount} → ${amount}; claim expiry ${fmtDate(v.claim_expiry_date)}; ${v.remarks}`);
      await invalidate(); toast.success("Extension recorded"); onClose();
    } catch (error) { toast.error(String((error as { message?: string }).message ?? error)); }
  };
  return <Dialog open onOpenChange={(open) => !open && !form.formState.isSubmitting && onClose()}><DialogContent className="max-h-[90dvh] overflow-y-auto">
    <DialogHeader><DialogTitle>Record extension</DialogTitle><DialogDescription>{bg.bg_number} · current expiry {fmtDate(bg.expiry_date)}</DialogDescription></DialogHeader>
    <Form {...form}><form noValidate onSubmit={form.handleSubmit(save)} className="space-y-4">
      <FormField control={form.control} name="new_expiry" render={({ field }) => <FormItem><FormLabel>New expiry date</FormLabel><FormControl><Input {...field} type="date" onChange={(e) => { field.onChange(e.target.value); if (e.target.value) form.setValue("claim_expiry_date", addDays(e.target.value, 90)); }} /></FormControl><FormMessage /></FormItem>} />
      <Field form={form} name="claim_expiry_date" label="Claim expiry date" type="date" />
      <Field form={form} name="new_amount" label="New amount (₹, optional)" type="number" />
      <Field form={form} name="remarks" label="Remarks" type="textarea" />
      <DialogFooter className="gap-2"><Button type="button" variant="outline" disabled={form.formState.isSubmitting} onClick={onClose}>Cancel</Button><Button type="submit" disabled={form.formState.isSubmitting}>{form.formState.isSubmitting ? "Saving…" : "Save extension"}</Button></DialogFooter>
    </form></Form>
  </DialogContent></Dialog>;
}