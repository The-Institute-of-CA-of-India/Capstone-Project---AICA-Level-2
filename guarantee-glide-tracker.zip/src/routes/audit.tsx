import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, ErrorState, EmptyState } from "@/components/AppShell";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useAudit, useBGs } from "@/lib/queries";
import { fmtDateTime } from "@/lib/format";

export const Route = createFileRoute("/audit")({
  head: () => ({
    meta: [
      { title: "Audit Log · BG Tracker" },
      { name: "description", content: "Chronological record of every action on bank guarantees." },
      { property: "og:title", content: "Audit Log · BG Tracker" },
      { property: "og:description", content: "Chronological record of every action on bank guarantees." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Audit,
});

function Audit() {
  const { data, isLoading, error } = useAudit();
  const bgs = useBGs().data;
  const [q, setQ] = useState("");
  const [action, setAction] = useState("");
  const actions = [...new Set((data ?? []).map((a) => a.action))].sort();
  const bgNo = (id: string | null) => (id ? bgs?.find((b) => b.id === id)?.bg_number ?? "" : "—");
  const list = (data ?? []).filter((a) => (!action || a.action === action) && (!q || `${a.details} ${bgNo(a.bg_id)}`.toLowerCase().includes(q.toLowerCase())));
  if (error) return <ErrorState error={error} />;
  return (
    <>
      <PageHeader title="Audit Log" subtitle="Every action, newest first" />
      <div className="card-soft mb-4 flex flex-wrap gap-2 p-3">
        <Input placeholder="Search details or BG no." value={q} onChange={(e) => setQ(e.target.value)} className="h-9 max-w-xs" />
        <select className="h-9 rounded-md border bg-card px-2 text-sm" value={action} onChange={(e) => setAction(e.target.value)}><option value="">All actions</option>{actions.map((a) => <option key={a}>{a}</option>)}</select>
      </div>
      <div className="card-soft overflow-x-auto">
        {isLoading ? <Skeleton className="m-4 h-64" /> : list.length === 0 ? <div className="p-4"><EmptyState title="No entries" /></div> : (
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-muted-foreground"><tr className="border-b"><th className="px-4 py-2">When</th><th className="pr-4">Action</th><th className="pr-4">BG</th><th className="pr-4">Details</th><th className="pr-4">By</th></tr></thead>
            <tbody>{list.map((a) => <tr key={a.id} className="border-b last:border-0"><td className="tabular whitespace-nowrap px-4 py-2">{fmtDateTime(a.created_at)}</td><td className="pr-4 font-medium">{a.action}</td><td className="pr-4">{bgNo(a.bg_id)}</td><td className="pr-4 text-muted-foreground">{a.details}</td><td className="pr-4">{a.performed_by}</td></tr>)}</tbody>
          </table>
        )}
      </div>
    </>
  );
}
