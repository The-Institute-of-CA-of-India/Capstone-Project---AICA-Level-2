import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Download, Plus, Pencil } from "lucide-react";
import { BGFormDialog, ExtensionDialog } from "@/components/BGDialogs";
import { PageHeader, ErrorState, EmptyState } from "@/components/AppShell";
import { StatusChip, DaysBadge } from "@/components/StatusChip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import { useBGs, useAmendments, useAudit, useReminders, logAudit, useInvalidateAll } from "@/lib/queries";
import { BANKS, BG_STATUSES, BG_TYPES, daysLeft, displayStatus, type BG } from "@/lib/bg";
import { fmtDate, fmtDateTime, inr, inrCompact, todayISO } from "@/lib/format";

export const Route = createFileRoute("/register")({
  validateSearch: (s: Record<string, unknown>): { bg?: string } => typeof s["bg"] === "string" ? { bg: s["bg"] } : {},
  head: () => ({
    meta: [
      { title: "BG Register · BG Tracker" },
      { name: "description", content: "Searchable register of all bank guarantees with lifecycle details." },
      { property: "og:title", content: "BG Register · BG Tracker" },
      { property: "og:description", content: "Searchable register of all bank guarantees with lifecycle details." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Register,
});

const sel = "h-9 rounded-md border bg-card px-2 text-sm";

function Register() {
  const { data, isLoading, error } = useBGs();
  const search = Route.useSearch();
  const nav = Route.useNavigate();
  const [q, setQ] = useState("");
  const [adding, setAdding] = useState(false);
  const [bank, setBank] = useState("");
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const [win, setWin] = useState("");
  const [sort, setSort] = useState<{ k: keyof BG; asc: boolean }>({ k: "expiry_date", asc: true });
  const today = todayISO();

  const rows = useMemo(() => {
    let r = data ?? [];
    const s = q.toLowerCase();
    if (s) r = r.filter((b) => [b.bg_number, b.applicant_name, b.beneficiary_name, b.bank_name, b.contract_ref].join(" ").toLowerCase().includes(s));
    if (bank) r = r.filter((b) => b.bank_name === bank);
    if (type) r = r.filter((b) => b.bg_type === type);
    if (status) r = r.filter((b) => b.status === status || displayStatus(b, today) === status);
    if (win) r = r.filter((b) => { const d = daysLeft(b, today); return win === "past" ? d < 0 : d >= 0 && d <= Number(win); });
    return [...r].sort((a, b) => { const x = a[sort.k] ?? "", y = b[sort.k] ?? ""; const c = sort.k === "amount" ? Number(x) - Number(y) : String(x).localeCompare(String(y)); return sort.asc ? c : -c; });
  }, [data, q, bank, type, status, win, sort, today]);

  const exportCsv = () => {
    const cols: (keyof BG)[] = ["bg_number", "bg_type", "bank_name", "applicant_name", "beneficiary_name", "amount", "margin_percent", "issue_date", "expiry_date", "claim_expiry_date", "status"];
    const csv = [cols.join(","), ...rows.map((r) => cols.map((c) => `"${String(r[c] ?? "").replace(/"/g, '""')}"`).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = "bg-register.csv";
    a.click();
  };
  const th = (k: keyof BG, l: string) => <th className="cursor-pointer py-2 pr-4 select-none" onClick={() => setSort({ k, asc: sort.k === k ? !sort.asc : true })}>{l}{sort.k === k ? (sort.asc ? " ↑" : " ↓") : ""}</th>;
  const open = data?.find((b) => b.id === search.bg);

  if (error) return <ErrorState error={error} />;
  return (
    <>
      <PageHeader title="BG Register" subtitle="All bank guarantees" actions={<><Button onClick={() => setAdding(true)} disabled={isLoading}><Plus className="size-4" />Add BG</Button><Button variant="outline" onClick={exportCsv}><Download className="size-4" />Export CSV</Button></>} />
      <div className="card-soft mb-4 flex flex-wrap gap-2 p-3">
        <Input placeholder="Search BG no., client, beneficiary…" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 max-w-xs" />
        <select className={sel} value={bank} onChange={(e) => setBank(e.target.value)}><option value="">All banks</option>{BANKS.map((b) => <option key={b}>{b}</option>)}</select>
        <select className={sel} value={type} onChange={(e) => setType(e.target.value)}><option value="">All types</option>{BG_TYPES.map((b) => <option key={b}>{b}</option>)}</select>
        <select className={sel} value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{[...BG_STATUSES, "Expiring Soon", "Overdue Release"].map((b) => <option key={b}>{b}</option>)}</select>
        <select className={sel} value={win} onChange={(e) => setWin(e.target.value)}><option value="">Any expiry</option><option value="7">≤ 7 days</option><option value="30">≤ 30 days</option><option value="90">≤ 90 days</option><option value="past">Already expired</option></select>
      </div>
      <div className="card-soft overflow-x-auto">
        {isLoading ? <div className="space-y-2 p-4">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-9" />)}</div> : rows.length === 0 ? <div className="p-4"><EmptyState title="No BGs match" hint="Try clearing filters." /></div> : (
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase text-muted-foreground"><tr className="border-b">{th("bg_number", "BG No.")}{th("applicant_name", "Client")}{th("bank_name", "Bank")}<th className="pr-4">Type</th>{th("amount", "Amount")}{th("expiry_date", "Expiry")}<th className="pr-4">Status</th><th className="pr-4">Days</th></tr></thead>
            <tbody>
              {rows.map((b) => (
                <tr key={b.id} onClick={() => nav({ search: { bg: b.id } })} className="cursor-pointer border-b last:border-0 hover:bg-muted/50">
                  <td className="px-0 py-2.5 pr-4 font-medium text-primary">{b.bg_number}</td>
                  <td className="pr-4">{b.applicant_name}</td>
                  <td className="pr-4 text-muted-foreground">{b.bank_name}</td>
                  <td className="pr-4">{b.bg_type}</td>
                  <td className="tabular pr-4" title={inr(Number(b.amount))}>{inrCompact(Number(b.amount))}</td>
                  <td className="tabular pr-4">{fmtDate(b.expiry_date)}</td>
                  <td className="pr-4"><StatusChip status={displayStatus(b, today)} /></td>
                  <td className="pr-4">{b.status === "Discharged" ? "—" : <DaysBadge days={daysLeft(b, today)} />}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <Sheet open={!!open} onOpenChange={(o) => !o && nav({ search: {} })}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-xl">{open && <Detail key={open.id} bg={open} rows={data ?? []} />}</SheetContent>
      </Sheet>
      {adding && <BGFormDialog rows={data ?? []} onClose={() => setAdding(false)} />}
    </>
  );
}

function Detail({ bg, rows }: { bg: BG; rows: BG[] }) {
  const [editing, setEditing] = useState(false);
  const [extending, setExtending] = useState(false);
  const am = useAmendments().data?.filter((a) => a.bg_id === bg.id) ?? [];
  const rem = useReminders().data?.filter((r) => r.bg_id === bg.id) ?? [];
  const aud = useAudit().data?.filter((a) => a.bg_id === bg.id) ?? [];
  const inv = useInvalidateAll();
  const upd = async (patch: Partial<BG>, action: string, details: string) => {
    const { error } = await supabase.from("bank_guarantees").update(patch).eq("id", bg.id);
    if (error) { toast.error(error.message); return; }
    await logAudit(bg.id, action, details);
    toast.success(action);
    inv();
  };
  const F = ({ l, v }: { l: string; v: ReactNode }) => <div className="min-w-0"><div className="text-xs text-muted-foreground">{l}</div><div className="break-words text-sm font-medium">{v}</div></div>;
  return (
    <div className="space-y-6 pb-8">
      <SheetHeader><SheetTitle>{bg.bg_number}</SheetTitle><StatusChip status={displayStatus(bg)} /></SheetHeader>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="outline" onClick={() => setEditing(true)}><Pencil className="size-4" />Edit</Button>
        <Button size="sm" onClick={() => setExtending(true)}>Record extension</Button>
        <Button size="sm" variant="outline" disabled={bg.original_returned} onClick={() => upd({ original_returned: true }, "Original returned", "Original BG received back")}>Mark original returned</Button>
        <Button size="sm" variant="outline" onClick={() => upd({ status: "Release Requested", release_letter_received: true }, "Release requested", "Release letter received; release requested")}>Request release</Button>
        <Button size="sm" variant="outline" onClick={() => upd({ status: "Discharged", original_returned: true, release_letter_received: true }, "Marked discharged", "BG closed")}>Mark discharged</Button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <F l="Type" v={bg.bg_type} /><F l="Amount" v={`${inr(Number(bg.amount))} (${inrCompact(Number(bg.amount))})`} />
        <F l="Bank" v={`${bg.bank_name}, ${bg.branch ?? ""}`} /><F l="Contract" v={bg.contract_ref} />
        <F l="Applicant" v={bg.applicant_name} /><F l="Beneficiary" v={bg.beneficiary_name} />
        <F l="Margin" v={`${bg.margin_percent}% · ${bg.margin_type}`} /><F l="FDR" v={bg.fdr_number ?? "—"} />
        <F l="Commission" v={`${bg.commission_rate_percent}% p.a.`} /><F l="Next commission" v={fmtDate(bg.next_commission_due)} />
        <F l="Original returned" v={bg.original_returned ? "Yes" : "No"} /><F l="Release letter" v={bg.release_letter_received ? "Received" : "Pending"} />
      </div>
      {bg.notes && <p className="rounded-lg bg-muted p-3 text-sm">{bg.notes}</p>}
      <section><h3 className="mb-2 text-sm font-semibold">Lifecycle</h3>
        <ol className="space-y-2 border-l-2 border-primary/30 pl-4 text-sm">
          <li>Issued · {fmtDate(bg.issue_date)}</li>
          {am.map((a) => <li key={a.id}>Extended on {fmtDate(a.amended_on)} · {fmtDate(a.old_expiry)} → {fmtDate(a.new_expiry)}{a.new_amount !== a.old_amount ? ` · ${inrCompact(Number(a.old_amount))} → ${inrCompact(Number(a.new_amount))}` : ""}<div className="text-xs text-muted-foreground">{a.remarks}</div></li>)}
          <li>Expiry · {fmtDate(bg.expiry_date)}</li>
          <li>Claim expiry · {fmtDate(bg.claim_expiry_date)}</li>
          <li>{bg.status === "Discharged" ? "Released / discharged" : "Release pending"}</li>
        </ol>
      </section>
      <section><h3 className="mb-2 text-sm font-semibold">Reminders ({rem.length})</h3>
        {rem.map((r) => <div key={r.id} className="flex justify-between border-b py-1.5 text-sm"><span>{r.reminder_type} → {r.recipient_role}</span><StatusChip status={r.status} /></div>)}
      </section>
      <section><h3 className="mb-2 text-sm font-semibold">Audit</h3>
        {aud.map((a) => <div key={a.id} className="border-b py-1.5 text-sm"><span className="font-medium">{a.action}</span> · <span className="text-muted-foreground">{fmtDateTime(a.created_at)}</span><div className="text-xs text-muted-foreground">{a.details}</div></div>)}
      </section>
      {editing && <BGFormDialog bg={bg} rows={rows} onClose={() => setEditing(false)} />}
      {extending && <ExtensionDialog bg={bg} onClose={() => setExtending(false)} />}
    </div>
  );
}
