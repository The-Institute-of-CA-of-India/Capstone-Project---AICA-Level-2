import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PlayCircle } from "lucide-react";
import { PageHeader, ErrorState, EmptyState } from "@/components/AppShell";
import { StatusChip } from "@/components/StatusChip";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { useBGs, useReminders, logAudit, useInvalidateAll } from "@/lib/queries";
import { RECIPIENT_ROLES, type Reminder } from "@/lib/bg";
import { runDailyCheck } from "@/lib/reminder-rules";
import { fmtDate } from "@/lib/format";

export const Route = createFileRoute("/reminders")({
  head: () => ({
    meta: [
      { title: "Reminders · BG Tracker" },
      { name: "description", content: "Approval queue for rules-driven BG reminder emails." },
      { property: "og:title", content: "Reminders · BG Tracker" },
      { property: "og:description", content: "Approval queue for rules-driven BG reminder emails." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Reminders,
});

const TABS = [["Draft/Pending Approval", "Pending"], ["Approved & Sent", "Sent"], ["Dismissed", "Dismissed"]] as const;

function Reminders() {
  const bgs = useBGs();
  const { data, isLoading, error } = useReminders();
  const inv = useInvalidateAll();
  const [tab, setTab] = useState<string>(TABS[0][0]);
  const [role, setRole] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async () => {
    if (!bgs.data || !data) return;
    setBusy(true);
    const drafts = runDailyCheck(bgs.data, data);
    if (drafts.length) {
      const { error: e } = await supabase.from("reminders").insert(drafts);
      if (e) { setBusy(false); toast.error(e.message); return; }
    }
    await logAudit(null, "Daily check run", `${drafts.length} new draft reminder(s) created`);
    toast.success(drafts.length ? `${drafts.length} new draft reminders created` : "No new reminders - all rules already covered");
    setBusy(false);
    inv();
  };
  const list = (data ?? []).filter((r) => r.status === tab && (!role || r.recipient_role === role));
  const bgNo = (id: string) => bgs.data?.find((b) => b.id === id)?.bg_number ?? "";

  if (error) return <ErrorState error={error} />;
  return (
    <>
      <PageHeader title="Reminders" subtitle="Review, edit and approve reminder emails" actions={<Button onClick={run} disabled={busy || !bgs.data || !data}><PlayCircle className="size-4" />Run daily check</Button>} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {TABS.map(([k, l]) => <Button key={k} size="sm" variant={tab === k ? "default" : "outline"} onClick={() => setTab(k)}>{l} ({(data ?? []).filter((r) => r.status === k).length})</Button>)}
        <select className="h-9 rounded-md border bg-card px-2 text-sm" value={role} onChange={(e) => setRole(e.target.value)}><option value="">All recipients</option>{RECIPIENT_ROLES.map((r) => <option key={r}>{r}</option>)}</select>
      </div>
      {isLoading ? <Skeleton className="h-64 rounded-xl" /> : list.length === 0 ? <EmptyState title="Nothing here" hint={tab === TABS[0][0] ? "Click “Run daily check” to generate drafts." : "No reminders in this category."} /> : (
        <div className="space-y-4">{list.map((r) => <Card key={r.id} r={r} bgNo={bgNo(r.bg_id)} onDone={inv} />)}</div>
      )}
    </>
  );
}

function Card({ r, bgNo, onDone }: { r: Reminder; bgNo: string; onDone: () => void }) {
  const [subject, setSubject] = useState(r.subject);
  const [body, setBody] = useState(r.body);
  const [open, setOpen] = useState(false);
  const pending = r.status === "Draft/Pending Approval";
  const act = async (status: string) => {
    const { error } = await supabase.from("reminders").update({ subject, body, status, sent_at: status === "Approved & Sent" ? new Date().toISOString() : null }).eq("id", r.id);
    if (error) { toast.error(error.message); return; }
    await logAudit(r.bg_id, status === "Dismissed" ? "Reminder dismissed" : "Reminder sent (simulated)", `${subject} → ${r.recipient_email}`);
    status === "Dismissed" ? toast("Reminder dismissed") : toast.success("Demo mode - no real email sent", { description: `Marked as sent to ${r.recipient_email}` });
    onDone();
  };
  return (
    <div className="card-soft p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="text-xs text-muted-foreground">{r.reminder_type} · {bgNo} · due {fmtDate(r.due_date)}</div>
          <div className="mt-1 font-medium">{subject}</div>
          <div className="text-sm text-muted-foreground">To: {r.recipient_role} &lt;{r.recipient_email}&gt;</div>
        </div>
        <StatusChip status={r.status} />
      </div>
      {open ? (
        <div className="mt-4 space-y-2">
          <Input value={subject} onChange={(e) => setSubject(e.target.value)} disabled={!pending} />
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={16} disabled={!pending} className="font-mono text-xs" />
        </div>
      ) : <p className="mt-3 line-clamp-2 whitespace-pre-line text-sm text-muted-foreground">{body}</p>}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant="ghost" onClick={() => setOpen(!open)}>{open ? "Collapse" : pending ? "View & edit" : "View"}</Button>
        {pending && <><Button size="sm" onClick={() => act("Approved & Sent")}>Approve & send</Button><Button size="sm" variant="outline" onClick={() => act("Dismissed")}>Dismiss</Button></>}
      </div>
    </div>
  );
}
