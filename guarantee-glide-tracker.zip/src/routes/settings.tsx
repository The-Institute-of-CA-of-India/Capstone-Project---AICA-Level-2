import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidateAll } from "@/lib/queries";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings · BG Tracker" },
      { name: "description", content: "Demo tools and reminder rule documentation." },
      { property: "og:title", content: "Settings · BG Tracker" },
      { property: "og:description", content: "Demo tools and reminder rule documentation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const inv = useInvalidateAll();
  const [busy, setBusy] = useState(false);
  const reset = async (label: string) => {
    if (!confirm(`${label}? All current demo data will be replaced.`)) return;
    setBusy(true);
    const { error } = await supabase.rpc("reset_demo_data");
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Demo data reloaded with dates relative to today");
    inv();
  };
  return (
    <>
      <PageHeader title="Settings" subtitle="Demo tools" />
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card-soft space-y-3 p-5">
          <h2 className="font-semibold">Demo data</h2>
          <p className="text-sm text-muted-foreground">All companies, banks' email addresses and people are fictional. Dates are generated relative to today so the demo always looks current.</p>
          <div className="flex gap-2">
            <Button variant="destructive" disabled={busy} onClick={() => reset("Reset demo data")}>Reset demo data</Button>
            <Button variant="outline" disabled={busy} onClick={() => reset("Re-seed")}>Re-seed</Button>
          </div>
        </div>
        <div className="card-soft space-y-3 p-5 text-sm">
          <h2 className="font-semibold">How the daily check works</h2>
          <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
            <li>60 / 30 / 15 / 7 days before expiry: reminder to the Internal Team and the Client.</li>
            <li>On the expiry date: notice to the Client.</li>
            <li>After expiry with the original not returned: polite request to the Beneficiary to return it or issue a release letter.</li>
            <li>Release letter received: formal request to the Bank for cancellation, margin/FDR lien release and closure confirmation.</li>
            <li>Claim expiry within 15 days and original not returned: escalation to the Internal Team.</li>
            <li>No duplicates: a reminder of the same type to the same recipient for a BG is created only once.</li>
          </ul>
          <div className="rounded-lg bg-accent p-3 text-accent-foreground">In production, this check would run automatically as a scheduled job every morning, and approved reminders would be sent as real emails. In this demo, sending is simulated.</div>
        </div>
      </div>
    </>
  );
}
