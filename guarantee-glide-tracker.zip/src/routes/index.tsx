import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, type ReactNode } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from "recharts";
import { Info } from "lucide-react";
import { PageHeader, ErrorState, EmptyState } from "@/components/AppShell";
import { StatusChip, DaysBadge } from "@/components/StatusChip";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useBGs } from "@/lib/queries";
import { daysLeft, displayStatus, isExposure, isLive, isOverdueRelease, marginBlocked, type BG } from "@/lib/bg";
import { addDays, daysBetween, fmtDate, inr, inrCompact, MONTH_LABELS, parseDate, todayISO } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · BG Tracker" },
      { name: "description", content: "Exposure, expiries and overdue releases across all bank guarantees at a glance." },
      { property: "og:title", content: "Dashboard · BG Tracker" },
      { property: "og:description", content: "Exposure, expiries and overdue releases across all bank guarantees at a glance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)", "var(--st-purple)", "var(--st-green)", "var(--st-grey)"];
const STATUS_COLORS: Record<string, string> = {
  Active: "var(--st-green)", "Expiring Soon": "var(--st-amber)", "Overdue Release": "var(--st-red)", Expired: "var(--st-red)",
  Extended: "var(--st-blue)", Invoked: "var(--st-purple)", "Release Requested": "var(--st-teal)", Discharged: "var(--st-grey)",
};

function Kpi({ label, value, sub, tip, tone }: { label: string; value: string; sub?: string; tip: string; tone?: string }) {
  return (
    <div className="card-soft p-5">
      <div className="flex items-center justify-between text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {label}
        <Tooltip>
          <TooltipTrigger aria-label={`About ${label}`}><Info className="size-3.5" /></TooltipTrigger>
          <TooltipContent className="max-w-xs">{tip}</TooltipContent>
        </Tooltip>
      </div>
      <div className={`tabular mt-2 text-2xl font-semibold ${tone ?? ""}`}>{value}</div>
      {sub && <div className="tabular mt-1 text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}

function Panel({ title, children, className }: { title: string; children: ReactNode; className?: string }) {
  return (
    <div className={`card-soft p-5 ${className ?? ""}`}>
      <h2 className="mb-4 text-sm font-semibold">{title}</h2>
      {children}
    </div>
  );
}

function Dashboard() {
  const { data, isLoading, error } = useBGs();
  const today = todayISO();
  const m = useMemo(() => (data ? compute(data, today) : null), [data, today]);

  if (error) return <ErrorState error={error} />;
  return (
    <>
      <PageHeader title="Dashboard" subtitle={`Portfolio snapshot as on ${fmtDate(today)}`} />
      {!m ? (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>
          <div className="grid gap-4 lg:grid-cols-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-72 rounded-xl" />)}</div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
            <Kpi label="Active BGs" value={String(m.active.length)} sub={`of ${data?.length ?? 0} total`} tip="BGs with status Active or Extended (not invoked, released or discharged)." />
            <Kpi label="Total exposure" value={inrCompact(m.exposure)} sub={inr(m.exposure)} tip="Sum of BG amounts for every guarantee not yet discharged, including invoked and release-requested BGs." />
            <Kpi label="Margin / FDR blocked" value={inrCompact(m.margin)} sub={inr(m.margin)} tip="Amount × margin % across non-discharged BGs: cash margin and FDRs under lien with banks." />
            <Kpi label="Expiring in 30 days" value={String(m.exp30.length)} sub={inrCompact(sum(m.exp30))} tone="text-st-amber" tip="Active/Extended BGs whose expiry date falls within the next 30 days." />
            <Kpi label="Overdue releases" value={String(m.overdue.length)} sub={inrCompact(sum(m.overdue))} tone="text-st-red" tip="BGs past expiry where the original instrument has not been returned by the beneficiary." />
            <Kpi label="Commission due ≤15 days" value={String(m.comm.length)} sub={`≈ ${inrCompact(m.commAmt)} estimated`} tip="Non-discharged BGs whose next commission due date is within 15 days. Estimate = amount × annual rate ÷ 4." />
          </div>

          <Panel title="Needs attention">
            {m.attention.length === 0 ? <EmptyState title="All clear" hint="Nothing expiring in 30 days and no overdue releases." /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-xs uppercase text-muted-foreground">
                    <tr className="border-b"><th className="py-2 pr-4">BG No.</th><th className="pr-4">Client</th><th className="pr-4">Bank</th><th className="pr-4 text-right">Amount</th><th className="pr-4">Expiry</th><th className="pr-4">Status</th><th>Days</th></tr>
                  </thead>
                  <tbody>
                    {m.attention.map((b) => (
                      <tr key={b.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="py-2.5 pr-4 font-medium"><Link to="/register" search={{ bg: b.id }} className="text-primary hover:underline">{b.bg_number}</Link></td>
                        <td className="pr-4">{b.applicant_name}</td>
                        <td className="pr-4 text-muted-foreground">{b.bank_name}</td>
                        <td className="tabular pr-4 text-right">{inrCompact(Number(b.amount))}</td>
                        <td className="tabular pr-4">{fmtDate(b.expiry_date)}</td>
                        <td className="pr-4"><StatusChip status={displayStatus(b, today)} /></td>
                        <td><DaysBadge days={daysLeft(b, today)} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Panel>

          <Panel title="Expiry heat strip - next 90 days">
            <div className="grid grid-cols-[repeat(15,minmax(0,1fr))] gap-1 sm:grid-cols-[repeat(30,minmax(0,1fr))]">
              {m.heat.map((h) => (
                <Tooltip key={h.date}>
                  <TooltipTrigger asChild>
                    <div className={`aspect-square rounded-sm ${h.count === 0 ? "bg-muted" : h.count === 1 ? "bg-st-amber/50" : "bg-st-red/70"} ${h.date === today ? "ring-2 ring-primary" : ""}`} />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="font-medium">{fmtDate(h.date)}</div>
                    {h.items.length ? h.items.map((b) => <div key={b.id}>{b.bg_number} · {inrCompact(Number(b.amount))}</div>) : <div>No expiries</div>}
                  </TooltipContent>
                </Tooltip>
              ))}
            </div>
            <div className="mt-3 flex gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><span className="size-3 rounded-sm bg-muted" />None</span>
              <span className="flex items-center gap-1"><span className="size-3 rounded-sm bg-st-amber/50" />1 BG</span>
              <span className="flex items-center gap-1"><span className="size-3 rounded-sm bg-st-red/70" />2+ BGs</span>
            </div>
          </Panel>

          <div className="grid gap-4 lg:grid-cols-2">
            <Panel title="Exposure by bank (₹ Cr)">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={m.byBank} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="var(--border)" />
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="name" width={130} tick={{ fontSize: 11 }} />
                  <RTooltip formatter={(v: number) => `₹${v.toFixed(2)} Cr`} />
                  <Bar dataKey="cr" fill="var(--chart-1)" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Panel>
            <Panel title="BGs by status">
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={m.byStatus} dataKey="value" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={2}>
                    {m.byStatus.map((s) => <Cell key={s.name} fill={STATUS_COLORS[s.name] ?? "var(--st-grey)"} />)}
                  </Pie>
                  <RTooltip />
                </PieChart>
              </ResponsiveContainer>
              <Legend items={m.byStatus.map((s) => ({ ...s, color: STATUS_COLORS[s.name] ?? "var(--st-grey)" }))} />
            </Panel>
            <Panel title="Expiry timeline - next 12 months">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={m.timeline}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <RTooltip formatter={(v: number, n: string) => (n === "cr" ? `₹${v.toFixed(2)} Cr` : v)} />
                  <Bar dataKey="count" name="BGs" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Panel>
            <Panel title="BG type split (by amount)">
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={m.byType} dataKey="value" nameKey="name" outerRadius={95}>
                    {m.byType.map((s, i) => <Cell key={s.name} fill={COLORS[i]} />)}
                  </Pie>
                  <RTooltip formatter={(v: number) => inrCompact(v)} />
                </PieChart>
              </ResponsiveContainer>
              <Legend items={m.byType.map((s, i) => ({ name: s.name, value: inrCompact(s.value), color: COLORS[i] ?? "var(--st-grey)" }))} />
            </Panel>
          </div>
        </div>
      )}
    </>
  );
}

function Legend({ items }: { items: { name: string; value: number | string; color?: string }[] }) {
  return (
    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs">
      {items.map((i) => (
        <span key={i.name} className="flex items-center gap-1.5"><span className="size-2.5 rounded-full" style={{ background: i.color }} />{i.name} <span className="tabular text-muted-foreground">{i.value}</span></span>
      ))}
    </div>
  );
}

const sum = (l: BG[]) => l.reduce((a, b) => a + Number(b.amount), 0);

function compute(bgs: BG[], today: string) {
  const active = bgs.filter(isLive);
  const open = bgs.filter(isExposure);
  const exp30 = active.filter((b) => { const d = daysLeft(b, today); return d >= 0 && d <= 30; });
  const overdue = bgs.filter((b) => isOverdueRelease(b, today));
  const comm = open.filter((b) => b.next_commission_due && daysBetween(today, b.next_commission_due) >= 0 && daysBetween(today, b.next_commission_due) <= 15);
  const commAmt = comm.reduce((a, b) => a + (Number(b.amount) * Number(b.commission_rate_percent)) / 100 / 4, 0);
  const attention = [...overdue, ...exp30].sort((a, b) => daysLeft(a, today) - daysLeft(b, today));

  const bank = new Map<string, number>();
  open.forEach((b) => bank.set(b.bank_name, (bank.get(b.bank_name) ?? 0) + Number(b.amount)));
  const byBank = [...bank].map(([name, v]) => ({ name, cr: +(v / 1e7).toFixed(2) })).sort((a, b) => b.cr - a.cr);

  const st = new Map<string, number>();
  bgs.forEach((b) => { const s = displayStatus(b, today); st.set(s, (st.get(s) ?? 0) + 1); });
  const byStatus = [...st].map(([name, value]) => ({ name, value }));

  const ty = new Map<string, number>();
  open.forEach((b) => ty.set(b.bg_type, (ty.get(b.bg_type) ?? 0) + Number(b.amount)));
  const byType = [...ty].map(([name, value]) => ({ name, value }));

  const t0 = parseDate(today);
  const timeline = Array.from({ length: 12 }, (_, i) => {
    const d = new Date(t0.getFullYear(), t0.getMonth() + i, 1);
    const items = active.filter((b) => { const e = parseDate(b.expiry_date); return e.getFullYear() === d.getFullYear() && e.getMonth() === d.getMonth() && b.expiry_date >= today; });
    return { label: `${MONTH_LABELS[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`, count: items.length, cr: sum(items) / 1e7 };
  });

  const heat = Array.from({ length: 90 }, (_, i) => {
    const date = addDays(today, i);
    const items = active.filter((b) => b.expiry_date === date);
    return { date, count: items.length, items };
  });

  return { active, exposure: sum(open), margin: open.reduce((a, b) => a + marginBlocked(b), 0), exp30, overdue, comm, commAmt, attention, byBank, byStatus, byType, timeline, heat };
}
