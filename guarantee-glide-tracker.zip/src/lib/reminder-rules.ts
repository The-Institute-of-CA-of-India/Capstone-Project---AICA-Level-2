import type { BG, Reminder } from "./bg";
import { INTERNAL_EMAIL, isLive } from "./bg";
import { daysBetween, fmtDate, inr, inrCompact, todayISO } from "./format";

export type DraftReminder = {
  bg_id: string;
  reminder_type: string;
  recipient_role: "Internal Team" | "Client" | "Beneficiary" | "Bank";
  recipient_email: string | null;
  subject: string;
  body: string;
  due_date: string;
};

export const EXPIRY_THRESHOLDS = [60, 30, 15, 7] as const;

const SIGN = `\n\nThanking you,\nYours faithfully,\n\nBG Desk\nFinance & Treasury Team\n(Demo - fictional organisation)`;

function facts(bg: BG): string {
  return [
    `BG No.: ${bg.bg_number}`,
    `Type: ${bg.bg_type}`,
    `Issuing Bank: ${bg.bank_name}${bg.branch ? `, ${bg.branch}` : ""}`,
    `Applicant: ${bg.applicant_name}`,
    `Beneficiary: ${bg.beneficiary_name}`,
    `Contract Ref.: ${bg.contract_ref ?? "—"}`,
    `Amount: ${inr(Number(bg.amount))} (${inrCompact(Number(bg.amount))})`,
    `Date of Issue: ${fmtDate(bg.issue_date)}`,
    `Date of Expiry: ${fmtDate(bg.expiry_date)}`,
    `Claim Expiry: ${fmtDate(bg.claim_expiry_date)}`,
  ].map((l) => `  • ${l}`).join("\n");
}

/** Pure rule engine: which reminders should exist today for this BG. */
export function rulesFor(bg: BG, today = todayISO()): DraftReminder[] {
  const out: DraftReminder[] = [];
  if (!isLive(bg) && bg.status !== "Release Requested") return out;
  const left = daysBetween(today, bg.expiry_date);
  const claimLeft = daysBetween(today, bg.claim_expiry_date);
  const base = { bg_id: bg.id, due_date: today };

  if (isLive(bg) && left > 0) {
    const t = [...EXPIRY_THRESHOLDS].reverse().find((x) => left <= x);
    if (t) {
      out.push({
        ...base,
        reminder_type: `Expiry T-${t}`,
        recipient_role: "Internal Team",
        recipient_email: INTERNAL_EMAIL,
        subject: `[Internal] BG ${bg.bg_number} expires in ${left} days - action required`,
        body: `Dear Team,\n\nPlease note that the following Bank Guarantee is due to expire in ${left} days, on ${fmtDate(bg.expiry_date)}.\n\n${facts(bg)}\n\nKindly coordinate with ${bg.applicant_name} to ascertain whether an extension is required under the contract, or whether the beneficiary will return the original instrument on expiry. Please also verify the margin of ${bg.margin_percent}% (${bg.margin_type}${bg.fdr_number ? `, ${bg.fdr_number}` : ""}) and the next commission due on ${fmtDate(bg.next_commission_due)}.${SIGN}`,
      });
      out.push({
        ...base,
        reminder_type: `Expiry T-${t}`,
        recipient_role: "Client",
        recipient_email: bg.applicant_email,
        subject: `Reminder: Bank Guarantee ${bg.bg_number} expiring on ${fmtDate(bg.expiry_date)}`,
        body: `Dear Sir/Madam,\n\nGreetings from the BG Desk.\n\nWe wish to bring to your kind attention that the Bank Guarantee furnished on your behalf in favour of ${bg.beneficiary_name} is due to expire in ${left} days.\n\n${facts(bg)}\n\nWe request you to kindly confirm at the earliest whether:\n  (a) the guarantee needs to be extended, in which case please share the beneficiary's request and the revised validity; or\n  (b) the contractual obligations are complete, so that we may follow up with the beneficiary for return of the original guarantee / release letter.\n\nTimely action will help avoid unnecessary commission charges and blocking of margin.${SIGN}`,
      });
    }
  }

  if (isLive(bg) && left === 0) {
    out.push({
      ...base,
      reminder_type: "Expiry day",
      recipient_role: "Client",
      recipient_email: bg.applicant_email,
      subject: `Bank Guarantee ${bg.bg_number} expires today`,
      body: `Dear Sir/Madam,\n\nThis is to inform you that the following Bank Guarantee expires today, ${fmtDate(bg.expiry_date)}.\n\n${facts(bg)}\n\nPlease note that the beneficiary may still lodge a claim up to ${fmtDate(bg.claim_expiry_date)}. We shall shortly write to ${bg.beneficiary_name} requesting return of the original guarantee or a release letter, so that the bank may cancel the instrument and release the margin. Kindly let us know if you have any objection.${SIGN}`,
    });
  }

  if (isLive(bg) && left < 0 && !bg.original_returned) {
    out.push({
      ...base,
      reminder_type: "Beneficiary release request",
      recipient_role: "Beneficiary",
      recipient_email: bg.beneficiary_email,
      subject: `Request for return of original Bank Guarantee ${bg.bg_number} / issue of release letter`,
      body: `Dear Sir/Madam,\n\nSub: Return of original Bank Guarantee No. ${bg.bg_number} - Contract Ref. ${bg.contract_ref ?? "—"}\n\nWe write on behalf of our client, ${bg.applicant_name}, with reference to the above Bank Guarantee issued by ${bg.bank_name} in your favour.\n\n${facts(bg)}\n\nThe validity of the guarantee expired on ${fmtDate(bg.expiry_date)}. As the purpose of the guarantee stands fulfilled, we would be grateful if you could kindly return the original Bank Guarantee, or alternatively issue a letter confirming that the guarantee stands released and that you have no further claim thereunder.\n\nThis will enable the issuing bank to cancel the guarantee and release the margin held against it. We would appreciate your early action in this matter.${SIGN}`,
    });
  }

  if (bg.release_letter_received && bg.status !== "Discharged") {
    out.push({
      ...base,
      reminder_type: "Bank cancellation request",
      recipient_role: "Bank",
      recipient_email: bg.bank_email,
      subject: `Request for cancellation of BG ${bg.bg_number} and release of margin / FDR lien`,
      body: `To,\nThe Branch Manager,\n${bg.bank_name}${bg.branch ? `, ${bg.branch}` : ""}\n\nDear Sir/Madam,\n\nSub: Cancellation of Bank Guarantee No. ${bg.bg_number} and release of margin\n\n${facts(bg)}\n\nWe are pleased to inform you that the beneficiary, ${bg.beneficiary_name}, has ${bg.original_returned ? "returned the original guarantee and " : ""}issued a release letter in respect of the above guarantee. A copy is enclosed for your records.\n\nWe therefore request you to kindly:\n  1. Cancel the above Bank Guarantee in your books;\n  2. Release the ${bg.margin_type.toLowerCase()} of ${bg.margin_percent}%${bg.fdr_number ? ` and remove the lien marked on FDR ${bg.fdr_number}` : ""}; and\n  3. Stop further commission and send us a written closure confirmation.\n\nWe thank you for your continued support.${SIGN}`,
    });
  }

  if (!bg.original_returned && claimLeft >= 0 && claimLeft <= 15 && (isLive(bg) || bg.status === "Release Requested")) {
    out.push({
      ...base,
      reminder_type: "Claim expiry escalation",
      recipient_role: "Internal Team",
      recipient_email: INTERNAL_EMAIL,
      subject: `[ESCALATION] Claim period for BG ${bg.bg_number} ends in ${claimLeft} days - original not returned`,
      body: `Dear Team,\n\nThis is an escalation. The claim period for the following guarantee ends in ${claimLeft} days, on ${fmtDate(bg.claim_expiry_date)}, and the original instrument has not yet been returned by the beneficiary.\n\n${facts(bg)}\n\nPlease follow up with ${bg.beneficiary_name} on priority, keep the client informed, and ensure the bank is approached for cancellation immediately after the claim period lapses.${SIGN}`,
    });
  }
  return out;
}

const key = (r: { bg_id: string; reminder_type: string; recipient_role: string }) =>
  `${r.bg_id}|${r.reminder_type}|${r.recipient_role}`;

/** Run the daily check across all BGs, skipping any reminder that already exists (any status). */
export function runDailyCheck(
  bgs: BG[],
  existing: Pick<Reminder, "bg_id" | "reminder_type" | "recipient_role">[],
  today = todayISO(),
): DraftReminder[] {
  const seen = new Set(existing.map(key));
  const out: DraftReminder[] = [];
  for (const bg of bgs) {
    for (const r of rulesFor(bg, today)) {
      const k = key(r);
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(r);
    }
  }
  return out;
}
