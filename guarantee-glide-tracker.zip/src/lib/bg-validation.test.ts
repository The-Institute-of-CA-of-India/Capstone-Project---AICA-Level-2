import { describe, expect, it } from "vitest";
import { bgDefaults, bgSchema, extensionSchema, uniqueBGNumber } from "./bg-validation";

const valid = { ...bgDefaults(), bg_number: "DEMO/1", applicant_name: "Demo Applicant", beneficiary_name: "Demo Beneficiary", amount: 1000000, issue_date: "2026-01-01", expiry_date: "2026-12-01", claim_expiry_date: "2026-12-01" };
describe("BG form rules", () => {
  it("requires a BG number", () => expect(bgSchema.safeParse({ ...valid, bg_number: " " }).success).toBe(false));
  it("requires a unique BG number and allows unchanged own number", () => {
    const rows = [{ id: "1", bg_number: "DEMO/1" }];
    expect(uniqueBGNumber(rows, " demo/1 ")).toBe(false);
    expect(uniqueBGNumber(rows, "DEMO/1", "1")).toBe(true);
  });
  it("requires amount greater than 0", () => {
    expect(bgSchema.safeParse({ ...valid, amount: 0 }).success).toBe(false);
    expect(bgSchema.safeParse({ ...valid, amount: 1 }).success).toBe(true);
  });
  it("allows margin 0–100 inclusive only", () => {
    for (const margin_percent of [-1, 101]) expect(bgSchema.safeParse({ ...valid, margin_percent }).success).toBe(false);
    for (const margin_percent of [0, 100]) expect(bgSchema.safeParse({ ...valid, margin_percent }).success).toBe(true);
  });
  it("requires expiry strictly after issue", () => expect(bgSchema.safeParse({ ...valid, expiry_date: valid.issue_date }).success).toBe(false));
  it("requires claim expiry on or after expiry", () => {
    expect(bgSchema.safeParse({ ...valid, claim_expiry_date: "2026-11-30" }).success).toBe(false);
    expect(bgSchema.safeParse(valid).success).toBe(true);
  });
  it("validates all provided emails", () => {
    for (const key of ["applicant_email", "beneficiary_email", "bank_email"]) expect(bgSchema.safeParse({ ...valid, [key]: "invalid" }).success).toBe(false);
    expect(bgSchema.safeParse({ ...valid, applicant_email: "demo@example.com" }).success).toBe(true);
  });
  it("rejects impossible calendar dates", () => expect(bgSchema.safeParse({ ...valid, expiry_date: "2026-02-30" }).success).toBe(false));
});
describe("extension rules", () => {
  const schema = extensionSchema("2026-12-01");
  const v = { new_expiry: "2027-01-01", claim_expiry_date: "2027-04-01", remarks: "" };
  it("requires a later new expiry", () => expect(schema.safeParse({ ...v, new_expiry: "2026-12-01" }).success).toBe(false));
  it("allows optional amount but rejects zero", () => {
    expect(schema.safeParse(v).success).toBe(true);
    expect(schema.safeParse({ ...v, new_amount: 0 }).success).toBe(false);
  });
  it("requires claim expiry on or after new expiry", () => expect(schema.safeParse({ ...v, claim_expiry_date: "2026-12-31" }).success).toBe(false));
});