import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Amendment, AuditEntry, BG, Reminder } from "./bg";

async function ensureSeeded() {
  const { count, error } = await supabase.from("bank_guarantees").select("id", { count: "exact", head: true });
  if (error) throw error;
  if (!count) {
    const { error: e } = await supabase.rpc("reset_demo_data");
    if (e) throw e;
  }
}

export function useBGs() {
  return useQuery({
    queryKey: ["bgs"],
    queryFn: async (): Promise<BG[]> => {
      await ensureSeeded();
      const { data, error } = await supabase.from("bank_guarantees").select("*").order("expiry_date");
      if (error) throw error;
      return data;
    },
  });
}

export function useReminders() {
  return useQuery({
    queryKey: ["reminders"],
    queryFn: async (): Promise<Reminder[]> => {
      const { data, error } = await supabase.from("reminders").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useAudit() {
  return useQuery({
    queryKey: ["audit"],
    queryFn: async (): Promise<AuditEntry[]> => {
      const { data, error } = await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data;
    },
  });
}

export function useAmendments() {
  return useQuery({
    queryKey: ["amendments"],
    queryFn: async (): Promise<Amendment[]> => {
      const { data, error } = await supabase.from("bg_amendments").select("*").order("amended_on");
      if (error) throw error;
      return data;
    },
  });
}

export async function logAudit(bg_id: string | null, action: string, details: string) {
  const { error } = await supabase.from("audit_log").insert({ bg_id, action, details, performed_by: "Demo User" });
  if (error) throw error;
}

export function useInvalidateAll() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries();
}
