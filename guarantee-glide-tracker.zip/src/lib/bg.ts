import type { Database } from "@/integrations/supabase/types";
import { daysBetween, todayISO } from "./format";

export type BG = Database["public"]["Tables"]["bank_guarantees"]["Row"];
export type BGInsert = Database["public"]["Tables"]["bank_guarantees"]["Insert"];
export type Amendment = Database["public"]["Tables"]["bg_amendments"]["Row"];
export type Reminder = Database["public"]["Tables"]["reminders"]["Row"];
export type AuditEntry = Database["public"]["Tables"]["audit_log"]["Row"];

export const BG_TYPES = ["Performance", "Bid/EMD", "Advance Payment", "Financial", "Retention Money"] as const;
export const BG_STATUSES = ["Active", "Extended", "Invoked", "Release Requested", "Discharged"] as const;
export const MARGIN_TYPES = ["FDR lien", "Cash margin", "Mixed"] as const;
export const BANKS = [
  "State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank",
  "Kotak Mahindra Bank", "Bank of Baroda", "Punjab National Bank", "Canara Bank",
] as const;
export const RECIPIENT_ROLES = ["Internal Team", "Client", "Beneficiary", "Bank"] as const;
export const INTERNAL_EMAIL = "bg-desk@bgtracker.example.com";

export type DisplayStatus =
  | "Active" | "Expiring Soon" | "Overdue Release" | "Expired" | "Extended"
  | "Invoked" | "Release Requested" | "Discharged";

export function isLive(bg: Pick<BG, "status">): boolean {
  return bg.status === "Active" || bg.status === "Extended";
}

export function daysLeft(bg: Pick<BG, "expiry_date">, today = todayISO()): number {
  return daysBetween(today, bg.expiry_date);
}

/** Overdue release: past expiry, original not returned, still open. */
export function isOverdueRelease(bg: BG, today = todayISO()): boolean {
  return isLive(bg) && daysLeft(bg, today) < 0 && !bg.original_returned;
}

export function displayStatus(bg: BG, today = todayISO()): DisplayStatus {
  if (!isLive(bg)) return bg.status as DisplayStatus;
  const d = daysLeft(bg, today);
  if (d < 0) return bg.original_returned ? "Expired" : "Overdue Release";
  if (d <= 30) return "Expiring Soon";
  return bg.status as DisplayStatus;
}

/** Exposure counts BGs that are not discharged. */
export function isExposure(bg: BG): boolean {
  return bg.status !== "Discharged";
}

export function marginBlocked(bg: BG): number {
  return (Number(bg.amount) * Number(bg.margin_percent)) / 100;
}
