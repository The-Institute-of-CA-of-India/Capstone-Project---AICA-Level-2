import { z } from "zod";
import { BANKS, BG_STATUSES, BG_TYPES, MARGIN_TYPES, type BG } from "./bg";
import { addDays, todayISO } from "./format";

const date = z.string().refine((s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s, "Enter a valid date");
const email = z.string().trim().email("Enter a valid email").or(z.literal(""));
export const bgSchema = z.object({
  bg_number: z.string().trim().min(1, "BG number is required"),
  bg_type: z.enum(BG_TYPES), bank_name: z.enum(BANKS), branch: z.string(),
  applicant_name: z.string().trim().min(1, "Applicant is required"),
  beneficiary_name: z.string().trim().min(1, "Beneficiary is required"), contract_ref: z.string(),
  amount: z.number().finite().positive("Amount must be greater than 0"),
  margin_percent: z.number().min(0, "Margin must be 0–100%").max(100, "Margin must be 0–100%"),
  margin_type: z.enum(MARGIN_TYPES), fdr_number: z.string(),
  commission_rate_percent: z.number().finite().min(0, "Commission cannot be negative"),
  next_commission_due: date.or(z.literal("")), issue_date: date, expiry_date: date, claim_expiry_date: date,
  original_returned: z.boolean(), release_letter_received: z.boolean(), status: z.enum(BG_STATUSES),
  applicant_email: email, beneficiary_email: email, bank_email: email, notes: z.string(),
}).superRefine((v, ctx) => {
  if (v.expiry_date <= v.issue_date) ctx.addIssue({ code: "custom", path: ["expiry_date"], message: "Expiry must be after issue date" });
  if (v.claim_expiry_date < v.expiry_date) ctx.addIssue({ code: "custom", path: ["claim_expiry_date"], message: "Claim expiry must be on or after expiry" });
});
export type BGValues = z.infer<typeof bgSchema>;
export function uniqueBGNumber(rows: Pick<BG, "id" | "bg_number">[], number: string, id?: string) {
  return !rows.some((b) => b.id !== id && b.bg_number.trim().toLowerCase() === number.trim().toLowerCase());
}
export function bgDefaults(bg?: BG): BGValues {
  const today = todayISO();
  const initial: BGValues = {
    bg_number: "", bg_type: "Performance", bank_name: BANKS[0], branch: "", applicant_name: "", beneficiary_name: "", contract_ref: "",
    amount: 0, margin_percent: 0, margin_type: "FDR lien", fdr_number: "", commission_rate_percent: 1,
    next_commission_due: "", issue_date: today, expiry_date: addDays(today, 365), claim_expiry_date: addDays(today, 455),
    original_returned: false, release_letter_received: false, status: "Active", applicant_email: "", beneficiary_email: "", bank_email: "", notes: "",
  };
  if (!bg) return initial;
  const values = Object.fromEntries(Object.keys(initial).map((k) => [k, bg[k as keyof BG] ?? ""]));
  return values as BGValues;
}
export function extensionSchema(expiry: string) {
  return z.object({ new_expiry: date, claim_expiry_date: date, new_amount: z.number().finite().positive("Amount must be greater than 0").optional(), remarks: z.string().trim() })
    .superRefine((v, ctx) => {
      if (v.new_expiry <= expiry) ctx.addIssue({ code: "custom", path: ["new_expiry"], message: "New expiry must be after current expiry" });
      if (v.claim_expiry_date < v.new_expiry) ctx.addIssue({ code: "custom", path: ["claim_expiry_date"], message: "Claim expiry must be on or after new expiry" });
    });
}
export type ExtensionValues = z.infer<ReturnType<typeof extensionSchema>>;