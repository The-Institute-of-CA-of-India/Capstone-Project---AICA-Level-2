import { describe, expect, it } from "vitest";
import type { BG } from "./bg";
import { addDays } from "./format";
import { runDailyCheck, rulesFor } from "./reminder-rules";

const T = "2026-11-08";
function bg(p: Partial<BG>): BG {
  return {
    id: "x", bg_number: "BG/1", bg_type: "Performance", bank_name: "Demo Bank", branch: null,
    applicant_name: "A", beneficiary_name: "B", contract_ref: null, amount: 1000000, margin_percent: 10,
    margin_type: "FDR lien", fdr_number: null, commission_rate_percent: 1, next_commission_due: null,
    issue_date: "2025-01-01", expiry_date: addDays(T, 100), claim_expiry_date: addDays(T, 160),
    original_returned: false, release_letter_received: false, status: "Active",
    applicant_email: "a@example.com", beneficiary_email: "b@example.com", bank_email: "k@example.com",
    notes: null, created_at: "", ...p,
  } as BG;
}
const types = (b: BG) => rulesFor(b, T).map((r) => `${r.reminder_type}:${r.recipient_role}`);

describe("reminder rules", () => {
  it("45 days before expiry sends T-60 to internal and client", () => {
    expect(types(bg({ expiry_date: addDays(T, 45) }))).toEqual(["Expiry T-60:Internal Team", "Expiry T-60:Client"]);
  });
  it("7 days before expiry uses T-7", () => {
    expect(types(bg({ expiry_date: addDays(T, 7) }))[0]).toBe("Expiry T-7:Internal Team");
  });
  it("more than 60 days out creates nothing", () => {
    expect(types(bg({ expiry_date: addDays(T, 61) }))).toEqual([]);
  });
  it("on expiry day notifies client", () => {
    expect(types(bg({ expiry_date: T }))).toContain("Expiry day:Client");
  });
  it("after expiry with original not returned writes to beneficiary", () => {
    expect(types(bg({ expiry_date: addDays(T, -5), claim_expiry_date: addDays(T, 40) }))).toEqual(["Beneficiary release request:Beneficiary"]);
  });
  it("release letter received asks bank for cancellation", () => {
    expect(types(bg({ expiry_date: addDays(T, -5), original_returned: true, release_letter_received: true, status: "Release Requested" }))).toEqual(["Bank cancellation request:Bank"]);
  });
  it("claim expiry within 15 days escalates internally", () => {
    expect(types(bg({ expiry_date: addDays(T, -10), claim_expiry_date: addDays(T, 15) }))).toContain("Claim expiry escalation:Internal Team");
    expect(types(bg({ expiry_date: addDays(T, -10), claim_expiry_date: addDays(T, 16) }))).not.toContain("Claim expiry escalation:Internal Team");
  });
  it("discharged BGs get no reminders", () => {
    expect(types(bg({ status: "Discharged", expiry_date: addDays(T, 5) }))).toEqual([]);
  });
  it("daily check does not duplicate existing reminders", () => {
    const b = bg({ expiry_date: addDays(T, 20) });
    const first = runDailyCheck([b], [], T);
    expect(first).toHaveLength(2);
    expect(runDailyCheck([b], first, T)).toHaveLength(0);
  });
});
