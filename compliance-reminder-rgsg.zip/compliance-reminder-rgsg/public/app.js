// RGSG & CO - Compliance Reminder : front-end (plain JavaScript, no build step)
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const pad = (n) => String(n).padStart(2, '0');
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const nice = (s) => { if (!s) return ''; const [y, m, d] = s.slice(0, 10).split('-').map(Number); return `${d} ${MON[m - 1]} ${y}`; };
const days = (s) => Math.round((Date.parse(s + 'T00:00:00Z') - Date.parse(todayStr() + 'T00:00:00Z')) / 86400000);
const STATUSES = ['Pending', 'In Progress', 'Completed', 'NA'];
const IS_MOBILE = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
async function logout() { try { await fetch('/api/logout', { method: 'POST' }); } finally { location.href = '/login.html'; } }

async function api(path, method = 'GET', body) {
  const res = await fetch(path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== '/api/password') { location.href = '/login.html'; throw new Error('Please log in'); }
  if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
  return data;
}
function toast(msg, err = false) {
  const t = $('#toast');
  t.textContent = msg; t.className = 'toast' + (err ? ' err' : '');
  clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.add('hidden'), err ? 6000 : 3000);
}
const fail = (e) => toast(e.message || String(e), true);
function openModal(html) { $('#modalBox').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); $('#modalBox').innerHTML = ''; }
$('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

function dueBadge(t) {
  if (t.status === 'Completed') return `<span class="badge green">Completed</span>`;
  if (t.status === 'NA') return `<span class="badge grey">N/A</span>`;
  const d = days(t.due_date);
  if (d < 0) return `<span class="badge red">Overdue ${-d}d</span>`;
  if (d === 0) return `<span class="badge amber">Due today</span>`;
  if (d <= 7) return `<span class="badge amber">${d}d left</span>`;
  return `<span class="badge grey">${d}d left</span>`;
}
const stageBadge = (s) => `<span class="badge ${s === 'Overdue' ? 'red' : s === 'Due today' ? 'amber' : ''}">${esc(s)}</span>`;
const statusBadge = (s) => `<span class="badge ${s === 'Completed' ? 'green' : s === 'In Progress' ? '' : s === 'NA' ? 'grey' : 'amber'}">${esc(s)}</span>`;

let cache = {};
async function load(key) {
  const urls = { compliances: '/api/compliances', clients: '/api/clients', settings: '/api/settings' };
  cache[key] = await api(urls[key]);
  return cache[key];
}

// ================= sending =================
async function sendFlow(taskId, kind, after) {
  try {
    const d = await api('/api/messages/prepare', 'POST', { task_id: taskId, kind });
    const t = d.task;
    const meta = d.mode === 'meta';
    openModal(`
      <div class="card-h"><h2>${kind === 'completion' ? 'Send completion update' : 'Send reminder'}</h2>${d.stage ? stageBadge(d.stage) : ''}</div>
      <div class="card-b">
        <div class="grid2 field">
          <div><label>To</label><b>${esc(t.contact_person || t.client_name)}</b> <span class="muted">(${esc(t.client_name)})</span></div>
          <div><label>WhatsApp number</label><b>+${esc(d.phone)}</b></div>
        </div>
        <div class="field"><label>Message (you can edit before sending)</label><textarea class="msg" id="msgBody">${esc(d.body)}</textarea></div>
        ${meta
          ? `<div class="note">Mode: <b>WhatsApp Cloud API</b>. The approved Meta template is sent with this task's details; the text above is saved in the log.</div>`
          : `<div class="note">WhatsApp ${d.linkStyle === 'app' || IS_MOBILE ? 'app' : 'Web'} will open with this message ready. Just press <b>Send</b> in WhatsApp.</div>`}
      </div>
      <div class="modal-foot">
        <button onclick="closeModal()">Cancel</button>
        <button id="skipBtn" title="Don't send; remove from today's list">Skip</button>
        <button class="wa" id="goBtn">${meta ? 'Send via WhatsApp API' : 'Open in WhatsApp'}</button>
      </div>`);
    const done = () => { closeModal(); after && after(); };
    $('#skipBtn').onclick = async () => {
      try { await api('/api/messages/log', 'POST', { task_id: taskId, kind, stage: d.stage, body: $('#msgBody').value, status: 'skipped' }); toast('Skipped'); done(); } catch (e) { fail(e); }
    };
    $('#goBtn').onclick = async () => {
      const body = $('#msgBody').value;
      if (meta) {
        $('#goBtn').disabled = true;
        try {
          const r = await api('/api/messages/send', 'POST', { task_id: taskId, kind, body });
          r.ok ? toast('Sent via WhatsApp API') : toast('Failed: ' + r.error, true); done();
        } catch (e) { fail(e); $('#goBtn').disabled = false; }
        return;
      }
      const enc = encodeURIComponent(body);
      // Phones always use the WhatsApp app (WhatsApp Web does not work on mobile browsers).
      const link = d.linkStyle === 'app' || IS_MOBILE ? `https://wa.me/${d.phone}?text=${enc}` : `https://web.whatsapp.com/send?phone=${d.phone}&text=${enc}`;
      if (!IS_MOBILE) window.open(link, 'whatsapp'); // must open before any await (popup blocker)
      try { await api('/api/messages/log', 'POST', { task_id: taskId, kind, stage: d.stage, body }); toast('Opened in WhatsApp and logged'); done(); } catch (e) { fail(e); }
      if (IS_MOBILE) location.href = link; // on phones: log first, then hand over to the WhatsApp app
    };
  } catch (e) { fail(e); }
}

function completeFlow(t, after) {
  openModal(`
    <div class="card-h"><h2>Mark as completed</h2><span class="muted">${esc(t.client_name)} - ${esc(t.title)} ${esc(t.period || '')}</span></div>
    <div class="card-b">
      <div class="grid2">
        <div class="field"><label>Completed / filed on</label><input type="date" id="cDate" value="${todayStr()}"></div>
        <div class="field"><label>ARN / Acknowledgement no. (optional)</label><input id="cArn" value="${esc(t.arn || '')}"></div>
      </div>
      <div class="field"><label>Remarks for client (optional)</label><input id="cRem" value="${esc(t.remarks || '')}" placeholder="e.g. Tax paid Rs. 12,500 via challan"></div>
      <label class="check"><input type="checkbox" id="cSend" checked> Send completion update to client on WhatsApp now</label>
    </div>
    <div class="modal-foot"><button onclick="closeModal()">Cancel</button><button class="primary" id="cSave">Save</button></div>`);
  $('#cSave').onclick = async () => {
    try {
      await api(`/api/tasks/${t.id}`, 'PUT', { status: 'Completed', completed_date: $('#cDate').value, arn: $('#cArn').value, remarks: $('#cRem').value });
      const send = $('#cSend').checked;
      closeModal(); toast('Marked completed');
      if (send) sendFlow(t.id, 'completion', after); else after && after();
    } catch (e) { fail(e); }
  };
}

// ================= pages =================
const pages = {};

pages.dashboard = async (el) => {
  const d = await api('/api/dashboard');
  const s = d.stats;
  const row = (t, extra) => `<tr>
      <td class="nowrap">${nice(t.due_date)}</td>
      <td><b>${esc(t.client_name)}</b><div class="muted">${esc(t.contact_person || '')}</div></td>
      <td>${esc(t.title)}<div class="muted">${esc(t.period || '')}</div></td>
      ${extra(t)}</tr>`;
  const table = (rows, head, emptyMsg) => rows.length
    ? `<div class="tbl-wrap"><table><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
    : `<div class="empty">${emptyMsg}</div>`;
  el.innerHTML = `
    <div class="head"><div><h1>Dashboard</h1><p class="sub">${nice(d.today)} - reminders to send and filings to follow up</p></div>
      <div class="actions"><button onclick="location.hash='#tasks'">All tasks</button></div></div>
    ${d.mode === 'manual' ? `<div class="note">Test mode: <b>click-to-WhatsApp</b>. Click <b>Send</b>, WhatsApp opens with the message typed, you press Send. Switch to the Meta API later in Settings for fully automatic sending.</div>` : ''}
    ${s.noOptIn ? `<div class="note amber">${s.noOptIn} active client(s) have no WhatsApp opt-in and are left out of reminders.</div>` : ''}
    <div class="stats">
      <div class="stat wa"><b>${s.reminders}</b><span>Reminders to send today</span></div>
      <div class="stat green"><b>${s.completions}</b><span>Completion updates to send</span></div>
      <div class="stat red"><b>${s.overdue}</b><span>Overdue tasks</span></div>
      <div class="stat amber"><b>${s.dueSoon}</b><span>Due in next 7 days</span></div>
      <div class="stat"><b>${s.completedThisMonth}</b><span>Completed this month</span></div>
      <div class="stat"><b>${s.clients}</b><span>Active clients</span></div>
    </div>
    <div class="card"><div class="card-h"><h2>Reminders to send today <small>(${d.reminders.length})</small></h2></div>
      ${table(d.reminders.map((t) => row(t, (t) => `<td>${stageBadge(t.stage)}</td><td class="muted">${esc(t.assigned_to || '')}</td>
        <td><div class="actions"><button class="wa sm" data-send="${t.id}">Send</button><button class="sm" data-done="${t.id}">Mark done</button></div></td>`)),
        ['Due', 'Client', 'Compliance', 'Stage', 'Staff', ''], 'No reminders due today.')}</div>
    <div class="card"><div class="card-h"><h2>Completion updates to send <small>(${d.completions.length})</small></h2></div>
      ${table(d.completions.map((t) => row(t, (t) => `<td class="nowrap">${nice(t.completed_date)}</td><td>${esc(t.arn || '-')}</td>
        <td><button class="wa sm" data-csend="${t.id}">Send update</button></td>`)),
        ['Due', 'Client', 'Compliance', 'Completed', 'ARN', ''], 'All completion updates have been sent.')}</div>
    <div class="card"><div class="card-h"><h2>Overdue <small>(${d.overdue.length})</small></h2></div>
      ${table(d.overdue.map((t) => row(t, (t) => `<td>${dueBadge(t)}</td><td>${statusBadge(t.status)}</td>
        <td><button class="sm" data-done="${t.id}">Mark done</button></td>`)), ['Due', 'Client', 'Compliance', '', 'Status', ''], 'Nothing overdue.')}</div>
    <div class="card"><div class="card-h"><h2>Due in next 7 days <small>(${d.dueSoon.length})</small></h2></div>
      ${table(d.dueSoon.map((t) => row(t, (t) => `<td>${dueBadge(t)}</td><td>${statusBadge(t.status)}</td>
        <td><button class="sm" data-done="${t.id}">Mark done</button></td>`)), ['Due', 'Client', 'Compliance', '', 'Status', ''], 'Nothing due in the next 7 days.')}</div>`;
  const all = [...d.reminders, ...d.completions, ...d.overdue, ...d.dueSoon];
  const find = (id) => all.find((t) => t.id === Number(id));
  const refresh = () => route();
  $$('[data-send]', el).forEach((b) => (b.onclick = () => sendFlow(Number(b.dataset.send), 'reminder', refresh)));
  $$('[data-csend]', el).forEach((b) => (b.onclick = () => sendFlow(Number(b.dataset.csend), 'completion', refresh)));
  $$('[data-done]', el).forEach((b) => (b.onclick = () => completeFlow(find(b.dataset.done), refresh)));
};

// ---------- tasks ----------
let taskFilter = { status: 'Open', category: '', client_id: '', from: '', to: '', q: '' };
pages.tasks = async (el) => {
  const [clients, comps] = await Promise.all([load('clients'), load('compliances')]);
  const cats = [...new Set(comps.map((c) => c.category))];
  el.innerHTML = `
    <div class="head"><div><h1>Tasks</h1><p class="sub">Every compliance due for every client. Tasks are created automatically from the Compliance Master.</p></div>
      <div class="actions"><button id="genBtn">Generate tasks</button><button class="primary" id="addBtn">+ Notice / ad-hoc task</button></div></div>
    <div class="card">
      <div class="filters">
        <div><label>Status</label><select id="fStatus">${['Open', ...STATUSES, ''].map((s) => `<option value="${s}" ${taskFilter.status === s ? 'selected' : ''}>${s || 'All'}</option>`).join('')}</select></div>
        <div><label>Category</label><select id="fCat"><option value="">All</option>${cats.map((c) => `<option ${taskFilter.category === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
        <div><label>Client</label><select id="fClient"><option value="">All</option>${clients.map((c) => `<option value="${c.id}" ${String(taskFilter.client_id) === String(c.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
        <div><label>Due from</label><input type="date" id="fFrom" value="${taskFilter.from}"></div>
        <div><label>Due to</label><input type="date" id="fTo" value="${taskFilter.to}"></div>
        <div style="flex:1"><label>Search</label><input id="fQ" placeholder="Client, compliance, period" value="${esc(taskFilter.q)}"></div>
      </div>
      <div id="taskList"><div class="empty">Loading...</div></div>
    </div>`;
  const read = () => {
    taskFilter = { status: $('#fStatus').value, category: $('#fCat').value, client_id: $('#fClient').value, from: $('#fFrom').value, to: $('#fTo').value, q: $('#fQ').value.trim() };
    list();
  };
  ['#fStatus', '#fCat', '#fClient', '#fFrom', '#fTo'].forEach((s) => ($(s).onchange = read));
  $('#fQ').oninput = () => { clearTimeout(read.h); read.h = setTimeout(read, 300); };
  $('#addBtn').onclick = () => taskModal(null, clients, comps, list);
  $('#genBtn').onclick = async () => {
    try { const r = await api('/api/tasks/generate', 'POST', {}); toast(`${r.created} new task(s) created (due ${nice(r.from)} to ${nice(r.to)})`); list(); } catch (e) { fail(e); }
  };
  async function list() {
    const qs = new URLSearchParams(Object.entries(taskFilter).filter(([, v]) => v)).toString();
    const tasks = await api('/api/tasks?' + qs);
    const box = $('#taskList');
    if (!tasks.length) { box.innerHTML = `<div class="empty">No tasks match these filters.</div>`; return; }
    box.innerHTML = `<div class="tbl-wrap"><table><thead><tr><th>Due</th><th>Client</th><th>Compliance</th><th></th><th>Status</th><th>Staff</th><th></th></tr></thead><tbody>
      ${tasks.map((t) => `<tr>
        <td class="nowrap">${nice(t.due_date)}</td>
        <td><b>${esc(t.client_name)}</b></td>
        <td>${esc(t.title)}<div class="muted">${esc(t.period || '')}${t.arn ? ' - ARN ' + esc(t.arn) : ''}</div></td>
        <td>${dueBadge(t)}</td>
        <td><select class="sm" data-status="${t.id}" style="width:auto">${STATUSES.map((s) => `<option ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
        <td class="muted">${esc(t.assigned_to || '')}</td>
        <td><div class="actions">
          ${t.status === 'Completed'
            ? `<button class="sm ${t.completion_sent ? '' : 'wa'}" data-csend="${t.id}">${t.completion_sent ? 'Resend update' : 'Send update'}</button>`
            : `<button class="sm wa" data-send="${t.id}">Remind</button><button class="sm" data-done="${t.id}">Done</button>`}
          <button class="sm" data-edit="${t.id}">Edit</button>
          <button class="sm danger" data-del="${t.id}" title="Delete">✕</button></div></td></tr>`).join('')}
      </tbody></table></div><div class="muted" style="padding:8px 14px">${tasks.length} task(s)</div>`;
    const find = (id) => tasks.find((t) => t.id === Number(id));
    $$('[data-send]', box).forEach((b) => (b.onclick = () => sendFlow(Number(b.dataset.send), 'reminder', list)));
    $$('[data-csend]', box).forEach((b) => (b.onclick = () => sendFlow(Number(b.dataset.csend), 'completion', list)));
    $$('[data-done]', box).forEach((b) => (b.onclick = () => completeFlow(find(b.dataset.done), list)));
    $$('[data-edit]', box).forEach((b) => (b.onclick = () => taskModal(find(b.dataset.edit), clients, comps, list)));
    $$('[data-del]', box).forEach((b) => (b.onclick = async () => {
      if (!confirm('Delete this task? (Recurring tasks may be re-created on next generation - set status "NA" instead to stop them.)')) return;
      try { await api(`/api/tasks/${b.dataset.del}`, 'DELETE'); toast('Deleted'); list(); } catch (e) { fail(e); }
    }));
    $$('[data-status]', box).forEach((s) => (s.onchange = async () => {
      const t = find(s.dataset.status);
      if (s.value === 'Completed') { s.value = t.status; return completeFlow(t, list); }
      try { await api(`/api/tasks/${t.id}`, 'PUT', { status: s.value }); toast('Status updated'); list(); } catch (e) { fail(e); }
    }));
  }
  list().catch(fail);
};

function taskModal(t, clients, comps, after) {
  const isNew = !t;
  const adhoc = comps.filter((c) => c.frequency === 'Ad-hoc');
  openModal(`
    <div class="card-h"><h2>${isNew ? 'Add notice / ad-hoc task' : 'Edit task'}</h2></div>
    <div class="card-b">
      ${isNew ? `<div class="note">Use this for GST / Income Tax notices, assessment hearings, or any one-off work with its own due date.</div>` : ''}
      <div class="grid2">
        <div class="field"><label>Client *</label><select id="tClient" ${isNew ? '' : 'disabled'}>${clients.map((c) => `<option value="${c.id}" ${t?.client_id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
        ${isNew ? `<div class="field"><label>Type</label><select id="tComp">${adhoc.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}<option value="">Other</option></select></div>`
          : `<div class="field"><label>Status</label><select id="tStatus">${STATUSES.map((s) => `<option ${t.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>`}
      </div>
      <div class="field"><label>Title (shown to client) *</label><input id="tTitle" value="${esc(t?.title || '')}" placeholder="e.g. GST Notice Reply - ASMT-10 / Income Tax Hearing u/s 143(2)"></div>
      <div class="grid3">
        <div class="field"><label>Period / AY / FY</label><input id="tPeriod" value="${esc(t?.period || '')}" placeholder="e.g. AY 2024-25"></div>
        <div class="field"><label>Due date *</label><input type="date" id="tDue" value="${t?.due_date || ''}"></div>
        <div class="field"><label>Assigned to</label><input id="tStaff" value="${esc(t?.assigned_to || '')}"></div>
      </div>
      <div class="field"><label>Documents required from client (one per line or separated by ;)</label><textarea id="tNotes" placeholder="Leave blank to use the default list from Compliance Master">${esc(t?.notes || '')}</textarea></div>
      ${!isNew && t.status === 'Completed' ? `<div class="grid2"><div class="field"><label>Completed on</label><input type="date" id="tCDate" value="${t.completed_date || ''}"></div>
        <div class="field"><label>ARN</label><input id="tArn" value="${esc(t.arn || '')}"></div></div>
        <div class="field"><label>Remarks for client</label><input id="tRem" value="${esc(t.remarks || '')}"></div>` : ''}
    </div>
    <div class="modal-foot"><button onclick="closeModal()">Cancel</button><button class="primary" id="tSave">Save</button></div>`);
  if (isNew) {
    const setTitle = () => { const c = adhoc.find((x) => String(x.id) === $('#tComp').value); if (!$('#tTitle').dataset.touched) $('#tTitle').value = c ? c.name : ''; };
    $('#tTitle').oninput = () => ($('#tTitle').dataset.touched = 1);
    $('#tComp').onchange = setTitle; setTitle();
    const setStaff = () => { const c = clients.find((x) => String(x.id) === $('#tClient').value); $('#tStaff').value = c?.assigned_to || ''; };
    $('#tClient').onchange = setStaff; setStaff();
  }
  $('#tSave').onclick = async () => {
    const body = { title: $('#tTitle').value, period: $('#tPeriod').value, due_date: $('#tDue').value, assigned_to: $('#tStaff').value, notes: $('#tNotes').value };
    try {
      if (isNew) await api('/api/tasks', 'POST', { ...body, client_id: Number($('#tClient').value), compliance_id: $('#tComp').value || null });
      else {
        body.status = $('#tStatus').value;
        if ($('#tCDate')) Object.assign(body, { completed_date: $('#tCDate').value, arn: $('#tArn').value, remarks: $('#tRem').value });
        await api(`/api/tasks/${t.id}`, 'PUT', body);
      }
      closeModal(); toast('Saved'); after && after();
    } catch (e) { fail(e); }
  };
}

// ---------- clients ----------
pages.clients = async (el) => {
  const [clients, comps] = await Promise.all([load('clients'), load('compliances')]);
  el.innerHTML = `
    <div class="head"><div><h1>Clients</h1><p class="sub">Client WhatsApp numbers and which compliances apply to each.</p></div>
      <div class="actions"><button id="impBtn">Import CSV</button><button class="primary" id="addBtn">+ Add client</button></div></div>
    <div class="card">${clients.length ? `<div class="tbl-wrap"><table><thead><tr><th>Client</th><th>Contact</th><th>WhatsApp</th><th>GSTIN / PAN</th><th>Compliances</th><th>Open tasks</th><th>Opt-in</th><th></th></tr></thead><tbody>
      ${clients.map((c) => `<tr style="${c.active ? '' : 'opacity:.55'}">
        <td><b>${esc(c.name)}</b><div class="muted">${esc(c.entity_type || '')}${c.active ? '' : ' - inactive'}</div></td>
        <td>${esc(c.contact_person || '')}<div class="muted">${esc(c.assigned_to ? 'Staff: ' + c.assigned_to : '')}</div></td>
        <td class="nowrap">${esc(c.whatsapp)}</td>
        <td class="muted">${esc(c.gstin || '')}<br>${esc(c.pan || '')}</td>
        <td>${c.compliance_ids.length}</td>
        <td>${c.open_tasks}</td>
        <td>${c.opt_in ? '<span class="badge green">Yes</span>' : '<span class="badge red">No</span>'}</td>
        <td><div class="actions"><button class="sm" data-edit="${c.id}">Edit</button><button class="sm" data-tasks="${c.id}">Tasks</button><button class="sm danger" data-del="${c.id}">✕</button></div></td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No clients yet. Click "+ Add client".</div>`}</div>`;
  const refresh = () => route();
  $('#addBtn').onclick = () => clientModal(null, comps, refresh);
  $('#impBtn').onclick = () => importModal(refresh);
  $$('[data-edit]', el).forEach((b) => (b.onclick = () => clientModal(clients.find((c) => c.id === Number(b.dataset.edit)), comps, refresh)));
  $$('[data-tasks]', el).forEach((b) => (b.onclick = () => { taskFilter = { ...taskFilter, client_id: b.dataset.tasks, status: 'Open' }; location.hash = '#tasks'; }));
  $$('[data-del]', el).forEach((b) => (b.onclick = async () => {
    if (!confirm('Delete this client and ALL their tasks and history? (Tip: untick "Active" instead to keep history.)')) return;
    try { await api(`/api/clients/${b.dataset.del}`, 'DELETE'); toast('Client deleted'); refresh(); } catch (e) { fail(e); }
  }));
};

function clientModal(c, comps, after) {
  const has = new Set(c?.compliance_ids || []);
  const groups = {};
  comps.filter((x) => x.frequency !== 'Ad-hoc').forEach((x) => (groups[x.category] ||= []).push(x));
  const f = (id, label, val = '', ph = '') => `<div class="field"><label>${label}</label><input id="${id}" value="${esc(val)}" placeholder="${ph}"></div>`;
  openModal(`
    <div class="card-h"><h2>${c ? 'Edit client' : 'Add client'}</h2></div>
    <div class="card-b">
      <div class="grid2">${f('cName', 'Client / entity name *', c?.name)}${f('cContact', 'Contact person (used in greeting)', c?.contact_person, 'e.g. Mr. Shah')}</div>
      <div class="grid3">${f('cWa', 'WhatsApp number *', c?.whatsapp, '10-digit mobile')}${f('cEmail', 'Email', c?.email)}${f('cStaff', 'Assigned staff', c?.assigned_to)}</div>
      <div class="grid3">${f('cGstin', 'GSTIN', c?.gstin)}${f('cPan', 'PAN', c?.pan)}
        <div class="field"><label>Entity type</label><select id="cType">${['', 'Individual', 'Proprietorship', 'Partnership Firm', 'LLP', 'Private Limited', 'Public Limited', 'Trust / Society', 'HUF', 'Other']
          .map((t) => `<option ${c?.entity_type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div></div>
      <div class="field" style="display:flex;gap:22px;flex-wrap:wrap">
        <label class="check"><input type="checkbox" id="cOpt" ${!c || c.opt_in ? 'checked' : ''}> Client has agreed to receive WhatsApp messages</label>
        <label class="check"><input type="checkbox" id="cActive" ${!c || c.active ? 'checked' : ''}> Active</label>
      </div>
      <label>Applicable compliances</label>
      ${Object.entries(groups).map(([cat, list]) => `<div class="cgroup"><h4>${esc(cat)}</h4><div class="opts">
        ${list.map((x) => `<label class="check"><input type="checkbox" class="cComp" value="${x.id}" ${has.has(x.id) ? 'checked' : ''}> ${esc(x.name)}</label>`).join('')}</div></div>`).join('')}
      <div class="field"><label>Notes</label><input id="cNotes" value="${esc(c?.notes || '')}"></div>
    </div>
    <div class="modal-foot"><button onclick="closeModal()">Cancel</button><button class="primary" id="cSave">Save</button></div>`);
  $('#cSave').onclick = async () => {
    const body = {
      name: $('#cName').value, contact_person: $('#cContact').value, whatsapp: $('#cWa').value, email: $('#cEmail').value,
      assigned_to: $('#cStaff').value, gstin: $('#cGstin').value, pan: $('#cPan').value, entity_type: $('#cType').value,
      opt_in: $('#cOpt').checked, active: $('#cActive').checked, notes: $('#cNotes').value,
      compliance_ids: $$('.cComp').filter((x) => x.checked).map((x) => Number(x.value)),
    };
    try {
      const r = c ? await api(`/api/clients/${c.id}`, 'PUT', body) : await api('/api/clients', 'POST', body);
      closeModal(); toast(`Saved${r.tasksCreated ? ` - ${r.tasksCreated} task(s) created` : ''}`); after && after();
    } catch (e) { fail(e); }
  };
}

function importModal(after) {
  const sample = 'name,contact_person,whatsapp,email,gstin,pan,entity_type,assigned_to,opt_in,compliances\n'
    + 'ABC Traders,Mr. Shah,9876543210,abc@example.com,27AAAAA0000A1Z5,AAAAA0000A,Proprietorship,Staff A,yes,GSTR1_M|GSTR3B_M|TDS_PAY|ADV_TAX|ITR_NA';
  openModal(`
    <div class="card-h"><h2>Import clients from CSV</h2></div>
    <div class="card-b">
      <div class="note">Save your Excel as <b>CSV</b> with these columns. <b>compliances</b> = codes from Compliance Master separated by <b>|</b>
        (e.g. GSTR1_M|GSTR3B_M|TDS_PAY). Only <b>name</b> and <b>whatsapp</b> are required.</div>
      <div class="field"><label>Choose CSV file</label><input type="file" id="iFile" accept=".csv,text/csv"></div>
      <div class="field"><label>...or paste CSV here</label><textarea id="iText" style="min-height:160px;font-family:Consolas,monospace;font-size:12px">${esc(sample)}</textarea></div>
    </div>
    <div class="modal-foot"><button onclick="closeModal()">Cancel</button><button class="primary" id="iGo">Import</button></div>`);
  $('#iFile').onchange = async (e) => { const f = e.target.files[0]; if (f) $('#iText').value = await f.text(); };
  $('#iGo').onclick = async () => {
    try {
      const r = await api('/api/clients/import', 'POST', { csv: $('#iText').value });
      closeModal(); toast(`${r.added} client(s) imported${r.errors.length ? ` - ${r.errors.length} error(s): ${r.errors.join('; ')}` : ''}`, r.errors.length > 0); after && after();
    } catch (e) { fail(e); }
  };
}

// ---------- compliance master ----------
function ruleText(c) {
  const r = JSON.parse(c.rule);
  const ord = (n) => n + (n % 10 === 1 && n !== 11 ? 'st' : n % 10 === 2 && n !== 12 ? 'nd' : n % 10 === 3 && n !== 13 ? 'rd' : 'th');
  const md = (s) => { const [m, d] = s.split('-').map(Number); return `${d} ${MON[m - 1]}`; };
  const ov = r.overrides ? ' (' + Object.entries(r.overrides).map(([m, v]) => `${MON[m - 1]} period: ${md(v)}`).join(', ') + ')' : '';
  if (r.type === 'monthly') return `${ord(r.day)} of next month${r.skipQuarterEnd ? ', except quarter-end months' : ''}${ov}`;
  if (r.type === 'quarterly') return `${ord(r.day)} of month after quarter${ov}`;
  if (r.type === 'fixed') return r.dates.map(md).join(', ') + (r.fy === 'previous' ? ' (for previous FY)' : '');
  return 'Manual due date per notice';
}
pages.compliances = async (el) => {
  const comps = await load('compliances');
  const groups = {};
  comps.forEach((c) => (groups[c.category] ||= []).push(c));
  el.innerHTML = `
    <div class="head"><div><h1>Compliance Master</h1><p class="sub">Due-date rules and the default list of documents requested from clients. Edit if due dates are extended.</p></div></div>
    ${Object.entries(groups).map(([cat, list]) => `<div class="card"><div class="card-h"><h2>${esc(cat)}</h2></div><div class="tbl-wrap"><table>
      <thead><tr><th>Code</th><th>Compliance</th><th>Frequency</th><th>Due date rule</th><th>Documents requested</th><th>Active</th><th></th></tr></thead><tbody>
      ${list.map((c) => `<tr><td class="muted nowrap">${esc(c.code)}</td><td><b>${esc(c.name)}</b></td><td>${esc(c.frequency)}</td>
        <td>${esc(ruleText(c))}</td><td class="muted">${esc(c.docs_required || '')}</td>
        <td>${c.active ? '<span class="badge green">Yes</span>' : '<span class="badge grey">No</span>'}</td>
        <td><button class="sm" data-edit="${c.id}">Edit</button></td></tr>`).join('')}</tbody></table></div></div>`).join('')}`;
  $$('[data-edit]', el).forEach((b) => (b.onclick = () => {
    const c = comps.find((x) => x.id === Number(b.dataset.edit));
    openModal(`
      <div class="card-h"><h2>Edit ${esc(c.code)}</h2></div>
      <div class="card-b">
        <div class="field"><label>Name (shown to client)</label><input id="mName" value="${esc(c.name)}"></div>
        <div class="field"><label>Documents requested (separate with ;)</label><textarea id="mDocs">${esc(c.docs_required || '')}</textarea></div>
        <div class="field"><label>Due date rule (advanced - JSON)</label><textarea id="mRule" style="font-family:Consolas,monospace;font-size:12px;min-height:70px">${esc(c.rule)}</textarea>
          <div class="muted">monthly: {"type":"monthly","day":20} | quarterly: {"type":"quarterly","day":31,"overrides":{"3":"05-31"}} | fixed: {"type":"fixed","dates":["07-31"],"fy":"previous"}.
          Example - due date extended to 15 Dec: change "11-28" to "12-15". Existing tasks keep their date; edit them on the Tasks page.</div></div>
        <label class="check"><input type="checkbox" id="mActive" ${c.active ? 'checked' : ''}> Active</label>
      </div>
      <div class="modal-foot"><button onclick="closeModal()">Cancel</button><button class="primary" id="mSave">Save</button></div>`);
    $('#mSave').onclick = async () => {
      try {
        await api(`/api/compliances/${c.id}`, 'PUT', { name: $('#mName').value, docs_required: $('#mDocs').value, rule: $('#mRule').value, active: $('#mActive').checked });
        closeModal(); toast('Saved'); route();
      } catch (e) { fail(e); }
    };
  }));
};

// ---------- templates ----------
const PLACEHOLDERS = ['contact_person', 'client_name', 'compliance', 'period', 'due_date', 'days_left', 'days_overdue', 'documents', 'firm_name', 'firm_phone', 'staff', 'completed_date', 'arn', 'arn_line', 'remarks_line'];
pages.templates = async (el) => {
  const s = await load('settings');
  const T = [
    ['tpl_reminder_upcoming', 'Reminder - before due date', 'Sent at D-7, D-3, D-1 (as per Settings)'],
    ['tpl_reminder_today', 'Reminder - on due date', 'Sent on the due date'],
    ['tpl_reminder_overdue', 'Reminder - overdue', 'Sent every few days after due date until completed'],
    ['tpl_completion', 'Completion update', 'Sent when a task is marked completed'],
  ];
  const sample = { contact_person: 'Mr. Shah', client_name: 'ABC Traders', compliance: 'GSTR-3B (Monthly)', period: 'Oct 2026', due_date: '20 Nov 2026',
    days_left: 3, days_overdue: 2, documents: '• Purchase invoices & expense bills\n• Confirmation of GST payment', firm_name: s.firm_name, firm_phone: s.firm_phone,
    staff: 'Staff A', completed_date: '18 Nov 2026', arn: 'AA2711260012345', arn_line: 'Acknowledgement / ARN: *AA2711260012345*', remarks_line: '' };
  const render = (tpl) => tpl.replace(/\{(\w+)\}/g, (m, k) => (k in sample ? sample[k] : m)).replace(/\n{3,}/g, '\n\n').trim();
  el.innerHTML = `
    <div class="head"><div><h1>Message Templates</h1><p class="sub">Wording of WhatsApp messages. *text* = bold in WhatsApp. Click a placeholder to insert it.</p></div>
      <div class="actions"><button class="primary" id="tplSave">Save templates</button></div></div>
    <div class="note">${PLACEHOLDERS.map((p) => `<span class="ph" data-ph="${p}">{${p}}</span>`).join('')}</div>
    ${T.map(([k, title, hint]) => `<div class="card"><div class="card-h"><h2>${title} <small>- ${hint}</small></h2></div>
      <div class="card-b grid2"><div><label>Template</label><textarea class="msg tpl" data-k="${k}">${esc(s[k])}</textarea></div>
      <div><label>Preview (sample data)</label><div class="preview" data-prev="${k}"></div></div></div></div>`).join('')}
    <div class="note amber">When you move to the Meta WhatsApp API, the same wording has to be submitted as templates in Meta WhatsApp Manager for approval (with {{1}}, {{2}}... in place of placeholders). See Settings.</div>`;
  let last = null;
  const upd = (ta) => ($(`[data-prev="${ta.dataset.k}"]`).textContent = render(ta.value));
  $$('.tpl', el).forEach((ta) => { upd(ta); ta.oninput = () => upd(ta); ta.onfocus = () => (last = ta); });
  $$('[data-ph]', el).forEach((p) => (p.onclick = () => {
    if (!last) return toast('Click inside a template first');
    const ins = `{${p.dataset.ph}}`; const a = last.selectionStart;
    last.value = last.value.slice(0, a) + ins + last.value.slice(last.selectionEnd); last.focus(); last.selectionStart = last.selectionEnd = a + ins.length; upd(last);
  }));
  $('#tplSave').onclick = async () => {
    const body = {}; $$('.tpl', el).forEach((ta) => (body[ta.dataset.k] = ta.value));
    try { await api('/api/settings', 'PUT', body); toast('Templates saved'); } catch (e) { fail(e); }
  };
};

// ---------- message log ----------
pages.messages = async (el) => {
  const msgs = await api('/api/messages?limit=500');
  el.innerHTML = `
    <div class="head"><div><h1>Message Log</h1><p class="sub">Every reminder and completion update - audit trail of client communication.</p></div></div>
    <div class="card">${msgs.length ? `<div class="tbl-wrap"><table><thead><tr><th>Date / time</th><th>Client</th><th>Task</th><th>Type</th><th>Stage</th><th>Channel</th><th>Status</th><th></th></tr></thead><tbody>
      ${msgs.map((m) => `<tr><td class="nowrap">${nice(m.sent_at)} <span class="muted">${esc(m.sent_at.slice(11, 16))}</span></td>
        <td>${esc(m.client_name || '-')}<div class="muted">+${esc(m.phone || '')}</div></td>
        <td>${esc(m.title || '-')}<div class="muted">${esc(m.period || '')}</div></td>
        <td>${m.type === 'completion' ? '<span class="badge green">Completion</span>' : '<span class="badge">Reminder</span>'}</td>
        <td>${esc(m.stage || '')}</td><td class="muted">${m.channel === 'meta' ? 'Meta API' : 'Click-to-WhatsApp'}</td>
        <td>${m.status === 'failed' ? `<span class="badge red" title="${esc(m.error || '')}">Failed</span>` : m.status === 'skipped' ? '<span class="badge grey">Skipped</span>' : `<span class="badge green">${esc(m.status)}</span>`}</td>
        <td><button class="sm" data-view="${m.id}">View</button></td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">No messages sent yet.</div>`}</div>`;
  $$('[data-view]', el).forEach((b) => (b.onclick = () => {
    const m = msgs.find((x) => x.id === Number(b.dataset.view));
    openModal(`<div class="card-h"><h2>Message to ${esc(m.client_name || '')}</h2></div><div class="card-b"><div class="preview">${esc(m.body || '')}</div>
      ${m.error ? `<p class="muted">Details: ${esc(m.error)}</p>` : ''}</div><div class="modal-foot"><button onclick="closeModal()">Close</button></div>`);
  }));
};

// ---------- settings ----------
pages.settings = async (el) => {
  const [s, net] = await Promise.all([load('settings'), api('/api/network')]);
  const f = (k, label, hint = '', type = 'text') => `<div class="field"><label>${label}</label><input id="s_${k}" type="${type}" value="${esc(s[k])}">${hint ? `<div class="muted">${hint}</div>` : ''}</div>`;
  el.innerHTML = `
    <div class="head"><div><h1>Settings</h1><p class="sub">Firm details, reminder schedule and WhatsApp sending mode.</p></div>
      <div class="actions"><button class="primary" id="sSave">Save settings</button></div></div>
    <div class="card"><div class="card-h"><h2>Open on mobile / other office computers</h2></div><div class="card-b">
      ${net.urls.length ? net.urls.map((u) => `<div style="font-size:18px;margin-bottom:6px"><b>${esc(u.url)}</b> <span class="muted">(${esc(u.name)})</span></div>`).join('')
        : '<div class="note amber">This PC is not connected to a network.</div>'}
      <div class="muted" style="margin-top:8px">Type this address in the phone's browser (Chrome / Safari). The phone must be on the <b>same office Wi-Fi</b> (not mobile data or a guest Wi-Fi),
        and the app must be running on this PC (start.bat window open). Tip: on the phone, use "Add to Home screen" for one-tap access.</div>
    </div></div>
    <div class="card"><div class="card-h"><h2>Change password</h2></div><div class="card-b">
      <div class="grid3">
        <div class="field"><label>Current password</label><input type="password" id="pwCur" autocomplete="current-password"></div>
        <div class="field"><label>New password (min 6 characters)</label><input type="password" id="pwNew" autocomplete="new-password"></div>
        <div class="field"><label>Repeat new password</label><input type="password" id="pwNew2" autocomplete="new-password"></div>
      </div>
      <div class="actions"><button id="pwBtn">Change password</button><span class="muted" style="align-self:center">Other devices will be logged out.</span></div>
    </div></div>
    <div class="card"><div class="card-h"><h2>Firm</h2></div><div class="card-b grid3">
      ${f('firm_name', 'Firm name (used in messages)')}${f('firm_phone', 'Firm contact number', 'Available as {firm_phone} in templates')}${f('country_code', 'Default country code', '91 for India')}</div></div>
    <div class="card"><div class="card-h"><h2>Reminder schedule</h2></div><div class="card-b grid2">
      ${f('reminder_offsets', 'Remind how many days before due date', 'Comma separated. 7,3,1,0 = 7 days before, 3 days before, 1 day before and on the due date')}
      ${f('overdue_every', 'After due date, remind every N days', 'Until the task is marked completed', 'number')}
      ${f('generate_days_ahead', 'Create tasks for the next N days', 'Tasks are generated automatically every day', 'number')}
      ${f('lookback_days', 'Also create tasks that fell due in the last N days', 'For newly added clients', 'number')}</div></div>
    <div class="card"><div class="card-h"><h2>WhatsApp sending</h2></div><div class="card-b">
      <div class="grid3">
        <div class="field"><label>Sending mode</label><select id="s_send_mode">
          <option value="manual" ${s.send_mode === 'manual' ? 'selected' : ''}>Click-to-WhatsApp (testing - you press Send)</option>
          <option value="meta" ${s.send_mode === 'meta' ? 'selected' : ''}>Meta WhatsApp Cloud API (automatic)</option></select></div>
        <div class="field"><label>Click-to-WhatsApp opens</label><select id="s_wa_link_style">
          <option value="web" ${s.wa_link_style === 'web' ? 'selected' : ''}>WhatsApp Web (browser)</option>
          <option value="app" ${s.wa_link_style === 'app' ? 'selected' : ''}>WhatsApp Desktop / phone app (wa.me)</option></select></div>
        ${f('send_hour', 'Automatic sending time (hour, 24h)', 'Meta API mode only - e.g. 9 = 9 AM. The app must be running.', 'number')}
      </div></div></div>
    <div class="card"><div class="card-h"><h2>Meta WhatsApp Cloud API <small>- fill later, when you set it up</small></h2></div><div class="card-b">
      <div class="note">Create templates in Meta WhatsApp Manager (category <b>Utility</b>) with 5 body variables:<br>
        <b>Reminder:</b> {{1}} contact person, {{2}} compliance, {{3}} period, {{4}} due date, {{5}} firm name<br>
        <b>Completion:</b> {{1}} contact person, {{2}} compliance, {{3}} period, {{4}} completed date, {{5}} ARN / reference</div>
      <div class="grid2">${f('meta_token', 'Access token (permanent system-user token)', '', 'password')}${f('meta_phone_number_id', 'Phone number ID')}</div>
      <div class="grid2">${f('meta_tpl_reminder', 'Reminder template name')}${f('meta_tpl_completion', 'Completion template name')}</div>
      <div class="grid2">${f('meta_template_lang', 'Template language code', 'e.g. en, en_US, hi')}${f('meta_api_version', 'Graph API version')}</div>
    </div></div>
    <div class="card"><div class="card-h"><h2>Maintenance</h2></div><div class="card-b actions"><button id="genBtn">Generate tasks now</button></div></div>`;
  $('#genBtn').onclick = async () => { try { const r = await api('/api/tasks/generate', 'POST', {}); toast(`${r.created} new task(s) created`); } catch (e) { fail(e); } };
  $('#pwBtn').onclick = async () => {
    if ($('#pwNew').value !== $('#pwNew2').value) return toast('New passwords do not match', true);
    try {
      await api('/api/password', 'POST', { current: $('#pwCur').value, next: $('#pwNew').value });
      ['#pwCur', '#pwNew', '#pwNew2'].forEach((i) => ($(i).value = '')); toast('Password changed');
    } catch (e) { fail(e); }
  };
  $('#sSave').onclick = async () => {
    const body = {};
    $$('[id^="s_"]', el).forEach((i) => (body[i.id.slice(2)] = i.value.trim()));
    try { await api('/api/settings', 'PUT', body); toast('Settings saved'); updateMode(); } catch (e) { fail(e); }
  };
};

// ================= router =================
async function updateMode() {
  try {
    const s = await load('settings');
    $('#modeBadge').innerHTML = (s.send_mode === 'meta' ? 'Mode: <b>Meta API (auto)</b>' : 'Mode: <b>Click-to-WhatsApp</b> (test)');
  } catch { /* ignore */ }
}
async function route() {
  const page = (location.hash || '#dashboard').slice(1);
  const fn = pages[page] || pages.dashboard;
  $$('#nav a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === '#' + page));
  const el = $('#app');
  try { await fn(el); } catch (e) { el.innerHTML = `<div class="note amber">Could not load: ${esc(e.message)}. Is the server running?</div>`; }
}
window.addEventListener('hashchange', route);
route();
updateMode();
