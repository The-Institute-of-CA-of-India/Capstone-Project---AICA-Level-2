@echo off
title RGSG ^& CO - Compliance Reminder
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download it from https://nodejs.org ^(version 22.13 or later^).
  pause
  exit /b 1
)
echo Starting Compliance Reminder...
start "" http://localhost:3100
node --no-warnings server.js
pause
