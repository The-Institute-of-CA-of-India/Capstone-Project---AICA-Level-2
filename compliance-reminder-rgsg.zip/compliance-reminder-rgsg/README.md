# RGSG & CO – Compliance Reminder (WhatsApp)

Sends compliance reminders to clients on WhatsApp before (and after) due dates, and a completion
update once the work is done.

## Start
Double-click **start.bat** (needs Node.js 22.13 or later; no `npm install` needed).
The app opens at http://localhost:3100. Others on the office network can open
`http://<this-PC-IP>:3100`.

Data is stored in `data/compliance.db` (SQLite). Back up this file.

## Login & mobile
- The app asks for a password on every device (change it in Settings > Change password).
  5 wrong attempts lock that device out for 10 minutes.
- On a phone: connect to the **same office Wi-Fi**, open the address shown in
  Settings > "Open on mobile" (also printed in the start.bat window), e.g. `http://192.168.1.11:3100`.
  On phones the Send button opens the WhatsApp app directly.
- If the PC's address changes after a router restart, check Settings again (or ask your IT person
  to reserve a fixed IP for this PC in the router).

## How it works
1. **Clients** – add each client's WhatsApp number and tick the compliances that apply
   (GST, TDS/TCS, Income Tax, ROC/PF/ESI). Or import from CSV.
2. **Tasks** are created automatically from the **Compliance Master** due-date rules
   (for the next 60 days, refreshed daily). Add GST / Income Tax notices and assessments
   as ad-hoc tasks with their own due date.
3. **Dashboard → Reminders to send today** lists tasks at D-7, D-3, D-1, due date, and
   every 3 days once overdue (configurable in Settings).
4. Click **Send** → WhatsApp opens with the message ready → press Send. It's logged.
5. When filed, click **Done**, enter date / ARN → **completion update** is sent to the client.

## Sending modes
- **Click-to-WhatsApp (current, for testing)** – free, you press Send in WhatsApp Web/app.
- **Meta WhatsApp Cloud API (later)** – fully automatic at the set hour each day. Needs Meta
  Business verification, a dedicated number, and two approved *Utility* templates. Enter the
  token, phone number ID and template names in Settings, then switch the mode.

## Files
- `server.js` – web server + API + daily scheduler
- `lib/rules.js` – due-date rules · `lib/reminders.js` – reminder schedule and message text
- `lib/whatsapp.js` – click-to-chat links and Meta Cloud API sending
- `public/` – the web app
