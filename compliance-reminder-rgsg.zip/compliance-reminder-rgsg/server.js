// RGSG & CO - Compliance Reminder (WhatsApp)
// Zero-dependency Node server: node:http + node:sqlite. Run: node server.js
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, getSettings, saveSettings } from './lib/db.js';
import { todayStr, addDays } from './lib/dates.js';
import { TASK_SELECT, generateTasks, computeQueue, buildMessage, reminderStage } from './lib/reminders.js';
import { normalizePhone, waLink, sendViaMeta } from './lib/whatsapp.js';
import { initAuth } from './lib/auth.js';
import os from 'node:os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3100);
const db = openDb(path.join(__dirname, 'data', 'compliance.db'));
const auth = initAuth(db);

/** This PC's addresses on the office network (for opening the app on mobile). */
function lanUrls() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family === 'IPv4' && !a.internal && !a.address.startsWith('169.254')) out.push({ name, url: `http://${a.address}:${PORT}` });
    }
  }
  return out;
}

// ---------- tiny router ----------
const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler });
}
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (msg) => { throw new HttpError(400, msg); };
const nn = (v) => (v === undefined || v === '' ? null : v);

// ---------- helpers ----------
function getTask(id) {
  const t = db.prepare(`${TASK_SELECT} WHERE t.id = ?`).get(id);
  if (!t) throw new HttpError(404, 'Task not found');
  return t;
}
function logMessage({ task, kind, stage, body, channel, status, error }) {
  const s = getSettings(db);
  db.prepare(`INSERT INTO messages (task_id, client_id, type, stage, phone, body, channel, status, error)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(task.id, task.client_id, kind, nn(stage), normalizePhone(task.whatsapp, s.country_code),
    nn(body), channel, status, nn(error));
  if (kind === 'completion' && status !== 'failed') {
    db.prepare('UPDATE tasks SET completion_sent = 1 WHERE id = ?').run(task.id);
  }
}
async function sendAuto(task, kind, bodyOverride) {
  const s = getSettings(db);
  const { body, vars } = buildMessage(task, kind, s);
  const stage = kind === 'reminder' ? reminderStage(db, task, s)?.stage || 'Manual' : null;
  const phone = normalizePhone(task.whatsapp, s.country_code);
  try {
    const r = await sendViaMeta(s, phone, kind, vars);
    logMessage({ task, kind, stage, body: bodyOverride || body, channel: 'meta', status: 'sent', error: r?.messages?.[0]?.id });
    return { ok: true };
  } catch (e) {
    logMessage({ task, kind, stage, body: bodyOverride || body, channel: 'meta', status: 'failed', error: e.message });
    return { ok: false, error: e.message };
  }
}
function parseCsv(text) {
  const rows = []; let row = []; let cur = ''; let q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"' && text[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') q = false;
      else cur += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cur); rows.push(row); row = []; cur = '';
    } else cur += ch;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim()));
}

// ---------- dashboard ----------
route('GET', '/api/dashboard', () => {
  const s = getSettings(db);
  const today = todayStr();
  const q = computeQueue(db, s, today);
  const overdue = db.prepare(`${TASK_SELECT} WHERE t.status NOT IN ('Completed','NA') AND t.due_date < ? AND c.active=1
    ORDER BY t.due_date`).all(today);
  const dueSoon = db.prepare(`${TASK_SELECT} WHERE t.status NOT IN ('Completed','NA') AND t.due_date BETWEEN ? AND ? AND c.active=1
    ORDER BY t.due_date, c.name`).all(today, addDays(today, 7));
  const month = today.slice(0, 7);
  const stats = {
    reminders: q.reminders.length,
    completions: q.completions.length,
    overdue: overdue.length,
    dueSoon: dueSoon.length,
    completedThisMonth: db.prepare(`SELECT count(*) n FROM tasks WHERE status='Completed' AND substr(completed_date,1,7)=?`).get(month).n,
    clients: db.prepare('SELECT count(*) n FROM clients WHERE active=1').get().n,
    noOptIn: db.prepare('SELECT count(*) n FROM clients WHERE active=1 AND opt_in=0').get().n,
  };
  return { today, mode: s.send_mode, stats, ...q, overdue, dueSoon };
});

// ---------- clients ----------
route('GET', '/api/clients', () => {
  const clients = db.prepare(`SELECT c.*,
      (SELECT group_concat(compliance_id) FROM client_compliances WHERE client_id=c.id) AS cids,
      (SELECT count(*) FROM tasks WHERE client_id=c.id AND status NOT IN ('Completed','NA')) AS open_tasks
    FROM clients c ORDER BY c.active DESC, c.name`).all();
  return clients.map((c) => ({ ...c, compliance_ids: c.cids ? String(c.cids).split(',').map(Number) : [] }));
});
function saveClient(id, b) {
  if (!b.name?.trim()) bad('Client name is required');
  if (String(b.whatsapp || '').replace(/\D/g, '').length < 10) bad('Valid WhatsApp number is required');
  const vals = [b.name.trim(), nn(b.contact_person), String(b.whatsapp).trim(), nn(b.email), nn(b.gstin?.toUpperCase()),
    nn(b.pan?.toUpperCase()), nn(b.entity_type), nn(b.assigned_to), b.opt_in ? 1 : 0, b.active === false || b.active === 0 ? 0 : 1, nn(b.notes)];
  if (id) {
    db.prepare(`UPDATE clients SET name=?, contact_person=?, whatsapp=?, email=?, gstin=?, pan=?, entity_type=?,
      assigned_to=?, opt_in=?, active=?, notes=? WHERE id=?`).run(...vals, id);
  } else {
    id = Number(db.prepare(`INSERT INTO clients (name, contact_person, whatsapp, email, gstin, pan, entity_type,
      assigned_to, opt_in, active, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(...vals).lastInsertRowid);
  }
  if (Array.isArray(b.compliance_ids)) {
    db.prepare('DELETE FROM client_compliances WHERE client_id=?').run(id);
    const ins = db.prepare('INSERT OR IGNORE INTO client_compliances (client_id, compliance_id) VALUES (?,?)');
    b.compliance_ids.forEach((cid) => ins.run(id, Number(cid)));
  }
  const g = generateTasks(db, getSettings(db));
  return { id, tasksCreated: g.created };
}
route('POST', '/api/clients', (_, b) => saveClient(null, b));
route('PUT', '/api/clients/:id', (p, b) => saveClient(Number(p.id), b));
route('DELETE', '/api/clients/:id', (p) => { db.prepare('DELETE FROM clients WHERE id=?').run(Number(p.id)); return { ok: true }; });
route('POST', '/api/clients/import', (_, b) => {
  const rows = parseCsv(String(b.csv || ''));
  if (rows.length < 2) bad('CSV needs a header row and at least one client');
  const head = rows[0].map((h) => h.trim().toLowerCase().replace(/\s+/g, '_'));
  const idx = (k) => head.indexOf(k);
  if (idx('name') < 0 || idx('whatsapp') < 0) bad('CSV must have "name" and "whatsapp" columns');
  const codeToId = Object.fromEntries(db.prepare('SELECT code, id FROM compliances').all().map((r) => [r.code.toUpperCase(), r.id]));
  let added = 0; const errors = [];
  rows.slice(1).forEach((r, i) => {
    const get = (k) => (idx(k) >= 0 ? (r[idx(k)] || '').trim() : '');
    try {
      const codes = get('compliances').split(/[|;]/).map((x) => x.trim().toUpperCase()).filter(Boolean);
      saveClient(null, {
        name: get('name'), contact_person: get('contact_person'), whatsapp: get('whatsapp'), email: get('email'),
        gstin: get('gstin'), pan: get('pan'), entity_type: get('entity_type'), assigned_to: get('assigned_to'),
        opt_in: !/^(n|no|0|false)$/i.test(get('opt_in')), notes: get('notes'),
        compliance_ids: codes.map((c) => codeToId[c]).filter(Boolean),
      });
      added++;
    } catch (e) { errors.push(`Row ${i + 2}: ${e.message}`); }
  });
  return { added, errors };
});

// ---------- compliances ----------
route('GET', '/api/compliances', () => db.prepare('SELECT * FROM compliances ORDER BY sort, id').all());
route('PUT', '/api/compliances/:id', (p, b) => {
  try { JSON.parse(b.rule); } catch { bad('Rule must be valid JSON'); }
  db.prepare('UPDATE compliances SET name=?, docs_required=?, rule=?, active=? WHERE id=?')
    .run(b.name, nn(b.docs_required), b.rule, b.active ? 1 : 0, Number(p.id));
  return { ok: true };
});

// ---------- tasks ----------
route('GET', '/api/tasks', (_, __, query) => {
  const w = ['1=1']; const a = [];
  if (query.status === 'Open') w.push("t.status NOT IN ('Completed','NA')");
  else if (query.status) { w.push('t.status = ?'); a.push(query.status); }
  if (query.client_id) { w.push('t.client_id = ?'); a.push(Number(query.client_id)); }
  if (query.category) { w.push('t.category = ?'); a.push(query.category); }
  if (query.from) { w.push('t.due_date >= ?'); a.push(query.from); }
  if (query.to) { w.push('t.due_date <= ?'); a.push(query.to); }
  if (query.q) { w.push('(c.name LIKE ? OR t.title LIKE ? OR t.period LIKE ?)'); a.push(...Array(3).fill(`%${query.q}%`)); }
  return db.prepare(`${TASK_SELECT} WHERE ${w.join(' AND ')} ORDER BY t.due_date, c.name LIMIT 1000`).all(...a);
});
route('POST', '/api/tasks', (_, b) => {
  if (!b.client_id || !b.title?.trim() || !b.due_date) bad('Client, title and due date are required');
  const co = b.compliance_id ? db.prepare('SELECT * FROM compliances WHERE id=?').get(Number(b.compliance_id)) : null;
  const client = db.prepare('SELECT * FROM clients WHERE id=?').get(Number(b.client_id));
  if (!client) bad('Client not found');
  const r = db.prepare(`INSERT INTO tasks (client_id, compliance_id, title, category, period, period_key, due_date, assigned_to, notes)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(client.id, co?.id ?? null, b.title.trim(), co?.category || 'Other', nn(b.period),
    `manual-${Date.now()}`, b.due_date, nn(b.assigned_to) ?? client.assigned_to, nn(b.notes));
  return { id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/tasks/:id', (p, b) => {
  const t = getTask(Number(p.id));
  const status = b.status ?? t.status;
  let completed = b.completed_date !== undefined ? nn(b.completed_date) : t.completed_date;
  let sent = t.completion_sent;
  if (status === 'Completed' && t.status !== 'Completed') { completed = completed || todayStr(); sent = 0; }
  if (status !== 'Completed') completed = null;
  db.prepare(`UPDATE tasks SET title=?, period=?, due_date=?, status=?, assigned_to=?, notes=?, completed_date=?,
    arn=?, remarks=?, completion_sent=? WHERE id=?`).run(
    b.title ?? t.title, b.period !== undefined ? nn(b.period) : t.period, b.due_date ?? t.due_date, status,
    b.assigned_to !== undefined ? nn(b.assigned_to) : t.assigned_to, b.notes !== undefined ? nn(b.notes) : t.notes,
    completed, b.arn !== undefined ? nn(b.arn) : t.arn, b.remarks !== undefined ? nn(b.remarks) : t.remarks, sent, t.id);
  return getTask(t.id);
});
route('DELETE', '/api/tasks/:id', (p) => { db.prepare('DELETE FROM tasks WHERE id=?').run(Number(p.id)); return { ok: true }; });
route('POST', '/api/tasks/generate', (_, b) => generateTasks(db, getSettings(db), todayStr(), b.days ? Number(b.days) : undefined));

// ---------- messages ----------
route('POST', '/api/messages/prepare', (_, b) => {
  const s = getSettings(db);
  const task = getTask(Number(b.task_id));
  const kind = b.kind === 'completion' ? 'completion' : 'reminder';
  const { body } = buildMessage(task, kind, s);
  const stage = kind === 'reminder' ? reminderStage(db, task, s)?.stage || 'Manual' : null;
  const phone = normalizePhone(task.whatsapp, s.country_code);
  return { task, kind, stage, phone, body, mode: s.send_mode, link: waLink(phone, body, s.wa_link_style), linkStyle: s.wa_link_style };
});
route('POST', '/api/messages/log', (_, b) => {
  const task = getTask(Number(b.task_id));
  const kind = b.kind === 'completion' ? 'completion' : 'reminder';
  logMessage({ task, kind, stage: b.stage, body: b.body, channel: b.channel || 'manual',
    status: b.status === 'skipped' ? 'skipped' : 'opened in WhatsApp' });
  return { ok: true };
});
route('POST', '/api/messages/send', async (_, b) => sendAuto(getTask(Number(b.task_id)), b.kind === 'completion' ? 'completion' : 'reminder', b.body));
route('GET', '/api/messages', (_, __, query) => db.prepare(`SELECT m.*, c.name AS client_name, t.title, t.period
  FROM messages m LEFT JOIN clients c ON c.id=m.client_id LEFT JOIN tasks t ON t.id=m.task_id
  ORDER BY m.id DESC LIMIT ?`).all(Number(query.limit || 300)));

// ---------- settings ----------
route('GET', '/api/settings', () => {
  const { password_hash, ...s } = getSettings(db);
  return { ...s, meta_token: s.meta_token ? '••••••' + s.meta_token.slice(-4) : '' };
});
route('GET', '/api/network', () => ({ port: PORT, urls: lanUrls() }));
route('PUT', '/api/settings', (_, b) => {
  if (b.meta_token && b.meta_token.startsWith('••••••')) delete b.meta_token; // unchanged
  saveSettings(db, b);
  return { ok: true };
});

// ---------- daily scheduler ----------
async function dailyJob() {
  try {
    const s = getSettings(db);
    generateTasks(db, s);
    const today = todayStr();
    if (s.send_mode !== 'meta' || s.last_auto_run === today || new Date().getHours() < Number(s.send_hour || 9)) return;
    saveSettings(db, { last_auto_run: today });
    const q = computeQueue(db, s, today);
    for (const t of q.reminders) await sendAuto(t, 'reminder');
    for (const t of q.completions) await sendAuto(t, 'completion');
    console.log(`[auto] ${today}: sent ${q.reminders.length} reminders, ${q.completions.length} completion updates`);
  } catch (e) { console.error('[auto] failed', e); }
}
setInterval(dailyJob, 15 * 60 * 1000);
dailyJob();

// ---------- http server ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };
const send = (res, status, data) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
};

const PUBLIC_FILES = new Set(['/login.html', '/style.css', '/favicon.ico']);

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/api/')) {
    let body = {};
    if (req.method !== 'GET') {
      let raw = '';
      for await (const chunk of req) { raw += chunk; if (raw.length > 5e6) return send(res, 413, { error: 'Too large' }); }
      try { body = raw ? JSON.parse(raw) : {}; } catch { return send(res, 400, { error: 'Invalid JSON' }); }
    }
    // ---- login / logout (no session needed for login) ----
    if (url.pathname === '/api/login' && req.method === 'POST') { const r = auth.login(req, res, body); return send(res, r.status, r.data); }
    if (url.pathname === '/api/logout' && req.method === 'POST') return send(res, 200, auth.logout(req, res));
    if (!auth.isAuthed(req)) return send(res, 401, { error: 'Please log in' });
    if (url.pathname === '/api/password' && req.method === 'POST') { const r = auth.changePassword(req, res, body); return send(res, r.status, r.data); }

    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) return send(res, 404, { error: 'Not found' });
    const m = url.pathname.match(r.re);
    const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
    try {
      send(res, 200, await r.handler(params, body, Object.fromEntries(url.searchParams)));
    } catch (e) {
      if (!e.status) console.error(e);
      send(res, e.status || 500, { error: e.message });
    }
    return;
  }
  if (!PUBLIC_FILES.has(url.pathname) && !auth.isAuthed(req)) {
    res.writeHead(302, { Location: '/login.html' }); return res.end();
  }
  if (url.pathname === '/login.html' && auth.isAuthed(req)) {
    res.writeHead(302, { Location: '/' }); return res.end();
  }
  const file = path.join(__dirname, 'public', url.pathname === '/' ? 'index.html' : path.normalize(url.pathname));
  if (!file.startsWith(path.join(__dirname, 'public')) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); return res.end('Not found');
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
}).on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error(`\n  Port ${PORT} is already in use - the app is probably already running in another window.\n`);
  else console.error(e);
  process.exit(1);
}).listen(PORT, '0.0.0.0', () => {
  console.log(`\n  RGSG & CO - Compliance Reminder is running`);
  console.log(`  On this PC :  http://localhost:${PORT}`);
  for (const u of lanUrls()) console.log(`  On mobile  :  ${u.url}   (${u.name} - phone must be on the same office Wi-Fi)`);
  console.log(`\n  Keep this window open. Closing it stops the app.\n`);
});
