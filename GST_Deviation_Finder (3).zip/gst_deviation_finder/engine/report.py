"""
Detailed deviation report: PDF (reportlab) and an extra Excel sheet, and saving both to the reports folder
on the computer where the app runs.
"""
from __future__ import annotations

import io
import os
import re
from datetime import date, datetime
from pathlib import Path

import pandas as pd

from . import schema as S

NAVY = "#0B1F3A"
SEV_COL = {"High": "#9B2C20", "Medium": "#9A6A00", "Low": "#1E6B3A"}
SEV_BG = {"High": "#F8E1DE", "Medium": "#FBF0D5", "Low": "#E3F1E8"}


def reports_dir() -> Path:
    d = Path(os.environ.get("GST_REPORTS_DIR") or Path(__file__).resolve().parent.parent / "reports")
    d.mkdir(parents=True, exist_ok=True)
    return d


def inr(p) -> str:
    return "-" if p is None else "Rs " + S.fmt_inr(p)


def read_quality(files: list[dict]) -> dict:
    q = {"Verified": 0, "Read": 0, "Check": 0, "Type it": 0}
    for f in files:
        for st in (f.get("fstatus") or {}).values():
            if st.get("status") in q:
                q[st["status"]] += 1
    return q


# --------------------------------------------------------------------------- PDF
def build_pdf(an: dict, files: list[dict], gstin: str, fy: str, tolerance: float, edits: list[str] | None = None,
              legal_name: str = "") -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                    TableStyle)

    C = colors.HexColor
    ss = getSampleStyleSheet()
    base = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=8.6, leading=11.4, alignment=TA_LEFT)
    small = ParagraphStyle("s", parent=base, fontSize=7.6, leading=9.6, textColor=C("#4A5568"))
    h1 = ParagraphStyle("h1", parent=base, fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=C(NAVY))
    h2 = ParagraphStyle("h2", parent=base, fontName="Helvetica-Bold", fontSize=11.5, leading=15, textColor=C(NAVY), spaceBefore=8, spaceAfter=4, keepWithNext=1)
    h3 = ParagraphStyle("h3", parent=base, fontName="Helvetica-Bold", fontSize=9.4, leading=12, textColor=C(NAVY))
    lab = ParagraphStyle("lab", parent=base, fontName="Helvetica-Bold", fontSize=8, leading=10, textColor=C("#2D3748"), spaceBefore=3)
    cell = ParagraphStyle("c", parent=base, fontSize=7.8, leading=9.6)
    cellb = ParagraphStyle("cb", parent=cell, fontName="Helvetica-Bold")

    def P(t, st=base):
        return Paragraph(_esc(t), st)

    def grid(data, widths, head=True, zebra=True):
        t = Table(data, colWidths=widths, repeatRows=1 if head else 0)
        style = [("GRID", (0, 0), (-1, -1), 0.35, C("#CBD5E0")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                 ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                 ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]
        if head:
            style += [("BACKGROUND", (0, 0), (-1, 0), C(NAVY)), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
        if zebra:
            for r in range(1 if head else 0, len(data)):
                if r % 2 == 0:
                    style.append(("BACKGROUND", (0, r), (-1, r), C("#F7FAFC")))
        t.setStyle(TableStyle(style))
        return t

    def H(t):
        return Paragraph(_esc(t), ParagraphStyle("hh", parent=cellb, textColor=colors.white))

    sm = an["summary"]
    items = an["items"]
    as_of = sm["as_of"]
    story = []
    story.append(P("GST Deviation Report", h1))
    story.append(P(f"GSTR-1 vs GSTR-3B vs GSTR-9 &nbsp;|&nbsp; FY {fy} &nbsp;|&nbsp; GSTIN {gstin or '-'}"
                   + (f" &nbsp;|&nbsp; {legal_name}" if legal_name else ""), ParagraphStyle("sub", parent=base, fontSize=9.5, textColor=C("#4A5568"))))
    story.append(P(f"Prepared {datetime.now():%d-%m-%Y %H:%M} &nbsp;|&nbsp; Interest computed to {as_of:%d-%m-%Y} &nbsp;|&nbsp; "
                   f"Tolerance Rs {tolerance:,.0f}", small))
    story.append(Spacer(1, 8))

    # ---- summary
    story.append(P("1. Summary", h2))
    sev = sm["severity"]
    kp = [[H("Deviations"), H("High"), H("Medium"), H("Low"), H("Monthly short payment"), H("Indicative interest (monthly)")],
          [P(str(sm["count"]), cellb), P(str(sev["High"]), cellb), P(str(sev["Medium"]), cellb), P(str(sev["Low"]), cellb),
           P(inr(sm["monthly_short"]), cellb), P(inr(sm["interest_monthly"]), cellb)]]
    story.append(grid(kp, [24 * mm, 18 * mm, 20 * mm, 18 * mm, 44 * mm, 52 * mm], zebra=False))
    story.append(Spacer(1, 4))
    kp2 = [[H("Added in GSTR-9, not in GSTR-1/3B"), H("Indicative interest on it (minimum)"), H("ITC in 2B not availed (8D)"), H("ITC availed above 2B")],
           [P(inr(sm["gstr9_added"]), cellb), P(inr(sm["interest_gstr9"]), cellb), P(inr(sm["itc_lapse"]), cellb), P(inr(sm["itc_excess"]), cellb)]]
    story.append(grid(kp2, [48 * mm, 46 * mm, 41 * mm, 41 * mm], zebra=False))
    story.append(Spacer(1, 6))
    story.append(P("Key dates", lab))
    dd = [[H("Event"), H("Date"), H("Days from report date")]]
    for n, d, left in sm["dates"]:
        dd.append([P(n, cell), P(f"{d:%d-%m-%Y}", cell), P(f"{left} days left" if left >= 0 else f"passed {-left} days ago", cellb if 0 <= left <= 45 else cell)])
    story.append(grid(dd, [110 * mm, 26 * mm, 40 * mm]))
    if sm.get("turnover_note"):
        story.append(Spacer(1, 3))
        story.append(P(sm["turnover_note"], small))

    # ---- what was read
    story.append(P("2. Returns read and reading quality", h2))
    q = read_quality(files)
    story.append(P(f"Figures: <b>{q['Verified']}</b> verified by two readers or by the return's own arithmetic, <b>{q['Read']}</b> read by one reader, "
                   f"<b>{q['Check']}</b> where the readers differed (table value used - confirm), <b>{q['Type it']}</b> not read (left blank for typing).", base))
    if edits:
        story.append(P("Figures typed or changed by the user before this report: " + "; ".join(edits), small))
    fr = [[H("File"), H("Return"), H("Period"), H("GSTIN"), H("Filed on"), H("Reading")]]
    lab_t = {"GSTR1": "GSTR-1", "GSTR3B": "GSTR-3B", "GSTR9": "GSTR-9"}
    for f in files:
        fo = (f.get("meta") or {}).get("filed_on")
        fr.append([P(f["name"], cell), P(lab_t.get(f.get("type"), "-"), cell),
                   P(S.period_label(f["period"]) if f.get("period") else ("FY " + f["fy"] if f.get("fy") else "-"), cell),
                   P(f.get("gstin") or "-", cell), P(fo.strftime("%d-%m-%Y") if fo else "-", cell), P(f["status"], cell)])
    story.append(grid(fr, [52 * mm, 18 * mm, 18 * mm, 34 * mm, 20 * mm, 34 * mm]))

    # ---- register
    story.append(P("3. Deviation register", h2))
    if not items:
        story.append(P("No deviation above the tolerance was found in the figures read.", base))
    else:
        rg = [[H("#"), H("Severity"), H("Check"), H("Period"), H("Head"), H("A (Rs)"), H("B (Rs)"), H("A - B (Rs)")]]
        for it in items:
            rg.append([P(str(it["no"]), cell), P(f"<font color='{SEV_COL[it['severity']]}'><b>{it['severity']}</b></font>", cell),
                       P(it["check"], cell), P(it["period"], cell), P(it["head"], cell),
                       P(S.fmt_inr(it["a"]), cell), P(S.fmt_inr(it["b"]), cell), P(S.fmt_inr(it["diff"]), cellb)])
        story.append(grid(rg, [8 * mm, 16 * mm, 48 * mm, 15 * mm, 20 * mm, 24 * mm, 24 * mm, 22 * mm]))

    # ---- detailed analysis
    if items:
        story.append(PageBreak())
        story.append(P("4. Detailed analysis of every deviation", h2))
        story.append(P("Severity: High = higher-risk direction and Rs 1 lakh or more (or 10%+); Medium = higher-risk Rs 10,000+, or a large "
                       "lower-risk difference; Low = small, no-tax or timing differences. Interest is indicative - see section 5.", small))
        for it in items:
            blk = []
            hdr = Table([[Paragraph(f"<b>#{it['no']} &nbsp; {_esc(it['check'])} - {_esc(it['head'])}, {_esc(it['period'])}</b>",
                                    ParagraphStyle("x", parent=h3, textColor=C(NAVY))),
                          Paragraph(f"<b>{it['severity']}</b>", ParagraphStyle("y", parent=h3, textColor=C(SEV_COL[it["severity"]]), alignment=2))]],
                        colWidths=[150 * mm, 26 * mm])
            hdr.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), C(SEV_BG[it["severity"]])), ("LEFTPADDING", (0, 0), (-1, -1), 5),
                                     ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
            blk.append(hdr)
            pct = f"{it['pct']:+.2f}%" if it["pct"] is not None else "n/a"
            fig = [[H(it["a_name"]), H(it["b_name"]), H("Difference (A - B)"), H("% of B"), H("Demand risk")],
                   [P(inr(it["a"]), cell), P(inr(it["b"]), cell), P(inr(it["diff"]), cellb), P(pct, cell),
                    P(it["risk"] or "-", cell)]]
            blk.append(Spacer(1, 2))
            blk.append(grid(fig, [42 * mm, 42 * mm, 36 * mm, 22 * mm, 34 * mm], zebra=False))
            sections = [("What it means", [it["meaning"]] if it["meaning"] else []), ("How it links", it["links"]),
                        ("Likely causes", it["causes"]), ("How to verify", it["verify"]), ("Action", it["action"])]
            if it["interest"]:
                sections.append(("Interest estimate (indicative)",
                                 [f"<b>{inr(it['interest']['amount'])}</b> on {inr(it['interest']['principal'])}. {_esc(it['interest']['basis'])}"]))
            sections.append(("Law", [", ".join(it["legal"])] if it["legal"] else []))
            sections.append(("Notes", it["notes"]))
            first = True
            for title, lines in sections:
                if not lines:
                    continue
                para = [Paragraph(f"<b>{title}</b>", lab)]
                for ln in lines:
                    para.append(Paragraph(("&bull; " if len(lines) > 1 else "") + (ln if "<b>" in ln else _esc(ln)), base))
                if first:
                    blk.extend(para)
                    first = False
                else:
                    blk.extend(para)
            blk.append(Spacer(1, 9))
            story.append(KeepTogether(blk[:4]))
            story.extend(blk[4:])

    # ---- method & limits
    story.append(P("5. Method, assumptions and limits", h2))
    for t in [
        "Figures are read only from the filed PDFs (two independent text readers plus a table reader). A figure is used when the readers agree, "
        "or when it sits in a ruled table cell under its column heading, or when the return's own arithmetic proves it (GSTR-3B 4C = 4A - 4B; "
        "GSTR-9 8D = 8A - (8B + 8C)). Watermark characters (rotated, transparent, oversized, light grey, image or vector stamps) are removed first.",
        "Comparisons: GSTR-1 total liability vs GSTR-3B 3.1(a)+(b) each month and for the year; GSTR-9 Table 4N vs GSTR-3B 3.1(a)+(b)+(d) and vs "
        "GSTR-1 + 3.1(d); GSTR-9 6A vs GSTR-3B 4A; GSTR-9 Table 9 payable vs paid; GSTR-9 Table 8D. Annual GSTR-9 checks run only when all 12 "
        "months of the return being compared are present.",
        "Interest: simple interest at 18% p.a. (Sec 50(1), N/N 13/2017-CT; Sec 50(3) for ITC wrongly availed and utilised), counted from the day "
        "after the GSTR-3B due date (20th of the next month, monthly filer) to the report date, assuming the amount is unpaid and paid in cash. "
        "DRC-03 payments, cash-ledger balances and QRMP due dates are not known to the tool. Treat every interest figure as an estimate.",
        "The tool does not see DRC-03 challans, GSTR-1A, IFF, GSTR-2B detail, e-invoice / e-way bill data or books of account; causes listed are "
        "the usual ones and must be confirmed from records. This report is a working paper, not a legal opinion.",
        "Rule 88C (DRC-01B) and Rule 88D (DRC-01C): the trigger thresholds have not been notified; Rs 25 lakh / 20% for DRC-01C is the 50th GST "
        "Council recommendation. GSTR-3B Table 3 auto-populated liability is non-editable from the July 2025 period (GSTN advisory 07-06-2025).",
    ]:
        story.append(P(t, small))
        story.append(Spacer(1, 2))

    bio = io.BytesIO()

    def deco(c, d):
        c.saveState()
        c.setFont("Helvetica", 7)
        c.setFillColor(C("#718096"))
        c.drawString(15 * mm, 9 * mm, f"GST Deviation Report - {gstin or ''} - FY {fy}")
        c.drawRightString(195 * mm, 9 * mm, f"Page {d.page}")
        c.setStrokeColor(C(NAVY))
        c.setLineWidth(1.2)
        c.line(15 * mm, 287 * mm, 195 * mm, 287 * mm)
        c.restoreState()

    doc = SimpleDocTemplate(bio, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=15 * mm,
                            title=f"GST Deviation Report {gstin} FY {fy}", author="GST Deviation Finder")
    doc.build(story, onFirstPage=deco, onLaterPages=deco)
    return bio.getvalue()


def _esc(t: str) -> str:
    t = str(t)
    if "<b>" in t or "&nbsp;" in t or "<font" in t:
        return t
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# --------------------------------------------------------------------------- Excel sheet
def analysis_frame(an: dict) -> pd.DataFrame:
    rows = []
    for it in an["items"]:
        i = it["interest"] or {}
        rows.append({"#": it["no"], "Severity": it["severity"], "Check": it["check"], "Period": it["period"], "Head": it["head"],
                     "A": it["a_name"], "A (Rs)": it["a"] / 100, "B": it["b_name"], "B (Rs)": it["b"] / 100, "A - B (Rs)": it["diff"] / 100,
                     "% of B": round(it["pct"], 2) if it["pct"] is not None else None, "Risk": it["risk"],
                     "What it means": it["meaning"], "How it links": "\n".join(it["links"]),
                     "Likely causes": "\n".join("- " + x for x in it["causes"]), "How to verify": "\n".join("- " + x for x in it["verify"]),
                     "Action": "\n".join("- " + x for x in it["action"]),
                     "Interest est. (Rs)": i.get("amount", 0) / 100 if i else None, "Interest basis": i.get("basis", ""),
                     "Law": ", ".join(it["legal"]), "Notes": "\n".join(it["notes"])})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- saving
def _safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "", s or "") or "NA"


def save(pdf: bytes, xlsx: bytes, gstin: str, fy: str, folder: Path | None = None) -> list[Path]:
    folder = Path(folder) if folder else reports_dir()
    folder.mkdir(parents=True, exist_ok=True)
    stem = f"GST_Deviation_Report_{_safe(gstin)}_FY{_safe(fy)}_{datetime.now():%Y%m%d_%H%M%S}"
    out = []
    for ext, data in ((".pdf", pdf), (".xlsx", xlsx)):
        p = folder / (stem + ext)
        p.write_bytes(data)
        out.append(p)
    return out


def list_saved(folder: Path | None = None) -> list[dict]:
    folder = Path(folder) if folder else reports_dir()
    if not folder.exists():
        return []
    out = []
    for p in sorted(folder.glob("GST_Deviation_Report_*"), key=lambda p: p.stat().st_mtime, reverse=True):
        if p.suffix.lower() in (".pdf", ".xlsx"):
            st = p.stat()
            out.append({"name": p.name, "path": p, "size_kb": round(st.st_size / 1024, 1), "saved": datetime.fromtimestamp(st.st_mtime)})
    return out


def open_folder(folder: Path | None = None) -> bool:
    """Open the reports folder in the file manager of the computer running the app."""
    import subprocess
    import sys

    folder = str(Path(folder) if folder else reports_dir())
    try:
        if sys.platform.startswith("win"):
            os.startfile(folder)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])
        return True
    except Exception:  # noqa: BLE001
        return False
