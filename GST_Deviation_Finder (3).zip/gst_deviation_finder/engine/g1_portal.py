"""
Table-wise reader for the GSTR-1 PDF downloaded from the GST portal (pdfmake layout, 2024-25 onwards).

Layout facts (from a filed GSTR-1, March 2025):
  * Column heading on every page: Description | No. of records | Document Type | Value | Integrated Tax |
    Central Tax | State/UT Tax | Cess.  Amounts are right-aligned, so every amount of one column shares the
    same right edge. Columns that do not apply (e.g. Central/State for B2CL, exports, SEZ) are simply absent.
  * Each table starts with a heading line '4A - ...', '9B - ...', '11A(1), 11A(2) - ...' and its rows follow:
    'Total', '- Nil', 'Amended amount - Total', 'Net differential amount (Amended - Original)', ...
  * The last row of the document is 'Total Liability (Outward supplies other than Reverse charge)'.
    Its Value INCLUDES Table 8 (nil rated / exempted / non-GST); its tax is net of credit notes.
  * Watermark ('FINAL' in very large letters) and the 'IP Address' footer are removed / ignored.

Every amount is placed in its column by its right edge, so a blank column can never shift figures.
"""
from __future__ import annotations

import io
import re

from . import readers as R
from . import schema as S

AMT = re.compile(r"^-?[\d,]+\.\d{2}$")
COLS = ["VALUE", "IGST", "CGST", "SGST", "CESS"]
HEAD_WORDS = {"Value": "VALUE", "Integrated": "IGST", "Central": "CGST", "State/UT": "SGST", "Cess": "CESS"}

# table heading -> (key, short name). Order matters: more specific first.
SECTIONS = [
    (r"^4A\b", "4A", "4A B2B Regular"),
    (r"^4B\b", "4B", "4B B2B Reverse charge"),
    (r"^5\s*[-–]", "5", "5 B2CL (Large)"),
    (r"^6A\b", "6A", "6A Exports"),
    (r"^6B\b", "6B", "6B SEZ"),
    (r"^6C\b", "6C", "6C Deemed exports"),
    (r"^7\s*[-–]", "7", "7 B2CS (Others)"),
    (r"^8\s*[-–]", "8", "8 Nil rated, exempted, non-GST"),
    (r"^9A\b.*B2B Regular", "9A_B2B", "9A Amendment B2B Regular"),
    (r"^9A\b.*Reverse charge", "9A_B2BRC", "9A Amendment B2B Reverse charge"),
    (r"^9A\b.*B2CL", "9A_B2CL", "9A Amendment B2CL"),
    (r"^9A\b.*Deemed", "9A_DE", "9A Amendment Deemed exports"),
    (r"^9A\b.*SEZ", "9A_SEZ", "9A Amendment SEZ"),
    (r"^9A\b.*Export", "9A_EXP", "9A Amendment Exports"),
    (r"^9B\b.*\(Registered\)|^9B\b.*CDNR\b", "9B_CDNR", "9B Credit/Debit notes (Registered)"),
    (r"^9B\b.*Unregistered|^9B\b.*CDNUR", "9B_CDNUR", "9B Credit/Debit notes (Unregistered)"),
    (r"^9C\b.*CDNRA|^9C\b.*\(Registered\)", "9C_CDNRA", "9C Amended CDN (Registered)"),
    (r"^9C\b.*CDNURA|^9C\b.*Unregistered", "9C_CDNURA", "9C Amended CDN (Unregistered)"),
    (r"^10\s*[-–]", "10", "10 Amendment B2C (Others)"),
    (r"^11A\s*\(1\)", "11A", "11A Advances received"),
    (r"^11B\s*\(1\)", "11B", "11B Advances adjusted"),
    (r"^11A\s*[-–]", "11A_AMD", "11A Amendment to advances received"),
    (r"^11B\s*[-–]", "11B_AMD", "11B Amendment to advances adjusted"),
    (r"^12\s*[-–]", "12", "12 HSN summary"),
    (r"^13\s*[-–]", "13", "13 Documents issued"),
    (r"^14A\b", "14A", "14A Amended ECO supplies"),
    (r"^14\s*[-–]", "14", "14 Supplies through ECO"),
    (r"^15A\s*\(I\)", "15A_I", "15A(I) Amended 9(5) - registered"),
    (r"^15A\s*\(II\)", "15A_II", "15A(II) Amended 9(5) - unregistered"),
    (r"^15\s*[-–]", "15", "15 Supplies u/s 9(5)"),
]
TOTAL_LIAB = re.compile(r"^Total Liability\b", re.I)


def _amt(s):
    if AMT.match(s):
        return S.to_paise(s.replace(",", ""))
    return None


def _lines(words, tol=2.5):
    out = []
    for w in sorted(words, key=lambda w: (round(w["top"], 1), w["x0"])):
        if out and abs(out[-1][0]["top"] - w["top"]) <= tol:
            out[-1].append(w)
        else:
            out.append([w])
    for ln in out:
        ln.sort(key=lambda w: w["x0"])
    return out


def _clean_pages(data):
    """(page_index, words) with watermark characters removed (same detection as the other readers)."""
    import copy

    import pdfplumber

    pdfium_pages = copy.deepcopy(R.pdfium_flags(data))
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for pi, page in enumerate(pdf.pages):
            pchars = R._flag_plumber(list(page.chars))
            R._merge_flags(pchars, pdfium_pages[pi] if pi < len(pdfium_pages) else [])
            wm = {id(c) for c in pchars if c["_wm"]}
            clean = page.filter(lambda o: not (o.get("object_type") == "char" and id(o) in wm))
            yield pi, clean.extract_words(x_tolerance=1.5, y_tolerance=2, keep_blank_chars=False), page.width


def _columns(lines, prev=None):
    """Right edges of the five amount columns on this page.
    Accepted only when the amounts form exactly five right-aligned columns AND each sits at the same offset from
    its heading (the portal layout). A page without enough amounts reuses the previous page's columns when its
    headings are at the same positions. Otherwise None - nothing on that page is read (no guessing)."""
    head = None
    for ln in lines:
        keys = [HEAD_WORDS[w["text"]] for w in ln if w["text"] in HEAD_WORDS]
        if len(set(keys)) == 5:
            head = {}
            for i, w in enumerate(ln):
                if w["text"] in HEAD_WORDS:
                    j = i   # the heading phrase: 'Integrated Tax (₹)' - centre of the whole phrase
                    while j + 1 < len(ln) and ln[j + 1]["text"] not in HEAD_WORDS and ln[j + 1]["x0"] - ln[j]["x1"] < 6:
                        j += 1
                    head[HEAD_WORDS[w["text"]]] = (w["x0"] + ln[j]["x1"]) / 2
            break
    if not head:
        return None, None, None
    edges = sorted(w["x1"] for ln in lines for w in ln if _amt(w["text"]) is not None)
    clusters = []
    for e in edges:
        if clusters and e - clusters[-1][-1] <= 3:
            clusters[-1].append(e)
        else:
            clusters.append([e])
    centres = [sum(c) / len(c) for c in clusters if len(c) >= 2]
    if len(centres) == 5:
        shifts = [c - head[k] for c, k in zip(centres, COLS)]
        med = sorted(shifts)[2]
        if all(abs(x - med) <= 8 for x in shifts) and -20 <= med <= 80:
            return dict(zip(COLS, centres)), "exact", head
    if prev and prev[1] and all(abs(head[k] - prev[1][k]) <= 2 for k in COLS):
        return prev[0], "previous page", head
    return None, None, head


def parse(data: bytes) -> dict | None:
    """Returns {"rows": [...], "meta": {...}, "tables": {key: {...}}, "total": {...}} or None if not a portal GSTR-1."""
    pages = list(_clean_pages(data))
    alltext = " ".join(w["text"] for _, ws, _ in pages for w in ws)
    if not re.search(r"FORM\s+GSTR-1\b", alltext) or not re.search(r"Total\s+Liability", alltext):
        return None
    meta = {}
    g = re.search(r"\b(\d{2}[A-Z]{5}\d{4}[A-Z][0-9A-Z]Z[0-9A-Z])\b", alltext)
    if g:
        meta["gstin"] = g.group(1)
    y = re.search(r"Financial\s+year\s*[:\-]?\s*(20\d{2})\s*-\s*(\d{2})", alltext, re.I)
    if y:
        meta["fy"] = f"{y.group(1)}-{y.group(2)}"
    p = re.search(r"Tax\s+period\s*[:\-]?\s*(January|February|March|April|May|June|July|August|September|October|November|December)", alltext, re.I)
    if p:
        meta["month"] = R._MONTHS[p.group(1).lower()]
    a = re.search(r"ARN\s+date\s*[:\-]?\s*(\d{2})/(\d{2})/(\d{4})", alltext, re.I)
    if a:
        from datetime import date

        try:
            meta["filed_on"] = date(int(a.group(3)), int(a.group(2)), int(a.group(1)))
        except ValueError:
            pass
    n = re.search(r"Legal\s+name\s+of\s+the\s+registered\s+person\s+(.+?)\s+\(b\)", alltext, re.I)
    if n:
        meta["legal_name"] = n.group(1).strip()

    rows, section, uncertain_pages = [], None, []
    prev = None
    for pi, words, width in pages:
        lines = _lines(words)
        cols, how, head = _columns(lines, prev)
        if cols:
            prev = (cols, head)
        elif any(_amt(w["text"]) is not None for w in words):
            uncertain_pages.append(pi + 1)
        for ln in lines:
            text = " ".join(w["text"] for w in ln)
            if text in ("Value", "Type") or text.startswith("IP Address") or re.match(r"^(No\.\s+of|Description|records\s+Type)", text):
                continue
            hit = next(((k, nm) for pat, k, nm in SECTIONS if re.search(pat, text)), None)
            nums = [(w, _amt(w["text"])) for w in ln if _amt(w["text"]) is not None]
            if hit and not nums:
                section = {"key": hit[0], "name": hit[1], "heading": text}
                continue
            if TOTAL_LIAB.match(text):
                section = {"key": "TOTAL", "name": "Total Liability (outward supplies other than reverse charge)", "heading": text}
            if not nums:
                # continuation of a wrapped row label
                prev = rows[-1]["label"] if rows else ""
                unfinished = prev.count("(") > prev.count(")") or re.search(r"(-|–|\bNet|\bAmended)$", prev)
                if rows and section and rows[-1]["table"] == section["key"] and not hit and len(text) < 120 and unfinished \
                        and not re.match(r"^(Verification|I hereby|Date:|Signature|Name of|Designation)", text) and ln[0]["top"] - rows[-1]["bottom"] < 14:
                    rows[-1]["label"] += " " + text
                    rows[-1]["bottom"] = max(w["bottom"] for w in ln)
                elif section and section["key"] != "TOTAL" and not hit:
                    section = {**section, "sub": text}
                continue
            if section is None or cols is None:
                continue
            vals = {}
            for w, v in nums:
                k = min(cols, key=lambda c: abs(cols[c] - w["x1"]))
                if abs(cols[k] - w["x1"]) > 12:
                    k = None
                if k:
                    vals[k] = v
            lab_words = [w for w in ln if _amt(w["text"]) is None and w["x1"] < (cols["VALUE"] - 60 if cols else 400)]
            label_txt = " ".join(w["text"] for w in lab_words)
            rec = re.search(r"\s(\d+)\s+(Invoice|Note|Net Value|Document/Net Value|Document/Net|Document|All Documents|NA)\b", " " + label_txt)
            records = int(rec.group(1)) if rec else None
            doc_type = rec.group(2) if rec else ""
            label = label_txt[:rec.start()].strip() if rec else label_txt.strip()
            rows.append({"table": section["key"], "table_name": section["name"], "sub": section.get("sub", ""), "label": label,
                         "records": records, "doc_type": doc_type, **{c: vals.get(c) for c in COLS},
                         "page": pi, "top": min(w["top"] for w in ln), "bottom": max(w["bottom"] for w in ln),
                         "x0": min(w["x0"] for w in ln), "x1": max(w["x1"] for w in ln)})
        # 13 - documents issued has no amounts; keep the count
        for ln in lines:
            text = " ".join(w["text"] for w in ln)
            m = re.match(r"^Net issued documents\s+(\d+)", text)
            if m:
                meta["docs_issued"] = int(m.group(1))
    tables = _summarise(rows)
    return {"rows": rows, "meta": meta, "tables": tables, "uncertain_pages": uncertain_pages}


def _first(rows, table, pat):
    for r in rows:
        if r["table"] == table and re.search(pat, r["label"], re.I):
            return r
    return None


def _summarise(rows):
    """Headline figure of every table: its Total row (or the net differential row for amendments)."""
    out = {}
    pick = {
        "9A_B2B": r"^Net differential", "9A_B2BRC": r"^Net differential", "9A_B2CL": r"^Net differential",
        "9A_EXP": r"^Net differential", "9A_SEZ": r"^Net differential", "9A_DE": r"^Net differential",
        "9B_CDNR": r"^Total", "9B_CDNUR": r"^Total", "9C_CDNRA": r"^Net Differential", "9C_CDNURA": r"^Net Differential",
        "10": r"^Net differential", "11A_AMD": r"^Total$", "11B_AMD": r"^Total$", "14A": r"^Net differential",
        "15A_I": r"^Net differential", "15A_II": r"^Net differential", "TOTAL": r"^Total Liability",
    }
    for key in dict.fromkeys(r["table"] for r in rows):
        r = _first(rows, key, pick.get(key, r"^Total"))
        if r is None:
            r = next(x for x in rows if x["table"] == key)
        out[key] = r
    # Table 8 parts
    for part in ("Nil", "Exempted", "Non-GST"):
        r = _first(rows, "8", rf"^-?\s*{part}$")
        if r:
            out[f"8_{part.upper().replace('-', '')}"] = r
    # export / SEZ split: with payment of tax (GSTR-9 Table 4) and without (Table 5)
    for tab, subs in (("6A", ("EXPWP", "EXPWOP")), ("6B", ("SEZWP", "SEZWOP"))):
        for sub in subs:
            r = _first(rows, tab, rf"^-?\s*{sub}$")
            if r:
                out[f"{tab}_{sub}"] = r
    return out


# --------------------------------------------------------------------------- figures for the comparison
SIGNS = {  # how each table enters the portal's 'Total Liability (other than reverse charge)'
    "4A": 1, "5": 1, "6A": 1, "6B": 1, "6C": 1, "7": 1, "8": 1,
    "9A_B2B": 1, "9A_B2CL": 1, "9A_EXP": 1, "9A_SEZ": 1, "9A_DE": 1,
    "9B_CDNR": 1, "9B_CDNUR": 1, "9C_CDNRA": 1, "9C_CDNURA": 1, "10": 1,
    "11A": 1, "11B": -1, "11A_AMD": 1, "11B_AMD": -1,
}


def figures(res: dict) -> tuple[dict, dict, list[str]]:
    """Field codes for the comparison (paise), a status per code, and notes.
    G1_TXVAL = Total Liability value minus Table 8 (the portal's total includes nil/exempt/non-GST)."""
    t = res["tables"]
    fields, status, notes = {}, {}, []
    tot = t.get("TOTAL")
    if not tot:
        return fields, status, ["'Total Liability' line not found."]
    ev = {"page": tot["page"], "bbox": (tot["x0"], tot["top"], tot["x1"], tot["bottom"]), "label": "Total Liability", "source": "portal-layout"}
    # arithmetic proof: sum of the tables = printed Total Liability, per head
    proved = {}
    for c in COLS:
        if tot.get(c) is None:
            continue
        s = sum(SIGNS[k] * (t[k].get(c) or 0) for k in SIGNS if k in t)
        proved[c] = (s == tot[c])
    for c, code in (("IGST", "G1_IGST"), ("CGST", "G1_CGST"), ("SGST", "G1_SGST"), ("CESS", "G1_CESS")):
        if tot.get(c) is not None:
            fields[code] = tot[c]
            status[code] = {"status": "Verified" if proved.get(c) else "Read",
                            "note": ("Total Liability equals the sum of the tables (4 to 11)." if proved.get(c)
                                     else "Read from the Total Liability line; the table-wise sum differs - see the GSTR-1 table-wise view."),
                            "ev": ev}
    nil = t.get("8")
    if tot.get("VALUE") is not None:
        nilv = (nil or {}).get("VALUE") or 0
        fields["G1_TXVAL"] = tot["VALUE"] - nilv
        fields["G1_NIL"] = nilv
        fields["G1_TOTVAL"] = tot["VALUE"]
        ok = proved.get("VALUE")
        st = {"status": "Verified" if ok and nil else ("Read" if nil else "Check"),
              "note": (f"Total Liability value {S.fmt_inr(tot['VALUE'])} less Table 8 nil/exempt/non-GST {S.fmt_inr(nilv)}."
                       + ("" if nil else " Table 8 was not found - confirm there were no nil/exempt supplies.")), "ev": ev}
        status["G1_TXVAL"] = st
        status["G1_NIL"] = {"status": "Verified" if nil else "Check", "note": "GSTR-1 Table 8 total.",
                            "ev": {"page": nil["page"], "bbox": (nil["x0"], nil["top"], nil["x1"], nil["bottom"]), "label": "Table 8",
                                   "source": "portal-layout"} if nil else ev}
    hsn = t.get("12")
    if hsn:
        for c, code in (("VALUE", "G1_HSN_VALUE"), ("IGST", "G1_HSN_IGST"), ("CGST", "G1_HSN_CGST"), ("SGST", "G1_HSN_SGST"), ("CESS", "G1_HSN_CESS")):
            if hsn.get(c) is not None:
                fields[code] = hsn[c]
                status[code] = {"status": "Read", "note": "GSTR-1 Table 12 HSN summary total.",
                                "ev": {"page": hsn["page"], "bbox": (hsn["x0"], hsn["top"], hsn["x1"], hsn["bottom"]), "label": "Table 12",
                                       "source": "portal-layout"}}
    if res.get("uncertain_pages"):
        notes.append(f"Page(s) {res['uncertain_pages']} not in the portal column layout - their tables were not read.")
    return fields, status, notes


def table_frame(res: dict):
    """Every row read, for display and export (rupees)."""
    import pandas as pd

    out = []
    for r in res["rows"]:
        out.append({"Table": r["table_name"], "Part": r["sub"], "Row": r["label"], "Records": r["records"], "Type": r["doc_type"],
                    **{n: (None if r[c] is None else r[c] / 100) for c, n in zip(COLS, ["Value", "IGST", "CGST", "SGST/UTGST", "Cess"])},
                    "Page": r["page"] + 1})
    return pd.DataFrame(out)


ORDER = [k for _, k, _ in SECTIONS] + ["8_NIL", "8_EXEMPTED", "8_NONGST", "TOTAL"]


def year_tables(files: list[dict], fy: str):
    """(month-wise headline row of every table, year total per table) for all GSTR-1 read table-wise. Rupees."""
    import pandas as pd

    months = S.fy_months(fy)
    long = []
    for f in files:
        if f.get("type") != "GSTR1" or not f.get("g1_rows") or f.get("period") not in months:
            continue
        summ = _summarise(f["g1_rows"])
        for key, r in summ.items():
            name = r["table_name"] if not key.startswith("8_") else "8 - " + key[2:].title().replace("Nongst", "Non-GST")
            long.append({"_o": ORDER.index(key) if key in ORDER else 99, "Table": name, "Row": r["label"], "Month": S.period_label(f["period"]),
                         "_m": months.index(f["period"]), "Records": r["records"],
                         **{n: (None if r[c] is None else r[c] / 100) for c, n in zip(COLS, ["Value", "IGST", "CGST", "SGST/UTGST", "Cess"])}})
    if not long:
        return pd.DataFrame(), pd.DataFrame()
    df = pd.DataFrame(long).sort_values(["_o", "_m"])
    year = (df.groupby(["_o", "Table"], sort=True)[["Records", "Value", "IGST", "CGST", "SGST/UTGST", "Cess"]]
            .sum(min_count=1).reset_index().drop(columns="_o"))
    year.insert(1, "Months", df.groupby(["_o", "Table"], sort=True)["Month"].nunique().values)
    return df.drop(columns=["_o", "_m"]).reset_index(drop=True), year
