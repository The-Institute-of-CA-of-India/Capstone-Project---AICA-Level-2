"""
Field definitions for every input the app accepts.

Every number is stored internally as integer paise. Each form is a list of
fields; each field has a stable code (used by the rules engine), a label
(shown to users and in the Excel template) and the portal reference it
comes from, so a user always knows where to copy a figure from.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

TEMPLATE_VERSION = "1.0"
APP_VERSION = "1.5.0"
RULEBOOK_VERSION = "2026.10"

HEADS = ["IGST", "CGST", "SGST", "CESS"]
HEAD_LABEL = {"IGST": "IGST", "CGST": "CGST", "SGST": "SGST/UTGST", "CESS": "Cess"}


@dataclass(frozen=True)
class Field:
    code: str
    label: str
    ref: str  # where the figure is found on the portal / in books


def _heads(prefix: str, label: str, ref: str) -> list[Field]:
    return [Field(f"{prefix}_{h}", f"{label} - {HEAD_LABEL[h]}", ref) for h in HEADS]


# ---------------------------------------------------------------------------
# BOOKS - kept deliberately small: 11 monthly figures read straight off the
# GST ledgers / sales and purchase register totals. No invoice-level data.
# ---------------------------------------------------------------------------
BOOKS_FIELDS: list[Field] = (
    [Field("BK_OUT_TXVAL", "Taxable sales value", "Sales register total / Sales ledger (net of credit notes)")]
    + _heads("BK_OUT", "Output tax", "Output GST ledger credits for the month")
    + [Field("BK_EXEMPT", "Exempt, nil-rated & non-GST sales", "Sales register - exempt/nil/non-GST columns")]
    + _heads("BK_ITC", "ITC booked", "Input GST ledger debits for the month (net of reversals)")
    + [Field("BK_RCM_TAX", "RCM tax payable (all heads)", "RCM payable ledger credits for the month")]
)

BOOKS_ANNUAL_FIELDS: list[Field] = [
    Field("BK_AFS_TURNOVER", "Turnover as per audited financial statements", "Audited P&L - revenue from operations (GSTIN share)"),
]

# ---------------------------------------------------------------------------
# RETURNS - monthly
# ---------------------------------------------------------------------------
GSTR1_FIELDS: list[Field] = (
    [Field("G1_TXVAL", "Taxable value (net of amendments, incl. GSTR-1A)", "GSTR-1 summary: total taxable value")]
    + _heads("G1", "Tax", "GSTR-1 summary: total liability (incl. 1A, net of CN/DN and amendments)")
)

GSTR3B_FIELDS: list[Field] = (
    [Field("G3B_OUT_TXVAL", "3.1(a)+(b) Taxable value", "GSTR-3B Table 3.1 (a) + (b)")]
    + _heads("G3B_OUT", "3.1(a)+(b) Tax", "GSTR-3B Table 3.1 (a) + (b)")
    + [Field("G3B_EXEMPT", "3.1(c)+(e) Nil/exempt/non-GST value", "GSTR-3B Table 3.1 (c) + (e)")]
    + _heads("G3B_RCM", "3.1(d) RCM tax", "GSTR-3B Table 3.1 (d)")
    + _heads("G3B_ITC_AVL", "4A ITC available", "GSTR-3B Table 4A (1) to (5) total")
    + _heads("G3B_ITC_REV", "4B ITC reversed", "GSTR-3B Table 4B (1) + (2)")
    + [
        Field("G3B_PAID_CASH", "Tax paid in cash (all heads)", "GSTR-3B Table 6.1 - paid in cash"),
        Field("G3B_PAID_ITC", "Tax paid through ITC (all heads)", "GSTR-3B Table 6.1 - paid through ITC"),
    ]
)

GSTR2B_FIELDS: list[Field] = _heads("G2B_ITC", "ITC available", "GSTR-2B summary: ITC available (Part A + B, after IMS action)")

# ---------------------------------------------------------------------------
# GSTR-9 (annual) - same rows for System-computed and Filed versions
# ---------------------------------------------------------------------------
GSTR9_ROWS: list[tuple[str, str]] = [
    ("4N", "Table 4N - Supplies on which tax is payable (total)"),
    ("5N", "Table 5N - Total turnover (incl. advances)"),
    ("6A", "Table 6A - ITC availed as per GSTR-3B"),
    ("7I", "Table 7I - Total ITC reversed"),
    ("8A", "Table 8A - ITC as per GSTR-2B"),
    ("8B", "Table 8B - ITC as per 6B (and 6H where applicable)"),
    ("8C", "Table 8C - ITC of this FY availed in next FY"),
    ("8D", "Table 8D - Difference [8A - (8B + 8C)]"),
    ("9P", "Table 9 - Tax payable"),
    ("9D", "Table 9 - Tax paid (cash + ITC)"),
    ("10", "Table 10 - Supplies added via amendments (next FY)"),
    ("11", "Table 11 - Supplies reduced via amendments (next FY)"),
]
GSTR9_COLS = ["TXVAL"] + HEADS  # taxable value + 4 heads


def gstr9_fields(version: str) -> list[Field]:
    """version: 'SYS' (system computed) or 'FILED'."""
    out = []
    for row, desc in GSTR9_ROWS:
        for col in GSTR9_COLS:
            lab = "Value" if col == "TXVAL" else HEAD_LABEL[col]
            out.append(Field(f"G9{version}_{row}_{col}", f"{desc} - {lab}", desc))
    return out


FORMS = {
    "BOOKS": ("Books of accounts", BOOKS_FIELDS),
    "GSTR1": ("GSTR-1 / 1A", GSTR1_FIELDS),
    "GSTR3B": ("GSTR-3B", GSTR3B_FIELDS),
    "GSTR2B": ("GSTR-2B", GSTR2B_FIELDS),
}
ANNUAL_FORMS = {
    "BOOKS_ANNUAL": ("Books - annual", BOOKS_ANNUAL_FIELDS),
    "GSTR9_SYS": ("GSTR-9 system computed", gstr9_fields("SYS")),
    "GSTR9_FILED": ("GSTR-9 as filed", gstr9_fields("FILED")),
}

TIER_LABEL = {1: "Portal JSON/Excel", 2: "MIS template / grid", 3: "PDF (reviewed)"}

MONTH_NAMES = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]


def fy_months(fy: str) -> list[str]:
    """'2025-26' -> ['2025-04', ..., '2026-03']"""
    start = int(fy[:4])
    out = []
    for i in range(12):
        m = 4 + i
        y = start + (m - 1) // 12
        m = (m - 1) % 12 + 1
        out.append(f"{y}-{m:02d}")
    return out


def period_label(period: str) -> str:
    y, m = period.split("-")
    return f"{MONTH_NAMES[(int(m) - 4) % 12]}-{y[2:]}"


def period_end(period: str) -> date:
    y, m = map(int, period.split("-"))
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return date.fromordinal(nxt.toordinal() - 1)


def due_3b(period: str) -> date:
    """20th of the following month (monthly filer)."""
    y, m = map(int, period.split("-"))
    return date(y + (m == 12), m % 12 + 1, 20)


def fy_list() -> list[str]:
    return ["2023-24", "2024-25", "2025-26", "2026-27"]


def fy_end(fy: str) -> date:
    return date(int(fy[:4]) + 1, 3, 31)


def itc_deadline(fy: str) -> date:
    """Sec 16(4): 30 Nov following the FY (or GSTR-9 filing date, if earlier)."""
    return date(int(fy[:4]) + 1, 11, 30)


def annual_return_due(fy: str) -> date:
    return date(int(fy[:4]) + 1, 12, 31)


def all_monthly_fields() -> dict[str, Field]:
    return {f.code: f for _, (_, fl) in FORMS.items() for f in fl}


def all_annual_fields() -> dict[str, Field]:
    return {f.code: f for _, (_, fl) in ANNUAL_FORMS.items() for f in fl}


# -------------------------- money helpers ----------------------------------
def to_paise(x) -> int | None:
    if x is None:
        return None
    if isinstance(x, str):
        s = x.strip().replace(",", "").replace("₹", "")
        if s in ("", "-", "—"):
            return None
        if s.startswith("(") and s.endswith(")"):
            s = "-" + s[1:-1]
        x = float(s)
    try:
        import math

        if isinstance(x, float) and math.isnan(x):
            return None
    except Exception:
        pass
    # round half away from zero at paise level
    v = float(x) * 100
    return int(v + 0.5) if v >= 0 else -int(-v + 0.5)


def rupees(p: int | None) -> float:
    return 0.0 if p is None else p / 100.0


def fmt_inr(p: int | float | None, paise: bool = True, lakh: bool = False) -> str:
    """Indian digit grouping. p in paise when paise=True."""
    if p is None:
        return "-"
    v = p / 100 if paise else float(p)
    if lakh:
        return f"{v / 1e5:,.2f} L"
    neg = v < 0
    v = abs(round(v))
    s = str(int(v))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if neg else "") + s


# -------------------------- GSTIN ------------------------------------------
_GSTIN_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def gstin_checksum_ok(gstin: str) -> bool:
    g = (gstin or "").strip().upper()
    if len(g) != 15 or any(c not in _GSTIN_CHARS for c in g):
        return False
    total = 0
    for i, c in enumerate(g[:14]):
        prod = _GSTIN_CHARS.index(c) * (2 if i % 2 else 1)
        total += prod // 36 + prod % 36
    check = (36 - total % 36) % 36
    return _GSTIN_CHARS[check] == g[14]


_GSTIN_SHAPE = __import__("re").compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][0-9A-Z]Z[0-9A-Z]$")


def clean_gstin(text: str) -> str:
    """Upper-case and drop spaces, dashes and dots that come in with copy-paste."""
    return "".join(ch for ch in (text or "").upper() if ch.isalnum())


def gstin_problem(gstin: str) -> str | None:
    """None if the GSTIN is valid, else a plain-English explanation of what is wrong."""
    g = clean_gstin(gstin)
    if not g:
        return "Enter the GSTIN."
    if len(g) != 15:
        return f"A GSTIN has 15 characters; this one has {len(g)}."
    if not _GSTIN_SHAPE.match(g):
        return ("The pattern does not look like a GSTIN: 2-digit state code, 10-character PAN (5 letters, 4 digits, 1 letter), "
                "entity number, the letter Z, check character.")
    if not gstin_checksum_ok(g):
        right = gstin_with_checksum(g[:14])[-1]
        return (f"The last character (check character) should be '{right}', not '{g[14]}'. "
                "One of the 15 characters is probably mistyped - compare with the registration certificate.")
    return None


def gstin_with_checksum(first14: str) -> str:
    g = first14.upper()
    total = 0
    for i, c in enumerate(g[:14]):
        prod = _GSTIN_CHARS.index(c) * (2 if i % 2 else 1)
        total += prod // 36 + prod % 36
    return g + _GSTIN_CHARS[(36 - total % 36) % 36]
