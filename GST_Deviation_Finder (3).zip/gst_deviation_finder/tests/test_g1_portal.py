"""GSTR-1 portal layout: table-wise reading, with and without extra watermarks.
The real filed GSTR-1 (tests/fixtures/real_gstr1.pdf) is used when present; it is client data and is not shipped."""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from engine import finder as Fd  # noqa: E402
from engine import g1_portal as G  # noqa: E402
from engine import readers as R  # noqa: E402
import g1_portal_pdfs as GP  # noqa: E402
import stamp as ST  # noqa: E402

REAL = os.path.join(os.path.dirname(__file__), "fixtures", "real_gstr1.pdf")
KINDS = ["none", "diagonal", "transparent", "tiled", "big", "all"]


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
@pytest.mark.parametrize("kind", KINDS)
def test_replica_every_table(seed, kind):
    pdf, exp = GP.gstr1(seed=seed)
    if kind != "none":
        R._CACHE.clear()
        pdf = ST.stamp(pdf, kind)
    r = G.parse(pdf)
    assert r and not r["uncertain_pages"]
    for k, v in exp["tables"].items():
        got = r["tables"][k]
        assert {c: got[c] for c in G.COLS} == v, k
    f, st, _ = G.figures(r)
    for k, v in exp["fields"].items():
        assert f[k] == v, k
    assert all(st[k]["status"] == "Verified" for k in ("G1_IGST", "G1_CGST", "G1_SGST", "G1_TXVAL"))
    rec = Fd.read_pdf(pdf, "x.pdf")
    assert rec["type"] == "GSTR1" and rec["period"] == "2025-03" and rec["fy"] == "2024-25"


def test_non_portal_layout_falls_back():
    import make_year as Y
    assert G.parse(Y.g1(0)[0]) is None or "TOTAL" not in G.parse(Y.g1(0)[0])["tables"]


@pytest.mark.skipif(not os.path.exists(REAL), reason="real GSTR-1 fixture not present")
@pytest.mark.parametrize("kind", KINDS)
def test_real_gstr1(kind):
    data = open(REAL, "rb").read()
    if kind != "none":
        R._CACHE.clear()
        data = ST.stamp(data, kind)
    f = Fd.read_pdf(data, "real.pdf")
    assert f["type"] == "GSTR1" and f["period"] == "2025-03" and f["fy"] == "2024-25"
    assert f["fields"]["G1_TOTVAL"] == 5_63_47_229_26
    assert f["fields"]["G1_NIL"] == 4_89_76_248_70
    assert f["fields"]["G1_TXVAL"] == 73_70_980_56            # 80,18,404.00 - 6,47,423.44
    assert (f["fields"]["G1_IGST"], f["fields"]["G1_CGST"], f["fields"]["G1_SGST"]) == (1_36_007_70, 1_16_270_69, 1_16_270_69)
    assert all(f["fstatus"][k]["status"] == "Verified" for k in ("G1_IGST", "G1_CGST", "G1_SGST", "G1_CESS", "G1_TXVAL"))
    t = {r["table"]: r for r in f["g1_rows"] if r["label"].startswith("Total")}
    assert t["4A"]["VALUE"] == 80_18_404_00 and t["4A"]["records"] == 10
    assert t["9B_CDNR"]["CGST"] == -16_163_28
    assert t["12"]["IGST"] == 1_36_007_70
