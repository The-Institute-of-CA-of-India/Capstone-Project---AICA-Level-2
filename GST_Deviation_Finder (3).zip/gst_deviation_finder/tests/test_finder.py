"""Run:  python -m pytest -q"""
import io
import os
import sys

import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from engine import finder as Fd  # noqa: E402
import make_year as Y  # noqa: E402


@pytest.fixture(scope="module")
def year():
    files = []
    for i, m in enumerate(Y.MONTHS):
        files.append(Fd.read_pdf(Y.g1(i)[0], f"GSTR1_{m}.pdf"))
        files.append(Fd.read_pdf(Y.b3(i, watermark=(i % 2 == 0))[0], f"GSTR3B_{m}.pdf"))
    files.append(Fd.read_pdf(Y.g9()[0], "GSTR9.pdf"))
    return files


def dev_of(files, tol=1.0):
    g1, b3, g9 = Fd.build_tables(files, "2025-26")
    return Fd.find_deviations(g1, b3, g9, tol), (g1, b3, g9)


def test_every_pdf_recognised_with_month(year):
    assert [f["type"] for f in year].count("GSTR1") == 12 and [f["type"] for f in year].count("GSTR3B") == 12
    assert sum(f["type"] == "GSTR9" for f in year) == 1
    assert {f["period"] for f in year if f["type"] == "GSTR1"} == set(Fd.months("2025-26"))
    assert all(not f["withheld"] for f in year)
    cov = Fd.coverage(year, "2025-26")
    assert cov["missing"] == {"GSTR1": [], "GSTR3B": []} and cov["gstins"] == [Y.GSTIN] and not cov["duplicates"]


def test_planted_deviations_found_and_nothing_else(year):
    dev, _ = dev_of(year)
    d = dev[dev["Result"] == "Deviation"]
    found = {(r["code"], r["Period"], r["Head"]): r["A - B (Rs)"] for _, r in d.iterrows()}
    assert found[("M1", "Aug-25", "IGST")] == 45000
    assert found[("M1", "Nov-25", "CGST")] == -12000 and found[("M1", "Nov-25", "SGST/UTGST")] == -12000
    assert found[("M1", "Mar-26", "Taxable value")] == 200000
    assert found[("A2", "Year", "IGST")] == 75000          # 45,000 short paid + 30,000 added in GSTR-9
    assert found[("A3", "Year", "IGST")] == 30000
    assert found[("A5", "Year", "IGST")] == 20000
    assert found[("A6", "Year", "CGST")] == 150000
    # no false alarms on clean months
    assert not any(k[0] == "M1" and k[1] not in ("Aug-25", "Nov-25", "Mar-26") for k in found)
    assert len(found) == 14
    risk = {k: v for k, v in zip(zip(d["code"], d["Period"], d["Head"]), d["Risk"])}
    assert risk[("M1", "Aug-25", "IGST")] == "Higher" and risk[("A6", "Year", "CGST")] == "Lower"


def test_typed_correction_changes_result(year):
    dev, (g1, b3, g9) = dev_of(year)
    b3 = b3.copy()
    b3.loc["Aug-25", "3.1(a+b) IGST"] += 45000          # user types the corrected figure
    dev2 = Fd.find_deviations(g1, b3, g9)
    assert not ((dev2["code"] == "M1") & (dev2["Period"] == "Aug-25") & (dev2["Result"] == "Deviation")).any()


def test_tolerance_hides_small_differences(year):
    dev, _ = dev_of(year, tol=15000)
    d = dev[dev["Result"] == "Deviation"]
    assert not (d["A - B (Rs)"].abs() <= 15000).any()


def test_missing_months_are_not_reported_as_deviations(year):
    part = [f for f in year if not (f["type"] == "GSTR3B" and f["period"] in ("2025-04", "2025-05"))]
    cov = Fd.coverage(part, "2025-26")
    assert cov["missing"]["GSTR3B"] == ["Apr-25", "May-25"]
    dev, _ = dev_of(part)
    m1 = dev[dev["code"] == "M1"]
    assert not m1["Period"].isin(["Apr-25", "May-25"]).any()
    a1 = dev[dev["code"] == "A1"]
    assert (a1["Source A"].str.contains("10 months")).all()          # year totals use only months present in both


def test_unrecognised_and_scanned_pdfs_are_reported_not_guessed():
    from reportlab.pdfgen import canvas
    bio = io.BytesIO()
    c = canvas.Canvas(bio)
    c.setFont("Helvetica", 9)
    for k in range(12):
        c.drawString(40, 780 - 14 * k, f"Some invoice text line {k} Total 1,23,456.00")
    c.save()
    f = Fd.read_pdf(bio.getvalue(), "invoice.pdf")
    assert f["type"] is None and f["status"] == "Not recognised"
    bio = io.BytesIO()
    c = canvas.Canvas(bio)
    c.rect(10, 10, 100, 100)
    c.save()
    f = Fd.read_pdf(bio.getvalue(), "scan.pdf")
    assert f["type"] is None and "Scanned" in f["status"]


def test_mixed_gstin_and_duplicates_flagged(year):
    import form_pdfs as F
    keep, F.GSTIN = F.GSTIN, "29AAHCB3304G1ZQ"
    try:
        other = dict(Fd.read_pdf(F.gstr1_pdf(month="August"), "other.pdf"))
    finally:
        F.GSTIN = keep
    cov = Fd.coverage(year + [other], "2025-26")
    assert len(cov["gstins"]) == 2
    assert "GSTR-1 Aug-25" in cov["duplicates"]


def test_excel_report(year):
    dev, (g1, b3, g9) = dev_of(year)
    x = Fd.to_excel(dev, g1, b3, g9, year, "test")
    sheets = pd.read_excel(io.BytesIO(x), sheet_name=None, header=2)
    assert list(sheets) == ["Deviations", "All comparisons", "GSTR-1 figures", "GSTR-3B figures", "GSTR-9 figures", "Files read"]
    assert len(sheets["Deviations"]) == 14 and len(sheets["Files read"]) == 25


def test_gstr9_checks_wait_for_full_year(year):
    part = [f for f in year if not (f["type"] == "GSTR3B" and f["period"] == "2025-04")]
    dev, _ = dev_of(part)
    assert not dev["code"].isin(["A2", "A3", "A4"]).any()       # no false 'short paid' from a missing month
    assert dev["code"].isin(["A5", "A6"]).any()                 # GSTR-9 internal checks still run


def test_detailed_analysis(year):
    from datetime import date

    from engine import analysis as A
    dev, (g1, b3, g9) = dev_of(year)
    an = A.analyse(dev, g1, b3, g9, "2025-26", year, date(2026, 11, 1))
    items = {(i["code"], i["period"], i["head"]): i for i in an["items"]}
    assert len(an["items"]) == 14
    # A2 is split into its GSTR-1 part and its GSTR-9 part
    a2 = items[("A2", "Year", "IGST")]
    assert any("Rs 45,000" in l and "Rs 30,000" in l for l in a2["links"])
    # A1 is made up of the monthly rows
    assert any("Aug-25" in l for l in items[("A1", "Year", "IGST")]["links"])
    # taxable-value-only month carries no tax
    assert items[("M1", "Mar-26", "Taxable value")]["severity"] == "Low"
    # interest on Aug-25 short payment: 45,000 x 18% x days(21-09-2025..01-11-2026 inclusive)/365
    i = items[("M1", "Aug-25", "IGST")]["interest"]
    days = (date(2026, 11, 1) - date(2025, 9, 20)).days
    assert i["amount"] == round(4500000 * 0.18 * days / 365)
    # ITC deadline note
    assert any("30-11-2026" in n for n in items[("A6", "Year", "CGST")]["notes"])
    assert an["summary"]["monthly_short"] == 4500000


def test_timing_difference_and_wrong_head():
    from datetime import date

    from engine import analysis as A
    ms = [Fd.label(p) for p in Fd.months("2025-26")]
    g1 = pd.DataFrame(0.0, index=ms, columns=Fd.G1_COLS)
    b3 = pd.DataFrame(0.0, index=ms, columns=Fd.B3_COLS)
    g1[:] = 100000.0
    b3[Fd.B3_COLS[:5]] = 100000.0
    b3.loc["Jun-25", "3.1(a+b) IGST"] -= 50000      # short in June, caught up in July
    b3.loc["Jul-25", "3.1(a+b) IGST"] += 50000
    b3.loc["Sep-25", "3.1(a+b) IGST"] += 20000      # Sept: IGST paid instead of CGST+SGST
    b3.loc["Sep-25", "3.1(a+b) CGST"] -= 10000
    b3.loc["Sep-25", "3.1(a+b) SGST"] -= 10000
    g9 = pd.DataFrame(index=[d for _, d in Fd.G9_ROWS], columns=Fd.G9_COLS, dtype=float)
    dev = Fd.find_deviations(g1, b3, g9)
    an = A.analyse(dev, g1, b3, g9, "2025-26", [], date(2026, 11, 1))
    it = {(i["period"], i["head"]): i for i in an["items"]}
    jun = it[("Jun-25", "IGST")]
    assert any("Reverses in Jul-25" in l for l in jun["links"])
    assert jun["interest"]["to"] == date(2025, 8, 20)           # delay only, to the July GSTR-3B due date
    assert any("wrong head" in l for l in it[("Sep-25", "CGST")]["links"])


def test_pdf_report_and_save(year, tmp_path):
    from datetime import date

    from engine import analysis as A
    from engine import report as RP
    dev, (g1, b3, g9) = dev_of(year)
    an = A.analyse(dev, g1, b3, g9, "2025-26", year, date(2026, 11, 1))
    pdf = RP.build_pdf(an, year, Y.GSTIN, "2025-26", 1.0, ["test edit"])
    assert pdf[:4] == b"%PDF" and len(pdf) > 5000
    x = Fd.to_excel(dev, g1, b3, g9, year, "t", an)
    sheets = pd.read_excel(io.BytesIO(x), sheet_name=None, header=2)
    assert list(sheets)[0] == "Detailed analysis" and len(sheets["Detailed analysis"]) == 14
    paths = RP.save(pdf, x, Y.GSTIN, "2025-26", tmp_path)
    assert all(p.exists() for p in paths) and {p.suffix for p in paths} == {".pdf", ".xlsx"}
    assert len(RP.list_saved(tmp_path)) == 2
    import pdfplumber
    with pdfplumber.open(io.BytesIO(pdf)) as d:
        text = "\n".join(p.extract_text() or "" for p in d.pages)
    assert "Detailed analysis of every deviation" in text and "How it links" in text
