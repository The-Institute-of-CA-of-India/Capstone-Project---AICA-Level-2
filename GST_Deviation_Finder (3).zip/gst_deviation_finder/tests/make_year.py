"""A full year of replica filed PDFs (12 GSTR-1 + 12 GSTR-3B + 1 GSTR-9) with planted deviations.
Layouts follow the portal wording used by the readers; figures are hypothetical."""
import io
import os
import sys

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

sys.path.insert(0, os.path.dirname(__file__))
from form_pdfs import _fmt  # noqa: E402

GSTIN = "27AAFCS4417K1Z5"
MONTHS = ["April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March"]
# monthly outward tax in paise: (taxable, igst, cgst, sgst, cess)
BASE = [(2_00_00_000_00 + i * 5_00_000_00, 15_00_000_00 + i * 40_000_00, 9_00_000_00 + i * 20_000_00, 9_00_000_00 + i * 20_000_00, 0) for i in range(12)]
RCM = (0, 25_000_00, 25_000_00, 0)            # 3.1(d) igst, cgst, sgst, cess each month
ITC = (10_00_000_00, 6_00_000_00, 6_00_000_00, 0)  # 4A each month

# planted: Aug GSTR-1 IGST higher by 45,000 (short payment); Nov 3B CGST/SGST higher by 12,000 each; Mar GSTR-1 taxable +2,00,000
PLANT_G1 = {"August": (0, 45_000_00, 0, 0, 0), "March": (2_00_000_00, 0, 0, 0, 0)}
PLANT_3B = {"November": (0, 0, 12_000_00, 12_000_00, 0)}


def _add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def g1(i):
    m = MONTHS[i]
    v = _add(BASE[i], PLANT_G1.get(m, (0,) * 5))
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    y = 800
    for ln in ["FORM GSTR-1 Details of outward supplies of goods or services", f"Financial Year 2025-26", f"Tax Period {m}", f"GSTIN {GSTIN}",
               "Description No. of records Document Type Value Integrated Tax Central Tax State/UT Tax Cess",
               "4A - Taxable outward supplies made to registered persons 40 Invoice " + " ".join(_fmt(x) for x in v),
               "Total Liability (Outward supplies other than Reverse charge) " + " ".join(_fmt(x) for x in v)]:
        c.setFont("Helvetica", 7)
        c.drawString(25, y, ln)
        y -= 14
    c.save()
    return bio.getvalue(), v


def b3(i, watermark=False):
    m = MONTHS[i]
    v = _add(BASE[i], PLANT_3B.get(m, (0,) * 5))
    bio = io.BytesIO()
    c = canvas.Canvas(bio, pagesize=A4)
    y = 800
    lines = ["Form GSTR-3B", "Year 2025-26", f"Period {m}", f"GSTIN of the supplier {GSTIN}",
             "3.1 Details of Outward supplies and inward supplies liable to reverse charge",
             "(a) Outward taxable supplies (other than zero rated, nil rated and exempted) " + " ".join(_fmt(x) for x in v),
             "(b) Outward taxable supplies (zero rated) 0.00 0.00 0.00",
             "(c) Other outward supplies (Nil rated, exempted) 4,00,000.00",
             "(d) Inward supplies (liable to reverse charge) 2,77,778.00 " + " ".join(_fmt(x) for x in RCM),
             "(e) Non-GST outward supplies 0.00", "4. Eligible ITC", "(A) ITC Available (whether in full or part)",
             "(1) Import of goods 0.00 0.00 0.00 0.00", "(2) Import of services 0.00 0.00 0.00 0.00",
             "(3) Inward supplies liable to reverse charge (other than 1 & 2 above) 0.00 25,000.00 25,000.00 0.00",
             "(4) Inward supplies from ISD 0.00 0.00 0.00 0.00",
             "(5) All other ITC " + " ".join(_fmt(x - r) for x, r in zip(ITC, (0, 25_000_00, 25_000_00, 0))),
             "(B) ITC Reversed", "(1) As per rules 38,42 & 43 of CGST Rules and section 17(5) 0.00 0.00 0.00 0.00", "(2) Others 0.00 0.00 0.00 0.00"]
    for ln in lines:
        c.setFont("Helvetica", 7)
        c.drawString(25, y, ln)
        y -= 14
    if watermark:
        c.saveState()
        c.setFillColorRGB(0.82, 0.82, 0.82)
        c.setFont("Helvetica-Bold", 58)
        c.translate(300, 500)
        c.rotate(35)
        c.drawCentredString(0, 0, "FILED COPY")
        c.restoreState()
    c.save()
    return bio.getvalue(), v


def g9():
    """GSTR-9 filed: 4N = GSTR-1 year + RCM + an extra 30,000 IGST typed in (planted A3/A2);
    6A = 3B 4A year; Table 9 IGST paid short by 20,000 (planted A5); 8A > 8B (ITC not availed, A6)."""
    import form_pdfs as F
    F.GSTIN = GSTIN
    yr1 = [sum(g1(i)[1][k] for i in range(12)) for k in range(5)]
    tax = {"IGST": yr1[1] + 12 * RCM[0] + 30_000_00, "CGST": yr1[2] + 12 * RCM[1], "SGST": yr1[3] + 12 * RCM[2], "CESS": yr1[4] + 12 * RCM[3]}
    itc = {h: 12 * ITC[k] for k, h in enumerate(["IGST", "CGST", "SGST", "CESS"])}
    F.G9.clear()
    F.G9.update({
        "4N": (yr1[0], tax["CGST"], tax["SGST"], tax["IGST"], tax["CESS"]),
        "5N": (yr1[0] + 48_00_000_00, tax["CGST"], tax["SGST"], tax["IGST"], tax["CESS"]),
        "6A": (itc["CGST"], itc["SGST"], itc["IGST"], itc["CESS"]),
        "7I": (0, 0, 0, 0),
        "8A": (itc["CGST"] - 3_00_000_00 + 1_50_000_00, itc["SGST"] - 3_00_000_00 + 1_50_000_00, itc["IGST"], 0),
        "8B": (itc["CGST"] - 3_00_000_00, itc["SGST"] - 3_00_000_00, itc["IGST"], 0),
        "8C": (0, 0, 0, 0),
        "10": (0, 0, 0, 0, 0), "11": (0, 0, 0, 0, 0),
    })
    F.G9["8D"] = tuple(F.G9["8A"][k] - F.G9["8B"][k] - F.G9["8C"][k] for k in range(4))
    F.T9.clear()
    F.T9.update({"IGST": (tax["IGST"], tax["IGST"] - 20_000_00 - itc["IGST"], 0, 0, itc["IGST"], 0),
                 "CGST": (tax["CGST"], 0, tax["CGST"], 0, 0, 0), "SGST": (tax["SGST"], 0, 0, tax["SGST"], 0, 0), "CESS": (0, 0, 0, 0, 0, 0)})
    return F.gstr9_pdf(), tax


def write_all(folder, watermark_3b=False):
    os.makedirs(folder, exist_ok=True)
    for i, m in enumerate(MONTHS):
        open(os.path.join(folder, f"GSTR1_{m}_2025-26.pdf"), "wb").write(g1(i)[0])
        open(os.path.join(folder, f"GSTR3B_{m}_2025-26.pdf"), "wb").write(b3(i, watermark=watermark_3b)[0])
    open(os.path.join(folder, "GSTR9_FY2025-26_filed.pdf"), "wb").write(g9()[0])


if __name__ == "__main__":
    write_all(sys.argv[1] if len(sys.argv) > 1 else "sample_pdfs", watermark_3b=True)
