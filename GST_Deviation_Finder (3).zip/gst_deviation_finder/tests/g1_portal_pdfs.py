"""Replica of the portal's GSTR-1 PDF layout (landscape, pdfmake), built from the positions measured on a filed
GSTR-1 (March 2025): column headings centred over right-aligned amount columns, tables flowing over pages with the
heading repeated, value-only Table 8 rows, blank Central/State columns for B2CL / exports / SEZ, 'FINAL' watermark."""
import io
import random

from reportlab.lib.colors import Color
from reportlab.pdfgen import canvas

W, H = 841.89, 595.28
RIGHT = {"VALUE": 458.5, "IGST": 543.3, "CGST": 628.0, "SGST": 712.8, "CESS": 797.6}
HEADS = [("VALUE", "Value (₹)"), ("IGST", "Integrated Tax (₹)"), ("CGST", "Central Tax (₹)"),
         ("SGST", "State/UT Tax (₹)"), ("CESS", "Cess (₹)")]
COLW = 84.8


def fmt(p):
    neg = p < 0
    p = abs(p)
    r, ps = divmod(p, 100)
    s = str(r)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts + [tail])
    return ("-" if neg else "") + f"{s}.{ps:02d}"


FONT = "Helvetica"


class Doc:
    def __init__(self, watermark=True):
        self.bio = io.BytesIO()
        self.c = canvas.Canvas(self.bio, pagesize=(W, H))
        self.y = H - 40
        self.wm = watermark
        self.page_start()

    def page_start(self):
        if self.wm:
            c = self.c
            c.saveState()
            c.setFillColor(Color(0, 0, 0, alpha=0.1))
            c.setFont("Helvetica-Bold", 220)
            c.translate(250, 90)
            c.rotate(35)
            c.drawString(0, 0, "FINAL")
            c.restoreState()

    def need(self, h):
        if self.y - h < 50:
            self.c.setFont(FONT, 7)
            self.c.drawRightString(W - 40, 38, "IP Address: 10.0.0.1")
            self.c.showPage()
            self.y = H - 40
            self.page_start()
            self.header()

    def text(self, x, s, size=7.5, bold=False):
        self.c.setFont(FONT + ("-Bold" if bold else ""), size)
        self.c.drawString(x, self.y, s)

    def header(self):
        c = self.c
        c.setFont(FONT + "-Bold", 7.5)
        c.drawString(270, self.y + 4, "No. of")
        c.drawString(325, self.y + 4, "Document")
        c.drawString(125, self.y, "Description")
        for k, t in HEADS:
            c.drawCentredString(RIGHT[k] - 38.2, self.y, t)
        c.drawString(270, self.y - 5, "records")
        c.drawString(336, self.y - 5, "Type")
        self.y -= 22

    def heading(self, s):
        self.need(30)
        self.text(44, s, 7.5, True)
        self.y -= 13

    def row(self, label, records=None, dtype="", vals=None, indent=0):
        self.need(14)
        c = self.c
        self.text(44 + indent, label)
        if records is not None:
            c.drawRightString(288, self.y, str(records))
            c.drawString(340, self.y, dtype)
        for k, v in (vals or {}).items():
            if v is not None:
                c.drawRightString(RIGHT[k], self.y, fmt(v))
        self.y -= 13

    def gap(self, n=12):
        self.y -= n

    def save(self):
        self.c.save()
        return self.bio.getvalue()


def v5(value, igst, cgst=0, cess=0, intra=True):
    return {"VALUE": value, "IGST": igst, "CGST": cgst if intra else None, "SGST": cgst if intra else None, "CESS": cess}


def gstr1(seed=1, watermark=True, fy="2024-25", month="March", gstin="27AAACZ1234F1Z5"):
    """Returns (pdf bytes, expected) where expected = {table key: headline values (paise)} plus figures for the comparison."""
    rnd = random.Random(seed)
    r = lambda lo, hi: rnd.randint(lo, hi) * 100 + rnd.randint(0, 99)  # noqa: E731
    t = {}
    t["4A"] = v5(r(10_00_000, 90_00_000), r(10_000, 2_00_000), r(10_000, 2_00_000))
    t["4B"] = v5(r(0, 2_00_000), 0, 0)
    t["5"] = v5(r(1_00_000, 9_00_000), r(10_000, 90_000), intra=False)
    t["6A"] = v5(r(0, 5_00_000), r(0, 50_000), intra=False)
    t["6B"] = v5(r(0, 3_00_000), r(0, 30_000), intra=False)
    t["6C"] = v5(0, 0, 0)
    t["7"] = v5(r(50_000, 9_00_000), r(0, 20_000), r(1_000, 50_000))
    nil = r(0, 4_00_00_000)
    t["8"] = {"VALUE": nil, "IGST": None, "CGST": None, "SGST": None, "CESS": None}
    t["9A_B2B"] = v5(r(0, 50_000), r(0, 5_000), r(0, 2_000))
    t["9B_CDNR"] = {k: (-v if v else v) for k, v in v5(r(10_000, 6_00_000), r(0, 500), r(1_000, 20_000)).items()}
    t["9B_CDNUR"] = v5(0, 0, intra=False)
    t["10"] = v5(0, 0, 0)
    t["11A"] = v5(r(0, 1_00_000), r(0, 5_000), r(0, 5_000))
    t["11B"] = v5(r(0, 50_000), r(0, 2_000), r(0, 2_000))
    signs = {"4A": 1, "5": 1, "6A": 1, "6B": 1, "6C": 1, "7": 1, "8": 1, "9A_B2B": 1, "9B_CDNR": 1, "9B_CDNUR": 1, "10": 1, "11A": 1, "11B": -1}
    tot = {k: sum(signs[x] * (t[x].get(k) or 0) for x in signs) for k in RIGHT}
    hsn = dict(tot)
    d = Doc(watermark)
    c = d.c
    c.setFont(FONT + "-Bold", 12)
    c.drawCentredString(W / 2, H - 40, "FORM GSTR-1")
    c.setFont(FONT, 8)
    c.drawCentredString(W / 2, H - 55, "[See rule 59(1)]")
    c.drawCentredString(W / 2, H - 66, "Details of outward supplies of goods or services")
    c.drawString(640, H - 100, "Financial year")
    c.drawString(732, H - 100, fy)
    c.drawString(640, H - 112, "Tax period")
    c.drawString(732, H - 112, month)
    for i, (a, b, val) in enumerate([("1", "GSTIN", gstin), ("2", "(a)  Legal name of the registered person", "ZEN TRADERS PRIVATE LIMITED"),
                                     ("", "(b)  Trade name if any", "ZEN TRADERS"), ("", "(c)  ARN", "AA270325000000Q"),
                                     ("", "(d)  ARN date", "11/04/2025")]):
        y = H - 145 - 13 * i
        c.drawString(44, y, a)
        c.drawString(89, y, b)
        c.drawString(360, y, val)
    d.y = H - 230
    d.header()
    d.heading("4A - Taxable outward supplies made to registered persons (other than reverse charge supplies) including supplies made through e-commerce operator attracting TCS - B2B Regular")
    d.row("Total", 10, "Invoice", t["4A"])
    d.gap()
    d.heading("4B - Taxable outward supplies made to registered persons attracting tax on reverse charge - B2B Reverse charge")
    d.row("Total", 1, "Invoice", t["4B"])
    d.gap()
    d.heading("5 - Taxable outward inter-state supplies made to unregistered persons (where invoice value is more than Rs. 1 lakh) including supplies made through e-commerce operator, rate wise - B2CL (Large)")
    d.row("Total", 2, "Invoice", t["5"])
    d.gap()
    d.heading("6A – Exports (with/without payment)")
    d.row("Total", 1, "Invoice", t["6A"])
    d.row("- EXPWP", 1, "Invoice", t["6A"], 4)
    d.row("- EXPWOP", 0, "Invoice", {"VALUE": 0}, 4)
    d.gap()
    d.heading("6B - Supplies made to SEZ unit or SEZ developer - SEZWP/SEZWOP")
    d.row("Total", 1, "Invoice", t["6B"])
    d.row("- SEZWP", 1, "Invoice", t["6B"], 4)
    d.row("- SEZWOP", 0, "Invoice", {"VALUE": 0}, 4)
    d.gap()
    d.heading("6C - Deemed Exports – DE")
    d.row("Total", 0, "Invoice", t["6C"])
    d.gap()
    d.heading("7- Taxable supplies (Net of debit and credit notes) to unregistered persons (other than the supplies covered in Table 5) - B2CS (Others)")
    d.row("Total", 0, "Net Value", t["7"])
    d.gap()
    d.heading("8 - Nil rated, exempted and non GST outward supplies")
    d.row("Total", vals={"VALUE": nil})
    d.row("- Nil", vals={"VALUE": nil}, indent=4)
    d.row("- Exempted", vals={"VALUE": 0}, indent=4)
    d.row("- Non-GST", vals={"VALUE": 0}, indent=4)
    d.gap()
    d.heading("9A - Amendment to taxable outward supplies made to registered person in returns of earlier tax periods in table 4 - B2B Regular")
    d.row("Amended amount - Total", 1, "Invoice", {k: (v or 0) * 3 for k, v in t["9A_B2B"].items()})
    d.row("Net differential amount (Amended - Original)", vals=t["9A_B2B"])
    d.gap()
    d.heading("9A - Amendment to Deemed Exports in returns of earlier tax periods in table 6C (DE)")
    d.row("Amended amount - Total", 0, "Invoice", v5(0, 0, 0))
    d.row("Net differential amount (Amended - Original)", vals=v5(0, 0, 0))
    d.gap()
    d.heading("9B - Credit/Debit Notes (Registered) – CDNR")
    d.row("Total - Net off debit/credit notes (Debit notes - Credit notes)", 3, "Note", t["9B_CDNR"])
    d.row("Credit / Debit notes issued to registered person for taxable outward supplies in table 4 other than table 6 - B2B Regular", indent=4)
    d.row("Net Total (Debit notes – Credit notes)", 3, "Note", t["9B_CDNR"], 10)
    d.gap()
    d.heading("9B - Credit/Debit Notes (Unregistered) – CDNUR")
    d.row("Total - Net off debit/credit notes (Debit notes - Credit notes)", 0, "Note", t["9B_CDNUR"])
    d.gap()
    d.heading("9C - Amended Credit/Debit Notes (Registered) - CDNRA")
    d.row("Amended amount - Total", 0, "Note", v5(0, 0, 0))
    d.row("Net Differential amount (Net Amended Debit notes - Net", vals=v5(0, 0, 0))
    d.row("Amended Credit notes) - Total")
    d.gap()
    d.heading("10 - Amendment to taxable outward supplies made to unregistered person in returns for earlier tax periods in table 7 - B2C (Others)")
    d.row("Amended amount - Total", 0, "Net Value", t["10"])
    d.row("Net differential amount (Amended - Original)", vals=t["10"])
    d.gap()
    d.heading("11A(1), 11A(2) - Advances received for which invoice has not been issued (tax amount to be added to the output tax liability)")
    d.row("Total", 1, "Net Value", t["11A"])
    d.gap()
    d.heading("11B(1), 11B(2) - Advance amount received in earlier tax period and adjusted against the supplies being shown in this tax period")
    d.row("Total", 1, "Net Value", t["11B"])
    d.gap()
    d.heading("12 - HSN-wise summary of outward supplies")
    d.row("Total", 4, "NA", hsn)
    d.gap()
    d.heading("13 - Documents issued")
    d.row("Net issued documents", 57, "All Documents")
    d.gap()
    d.heading("14 - Supplies made through E-Commerce Operators")
    d.row("Total", 0, "Net Value", v5(0, 0, 0))
    d.gap(20)
    d.row("Total Liability (Outward supplies other than Reverse charge)", vals=tot)
    pdf = d.save()
    exp = {"tables": t, "TOTAL": tot, "HSN": hsn,
           "fields": {"G1_TXVAL": tot["VALUE"] - nil, "G1_NIL": nil, "G1_TOTVAL": tot["VALUE"], "G1_IGST": tot["IGST"],
                      "G1_CGST": tot["CGST"], "G1_SGST": tot["SGST"], "G1_CESS": tot["CESS"]},
           "meta": {"fy": fy, "gstin": gstin}}
    return pdf, exp
