@echo off
title Stop GST Deviation Finder
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":850[0-9] .*LISTENING"') do (
  tasklist /FI "PID eq %%p" /NH | findstr /i "python" >nul && taskkill /PID %%p /T /F >nul 2>nul && echo   Stopped GST Deviation Finder - process %%p
)
echo   Done. You can now start GST Deviation Finder again with run_app.bat.
pause
