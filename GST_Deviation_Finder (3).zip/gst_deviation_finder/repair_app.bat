@echo off
title Repair GST Deviation Finder
cd /d "%~dp0"
echo.
echo   This deletes the app's private library folder (.venv) and installs it again.
echo   Your saved reports are NOT touched.
echo.
choice /c YN /m "  Continue"
if errorlevel 2 exit /b 0
if exist ".venv" rmdir /s /q ".venv"
call run_app.bat
