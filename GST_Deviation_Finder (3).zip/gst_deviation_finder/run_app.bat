@echo off
setlocal EnableExtensions EnableDelayedExpansion
title GST Deviation Finder - keep this window open while you use the app
cd /d "%~dp0"
set "VPY=.venv\Scripts\python.exe"
set "LOG=setup_log.txt"
set "CHECK=import streamlit, numpy, pandas, pyarrow, plotly, pdfplumber, pypdfium2, xlsxwriter, openpyxl, reportlab"

echo.
echo   GST Deviation Finder - starting...
echo.

rem ---------- 1. Find Python 3.10 or later -------------------------------------
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "PY=python"
if not defined PY goto :nopython

rem ---------- 2. Libraries: checked on EVERY start, repaired if anything is missing
set "NEED="
if not exist "%VPY%" set "NEED=1"
if not defined NEED "%VPY%" -c "%CHECK%" >nul 2>nul || set "NEED=1"
if defined NEED call :install
if defined NEED goto :failed

rem ---------- 3. Skip Streamlit's one-time "Email:" question ------------------
if not exist "%USERPROFILE%\.streamlit" mkdir "%USERPROFILE%\.streamlit"
if not exist "%USERPROFILE%\.streamlit\credentials.toml" (
  > "%USERPROFILE%\.streamlit\credentials.toml" echo [general]
  >> "%USERPROFILE%\.streamlit\credentials.toml" echo email = ""
)

rem ---------- 4. Is an earlier copy still running on port 8501? ---------------
set "PORTARG=--server.port 8501"
set "OLDPID="
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":8501 .*LISTENING"') do set "OLDPID=%%p"
if defined OLDPID (
  echo   An earlier copy of the app is using address 8501 - closing it.
  taskkill /PID !OLDPID! /T /F >nul 2>nul
  timeout /t 2 /nobreak >nul
)

rem ---------- 5. Start - the browser opens by itself --------------------------
echo   The app will open in your browser in a few seconds.
echo   Keep THIS window open while you work. Close it to stop the app.
echo.
"%VPY%" -m streamlit run app.py %PORTARG% --server.headless false
echo.
echo   GST Deviation Finder has stopped.
pause
exit /b 0

rem =============================================================================
:install
echo   Setting up the libraries. First time: 3 to 8 minutes, needs internet.
echo   Progress is written to %LOG% in this folder.
echo.
if exist "%VPY%" "%VPY%" -c "import sys" >nul 2>nul || rmdir /s /q .venv
if not exist "%VPY%" %PY% -m venv .venv > "%LOG%" 2>&1
if not exist "%VPY%" exit /b 1
"%VPY%" -m pip install --upgrade pip --disable-pip-version-check >> "%LOG%" 2>&1
"%VPY%" -m pip install --prefer-binary --disable-pip-version-check -r requirements.txt >> "%LOG%" 2>&1
"%VPY%" -c "%CHECK%" >nul 2>nul || exit /b 1
set "NEED="
echo   Libraries installed.
echo.
exit /b 0

:nopython
echo   Python 3.10 or later was not found.
echo   Install Python from https://www.python.org/downloads/ and tick
echo   "Add python.exe to PATH" on the first screen of the installer, then run this again.
echo.
pause
exit /b 1

:failed
echo.
echo   The libraries could not be installed. Last lines of %LOG%:
echo   ---------------------------------------------------------------------------
powershell -NoProfile -Command "Get-Content -Tail 20 '%LOG%'" 2>nul || type "%LOG%"
echo   ---------------------------------------------------------------------------
echo   Usual causes: no internet, office firewall/proxy blocking pip, or a very new
echo   Python version. Check the internet and run run_app.bat again - it resumes.
echo   If it still fails, send setup_log.txt.
echo.
pause
exit /b 1
