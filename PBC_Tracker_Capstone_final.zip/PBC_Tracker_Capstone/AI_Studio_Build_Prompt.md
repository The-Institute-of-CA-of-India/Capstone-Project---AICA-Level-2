# PBC Tracker – Google AI Studio Build Prompt

## A. Prompt to paste into Google AI Studio → Build

```
Build a responsive web app called "PBC Tracker" – an audit document tracker for an Indian
Chartered Accountancy firm. It tracks documents requested from clients (PBC = Prepared By Client)
across four audit types: Statutory Audit, Internal Audit, Concurrent Audit of Banks, and Tax Audit (Form 3CD).

Design: clean professional dashboard, navy (#14213d) header with gold (#c9a227) accents, cards,
works on mobile. Store all data in localStorage. Use the Gemini API for the AI features.

1. DASHBOARD
- KPI tiles: active engagements, documents tracked, awaited from clients, overdue, overall % completion.
- Filter chips by audit type + search by client name.
- One card per engagement: audit-type tag, client, period, partner, progress bar (% received),
  overdue count in red, documents-due date.
- Pre-load 4 demo engagements (one per audit type) with mixed statuses so the demo looks real.

2. NEW ENGAGEMENT
- Fields: client name, audit type, period (FY/AY/month), partner/team lead, documents due date,
  client e-mail, client WhatsApp number.
- On create, auto-load a standard PBC checklist grouped by category for that audit type:
  * Statutory Audit: TB & ledgers, draft Schedule III financials, bank statements & BRS, balance
    confirmations, fixed asset register & physical verification, inventory valuation, debtors/creditors
    ageing, loan sanction letters, MSME dues, GST returns & 2B reconciliation, TDS & 26AS/AIS,
    PF/ESI/PT challans, Board minutes, ROC filings, related party list, legal cases, CARO 2020 info,
    IFC risk control matrix, actuarial valuation, management representation letter.
  * Internal Audit: previous IA report & ATR, delegation of authority, SOPs, PO/GRN/invoices,
    vendor master changes, payment approvals, sales & credit notes, stock registers, FA tagging,
    attendance & payroll, F&F settlements, BRS, petty cash count, compliance tracker, IT user access.
  * Concurrent Audit (Bank): loan files (sanction, appraisal, KYC), security documents, CERSAI,
    inspection reports, insurance, stock statements & drawing power, renewals due, SMA/NPA & IRAC,
    TOD/excess drawings, new account KYC, CTR/STR, dormant accounts, cash & ATM verification,
    gold loan packets, locker register, suspense/sundry accounts, inter-branch reconciliation,
    interest & charges leakage, BG/LC, previous report compliance, CBS exception reports.
  * Tax Audit (3CD): financials & TB, previous 3CD, ITR/26AS/AIS, 43CA/50C stamp value (Cl.17),
    56(2)(x), quantitative details (Cl.35), 40A(3) cash payments (Cl.21), 40A(2)(b) related parties
    (Cl.23), 43B incl. 43B(h) MSME (Cl.26), 40(b), IT-Act depreciation (Cl.18), TDS/TCS (Cl.34),
    269SS/269T (Cl.31), brought-forward losses (Cl.32), GST turnover reconciliation (Cl.44), 15CA/CB.

3. ENGAGEMENT CHECKLIST SCREEN
- Table grouped by category: Sl, document, status dropdown (Pending / Requested / Received /
  Verified / Query / N/A, colour-coded), due date, assigned team member, uploaded files, remarks.
- Overdue rows (past due date and not Received/Verified/N/A) highlighted in red.
- Upload button per item: attaching a file auto-moves status to "Received".
- Filter: all / awaited / overdue / by status. Add custom item. Edit or delete engagement.
- Export to CSV and "Copy for Excel"; print-friendly PBC list.

4. AI FEATURES (Gemini)
- "Smart Upload": user uploads any document (image or PDF). Send it to Gemini with the list of
  awaited checklist items. Gemini returns JSON {item_id, confidence, document_type, period_covered,
  summary, red_flags[]}. Red flags = wrong period, unsigned/unstamped, illegible, totals not matching,
  different entity name. Show the result; on confirm attach the file to that item – status "Received",
  or "Query" with red flags written into remarks.
- "Client Reminder": auto-draft a polite reminder listing awaited items and items under query, with
  buttons: Polish with AI, Copy, WhatsApp (wa.me link with the client's number), E-mail (mailto).
- "AI Status Note": Gemini writes a <150-word note for the engagement partner – overall status,
  key risk areas from pending items for that audit type, top 3 actions.
```
