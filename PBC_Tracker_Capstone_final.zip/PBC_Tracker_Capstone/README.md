<div align="center">

<br><br>

# CAPSTONE PROJECT

## AI POWERED AUDIT DOCUMENT TRACKER
### *(PBC Tracker)*

<br>

**Certificate Course on Artificial Intelligence for Chartered Accountants**
**AICA Level-2**
The Institute of Chartered Accountants of India

<br>

| | |
|---|---|
| **MEMBER NAME** | SWATI KEJRIWAL |
| **MEMBERSHIP NO.** | 067891 |
| **BATCH** | AICA-L2-B14-BHUBANESWAR BATCH |
| **CAPSTONE PROJECT** | AI POWERED AUDIT DOCUMENT TRACKER |

<br>

*Built with Google AI Studio (Gemini) · HTML / CSS / JavaScript*

<br><br>

</div>

---

# PBC Tracker – AI-Powered Audit Document Tracker

## 1. The problem

Every audit begins with a list of documents requested from the client, the PBC (*Prepared By Client*) list. After that comes weeks of chasing. In most CA firms:

- the document list sits in Excel sheets, e-mails and WhatsApp chats;
- nobody can tell at a glance what is pending, received, verified or overdue;
- team members follow up manually, and reminders are inconsistent;
- the engagement partner gets a status update only when deadlines are close.

This happens across **statutory audit, internal audit, concurrent audit of banks and tax audit**, and it costs the team hours on every engagement.

## 2. The solution

**PBC Tracker** is a single web app that:

1. **Loads the right checklist automatically.** It holds ready-made PBC lists for:
   - **Statutory audit** – Schedule III, CARO 2020, IFC, balance confirmations, MSME, related parties and more;
   - **Internal audit** – procure-to-pay, order-to-cash, payroll, inventory and IT access;
   - **Concurrent audit (bank)** – loan files, drawing power, CERSAI, SMA/NPA, KYC/AML, cash and gold loans, suspense accounts;
   - **Tax audit (Form 3CD)** – clause-wise items such as 40A(3), 43B / 43B(h), 269SS/T, TDS and 44AB.
2. **Tracks every document** as Pending, Requested, Received, Verified, Query or N/A, with due dates, the team member assigned, uploaded files and remarks. Overdue items are highlighted in red.
3. **Uses AI to read uploaded documents (✨ Smart Upload).** Gemini reads the uploaded PDF or image, matches it to the right checklist item and flags red flags: wrong period, unsigned or unstamped, illegible, totals not matching, or a different entity name. A clean document is marked *Received*. A flagged one goes to *Query*, with the reasons written into the remarks.
4. **Drafts client reminders automatically (📩).** It lists the pending items and the items under query. The reminder can be polished with AI and sent by WhatsApp or e-mail.
5. **Writes an AI status note for the partner (🧠).** This is a short note covering overall status, key risk areas and the top 3 actions.
6. **Shows a dashboard** of all engagements: completion %, documents awaited, overdue counts, and filters by audit type.
7. **Exports and prints.** The list can be copied to Excel, downloaded as CSV, printed as a PBC list, or backed up and restored as JSON.

## 3. The app in action – screenshots

### 3.1 Dashboard – all engagements at a glance
KPI tiles for active engagements, documents awaited, overdue items and overall completion. There is one card per engagement, and you can filter by audit type.

![Dashboard](screenshots/01_dashboard.png)

### 3.2 Creating a new engagement
Enter the client, audit type, period, partner, due date and the client's e-mail / WhatsApp.

![New engagement](screenshots/02_new_engagement.png)

### 3.3 Standard checklist loaded automatically
The full statutory-audit PBC list loads category-wise as soon as the engagement is created.

![Checklist loaded](screenshots/03_checklist_loaded.png)

### 3.4 Adding documents
Uploading a file against an item moves its status to *Received*. The auditor marks it *Verified* after checking, and the completion % and KPI tiles update instantly.

![Documents added](screenshots/04_documents_added.png)

### 3.5 Sending a reminder to the client
The reminder is drafted automatically from the pending items and the items under query. It can be polished with AI and sent by WhatsApp or e-mail.

![Client reminder](screenshots/05_client_reminder.png)

### 3.6 AI feature – Smart Upload with red-flag review
Gemini reads the uploaded bank statement and matches it to *Bank statements for all accounts*. It also flags that March 2026 is missing and that the bank seal is not visible. One click attaches the file and raises a query, with the red flags written into the remarks.

![AI Smart Upload](screenshots/06_ai_smart_upload.png)

### 3.7 AI feature – status note for the engagement partner
Gemini writes a short note covering overall status, key risk areas and the top 3 actions for the team.

![AI status note](screenshots/07_ai_status_note.png)

*Client names and contact details in the screenshots are dummy data.*

## 4. AICA Level-2 learning applied

| Course module | Where it is used in the project |
|---|---|
| Module 1 – AI agents & prompt engineering | Structured prompts that return JSON for document matching and red-flag review |
| Module 3 – Computer vision / Google AI Studio | Gemini reads scanned bills, bank statements and returns (images and PDFs) |
| Module 4 – Communication automation & data visualisation | Auto-drafted reminders with WhatsApp / e-mail links; KPI dashboard with progress bars |
| Module 7 – Full-stack web app development | Complete responsive web app built through AI Studio, usable on desktop and mobile |
| Module 9 – Workflow automation | Status automation: upload → Received; red flag → Query; overdue detection |

## 5. How to run

1. Download `index.html` and open it in **Google Chrome**. No installation is needed.
2. Click **⚙ AI Settings** and paste your **Gemini API key** (free from aistudio.google.com → *Get API key*).
   - The key is stored only in your own browser.
   - Without a key, the app still works: Smart Upload falls back to file-name matching and reminders use a standard template.
3. The app opens with 4 demo engagements, one per audit type. Use **Reset demo data** in Settings to restore them at any time.
4. Click **+ New Engagement** to start a real one. The standard checklist for that audit type loads by itself.

## 6. Files in this repository

| File | Purpose |
|---|---|
| `index.html` | The complete app (single file) |
| `AI_Studio_Build_Prompt.md` | The prompt used in Google AI Studio *Build* mode to generate the app |
| `README.md` | This document |
| `screenshots/` | 7 screenshots of the app in use (section 3) |

## 7. Data privacy & professional responsibility

- All engagement data stays in the user's browser (localStorage). There is no server or database.
- AI calls go directly from the browser to Google Gemini, using the user's own API key.
- AI output is an **assistant, not a substitute for the auditor's judgement**. Every match and red flag is shown for the auditor to confirm before it is applied. This is in line with SA 230 documentation, and with the confidentiality obligations of the ICAI Code of Ethics.

## 8. Future scope

- Client login (Supabase) so clients upload documents directly against each checklist item
- Scheduled daily reminders through an n8n workflow
- Multi-user access for the audit team, with partner review sign-off
- Mobile app (PWA / Android APK)

---

**Submitted by:** CA Swati Kejriwal (M. No. 067891) · AICA-L2-B14-BHUBANESWAR BATCH
