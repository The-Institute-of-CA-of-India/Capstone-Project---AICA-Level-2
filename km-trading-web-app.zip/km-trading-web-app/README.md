# KM Trading: Fruits & Vegetables Branch Receiving Web App

A mobile-friendly full-stack web application for **KM Trading** to record warehouse-to-branch fruits & vegetables transfers, calculate quantity/value variances, require reasons for every difference, lock daily reports at day end, monitor threshold alerts, and export daily/monthly management reports.

## Architecture & Tech Stack
- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons, jsPDF + jspdf-autotable, SheetJS (`xlsx`)
- **Backend**: Node.js, Express (`server.ts`), Multer (in-memory upload validation), SheetJS (`xlsx`)
- **Database**: SQLite (`better-sqlite3`, stored at `data/km_trading.db`)
- **Authentication**: Server-side `crypto.scrypt` password hashing + HMAC-SHA256 Bearer tokens + Role-Based Access Control (`admin`, `manager`, `branch`)

## Folder Structure
- `server.ts` — Express server entry point (port 3000) serving API routes and Vite frontend
- `server/db.ts` — SQLite schema, indexes, seed data, audit logger, and day-lock status helper
- `server/auth.ts` — Password hashing, signed token verification, and RBAC middleware
- `server/routes/authRoutes.ts` — First-run admin setup, login, password change
- `server/routes/masterRoutes.ts` — Products CRUD/export, Master Excel/CSV template & upload validation/import, Branches, Reasons, Users, Settings, Audit Log
- `server/routes/receivingRoutes.ts` — Daily receiving entries, day locking/reopening, dashboard & reports
- `src/App.tsx` — Main responsive shell and navigation
- `src/components/` — `LoginScreen`, `ReceivingPage`, `DashboardPage`, `ReportsPage`, `MasterProductsPage`, `MasterUploadPage`, `AdminSetupPage`, `UserGuidePage`
- `src/lib/api.ts` — API client and number formatters
- `src/lib/exportUtils.ts` — PDF, Excel, and CSV export helpers

## Setup & Run Instructions
1. **Install dependencies**:
   ```bash
   npm install
   ```
2. **Environment variables (optional)**:
   - Copy `.env.example` to `.env` if you wish to pre-set `ADMIN_INITIAL_PASSWORD`.
   - If `ADMIN_INITIAL_PASSWORD` is left blank, the app shows an inline **Initial Administrator Setup** form on first launch so you can claim the `admin` account directly in the browser.
3. **Run in development**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000`.
4. **Build & run in production**:
   ```bash
   npm run build
   npm start
   ```

## Seed Data Included on First Boot
- **2 Branches**: `Branch A - Al Karama`, `Branch B - Deira Market`
- **6 Default Reasons**: `Shortage`, `Wastage or damage`, `Weight loss or drying`, `Quality rejection`, `Wrong item sent`, `Other`
- **8 Sample Products**: Onions, Tomatoes, Potatoes, Cucumbers, Bananas, Apples, Watermelons, Oranges
- **Default Alert Threshold**: `5%`

## Quick User Guide
### Administrator
1. On first run, set the `admin` password on the setup screen.
2. Go to **Master Data Upload**, download the Excel (`.xlsx`) or CSV template (`barcode, product_name, unit, default_price, category, active`), fill in your catalog, upload to preview validation results, and confirm import.
3. Go to **Admin Setup & Audit** to manage Branches, Variance Reasons, Staff Users (`admin`, `manager`, `branch`), and Alert Threshold %.
4. Use **Products Master** to add/edit individual items, update prices (new entries only), deactivate items, or export the master list to Excel.

### Branch Staff
1. Open **Daily Receiving** (date defaults to today; branch is pre-selected).
2. Enter the GRN / transfer document number.
3. Search products by name or typed barcode; unit and default price fill automatically.
4. Enter **Transferred Qty** and **Received Qty** (up to 3 decimals for `kg`).
5. If there is a difference, select a **Variance Reason** (required before saving) and add remarks. Multiple products can be saved under the same document number.

### Managers
1. Review **Variance Dashboard** for daily loss totals, threshold alerts, top shortage products, and top reasons.
2. At day end, click **Close Day** on **Daily Receiving** to lock the date.
3. Open **Reports & Export** for Daily Detail, Daily Consolidated, and Monthly reports with Print, PDF, Excel, and CSV exports.
