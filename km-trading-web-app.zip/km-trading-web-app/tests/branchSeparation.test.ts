import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';

function makeTestPassword(): string {
  return `Km${crypto.randomBytes(6).toString('hex')}9`;
}

async function runTests() {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'km-trading-test-'));
  const tempDbPath = path.join(tempDir, 'test.db');
  process.env.KM_DB_PATH = tempDbPath;
  process.env.KM_DISABLE_LISTEN = '1';

  const { createApiApp } = await import('../server');
  const app = createApiApp();
  const server = http.createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const addr = server.address();
  assert(addr && typeof addr === 'object', 'Server address should be bound');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  async function api(
    route: string,
    opts: { method?: string; token?: string; cookie?: string; body?: unknown } = {}
  ) {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
    };
    if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
    if (opts.cookie) headers.Cookie = opts.cookie;

    const res = await fetch(`${baseUrl}${route}`, {
      method: opts.method || 'GET',
      headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
    const text = await res.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = text;
    }
    return { status: res.status, json, headers: res.headers };
  }

  try {
    // 1. Setup Admin enforces password policy
    const weakSetup = await api('/api/auth/setup-admin', {
      method: 'POST',
      body: { password: 'short', full_name: 'HO Admin' },
    });
    assert.equal(weakSetup.status, 400, 'Weak password without length/number should be rejected');

    const noNumberSetup = await api('/api/auth/setup-admin', {
      method: 'POST',
      body: { password: 'OnlyLettersPassword', full_name: 'HO Admin' },
    });
    assert.equal(noNumberSetup.status, 400, 'Password without number should be rejected');

    const adminPass = makeTestPassword();
    const adminSetup = await api('/api/auth/setup-admin', {
      method: 'POST',
      body: { password: adminPass, full_name: 'HO Admin' },
    });
    assert.equal(adminSetup.status, 201 === adminSetup.status ? 201 : 200);
    assert.equal(adminSetup.json.user.role, 'admin');
    const adminToken = adminSetup.json.token as string;
    const setCookieHeader = adminSetup.headers.get('set-cookie') || '';
    assert(setCookieHeader.includes('km_session='), 'Should set HttpOnly session cookie');
    assert(setCookieHeader.includes('HttpOnly'), 'Session cookie must be HttpOnly');

    // Cookie auth works without Bearer token on /api/auth/me
    const cookieValue = setCookieHeader.split(';')[0];
    const meByCookie = await api('/api/auth/me', { cookie: cookieValue });
    assert.equal(meByCookie.status, 200);
    assert.equal(meByCookie.json.user.username, 'admin');

    // 2. Verify all 12 seeded accounts exist & issue bulk temp passwords
    const usersRes = await api('/api/users', { token: adminToken });
    assert.equal(usersRes.status, 200);
    assert.equal(usersRes.json.length, 12, 'Should seed admin + ho_manager + 10 branch users');

    const bulkRes = await api('/api/users/bulk-branch-logins', {
      method: 'POST',
      token: adminToken,
      body: { reissueAll: false },
    });
    assert.equal(bulkRes.status, 200);
    assert.equal(bulkRes.json.issued.length, 11, 'Should issue temp passwords for ho_manager + 10 branches');

    const issuedMap = new Map<string, string>();
    for (const item of bulkRes.json.issued) {
      issuedMap.set(item.username, item.temp_password);
    }

    const amaratTempPw = issuedMap.get('branch_al_amerat');
    const ruwiTempPw = issuedMap.get('branch_ruwi');
    const hoManagerTempPw = issuedMap.get('ho_manager');
    assert(amaratTempPw && ruwiTempPw && hoManagerTempPw, 'Seeded accounts must receive temp passwords');

    // 3. Branch A logs in with temp password -> forced password change gate
    const amaratLogin = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_al_amerat', password: amaratTempPw, rememberMe: false },
    });
    assert.equal(amaratLogin.status, 200);
    assert.equal(amaratLogin.json.user.must_change_password, true);
    const amaratToken = amaratLogin.json.token as string;
    const amaratBranchId = amaratLogin.json.user.branch_id as number;
    const today = amaratLogin.json.server_today as string;

    const blockedBeforeChange = await api(`/api/receiving?date=${today}`, { token: amaratToken });
    assert.equal(blockedBeforeChange.status, 403, 'Branch user with temp password must change password first');
    assert.equal(blockedBeforeChange.json.must_change_password, true);

    const amaratNewPw = makeTestPassword();
    const changeAmaratPw = await api('/api/auth/change-password', {
      method: 'POST',
      token: amaratToken,
      body: { currentPassword: amaratTempPw, newPassword: amaratNewPw },
    });
    assert.equal(changeAmaratPw.status, 200);
    assert.equal(changeAmaratPw.json.user.must_change_password, false);

    // 4. Branch B logs in, changes password, and creates an entry in Ruwi
    const ruwiLogin = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_ruwi', password: ruwiTempPw, rememberMe: true },
    });
    assert.equal(ruwiLogin.status, 200);
    const ruwiToken = ruwiLogin.json.token as string;
    const ruwiBranchId = ruwiLogin.json.user.branch_id as number;
    assert.notEqual(amaratBranchId, ruwiBranchId, 'Branches must have distinct IDs');

    const ruwiNewPw = makeTestPassword();
    const changeRuwiPw = await api('/api/auth/change-password', {
      method: 'POST',
      token: ruwiToken,
      body: { currentPassword: ruwiTempPw, newPassword: ruwiNewPw },
    });
    assert.equal(changeRuwiPw.status, 200);

    const prodRes = await api('/api/products?activeOnly=true', { token: ruwiToken });
    assert.equal(prodRes.status, 200);
    assert(prodRes.json.length > 0, 'Products should exist');
    const productId = prodRes.json[0].id as number;

    const reasonsRes = await api('/api/reasons?activeOnly=true', { token: ruwiToken });
    assert.equal(reasonsRes.status, 200);
    const reasonId = reasonsRes.json[0].id as number;

    const ruwiCreate = await api('/api/receiving', {
      method: 'POST',
      token: ruwiToken,
      body: {
        entry_date: today,
        branch_id: ruwiBranchId,
        document_number: 'GRN-RUWI-9001',
        product_id: productId,
        unit: 'kg',
        transferred_qty: 20,
        received_qty: 18,
        unit_price: 2.5,
        reason_id: reasonId,
        remarks: 'Ruwi confidential entry',
      },
    });
    assert.equal(ruwiCreate.status, 201);
    const ruwiEntryId = ruwiCreate.json.id as number;
    assert.equal(ruwiCreate.json.branch_id, ruwiBranchId);

    // 5. Branch A attempts cross-branch access via query/body/URL tampering
    const amaratSpoofRead = await api(`/api/receiving?date=${today}&branchId=${ruwiBranchId}`, {
      token: amaratToken,
    });
    assert.equal(amaratSpoofRead.status, 200);
    assert.equal(
      amaratSpoofRead.json.some((e: any) => e.id === ruwiEntryId || e.branch_id === ruwiBranchId),
      false,
      'Branch A must NEVER read Branch B entries even with branchId query param'
    );

    const amaratSpoofCreate = await api('/api/receiving', {
      method: 'POST',
      token: amaratToken,
      body: {
        entry_date: today,
        branch_id: ruwiBranchId, // spoofed to Branch B
        document_number: 'GRN-SPOOF-1',
        product_id: productId,
        unit: 'kg',
        transferred_qty: 10,
        received_qty: 10,
        unit_price: 1.5,
      },
    });
    assert.equal(amaratSpoofCreate.status, 201);
    assert.equal(
      amaratSpoofCreate.json.branch_id,
      amaratBranchId,
      'Server must force created entry to Branch A own branch_id even if body sends Branch B'
    );

    const amaratEditRuwi = await api(`/api/receiving/${ruwiEntryId}`, {
      method: 'PUT',
      token: amaratToken,
      body: {
        document_number: 'HACKED',
        product_id: productId,
        unit: 'kg',
        transferred_qty: 1,
        received_qty: 1,
        unit_price: 1,
      },
    });
    assert.equal(amaratEditRuwi.status, 403, 'Branch A must get 403 editing Branch B entry');

    const amaratDeleteRuwi = await api(`/api/receiving/${ruwiEntryId}`, {
      method: 'DELETE',
      token: amaratToken,
    });
    assert.equal(amaratDeleteRuwi.status, 403, 'Branch A must get 403 deleting Branch B entry');

    // Reports isolation for Branch A
    const dailyReportA = await api(`/api/reports/daily?date=${today}&branchId=${ruwiBranchId}`, {
      token: amaratToken,
    });
    assert.equal(dailyReportA.status, 200);
    assert.equal(
      dailyReportA.json.entries.some((e: any) => e.branch_id === ruwiBranchId),
      false,
      'Daily report for Branch A must not include Branch B entries'
    );

    const consolidatedA = await api(`/api/reports/consolidated?date=${today}&branchId=${ruwiBranchId}`, {
      token: amaratToken,
    });
    assert.equal(consolidatedA.status, 200);
    assert.equal(consolidatedA.json.rows.length, 1);
    assert.equal(consolidatedA.json.rows[0].branch_id, amaratBranchId);

    const monthlyA = await api(`/api/reports/monthly?month=${today.slice(0, 7)}&branchId=${ruwiBranchId}`, {
      token: amaratToken,
    });
    assert.equal(monthlyA.status, 200);
    assert.equal(
      monthlyA.json.byBranch.some((b: any) => b.branch_id === ruwiBranchId),
      false,
      'Monthly report for Branch A must not include Branch B'
    );

    const dashboardA = await api(`/api/reports/dashboard?date=${today}`, { token: amaratToken });
    assert.equal(dashboardA.status, 200);
    assert.equal(dashboardA.json.branchStats.length, 1);
    assert.equal(dashboardA.json.branchStats[0].branch_id, amaratBranchId);

    // Branch A blocked from Admin routes
    const amaratUsersRes = await api('/api/users', { token: amaratToken });
    assert.equal(amaratUsersRes.status, 403);

    // 6. Head Office Manager can see all branches but cannot edit master/users
    const mgrLogin = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'ho_manager', password: hoManagerTempPw },
    });
    assert.equal(mgrLogin.status, 200);
    const mgrNewPw = makeTestPassword();
    await api('/api/auth/change-password', {
      method: 'POST',
      token: mgrLogin.json.token,
      body: { currentPassword: hoManagerTempPw, newPassword: mgrNewPw },
    });
    const mgrConsolidated = await api(`/api/reports/consolidated?date=${today}`, { token: mgrLogin.json.token });
    assert.equal(mgrConsolidated.status, 200);
    assert.equal(mgrConsolidated.json.rows.length, 10, 'Manager sees all 10 branches');

    const mgrUsersForbidden = await api('/api/users', { token: mgrLogin.json.token });
    assert.equal(mgrUsersForbidden.status, 403, 'Manager must not access User Management');

    // 7. Account lockout after 5 failed attempts & 30-min one-time reset link recovery
    for (let i = 0; i < 4; i++) {
      const failRes = await api('/api/auth/login', {
        method: 'POST',
        body: { username: 'branch_al_amerat', password: 'WrongPassword123' },
      });
      assert.equal(failRes.status, 401);
    }
    const fifthFail = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_al_amerat', password: 'WrongPassword123' },
    });
    assert.equal(fifthFail.status, 423, '5th failed login must lock account for 15 minutes');

    const lockedEvenCorrect = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_al_amerat', password: amaratNewPw },
    });
    assert.equal(lockedEvenCorrect.status, 423, 'Even correct password must fail while locked');

    const amaratRecord = usersRes.json.find((u: any) => u.username === 'branch_al_amerat');
    const resetLinkRes = await api(`/api/users/${amaratRecord.id}/reset-link`, {
      method: 'POST',
      token: adminToken,
    });
    assert.equal(resetLinkRes.status, 200);
    const resetToken = resetLinkRes.json.token as string;

    const resetFinalPw = makeTestPassword();
    const useLinkRes = await api('/api/auth/reset-token', {
      method: 'POST',
      body: { token: resetToken, newPassword: resetFinalPw },
    });
    assert.equal(useLinkRes.status, 200, 'One-time reset link should reset password & clear lockout');

    const reuseLinkRes = await api('/api/auth/reset-token', {
      method: 'POST',
      body: { token: resetToken, newPassword: makeTestPassword() },
    });
    assert.equal(reuseLinkRes.status, 400, 'One-time reset link cannot be reused');

    const loginAfterReset = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_al_amerat', password: resetFinalPw },
    });
    assert.equal(loginAfterReset.status, 200);
    assert.equal(loginAfterReset.json.user.must_change_password, false);

    // 8. Deactivated user cannot sign in
    const toggleOff = await api(`/api/users/${amaratRecord.id}/toggle`, {
      method: 'PATCH',
      token: adminToken,
    });
    assert.equal(toggleOff.status, 200);
    const deactivatedLogin = await api('/api/auth/login', {
      method: 'POST',
      body: { username: 'branch_al_amerat', password: resetFinalPw },
    });
    assert.equal(deactivatedLogin.status, 403, 'Deactivated user cannot sign in');

    // 9. Project ZIP export enforces Admin-only auth & excludes secrets/DB/android-app
    const unauthZip = await fetch(`${baseUrl}/api/project/export-zip`);
    assert.equal(unauthZip.status, 401, 'Unauthenticated project ZIP export must return 401');

    const branchZip = await fetch(`${baseUrl}/api/project/export-zip`, {
      headers: { Authorization: `Bearer ${ruwiToken}` },
    });
    assert.equal(branchZip.status, 403, 'Branch user must be forbidden from project ZIP export');

    const mgrZip = await fetch(`${baseUrl}/api/project/export-zip`, {
      headers: { Authorization: `Bearer ${mgrLogin.json.token}` },
    });
    assert.equal(mgrZip.status, 403, 'Manager must be forbidden from project ZIP export');

    const adminZip = await fetch(`${baseUrl}/api/project/export-zip`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    assert.equal(adminZip.status, 200, 'Admin must be able to export clean web app ZIP');
    assert.equal(adminZip.headers.get('content-type'), 'application/zip');
    const zipBytes = Buffer.from(await adminZip.arrayBuffer());
    const JSZipMod = (await import('jszip')).default;
    const loadedZip = await JSZipMod.loadAsync(zipBytes);
    const fileNames = Object.keys(loadedZip.files);
    assert(fileNames.includes('km-trading-web-app/package.json'), 'ZIP must contain package.json');
    assert(fileNames.includes('km-trading-web-app/server.ts'), 'ZIP must contain server.ts');
    assert(fileNames.includes('km-trading-web-app/src/App.tsx'), 'ZIP must contain src/App.tsx');
    assert(
      !fileNames.some((n) => n.includes('/.env') && !n.endsWith('.env.example')),
      'ZIP must not contain .env secrets'
    );
    assert(
      !fileNames.some((n) => n.includes('/data/') || n.endsWith('.db') || n.includes('android-app')),
      'ZIP must exclude live DB files and android-app'
    );

    console.log('ALL BRANCH ISOLATION & AUTH SECURITY TESTS PASSED');
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

runTests().catch((err) => {
  console.error('TEST FAILED:', err);
  process.exit(1);
});
