export type UserRole = 'admin' | 'manager' | 'branch';
export type ProductUnit = 'kg' | 'pcs' | 'pack';
export type ProductCategory = 'Fruit' | 'Vegetable';
export type DayStatus = 'open' | 'locked';

export interface AuthUser {
  id: number;
  username: string;
  full_name: string;
  role: UserRole;
  branch_id: number | null;
  branch_name: string | null;
  email: string;
  phone: string;
  must_change_password: boolean;
  last_login_at: string | null;
  remember_me?: boolean;
  active: number;
}

export interface Branch {
  id: number;
  name: string;
  location: string;
  active: number;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: number;
  barcode: string;
  name: string;
  unit: ProductUnit;
  default_price: number;
  category: ProductCategory;
  active: number;
  transaction_count?: number;
  created_at: string;
  updated_at: string;
}

export interface Reason {
  id: number;
  name: string;
  description: string;
  active: number;
  created_at: string;
  updated_at: string;
}

export interface UserRecord {
  id: number;
  username: string;
  full_name: string;
  role: UserRole;
  branch_id: number | null;
  branch_name: string | null;
  email: string;
  phone: string;
  must_change_password: boolean;
  last_login_at: string | null;
  failed_login_attempts?: number;
  locked_until?: string | null;
  active: number;
  has_password: boolean;
  created_at: string;
  updated_at: string;
}

export interface PasswordResetRequest {
  id: number;
  user_id: number;
  username: string;
  full_name: string;
  role: UserRole;
  branch_name: string | null;
  note: string;
  status: 'pending' | 'resolved' | 'dismissed';
  requested_at: string;
  resolved_at: string | null;
}

export interface ReceivingEntry {
  id: number;
  document_id: number;
  document_number: string;
  entry_date: string;
  branch_id: number;
  branch_name: string;
  product_id: number;
  barcode_snapshot: string;
  product_name_snapshot: string;
  unit_snapshot: ProductUnit;
  category_snapshot: ProductCategory;
  transferred_qty: number;
  received_qty: number;
  difference_qty: number;
  unit_price: number;
  transferred_value: number;
  received_value: number;
  difference_value: number;
  value_overridden: number;
  reason_id: number | null;
  reason_name: string | null;
  remarks: string;
  created_by: number;
  created_by_name: string;
  updated_by: number | null;
  created_at: string;
  updated_at: string;
}

export interface DayLockInfo {
  entry_date: string;
  status: DayStatus;
  auto_locked: boolean;
  locked_by_name: string | null;
  locked_at: string | null;
  reopened_by_name: string | null;
  reopened_at: string | null;
  reopen_reason: string | null;
  server_today: string;
}

export interface UploadPreviewRow {
  rowNumber: number;
  barcode: string;
  product_name: string;
  unit: string;
  default_price: number | null;
  category: string;
  active: number;
  status: 'new' | 'update' | 'invalid';
  errors: string[];
}

export interface UploadConfirmResult {
  total: number;
  added: number;
  updated: number;
  failed: number;
  failedRows: UploadPreviewRow[];
}

export interface AuditLogEntry {
  id: number;
  user_id: number | null;
  username: string;
  action: string;
  entity_type: string;
  entity_id: string;
  old_value_json: string | null;
  new_value_json: string | null;
  note: string | null;
  created_at: string;
}

export interface MasterUploadLogEntry {
  id: number;
  uploaded_by: number;
  uploaded_by_name: string;
  filename: string;
  total_rows: number;
  added_count: number;
  updated_count: number;
  failed_count: number;
  failed_rows_json: string | null;
  created_at: string;
}

export interface DashboardSummary {
  date: string;
  dayStatus: DayStatus;
  alertThresholdPct: number;
  totals: {
    entryCount: number;
    transferredQty: number;
    receivedQty: number;
    differenceQty: number;
    transferredValue: number;
    receivedValue: number;
    differenceValue: number;
    lossPct: number;
  };
  branchStats: Array<{
    branch_id: number;
    branch_name: string;
    branch_location: string;
    entry_count: number;
    transferred_qty: number;
    received_qty: number;
    difference_qty: number;
    transferred_value: number;
    received_value: number;
    difference_value: number;
    loss_pct: number;
    is_alert: boolean;
  }>;
  flaggedEntries: Array<ReceivingEntry & { loss_pct: number }>;
  topShortageProducts: Array<{
    product_id: number;
    barcode: string;
    product_name: string;
    unit: string;
    shortage_count: number;
    total_shortage_qty: number;
    total_loss_value: number;
  }>;
  topReasons: Array<{
    reason_id: number;
    reason_name: string;
    occurrence_count: number;
    total_difference_qty: number;
    total_difference_value: number;
  }>;
}
