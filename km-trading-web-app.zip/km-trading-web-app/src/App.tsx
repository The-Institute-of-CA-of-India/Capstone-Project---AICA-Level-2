import React, { useCallback, useEffect, useState } from 'react';
import {
  BarChart3,
  BookOpen,
  ClipboardList,
  Eye,
  EyeOff,
  FileSpreadsheet,
  FolderKanban,
  KeyRound,
  LogOut,
  Menu,
  Package,
  Settings,
  ShieldAlert,
  Upload,
  X,
} from 'lucide-react';
import { AdminSetupPage } from './components/AdminSetupPage';
import { DashboardPage } from './components/DashboardPage';
import { LoginScreen } from './components/LoginScreen';
import { MasterProductsPage } from './components/MasterProductsPage';
import { MasterUploadPage } from './components/MasterUploadPage';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';
import { ProjectPortfolioPage } from './components/ProjectPortfolioPage';
import { ReceivingPage } from './components/ReceivingPage';
import { ReportsPage } from './components/ReportsPage';
import { UserGuidePage } from './components/UserGuidePage';
import { apiRequest, PASSWORD_POLICY_HINT, setAuthToken, validateClientPassword } from './lib/api';
import type { AuthUser } from './types';

type NavKey = 'receiving' | 'dashboard' | 'reports' | 'products' | 'upload' | 'admin' | 'portfolio' | 'guide';

const IDLE_TIMEOUT_MS = 30 * 60 * 1000;

function getDefaultNav(role: AuthUser['role']): NavKey {
  return role === 'branch' ? 'receiving' : 'dashboard';
}

export default function App() {
  const [bootLoading, setBootLoading] = useState(true);
  const [needsAdminSetup, setNeedsAdminSetup] = useState(false);
  const [sessionNotice, setSessionNotice] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [serverToday, setServerToday] = useState(() =>
    new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date())
  );

  const [activeNav, setActiveNav] = useState<NavKey>('receiving');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [publicPortfolioOpen, setPublicPortfolioOpen] = useState(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('view') === 'portfolio';
  });

  // Forced first-login password change state
  const [forceCurPw, setForceCurPw] = useState('');
  const [forceNewPw, setForceNewPw] = useState('');
  const [forceConfirmPw, setForceConfirmPw] = useState('');
  const [forceError, setForceError] = useState<string | null>(null);
  const [forceSaving, setForceSaving] = useState(false);
  const [forceShowPw, setForceShowPw] = useState(false);

  // Change password modal
  const [pwModalOpen, setPwModalOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [pwError, setPwError] = useState<string | null>(null);
  const [pwSuccess, setPwSuccess] = useState(false);
  const [showModalPw, setShowModalPw] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const hasResetToken = Boolean(params.get('resetToken'));

    async function bootstrap() {
      try {
        if (!hasResetToken) {
          try {
            const me = await apiRequest<{ user: AuthUser; server_today: string }>('/api/auth/me');
            setUser(me.user);
            setServerToday(me.server_today);
            setActiveNav(getDefaultNav(me.user.role));
            return;
          } catch {
            // Not signed in or session expired; check setup status below
          }
        }
        const status = await apiRequest<{ needsAdminSetup: boolean }>('/api/auth/status');
        setNeedsAdminSetup(status.needsAdminSetup);
      } catch {
        setNeedsAdminSetup(false);
      } finally {
        setBootLoading(false);
      }
    }

    bootstrap();
  }, []);

  const handleSignOut = useCallback(async (notice?: string) => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors on sign out
    }
    setAuthToken(null);
    setUser(null);
    setMobileMenuOpen(false);
    setPwModalOpen(false);
    setSessionNotice(notice || null);
  }, []);

  // 30-minute inactivity auto sign-out when Remember Me is NOT selected
  useEffect(() => {
    if (!user || user.remember_me) return;

    let timer: ReturnType<typeof setTimeout> | null = null;
    const resetIdleTimer = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        void handleSignOut('Signed out automatically after 30 minutes of inactivity.');
      }, IDLE_TIMEOUT_MS);
    };

    const events: Array<keyof WindowEventMap> = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'];
    for (const ev of events) {
      window.addEventListener(ev, resetIdleTimer, { passive: true });
    }
    resetIdleTimer();

    return () => {
      if (timer) clearTimeout(timer);
      for (const ev of events) {
        window.removeEventListener(ev, resetIdleTimer);
      }
    };
  }, [user, handleSignOut]);

  function openPwModal() {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
    setPwError(null);
    setPwSuccess(false);
    setShowModalPw(false);
    setPwModalOpen(true);
  }

  function handleAuthenticated(authedUser: AuthUser, today: string) {
    setUser(authedUser);
    setServerToday(today);
    setNeedsAdminSetup(false);
    setSessionNotice(null);
    setForceCurPw('');
    setForceNewPw('');
    setForceConfirmPw('');
    setForceError(null);
    setActiveNav(getDefaultNav(authedUser.role));
  }

  async function handleForcePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setForceError(null);
    if (!forceCurPw) {
      setForceError('Enter your current temporary password.');
      return;
    }
    const pwErr = validateClientPassword(forceNewPw);
    if (pwErr) {
      setForceError(pwErr);
      return;
    }
    if (forceNewPw !== forceConfirmPw) {
      setForceError('New passwords do not match.');
      return;
    }
    setForceSaving(true);
    try {
      const res = await apiRequest<{ ok: boolean; user: AuthUser }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword: forceCurPw, newPassword: forceNewPw }),
      });
      setUser(res.user);
      setActiveNav(getDefaultNav(res.user.role));
      setForceCurPw('');
      setForceNewPw('');
      setForceConfirmPw('');
    } catch (err) {
      setForceError(err instanceof Error ? err.message : 'Failed to update password.');
    } finally {
      setForceSaving(false);
    }
  }

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwError(null);
    setPwSuccess(false);
    const pwErr = validateClientPassword(newPassword);
    if (pwErr) {
      setPwError(pwErr);
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPwError('New passwords do not match.');
      return;
    }
    try {
      const res = await apiRequest<{ ok: boolean; user?: AuthUser }>('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (res.user) {
        setUser(res.user);
      }
      setPwSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setTimeout(() => {
        setPwModalOpen(false);
        setPwSuccess(false);
      }, 1200);
    } catch (err) {
      setPwError(err instanceof Error ? err.message : 'Failed to change password.');
    }
  }

  if (bootLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-600">
        Loading KM Trading...
      </div>
    );
  }

  function setPortfolioQuery(open: boolean) {
    setPublicPortfolioOpen(open);
    const url = new URL(window.location.href);
    if (open) {
      url.searchParams.set('view', 'portfolio');
    } else {
      url.searchParams.delete('view');
    }
    window.history.replaceState({}, '', url.pathname + url.search);
  }

  if (!user) {
    if (publicPortfolioOpen) {
      return (
        <ProjectPortfolioPage
          isAuthenticated={false}
          onBackToSignIn={() => setPortfolioQuery(false)}
        />
      );
    }
    return (
      <LoginScreen
        needsAdminSetup={needsAdminSetup}
        sessionNotice={sessionNotice}
        onAuthenticated={handleAuthenticated}
        onOpenPortfolio={() => setPortfolioQuery(true)}
      />
    );
  }

  // Mandatory first-login temporary password change gate
  if (user.must_change_password) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-4 py-10">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-5">
          <div className="pb-4 border-b border-slate-100">
            <img
              src="/assets/aistudio/image_ea5d3a57.png"
              alt="KM Trading"
              className="h-10 w-auto object-contain mb-3"
            />
            <div className="flex items-center gap-2 text-amber-800 text-xs font-semibold mb-1">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>Password Change Required</span>
            </div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Set Your Personal Password</h1>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Signed in as <strong className="font-mono text-slate-900">{user.username}</strong>
              {user.branch_name ? ` (${user.branch_name})` : ''}. Because you signed in with a temporary password, you
              must choose a personal password before accessing receiving entries or reports.
            </p>
          </div>

          {forceError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700" role="alert">
              {forceError}
            </div>
          )}

          <form onSubmit={handleForcePasswordSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Current Temporary Password</label>
              <div className="relative">
                <input
                  type={forceShowPw ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={forceCurPw}
                  onChange={(e) => setForceCurPw(e.target.value)}
                  className="w-full min-h-[44px] pl-3.5 pr-11 py-2 text-sm border border-slate-300 rounded-lg"
                />
                <button
                  type="button"
                  onClick={() => setForceShowPw(!forceShowPw)}
                  aria-label={forceShowPw ? 'Hide passwords' : 'Show passwords'}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 min-h-[36px] min-w-[36px] inline-flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  {forceShowPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">New Password</label>
              <input
                type={forceShowPw ? 'text' : 'password'}
                required
                minLength={8}
                autoComplete="new-password"
                value={forceNewPw}
                onChange={(e) => setForceNewPw(e.target.value)}
                placeholder="Min 8 chars (letters & numbers)"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Confirm New Password</label>
              <input
                type={forceShowPw ? 'text' : 'password'}
                required
                minLength={8}
                autoComplete="new-password"
                value={forceConfirmPw}
                onChange={(e) => setForceConfirmPw(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <p className="text-xs text-slate-500">{PASSWORD_POLICY_HINT}</p>

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={() => void handleSignOut()}
                className="min-h-[42px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-lg cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
              <button
                type="submit"
                disabled={forceSaving}
                className="min-h-[42px] inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                {forceSaving ? 'Saving...' : 'Save Password & Continue'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  const navItems: Array<{ key: NavKey; label: string; icon: React.ComponentType<{ className?: string }>; visible: boolean }> = [
    { key: 'receiving', label: 'Daily Receiving', icon: ClipboardList, visible: true },
    { key: 'dashboard', label: 'Variance Dashboard', icon: BarChart3, visible: true },
    { key: 'reports', label: 'Reports & Export', icon: FileSpreadsheet, visible: true },
    { key: 'products', label: 'Products Master', icon: Package, visible: user.role === 'admin' || user.role === 'manager' },
    { key: 'upload', label: 'Master Data Upload', icon: Upload, visible: user.role === 'admin' },
    {
      key: 'admin',
      label: user.role === 'admin' ? 'Admin Setup & Audit' : 'Branches & Reasons',
      icon: Settings,
      visible: user.role === 'admin' || user.role === 'manager',
    },
    { key: 'portfolio', label: 'Project Portfolio', icon: FolderKanban, visible: true },
    { key: 'guide', label: 'User Guide', icon: BookOpen, visible: true },
  ];

  const visibleNav = navItems.filter((n) => n.visible);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Mobile Top Bar (compact <= 60px, hidden on desktop & print) */}
      <header className="no-print lg:hidden sticky top-0 z-30 bg-white border-b border-slate-200 px-3 h-14 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <img
            src="/assets/aistudio/image_ea5d3a57.png"
            alt="KM Trading"
            className="h-8 w-auto object-contain shrink-0"
          />
          <div className="min-w-0">
            <div className="font-bold text-slate-900 tracking-tight whitespace-nowrap text-sm leading-tight">
              KM Trading
            </div>
            {user.branch_name && (
              <div className="text-[11px] text-emerald-700 font-medium truncate">{user.branch_name}</div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <PWAInstallButton compact />
          <button
            type="button"
            onClick={() => void handleSignOut()}
            className="min-h-[38px] inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-lg cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Sign Out</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="no-print lg:hidden fixed inset-0 top-14 z-40 bg-slate-900/40" onClick={() => setMobileMenuOpen(false)}>
          <aside
            className="w-72 max-w-[85vw] h-full bg-white border-r border-slate-200 p-4 flex flex-col justify-between overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <nav className="space-y-1">
              {visibleNav.map((item) => {
                const Icon = item.icon;
                const active = activeNav === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      setActiveNav(item.key);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full min-h-[44px] flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                      active ? 'bg-emerald-700 text-white' : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="pt-4 border-t border-slate-200 space-y-2">
              <div className="px-2 text-xs text-slate-600">
                <div className="font-semibold text-slate-900">{user.full_name}</div>
                <div className="capitalize">
                  {user.role === 'admin' ? 'Head Office Admin' : user.role === 'manager' ? 'Head Office Manager' : 'Branch User'}
                  {user.branch_name ? ` · ${user.branch_name}` : ''}
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  openPwModal();
                }}
                className="w-full min-h-[44px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                Change Password
              </button>
              <button
                type="button"
                onClick={() => void handleSignOut()}
                className="w-full min-h-[44px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-red-700 hover:bg-red-50 rounded-lg cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="no-print hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-white border-r border-slate-200 min-h-screen sticky top-0 h-screen justify-between p-4">
        <div className="space-y-6">
          <div className="px-2 pt-1 pb-4 border-b border-slate-100">
            <img
              src="/assets/aistudio/image_ea5d3a57.png"
              alt="KM Trading — Symbol Of Confidence"
              className="h-10 w-auto object-contain mb-2"
            />
            <div className="text-base font-bold text-slate-900 tracking-tight whitespace-nowrap">KM Trading</div>
            <p className="text-xs text-slate-500 mt-0.5">Fruits &amp; Vegetables Receiving</p>
          </div>

          <nav className="space-y-1">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const active = activeNav === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setActiveNav(item.key)}
                  className={`w-full min-h-[40px] flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    active ? 'bg-emerald-700 text-white' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="pt-4 border-t border-slate-200 space-y-2">
          <div className="px-2">
            <div className="text-sm font-semibold text-slate-900 truncate">{user.full_name}</div>
            <div className="text-xs text-slate-500 truncate">
              {user.role === 'admin' ? 'Head Office Admin' : user.role === 'manager' ? 'Head Office Manager' : 'Branch User'}
              {user.branch_name ? ` · ${user.branch_name}` : ''}
            </div>
          </div>
          <div className="space-y-1.5 pt-1">
            <PWAInstallButton fullWidth />
            <button
              type="button"
              onClick={openPwModal}
              className="w-full min-h-[38px] inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              Change Password
            </button>
            <button
              type="button"
              onClick={() => void handleSignOut()}
              className="w-full min-h-[38px] inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100 rounded-lg cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
        {activeNav === 'receiving' && <ReceivingPage user={user} serverToday={serverToday} />}
        {activeNav === 'dashboard' && <DashboardPage serverToday={serverToday} />}
        {activeNav === 'reports' && <ReportsPage user={user} serverToday={serverToday} />}
        {activeNav === 'products' && <MasterProductsPage user={user} />}
        {activeNav === 'upload' && user.role === 'admin' && <MasterUploadPage />}
        {activeNav === 'admin' && (user.role === 'admin' || user.role === 'manager') && <AdminSetupPage user={user} />}
        {activeNav === 'portfolio' && (
          <ProjectPortfolioPage
            isAuthenticated={true}
            userRole={user.role}
            onOpenReceiving={() => setActiveNav('receiving')}
          />
        )}
        {activeNav === 'guide' && <UserGuidePage />}
      </main>

      {/* Change Password Modal */}
      {pwModalOpen && (
        <div className="no-print fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-sm w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">Change Password</h3>
              <button type="button" onClick={() => setPwModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            {pwError && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">{pwError}</div>}
            {pwSuccess && (
              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-700">
                Password updated successfully.
              </div>
            )}
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-medium text-slate-700">Current Password</label>
                  <button
                    type="button"
                    onClick={() => setShowModalPw(!showModalPw)}
                    className="text-[11px] font-medium text-emerald-700 hover:underline cursor-pointer"
                  >
                    {showModalPw ? 'Hide' : 'Show'}
                  </button>
                </div>
                <input
                  type={showModalPw ? 'text' : 'password'}
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">New Password</label>
                <input
                  type={showModalPw ? 'text' : 'password'}
                  required
                  minLength={8}
                  autoComplete="new-password"
                  placeholder="Min 8 chars (letters & numbers)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Confirm New Password</label>
                <input
                  type={showModalPw ? 'text' : 'password'}
                  required
                  minLength={8}
                  autoComplete="new-password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <p className="text-[11px] text-slate-500">{PASSWORD_POLICY_HINT}</p>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPwModalOpen(false)}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <OfflineIndicator />
    </div>
  );
}
