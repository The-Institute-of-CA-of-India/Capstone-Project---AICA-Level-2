let inMemoryToken: string | null = null;

export function setAuthToken(token: string | null): void {
  inMemoryToken = token;
}

export function getAuthToken(): string | null {
  return inMemoryToken;
}

export const PASSWORD_POLICY_HINT = 'At least 8 characters with at least one letter and one number.';

export function validateClientPassword(password: string): string | null {
  if (!password || password.length < 8) {
    return 'Password must be at least 8 characters long.';
  }
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    return 'Password must contain at least one letter and one number.';
  }
  return null;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }
  headers.set('X-Requested-With', 'XMLHttpRequest');
  if (inMemoryToken) {
    headers.set('Authorization', `Bearer ${inMemoryToken}`);
  }

  const res = await fetch(path, { ...options, headers, credentials: 'include' });
  const contentType = res.headers.get('content-type') || '';

  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    if (contentType.includes('application/json')) {
      const data = (await res.json().catch(() => null)) as { error?: string } | null;
      if (data?.error) msg = data.error;
    }
    throw new ApiError(msg, res.status);
  }

  if (contentType.includes('application/json')) {
    return (await res.json()) as T;
  }
  return (await res.text()) as unknown as T;
}

export async function apiDownload(path: string, filename: string): Promise<void> {
  const headers = new Headers();
  headers.set('X-Requested-With', 'XMLHttpRequest');
  if (inMemoryToken) {
    headers.set('Authorization', `Bearer ${inMemoryToken}`);
  }
  const res = await fetch(path, { headers, credentials: 'include' });
  if (!res.ok) {
    throw new ApiError(`Download failed (${res.status})`, res.status);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function formatQty(val: number, unit?: string): string {
  const rounded = Math.round((val + Number.EPSILON) * 1000) / 1000;
  const formatted =
    (unit === 'pcs' || unit === 'pack' || unit === 'piece') && Number.isInteger(rounded)
      ? rounded.toLocaleString('en-US')
      : rounded.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 3 });
  return formatted;
}

export function formatMoney(val: number): string {
  return val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatPct(val: number): string {
  return `${val.toFixed(2)}%`;
}
