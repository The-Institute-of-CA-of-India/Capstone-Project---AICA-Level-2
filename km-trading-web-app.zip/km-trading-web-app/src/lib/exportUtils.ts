import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export interface ExportColumn {
  header: string;
  key: string;
  align?: 'left' | 'right';
}

export function exportToExcel(
  filename: string,
  sheetName: string,
  columns: ExportColumn[],
  rows: Array<Record<string, unknown>>
): void {
  const mapped = rows.map((row) => {
    const obj: Record<string, unknown> = {};
    for (const col of columns) {
      obj[col.header] = row[col.key] ?? '';
    }
    return obj;
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(mapped);
  XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
  XLSX.writeFile(wb, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}

export function exportToCsv(
  filename: string,
  columns: ExportColumn[],
  rows: Array<Record<string, unknown>>
): void {
  const mapped = rows.map((row) => {
    const obj: Record<string, unknown> = {};
    for (const col of columns) {
      obj[col.header] = row[col.key] ?? '';
    }
    return obj;
  });

  const ws = XLSX.utils.json_to_sheet(mapped);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function exportToPdf(options: {
  filename: string;
  title: string;
  subtitle: string;
  columns: ExportColumn[];
  rows: Array<Record<string, unknown>>;
  totalsRow?: Record<string, unknown>;
}): void {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text('KM Trading', 40, 38);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.text(options.title, 40, 56);

  doc.setFontSize(9);
  doc.setTextColor(90, 95, 105);
  doc.text(options.subtitle, 40, 72);
  doc.setTextColor(0, 0, 0);

  const head = [options.columns.map((c) => c.header)];
  const body = options.rows.map((r) => options.columns.map((c) => String(r[c.key] ?? '')));
  if (options.totalsRow) {
    body.push(options.columns.map((c) => String(options.totalsRow![c.key] ?? '')));
  }

  const columnStyles: Record<number, { halign: 'left' | 'right' }> = {};
  options.columns.forEach((c, idx) => {
    columnStyles[idx] = { halign: c.align || 'left' };
  });

  autoTable(doc, {
    startY: 86,
    head,
    body,
    theme: 'grid',
    styles: { fontSize: 8, cellPadding: 4 },
    headStyles: { fillColor: [15, 23, 42], textColor: 255, fontStyle: 'bold' },
    columnStyles,
    didParseCell: (data) => {
      if (options.totalsRow && data.section === 'body' && data.row.index === body.length - 1) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [241, 245, 249];
      }
    },
  });

  doc.save(options.filename.endsWith('.pdf') ? options.filename : `${options.filename}.pdf`);
}
