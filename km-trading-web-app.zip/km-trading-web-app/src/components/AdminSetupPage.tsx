import React, { useCallback, useEffect, useState } from 'react';
import {
  Copy,
  Download,
  Edit3,
  Eye,
  EyeOff,
  KeyRound,
  Link2,
  Plus,
  Power,
  Printer,
  Save,
  Search,
  ShieldCheck,
  X,
} from 'lucide-react';
import { apiDownload, apiRequest, PASSWORD_POLICY_HINT, validateClientPassword } from '../lib/api';
import type { AuditLogEntry, AuthUser, Branch, PasswordResetRequest, Reason, UserRecord, UserRole } from '../types';

interface AdminSetupPageProps {
  user: AuthUser;
}

type AdminTab = 'branches' | 'reasons' | 'users' | 'settings' | 'audit';

interface BulkCredentialItem {
  id: number;
  username: string;
  full_name: string;
  role: string;
  branch_name: string | null;
  temp_password: string;
}

export function AdminSetupPage({ user }: AdminSetupPageProps) {
  const isAdmin = user.role === 'admin';
  const [tab, setTab] = useState<AdminTab>('branches');
  const [branches, setBranches] = useState<Branch[]>([]);
  const [reasons, setReasons] = useState<Reason[]>([]);
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [resetRequests, setResetRequests] = useState<PasswordResetRequest[]>([]);
  const [thresholdPct, setThresholdPct] = useState('5');
  const [companyName, setCompanyName] = useState('KM Trading');
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  const [auditSearch, setAuditSearch] = useState('');
  const [auditAction, setAuditAction] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Branch modal
  const [branchModal, setBranchModal] = useState<{ open: boolean; editing: Branch | null }>({ open: false, editing: null });
  const [bName, setBName] = useState('');
  const [bLocation, setBLocation] = useState('');

  // Reason modal
  const [reasonModal, setReasonModal] = useState<{ open: boolean; editing: Reason | null }>({ open: false, editing: null });
  const [rName, setRName] = useState('');
  const [rDesc, setRDesc] = useState('');

  // User modal
  const [userModal, setUserModal] = useState<{ open: boolean; editing: UserRecord | null }>({ open: false, editing: null });
  const [uUsername, setUUsername] = useState('');
  const [uFullName, setUFullName] = useState('');
  const [uPassword, setUPassword] = useState('');
  const [uShowPassword, setUShowPassword] = useState(false);
  const [uEmail, setUEmail] = useState('');
  const [uPhone, setUPhone] = useState('');
  const [uRole, setURole] = useState<UserRole>('branch');
  const [uBranchId, setUBranchId] = useState('');

  // Reset password & 30-min link modal
  const [resetModalUser, setResetModalUser] = useState<UserRecord | null>(null);
  const [resetPasswordVal, setResetPasswordVal] = useState('');
  const [resetShowPw, setResetShowPw] = useState(false);
  const [generatedResetLink, setGeneratedResetLink] = useState<string | null>(null);
  const [resetLinkExpires, setResetLinkExpires] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Bulk issued credentials modal
  const [bulkCredentials, setBulkCredentials] = useState<BulkCredentialItem[] | null>(null);
  const [bulkLoading, setBulkLoading] = useState(false);
  const [exportingZip, setExportingZip] = useState(false);

  const loadData = useCallback(async () => {
    setError(null);
    try {
      const [b, r, s] = await Promise.all([
        apiRequest<Branch[]>('/api/branches'),
        apiRequest<Reason[]>('/api/reasons'),
        apiRequest<{ alert_threshold_pct: number; company_name: string }>('/api/settings'),
      ]);
      setBranches(b);
      setReasons(r);
      setThresholdPct(String(s.alert_threshold_pct));
      setCompanyName(s.company_name);

      if (isAdmin) {
        const [uList, aList, reqList] = await Promise.all([
          apiRequest<UserRecord[]>('/api/users'),
          apiRequest<AuditLogEntry[]>(
            `/api/audit-logs?search=${encodeURIComponent(auditSearch)}&action=${encodeURIComponent(auditAction)}`
          ),
          apiRequest<PasswordResetRequest[]>('/api/password-reset-requests'),
        ]);
        setUsers(uList);
        setAuditLogs(aList);
        setResetRequests(reqList);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load administration data.');
    }
  }, [isAdmin, auditSearch, auditAction]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Branch handlers
  async function saveBranch(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      if (branchModal.editing) {
        await apiRequest(`/api/branches/${branchModal.editing.id}`, {
          method: 'PUT',
          body: JSON.stringify({ name: bName.trim(), location: bLocation.trim() }),
        });
        setSuccessMsg('Branch updated.');
      } else {
        await apiRequest('/api/branches', {
          method: 'POST',
          body: JSON.stringify({ name: bName.trim(), location: bLocation.trim() }),
        });
        setSuccessMsg('Branch created.');
      }
      setBranchModal({ open: false, editing: null });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save branch.');
    }
  }

  async function toggleBranch(b: Branch) {
    try {
      await apiRequest(`/api/branches/${b.id}/toggle`, { method: 'PATCH' });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to toggle branch.');
    }
  }

  // Reason handlers
  async function saveReason(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      if (reasonModal.editing) {
        await apiRequest(`/api/reasons/${reasonModal.editing.id}`, {
          method: 'PUT',
          body: JSON.stringify({ name: rName.trim(), description: rDesc.trim() }),
        });
        setSuccessMsg('Reason updated.');
      } else {
        await apiRequest('/api/reasons', {
          method: 'POST',
          body: JSON.stringify({ name: rName.trim(), description: rDesc.trim() }),
        });
        setSuccessMsg('Reason added.');
      }
      setReasonModal({ open: false, editing: null });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save reason.');
    }
  }

  async function toggleReason(r: Reason) {
    try {
      await apiRequest(`/api/reasons/${r.id}/toggle`, { method: 'PATCH' });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to toggle reason.');
    }
  }

  // User handlers
  async function saveUser(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!userModal.editing) {
      const pwErr = validateClientPassword(uPassword);
      if (pwErr) {
        setError(pwErr);
        return;
      }
    }
    try {
      if (userModal.editing) {
        await apiRequest(`/api/users/${userModal.editing.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            full_name: uFullName.trim(),
            email: uEmail.trim(),
            phone: uPhone.trim(),
            role: uRole,
            branch_id: uRole === 'branch' ? Number(uBranchId) : null,
          }),
        });
        setSuccessMsg('User updated.');
      } else {
        await apiRequest('/api/users', {
          method: 'POST',
          body: JSON.stringify({
            username: uUsername.trim(),
            full_name: uFullName.trim(),
            email: uEmail.trim(),
            phone: uPhone.trim(),
            password: uPassword,
            role: uRole,
            branch_id: uRole === 'branch' ? Number(uBranchId) : null,
          }),
        });
        setSuccessMsg('User created with temporary password (must change on first sign-in).');
      }
      setUserModal({ open: false, editing: null });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save user.');
    }
  }

  async function handleResetPassword(e: React.FormEvent) {
    e.preventDefault();
    if (!resetModalUser) return;
    setError(null);
    const pwErr = validateClientPassword(resetPasswordVal);
    if (pwErr) {
      setError(pwErr);
      return;
    }
    try {
      await apiRequest(`/api/users/${resetModalUser.id}/reset-password`, {
        method: 'POST',
        body: JSON.stringify({ password: resetPasswordVal }),
      });
      setSuccessMsg(`Temporary password set for ${resetModalUser.username}. They must change it on next sign-in.`);
      setResetModalUser(null);
      setResetPasswordVal('');
      setGeneratedResetLink(null);
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset password.');
    }
  }

  async function handleGenerateResetLink() {
    if (!resetModalUser) return;
    setError(null);
    try {
      const res = await apiRequest<{ ok: boolean; token: string; expires_at: string }>(
        `/api/users/${resetModalUser.id}/reset-link`,
        { method: 'POST' }
      );
      const url = `${window.location.origin}/?resetToken=${encodeURIComponent(res.token)}`;
      setGeneratedResetLink(url);
      setResetLinkExpires(new Date(res.expires_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate reset link.');
    }
  }

  async function handleBulkBranchLogins(reissueAll = false) {
    setError(null);
    setBulkLoading(true);
    try {
      const res = await apiRequest<{ issued: BulkCredentialItem[] }>('/api/users/bulk-branch-logins', {
        method: 'POST',
        body: JSON.stringify({ reissueAll }),
      });
      if (res.issued.length === 0) {
        setSuccessMsg('All active branch accounts and ho_manager already have passwords configured.');
      } else {
        setBulkCredentials(res.issued);
        setSuccessMsg(`Generated temporary passwords for ${res.issued.length} staff account(s).`);
      }
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to issue branch logins.');
    } finally {
      setBulkLoading(false);
    }
  }

  async function copyToClipboard(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedText(label);
      setTimeout(() => setCopiedText(null), 2000);
    } catch {
      setError('Could not copy automatically. Please select and copy manually.');
    }
  }

  function downloadCredentialsCsv(items: BulkCredentialItem[]) {
    const header = ['Username', 'Full Name', 'Role', 'Branch', 'Temporary Password'];
    const lines = [
      header.join(','),
      ...items.map((i) =>
        [i.username, i.full_name, i.role, i.branch_name || 'Head Office', i.temp_password]
          .map((v) => `"${String(v).replace(/"/g, '""')}"`)
          .join(',')
      ),
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'km_trading_temp_credentials.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function dismissResetRequest(reqItem: PasswordResetRequest) {
    setError(null);
    try {
      await apiRequest(`/api/password-reset-requests/${reqItem.id}/dismiss`, { method: 'POST' });
      setSuccessMsg(`Dismissed password reset request for ${reqItem.username}.`);
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to dismiss request.');
    }
  }

  async function toggleUser(u: UserRecord) {
    try {
      await apiRequest(`/api/users/${u.id}/toggle`, { method: 'PATCH' });
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user status.');
    }
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiRequest('/api/settings', {
        method: 'PUT',
        body: JSON.stringify({
          alert_threshold_pct: Number(thresholdPct),
          company_name: companyName.trim(),
        }),
      });
      setSuccessMsg('Alert threshold & settings updated.');
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save settings.');
    }
  }

  async function handleDownloadProjectZip() {
    setError(null);
    setExportingZip(true);
    try {
      await apiDownload('/api/project/export-zip', 'km-trading-web-app.zip');
      setSuccessMsg('Web application source ZIP downloaded.');
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to download project ZIP.');
    } finally {
      setExportingZip(false);
    }
  }

  const pendingPasswordCount = users.filter((u) => u.active === 1 && !u.has_password).length;

  const availableTabs: Array<{ id: AdminTab; label: string }> = isAdmin
    ? [
        { id: 'branches', label: 'Branches' },
        { id: 'reasons', label: 'Variance Reasons' },
        {
          id: 'users',
          label: resetRequests.length > 0 ? `Users & Roles (${resetRequests.length})` : 'Users & Roles',
        },
        { id: 'settings', label: 'Alert Settings' },
        { id: 'audit', label: 'Audit Log' },
      ]
    : [
        { id: 'branches', label: 'Branches' },
        { id: 'reasons', label: 'Variance Reasons' },
      ];

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {isAdmin ? 'Master Setup, Users & Audit Log' : 'Branches & Reasons Directory'}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {isAdmin
              ? 'Manage locations, variance reasons, branch logins, alert threshold, and audit trail'
              : 'Read-only directory of branches and variance reasons'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {availableTabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                tab === t.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">{error}</div>
      )}
      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800 flex items-center justify-between">
          <span>{successMsg}</span>
          <button type="button" onClick={() => setSuccessMsg(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* BRANCHES */}
      {tab === 'branches' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-slate-900">Branches / Sales Locations</h2>
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setBName('');
                  setBLocation('');
                  setBranchModal({ open: true, editing: null });
                }}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Branch
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Branch Name</th>
                  <th className="py-2.5 px-4">Location</th>
                  <th className="py-2.5 px-4">Status</th>
                  {isAdmin && <th className="py-2.5 px-4 text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {branches.map((b) => (
                  <tr key={b.id} className={b.active === 0 ? 'bg-slate-50 text-slate-500' : 'hover:bg-slate-50'}>
                    <td className="py-2.5 px-4 font-medium text-slate-900">{b.name}</td>
                    <td className="py-2.5 px-4 text-xs text-slate-600">{b.location || '—'}</td>
                    <td className="py-2.5 px-4 text-xs font-semibold">
                      <span className={b.active === 1 ? 'text-emerald-700' : 'text-slate-500'}>
                        {b.active === 1 ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => {
                            setBName(b.name);
                            setBLocation(b.location);
                            setBranchModal({ open: true, editing: b });
                          }}
                          className="p-2 text-slate-600 hover:text-emerald-700 rounded-md cursor-pointer"
                          title="Edit"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleBranch(b)}
                          className="p-2 text-slate-600 hover:text-amber-700 rounded-md cursor-pointer"
                          title={b.active === 1 ? 'Deactivate' : 'Reactivate'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REASONS */}
      {tab === 'reasons' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between gap-3">
            <h2 className="text-base font-semibold text-slate-900">Variance Reasons</h2>
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setRName('');
                  setRDesc('');
                  setReasonModal({ open: true, editing: null });
                }}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Reason
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Reason Name</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">Status</th>
                  {isAdmin && <th className="py-2.5 px-4 text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {reasons.map((r) => (
                  <tr key={r.id} className={r.active === 0 ? 'bg-slate-50 text-slate-500' : 'hover:bg-slate-50'}>
                    <td className="py-2.5 px-4 font-medium text-slate-900">{r.name}</td>
                    <td className="py-2.5 px-4 text-xs text-slate-600">{r.description || '—'}</td>
                    <td className="py-2.5 px-4 text-xs font-semibold">
                      <span className={r.active === 1 ? 'text-emerald-700' : 'text-slate-500'}>
                        {r.active === 1 ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => {
                            setRName(r.name);
                            setRDesc(r.description);
                            setReasonModal({ open: true, editing: r });
                          }}
                          className="p-2 text-slate-600 hover:text-emerald-700 rounded-md cursor-pointer"
                          title="Edit"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleReason(r)}
                          className="p-2 text-slate-600 hover:text-amber-700 rounded-md cursor-pointer"
                          title={r.active === 1 ? 'Deactivate' : 'Reactivate'}
                        >
                          <Power className="w-4 h-4" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* USERS */}
      {tab === 'users' && isAdmin && (
        <div className="space-y-4">
          {pendingPasswordCount > 0 && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold text-emerald-950">
                  {pendingPasswordCount} Pre-seeded Branch / Manager Account(s) Awaiting Initial Password
                </h2>
                <p className="text-xs text-emerald-800 mt-0.5">
                  Issue one-time temporary passwords for all branch logins and Head Office Manager in a single step. Staff
                  will be required to set their own password on first sign-in.
                </p>
              </div>
              <button
                type="button"
                disabled={bulkLoading}
                onClick={() => handleBulkBranchLogins(false)}
                className="min-h-[40px] shrink-0 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                {bulkLoading ? 'Generating...' : 'Issue All Pending Temp Passwords'}
              </button>
            </div>
          )}

          {resetRequests.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 sm:p-5 space-y-3">
              <div>
                <h2 className="text-sm font-bold text-amber-950">
                  Pending Forgot Password Requests ({resetRequests.length})
                </h2>
                <p className="text-xs text-amber-800 mt-0.5">
                  Verify the staff member and issue a temporary password or 30-minute one-time reset link.
                </p>
              </div>
              <div className="divide-y divide-amber-200 bg-white border border-amber-200 rounded-lg">
                {resetRequests.map((reqItem) => {
                  const matchedUser = users.find((u) => u.id === reqItem.user_id);
                  return (
                    <div
                      key={reqItem.id}
                      className="p-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                    >
                      <div className="space-y-0.5 text-xs">
                        <div className="font-semibold text-slate-900">
                          <span className="font-mono">{reqItem.username}</span> · {reqItem.full_name} (
                          <span className="capitalize">{reqItem.role}</span>
                          {reqItem.branch_name ? ` · ${reqItem.branch_name}` : ''})
                        </div>
                        <div className="text-slate-500 font-mono">{reqItem.requested_at}</div>
                        {reqItem.note && <div className="text-slate-700">Note: {reqItem.note}</div>}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {matchedUser && (
                          <button
                            type="button"
                            onClick={() => {
                              setResetPasswordVal('');
                              setGeneratedResetLink(null);
                              setResetLinkExpires(null);
                              setResetModalUser(matchedUser);
                            }}
                            className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg cursor-pointer"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                            Reset / Link
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => dismissResetRequest(reqItem)}
                          className="min-h-[36px] px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold text-slate-900">User Accounts &amp; Branch Assignments</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Deactivated accounts keep full receiving audit history and are blocked from signing in.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={bulkLoading}
                  onClick={() => handleBulkBranchLogins(false)}
                  className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Sync Branch Logins
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUUsername('');
                    setUFullName('');
                    setUPassword('');
                    setUShowPassword(false);
                    setUEmail('');
                    setUPhone('');
                    setURole('branch');
                    setUBranchId(branches[0] ? String(branches[0].id) : '');
                    setUserModal({ open: true, editing: null });
                  }}
                  className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Add User
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-4">Username</th>
                    <th className="py-2.5 px-4">Full Name</th>
                    <th className="py-2.5 px-4">Role</th>
                    <th className="py-2.5 px-4">Assigned Branch</th>
                    <th className="py-2.5 px-4">Email / Phone</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4">Last Login</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {users.map((u) => {
                    const isLockedNow = u.locked_until && Date.parse(u.locked_until) > Date.now();
                    return (
                      <tr key={u.id} className={u.active === 0 ? 'bg-slate-50 text-slate-500' : 'hover:bg-slate-50'}>
                        <td className="py-2.5 px-4 font-mono text-xs font-semibold text-slate-900">{u.username}</td>
                        <td className="py-2.5 px-4 text-slate-900">{u.full_name}</td>
                        <td className="py-2.5 px-4 text-xs capitalize">
                          {u.role === 'admin' ? 'Head Office Admin' : u.role === 'manager' ? 'Head Office Manager' : 'Branch User'}
                        </td>
                        <td className="py-2.5 px-4 text-xs text-slate-600">{u.branch_name || 'All Branches'}</td>
                        <td className="py-2.5 px-4 text-xs text-slate-600">
                          {u.email || u.phone ? (
                            <div className="space-y-0.5">
                              {u.email && <div className="font-mono text-[11px]">{u.email}</div>}
                              {u.phone && <div className="font-mono text-[11px] text-slate-500">{u.phone}</div>}
                            </div>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-xs font-semibold">
                          <div className={u.active === 1 ? 'text-emerald-700' : 'text-slate-500'}>
                            {u.active === 1 ? 'Active' : 'Inactive'}
                          </div>
                          {!u.has_password && <div className="text-[11px] font-normal text-amber-700">Pending Password</div>}
                          {u.has_password && u.must_change_password && (
                            <div className="text-[11px] font-normal text-amber-700">Temp PW Required</div>
                          )}
                          {isLockedNow && <div className="text-[11px] font-normal text-red-700">15m Lockout</div>}
                        </td>
                        <td className="py-2.5 px-4 text-xs font-mono text-slate-600 whitespace-nowrap">
                          {u.last_login_at ? u.last_login_at.slice(0, 16).replace('T', ' ') : 'Never'}
                        </td>
                        <td className="py-2.5 px-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setUUsername(u.username);
                              setUFullName(u.full_name);
                              setUEmail(u.email || '');
                              setUPhone(u.phone || '');
                              setURole(u.role);
                              setUBranchId(u.branch_id ? String(u.branch_id) : '');
                              setUserModal({ open: true, editing: u });
                            }}
                            className="p-2 text-slate-600 hover:text-emerald-700 rounded-md cursor-pointer"
                            title="Edit user"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setResetPasswordVal('');
                              setResetShowPw(false);
                              setGeneratedResetLink(null);
                              setResetLinkExpires(null);
                              setResetModalUser(u);
                            }}
                            className="p-2 text-slate-600 hover:text-amber-700 rounded-md cursor-pointer"
                            title="Reset password or generate reset link"
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>
                          {u.id !== user.id && (
                            <button
                              type="button"
                              onClick={() => toggleUser(u)}
                              className="p-2 text-slate-600 hover:text-red-700 rounded-md cursor-pointer"
                              title={u.active === 1 ? 'Deactivate' : 'Reactivate'}
                            >
                              <Power className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SETTINGS */}
      {tab === 'settings' && isAdmin && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          <form onSubmit={saveSettings} className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Alert Threshold &amp; Company Settings</h2>
              <p className="text-xs text-slate-500 mt-1">
                Any branch or entry with loss percentage exceeding the threshold is flagged on the dashboard and consolidated report.
              </p>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Company Name (for Reports &amp; Print)</label>
              <input
                type="text"
                required
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Loss Alert Threshold (%)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                required
                value={thresholdPct}
                onChange={(e) => setThresholdPct(e.target.value)}
                className="w-full min-h-[42px] px-3 py-2 text-sm font-mono tabular-nums border border-slate-300 rounded-lg"
              />
            </div>
            <button
              type="submit"
              className="min-h-[42px] inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
            >
              <Save className="w-4 h-4" />
              Save Settings
            </button>
          </form>

          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Project Source Code Archive (.zip)</h2>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Download a clean package of the KM Trading web application source code (React UI, Express API, SQLite schema,
                PWA assets, configuration, and security tests). Local database files, environment secrets, and build caches are
                excluded automatically.
              </p>
            </div>
            <button
              type="button"
              disabled={exportingZip}
              onClick={() => void handleDownloadProjectZip()}
              className="min-h-[42px] inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-60 rounded-lg cursor-pointer"
            >
              <Download className="w-4 h-4" />
              {exportingZip ? 'Packaging ZIP...' : 'Download Web App (.zip)'}
            </button>
          </div>
        </div>
      )}

      {/* AUDIT LOG */}
      {tab === 'audit' && isAdmin && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <h2 className="text-base font-semibold text-slate-900">System Audit Log</h2>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  placeholder="Search user, entity, values..."
                  className="min-h-[38px] pl-9 pr-3 py-1.5 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <select
                value={auditAction}
                onChange={(e) => setAuditAction(e.target.value)}
                className="min-h-[38px] px-3 py-1.5 text-sm border border-slate-300 rounded-lg"
              >
                <option value="">All Actions</option>
                <option value="LOGIN_SUCCESS">LOGIN_SUCCESS</option>
                <option value="LOGIN_FAILED">LOGIN_FAILED</option>
                <option value="LOGIN_LOCKED">LOGIN_LOCKED</option>
                <option value="LOGOUT">LOGOUT</option>
                <option value="CREATE">CREATE</option>
                <option value="UPDATE">UPDATE</option>
                <option value="DELETE">DELETE</option>
                <option value="LOCK_DAY">LOCK_DAY</option>
                <option value="REOPEN_DAY">REOPEN_DAY</option>
                <option value="MASTER_UPLOAD">MASTER_UPLOAD</option>
                <option value="RESET_PASSWORD">RESET_PASSWORD</option>
                <option value="CHANGE_PASSWORD">CHANGE_PASSWORD</option>
                <option value="GENERATE_RESET_LINK">GENERATE_RESET_LINK</option>
                <option value="PASSWORD_RESET_BY_LINK">PASSWORD_RESET_BY_LINK</option>
                <option value="FORGOT_PASSWORD_REQUEST">FORGOT_PASSWORD_REQUEST</option>
                <option value="DISMISS_RESET_REQUEST">DISMISS_RESET_REQUEST</option>
                <option value="UPDATE_SETTING">UPDATE_SETTING</option>
                <option value="EXPORT_PROJECT_ZIP">EXPORT_PROJECT_ZIP</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[520px]">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 font-semibold text-slate-600">
                <tr>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">User</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Entity</th>
                  <th className="py-2.5 px-3">Note / Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {auditLogs.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50 align-top">
                    <td className="py-2 px-3 font-mono whitespace-nowrap text-slate-600">{a.created_at}</td>
                    <td className="py-2 px-3 font-mono font-semibold text-slate-900">{a.username}</td>
                    <td className="py-2 px-3 font-mono font-semibold text-emerald-700">{a.action}</td>
                    <td className="py-2 px-3 font-mono text-slate-700">
                      {a.entity_type} #{a.entity_id}
                    </td>
                    <td className="py-2 px-3 text-slate-700 max-w-xl">
                      {a.note && <div className="font-medium text-slate-900 mb-0.5">{a.note}</div>}
                      {a.old_value_json && (
                        <div className="font-mono text-[11px] text-red-700 break-all">Old: {a.old_value_json}</div>
                      )}
                      {a.new_value_json && (
                        <div className="font-mono text-[11px] text-emerald-800 break-all">New: {a.new_value_json}</div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Branch Modal */}
      {branchModal.open && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">{branchModal.editing ? 'Edit Branch' : 'Add Branch'}</h3>
            <form onSubmit={saveBranch} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Branch Name</label>
                <input
                  type="text"
                  required
                  value={bName}
                  onChange={(e) => setBName(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Location</label>
                <input
                  type="text"
                  value={bLocation}
                  onChange={(e) => setBLocation(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setBranchModal({ open: false, editing: null })}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button type="submit" className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-emerald-700 rounded-lg cursor-pointer">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reason Modal */}
      {reasonModal.open && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">{reasonModal.editing ? 'Edit Reason' : 'Add Reason'}</h3>
            <form onSubmit={saveReason} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Reason Name</label>
                <input
                  type="text"
                  required
                  value={rName}
                  onChange={(e) => setRName(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
                <input
                  type="text"
                  value={rDesc}
                  onChange={(e) => setRDesc(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReasonModal({ open: false, editing: null })}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button type="submit" className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-emerald-700 rounded-lg cursor-pointer">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* User Modal */}
      {userModal.open && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">{userModal.editing ? 'Edit User' : 'Create User'}</h3>
            <form onSubmit={saveUser} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Username (unique)</label>
                <input
                  type="text"
                  required
                  disabled={Boolean(userModal.editing)}
                  value={uUsername}
                  onChange={(e) => setUUsername(e.target.value)}
                  placeholder="e.g. branch_ruwi"
                  className="w-full min-h-[42px] px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg disabled:bg-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={uFullName}
                  onChange={(e) => setUFullName(e.target.value)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              {!userModal.editing && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Temporary Password (user must change on first sign-in)
                  </label>
                  <div className="relative">
                    <input
                      type={uShowPassword ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={uPassword}
                      onChange={(e) => setUPassword(e.target.value)}
                      placeholder="Min 8 chars (letters & numbers)"
                      className="w-full min-h-[42px] pl-3 pr-10 py-2 text-sm border border-slate-300 rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => setUShowPassword(!uShowPassword)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-500 hover:text-slate-800 cursor-pointer"
                      aria-label={uShowPassword ? 'Hide password' : 'Show password'}
                    >
                      {uShowPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">{PASSWORD_POLICY_HINT}</p>
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Email (optional)</label>
                  <input
                    type="email"
                    value={uEmail}
                    onChange={(e) => setUEmail(e.target.value)}
                    placeholder="staff@kmtrading.om"
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Phone (optional)</label>
                  <input
                    type="text"
                    value={uPhone}
                    onChange={(e) => setUPhone(e.target.value)}
                    placeholder="+968 ..."
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Role</label>
                <select
                  value={uRole}
                  onChange={(e) => setURole(e.target.value as UserRole)}
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                >
                  <option value="branch">Branch User</option>
                  <option value="manager">Head Office Manager</option>
                  <option value="admin">Head Office Admin</option>
                </select>
              </div>
              {uRole === 'branch' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Assigned Branch</label>
                  <select
                    required
                    value={uBranchId}
                    onChange={(e) => setUBranchId(e.target.value)}
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                  >
                    <option value="">Select branch...</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setUserModal({ open: false, editing: null })}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button type="submit" className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-emerald-700 rounded-lg cursor-pointer">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Password & 30-Min Link Modal */}
      {resetModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">
                Reset Access · <span className="font-mono">{resetModalUser.username}</span>
              </h3>
              <button
                type="button"
                onClick={() => setResetModalUser(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleResetPassword} className="space-y-3 pb-4 border-b border-slate-200">
              <div className="text-xs font-semibold text-slate-800">Option 1: Set Temporary Password</div>
              <div className="relative">
                <input
                  type={resetShowPw ? 'text' : 'password'}
                  required
                  minLength={8}
                  value={resetPasswordVal}
                  onChange={(e) => setResetPasswordVal(e.target.value)}
                  placeholder="Min 8 chars (letters & numbers)"
                  className="w-full min-h-[42px] pl-3 pr-10 py-2 text-sm border border-slate-300 rounded-lg"
                />
                <button
                  type="button"
                  onClick={() => setResetShowPw(!resetShowPw)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-500 hover:text-slate-800 cursor-pointer"
                  aria-label={resetShowPw ? 'Hide password' : 'Show password'}
                >
                  {resetShowPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">{PASSWORD_POLICY_HINT} User must change it on next sign-in.</p>
              <button
                type="submit"
                className="w-full min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg cursor-pointer"
              >
                Save Temporary Password
              </button>
            </form>

            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-800">Option 2: One-Time 30-Minute Reset Link</div>
              <p className="text-xs text-slate-600">
                Generate a single-use reset link valid for 30 minutes to share directly with this user.
              </p>
              <button
                type="button"
                onClick={handleGenerateResetLink}
                className="w-full min-h-[40px] inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg cursor-pointer"
              >
                <Link2 className="w-4 h-4" />
                Generate One-Time Reset Link
              </button>

              {generatedResetLink && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                  <div className="text-[11px] font-medium text-slate-700">
                    Expires around {resetLinkExpires} (one-time use):
                  </div>
                  <div className="text-xs font-mono break-all bg-white p-2 border border-slate-200 rounded text-slate-900">
                    {generatedResetLink}
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(generatedResetLink, 'link')}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedText === 'link' ? 'Copied to clipboard' : 'Copy Reset Link'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* One-Time Generated Credentials Modal */}
      {bulkCredentials && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] flex flex-col">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900">One-Time Temporary Staff Passwords</h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Save or print this sheet now. For security, plaintext temporary passwords are shown only once; every
                  user will be forced to choose a personal password on first sign-in.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setBulkCredentials(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                  <tr>
                    <th className="py-2 px-3">Username</th>
                    <th className="py-2 px-3">Role / Branch</th>
                    <th className="py-2 px-3">Temporary Password</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {bulkCredentials.map((c) => (
                    <tr key={c.id}>
                      <td className="py-2 px-3 font-mono font-semibold text-slate-900">{c.username}</td>
                      <td className="py-2 px-3 text-slate-700">
                        {c.branch_name || (c.role === 'manager' ? 'Head Office Manager' : c.role)}
                      </td>
                      <td className="py-2 px-3 font-mono font-bold text-emerald-800">{c.temp_password}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    copyToClipboard(
                      bulkCredentials
                        .map((c) => `${c.username}\t${c.branch_name || c.role}\t${c.temp_password}`)
                        .join('\n'),
                      'bulk'
                    )
                  }
                  className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copiedText === 'bulk' ? 'Copied' : 'Copy All'}
                </button>
                <button
                  type="button"
                  onClick={() => downloadCredentialsCsv(bulkCredentials)}
                  className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download CSV
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print
                </button>
              </div>
              <button
                type="button"
                onClick={() => setBulkCredentials(null)}
                className="min-h-[38px] px-4 py-1.5 text-xs font-semibold text-white bg-emerald-700 rounded-lg cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
