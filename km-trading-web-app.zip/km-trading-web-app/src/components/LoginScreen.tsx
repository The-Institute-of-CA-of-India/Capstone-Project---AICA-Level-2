import React, { useEffect, useState } from 'react';
import { ArrowLeft, Eye, EyeOff, FolderKanban, KeyRound, Lock, LogIn, MailQuestion, ShieldCheck } from 'lucide-react';
import { apiRequest, PASSWORD_POLICY_HINT, setAuthToken, validateClientPassword } from '../lib/api';
import type { AuthUser } from '../types';
import { OfflineIndicator } from './OfflineIndicator';
import { PWAInstallButton } from './PWAInstallButton';

interface LoginScreenProps {
  needsAdminSetup: boolean;
  sessionNotice?: string | null;
  onAuthenticated: (user: AuthUser, serverToday: string) => void;
  onOpenPortfolio?: () => void;
}

type AuthViewMode = 'signin' | 'forgot' | 'change' | 'resetLink';

function PasswordField({
  id,
  label,
  value,
  onChange,
  placeholder,
  autoComplete,
  required = true,
  minLength,
  rightAction,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  autoComplete?: string;
  required?: boolean;
  minLength?: number;
  rightAction?: React.ReactNode;
}) {
  const [visible, setVisible] = useState(false);

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <label htmlFor={id} className="block text-xs font-medium text-slate-700">
          {label}
        </label>
        {rightAction}
      </div>
      <div className="relative">
        <input
          id={id}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          minLength={minLength}
          autoComplete={autoComplete}
          placeholder={placeholder}
          className="w-full min-h-[44px] pl-3.5 pr-11 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
        />
        <button
          type="button"
          onClick={() => setVisible(!visible)}
          aria-label={visible ? 'Hide password' : 'Show password'}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 min-h-[36px] min-w-[36px] inline-flex items-center justify-center text-slate-500 hover:text-slate-800 rounded-md cursor-pointer"
        >
          {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}

export function LoginScreen({ needsAdminSetup, sessionNotice, onAuthenticated, onOpenPortfolio }: LoginScreenProps) {
  const [setupMode, setSetupMode] = useState(needsAdminSetup);
  const [viewMode, setViewMode] = useState<AuthViewMode>('signin');
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('Head Office Administrator');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [resetNote, setResetNote] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [resetTokenUser, setResetTokenUser] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setSetupMode(needsAdminSetup);
  }, [needsAdminSetup]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('resetToken')?.trim();
    if (token) {
      setResetToken(token);
      setViewMode('resetLink');
      setLoading(true);
      apiRequest<{ valid: boolean; username: string; full_name: string }>(
        `/api/auth/reset-token/${encodeURIComponent(token)}`
      )
        .then((res) => {
          setResetTokenUser(`${res.full_name} (${res.username})`);
        })
        .catch((err) => {
          setError(err instanceof Error ? err.message : 'Reset link is invalid or expired.');
        })
        .finally(() => setLoading(false));
    }
  }, []);

  function clearResetQueryParam() {
    const url = new URL(window.location.href);
    if (url.searchParams.has('resetToken')) {
      url.searchParams.delete('resetToken');
      window.history.replaceState({}, '', url.pathname + url.search);
    }
  }

  function switchMode(next: AuthViewMode) {
    if (next !== 'resetLink') {
      clearResetQueryParam();
    }
    setViewMode(next);
    setError(null);
    setSuccessMsg(null);
    setPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
  }

  async function handleSetupSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const pwErr = validateClientPassword(password);
    if (pwErr) {
      setError(pwErr);
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiRequest<{ token: string; user: AuthUser; server_today: string }>('/api/auth/setup-admin', {
        method: 'POST',
        body: JSON.stringify({ password, full_name: fullName }),
      });
      setAuthToken(res.token);
      setSetupMode(false);
      onAuthenticated(res.user, res.server_today);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to configure admin account.');
    } finally {
      setLoading(false);
    }
  }

  async function handleLoginSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!username.trim() || !password) {
      setError('Enter your username (or registered email) and password.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiRequest<{ token: string; user: AuthUser; server_today: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username: username.trim(), password, rememberMe }),
      });
      setAuthToken(res.token);
      onAuthenticated(res.user, res.server_today);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed.');
    } finally {
      setLoading(false);
    }
  }

  async function handleForgotSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!username.trim()) {
      setError('Enter your username or registered email.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiRequest<{ ok: boolean; message: string }>('/api/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ identifier: username.trim(), note: resetNote.trim() }),
      });
      setSuccessMsg(res.message);
      setResetNote('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit password reset request.');
    } finally {
      setLoading(false);
    }
  }

  async function handleChangePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (!username.trim() || !password) {
      setError('Enter your username (or email) and current password.');
      return;
    }
    const pwErr = validateClientPassword(newPassword);
    if (pwErr) {
      setError(pwErr);
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('New passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      await apiRequest('/api/auth/change-password-login', {
        method: 'POST',
        body: JSON.stringify({
          username: username.trim(),
          currentPassword: password,
          newPassword,
        }),
      });
      setPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setSuccessMsg('Password updated successfully. You can now sign in with your new password.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update password.');
    } finally {
      setLoading(false);
    }
  }

  async function handleResetLinkSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    const pwErr = validateClientPassword(newPassword);
    if (pwErr) {
      setError(pwErr);
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const res = await apiRequest<{ ok: boolean; username: string }>('/api/auth/reset-token', {
        method: 'POST',
        body: JSON.stringify({ token: resetToken, newPassword }),
      });
      clearResetQueryParam();
      setUsername(res.username);
      setNewPassword('');
      setConfirmNewPassword('');
      setViewMode('signin');
      setSuccessMsg(`Password updated for ${res.username}. Please sign in with your new password.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset password.');
    } finally {
      setLoading(false);
    }
  }

  const headerTitle = setupMode
    ? 'Initial Head Office Admin Setup'
    : viewMode === 'forgot'
    ? 'Forgot Password'
    : viewMode === 'change'
    ? 'Change Password'
    : viewMode === 'resetLink'
    ? 'Set New Password'
    : 'Branch Receiving Sign In';

  const headerSubtitle = setupMode
    ? 'Create the Head Office administrator password to initialize branches, products, and staff logins.'
    : viewMode === 'forgot'
    ? 'Request assistance from Head Office Admin using your username or registered email.'
    : viewMode === 'change'
    ? 'Update your password using your current or temporary password.'
    : viewMode === 'resetLink'
    ? resetTokenUser
      ? `One-time 30-minute reset link verified for ${resetTokenUser}.`
      : 'Validating your one-time password reset link...'
    : 'Sign in with your assigned KM Trading account to access your branch or Head Office portal.';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-4 py-10">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
        <div className="mb-6 pb-5 border-b border-slate-100">
          <img
            src="/assets/aistudio/image_ea5d3a57.png"
            alt="KM Trading — Symbol Of Confidence"
            className="h-12 w-auto object-contain mb-3"
          />
          <p className="text-xs font-medium text-emerald-700 tracking-wide mb-1">KM Trading Operations</p>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{headerTitle}</h1>
          <p className="text-sm text-slate-500 mt-1.5 leading-relaxed">{headerSubtitle}</p>
        </div>

        {sessionNotice && !error && !successMsg && (
          <div className="mb-5 p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-sm text-amber-900" role="status">
            {sessionNotice}
          </div>
        )}

        {error && (
          <div className="mb-5 p-3.5 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700" role="alert">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="mb-5 p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-800" role="status">
            {successMsg}
          </div>
        )}

        {setupMode ? (
          <form onSubmit={handleSetupSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Head Office Admin Username</label>
              <input
                type="text"
                value="admin"
                disabled
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm font-mono bg-slate-100 border border-slate-200 rounded-lg text-slate-600"
              />
            </div>

            <div>
              <label htmlFor="setup-fullname" className="block text-xs font-medium text-slate-700 mb-1.5">
                Full Name
              </label>
              <input
                id="setup-fullname"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
              />
            </div>

            <PasswordField
              id="setup-password"
              label="New Admin Password"
              value={password}
              onChange={setPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Min 8 chars (letters & numbers)"
            />

            <PasswordField
              id="setup-confirm"
              label="Confirm Password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Re-enter password"
            />

            <p className="text-xs text-slate-500">{PASSWORD_POLICY_HINT}</p>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] mt-2 inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              {loading ? 'Configuring...' : 'Claim Admin & Continue'}
            </button>
          </form>
        ) : viewMode === 'resetLink' ? (
          <form onSubmit={handleResetLinkSubmit} className="space-y-4">
            <PasswordField
              id="rl-new"
              label="New Password"
              value={newPassword}
              onChange={setNewPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Min 8 chars (letters & numbers)"
            />

            <PasswordField
              id="rl-confirm"
              label="Confirm New Password"
              value={confirmNewPassword}
              onChange={setConfirmNewPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Re-enter new password"
            />

            <p className="text-xs text-slate-500">{PASSWORD_POLICY_HINT}</p>

            <button
              type="submit"
              disabled={loading || !resetTokenUser}
              className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {loading ? 'Updating...' : 'Save New Password'}
            </button>

            <button
              type="button"
              onClick={() => switchMode('signin')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer py-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to Sign In
            </button>
          </form>
        ) : viewMode === 'forgot' ? (
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <div>
              <label htmlFor="forgot-username" className="block text-xs font-medium text-slate-700 mb-1.5">
                Username or Registered Email
              </label>
              <input
                id="forgot-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                placeholder="e.g. branch_ruwi or staff@kmtrading.om"
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
              />
            </div>

            <div>
              <label htmlFor="forgot-note" className="block text-xs font-medium text-slate-700 mb-1.5">
                Branch / Contact Note (optional)
              </label>
              <input
                id="forgot-note"
                type="text"
                maxLength={250}
                value={resetNote}
                onChange={(e) => setResetNote(e.target.value)}
                placeholder="e.g. Ruwi Branch — locked out before shift"
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
              />
            </div>

            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 border border-slate-200 rounded-lg p-3">
              Automated email sending is not active in this deployment. Submitting this request notifies Head Office
              Admin under <strong>Admin Setup → Users &amp; Roles</strong> so they can issue a temporary password or
              send you a one-time 30-minute reset link.
            </p>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              <MailQuestion className="w-4 h-4" />
              {loading ? 'Submitting Request...' : 'Notify Head Office Admin'}
            </button>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => switchMode('signin')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer py-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Sign In
              </button>
              <button
                type="button"
                onClick={() => switchMode('change')}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer py-1"
              >
                Change password instead
              </button>
            </div>
          </form>
        ) : viewMode === 'change' ? (
          <form onSubmit={handleChangePasswordSubmit} className="space-y-4">
            <div>
              <label htmlFor="cp-username" className="block text-xs font-medium text-slate-700 mb-1.5">
                Username or Email
              </label>
              <input
                id="cp-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                placeholder="e.g. admin or branch_ruwi"
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
              />
            </div>

            <PasswordField
              id="cp-current"
              label="Current / Temporary Password"
              value={password}
              onChange={setPassword}
              autoComplete="current-password"
              placeholder="Enter current password"
            />

            <PasswordField
              id="cp-new"
              label="New Password"
              value={newPassword}
              onChange={setNewPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Min 8 chars (letters & numbers)"
            />

            <PasswordField
              id="cp-confirm"
              label="Confirm New Password"
              value={confirmNewPassword}
              onChange={setConfirmNewPassword}
              minLength={8}
              autoComplete="new-password"
              placeholder="Re-enter new password"
            />

            <p className="text-xs text-slate-500">{PASSWORD_POLICY_HINT}</p>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {loading ? 'Updating...' : 'Update Password'}
            </button>

            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => switchMode('signin')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer py-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Sign In
              </button>
              <button
                type="button"
                onClick={() => switchMode('forgot')}
                className="text-xs font-medium text-amber-700 hover:text-amber-800 cursor-pointer py-1"
              >
                Forgot password?
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-username" className="block text-xs font-medium text-slate-700 mb-1.5">
                Username or Email
              </label>
              <input
                id="login-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                autoComplete="username"
                placeholder="e.g. admin, ho_manager, or branch_ruwi"
                className="w-full min-h-[44px] px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600"
              />
            </div>

            <PasswordField
              id="login-password"
              label="Password"
              value={password}
              onChange={setPassword}
              autoComplete="current-password"
              placeholder="Enter your password"
              rightAction={
                <button
                  type="button"
                  onClick={() => switchMode('forgot')}
                  className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
                >
                  Forgot password?
                </button>
              }
            />

            <label className="flex items-start gap-2.5 pt-0.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
              />
              <span className="text-xs text-slate-600 leading-snug">
                <strong className="text-slate-800 font-medium">Remember Me (30 days)</strong>
                <span className="block text-[11px] text-slate-500">
                  Leave unticked on shared branch devices (auto sign-out on close or 30 min idle).
                </span>
              </span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[46px] mt-1 inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 rounded-lg transition-colors cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              {loading ? 'Signing in...' : 'Sign In'}
            </button>

            <div className="pt-1 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => switchMode('change')}
                className="inline-flex items-center gap-1.5 font-medium text-slate-600 hover:text-emerald-700 cursor-pointer py-1"
              >
                <KeyRound className="w-3.5 h-3.5" />
                Change password
              </button>
              <button
                type="button"
                onClick={() => switchMode('forgot')}
                className="font-medium text-slate-600 hover:text-amber-700 cursor-pointer py-1"
              >
                Request reset
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Strict branch isolation · 5-attempt lockout protection</span>
          </div>
          <div className="flex items-center gap-2">
            {onOpenPortfolio && (
              <button
                type="button"
                onClick={onOpenPortfolio}
                className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <FolderKanban className="w-3.5 h-3.5" />
                Project Portfolio
              </button>
            )}
            <PWAInstallButton />
          </div>
        </div>
      </div>
      <OfflineIndicator />
    </div>
  );
}
