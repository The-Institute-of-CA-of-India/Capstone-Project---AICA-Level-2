import React from 'react';

export function UserGuidePage() {
  return (
    <div className="space-y-6 max-w-4xl">
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">KM Trading Operational User Guide</h1>
        <p className="text-sm text-slate-600 mt-1">
          Step-by-step instructions for Head Office Admins, Managers, and Branch Receiving Staff.
        </p>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">01. User Accounts, Branch Isolation &amp; Security Rules</h2>
        <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700 leading-relaxed">
          <li>
            <strong>Roles &amp; Access:</strong> <em>Head Office Admin</em> manages branches, products, master uploads,
            users, and day locks. <em>Head Office Manager</em> monitors the dashboard, closes days, and exports reports
            for all branches without editing master data. <em>Branch Users</em> are locked to one branch and can never
            view, add, edit, or export data from any other branch.
          </li>
          <li>
            <strong>Seeded Usernames:</strong> The system includes <code className="font-mono text-xs">admin</code>{' '}
            (Head Office Admin), <code className="font-mono text-xs">ho_manager</code> (Head Office Manager), and 10
            branch accounts (<code className="font-mono text-xs">branch_al_amerat</code>,{' '}
            <code className="font-mono text-xs">branch_al_khoud</code>,{' '}
            <code className="font-mono text-xs">branch_al_khuwair</code>,{' '}
            <code className="font-mono text-xs">branch_ibri_dhank</code>,{' '}
            <code className="font-mono text-xs">branch_rop_quram</code>,{' '}
            <code className="font-mono text-xs">branch_ruwi</code>,{' '}
            <code className="font-mono text-xs">branch_saada</code>,{' '}
            <code className="font-mono text-xs">branch_safa_hyper_mabela</code>,{' '}
            <code className="font-mono text-xs">branch_salalah</code>, and{' '}
            <code className="font-mono text-xs">branch_yanqul</code>).
          </li>
          <li>
            <strong>Issuing Temporary Passwords:</strong> Head Office Admin opens <em>Admin Setup → Users &amp; Roles</em>{' '}
            and clicks <strong>Issue All Pending Temp Passwords</strong> (or resets any individual user) to generate
            one-time temporary passwords or a 30-minute reset link. Staff must set a personal password on first sign-in.
          </li>
          <li>
            <strong>Password Policy &amp; Lockout:</strong> Passwords must be at least 8 characters with at least one
            letter and one number. Accounts automatically lock for 15 minutes after 5 failed sign-in attempts.
          </li>
          <li>
            <strong>Remember Me vs. Shared Devices:</strong> Ticking <em>Remember Me</em> keeps you signed in for 30
            days. Leaving it unticked ends your session when the browser closes or after 30 minutes of inactivity.
          </li>
        </ol>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">02. Administrator — First-Time Master Data Upload &amp; Setup</h2>
        <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700 leading-relaxed">
          <li>
            <strong>Sign In &amp; Claim Admin:</strong> On initial launch, set the <code className="font-mono text-xs">admin</code>{' '}
            password on the setup screen.
          </li>
          <li>
            <strong>Adding New Branches:</strong> Go to <em>Admin Setup → Branches</em> to add a new location, then go
            to <em>Users &amp; Roles</em> and click <strong>Sync Branch Logins</strong> (or <strong>Add User</strong>)
            to assign a branch login.
          </li>
          <li>
            <strong>Download Upload Template:</strong> Open <em>Master Upload</em> and click{' '}
            <strong>Download Excel Template</strong> (or CSV). Keep the exact headers:{' '}
            <code className="font-mono text-xs bg-slate-100 px-1 py-0.5 rounded">
              barcode, product_name, unit, default_price, category, active
            </code>
            .
          </li>
          <li>
            <strong>Upload &amp; Validate:</strong> Select your filled spreadsheet. Review the preview table showing{' '}
            <em>New</em>, <em>Update</em>, and <em>Invalid</em> rows, then click <strong>Confirm Import</strong>.
          </li>
        </ol>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">03. Branch Staff — Daily Receiving Entry</h2>
        <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700 leading-relaxed">
          <li>
            <strong>Open Daily Receiving:</strong> Branch staff land directly on Daily Receiving with their assigned
            branch fixed.
          </li>
          <li>
            <strong>Enter GRN / Transfer Number:</strong> Type the transfer document number from the warehouse.
          </li>
          <li>
            <strong>Enter Barcode, Product &amp; Unit:</strong> Type a barcode in the <em>Barcode</em> field to
            auto-fill the <em>Product</em>, or search by name in the <em>Product</em> field. If an item is not in
            Master Data yet, enter both Barcode and Product Name and select its category to create it inline. Choose the
            entry <strong>Unit</strong> (<code className="font-mono text-xs">KG</code>,{' '}
            <code className="font-mono text-xs">PCS</code>, or <code className="font-mono text-xs">PACK</code>) and
            manually enter the mandatory <strong>Unit Price</strong> (highlighted in light red).
          </li>
          <li>
            <strong>Enter Quantities &amp; Variance Reason:</strong> Type the <em>Transferred Qty</em> and actual{' '}
            <em>Received Qty</em>. Whenever they differ, select a variance reason and add remarks if needed.
          </li>
          <li>
            <strong>Print Preview &amp; Signatures:</strong> Click <strong>Print Preview</strong> for a clean company
            receiving sheet with Receiver, Branch Incharge, and Management signature lines.
          </li>
        </ol>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">04. Managers &amp; Admins — Day Locking, Alerts &amp; Reports</h2>
        <ol className="list-decimal list-inside space-y-2 text-sm text-slate-700 leading-relaxed">
          <li>
            <strong>Monitor Alerts:</strong> Head Office Admin &amp; Manager land on the <em>Variance Dashboard</em>{' '}
            showing total loss value, branches exceeding the loss threshold (default 5%), and top shortage items.
          </li>
          <li>
            <strong>Close / Reopen Day:</strong> Head Office Manager or Admin closes each day at day end. Only Head
            Office Admin can reopen a locked date with a mandatory audit reason.
          </li>
          <li>
            <strong>Export Reports:</strong> Filter Daily Detail, Consolidated Summary, or Monthly Summaries and export
            to PDF, Excel, CSV, or Print.
          </li>
        </ol>
      </div>
    </div>
  );
}
