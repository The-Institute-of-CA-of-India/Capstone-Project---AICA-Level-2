import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  Check,
  Edit3,
  FilePlus2,
  Lock,
  Plus,
  Printer,
  Search,
  Trash2,
  Unlock,
  X,
} from 'lucide-react';
import { apiRequest, formatMoney, formatQty } from '../lib/api';
import type {
  AuthUser,
  Branch,
  DayLockInfo,
  Product,
  ProductCategory,
  ProductUnit,
  Reason,
  ReceivingEntry,
} from '../types';

interface ReceivingPageProps {
  user: AuthUser;
  serverToday: string;
}

export function ReceivingPage({ user, serverToday }: ReceivingPageProps) {
  const [selectedDate, setSelectedDate] = useState(serverToday);
  const [dayInfo, setDayInfo] = useState<DayLockInfo | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [reasons, setReasons] = useState<Reason[]>([]);
  const [entries, setEntries] = useState<ReceivingEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Filters on table
  const [filterBranchId, setFilterBranchId] = useState<string>(user.role === 'branch' && user.branch_id ? String(user.branch_id) : '');
  const [filterDoc, setFilterDoc] = useState('');

  // Entry form state
  const [editingId, setEditingId] = useState<number | null>(null);
  const [branchId, setBranchId] = useState<string>(user.role === 'branch' && user.branch_id ? String(user.branch_id) : '');
  const [documentNumber, setDocumentNumber] = useState('');
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [barcodeQuery, setBarcodeQuery] = useState('');
  const [barcodeDropdownOpen, setBarcodeDropdownOpen] = useState(false);
  const [productQuery, setProductQuery] = useState('');
  const [productDropdownOpen, setProductDropdownOpen] = useState(false);
  const [entryUnit, setEntryUnit] = useState<ProductUnit>('kg');
  const [newProductCategory, setNewProductCategory] = useState<ProductCategory>('Vegetable');
  const [creatingProduct, setCreatingProduct] = useState(false);
  const [transferredQty, setTransferredQty] = useState('');
  const [receivedQty, setReceivedQty] = useState('');
  const [unitPrice, setUnitPrice] = useState('');
  const [overrideValue, setOverrideValue] = useState(false);
  const [manualTransferredVal, setManualTransferredVal] = useState('');
  const [manualReceivedVal, setManualReceivedVal] = useState('');
  const [reasonId, setReasonId] = useState<string>('');
  const [remarks, setRemarks] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Reopen day modal
  const [reopenModalOpen, setReopenModalOpen] = useState(false);
  const [reopenReason, setReopenReason] = useState('');
  const [lockingAction, setLockingAction] = useState(false);

  // Print preview modal
  const [printPreviewOpen, setPrintPreviewOpen] = useState(false);

  const barcodeDropdownRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (barcodeDropdownRef.current && !barcodeDropdownRef.current.contains(e.target as Node)) {
        setBarcodeDropdownOpen(false);
      }
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setProductDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const loadMasterData = useCallback(async () => {
    try {
      const [bData, pData, rData] = await Promise.all([
        apiRequest<Branch[]>('/api/branches?activeOnly=true'),
        apiRequest<Product[]>('/api/products?activeOnly=true'),
        apiRequest<Reason[]>('/api/reasons?activeOnly=true'),
      ]);
      setBranches(bData);
      setProducts(pData);
      setReasons(rData);

      if (user.role === 'branch' && user.branch_id) {
        setBranchId(String(user.branch_id));
        setFilterBranchId(String(user.branch_id));
      } else if (bData.length > 0 && !branchId) {
        setBranchId(String(bData[0].id));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load master data.');
    }
  }, [user.branch_id, user.role, branchId]);

  const loadDayAndEntries = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ date: selectedDate });
      if (user.role !== 'branch' && filterBranchId) {
        params.set('branchId', filterBranchId);
      }
      if (filterDoc.trim()) {
        params.set('documentNumber', filterDoc.trim());
      }
      const [lockRes, listRes] = await Promise.all([
        apiRequest<DayLockInfo>(`/api/days/${selectedDate}`),
        apiRequest<ReceivingEntry[]>(`/api/receiving?${params.toString()}`),
      ]);
      setDayInfo(lockRes);
      setEntries(listRes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load receiving entries.');
    } finally {
      setLoading(false);
    }
  }, [selectedDate, filterBranchId, filterDoc, user.role]);

  useEffect(() => {
    loadMasterData();
  }, [loadMasterData]);

  useEffect(() => {
    loadDayAndEntries();
  }, [loadDayAndEntries]);

  const selectedProduct = useMemo(
    () => products.find((p) => p.id === selectedProductId) || null,
    [products, selectedProductId]
  );

  const filteredProductsByBarcode = useMemo(() => {
    const q = barcodeQuery.trim().toLowerCase();
    if (!q) return products.slice(0, 40);
    return products
      .filter((p) => p.barcode.toLowerCase().includes(q) || p.name.toLowerCase().includes(q))
      .slice(0, 40);
  }, [products, barcodeQuery]);

  const filteredProducts = useMemo(() => {
    const q = productQuery.trim().toLowerCase();
    if (!q) return products.slice(0, 40);
    return products
      .filter((p) => p.name.toLowerCase().includes(q) || p.barcode.toLowerCase().includes(q))
      .slice(0, 40);
  }, [products, productQuery]);

  // Live calculations
  const calc = useMemo(() => {
    const tQty = Number(transferredQty) || 0;
    const rQty = Number(receivedQty) || 0;
    const price = Number(unitPrice) || 0;
    const diffQty = Math.round((tQty - rQty + Number.EPSILON) * 1000) / 1000;

    const autoTVal = Math.round((tQty * price + Number.EPSILON) * 100) / 100;
    const autoRVal = Math.round((rQty * price + Number.EPSILON) * 100) / 100;

    const tVal = overrideValue ? Number(manualTransferredVal) || 0 : autoTVal;
    const rVal = overrideValue ? Number(manualReceivedVal) || 0 : autoRVal;
    const diffVal = Math.round((tVal - rVal + Number.EPSILON) * 100) / 100;

    const hasVariance = Math.abs(diffQty) > 0.0001;
    const varianceType: 'short' | 'excess' | 'match' = diffQty > 0.0001 ? 'short' : diffQty < -0.0001 ? 'excess' : 'match';

    return { tQty, rQty, price, diffQty, tVal, rVal, diffVal, hasVariance, varianceType };
  }, [transferredQty, receivedQty, unitPrice, overrideValue, manualTransferredVal, manualReceivedVal]);

  const isDayOpen = dayInfo?.status === 'open';
  const canEditEntries = isDayOpen && (user.role === 'admin' || user.role === 'branch');
  const isMissingReason = calc.hasVariance && !reasonId;
  const isMissingUnitPrice =
    unitPrice.trim() === '' || !Number.isFinite(Number(unitPrice)) || Number(unitPrice) < 0;

  const isNewProductDraft = !selectedProduct && Boolean(barcodeQuery.trim() || productQuery.trim());
  const canQuickCreateProduct = Boolean(barcodeQuery.trim() && productQuery.trim());

  function selectProduct(p: Product) {
    setSelectedProductId(p.id);
    setBarcodeQuery(p.barcode);
    setProductQuery(p.name);
    setEntryUnit(p.unit === 'pcs' || p.unit === 'pack' ? p.unit : 'kg');
    setUnitPrice('');
    setBarcodeDropdownOpen(false);
    setProductDropdownOpen(false);
  }

  function handleBarcodeInput(val: string) {
    setBarcodeQuery(val);
    const trimmed = val.trim().toLowerCase();
    if (!trimmed) {
      if (selectedProductId !== null) {
        setSelectedProductId(null);
        setProductQuery('');
      }
      setBarcodeDropdownOpen(true);
      return;
    }

    const exact = products.find((p) => p.barcode.toLowerCase() === trimmed);
    if (exact) {
      setSelectedProductId(exact.id);
      setProductQuery(exact.name);
      setEntryUnit(exact.unit === 'pcs' || exact.unit === 'pack' ? exact.unit : 'kg');
      setBarcodeDropdownOpen(false);
      setProductDropdownOpen(false);
    } else {
      if (selectedProductId !== null) {
        setSelectedProductId(null);
        setProductQuery('');
      }
      setBarcodeDropdownOpen(true);
    }
  }

  function handleProductInput(val: string) {
    setProductQuery(val);
    if (selectedProductId !== null) {
      setSelectedProductId(null);
    }
    setProductDropdownOpen(true);
  }

  async function quickCreateProduct(): Promise<Product | null> {
    const cleanBarcode = barcodeQuery.trim();
    const cleanName = productQuery.trim();
    if (!cleanBarcode || !cleanName) {
      setError('Enter both Barcode and Product Name to create a new product.');
      return null;
    }

    setCreatingProduct(true);
    setError(null);
    try {
      const created = await apiRequest<Product>('/api/receiving/quick-product', {
        method: 'POST',
        body: JSON.stringify({
          barcode: cleanBarcode,
          name: cleanName,
          unit: entryUnit,
          category: newProductCategory,
        }),
      });
      setProducts((prev) =>
        [...prev, created].sort((a, b) => a.name.localeCompare(b.name))
      );
      setSelectedProductId(created.id);
      setBarcodeQuery(created.barcode);
      setProductQuery(created.name);
      setEntryUnit(created.unit);
      setBarcodeDropdownOpen(false);
      setProductDropdownOpen(false);
      setSuccessMsg(`Created new product "${created.name}" (${created.barcode}) in Master Data.`);
      return created;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create product.');
      return null;
    } finally {
      setCreatingProduct(false);
    }
  }

  function resetProductFields(keepDocument = true) {
    setEditingId(null);
    if (!keepDocument) setDocumentNumber('');
    setSelectedProductId(null);
    setBarcodeQuery('');
    setProductQuery('');
    setEntryUnit('kg');
    setNewProductCategory('Vegetable');
    setTransferredQty('');
    setReceivedQty('');
    setUnitPrice('');
    setOverrideValue(false);
    setManualTransferredVal('');
    setManualReceivedVal('');
    setReasonId('');
    setRemarks('');
  }

  function startEditRow(entry: ReceivingEntry) {
    setEditingId(entry.id);
    setBranchId(String(entry.branch_id));
    setDocumentNumber(entry.document_number);
    setSelectedProductId(entry.product_id);
    setBarcodeQuery(entry.barcode_snapshot);
    setProductQuery(entry.product_name_snapshot);
    const rawUnit = String(entry.unit_snapshot);
    setEntryUnit(rawUnit === 'pcs' || rawUnit === 'piece' ? 'pcs' : rawUnit === 'pack' ? 'pack' : 'kg');
    setTransferredQty(String(entry.transferred_qty));
    setReceivedQty(String(entry.received_qty));
    setUnitPrice(String(entry.unit_price));
    setOverrideValue(entry.value_overridden === 1);
    setManualTransferredVal(String(entry.transferred_value));
    setManualReceivedVal(String(entry.received_value));
    setReasonId(entry.reason_id ? String(entry.reason_id) : '');
    setRemarks(entry.remarks || '');
    setError(null);
    setSuccessMsg(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function handleSaveEntry(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!canEditEntries) {
      setError('Entries can only be saved when the selected day is open.');
      return;
    }
    if (!branchId) {
      setError('Select a branch.');
      return;
    }
    if (!documentNumber.trim()) {
      setError('Enter the GRN or Transfer document number.');
      return;
    }
    if (!selectedProductId && (!barcodeQuery.trim() || !productQuery.trim())) {
      setError('Enter a barcode to auto-fill a product, select a product, or enter both Barcode and Product Name to create a new product.');
      return;
    }
    if (transferredQty === '' || receivedQty === '' || Number(transferredQty) < 0 || Number(receivedQty) < 0) {
      setError('Enter valid non-negative transferred and received quantities.');
      return;
    }
    if (isMissingUnitPrice) {
      setError('Unit price is mandatory. Enter a valid non-negative unit price manually.');
      return;
    }
    if (calc.hasVariance && !reasonId) {
      setError('Reason is mandatory whenever transferred and received quantities differ.');
      return;
    }

    setSubmitting(true);
    try {
      let resolvedProductId = selectedProductId;
      if (!resolvedProductId) {
        const created = await quickCreateProduct();
        if (!created) {
          setSubmitting(false);
          return;
        }
        resolvedProductId = created.id;
      }

      const payload = {
        entry_date: selectedDate,
        branch_id: Number(branchId),
        document_number: documentNumber.trim(),
        product_id: resolvedProductId,
        unit: entryUnit,
        transferred_qty: Number(transferredQty),
        received_qty: Number(receivedQty),
        unit_price: Number(unitPrice),
        value_overridden: overrideValue,
        transferred_value: overrideValue ? Number(manualTransferredVal || 0) : undefined,
        received_value: overrideValue ? Number(manualReceivedVal || 0) : undefined,
        reason_id: calc.hasVariance ? Number(reasonId) : null,
        remarks: remarks.trim(),
      };

      if (editingId) {
        await apiRequest(`/api/receiving/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        setSuccessMsg('Receiving entry updated.');
        resetProductFields(true);
      } else {
        await apiRequest('/api/receiving', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        setSuccessMsg(`Saved under Document #${documentNumber.trim()}. Ready for next item.`);
        resetProductFields(true);
      }
      await loadDayAndEntries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save entry.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteRow(entry: ReceivingEntry) {
    if (!canEditEntries) return;
    setError(null);
    setSuccessMsg(null);
    try {
      await apiRequest(`/api/receiving/${entry.id}`, { method: 'DELETE' });
      if (editingId === entry.id) {
        resetProductFields(true);
      }
      setSuccessMsg(`Deleted ${entry.product_name_snapshot} from ${entry.document_number}.`);
      await loadDayAndEntries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete entry.');
    }
  }

  async function handleCloseDay() {
    setLockingAction(true);
    setError(null);
    try {
      await apiRequest(`/api/days/${selectedDate}/close`, { method: 'POST' });
      setSuccessMsg(`Day ${selectedDate} has been locked.`);
      await loadDayAndEntries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to close day.');
    } finally {
      setLockingAction(false);
    }
  }

  async function handleReopenDay(e: React.FormEvent) {
    e.preventDefault();
    if (reopenReason.trim().length < 3) {
      setError('Enter a reason (at least 3 characters) to reopen the day.');
      return;
    }
    setLockingAction(true);
    setError(null);
    try {
      await apiRequest(`/api/days/${selectedDate}/reopen`, {
        method: 'POST',
        body: JSON.stringify({ reason: reopenReason.trim() }),
      });
      setReopenModalOpen(false);
      setReopenReason('');
      setSuccessMsg(`Day ${selectedDate} reopened for editing.`);
      await loadDayAndEntries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reopen day.');
    } finally {
      setLockingAction(false);
    }
  }

  const dayTotals = useMemo(() => {
    return entries.reduce(
      (acc, r) => {
        acc.tQty += r.transferred_qty;
        acc.rQty += r.received_qty;
        acc.dQty += r.difference_qty;
        acc.tVal += r.transferred_value;
        acc.rVal += r.received_value;
        acc.dVal += r.difference_value;
        return acc;
      },
      { tQty: 0, rQty: 0, dQty: 0, tVal: 0, rVal: 0, dVal: 0 }
    );
  }, [entries]);

  const previewBranchName =
    user.role === 'branch'
      ? user.branch_name || 'Assigned Branch'
      : filterBranchId
      ? branches.find((b) => String(b.id) === filterBranchId)?.name || 'Selected Branch'
      : 'All Branches';

  return (
    <>
      <div className={printPreviewOpen ? 'no-print space-y-6' : 'space-y-6'}>
        {/* Header & Day Control Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Daily Receiving Entry</h1>
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500 mt-1">
            <span>Date: {selectedDate}</span>
            <span aria-hidden="true">·</span>
            <span className={isDayOpen ? 'font-semibold text-emerald-700' : 'font-semibold text-red-700'}>
              Status: {isDayOpen ? 'Open for Entry' : 'Locked (Read-Only)'}
            </span>
            {dayInfo?.locked_by_name && !isDayOpen && (
              <>
                <span aria-hidden="true">·</span>
                <span>Closed by {dayInfo.locked_by_name}</span>
              </>
            )}
            {dayInfo?.auto_locked && !isDayOpen && (
              <>
                <span aria-hidden="true">·</span>
                <span>Past date (auto-locked)</span>
              </>
            )}
            {dayInfo?.reopen_reason && isDayOpen && (
              <>
                <span aria-hidden="true">·</span>
                <span>Reopened: {dayInfo.reopen_reason}</span>
              </>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 rounded-lg px-3 min-h-[44px] sm:min-h-[40px]">
            <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => {
                if (e.target.value) {
                  setSelectedDate(e.target.value);
                  resetProductFields(false);
                }
              }}
              aria-label="Select receiving date"
              className="bg-transparent text-sm font-mono text-slate-900 focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={() => setPrintPreviewOpen(true)}
            className="min-h-[44px] sm:min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Preview
          </button>

          {isDayOpen && (user.role === 'admin' || user.role === 'manager') && (
            <button
              type="button"
              onClick={handleCloseDay}
              disabled={lockingAction}
              className="min-h-[44px] sm:min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              Close Day
            </button>
          )}

          {!isDayOpen && user.role === 'admin' && (
            <button
              type="button"
              onClick={() => setReopenModalOpen(true)}
              disabled={lockingAction}
              className="min-h-[44px] sm:min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              Reopen Day
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800 flex items-start gap-2.5" role="alert">
          <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button type="button" onClick={() => setSuccessMsg(null)} className="text-emerald-700 hover:text-emerald-900 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Entry Form (only editable when Open and user is Admin or Branch) */}
      {canEditEntries ? (
        <form onSubmit={handleSaveEntry} className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                {editingId ? 'Edit Receiving Line Item' : 'Add Receiving Line Item'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Type a product name or barcode. Multiple items can be saved under the same GRN / transfer number.
              </p>
            </div>
            <div className="flex items-center gap-2">
              {editingId ? (
                <button
                  type="button"
                  onClick={() => resetProductFields(true)}
                  className="min-h-[40px] px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancel Edit
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => resetProductFields(false)}
                  className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  <FilePlus2 className="w-3.5 h-3.5" />
                  New Document
                </button>
              )}
            </div>
          </div>

          {/* Row 1: Branch, Document Number, Barcode, Product, Unit */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Branch</label>
              {user.role === 'branch' ? (
                <input
                  type="text"
                  value={user.branch_name || 'Assigned Branch'}
                  disabled
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-slate-100 border border-slate-200 rounded-lg text-slate-700"
                />
              ) : (
                <select
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  disabled={Boolean(editingId)}
                  required
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  <option value="">Select branch...</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="md:col-span-2">
              <label htmlFor="doc-number" className="block text-xs font-medium text-slate-700 mb-1.5">
                GRN / Doc No.
              </label>
              <input
                id="doc-number"
                type="text"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                required
                placeholder="e.g. GRN-2026-041"
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            {/* Split Barcode Field (auto-fills Product on match) */}
            <div className="md:col-span-3 relative" ref={barcodeDropdownRef}>
              <label htmlFor="barcode-input" className="block text-xs font-medium text-slate-700 mb-1.5">
                Barcode <span className="text-slate-400 font-normal">(auto-fills product)</span>
              </label>
              <div className="relative">
                <input
                  id="barcode-input"
                  type="text"
                  value={barcodeQuery}
                  onFocus={() => setBarcodeDropdownOpen(true)}
                  onChange={(e) => handleBarcodeInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && barcodeDropdownOpen && filteredProductsByBarcode.length > 0) {
                      e.preventDefault();
                      const exact = filteredProductsByBarcode.find(
                        (p) => p.barcode.toLowerCase() === barcodeQuery.trim().toLowerCase()
                      );
                      selectProduct(exact || filteredProductsByBarcode[0]);
                    }
                  }}
                  placeholder="Type barcode (e.g. 709007)"
                  className="w-full min-h-[44px] pl-3 pr-8 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                {barcodeQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setBarcodeQuery('');
                      setSelectedProductId(null);
                      setProductQuery('');
                      setBarcodeDropdownOpen(true);
                    }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    aria-label="Clear barcode"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {barcodeDropdownOpen && (
                <div className="absolute z-30 mt-1 w-full max-h-64 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg divide-y divide-slate-100">
                  {filteredProductsByBarcode.length === 0 ? (
                    <div className="px-3.5 py-2.5 text-xs text-slate-600 space-y-2">
                      <div>No existing barcode matches &quot;{barcodeQuery}&quot;.</div>
                      {canQuickCreateProduct && (
                        <button
                          type="button"
                          onClick={quickCreateProduct}
                          disabled={creatingProduct}
                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          {creatingProduct ? 'Creating...' : `Create "${productQuery.trim()}" (${barcodeQuery.trim()})`}
                        </button>
                      )}
                    </div>
                  ) : (
                    filteredProductsByBarcode.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => selectProduct(p)}
                        className="w-full text-left px-3 py-2 hover:bg-emerald-50 flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-mono font-semibold text-slate-900">{p.barcode}</div>
                          <div className="text-xs text-slate-600 truncate">{p.name}</div>
                        </div>
                        <span className="text-[11px] font-mono font-semibold text-slate-500 uppercase shrink-0">
                          {p.unit}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Split Product Field (search or make new product inline) */}
            <div className="md:col-span-3 relative" ref={dropdownRef}>
              <label htmlFor="product-search" className="block text-xs font-medium text-slate-700 mb-1.5">
                Product <span className="text-slate-400 font-normal">(search or add new)</span>
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="product-search"
                  type="text"
                  value={productQuery}
                  onFocus={() => setProductDropdownOpen(true)}
                  onChange={(e) => handleProductInput(e.target.value)}
                  placeholder="Type product name or create new"
                  className="w-full min-h-[44px] pl-9 pr-8 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
                {productQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setProductQuery('');
                      setSelectedProductId(null);
                      setProductDropdownOpen(true);
                    }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    aria-label="Clear product name"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {productDropdownOpen && (
                <div className="absolute z-30 mt-1 w-full max-h-64 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg divide-y divide-slate-100">
                  {filteredProducts.length === 0 ? (
                    <div className="px-3.5 py-3 text-xs text-slate-600 space-y-2">
                      <div>No existing product matches &quot;{productQuery}&quot;.</div>
                      {canQuickCreateProduct ? (
                        <button
                          type="button"
                          onClick={quickCreateProduct}
                          disabled={creatingProduct}
                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          {creatingProduct
                            ? 'Creating...'
                            : `Create "${productQuery.trim()}" (${barcodeQuery.trim()})`}
                        </button>
                      ) : (
                        <div className="text-[11px] text-amber-700">
                          Enter a Barcode in the Barcode field to save this as a new product.
                        </div>
                      )}
                    </div>
                  ) : (
                    <>
                      {filteredProducts.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => selectProduct(p)}
                          className="w-full text-left px-3.5 py-2.5 hover:bg-emerald-50 flex items-center justify-between gap-2 cursor-pointer"
                        >
                          <div className="min-w-0">
                            <div className="text-sm font-medium text-slate-900 truncate">{p.name}</div>
                            <div className="text-xs text-slate-500 font-mono">
                              {p.barcode} · {p.category}
                            </div>
                          </div>
                          <div className="text-xs font-mono font-semibold text-slate-600 uppercase shrink-0">
                            {p.unit}
                          </div>
                        </button>
                      ))}
                      {canQuickCreateProduct && !selectedProduct && (
                        <div className="p-2 bg-slate-50">
                          <button
                            type="button"
                            onClick={quickCreateProduct}
                            disabled={creatingProduct}
                            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-md cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            {creatingProduct
                              ? 'Creating...'
                              : `Create New Product: "${productQuery.trim()}" (${barcodeQuery.trim()})`}
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>

            {/* New Unit Field (KG / PCS / PACK) */}
            <div className="md:col-span-2">
              <label htmlFor="entry-unit" className="block text-xs font-medium text-slate-700 mb-1.5">
                Unit (KG / PCS / PACK)
              </label>
              <select
                id="entry-unit"
                value={entryUnit}
                onChange={(e) => setEntryUnit(e.target.value as ProductUnit)}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono font-semibold bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <option value="kg">KG</option>
                <option value="pcs">PCS</option>
                <option value="pack">PACK</option>
              </select>
            </div>
          </div>

          {/* Selected Product Auto-fill Strip OR Inline New Product Creator */}
          {selectedProduct ? (
            <div className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-slate-600">
              <span>
                Barcode: <strong className="font-mono text-slate-900">{selectedProduct.barcode}</strong>
              </span>
              <span>
                Product: <strong className="text-slate-900">{selectedProduct.name}</strong>
              </span>
              <span>
                Unit: <strong className="font-mono uppercase text-slate-900">{entryUnit}</strong>
              </span>
              <span>
                Category: <strong className="text-slate-900">{selectedProduct.category}</strong>
              </span>
              <span>
                Unit Price: <strong className="text-red-700">Manual entry required</strong>
              </span>
            </div>
          ) : (
            isNewProductDraft && (
              <div className="px-3.5 py-2.5 bg-amber-50 border border-amber-200 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs text-amber-950">
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span className="font-semibold text-amber-900">New Product Mode</span>
                  <span>
                    Barcode: <strong className="font-mono">{barcodeQuery.trim() || '—'}</strong>
                  </span>
                  <span>
                    Name: <strong>{productQuery.trim() || '—'}</strong>
                  </span>
                  <span>
                    Unit: <strong className="font-mono uppercase">{entryUnit}</strong>
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <label htmlFor="new-prod-cat" className="text-xs font-medium text-amber-900">
                    Category:
                  </label>
                  <select
                    id="new-prod-cat"
                    value={newProductCategory}
                    onChange={(e) => setNewProductCategory(e.target.value as ProductCategory)}
                    className="min-h-[34px] px-2.5 py-1 text-xs bg-white border border-amber-300 rounded-md text-slate-900"
                  >
                    <option value="Vegetable">Vegetable</option>
                    <option value="Fruit">Fruit</option>
                  </select>
                  <button
                    type="button"
                    onClick={quickCreateProduct}
                    disabled={!canQuickCreateProduct || creatingProduct}
                    className="min-h-[34px] inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 disabled:text-slate-500 rounded-md cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    {creatingProduct ? 'Adding...' : 'Add Product to Master'}
                  </button>
                </div>
              </div>
            )
          )}

          {/* Row 2: Quantities, Unit Price, Variance Readout */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 items-end">
            <div className="lg:col-span-2">
              <label htmlFor="t-qty" className="block text-xs font-medium text-slate-700 mb-1.5">
                Transferred Qty ({entryUnit.toUpperCase()})
              </label>
              <input
                id="t-qty"
                type="number"
                step={entryUnit === 'kg' ? '0.001' : '1'}
                min="0"
                value={transferredQty}
                onChange={(e) => setTransferredQty(e.target.value)}
                required
                placeholder={entryUnit === 'kg' ? '0.000' : '0'}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="lg:col-span-2">
              <label htmlFor="r-qty" className="block text-xs font-medium text-slate-700 mb-1.5">
                Received Qty ({entryUnit.toUpperCase()})
              </label>
              <input
                id="r-qty"
                type="number"
                step={entryUnit === 'kg' ? '0.001' : '1'}
                min="0"
                value={receivedQty}
                onChange={(e) => setReceivedQty(e.target.value)}
                required
                placeholder={entryUnit === 'kg' ? '0.000' : '0'}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="lg:col-span-2">
              <label htmlFor="u-price" className="block text-xs font-medium text-red-800 mb-1.5">
                Unit Price <span className="font-semibold text-red-600">* (Mandatory)</span>
              </label>
              <input
                id="u-price"
                type="number"
                step="0.01"
                min="0"
                value={unitPrice}
                onChange={(e) => setUnitPrice(e.target.value)}
                required
                placeholder="Enter price"
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono tabular-nums bg-red-50 border border-red-300 rounded-lg text-slate-900 placeholder:text-red-400 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>

            {/* Live Variance Summary Box */}
            <div className="sm:col-span-2 lg:col-span-6">
              <div
                className={`min-h-[44px] px-4 py-2.5 rounded-lg border flex flex-wrap items-center justify-between gap-3 ${
                  calc.varianceType === 'short'
                    ? 'bg-red-50 border-red-200 text-red-900'
                    : calc.varianceType === 'excess'
                    ? 'bg-amber-50 border-amber-200 text-amber-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}
              >
                <div className="text-xs">
                  <span className="font-semibold">
                    {calc.varianceType === 'short'
                      ? 'Shortage'
                      : calc.varianceType === 'excess'
                      ? 'Excess'
                      : 'Exact Match'}
                  </span>
                  <span className="mx-2" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-mono tabular-nums font-semibold">
                    Diff Qty: {formatQty(calc.diffQty, entryUnit)} {entryUnit.toUpperCase()}
                  </span>
                </div>
                <div className="text-xs font-mono tabular-nums">
                  <span>Rec. Value: {formatMoney(calc.rVal)}</span>
                  <span className="mx-2" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-semibold">Diff Value: {formatMoney(calc.diffVal)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Optional Value Override */}
          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
              <input
                type="checkbox"
                checked={overrideValue}
                onChange={(e) => {
                  const checked = e.target.checked;
                  setOverrideValue(checked);
                  if (checked) {
                    setManualTransferredVal(String(calc.tVal));
                    setManualReceivedVal(String(calc.rVal));
                  }
                }}
                className="rounded border-slate-300 text-emerald-700 focus:ring-emerald-600"
              />
              Override calculated values manually
            </label>

            {overrideValue && (
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-slate-600">Transferred Val:</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={manualTransferredVal}
                    onChange={(e) => setManualTransferredVal(e.target.value)}
                    className="w-28 min-h-[38px] px-2.5 py-1 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-xs text-slate-600">Received Val:</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={manualReceivedVal}
                    onChange={(e) => setManualReceivedVal(e.target.value)}
                    className="w-28 min-h-[38px] px-2.5 py-1 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Row 3: Reason, Remarks, Save Button */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            <div className="md:col-span-4">
              <label htmlFor="variance-reason" className="block text-xs font-medium text-slate-700 mb-1.5">
                Variance Reason {calc.hasVariance ? <span className="text-red-600 font-semibold">(Required)</span> : '(Optional when matched)'}
              </label>
              <select
                id="variance-reason"
                value={reasonId}
                onChange={(e) => setReasonId(e.target.value)}
                disabled={!calc.hasVariance}
                required={calc.hasVariance}
                className={`w-full min-h-[44px] px-3 py-2 text-sm rounded-lg border focus:outline-none focus:ring-2 focus:ring-emerald-600 ${
                  !calc.hasVariance
                    ? 'bg-slate-100 border-slate-200 text-slate-400'
                    : isMissingReason
                    ? 'bg-red-50 border-red-400 text-slate-900'
                    : 'bg-white border-slate-300 text-slate-900'
                }`}
              >
                <option value="">{calc.hasVariance ? 'Select reason for difference...' : 'No difference'}</option>
                {reasons.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-5">
              <label htmlFor="entry-remarks" className="block text-xs font-medium text-slate-700 mb-1.5">
                Remarks
              </label>
              <input
                id="entry-remarks"
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Optional note (e.g. crushed crates, moisture loss)"
                className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="md:col-span-3">
              <button
                type="submit"
                disabled={submitting || creatingProduct || isMissingReason || isMissingUnitPrice}
                className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 disabled:text-slate-500 rounded-lg transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                {submitting || creatingProduct
                  ? 'Saving...'
                  : editingId
                  ? 'Update Entry'
                  : 'Save Receiving Row'}
              </button>
            </div>
          </div>

          {((selectedProductId !== null && isMissingUnitPrice) || (isNewProductDraft && isMissingUnitPrice) || isMissingReason) && (
            <div className="space-y-1">
              {(selectedProductId !== null || isNewProductDraft) && isMissingUnitPrice && (
                <p className="text-xs text-red-600 font-medium">
                  Unit Price is mandatory — enter the unit price manually before saving.
                </p>
              )}
              {isMissingReason && (
                <p className="text-xs text-red-600 font-medium">
                  Saving is blocked until you select a reason for the quantity difference.
                </p>
              )}
            </div>
          )}
        </form>
      ) : (
        <div className="bg-slate-100 border border-slate-200 rounded-xl p-4 text-sm text-slate-700 flex items-center gap-3">
          <Lock className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            {!isDayOpen
              ? `Date ${selectedDate} is locked in read-only mode. Only an Administrator can reopen a locked date.`
              : 'Manager accounts view receiving entries in read-only mode and can close the day at day end.'}
          </span>
        </div>
      )}

      {/* Entries Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Recorded Entries · {selectedDate}</h2>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              {entries.length} {entries.length === 1 ? 'line item' : 'line items'} · Diff Value: {formatMoney(dayTotals.dVal)}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {user.role !== 'branch' && (
              <select
                value={filterBranchId}
                onChange={(e) => setFilterBranchId(e.target.value)}
                aria-label="Filter by branch"
                className="min-h-[40px] px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-800"
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            )}

            <input
              type="text"
              value={filterDoc}
              onChange={(e) => setFilterDoc(e.target.value)}
              placeholder="Filter GRN / Doc No..."
              className="min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg text-slate-800 w-44"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="py-2.5 px-3 whitespace-nowrap">Doc No.</th>
                {user.role !== 'branch' && <th className="py-2.5 px-3 whitespace-nowrap">Branch</th>}
                <th className="py-2.5 px-3 whitespace-nowrap">Product / Barcode</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap">Transferred</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap">Received</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap">Diff Qty</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap bg-red-100/80 text-red-900 border-x border-red-200">
                  Unit Price *
                </th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap">Rec. Value</th>
                <th className="py-2.5 px-3 text-right whitespace-nowrap">Diff Value</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Status & Reason</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Remarks</th>
                {canEditEntries && <th className="py-2.5 px-3 text-right whitespace-nowrap">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {loading ? (
                <tr>
                  <td colSpan={12} className="py-8 text-center text-slate-500">
                    Loading entries...
                  </td>
                </tr>
              ) : entries.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-10 text-center text-slate-500">
                    No receiving entries recorded for {selectedDate}.
                  </td>
                </tr>
              ) : (
                entries.map((row) => {
                  const isShort = row.difference_qty > 0.0001;
                  const isExcess = row.difference_qty < -0.0001;
                  const rowBg = isShort
                    ? 'bg-red-50/70 hover:bg-red-50'
                    : isExcess
                    ? 'bg-amber-50/70 hover:bg-amber-50'
                    : 'bg-emerald-50/50 hover:bg-emerald-50';

                  return (
                    <tr key={row.id} className={`${rowBg} transition-colors`}>
                      <td className="py-2.5 px-3 font-mono text-xs font-semibold text-slate-900 whitespace-nowrap">
                        {row.document_number}
                      </td>
                      {user.role !== 'branch' && (
                        <td className="py-2.5 px-3 text-xs text-slate-700 whitespace-nowrap">{row.branch_name}</td>
                      )}
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-slate-900">{row.product_name_snapshot}</div>
                        <div className="text-xs font-mono text-slate-500">
                          {row.barcode_snapshot} · {row.unit_snapshot}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        {formatQty(row.transferred_qty, row.unit_snapshot)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        {formatQty(row.received_qty, row.unit_snapshot)}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono tabular-nums font-semibold whitespace-nowrap ${
                          isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                        }`}
                      >
                        {formatQty(row.difference_qty, row.unit_snapshot)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap bg-red-50/85 text-red-950 font-medium border-x border-red-200/80">
                        {formatMoney(row.unit_price)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        {formatMoney(row.received_value)}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono tabular-nums font-semibold whitespace-nowrap ${
                          isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                        }`}
                      >
                        {formatMoney(row.difference_value)}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div
                          className={`text-xs font-semibold ${
                            isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                          }`}
                        >
                          {isShort ? 'Short' : isExcess ? 'Excess' : 'Match'}
                        </div>
                        {row.reason_name && <div className="text-xs text-slate-600">{row.reason_name}</div>}
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-600 max-w-[180px] truncate" title={row.remarks}>
                        {row.remarks || '—'}
                      </td>
                      {canEditEntries && (
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => startEditRow(row)}
                              className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-white rounded-md cursor-pointer"
                              title="Edit row"
                              aria-label={`Edit ${row.product_name_snapshot}`}
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteRow(row)}
                              className="p-2 text-slate-600 hover:text-red-700 hover:bg-white rounded-md cursor-pointer"
                              title="Delete row"
                              aria-label={`Delete ${row.product_name_snapshot}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
            {entries.length > 0 && (
              <tfoot>
                <tr className="bg-slate-100 border-t border-slate-300 text-xs font-semibold text-slate-900">
                  <td colSpan={user.role !== 'branch' ? 3 : 2} className="py-3 px-3">
                    Day Totals ({entries.length} rows)
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">{formatQty(dayTotals.tQty)}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">{formatQty(dayTotals.rQty)}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">{formatQty(dayTotals.dQty)}</td>
                  <td className="py-3 px-3 bg-red-100/70 border-x border-red-200"></td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">{formatMoney(dayTotals.rVal)}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums">{formatMoney(dayTotals.dVal)}</td>
                  <td colSpan={canEditEntries ? 3 : 2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Reopen Day Modal (Admin only) */}
      {reopenModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">Reopen Locked Day · {selectedDate}</h3>
              <button
                type="button"
                onClick={() => setReopenModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-slate-600">
              Reopening a locked date allows editing and deleting entries for that date. The reason is permanently saved in the audit log.
            </p>
            <form onSubmit={handleReopenDay} className="space-y-4">
              <div>
                <label htmlFor="reopen-reason" className="block text-xs font-medium text-slate-700 mb-1.5">
                  Mandatory Reason for Reopening
                </label>
                <textarea
                  id="reopen-reason"
                  rows={3}
                  required
                  minLength={3}
                  value={reopenReason}
                  onChange={(e) => setReopenReason(e.target.value)}
                  placeholder="e.g. Late truck arrival GRN-048 correction"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReopenModalOpen(false)}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={lockingAction}
                  className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg cursor-pointer"
                >
                  {lockingAction ? 'Reopening...' : 'Confirm Reopen'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </div>

      {/* Company-Branded Print Preview Modal */}
      {printPreviewOpen && (
        <div className="print-modal-root fixed inset-0 z-50 bg-slate-900/60 overflow-y-auto p-3 sm:p-6 flex justify-center items-start">
          <div className="print-sheet bg-white border border-slate-200 rounded-xl w-full max-w-5xl shadow-xl overflow-hidden my-2">
            {/* Modal Action Bar (hidden when printing) */}
            <div className="no-print px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Print Preview — Daily Receiving Summary</h3>
                <p className="text-xs text-slate-500">
                  {previewBranchName} · {selectedDate}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Print Sheet
                </button>
                <button
                  type="button"
                  onClick={() => setPrintPreviewOpen(false)}
                  className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  <X className="w-4 h-4" />
                  Close Preview
                </button>
              </div>
            </div>

            {/* Printable Summary Content */}
            <div className="p-6 sm:p-8 space-y-6 text-slate-900">
              {/* Branded Header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-5 border-b-2 border-slate-900">
                <div className="flex items-center gap-4">
                  <img
                    src="/assets/aistudio/image_ea5d3a57.png"
                    alt="KM Trading — Symbol Of Confidence"
                    className="h-14 w-auto object-contain shrink-0"
                  />
                  <div>
                    <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                      KM Trading — Daily Receiving Summary
                    </h2>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Fruits & Vegetables Branch Transfer Verification Sheet
                    </p>
                  </div>
                </div>

                <div className="text-xs space-y-1 sm:text-right">
                  <div>
                    <span className="text-slate-500">Branch:</span>{' '}
                    <strong className="text-slate-900">{previewBranchName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Receiving Date:</span>{' '}
                    <strong className="font-mono text-slate-900">{selectedDate}</strong>
                    <span className="mx-1.5 text-slate-400">·</span>
                    <span className={isDayOpen ? 'font-semibold text-emerald-700' : 'font-semibold text-slate-900'}>
                      {isDayOpen ? 'Open' : 'Locked'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Prepared By:</span>{' '}
                    <span className="text-slate-800">{user.full_name}</span>
                  </div>
                  {filterDoc.trim() && (
                    <div>
                      <span className="text-slate-500">GRN Filter:</span>{' '}
                      <span className="font-mono text-slate-800">{filterDoc.trim()}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Summary Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Line Items</div>
                  <div className="text-base font-bold font-mono tabular-nums mt-0.5">{entries.length}</div>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Transferred Qty</div>
                  <div className="text-base font-bold font-mono tabular-nums mt-0.5">{formatQty(dayTotals.tQty)}</div>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Received Qty</div>
                  <div className="text-base font-bold font-mono tabular-nums mt-0.5">{formatQty(dayTotals.rQty)}</div>
                </div>
                <div className="border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Net Diff Qty</div>
                  <div className="text-base font-bold font-mono tabular-nums mt-0.5">{formatQty(dayTotals.dQty)}</div>
                </div>
                <div className="col-span-2 sm:col-span-1 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Net Diff / Loss Value</div>
                  <div
                    className={`text-base font-bold font-mono tabular-nums mt-0.5 ${
                      dayTotals.dVal > 0 ? 'text-red-700' : 'text-slate-900'
                    }`}
                  >
                    {formatMoney(dayTotals.dVal)}
                  </div>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="border border-slate-300 rounded-lg overflow-hidden">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-300 font-semibold text-slate-700">
                      <th className="py-2 px-2.5">#</th>
                      <th className="py-2 px-2.5">Doc No.</th>
                      {user.role !== 'branch' && !filterBranchId && <th className="py-2 px-2.5">Branch</th>}
                      <th className="py-2 px-2.5">Product & Barcode</th>
                      <th className="py-2 px-2.5 text-right">Trans.</th>
                      <th className="py-2 px-2.5 text-right">Rec.</th>
                      <th className="py-2 px-2.5 text-right">Diff Qty</th>
                      <th className="py-2 px-2.5 text-right bg-red-100/80 text-red-900 border-x border-red-200">Price *</th>
                      <th className="py-2 px-2.5 text-right">Rec. Value</th>
                      <th className="py-2 px-2.5 text-right">Diff Value</th>
                      <th className="py-2 px-2.5">Status / Reason</th>
                      <th className="py-2 px-2.5">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {entries.length === 0 ? (
                      <tr>
                        <td colSpan={12} className="py-8 text-center text-slate-500">
                          No receiving entries recorded for {selectedDate}.
                        </td>
                      </tr>
                    ) : (
                      entries.map((row, idx) => {
                        const isShort = row.difference_qty > 0.0001;
                        const isExcess = row.difference_qty < -0.0001;
                        return (
                          <tr key={row.id}>
                            <td className="py-2 px-2.5 font-mono text-slate-500">{idx + 1}</td>
                            <td className="py-2 px-2.5 font-mono font-medium">{row.document_number}</td>
                            {user.role !== 'branch' && !filterBranchId && (
                              <td className="py-2 px-2.5">{row.branch_name}</td>
                            )}
                            <td className="py-2 px-2.5">
                              <div className="font-medium text-slate-900">{row.product_name_snapshot}</div>
                              <div className="text-[11px] font-mono text-slate-500">
                                {row.barcode_snapshot} · {row.unit_snapshot}
                              </div>
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono tabular-nums">
                              {formatQty(row.transferred_qty, row.unit_snapshot)}
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono tabular-nums">
                              {formatQty(row.received_qty, row.unit_snapshot)}
                            </td>
                            <td
                              className={`py-2 px-2.5 text-right font-mono tabular-nums font-semibold ${
                                isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                              }`}
                            >
                              {formatQty(row.difference_qty, row.unit_snapshot)}
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono tabular-nums bg-red-50/80 text-red-950 font-medium border-x border-red-200/80">
                              {formatMoney(row.unit_price)}
                            </td>
                            <td className="py-2 px-2.5 text-right font-mono tabular-nums">
                              {formatMoney(row.received_value)}
                            </td>
                            <td
                              className={`py-2 px-2.5 text-right font-mono tabular-nums font-semibold ${
                                isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                              }`}
                            >
                              {formatMoney(row.difference_value)}
                            </td>
                            <td className="py-2 px-2.5">
                              <span
                                className={`font-semibold ${
                                  isShort ? 'text-red-700' : isExcess ? 'text-amber-700' : 'text-emerald-700'
                                }`}
                              >
                                {isShort ? 'Short' : isExcess ? 'Excess' : 'Match'}
                              </span>
                              {row.reason_name && <div className="text-slate-600">{row.reason_name}</div>}
                            </td>
                            <td className="py-2 px-2.5 text-slate-600">{row.remarks || '—'}</td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                  {entries.length > 0 && (
                    <tfoot>
                      <tr className="bg-slate-100 border-t border-slate-300 font-bold text-slate-900">
                        <td colSpan={user.role !== 'branch' && !filterBranchId ? 4 : 3} className="py-2.5 px-2.5">
                          Day Totals ({entries.length} items)
                        </td>
                        <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">{formatQty(dayTotals.tQty)}</td>
                        <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">{formatQty(dayTotals.rQty)}</td>
                        <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">{formatQty(dayTotals.dQty)}</td>
                        <td className="py-2.5 px-2.5 bg-red-100/70 border-x border-red-200"></td>
                        <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">{formatMoney(dayTotals.rVal)}</td>
                        <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">{formatMoney(dayTotals.dVal)}</td>
                        <td colSpan={2}></td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>

              {/* Management Signature Section */}
              <div className="pt-4">
                <div className="text-xs font-semibold text-slate-700 mb-4">
                  Verification & Management Sign-Off
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="border border-slate-300 rounded-lg p-4">
                    <div className="text-xs font-semibold text-slate-800">Prepared By (Branch Receiver)</div>
                    <div className="h-12 border-b border-slate-400 mt-4"></div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                      <span>Name: {user.full_name}</span>
                      <span>Date: {selectedDate}</span>
                    </div>
                  </div>

                  <div className="border border-slate-300 rounded-lg p-4">
                    <div className="text-xs font-semibold text-slate-800">Verified By (Branch In-Charge)</div>
                    <div className="h-12 border-b border-slate-400 mt-4"></div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                      <span>Name: ___________________</span>
                      <span>Date: ____________</span>
                    </div>
                  </div>

                  <div className="border border-slate-300 rounded-lg p-4">
                    <div className="text-xs font-semibold text-slate-800">Approved By (Management)</div>
                    <div className="h-12 border-b border-slate-400 mt-4"></div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2">
                      <span>Name: ___________________</span>
                      <span>Date: ____________</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <span>KM Trading — Symbol Of Confidence</span>
                <span>Printed on {new Date().toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

