import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Calculator,
  Check,
  Copy,
  Download,
  FileText,
  Layers,
  Lock,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import { apiDownload } from '../lib/api';
import type { UserRole } from '../types';

type PortfolioSection = 'all' | 'problem' | 'input' | 'process' | 'output' | 'prompt';

interface ProjectPortfolioPageProps {
  isAuthenticated: boolean;
  userRole?: UserRole;
  onBackToSignIn?: () => void;
  onOpenReceiving?: () => void;
}

const FULL_APPLICATION_PROMPT = `KM Trading: Fruits & Vegetables Branch Receiving Web App

Role and Goal
Build a simple, clean, mobile-friendly full-stack web application (with installable PWA support) for KM Trading to record and monitor fruits and vegetables transferred from the Warehouse to company Branches (10 Oman sales locations). Branch staff manually enter what each branch actually received. The app must automatically calculate differences between transferred and received quantities (shortage, wastage, weight loss), require a reason for every difference, lock each day's report at day end, and provide daily and monthly summaries for all locations so management can spot receiving mistakes and take immediate action.

Scope Constraints
- No barcode scanning (no camera scanner, no scanner integration).
- No document, PDF, or image attachments on transactions.
- All transaction data is entered manually by typing.
- The only file upload allowed is Master Data Upload (Excel .xlsx or CSV).

Master Data Management
1. Products Master: barcode (typed unique text), product name, unit (kg, pcs, or pack), default price per unit, category (Fruit or Vegetable), active flag.
2. Master Data Upload: Admin-only screen with downloadable Excel/CSV template, row-by-row validation preview (new, update, invalid, duplicate), bulk upsert matched by barcode, summary counts (added/updated/failed), and downloadable failed rows report.
3. Master Data Maintenance: Search, filter, add/edit/toggle products, delete only if zero transactions exist, export to Excel, and log all changes to audit_log. Price updates apply only to new entries; locked reports keep saved snapshot prices.
4. Branches, Reasons & Users: Admin manages branches, default variance reasons (Shortage, Wastage or damage, Weight loss or drying, Quality rejection, Wrong item sent, Other), and users (username, hashed password, role, assigned branch).

Daily Receiving Entry Screen
- Date defaults to today; only Open days are editable.
- Branch auto-assigned and strictly isolated for Branch users; selectable for Admin.
- Document / GRN number typed as text; multiple products allowed under one document.
- Split Barcode and Product fields: typing a matching barcode auto-fills the Product, Unit, and Default Price; staff can also search by Product Name or quick-create a new product inline when not yet in Master Data.
- Unit selector supporting KG, PCS, and PACK (quantities accept up to 3 decimals).
- Unit Price column is mandatory and highlighted in light red for manual verification/entry.
- Live auto-calculation of Difference Qty (Transferred - Received), Transferred Value, Received Value, and Difference Value (with optional manual Value override).
- Reason dropdown is mandatory whenever Difference Qty is not zero; optional Remarks.
- Color-coded rows: Shortage (red), Excess (orange), Exact Match (green).
- Branded Print Preview with KM Trading logo, document summary, and Prepared / Branch Incharge / Management signature lines.

Day Locking, Security & Audit Trail
- Each date has status Open or Locked (past dates auto-lock).
- Admin or Manager closes the day at day end; only Admin can reopen a locked day with a mandatory audit reason.
- Secure authentication with PBKDF2 hashed passwords, 8+ char alphanumeric policy, forced password change for temporary passwords, 5-attempt lockout, Change Password, Forgot Password request workflow, 30-minute one-time reset links, and Remember Me vs. 30-minute idle timeout.
- Strict server-side branch data isolation across all receiving and report APIs.

Reports & Variance Monitoring Dashboard
- Variance Monitoring Dashboard: today's total loss value, branches with highest loss %, threshold alerts (default 5%, configurable by Admin), top repeated shortage products, and top reasons.
- Daily Report per branch, Daily Consolidated Report (all branches + grand total), and Monthly Report (per branch, per product, per reason, daily breakdown) with date/branch/product/reason filters.
- Export to PDF, Excel (.xlsx), CSV, and Print.

Technical Stack
- Frontend: React 19, TypeScript, Tailwind CSS, SheetJS (xlsx), jsPDF + AutoTable, VitePWA.
- Backend: Node.js, Express, SQLite (better-sqlite3 WAL mode) with 13 relational tables and automated branch-isolation & auth security tests.`;

const PROBLEM_STEPS = [
  {
    step: '01',
    title: 'Unmonitored Warehouse-to-Branch Shrinkage',
    detail:
      'Fresh fruits and vegetables transferred from the Central Warehouse to 10 retail branches experience physical shortages, bruising, spoilage, and moisture weight loss during transit.',
    impact: 'Without row-level receiving logs, true transit loss stayed hidden inside branch inventory adjustments.',
  },
  {
    step: '02',
    title: 'Delayed Paper & Spreadsheet Reconciliation',
    detail:
      'Paper GRN slips and manual end-of-week spreadsheets delayed loss visibility, preventing Head Office from catching repeated receiving mistakes on the same day.',
    impact: 'Management lacked a consolidated same-day view across Al Amerat, Ruwi, Salalah, and 7 other outlets.',
  },
  {
    step: '03',
    title: 'Missing Variance Accountability',
    detail:
      'Receiving staff previously noted net counts without structured root-cause classification or financial valuation of each unit lost.',
    impact: 'Procurement and logistics could not distinguish drying weight loss from wrong-item dispatch or quality rejection.',
  },
  {
    step: '04',
    title: 'Mutable History & Price Drift Risk',
    detail:
      'Master catalog prices fluctuate daily for produce. Editing a master price or reopening old spreadsheets risked altering past financial variance figures.',
    impact: 'Reports required immutable unit/price snapshots and formal day-end locking with audited Admin-only reopening.',
  },
  {
    step: '05',
    title: 'Branch Isolation & Device Security Gaps',
    detail:
      'Branch teams needed fast mobile access restricted strictly to their own outlet, while Managers and Admins required cross-branch analytics and print sign-off.',
    impact: 'Required strict server-side RBAC, shared-device idle timeouts, and guided temporary-password onboarding.',
  },
];

const INPUT_STAGES = [
  {
    stage: '01. Master Data & Catalog Setup',
    actor: 'Head Office Admin',
    format: 'Excel (.xlsx), CSV, or Form Entry',
    fields: 'barcode, product_name, unit (kg/pcs/pack), default_price, category (Fruit/Vegetable), active, branches, reasons, staff accounts',
  },
  {
    stage: '02. Staff Authentication & Context',
    actor: 'Admin / Manager / Branch User',
    format: 'Credentials or 30-Min Reset Token',
    fields: 'username or email, password (min 8 chars + letter & number), rememberMe flag, server-bound branch_id',
  },
  {
    stage: '03. Daily Receiving Transaction Row',
    actor: 'Branch Receiver / Admin',
    format: 'Manual Keyboard Entry (No Scanner)',
    fields: 'entry_date, branch_id, document_number (GRN), barcode, product_id, unit (kg/pcs/pack), transferred_qty, received_qty, mandatory unit_price, optional value override, reason_id, remarks',
  },
  {
    stage: '04. Day Lock & Governance Controls',
    actor: 'Manager / Admin',
    format: 'Workflow Action + Audit Note',
    fields: 'Close Day command, Admin Reopen reason (min 3 chars), configurable alert_threshold_pct (default 5%)',
  },
];

const PROCESS_PIPELINE = [
  {
    step: '01. Catalog Resolution & Snapshotting',
    description:
      'Typing a barcode automatically resolves the active Product, Unit, and Default Price (or allows inline quick-creation of a new SKU). On save, barcode, product name, unit, and category are written as immutable snapshots onto receiving_items.',
  },
  {
    step: '02. Deterministic Variance & Financial Calculation',
    description:
      'Quantities are rounded to 3 decimals (kg) and currency to 2 decimals. Difference Qty = Transferred - Received. Transferred/Received Values multiply Qty by mandatory Unit Price unless manually overridden. Loss % = (Difference Qty / Transferred Qty) × 100.',
  },
  {
    step: '03. Server-Side Validation & Branch Isolation',
    description:
      'Express routes reject missing mandatory unit prices, reject non-zero differences lacking an active Reason, block branch users from reading or mutating any foreign branch_id, and block edits on locked dates.',
  },
  {
    step: '04. Day-End Locking & Immutable Audit Trail',
    description:
      'Closing a date records status = locked in daily_lock; past dates lock automatically. Every CREATE, UPDATE, DELETE, LOCK_DAY, REOPEN_DAY, MASTER_UPLOAD, and auth action stores old/new JSON diffs in audit_log.',
  },
  {
    step: '05. Multi-Branch Aggregation & Threshold Alerting',
    description:
      'SQL aggregations compute per-branch, per-product, per-reason, and daily rollups, flagging any entry or branch whose |Loss %| exceeds the Admin-configured alert threshold.',
  },
];

const OUTPUT_DELIVERABLES = [
  {
    name: 'Color-Coded Daily Receiving Ledger',
    audience: 'Branch Staff & Admin',
    description:
      'Live daily entry table highlighting Shortage rows in red, Excess rows in orange, and Exact Matches in green with inline edit/delete while Open.',
  },
  {
    name: 'Company-Branded Print Preview Sheet',
    audience: 'Branch Incharge & Management',
    description:
      'Landscape A4 printable receiving report featuring the KM Trading logo, document totals, variance breakdown, and 3 signature blocks.',
  },
  {
    name: 'Variance Monitoring Dashboard',
    audience: 'Head Office Management',
    description:
      'Real-time daily loss value, branch loss ranking, threshold breach alerts, top 30-day repeated shortage SKUs, and top variance reasons.',
  },
  {
    name: 'Daily, Consolidated & Monthly Exports',
    audience: 'Finance & Operations',
    description:
      'Filterable reports (by date range, branch, product, reason) exported cleanly to PDF, Excel (.xlsx), CSV, and Print.',
  },
  {
    name: 'Audit Log & Upload Validation Report',
    audience: 'Head Office Admin',
    description:
      'Searchable compliance log of all data/auth events plus bulk upload validation counts and downloadable failed-row error sheets.',
  },
];

const DATABASE_TABLES = [
  'branches',
  'users',
  'products',
  'reasons',
  'receiving_documents',
  'receiving_items',
  'daily_lock',
  'settings',
  'master_upload_log',
  'audit_log',
  'password_reset_requests',
  'password_reset_tokens',
  'sessions',
];

export function ProjectPortfolioPage({
  isAuthenticated,
  userRole,
  onBackToSignIn,
  onOpenReceiving,
}: ProjectPortfolioPageProps) {
  const [section, setSection] = useState<PortfolioSection>('all');
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipError, setZipError] = useState<string | null>(null);

  // Interactive variance simulator for the Process section
  const [simTransferred, setSimTransferred] = useState('10');
  const [simReceived, setSimReceived] = useState('8');
  const [simUnitPrice, setSimUnitPrice] = useState('2.50');
  const [simThreshold, setSimThreshold] = useState('5');

  const simResult = useMemo(() => {
    const tQty = Math.max(0, Number(simTransferred) || 0);
    const rQty = Math.max(0, Number(simReceived) || 0);
    const price = Math.max(0, Number(simUnitPrice) || 0);
    const threshold = Math.max(0, Number(simThreshold) || 0);

    const diffQty = Math.round((tQty - rQty + Number.EPSILON) * 1000) / 1000;
    const tVal = Math.round((tQty * price + Number.EPSILON) * 100) / 100;
    const rVal = Math.round((rQty * price + Number.EPSILON) * 100) / 100;
    const diffVal = Math.round((tVal - rVal + Number.EPSILON) * 100) / 100;
    const lossPct = tQty > 0 ? Math.round(((diffQty / tQty) * 100 + Number.EPSILON) * 100) / 100 : 0;
    const isAlert = Math.abs(lossPct) > threshold && tQty > 0;
    const status = diffQty > 0.0001 ? 'Shortage' : diffQty < -0.0001 ? 'Excess' : 'Exact Match';
    const requiresReason = Math.abs(diffQty) > 0.0001;

    return { tQty, rQty, diffQty, tVal, rVal, diffVal, lossPct, isAlert, status, requiresReason };
  }, [simTransferred, simReceived, simUnitPrice, simThreshold]);

  async function handleCopyPrompt() {
    try {
      await navigator.clipboard.writeText(FULL_APPLICATION_PROMPT);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2000);
    } catch {
      setCopiedPrompt(false);
    }
  }

  function handleDownloadPrompt() {
    const blob = new Blob([FULL_APPLICATION_PROMPT], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'km_trading_receiving_prompt.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function handleDownloadProjectZip() {
    setZipError(null);
    setDownloadingZip(true);
    try {
      await apiDownload('/api/project/export-zip', 'km-trading-web-app.zip');
    } catch (err) {
      setZipError(err instanceof Error ? err.message : 'Failed to download project ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  }

  const tabs: Array<{ key: PortfolioSection; label: string }> = [
    { key: 'all', label: 'Overview (All Steps)' },
    { key: 'problem', label: '1. Problem Statement' },
    { key: 'input', label: '2. Input' },
    { key: 'process', label: '3. Process' },
    { key: 'output', label: '4. Output' },
    { key: 'prompt', label: '5. Full Prompt' },
  ];

  const show = (target: Exclude<PortfolioSection, 'all'>) => section === 'all' || section === target;

  return (
    <div className={isAuthenticated ? 'space-y-8 max-w-6xl' : 'min-h-screen bg-slate-50 py-6 px-4 sm:px-8'}>
      <div className={isAuthenticated ? 'space-y-8' : 'max-w-6xl mx-auto space-y-8'}>
        {/* Hero Header */}
        <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 print-container">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="flex items-center gap-4">
                <img
                  src="/assets/aistudio/image_ea5d3a57.png"
                  alt="KM Trading — Symbol Of Confidence"
                  className="h-12 w-auto object-contain shrink-0"
                />
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span>Project Case Study</span>
                  <span aria-hidden="true">·</span>
                  <span>Full-Stack Web &amp; PWA</span>
                  <span aria-hidden="true">·</span>
                  <span>React 19, Express &amp; SQLite</span>
                </div>
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight text-balance">
                KM Trading: Fruits &amp; Vegetables Branch Receiving &amp; Variance Control
              </h1>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                End-to-end project portfolio documentation covering the operational problem statement, structured inputs,
                calculation and locking pipeline, management outputs, and the complete application build prompt.
              </p>
            </div>

            <div className="no-print flex flex-wrap items-center gap-2.5 shrink-0">
              {!isAuthenticated && onBackToSignIn && (
                <button
                  type="button"
                  onClick={onBackToSignIn}
                  className="min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to Sign In
                </button>
              )}
              {isAuthenticated && onOpenReceiving && (
                <button
                  type="button"
                  onClick={onOpenReceiving}
                  className="min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Daily Receiving
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
              {isAuthenticated && userRole === 'admin' && (
                <button
                  type="button"
                  disabled={downloadingZip}
                  onClick={() => void handleDownloadProjectZip()}
                  className="min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Download className="w-4 h-4" />
                  {downloadingZip ? 'Packaging ZIP...' : 'Download Web App (.zip)'}
                </button>
              )}
              <button
                type="button"
                onClick={() => window.print()}
                className="min-h-[40px] inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Printer className="w-4 h-4" />
                Print Case Study
              </button>
            </div>
          </div>
          {zipError && (
            <div className="no-print mt-4 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {zipError}
            </div>
          )}

          {/* Grounded Architecture KPI Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
            <div>
              <div className="text-xs text-slate-500">Seeded Retail Branches</div>
              <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">10</div>
              <div className="text-xs text-slate-500 mt-0.5">Strictly isolated per login</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Seeded Produce Catalog</div>
              <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">762</div>
              <div className="text-xs text-slate-500 mt-0.5">SKUs across kg, pcs &amp; pack</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">SQLite Relational Schema</div>
              <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">13</div>
              <div className="text-xs text-slate-500 mt-0.5">Tables with WAL &amp; audit log</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Role &amp; Account Tiers</div>
              <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">3 / 12</div>
              <div className="text-xs text-slate-500 mt-0.5">Admin, Manager &amp; 10 Branches</div>
            </div>
          </div>
        </section>

        {/* Interactive Section Filter Bar */}
        <div className="no-print flex flex-wrap items-center gap-1.5 p-1.5 bg-white border border-slate-200 rounded-xl">
          {tabs.map((tab) => {
            const active = section === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setSection(tab.key)}
                className={`min-h-[38px] px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  active ? 'bg-emerald-700 text-white' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 01. Step-by-Step Problem Statement */}
        {show('problem') && (
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-bold text-slate-900">01. Step-by-Step Problem Statement</h2>
                <p className="text-sm text-slate-600 mt-1">
                  Why warehouse-to-branch fresh produce transfers required real-time variance governance.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">5 Operational Gaps Identified</span>
            </div>

            <div className="divide-y divide-slate-100">
              {PROBLEM_STEPS.map((item) => (
                <div key={item.step} className="py-4 first:pt-0 last:pb-0 grid grid-cols-1 lg:grid-cols-12 gap-3 lg:gap-6">
                  <div className="lg:col-span-4 flex items-baseline gap-3">
                    <span className="font-mono text-sm font-bold text-emerald-700 tabular-nums">{item.step}.</span>
                    <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
                  </div>
                  <p className="lg:col-span-4 text-sm text-slate-600 leading-relaxed">{item.detail}</p>
                  <p className="lg:col-span-4 text-sm text-slate-700 leading-relaxed">{item.impact}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* 02. Step-by-Step Input */}
        {show('input') && (
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-bold text-slate-900">02. Input Architecture (Step-by-Step)</h2>
                <p className="text-sm text-slate-600 mt-1">
                  Structured manual inputs, validated spreadsheets, and access credentials entering the system.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">Keyboard Entry · No Scanner</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 pr-4">Input Stage</th>
                    <th className="py-2.5 pr-4">Role / Actor</th>
                    <th className="py-2.5 pr-4">Channel &amp; Format</th>
                    <th className="py-2.5">Captured Fields &amp; Constraints</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {INPUT_STAGES.map((row) => (
                    <tr key={row.stage} className="align-top hover:bg-slate-50/70">
                      <td className="py-3.5 pr-4 font-semibold text-slate-900 whitespace-nowrap">{row.stage}</td>
                      <td className="py-3.5 pr-4 text-slate-700 whitespace-nowrap">{row.actor}</td>
                      <td className="py-3.5 pr-4 text-slate-600 whitespace-nowrap">{row.format}</td>
                      <td className="py-3.5 text-slate-600 font-mono text-xs leading-relaxed">{row.fields}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {/* 03. Step-by-Step Process + Interactive Formula Simulator */}
        {show('process') && (
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-bold text-slate-900">03. System Process &amp; Calculation Engine</h2>
                <p className="text-sm text-slate-600 mt-1">
                  How the Express API and SQLite database validate, compute, lock, and audit every transfer row.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">5-Stage Server Pipeline</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <ol className="lg:col-span-7 space-y-4">
                {PROCESS_PIPELINE.map((item) => (
                  <li key={item.step} className="pb-4 border-b border-slate-100 last:border-b-0 last:pb-0">
                    <h3 className="text-sm font-semibold text-slate-900">{item.step}</h3>
                    <p className="text-sm text-slate-600 mt-1 leading-relaxed">{item.description}</p>
                  </li>
                ))}
              </ol>

              {/* Interactive Process Logic Simulator */}
              <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <Calculator className="w-4 h-4 text-emerald-700" />
                  <span>Live Variance Process Simulator</span>
                </div>
                <p className="text-xs text-slate-600">
                  Test the exact server-side formula (e.g., Onion 10 kg transferred vs. 8 kg received).
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="sim-trf" className="block text-xs font-medium text-slate-700 mb-1">
                      Transferred Qty
                    </label>
                    <input
                      id="sim-trf"
                      type="number"
                      min="0"
                      step="0.001"
                      value={simTransferred}
                      onChange={(e) => setSimTransferred(e.target.value)}
                      className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label htmlFor="sim-rcv" className="block text-xs font-medium text-slate-700 mb-1">
                      Received Qty
                    </label>
                    <input
                      id="sim-rcv"
                      type="number"
                      min="0"
                      step="0.001"
                      value={simReceived}
                      onChange={(e) => setSimReceived(e.target.value)}
                      className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label htmlFor="sim-price" className="block text-xs font-medium text-red-800 mb-1">
                      Unit Price (Mandatory)
                    </label>
                    <input
                      id="sim-price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={simUnitPrice}
                      onChange={(e) => setSimUnitPrice(e.target.value)}
                      className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono tabular-nums bg-red-50 border border-red-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label htmlFor="sim-thresh" className="block text-xs font-medium text-slate-700 mb-1">
                      Alert Threshold %
                    </label>
                    <input
                      id="sim-thresh"
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={simThreshold}
                      onChange={(e) => setSimThreshold(e.target.value)}
                      className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Row Classification</span>
                    <span
                      className={`font-semibold ${
                        simResult.status === 'Shortage'
                          ? 'text-red-700'
                          : simResult.status === 'Excess'
                          ? 'text-orange-700'
                          : 'text-emerald-700'
                      }`}
                    >
                      {simResult.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Difference Qty</span>
                    <span className="font-mono font-semibold tabular-nums text-slate-900">{simResult.diffQty}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Transferred / Received Value</span>
                    <span className="font-mono tabular-nums text-slate-900">
                      {simResult.tVal.toFixed(2)} / {simResult.rVal.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Difference Value (Loss)</span>
                    <span className="font-mono font-bold tabular-nums text-slate-900">
                      {simResult.diffVal.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Loss Percentage</span>
                    <span className={`font-mono font-bold tabular-nums ${simResult.isAlert ? 'text-red-700' : 'text-slate-900'}`}>
                      {simResult.lossPct.toFixed(2)}% {simResult.isAlert ? '(Alert Triggered)' : '(Within Limit)'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-600">Reason Enforcement</span>
                    <span className="font-medium text-slate-800">
                      {simResult.requiresReason ? 'Mandatory (Save Blocked Without Reason)' : 'Not Required'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* 04. Step-by-Step Output & Technical Architecture */}
        {show('output') && (
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-bold text-slate-900">04. Output Deliverables &amp; System Architecture</h2>
                <p className="text-sm text-slate-600 mt-1">
                  Operational screens, printable management sheets, multi-format exports, and SQLite persistence.
                </p>
              </div>
              <span className="text-xs font-mono text-slate-500">PDF · XLSX · CSV · Print · PWA</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {OUTPUT_DELIVERABLES.map((out) => (
                <div key={out.name} className="p-4 border border-slate-200 rounded-lg space-y-1.5">
                  <div className="text-xs text-emerald-700 font-medium">{out.audience}</div>
                  <h3 className="text-sm font-bold text-slate-900">{out.name}</h3>
                  <p className="text-sm text-slate-600 leading-relaxed">{out.description}</p>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-3 gap-6 text-sm">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 font-semibold text-slate-900">
                  <Layers className="w-4 h-4 text-emerald-700" />
                  <span>Frontend &amp; Export Stack</span>
                </div>
                <p className="text-slate-600 text-xs leading-relaxed">
                  React 19, TypeScript, Tailwind CSS v4, Lucide Icons, SheetJS (xlsx), jsPDF + jspdf-autotable, and
                  VitePWA service worker caching.
                </p>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 font-semibold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Security &amp; Verification</span>
                </div>
                <p className="text-slate-600 text-xs leading-relaxed">
                  PBKDF2-SHA512 passwords, HttpOnly cookies + Bearer tokens, 5-attempt 15-minute lockout, forced temp
                  password rotation, and automated branch-isolation test suite.
                </p>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 font-semibold text-slate-900">
                  <Lock className="w-4 h-4 text-emerald-700" />
                  <span>13 SQLite Tables (WAL)</span>
                </div>
                <p className="text-slate-600 font-mono text-[11px] leading-relaxed">
                  {DATABASE_TABLES.join(', ')}
                </p>
              </div>
            </div>
          </section>
        )}

        {/* 05. Full Master Prompt */}
        {show('prompt') && (
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-bold text-slate-900">05. Full Application Build Prompt</h2>
                <p className="text-sm text-slate-600 mt-1">
                  Complete specification prompt incorporating all KM Trading receiving, variance, catalog, security, and
                  reporting requirements.
                </p>
              </div>
              <div className="no-print flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleDownloadPrompt}
                  className="min-h-[38px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download .txt
                </button>
                <button
                  type="button"
                  onClick={() => void handleCopyPrompt()}
                  className="min-h-[38px] inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedPrompt ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedPrompt ? 'Copied' : 'Copy Full Prompt'}
                </button>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 sm:p-5 overflow-x-auto">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-500 mb-3">
                <FileText className="w-3.5 h-3.5" />
                <span>Specification Prompt</span>
              </div>
              <pre className="text-xs sm:text-[13px] font-mono text-slate-800 whitespace-pre-wrap leading-relaxed">
                {FULL_APPLICATION_PROMPT}
              </pre>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
