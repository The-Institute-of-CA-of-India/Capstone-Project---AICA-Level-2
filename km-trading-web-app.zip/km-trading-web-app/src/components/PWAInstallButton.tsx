import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
  fullWidth?: boolean;
}

export function PWAInstallButton({ compact = false, fullWidth = false }: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  const buttonClass = compact
    ? 'min-h-[38px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg cursor-pointer'
    : `${fullWidth ? 'w-full' : ''} min-h-[38px] inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg cursor-pointer transition-colors`;

  async function handleClick() {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) return;
    } else {
      setShowGuide(true);
    }
  }

  const label = compact ? 'App' : isIOS ? 'Install on iOS' : 'Install Android App';

  return (
    <>
      <button type="button" onClick={handleClick} className={buttonClass} title="Install KM Trading App on your phone">
        {isInstallable ? <Download className="w-3.5 h-3.5 shrink-0" /> : <Smartphone className="w-3.5 h-3.5 shrink-0" />}
        <span>{label}</span>
      </button>

      {showGuide && (
        <div
          className="no-print fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="bg-white border border-slate-200 rounded-xl max-w-sm w-full p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {isIOS ? 'Install on iPhone / iPad' : 'Install KM Trading on Android'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isIOS ? (
              <ol className="list-decimal list-inside space-y-2 text-xs text-slate-700 leading-relaxed">
                <li>Open this web app link in <strong>Safari</strong>.</li>
                <li>Tap the <strong>Share</strong> icon in Safari&apos;s toolbar.</li>
                <li>Scroll down and tap <strong>Add to Home Screen</strong>, then tap <strong>Add</strong>.</li>
              </ol>
            ) : (
              <div className="space-y-2.5 text-xs text-slate-700 leading-relaxed">
                <ol className="list-decimal list-inside space-y-2">
                  <li>
                    Open the shared app URL directly in <strong>Google Chrome</strong> on your Android phone or tablet (not inside a preview frame).
                  </li>
                  <li>
                    Tap the <strong>{isAndroid ? '⋮ (Menu)' : 'Install'}</strong> button in Chrome&apos;s top-right corner.
                  </li>
                  <li>
                    Select <strong>Install app</strong> (or <strong>Add to Home screen</strong>) to launch KM Trading as a standalone Android app.
                  </li>
                </ol>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="w-full min-h-[40px] px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
}
