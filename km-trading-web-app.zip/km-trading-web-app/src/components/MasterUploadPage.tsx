import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Download, FileSpreadsheet, Upload, XCircle } from 'lucide-react';
import { apiDownload, apiRequest, formatMoney, getAuthToken } from '../lib/api';
import { exportToCsv, type ExportColumn } from '../lib/exportUtils';
import type { MasterUploadLogEntry, UploadConfirmResult, UploadPreviewRow } from '../types';

export function MasterUploadPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewFilename, setPreviewFilename] = useState('');
  const [previewRows, setPreviewRows] = useState<UploadPreviewRow[] | null>(null);
  const [previewSummary, setPreviewSummary] = useState<{
    total: number;
    newCount: number;
    updateCount: number;
    invalidCount: number;
  } | null>(null);
  const [confirmResult, setConfirmResult] = useState<UploadConfirmResult | null>(null);
  const [logs, setLogs] = useState<MasterUploadLogEntry[]>([]);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadLogs = useCallback(async () => {
    try {
      const res = await apiRequest<MasterUploadLogEntry[]>('/api/master-upload/logs');
      setLogs(res);
    } catch {
      // ignore initial log failure
    }
  }, []);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    setConfirmResult(null);
    setError(null);
    setLoadingPreview(true);

    try {
      const formData = new FormData();
      formData.append('file', file);
      const token = getAuthToken();
      const res = await fetch('/api/master-upload/preview', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      });

      const body = await res.json();
      if (!res.ok) {
        throw new Error(body.error || 'Preview failed');
      }

      setPreviewFilename(body.filename);
      setPreviewRows(body.rows);
      setPreviewSummary(body.summary);
    } catch (err) {
      setPreviewRows(null);
      setPreviewSummary(null);
      setError(err instanceof Error ? err.message : 'Failed to validate uploaded file.');
    } finally {
      setLoadingPreview(false);
    }
  }

  async function handleConfirmImport() {
    if (!previewRows) return;
    setConfirming(true);
    setError(null);
    try {
      const result = await apiRequest<UploadConfirmResult>('/api/master-upload/confirm', {
        method: 'POST',
        body: JSON.stringify({
          filename: previewFilename || selectedFile?.name || 'import.xlsx',
          rows: previewRows,
        }),
      });
      setConfirmResult(result);
      setPreviewRows(null);
      setPreviewSummary(null);
      setSelectedFile(null);
      await loadLogs();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Import failed.');
    } finally {
      setConfirming(false);
    }
  }

  function downloadFailedRows(failedRows: UploadPreviewRow[]) {
    const cols: ExportColumn[] = [
      { header: 'Row Number', key: 'rowNumber' },
      { header: 'Barcode', key: 'barcode' },
      { header: 'Product Name', key: 'product_name' },
      { header: 'Unit', key: 'unit' },
      { header: 'Default Price', key: 'default_price' },
      { header: 'Category', key: 'category' },
      { header: 'Failure Reason', key: 'reason' },
    ];
    const mapped = failedRows.map((r) => ({
      ...r,
      reason: r.errors.join('; '),
    }));
    exportToCsv('km_trading_failed_upload_rows.csv', cols, mapped);
  }

  const validCount = (previewSummary?.newCount || 0) + (previewSummary?.updateCount || 0);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Master Data Upload</h1>
          <p className="text-xs text-slate-500 mt-1">
            Bulk upload or refresh Fruits & Vegetables products from Excel (.xlsx) or CSV (.csv)
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => apiDownload('/api/master-upload/template?format=xlsx', 'km_trading_products_template.xlsx')}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Download Excel Template
          </button>
          <button
            type="button"
            onClick={() => apiDownload('/api/master-upload/template?format=csv', 'km_trading_products_template.csv')}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4" />
            Download CSV Template
          </button>
        </div>
      </div>

      {/* Upload Box */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900">1. Choose Spreadsheet File</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Required columns: <code className="font-mono">barcode</code>, <code className="font-mono">product_name</code>,{' '}
            <code className="font-mono">unit</code> (kg, pcs, or pack), <code className="font-mono">default_price</code>,{' '}
            <code className="font-mono">category</code> (Fruit or Vegetable), <code className="font-mono">active</code> (Yes/No).
          </p>
        </div>

        <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-emerald-600 rounded-xl p-8 bg-slate-50/60 cursor-pointer transition-colors">
          <Upload className="w-7 h-7 text-emerald-700 mb-2" />
          <span className="text-sm font-semibold text-slate-900">
            {loadingPreview ? 'Validating file...' : selectedFile ? selectedFile.name : 'Click to select .xlsx, .xls, or .csv file'}
          </span>
          <span className="text-xs text-slate-500 mt-1">All rows are validated and previewed before saving</span>
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileSelect}
            className="hidden"
          />
        </label>

        {error && (
          <div className="p-4 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">{error}</div>
        )}
      </div>

      {/* Validation Preview Table */}
      {previewRows && previewSummary && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">2. Validation Preview · {previewFilename}</h2>
              <p className="text-xs text-slate-600 mt-1 font-mono tabular-nums">
                Total: {previewSummary.total} · New: {previewSummary.newCount} · Updates: {previewSummary.updateCount} · Invalid:{' '}
                <span className={previewSummary.invalidCount > 0 ? 'text-red-700 font-bold' : ''}>
                  {previewSummary.invalidCount}
                </span>
              </p>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setPreviewRows(null);
                  setPreviewSummary(null);
                  setSelectedFile(null);
                }}
                className="min-h-[40px] px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Discard
              </button>
              <button
                type="button"
                onClick={handleConfirmImport}
                disabled={confirming || validCount === 0}
                className="min-h-[40px] px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 rounded-lg cursor-pointer"
              >
                {confirming ? 'Importing...' : `Confirm Import (${validCount} valid rows)`}
              </button>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[420px]">
            <table className="w-full text-left border-collapse text-sm">
              <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <tr>
                  <th className="py-2.5 px-3">Row</th>
                  <th className="py-2.5 px-3">Validation</th>
                  <th className="py-2.5 px-3">Barcode</th>
                  <th className="py-2.5 px-3">Product Name</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Unit</th>
                  <th className="py-2.5 px-3 text-right">Price</th>
                  <th className="py-2.5 px-3">Active</th>
                  <th className="py-2.5 px-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {previewRows.map((r) => (
                  <tr
                    key={r.rowNumber}
                    className={
                      r.status === 'invalid'
                        ? 'bg-red-50/70'
                        : r.status === 'update'
                        ? 'bg-amber-50/40'
                        : 'bg-emerald-50/30'
                    }
                  >
                    <td className="py-2 px-3 font-mono text-xs">{r.rowNumber}</td>
                    <td className="py-2 px-3 text-xs font-semibold">
                      {r.status === 'new' && <span className="text-emerald-700">New</span>}
                      {r.status === 'update' && <span className="text-amber-700">Update</span>}
                      {r.status === 'invalid' && <span className="text-red-700">Invalid</span>}
                    </td>
                    <td className="py-2 px-3 font-mono text-xs">{r.barcode || '—'}</td>
                    <td className="py-2 px-3 text-xs font-medium">{r.product_name || '—'}</td>
                    <td className="py-2 px-3 text-xs">{r.category || '—'}</td>
                    <td className="py-2 px-3 font-mono text-xs">{r.unit || '—'}</td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-xs">
                      {r.default_price !== null ? formatMoney(r.default_price) : '—'}
                    </td>
                    <td className="py-2 px-3 text-xs">{r.active === 1 ? 'Yes' : 'No'}</td>
                    <td className="py-2 px-3 text-xs text-red-700">
                      {r.errors.length > 0 ? r.errors.join('; ') : 'Valid'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Import Result Summary */}
      {confirmResult && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              {confirmResult.failed === 0 ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div>
                <h2 className="text-base font-bold text-slate-900">Import Completed</h2>
                <p className="text-sm text-slate-600 mt-1 font-mono tabular-nums">
                  Added: <strong>{confirmResult.added}</strong> · Updated: <strong>{confirmResult.updated}</strong> · Failed:{' '}
                  <strong className={confirmResult.failed > 0 ? 'text-red-700' : ''}>{confirmResult.failed}</strong>
                </p>
              </div>
            </div>

            {confirmResult.failedRows.length > 0 && (
              <button
                type="button"
                onClick={() => downloadFailedRows(confirmResult.failedRows)}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Download Failed Rows ({confirmResult.failedRows.length})
              </button>
            )}
          </div>
        </div>
      )}

      {/* Upload History */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">Recent Master Upload History</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="py-2.5 px-4">Timestamp</th>
                <th className="py-2.5 px-4">Uploaded By</th>
                <th className="py-2.5 px-4">Filename</th>
                <th className="py-2.5 px-4 text-right">Total</th>
                <th className="py-2.5 px-4 text-right">Added</th>
                <th className="py-2.5 px-4 text-right">Updated</th>
                <th className="py-2.5 px-4 text-right">Failed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No bulk uploads recorded yet.
                  </td>
                </tr>
              ) : (
                logs.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-mono text-xs text-slate-600">{l.created_at}</td>
                    <td className="py-2.5 px-4 text-xs font-medium text-slate-900">{l.uploaded_by_name}</td>
                    <td className="py-2.5 px-4 text-xs font-mono">{l.filename}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{l.total_rows}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-emerald-700">{l.added_count}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-amber-700">{l.updated_count}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-red-700">{l.failed_count}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
