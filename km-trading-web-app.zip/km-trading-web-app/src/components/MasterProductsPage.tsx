import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Edit3, FileSpreadsheet, Plus, Power, Search, Trash2, X } from 'lucide-react';
import { apiDownload, apiRequest, formatMoney } from '../lib/api';
import type { AuthUser, Product, ProductCategory, ProductUnit } from '../types';

interface MasterProductsPageProps {
  user: AuthUser;
}

export function MasterProductsPage({ user }: MasterProductsPageProps) {
  const isAdmin = user.role === 'admin';
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState<'ALL' | ProductCategory>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [unit, setUnit] = useState<ProductUnit>('kg');
  const [defaultPrice, setDefaultPrice] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Vegetable');
  const [saving, setSaving] = useState(false);

  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const rows = await apiRequest<Product[]>('/api/products');
      setProducts(rows);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load products.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      if (catFilter !== 'ALL' && p.category !== catFilter) return false;
      if (statusFilter === 'ACTIVE' && p.active !== 1) return false;
      if (statusFilter === 'INACTIVE' && p.active !== 0) return false;
      if (q && !p.name.toLowerCase().includes(q) && !p.barcode.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [products, search, catFilter, statusFilter]);

  function openAddModal() {
    setEditing(null);
    setBarcode('');
    setName('');
    setUnit('kg');
    setDefaultPrice('');
    setCategory('Vegetable');
    setError(null);
    setModalOpen(true);
  }

  function openEditModal(p: Product) {
    setEditing(p);
    setBarcode(p.barcode);
    setName(p.name);
    setUnit(p.unit);
    setDefaultPrice(String(p.default_price));
    setCategory(p.category);
    setError(null);
    setModalOpen(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const payload = {
        barcode: barcode.trim(),
        name: name.trim(),
        unit,
        default_price: Number(defaultPrice),
        category,
        active: editing ? editing.active : 1,
      };
      if (editing) {
        await apiRequest(`/api/products/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        setSuccessMsg(`Updated "${payload.name}". Price changes apply to new entries only.`);
      } else {
        await apiRequest('/api/products', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        setSuccessMsg(`Added product "${payload.name}".`);
      }
      setModalOpen(false);
      await loadProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save product.');
    } finally {
      setSaving(false);
    }
  }

  async function handleToggle(p: Product) {
    setError(null);
    setSuccessMsg(null);
    try {
      await apiRequest(`/api/products/${p.id}/toggle`, { method: 'PATCH' });
      setSuccessMsg(`${p.name} ${p.active === 1 ? 'deactivated' : 'reactivated'}.`);
      await loadProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status.');
    }
  }

  async function handleDelete(p: Product) {
    setError(null);
    setSuccessMsg(null);
    try {
      await apiRequest(`/api/products/${p.id}`, { method: 'DELETE' });
      setSuccessMsg(`Deleted product "${p.name}".`);
      await loadProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete product.');
    }
  }

  async function handleExportExcel() {
    try {
      await apiDownload('/api/products/export', 'km_trading_products_master.xlsx');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to export products.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Products Master</h1>
          <p className="text-xs text-slate-500 mt-1">
            {products.length} products in master catalog · Price updates apply to new entries only
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportExcel}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Master to Excel
          </button>

          {isAdmin && (
            <button
              type="button"
              onClick={openAddModal}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Add Product
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">{error}</div>
      )}
      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-sm text-emerald-800 flex items-center justify-between">
          <span>{successMsg}</span>
          <button type="button" onClick={() => setSuccessMsg(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by product name or barcode..."
            className="w-full min-h-[40px] pl-9 pr-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['ALL', 'Fruit', 'Vegetable'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCatFilter(c)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                  catFilter === c ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {c === 'ALL' ? 'All Categories' : c}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['ALL', 'ACTIVE', 'INACTIVE'] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                  statusFilter === s ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                }`}
              >
                {s === 'ALL' ? 'All' : s === 'ACTIVE' ? 'Active' : 'Inactive'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="py-2.5 px-4">Barcode</th>
                <th className="py-2.5 px-4">Product Name</th>
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4">Unit</th>
                <th className="py-2.5 px-4 text-right">Default Price</th>
                <th className="py-2.5 px-4 text-right">Transactions</th>
                <th className="py-2.5 px-4">Status</th>
                {isAdmin && <th className="py-2.5 px-4 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Loading products...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-500">
                    No products match your search criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((p) => (
                  <tr key={p.id} className={p.active === 0 ? 'bg-slate-50/80 text-slate-500' : 'hover:bg-slate-50'}>
                    <td className="py-2.5 px-4 font-mono text-xs font-medium">{p.barcode}</td>
                    <td className="py-2.5 px-4 font-medium text-slate-900">{p.name}</td>
                    <td className="py-2.5 px-4 text-xs">{p.category}</td>
                    <td className="py-2.5 px-4 font-mono text-xs">{p.unit}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums font-medium">
                      {formatMoney(p.default_price)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-xs">
                      {p.transaction_count ?? 0}
                    </td>
                    <td className="py-2.5 px-4 text-xs font-semibold">
                      {p.active === 1 ? (
                        <span className="text-emerald-700">Active</span>
                      ) : (
                        <span className="text-slate-500">Inactive</span>
                      )}
                    </td>
                    {isAdmin && (
                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEditModal(p)}
                            className="p-2 text-slate-600 hover:text-emerald-700 rounded-md cursor-pointer"
                            title="Edit product"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleToggle(p)}
                            className="p-2 text-slate-600 hover:text-amber-700 rounded-md cursor-pointer"
                            title={p.active === 1 ? 'Deactivate' : 'Reactivate'}
                          >
                            <Power className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(p)}
                            disabled={(p.transaction_count ?? 0) > 0}
                            className="p-2 text-slate-600 hover:text-red-700 disabled:opacity-30 disabled:cursor-not-allowed rounded-md cursor-pointer"
                            title={
                              (p.transaction_count ?? 0) > 0
                                ? 'Cannot delete product with existing transactions'
                                : 'Delete product'
                            }
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">{editing ? 'Edit Product' : 'Add Product'}</h3>
              <button type="button" onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Barcode (Unique Text Reference)</label>
                <input
                  type="text"
                  required
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  placeholder="e.g. KM-VEG-010"
                  className="w-full min-h-[42px] px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Product Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Red Onion"
                  className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ProductCategory)}
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                  >
                    <option value="Vegetable">Vegetable</option>
                    <option value="Fruit">Fruit</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Unit</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value as ProductUnit)}
                    className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg"
                  >
                    <option value="kg">kg</option>
                    <option value="pcs">pcs</option>
                    <option value="pack">pack</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Default Price per Unit</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={defaultPrice}
                  onChange={(e) => setDefaultPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full min-h-[42px] px-3 py-2 text-sm font-mono tabular-nums border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="min-h-[40px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[40px] px-4 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                >
                  {saving ? 'Saving...' : editing ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
