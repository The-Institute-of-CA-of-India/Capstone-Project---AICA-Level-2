import React, { useCallback, useEffect, useState } from 'react';
import { Download, FileSpreadsheet, FileText, Printer } from 'lucide-react';
import { apiRequest, formatMoney, formatPct, formatQty } from '../lib/api';
import { exportToCsv, exportToExcel, exportToPdf, type ExportColumn } from '../lib/exportUtils';
import type { AuthUser, Branch, Product, Reason, ReceivingEntry } from '../types';

interface ReportsPageProps {
  user: AuthUser;
  serverToday: string;
}

type ReportTab = 'daily' | 'consolidated' | 'monthly';
type MonthlySection = 'byBranch' | 'byProduct' | 'byReason' | 'byDay';

export function ReportsPage({ user, serverToday }: ReportsPageProps) {
  const [tab, setTab] = useState<ReportTab>('daily');
  const [monthlySection, setMonthlySection] = useState<MonthlySection>('byBranch');

  // Filters
  const [date, setDate] = useState(serverToday);
  const [useRange, setUseRange] = useState(false);
  const [startDate, setStartDate] = useState(serverToday);
  const [endDate, setEndDate] = useState(serverToday);
  const [month, setMonth] = useState(serverToday.slice(0, 7));
  const [branchId, setBranchId] = useState(user.role === 'branch' && user.branch_id ? String(user.branch_id) : '');
  const [productId, setProductId] = useState('');
  const [reasonId, setReasonId] = useState('');

  // Reference options
  const [branches, setBranches] = useState<Branch[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [reasons, setReasons] = useState<Reason[]>([]);

  // Report data
  const [dailyData, setDailyData] = useState<{
    entries: Array<ReceivingEntry & { loss_pct: number; is_alert: boolean }>;
    alertThresholdPct: number;
    totals: {
      transferredQty: number;
      receivedQty: number;
      differenceQty: number;
      transferredValue: number;
      receivedValue: number;
      differenceValue: number;
      lossPct: number;
    };
  } | null>(null);

  const [consolidatedData, setConsolidatedData] = useState<{
    startDate: string;
    endDate: string;
    alertThresholdPct: number;
    rows: Array<{
      branch_id: number;
      branch_name: string;
      branch_location: string;
      entry_count: number;
      doc_count: number;
      transferred_qty: number;
      received_qty: number;
      difference_qty: number;
      transferred_value: number;
      received_value: number;
      difference_value: number;
      loss_pct: number;
      is_alert: boolean;
    }>;
    grandTotal: {
      entry_count: number;
      transferred_qty: number;
      received_qty: number;
      difference_qty: number;
      transferred_value: number;
      received_value: number;
      difference_value: number;
      loss_pct: number;
    };
  } | null>(null);

  const [monthlyData, setMonthlyData] = useState<{
    month: string;
    startDate: string;
    endDate: string;
    alertThresholdPct: number;
    byBranch: Array<any>;
    byProduct: Array<any>;
    byReason: Array<any>;
    byDay: Array<any>;
    totals: {
      entryCount: number;
      transferredQty: number;
      receivedQty: number;
      differenceQty: number;
      transferredValue: number;
      receivedValue: number;
      differenceValue: number;
      lossPct: number;
    };
  } | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      apiRequest<Branch[]>('/api/branches'),
      apiRequest<Product[]>('/api/products'),
      apiRequest<Reason[]>('/api/reasons'),
    ])
      .then(([b, p, r]) => {
        setBranches(b);
        setProducts(p);
        setReasons(r);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load filters.'));
  }, []);

  const fetchReport = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (branchId) params.set('branchId', branchId);
      if (productId) params.set('productId', productId);
      if (reasonId) params.set('reasonId', reasonId);

      if (tab === 'daily') {
        if (useRange) {
          params.set('startDate', startDate);
          params.set('endDate', endDate);
        } else {
          params.set('date', date);
        }
        const res = await apiRequest<typeof dailyData>(`/api/reports/daily?${params.toString()}`);
        setDailyData(res);
      } else if (tab === 'consolidated') {
        if (useRange) {
          params.set('startDate', startDate);
          params.set('endDate', endDate);
        } else {
          params.set('date', date);
        }
        const res = await apiRequest<typeof consolidatedData>(`/api/reports/consolidated?${params.toString()}`);
        setConsolidatedData(res);
      } else {
        params.set('month', month);
        const res = await apiRequest<typeof monthlyData>(`/api/reports/monthly?${params.toString()}`);
        setMonthlyData(res);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load report.');
    } finally {
      setLoading(false);
    }
  }, [tab, date, useRange, startDate, endDate, month, branchId, productId, reasonId]);

  useEffect(() => {
    fetchReport();
  }, [fetchReport]);

  const activeBranchLabel = branchId
    ? branches.find((b) => String(b.id) === branchId)?.name || 'Selected Branch'
    : 'All Branches';

  const activeDateLabel =
    tab === 'monthly'
      ? `Month: ${month}`
      : useRange
      ? `Range: ${startDate} to ${endDate}`
      : `Date: ${date}`;

  function handleExport(format: 'pdf' | 'xlsx' | 'csv') {
    if (tab === 'daily' && dailyData) {
      const cols: ExportColumn[] = [
        { header: 'Date', key: 'entry_date' },
        { header: 'Branch', key: 'branch_name' },
        { header: 'Doc No.', key: 'document_number' },
        { header: 'Barcode', key: 'barcode_snapshot' },
        { header: 'Product', key: 'product_name_snapshot' },
        { header: 'Unit', key: 'unit_snapshot' },
        { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
        { header: 'Received Qty', key: 'received_qty', align: 'right' },
        { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
        { header: 'Unit Price', key: 'unit_price', align: 'right' },
        { header: 'Diff Value', key: 'difference_value', align: 'right' },
        { header: 'Loss %', key: 'loss_pct_fmt', align: 'right' },
        { header: 'Reason', key: 'reason_name' },
        { header: 'Remarks', key: 'remarks' },
      ];
      const rows = dailyData.entries.map((e) => ({
        ...e,
        loss_pct_fmt: formatPct(e.loss_pct),
        reason_name: e.reason_name || 'Match',
      }));
      const totalsRow = {
        entry_date: 'TOTAL',
        branch_name: '',
        document_number: `${rows.length} rows`,
        barcode_snapshot: '',
        product_name_snapshot: '',
        unit_snapshot: '',
        transferred_qty: formatQty(dailyData.totals.transferredQty),
        received_qty: formatQty(dailyData.totals.receivedQty),
        difference_qty: formatQty(dailyData.totals.differenceQty),
        unit_price: '',
        difference_value: formatMoney(dailyData.totals.differenceValue),
        loss_pct_fmt: formatPct(dailyData.totals.lossPct),
        reason_name: '',
        remarks: '',
      };

      const base = `km_trading_daily_${useRange ? `${startDate}_${endDate}` : date}`;
      if (format === 'xlsx') exportToExcel(base, 'Daily Report', cols, [...rows, totalsRow]);
      if (format === 'csv') exportToCsv(base, cols, [...rows, totalsRow]);
      if (format === 'pdf') {
        exportToPdf({
          filename: base,
          title: 'Daily Receiving Report',
          subtitle: `${activeBranchLabel} | ${activeDateLabel}`,
          columns: cols,
          rows,
          totalsRow,
        });
      }
    } else if (tab === 'consolidated' && consolidatedData) {
      const cols: ExportColumn[] = [
        { header: 'Branch', key: 'branch_name' },
        { header: 'Location', key: 'branch_location' },
        { header: 'Documents', key: 'doc_count', align: 'right' },
        { header: 'Entries', key: 'entry_count', align: 'right' },
        { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
        { header: 'Received Qty', key: 'received_qty', align: 'right' },
        { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
        { header: 'Transferred Value', key: 'transferred_value_fmt', align: 'right' },
        { header: 'Received Value', key: 'received_value_fmt', align: 'right' },
        { header: 'Diff Value', key: 'difference_value_fmt', align: 'right' },
        { header: 'Loss %', key: 'loss_pct_fmt', align: 'right' },
        { header: 'Alert', key: 'alert_label' },
      ];
      const rows = consolidatedData.rows.map((r) => ({
        ...r,
        transferred_value_fmt: formatMoney(r.transferred_value),
        received_value_fmt: formatMoney(r.received_value),
        difference_value_fmt: formatMoney(r.difference_value),
        loss_pct_fmt: formatPct(r.loss_pct),
        alert_label: r.is_alert ? 'ALERT' : 'OK',
      }));
      const totalsRow = {
        branch_name: 'GRAND TOTAL',
        branch_location: '',
        doc_count: '',
        entry_count: consolidatedData.grandTotal.entry_count,
        transferred_qty: formatQty(consolidatedData.grandTotal.transferred_qty),
        received_qty: formatQty(consolidatedData.grandTotal.received_qty),
        difference_qty: formatQty(consolidatedData.grandTotal.difference_qty),
        transferred_value_fmt: formatMoney(consolidatedData.grandTotal.transferred_value),
        received_value_fmt: formatMoney(consolidatedData.grandTotal.received_value),
        difference_value_fmt: formatMoney(consolidatedData.grandTotal.difference_value),
        loss_pct_fmt: formatPct(consolidatedData.grandTotal.loss_pct),
        alert_label: '',
      };

      const base = `km_trading_consolidated_${consolidatedData.startDate}_${consolidatedData.endDate}`;
      if (format === 'xlsx') exportToExcel(base, 'Consolidated', cols, [...rows, totalsRow]);
      if (format === 'csv') exportToCsv(base, cols, [...rows, totalsRow]);
      if (format === 'pdf') {
        exportToPdf({
          filename: base,
          title: 'Daily Consolidated Report (All Locations)',
          subtitle: `${activeBranchLabel} | ${activeDateLabel} | Alert Threshold: ${consolidatedData.alertThresholdPct}%`,
          columns: cols,
          rows,
          totalsRow,
        });
      }
    } else if (tab === 'monthly' && monthlyData) {
      let cols: ExportColumn[] = [];
      let rawRows: any[] = [];
      if (monthlySection === 'byBranch') {
        cols = [
          { header: 'Branch', key: 'branch_name' },
          { header: 'Entries', key: 'entry_count', align: 'right' },
          { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
          { header: 'Received Qty', key: 'received_qty', align: 'right' },
          { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
          { header: 'Diff Value', key: 'difference_value_fmt', align: 'right' },
          { header: 'Loss %', key: 'loss_pct_fmt', align: 'right' },
        ];
        rawRows = monthlyData.byBranch;
      } else if (monthlySection === 'byProduct') {
        cols = [
          { header: 'Barcode', key: 'barcode' },
          { header: 'Product', key: 'product_name' },
          { header: 'Unit', key: 'unit' },
          { header: 'Entries', key: 'entry_count', align: 'right' },
          { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
          { header: 'Received Qty', key: 'received_qty', align: 'right' },
          { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
          { header: 'Diff Value', key: 'difference_value_fmt', align: 'right' },
          { header: 'Loss %', key: 'loss_pct_fmt', align: 'right' },
        ];
        rawRows = monthlyData.byProduct;
      } else if (monthlySection === 'byReason') {
        cols = [
          { header: 'Reason', key: 'reason_name' },
          { header: 'Entries', key: 'entry_count', align: 'right' },
          { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
          { header: 'Received Qty', key: 'received_qty', align: 'right' },
          { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
          { header: 'Diff Value', key: 'difference_value_fmt', align: 'right' },
        ];
        rawRows = monthlyData.byReason;
      } else {
        cols = [
          { header: 'Date', key: 'entry_date' },
          { header: 'Entries', key: 'entry_count', align: 'right' },
          { header: 'Transferred Qty', key: 'transferred_qty', align: 'right' },
          { header: 'Received Qty', key: 'received_qty', align: 'right' },
          { header: 'Diff Qty', key: 'difference_qty', align: 'right' },
          { header: 'Diff Value', key: 'difference_value_fmt', align: 'right' },
          { header: 'Loss %', key: 'loss_pct_fmt', align: 'right' },
        ];
        rawRows = monthlyData.byDay;
      }

      const rows = rawRows.map((r) => ({
        ...r,
        difference_value_fmt: formatMoney(r.difference_value),
        loss_pct_fmt: formatPct(r.loss_pct || 0),
      }));

      const base = `km_trading_monthly_${month}_${monthlySection}`;
      if (format === 'xlsx') exportToExcel(base, monthlySection, cols, rows);
      if (format === 'csv') exportToCsv(base, cols, rows);
      if (format === 'pdf') {
        exportToPdf({
          filename: base,
          title: `Monthly Summary Report (${monthlySection})`,
          subtitle: `${activeBranchLabel} | Month: ${month}`,
          columns: cols,
          rows,
        });
      }
    }
  }

  return (
    <div className="space-y-6">
      {/* Screen Header + Export Actions */}
      <div className="no-print bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Receiving & Variance Reports</h1>
          <p className="text-xs text-slate-500 mt-1">
            {activeBranchLabel} · {activeDateLabel}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <Printer className="w-4 h-4" />
            Print
          </button>
          <button
            type="button"
            onClick={() => handleExport('pdf')}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <FileText className="w-4 h-4" />
            Export PDF
          </button>
          <button
            type="button"
            onClick={() => handleExport('xlsx')}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Excel
          </button>
          <button
            type="button"
            onClick={() => handleExport('csv')}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4" />
            CSV
          </button>
        </div>
      </div>

      {/* Report Tabs + Filter Bar */}
      <div className="no-print bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
          <button
            type="button"
            onClick={() => setTab('daily')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              tab === 'daily' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Daily Report (Entries)
          </button>
          <button
            type="button"
            onClick={() => setTab('consolidated')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              tab === 'consolidated' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Daily Consolidated
          </button>
          <button
            type="button"
            onClick={() => setTab('monthly')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              tab === 'monthly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly Report
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
          {tab === 'monthly' ? (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Month</label>
              <input
                type="month"
                value={month}
                onChange={(e) => e.target.value && setMonth(e.target.value)}
                className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
              />
            </div>
          ) : (
            <>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-700">{useRange ? 'Start Date' : 'Date'}</label>
                  <button
                    type="button"
                    onClick={() => setUseRange(!useRange)}
                    className="text-xs text-emerald-700 hover:underline cursor-pointer"
                  >
                    {useRange ? 'Single Date' : 'Date Range'}
                  </button>
                </div>
                <input
                  type="date"
                  value={useRange ? startDate : date}
                  onChange={(e) => (useRange ? setStartDate(e.target.value) : setDate(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                />
              </div>

              {useRange && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              )}
            </>
          )}

          {user.role !== 'branch' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Branch</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="w-full min-h-[40px] px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
              >
                <option value="">All Branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Product</label>
            <select
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              className="w-full min-h-[40px] px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
            >
              <option value="">All Products</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.barcode})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Reason</label>
            <select
              value={reasonId}
              onChange={(e) => setReasonId(e.target.value)}
              className="w-full min-h-[40px] px-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg"
            >
              <option value="">All Reasons</option>
              {reasons.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">{error}</div>
      )}

      {/* Printable Report Sheet */}
      <div className="print-container bg-white border border-slate-200 rounded-xl overflow-hidden">
        {/* Print-only Header */}
        <div className="hidden print-only p-4 border-b border-slate-300 mb-2">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/image_ea5d3a57.png"
                alt="KM Trading"
                className="h-11 w-auto object-contain"
              />
              <div>
                <h2 className="text-lg font-bold text-black">KM Trading — Fruits & Vegetables Receiving Report</h2>
                <p className="text-xs text-slate-700 mt-0.5">
                  {tab === 'daily'
                    ? 'Daily Receiving Detail'
                    : tab === 'consolidated'
                    ? 'Daily Consolidated Summary'
                    : `Monthly Summary (${monthlySection})`}
                </p>
              </div>
            </div>
            <div className="text-right text-xs text-slate-700">
              <div>Branch: {activeBranchLabel}</div>
              <div>{activeDateLabel}</div>
            </div>
          </div>
        </div>

        {/* Tab 1: Daily Report */}
        {tab === 'daily' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Branch</th>
                  <th className="py-2.5 px-3">Doc No.</th>
                  <th className="py-2.5 px-3">Product</th>
                  <th className="py-2.5 px-3 text-right">Transferred</th>
                  <th className="py-2.5 px-3 text-right">Received</th>
                  <th className="py-2.5 px-3 text-right">Diff Qty</th>
                  <th className="py-2.5 px-3 text-right">Price</th>
                  <th className="py-2.5 px-3 text-right">Diff Value</th>
                  <th className="py-2.5 px-3 text-right">Loss %</th>
                  <th className="py-2.5 px-3">Reason & Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {loading || !dailyData ? (
                  <tr>
                    <td colSpan={11} className="py-8 text-center text-slate-500">
                      Loading report...
                    </td>
                  </tr>
                ) : dailyData.entries.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-slate-500">
                      No entries match the selected filters.
                    </td>
                  </tr>
                ) : (
                  dailyData.entries.map((e) => (
                    <tr key={e.id} className={e.is_alert ? 'bg-red-50/60' : 'hover:bg-slate-50'}>
                      <td className="py-2 px-3 font-mono text-xs whitespace-nowrap">{e.entry_date}</td>
                      <td className="py-2 px-3 text-xs">{e.branch_name}</td>
                      <td className="py-2 px-3 font-mono text-xs">{e.document_number}</td>
                      <td className="py-2 px-3">
                        <div className="text-xs font-medium text-slate-900">{e.product_name_snapshot}</div>
                        <div className="text-[11px] font-mono text-slate-500">
                          {e.barcode_snapshot} · {e.unit_snapshot}
                        </div>
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-xs">
                        {formatQty(e.transferred_qty, e.unit_snapshot)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-xs">
                        {formatQty(e.received_qty, e.unit_snapshot)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-xs font-semibold">
                        {formatQty(e.difference_qty, e.unit_snapshot)}
                      </td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-xs">{formatMoney(e.unit_price)}</td>
                      <td className="py-2 px-3 text-right font-mono tabular-nums text-xs font-semibold">
                        {formatMoney(e.difference_value)}
                      </td>
                      <td
                        className={`py-2 px-3 text-right font-mono tabular-nums text-xs font-semibold ${
                          e.is_alert ? 'text-red-700' : 'text-slate-700'
                        }`}
                      >
                        {formatPct(e.loss_pct)}
                      </td>
                      <td className="py-2 px-3 text-xs text-slate-600">
                        <div>{e.reason_name || 'Match'}</div>
                        {e.remarks && <div className="text-[11px] text-slate-400">{e.remarks}</div>}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {dailyData && dailyData.entries.length > 0 && (
                <tfoot>
                  <tr className="bg-slate-100 border-t border-slate-300 text-xs font-bold text-slate-900">
                    <td colSpan={4} className="py-3 px-3">
                      Totals ({dailyData.entries.length} entries)
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {formatQty(dailyData.totals.transferredQty)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {formatQty(dailyData.totals.receivedQty)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {formatQty(dailyData.totals.differenceQty)}
                    </td>
                    <td className="py-3 px-3"></td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {formatMoney(dailyData.totals.differenceValue)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {formatPct(dailyData.totals.lossPct)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}

        {/* Tab 2: Consolidated Report */}
        {tab === 'consolidated' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Branch</th>
                  <th className="py-2.5 px-4 text-right">Docs</th>
                  <th className="py-2.5 px-4 text-right">Entries</th>
                  <th className="py-2.5 px-4 text-right">Transferred Qty</th>
                  <th className="py-2.5 px-4 text-right">Received Qty</th>
                  <th className="py-2.5 px-4 text-right">Diff Qty</th>
                  <th className="py-2.5 px-4 text-right">Transferred Val</th>
                  <th className="py-2.5 px-4 text-right">Received Val</th>
                  <th className="py-2.5 px-4 text-right">Diff Value</th>
                  <th className="py-2.5 px-4 text-right">Loss %</th>
                  <th className="py-2.5 px-4">Threshold Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {loading || !consolidatedData ? (
                  <tr>
                    <td colSpan={11} className="py-8 text-center text-slate-500">
                      Loading consolidated report...
                    </td>
                  </tr>
                ) : (
                  consolidatedData.rows.map((r) => (
                    <tr key={r.branch_id} className={r.is_alert ? 'bg-red-50/60' : 'hover:bg-slate-50'}>
                      <td className="py-2.5 px-4">
                        <div className="font-medium text-slate-900">{r.branch_name}</div>
                        <div className="text-xs text-slate-500">{r.branch_location}</div>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{r.doc_count}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{r.entry_count}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(r.transferred_qty)}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(r.received_qty)}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                        {formatQty(r.difference_qty)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                        {formatMoney(r.transferred_value)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                        {formatMoney(r.received_value)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                        {formatMoney(r.difference_value)}
                      </td>
                      <td
                        className={`py-2.5 px-4 text-right font-mono tabular-nums font-semibold ${
                          r.is_alert ? 'text-red-700' : 'text-slate-900'
                        }`}
                      >
                        {formatPct(r.loss_pct)}
                      </td>
                      <td className="py-2.5 px-4 text-xs font-semibold">
                        {r.is_alert ? (
                          <span className="text-red-700">Alert (&gt;{consolidatedData.alertThresholdPct}%)</span>
                        ) : r.entry_count === 0 ? (
                          <span className="text-slate-400">No activity</span>
                        ) : (
                          <span className="text-emerald-700">Normal</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {consolidatedData && (
                <tfoot>
                  <tr className="bg-slate-100 border-t border-slate-300 text-xs font-bold text-slate-900">
                    <td className="py-3 px-4">Grand Total</td>
                    <td className="py-3 px-4"></td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {consolidatedData.grandTotal.entry_count}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatQty(consolidatedData.grandTotal.transferred_qty)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatQty(consolidatedData.grandTotal.received_qty)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatQty(consolidatedData.grandTotal.difference_qty)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatMoney(consolidatedData.grandTotal.transferred_value)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatMoney(consolidatedData.grandTotal.received_value)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatMoney(consolidatedData.grandTotal.difference_value)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatPct(consolidatedData.grandTotal.loss_pct)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}

        {/* Tab 3: Monthly Report */}
        {tab === 'monthly' && (
          <div>
            <div className="no-print p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
                {(
                  [
                    ['byBranch', 'Per Branch'],
                    ['byProduct', 'Per Product'],
                    ['byReason', 'Per Reason'],
                    ['byDay', 'Daily Breakdown'],
                  ] as Array<[MonthlySection, string]>
                ).map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setMonthlySection(key)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      monthlySection === key
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              {monthlyData && (
                <div className="text-xs text-slate-600 font-mono tabular-nums">
                  Month Totals: {monthlyData.totals.entryCount} entries · Diff Value:{' '}
                  <strong className="text-slate-900">{formatMoney(monthlyData.totals.differenceValue)}</strong> · Loss:{' '}
                  <strong className="text-slate-900">{formatPct(monthlyData.totals.lossPct)}</strong>
                </div>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-4">
                      {monthlySection === 'byBranch'
                        ? 'Branch'
                        : monthlySection === 'byProduct'
                        ? 'Product / Barcode'
                        : monthlySection === 'byReason'
                        ? 'Reason'
                        : 'Date'}
                    </th>
                    <th className="py-2.5 px-4 text-right">Entries</th>
                    <th className="py-2.5 px-4 text-right">Transferred Qty</th>
                    <th className="py-2.5 px-4 text-right">Received Qty</th>
                    <th className="py-2.5 px-4 text-right">Diff Qty</th>
                    <th className="py-2.5 px-4 text-right">Diff Value</th>
                    {monthlySection !== 'byReason' && <th className="py-2.5 px-4 text-right">Loss %</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {loading || !monthlyData ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        Loading monthly breakdown...
                      </td>
                    </tr>
                  ) : monthlyData[monthlySection].length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-10 text-center text-slate-500">
                        No data recorded for {month}.
                      </td>
                    </tr>
                  ) : (
                    monthlyData[monthlySection].map((row: any, idx: number) => (
                      <tr key={idx} className={row.is_alert && monthlySection !== 'byReason' ? 'bg-red-50/50' : 'hover:bg-slate-50'}>
                        <td className="py-2.5 px-4">
                          {monthlySection === 'byBranch' && <span className="font-medium text-slate-900">{row.branch_name}</span>}
                          {monthlySection === 'byProduct' && (
                            <div>
                              <div className="font-medium text-slate-900">{row.product_name}</div>
                              <div className="text-xs font-mono text-slate-500">
                                {row.barcode} · {row.unit}
                              </div>
                            </div>
                          )}
                          {monthlySection === 'byReason' && <span className="font-medium text-slate-900">{row.reason_name}</span>}
                          {monthlySection === 'byDay' && <span className="font-mono text-slate-900">{row.entry_date}</span>}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono tabular-nums">{row.entry_count}</td>
                        <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(row.transferred_qty)}</td>
                        <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(row.received_qty)}</td>
                        <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                          {formatQty(row.difference_qty)}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                          {formatMoney(row.difference_value)}
                        </td>
                        {monthlySection !== 'byReason' && (
                          <td
                            className={`py-2.5 px-4 text-right font-mono tabular-nums font-semibold ${
                              row.is_alert ? 'text-red-700' : 'text-slate-900'
                            }`}
                          >
                            {formatPct(row.loss_pct)}
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
                {monthlyData && monthlyData[monthlySection].length > 0 && (
                  <tfoot>
                    <tr className="bg-slate-100 border-t border-slate-300 text-xs font-bold text-slate-900">
                      <td className="py-3 px-4">Monthly Total</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{monthlyData.totals.entryCount}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatQty(monthlyData.totals.transferredQty)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatQty(monthlyData.totals.receivedQty)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatQty(monthlyData.totals.differenceQty)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        {formatMoney(monthlyData.totals.differenceValue)}
                      </td>
                      {monthlySection !== 'byReason' && (
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatPct(monthlyData.totals.lossPct)}
                        </td>
                      )}
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
