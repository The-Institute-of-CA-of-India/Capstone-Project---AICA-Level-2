import React, { useCallback, useEffect, useState } from 'react';
import { AlertOctagon, Calendar, RefreshCw } from 'lucide-react';
import { apiRequest, formatMoney, formatPct, formatQty } from '../lib/api';
import type { DashboardSummary } from '../types';

interface DashboardPageProps {
  serverToday: string;
}

export function DashboardPage({ serverToday }: DashboardPageProps) {
  const [date, setDate] = useState(serverToday);
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<DashboardSummary>(`/api/reports/dashboard?date=${date}`);
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard.');
    } finally {
      setLoading(false);
    }
  }, [date]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const alertBranches = data?.branchStats.filter((b) => b.is_alert) || [];
  const hasAlerts = alertBranches.length > 0 || (data?.flaggedEntries.length || 0) > 0;

  return (
    <div className="space-y-6">
      {/* Header Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Variance Monitoring Dashboard</h1>
          <p className="text-xs text-slate-500 mt-1">
            Date: {date} · Alert Threshold: {data ? `${data.alertThresholdPct}%` : '—'} · Day Status:{' '}
            <span className={data?.dayStatus === 'open' ? 'font-semibold text-emerald-700' : 'font-semibold text-red-700'}>
              {data?.dayStatus === 'open' ? 'Open' : 'Locked'}
            </span>
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 rounded-lg px-3 min-h-[40px]">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input
              type="date"
              value={date}
              onChange={(e) => e.target.value && setDate(e.target.value)}
              className="bg-transparent text-sm font-mono text-slate-900 focus:outline-none"
            />
          </div>
          <button
            type="button"
            onClick={loadDashboard}
            className="min-h-[40px] px-3.5 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">{error}</div>
      )}

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Transferred Value</p>
          <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1.5">
            {loading || !data ? '—' : formatMoney(data.totals.transferredValue)}
          </p>
          <p className="text-xs text-slate-500 font-mono tabular-nums mt-1">
            {data ? `${formatQty(data.totals.transferredQty)} total units` : ''}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Actual Received Value</p>
          <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1.5">
            {loading || !data ? '—' : formatMoney(data.totals.receivedValue)}
          </p>
          <p className="text-xs text-slate-500 font-mono tabular-nums mt-1">
            {data ? `${data.totals.entryCount} receiving lines` : ''}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Net Variance / Loss Value</p>
          <p
            className={`text-2xl font-bold font-mono tabular-nums mt-1.5 ${
              (data?.totals.differenceValue || 0) > 0 ? 'text-red-700' : 'text-emerald-700'
            }`}
          >
            {loading || !data ? '—' : formatMoney(data.totals.differenceValue)}
          </p>
          <p className="text-xs text-slate-500 font-mono tabular-nums mt-1">
            {data ? `Diff Qty: ${formatQty(data.totals.differenceQty)}` : ''}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500">Overall Loss Percentage</p>
          <p
            className={`text-2xl font-bold font-mono tabular-nums mt-1.5 ${
              data && Math.abs(data.totals.lossPct) > data.alertThresholdPct ? 'text-red-700' : 'text-slate-900'
            }`}
          >
            {loading || !data ? '—' : formatPct(data.totals.lossPct)}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            {data && Math.abs(data.totals.lossPct) > data.alertThresholdPct
              ? `Exceeds ${data.alertThresholdPct}% threshold`
              : `Within ${data?.alertThresholdPct ?? 5}% threshold`}
          </p>
        </div>
      </div>

      {/* Threshold Alerts Banner & Flagged Items */}
      {data && hasAlerts && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 space-y-4">
          <div className="flex items-start gap-3">
            <AlertOctagon className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-base font-bold text-red-900">
                Variance Threshold Alerts ({'>'} {data.alertThresholdPct}%)
              </h2>
              <p className="text-xs text-red-800 mt-0.5">
                {alertBranches.length} branch(es) and {data.flaggedEntries.length} line item(s) exceeded the configured loss threshold on {date}.
              </p>
            </div>
          </div>

          {data.flaggedEntries.length > 0 && (
            <div className="overflow-x-auto bg-white border border-red-200 rounded-lg">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-red-50/60 border-b border-red-200 text-xs font-semibold text-red-900">
                    <th className="py-2 px-3">Branch</th>
                    <th className="py-2 px-3">Doc No.</th>
                    <th className="py-2 px-3">Product</th>
                    <th className="py-2 px-3 text-right">Transferred</th>
                    <th className="py-2 px-3 text-right">Received</th>
                    <th className="py-2 px-3 text-right">Loss %</th>
                    <th className="py-2 px-3 text-right">Diff Value</th>
                    <th className="py-2 px-3">Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-red-100">
                  {data.flaggedEntries.map((e) => (
                    <tr key={e.id}>
                      <td className="py-2 px-3 text-xs font-medium text-slate-900">{e.branch_name}</td>
                      <td className="py-2 px-3 text-xs font-mono text-slate-700">{e.document_number}</td>
                      <td className="py-2 px-3 text-xs text-slate-900">{e.product_name_snapshot}</td>
                      <td className="py-2 px-3 text-right text-xs font-mono tabular-nums">
                        {formatQty(e.transferred_qty, e.unit_snapshot)}
                      </td>
                      <td className="py-2 px-3 text-right text-xs font-mono tabular-nums">
                        {formatQty(e.received_qty, e.unit_snapshot)}
                      </td>
                      <td className="py-2 px-3 text-right text-xs font-mono tabular-nums font-bold text-red-700">
                        {formatPct(e.loss_pct)}
                      </td>
                      <td className="py-2 px-3 text-right text-xs font-mono tabular-nums font-semibold text-red-700">
                        {formatMoney(e.difference_value)}
                      </td>
                      <td className="py-2 px-3 text-xs text-slate-700">{e.reason_name || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Branch Loss Comparison */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">Branch Loss Ranking · {date}</h2>
          <p className="text-xs text-slate-500 mt-0.5">Ordered by highest loss percentage for immediate follow-up.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="py-2.5 px-4">Branch</th>
                <th className="py-2.5 px-4 text-right">Entries</th>
                <th className="py-2.5 px-4 text-right">Transferred Qty</th>
                <th className="py-2.5 px-4 text-right">Received Qty</th>
                <th className="py-2.5 px-4 text-right">Diff Qty</th>
                <th className="py-2.5 px-4 text-right">Diff Value</th>
                <th className="py-2.5 px-4 text-right">Loss %</th>
                <th className="py-2.5 px-4">Alert State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {!data || data.branchStats.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No active branches available.
                  </td>
                </tr>
              ) : (
                data.branchStats.map((b) => (
                  <tr key={b.branch_id} className={b.is_alert ? 'bg-red-50/60' : 'hover:bg-slate-50'}>
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-slate-900">{b.branch_name}</div>
                      <div className="text-xs text-slate-500">{b.branch_location}</div>
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{b.entry_count}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(b.transferred_qty)}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(b.received_qty)}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(b.difference_qty)}</td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                      {formatMoney(b.difference_value)}
                    </td>
                    <td
                      className={`py-2.5 px-4 text-right font-mono tabular-nums font-semibold ${
                        b.is_alert ? 'text-red-700' : 'text-slate-900'
                      }`}
                    >
                      {formatPct(b.loss_pct)}
                    </td>
                    <td className="py-2.5 px-4 text-xs font-semibold">
                      {b.is_alert ? (
                        <span className="text-red-700">Threshold Exceeded</span>
                      ) : b.entry_count === 0 ? (
                        <span className="text-slate-400">No entries</span>
                      ) : (
                        <span className="text-emerald-700">Normal</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2-Column Analytical Split: Top Products with Repeated Shortages & Top Reasons */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-200">
            <h2 className="text-base font-semibold text-slate-900">Top Products with Repeated Shortages</h2>
            <p className="text-xs text-slate-500 mt-0.5">Rolling 30-day window ending {date}</p>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Product</th>
                  <th className="py-2.5 px-4 text-right">Shortage Count</th>
                  <th className="py-2.5 px-4 text-right">Total Short Qty</th>
                  <th className="py-2.5 px-4 text-right">Loss Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {!data || data.topShortageProducts.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-500">
                      No shortages recorded in the past 30 days.
                    </td>
                  </tr>
                ) : (
                  data.topShortageProducts.map((p) => (
                    <tr key={p.product_id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4">
                        <div className="font-medium text-slate-900">{p.product_name}</div>
                        <div className="text-xs font-mono text-slate-500">{p.barcode}</div>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold text-red-700">
                        {p.shortage_count}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                        {formatQty(p.total_shortage_qty, p.unit)} {p.unit}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                        {formatMoney(p.total_loss_value)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 sm:p-5 border-b border-slate-200">
            <h2 className="text-base font-semibold text-slate-900">Top Variance Reasons</h2>
            <p className="text-xs text-slate-500 mt-0.5">Rolling 30-day window ending {date}</p>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Reason</th>
                  <th className="py-2.5 px-4 text-right">Occurrences</th>
                  <th className="py-2.5 px-4 text-right">Total Diff Qty</th>
                  <th className="py-2.5 px-4 text-right">Total Diff Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {!data || data.topReasons.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-500">
                      No variance reasons recorded in the past 30 days.
                    </td>
                  </tr>
                ) : (
                  data.topReasons.map((r) => (
                    <tr key={r.reason_id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-medium text-slate-900">{r.reason_name}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{r.occurrence_count}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums">{formatQty(r.total_difference_qty)}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold">
                        {formatMoney(r.total_difference_value)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
