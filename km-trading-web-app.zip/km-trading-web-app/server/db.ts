import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { KM_CATALOG_PRODUCTS } from './kmProductsCatalog';

const DEFAULT_DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = process.env.KM_DB_PATH ? path.resolve(process.env.KM_DB_PATH) : path.join(DEFAULT_DATA_DIR, 'km_trading.db');
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function getTodayDateString(): string {
  return new Intl.DateTimeFormat('en-CA', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

export function roundQty(n: number): number {
  return Math.round((n + Number.EPSILON) * 1000) / 1000;
}

export function roundMoney(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS branches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      location TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      password_hash TEXT,
      role TEXT NOT NULL CHECK(role IN ('admin', 'manager', 'branch')),
      branch_id INTEGER REFERENCES branches(id),
      email TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      must_change_password INTEGER NOT NULL DEFAULT 0,
      last_login_at TEXT,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      barcode TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      unit TEXT NOT NULL CHECK(unit IN ('kg', 'pcs', 'pack')),
      default_price REAL NOT NULL DEFAULT 0,
      category TEXT NOT NULL CHECK(category IN ('Fruit', 'Vegetable')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS reasons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS receiving_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entry_date TEXT NOT NULL,
      branch_id INTEGER NOT NULL REFERENCES branches(id),
      document_number TEXT NOT NULL,
      created_by INTEGER NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(entry_date, branch_id, document_number)
    );

    CREATE TABLE IF NOT EXISTS receiving_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      document_id INTEGER NOT NULL REFERENCES receiving_documents(id) ON DELETE CASCADE,
      entry_date TEXT NOT NULL,
      branch_id INTEGER NOT NULL REFERENCES branches(id),
      product_id INTEGER NOT NULL REFERENCES products(id),
      barcode_snapshot TEXT NOT NULL,
      product_name_snapshot TEXT NOT NULL,
      unit_snapshot TEXT NOT NULL,
      category_snapshot TEXT NOT NULL,
      transferred_qty REAL NOT NULL,
      received_qty REAL NOT NULL,
      difference_qty REAL NOT NULL,
      unit_price REAL NOT NULL,
      transferred_value REAL NOT NULL,
      received_value REAL NOT NULL,
      difference_value REAL NOT NULL,
      value_overridden INTEGER NOT NULL DEFAULT 0,
      reason_id INTEGER REFERENCES reasons(id),
      remarks TEXT NOT NULL DEFAULT '',
      created_by INTEGER NOT NULL REFERENCES users(id),
      updated_by INTEGER REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS daily_lock (
      entry_date TEXT PRIMARY KEY,
      status TEXT NOT NULL CHECK(status IN ('open', 'locked')),
      locked_by INTEGER REFERENCES users(id),
      locked_at TEXT,
      reopened_by INTEGER REFERENCES users(id),
      reopened_at TEXT,
      reopen_reason TEXT
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_by INTEGER REFERENCES users(id),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS master_upload_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uploaded_by INTEGER NOT NULL REFERENCES users(id),
      filename TEXT NOT NULL,
      total_rows INTEGER NOT NULL,
      added_count INTEGER NOT NULL,
      updated_count INTEGER NOT NULL,
      failed_count INTEGER NOT NULL,
      failed_rows_json TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      old_value_json TEXT,
      new_value_json TEXT,
      note TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS password_reset_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      username TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'resolved', 'dismissed')),
      requested_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_by INTEGER REFERENCES users(id),
      resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS password_reset_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      remember_me INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      last_activity_at TEXT NOT NULL DEFAULT (datetime('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_receiving_items_date ON receiving_items(entry_date);
    CREATE INDEX IF NOT EXISTS idx_receiving_items_branch ON receiving_items(branch_id);
    CREATE INDEX IF NOT EXISTS idx_receiving_items_product ON receiving_items(product_id);
    CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_pw_reset_status ON password_reset_requests(status, requested_at DESC);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  `);

  migrateUserSecurityColumns();
  migrateProductUnits();
  seedInitialData();
}

function migrateUserSecurityColumns(): void {
  const cols = db.prepare("PRAGMA table_info('users')").all() as Array<{ name: string }>;
  const names = new Set(cols.map((c) => c.name));
  const additions: Array<[string, string]> = [
    ['email', "TEXT NOT NULL DEFAULT ''"],
    ['phone', "TEXT NOT NULL DEFAULT ''"],
    ['must_change_password', 'INTEGER NOT NULL DEFAULT 0'],
    ['last_login_at', 'TEXT'],
    ['failed_login_attempts', 'INTEGER NOT NULL DEFAULT 0'],
    ['locked_until', 'TEXT'],
  ];
  for (const [col, def] of additions) {
    if (!names.has(col)) {
      db.exec(`ALTER TABLE users ADD COLUMN ${col} ${def};`);
    }
  }
}

function migrateProductUnits(): void {
  const tableDef = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'products'")
    .get() as { sql: string } | undefined;

  if (tableDef?.sql && !tableDef.sql.includes("'pack'")) {
    db.pragma('foreign_keys = OFF');
    const migrateTx = db.transaction(() => {
      db.exec(`
        CREATE TABLE products_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          barcode TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          unit TEXT NOT NULL CHECK(unit IN ('kg', 'pcs', 'pack')),
          default_price REAL NOT NULL DEFAULT 0,
          category TEXT NOT NULL CHECK(category IN ('Fruit', 'Vegetable')),
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        INSERT INTO products_new (id, barcode, name, unit, default_price, category, active, created_at, updated_at)
        SELECT id, barcode, name,
          CASE WHEN unit = 'piece' THEN 'pcs' ELSE unit END,
          default_price, category, active, created_at, updated_at
        FROM products;

        DROP TABLE products;
        ALTER TABLE products_new RENAME TO products;

        UPDATE receiving_items SET unit_snapshot = 'pcs' WHERE unit_snapshot = 'piece';
      `);
    });
    migrateTx();
    db.pragma('foreign_keys = ON');
  }
}

function seedInitialData(): void {
  const kmBranches: Array<[string, string]> = [
    ['AL AMERAT', 'Al Amerat, Muscat'],
    ['AL KHOUD', 'Al Khoud, Muscat'],
    ['AL KHUWAIR', 'Al Khuwair, Muscat'],
    ['IBRI DHANK', 'Ibri / Dhank, Al Dhahirah'],
    ['ROP QURAM', 'Qurum, Muscat'],
    ['RUWI', 'Ruwi, Muscat'],
    ['SAADA', 'Saada, Salalah'],
    ['SAFA HYPER-MABELA', 'Al Mabela, Seeb'],
    ['SALALAH', 'Salalah, Dhofar'],
    ['YANQUL', 'Yanqul, Al Dhahirah'],
  ];

  const insertBranch = db.prepare('INSERT OR IGNORE INTO branches (name, location, active) VALUES (?, ?, 1)');
  for (const [name, location] of kmBranches) {
    insertBranch.run(name, location);
  }

  // Clean up unused initial sample placeholder branches if they have no users or transactions
  const placeholderNames = ['Branch A - Al Karama', 'Branch B - Deira Market'];
  for (const placeholder of placeholderNames) {
    const row = db.prepare('SELECT id FROM branches WHERE name = ?').get(placeholder) as { id: number } | undefined;
    if (row) {
      const usedInUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE branch_id = ?').get(row.id) as { c: number }).c;
      const usedInDocs = (db.prepare('SELECT COUNT(*) as c FROM receiving_documents WHERE branch_id = ?').get(row.id) as { c: number }).c;
      const usedInItems = (db.prepare('SELECT COUNT(*) as c FROM receiving_items WHERE branch_id = ?').get(row.id) as { c: number }).c;
      if (usedInUsers === 0 && usedInDocs === 0 && usedInItems === 0) {
        db.prepare('DELETE FROM branches WHERE id = ?').run(row.id);
      }
    }
  }

  const reasonCount = (db.prepare('SELECT COUNT(*) as c FROM reasons').get() as { c: number }).c;
  if (reasonCount === 0) {
    const insertReason = db.prepare('INSERT INTO reasons (name, description, active) VALUES (?, ?, 1)');
    const defaultReasons: Array<[string, string]> = [
      ['Shortage', 'Quantity delivered is less than transfer note quantity'],
      ['Wastage or damage', 'Produce crushed, bruised, or spoiled during transit'],
      ['Weight loss or drying', 'Moisture evaporation or natural weight shrinkage'],
      ['Quality rejection', 'Rejected at branch receiving check due to poor grade'],
      ['Wrong item sent', 'Different variety or product dispatched from warehouse'],
      ['Other', 'Other variance explained in remarks'],
    ];
    for (const [name, desc] of defaultReasons) {
      insertReason.run(name, desc);
    }
  }

  const catalogSeededRow = db.prepare("SELECT key FROM settings WHERE key = 'km_catalog_pdf_seeded_v1'").get();
  if (!catalogSeededRow) {
    const seedCatalogTx = db.transaction(() => {
      // Remove initial dummy sample products if they have no transactions
      const sampleBarcodes = [
        'KM-VEG-001',
        'KM-VEG-002',
        'KM-VEG-003',
        'KM-VEG-004',
        'KM-FRT-001',
        'KM-FRT-002',
        'KM-FRT-003',
        'KM-FRT-004',
      ];
      for (const sb of sampleBarcodes) {
        const prod = db.prepare('SELECT id FROM products WHERE barcode = ?').get(sb) as { id: number } | undefined;
        if (prod) {
          const used = (db.prepare('SELECT COUNT(*) as c FROM receiving_items WHERE product_id = ?').get(prod.id) as { c: number }).c;
          if (used === 0) {
            db.prepare('DELETE FROM products WHERE id = ?').run(prod.id);
          }
        }
      }

      const insertCatalogProduct = db.prepare(
        'INSERT OR IGNORE INTO products (barcode, name, unit, default_price, category, active) VALUES (?, ?, ?, ?, ?, 1)'
      );
      for (const row of KM_CATALOG_PRODUCTS) {
        insertCatalogProduct.run(...row);
      }

      db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('km_catalog_pdf_seeded_v1', '1')").run();
    });
    seedCatalogTx();
  }

  const thresholdRow = db.prepare("SELECT key FROM settings WHERE key = 'alert_threshold_pct'").get();
  if (!thresholdRow) {
    db.prepare("INSERT INTO settings (key, value) VALUES ('alert_threshold_pct', '5')").run();
  }

  const companyRow = db.prepare("SELECT key FROM settings WHERE key = 'company_name'").get();
  if (!companyRow) {
    db.prepare("INSERT INTO settings (key, value) VALUES ('company_name', 'KM Trading')").run();
  }

  const adminUser = db.prepare("SELECT id FROM users WHERE username = 'admin'").get();
  if (!adminUser) {
    db.prepare(
      "INSERT INTO users (username, full_name, password_hash, role, branch_id, must_change_password, active) VALUES ('admin', 'Head Office Administrator', NULL, 'admin', NULL, 0, 1)"
    ).run();
  }

  // Seed 1 Head Office Manager & 10 Branch User accounts (one per branch) once if not yet seeded
  const staffSeeded = db.prepare("SELECT key FROM settings WHERE key = 'km_staff_accounts_seeded_v1'").get();
  if (!staffSeeded) {
    const seedStaffTx = db.transaction(() => {
      db.prepare(
        "INSERT OR IGNORE INTO users (username, full_name, password_hash, role, branch_id, must_change_password, active) VALUES ('ho_manager', 'Head Office Manager', NULL, 'manager', NULL, 1, 1)"
      ).run();

      const activeBranches = db
        .prepare('SELECT id, name FROM branches WHERE active = 1 ORDER BY name ASC')
        .all() as Array<{ id: number; name: string }>;

      const insertBranchUser = db.prepare(
        "INSERT OR IGNORE INTO users (username, full_name, password_hash, role, branch_id, must_change_password, active) VALUES (?, ?, NULL, 'branch', ?, 1, 1)"
      );
      for (const b of activeBranches) {
        const existingForBranch = db
          .prepare("SELECT id FROM users WHERE role = 'branch' AND branch_id = ?")
          .get(b.id);
        if (!existingForBranch) {
          const slug = b.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '');
          const uname = `branch_${slug}`;
          insertBranchUser.run(uname, `${b.name} Receiver`, b.id);
        }
      }
      db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('km_staff_accounts_seeded_v1', '1')").run();
    });
    seedStaffTx();
  }
}

export function logAudit(params: {
  userId: number | null;
  username: string;
  action: string;
  entityType: string;
  entityId: string | number;
  oldValue?: unknown;
  newValue?: unknown;
  note?: string | null;
}): void {
  db.prepare(
    `INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, old_value_json, new_value_json, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.userId,
    params.username,
    params.action,
    params.entityType,
    String(params.entityId),
    params.oldValue !== undefined ? JSON.stringify(params.oldValue) : null,
    params.newValue !== undefined ? JSON.stringify(params.newValue) : null,
    params.note ?? null
  );
}

export function getDayLockStatus(entryDate: string): {
  status: 'open' | 'locked';
  auto_locked: boolean;
  row: {
    entry_date: string;
    status: 'open' | 'locked';
    locked_by: number | null;
    locked_at: string | null;
    reopened_by: number | null;
    reopened_at: string | null;
    reopen_reason: string | null;
  } | null;
} {
  const row = db
    .prepare('SELECT * FROM daily_lock WHERE entry_date = ?')
    .get(entryDate) as
    | {
        entry_date: string;
        status: 'open' | 'locked';
        locked_by: number | null;
        locked_at: string | null;
        reopened_by: number | null;
        reopened_at: string | null;
        reopen_reason: string | null;
      }
    | undefined;

  const today = getTodayDateString();
  if (row) {
    return { status: row.status, auto_locked: false, row };
  }
  if (entryDate < today) {
    return { status: 'locked', auto_locked: true, row: null };
  }
  return { status: 'open', auto_locked: false, row: null };
}
