import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { db } from './db';
import type { AuthUser, UserRole } from '../src/types';

export const SESSION_COOKIE_NAME = 'km_session';
export const REMEMBER_ME_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
export const IDLE_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes
export const MAX_FAILED_LOGIN_ATTEMPTS = 5;
export const LOCKOUT_DURATION_MINUTES = 15;
export const RESET_TOKEN_TTL_MINUTES = 30;

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

export function verifyConstantTime(input: string, expected: string): boolean {
  const a = Buffer.from(input, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function validatePasswordPolicy(password: unknown): { valid: boolean; error?: string } {
  if (typeof password !== 'string') {
    return { valid: false, error: 'Password is required.' };
  }
  if (password.length < 8) {
    return { valid: false, error: 'Password must be at least 8 characters long.' };
  }
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    return { valid: false, error: 'Password must contain at least one letter and one number.' };
  }
  return { valid: true };
}

export function generateTempPassword(length = 10): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnpqrstuvwxyz';
  const digits = '23456789';
  const all = upper + lower + digits;
  const pick = (chars: string) => chars[crypto.randomInt(0, chars.length)];
  const chars = [pick(upper), pick(lower), pick(digits)];
  while (chars.length < length) {
    chars.push(pick(all));
  }
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(0, i + 1);
    const tmp = chars[i];
    chars[i] = chars[j];
    chars[j] = tmp;
  }
  return chars.join('');
}

export function hashResetToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function createSession(userId: number, rememberMe: boolean): string {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  const expiresAt = new Date(now + (rememberMe ? REMEMBER_ME_MS : 24 * 60 * 60 * 1000)).toISOString();
  const nowIso = new Date(now).toISOString();
  db.prepare(
    `INSERT INTO sessions (id, user_id, remember_me, expires_at, last_activity_at, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(sessionId, userId, rememberMe ? 1 : 0, expiresAt, nowIso, nowIso);
  return sessionId;
}

export function deleteSession(sessionId: string): void {
  db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}

export function deleteUserSessions(userId: number): void {
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
}

export function parseSessionCookie(req: Request): string | null {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  const parts = cookieHeader.split(';');
  for (const part of parts) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const name = part.slice(0, idx).trim();
    if (name === SESSION_COOKIE_NAME) {
      return decodeURIComponent(part.slice(idx + 1).trim());
    }
  }
  return null;
}

function isHttpsRequest(req: Request): boolean {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  return req.secure || proto === 'https';
}

export function setSessionCookie(req: Request, res: Response, sessionId: string, rememberMe: boolean): void {
  const isHttps = isHttpsRequest(req);
  const parts = [
    `${SESSION_COOKIE_NAME}=${encodeURIComponent(sessionId)}`,
    'Path=/',
    'HttpOnly',
    isHttps ? 'SameSite=None' : 'SameSite=Lax',
  ];
  if (isHttps) {
    parts.push('Secure');
    parts.push('Partitioned');
  }
  if (rememberMe) {
    parts.push(`Max-Age=${Math.floor(REMEMBER_ME_MS / 1000)}`);
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

export function clearSessionCookie(req: Request, res: Response): void {
  const isHttps = isHttpsRequest(req);
  const parts = [
    `${SESSION_COOKIE_NAME}=`,
    'Path=/',
    'HttpOnly',
    'Max-Age=0',
    isHttps ? 'SameSite=None' : 'SameSite=Lax',
  ];
  if (isHttps) {
    parts.push('Secure');
    parts.push('Partitioned');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
  sessionId?: string;
}

export function loadUserById(userId: number): AuthUser | null {
  const row = db
    .prepare(
      `SELECT u.id, u.username, u.full_name, u.role, u.branch_id, b.name as branch_name,
              u.email, u.phone, u.must_change_password, u.last_login_at, u.active
       FROM users u
       LEFT JOIN branches b ON b.id = u.branch_id
       WHERE u.id = ?`
    )
    .get(userId) as
    | (Omit<AuthUser, 'must_change_password'> & { must_change_password: number })
    | undefined;

  if (!row) return null;
  return {
    ...row,
    must_change_password: Boolean(row.must_change_password),
  };
}

const MUST_CHANGE_ALLOWED_PATHS = new Set(['/api/auth/me', '/api/auth/change-password', '/api/auth/logout']);

function verifySameOriginOrXhr(req: Request): boolean {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
    return true;
  }
  const xhr = req.headers['x-requested-with'];
  if (typeof xhr === 'string' && xhr.toLowerCase() === 'xmlhttprequest') {
    return true;
  }
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin && host) {
    try {
      const originHost = new URL(origin).host;
      return originHost === host;
    } catch {
      return false;
    }
  }
  return false;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  const bearerToken = header && header.startsWith('Bearer ') ? header.slice('Bearer '.length).trim() : null;
  const cookieToken = parseSessionCookie(req);
  const sessionId = bearerToken || cookieToken;
  const authenticatedViaCookieOnly = !bearerToken && Boolean(cookieToken);

  if (!sessionId) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  if (authenticatedViaCookieOnly && !verifySameOriginOrXhr(req)) {
    res.status(403).json({ error: 'Invalid request origin.' });
    return;
  }

  const session = db
    .prepare('SELECT id, user_id, remember_me, expires_at, last_activity_at FROM sessions WHERE id = ?')
    .get(sessionId) as
    | { id: string; user_id: number; remember_me: number; expires_at: string; last_activity_at: string }
    | undefined;

  if (!session) {
    if (cookieToken) clearSessionCookie(req, res);
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }

  const nowMs = Date.now();
  const expiresMs = Date.parse(session.expires_at);
  if (!Number.isFinite(expiresMs) || nowMs > expiresMs) {
    deleteSession(session.id);
    if (cookieToken) clearSessionCookie(req, res);
    res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
    return;
  }

  if (session.remember_me === 0) {
    const lastActivityMs = Date.parse(session.last_activity_at);
    if (!Number.isFinite(lastActivityMs) || nowMs - lastActivityMs > IDLE_TIMEOUT_MS) {
      deleteSession(session.id);
      if (cookieToken) clearSessionCookie(req, res);
      res.status(401).json({ error: 'Signed out due to 30 minutes of inactivity. Please sign in again.' });
      return;
    }
  }

  const user = loadUserById(session.user_id);
  if (!user || user.active !== 1) {
    deleteSession(session.id);
    if (cookieToken) clearSessionCookie(req, res);
    res.status(401).json({ error: 'Account is inactive or unavailable.' });
    return;
  }

  if (user.must_change_password && !MUST_CHANGE_ALLOWED_PATHS.has(req.originalUrl.split('?')[0])) {
    res.status(403).json({
      error: 'You must change your temporary password before accessing the application.',
      must_change_password: true,
    });
    return;
  }

  db.prepare('UPDATE sessions SET last_activity_at = ? WHERE id = ?').run(new Date(nowMs).toISOString(), session.id);

  req.user = { ...user, remember_me: session.remember_me === 1 };
  req.sessionId = session.id;
  next();
}

export function requireRole(...roles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'You do not have permission to perform this action.' });
      return;
    }
    next();
  };
}
