import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { Router } from 'express';
import JSZip from 'jszip';
import multer from 'multer';
import * as XLSX from 'xlsx';
import {
  AuthenticatedRequest,
  RESET_TOKEN_TTL_MINUTES,
  deleteUserSessions,
  generateTempPassword,
  hashPassword,
  hashResetToken,
  requireAuth,
  requireRole,
  validatePasswordPolicy,
} from '../auth';
import { db, logAudit, roundMoney } from '../db';
import type { ProductCategory, ProductUnit, UploadPreviewRow, UserRole } from '../../src/types';

export const masterRouter = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
});

function normalizeHeader(h: string): string {
  return String(h || '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '_');
}

function parseActiveFlag(raw: unknown): { value: number; valid: boolean } {
  if (raw === undefined || raw === null || String(raw).trim() === '') {
    return { value: 1, valid: true };
  }
  const s = String(raw).trim().toLowerCase();
  if (['1', 'true', 'yes', 'y', 'active'].includes(s)) return { value: 1, valid: true };
  if (['0', 'false', 'no', 'n', 'inactive'].includes(s)) return { value: 0, valid: true };
  return { value: 1, valid: false };
}

function parseUnit(raw: unknown): { value: ProductUnit; valid: boolean } {
  const s = String(raw || '').trim().toLowerCase();
  if (s === 'kg' || s === 'kgs' || s === 'kilogram') return { value: 'kg', valid: true };
  if (s === 'pcs' || s === 'pc' || s === 'piece' || s === 'pieces') return { value: 'pcs', valid: true };
  if (s === 'pack' || s === 'packs' || s === 'pkt' || s === 'pkts' || s === 'packet') return { value: 'pack', valid: true };
  return { value: 'kg', valid: false };
}

function parseCategory(raw: unknown): { value: ProductCategory; valid: boolean } {
  const s = String(raw || '').trim().toLowerCase();
  if (s === 'fruit' || s === 'fruits') return { value: 'Fruit', valid: true };
  if (s === 'vegetable' || s === 'vegetables' || s === 'veg') return { value: 'Vegetable', valid: true };
  return { value: 'Vegetable', valid: false };
}

// ---------------- PRODUCTS ----------------

masterRouter.get('/products', requireAuth, (req, res) => {
  const activeOnly = req.query.activeOnly === 'true';
  const rows = db
    .prepare(
      `SELECT p.*,
        (SELECT COUNT(*) FROM receiving_items ri WHERE ri.product_id = p.id) as transaction_count
       FROM products p
       ${activeOnly ? 'WHERE p.active = 1' : ''}
       ORDER BY p.name ASC`
    )
    .all();
  res.json(rows);
});

masterRouter.get('/products/export', requireAuth, requireRole('admin', 'manager'), (_req, res) => {
  const rows = db
    .prepare('SELECT barcode, name as product_name, unit, default_price, category, active FROM products ORDER BY name ASC')
    .all() as Array<{
    barcode: string;
    product_name: string;
    unit: string;
    default_price: number;
    category: string;
    active: number;
  }>;

  const exportRows = rows.map((r) => ({
    barcode: r.barcode,
    product_name: r.product_name,
    unit: r.unit,
    default_price: r.default_price,
    category: r.category,
    active: r.active === 1 ? 'Yes' : 'No',
  }));

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(exportRows);
  XLSX.utils.book_append_sheet(wb, ws, 'Products Master');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="km_trading_products_master.xlsx"');
  res.send(buf);
});

masterRouter.post('/products', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { barcode, name, unit, default_price, category, active } = req.body as {
    barcode?: string;
    name?: string;
    unit?: string;
    default_price?: number;
    category?: string;
    active?: number;
  };

  const cleanBarcode = String(barcode || '').trim();
  const cleanName = String(name || '').trim();
  const parsedUnit = parseUnit(unit);
  const parsedCat = parseCategory(category);
  const priceNum = Number(default_price);

  if (!cleanBarcode || !cleanName) {
    res.status(400).json({ error: 'Barcode and product name are required.' });
    return;
  }
  if (!parsedUnit.valid) {
    res.status(400).json({ error: 'Unit must be kg, pcs, or pack.' });
    return;
  }
  if (!parsedCat.valid) {
    res.status(400).json({ error: 'Category must be Fruit or Vegetable.' });
    return;
  }
  if (!Number.isFinite(priceNum) || priceNum < 0) {
    res.status(400).json({ error: 'Default price must be a non-negative number.' });
    return;
  }

  const dup = db.prepare('SELECT id FROM products WHERE LOWER(barcode) = LOWER(?)').get(cleanBarcode);
  if (dup) {
    res.status(409).json({ error: `Barcode "${cleanBarcode}" already exists.` });
    return;
  }

  const cleanPrice = roundMoney(priceNum);
  const isActive = active === 0 ? 0 : 1;

  const info = db
    .prepare('INSERT INTO products (barcode, name, unit, default_price, category, active) VALUES (?, ?, ?, ?, ?, ?)')
    .run(cleanBarcode, cleanName, parsedUnit.value, cleanPrice, parsedCat.value, isActive);

  const created = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(info.lastInsertRowid));
  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'product',
    entityId: Number(info.lastInsertRowid),
    newValue: created,
  });

  res.status(201).json(created);
});

masterRouter.put('/products/:id', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Product not found.' });
    return;
  }

  const { barcode, name, unit, default_price, category, active } = req.body as {
    barcode?: string;
    name?: string;
    unit?: string;
    default_price?: number;
    category?: string;
    active?: number;
  };

  const cleanBarcode = String(barcode || '').trim();
  const cleanName = String(name || '').trim();
  const parsedUnit = parseUnit(unit);
  const parsedCat = parseCategory(category);
  const priceNum = Number(default_price);

  if (!cleanBarcode || !cleanName) {
    res.status(400).json({ error: 'Barcode and product name are required.' });
    return;
  }
  if (!parsedUnit.valid) {
    res.status(400).json({ error: 'Unit must be kg, pcs, or pack.' });
    return;
  }
  if (!parsedCat.valid) {
    res.status(400).json({ error: 'Category must be Fruit or Vegetable.' });
    return;
  }
  if (!Number.isFinite(priceNum) || priceNum < 0) {
    res.status(400).json({ error: 'Default price must be a non-negative number.' });
    return;
  }

  const dup = db
    .prepare('SELECT id FROM products WHERE LOWER(barcode) = LOWER(?) AND id != ?')
    .get(cleanBarcode, id);
  if (dup) {
    res.status(409).json({ error: `Barcode "${cleanBarcode}" is already used by another product.` });
    return;
  }

  const cleanPrice = roundMoney(priceNum);
  const isActive = active === 0 ? 0 : 1;

  db.prepare(
    `UPDATE products
     SET barcode = ?, name = ?, unit = ?, default_price = ?, category = ?, active = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(cleanBarcode, cleanName, parsedUnit.value, cleanPrice, parsedCat.value, isActive, id);

  const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'product',
    entityId: id,
    oldValue: existing,
    newValue: updated,
  });

  res.json(updated);
});

masterRouter.patch('/products/:id/toggle', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as { active: number } | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Product not found.' });
    return;
  }

  const nextActive = existing.active === 1 ? 0 : 1;
  db.prepare("UPDATE products SET active = ?, updated_at = datetime('now') WHERE id = ?").run(nextActive, id);
  const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'product',
    entityId: id,
    oldValue: { active: existing.active },
    newValue: { active: nextActive },
    note: nextActive === 1 ? 'Product reactivated' : 'Product deactivated',
  });

  res.json(updated);
});

masterRouter.delete('/products/:id', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Product not found.' });
    return;
  }

  const usage = db.prepare('SELECT COUNT(*) as c FROM receiving_items WHERE product_id = ?').get(id) as { c: number };
  if (usage.c > 0) {
    res.status(409).json({
      error: `Cannot delete product because it is referenced in ${usage.c} receiving entries. Deactivate it instead.`,
    });
    return;
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'DELETE',
    entityType: 'product',
    entityId: id,
    oldValue: existing,
  });

  res.json({ ok: true });
});

// ---------------- MASTER DATA UPLOAD ----------------

masterRouter.get('/master-upload/template', requireAuth, requireRole('admin'), (req, res) => {
  const format = String(req.query.format || 'xlsx').toLowerCase();
  const sampleRows = [
    {
      barcode: 'KM-VEG-101',
      product_name: 'Fresh Carrot',
      unit: 'kg',
      default_price: 4.5,
      category: 'Vegetable',
      active: 'Yes',
    },
    {
      barcode: 'KM-FRT-102',
      product_name: 'Pineapple Large',
      unit: 'pcs',
      default_price: 9.75,
      category: 'Fruit',
      active: 'Yes',
    },
    {
      barcode: 'KM-VEG-103',
      product_name: 'Baby Spinach',
      unit: 'pack',
      default_price: 6.25,
      category: 'Vegetable',
      active: 'Yes',
    },
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(sampleRows);
  XLSX.utils.book_append_sheet(wb, ws, 'Products');

  if (format === 'csv') {
    const csv = XLSX.utils.sheet_to_csv(ws);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="km_trading_products_template.csv"');
    res.send(csv);
    return;
  }

  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="km_trading_products_template.xlsx"');
  res.send(buf);
});

masterRouter.post(
  '/master-upload/preview',
  requireAuth,
  requireRole('admin'),
  upload.single('file'),
  (req, res) => {
    if (!req.file) {
      res.status(400).json({ error: 'Please select an Excel (.xlsx) or CSV (.csv) file.' });
      return;
    }

    const ext = req.file.originalname.split('.').pop()?.toLowerCase() || '';
    if (!['xlsx', 'xls', 'csv'].includes(ext)) {
      res.status(400).json({ error: 'Unsupported file format. Only .xlsx, .xls, and .csv files are accepted.' });
      return;
    }

    let workbook: XLSX.WorkBook;
    try {
      workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    } catch {
      res.status(400).json({ error: 'Could not parse uploaded file. Ensure it is a valid Excel or CSV file.' });
      return;
    }

    const firstSheetName = workbook.SheetNames[0];
    if (!firstSheetName) {
      res.status(400).json({ error: 'The uploaded file contains no worksheets.' });
      return;
    }

    const rawRecords = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[firstSheetName], {
      defval: '',
    });

    if (rawRecords.length === 0) {
      res.status(400).json({ error: 'The uploaded file has no data rows.' });
      return;
    }

    const existingBarcodes = new Set(
      (db.prepare('SELECT LOWER(barcode) as bc FROM products').all() as Array<{ bc: string }>).map((r) => r.bc)
    );

    const seenInFile = new Map<string, number>();
    const previewRows: UploadPreviewRow[] = rawRecords.map((raw, idx) => {
      const normalized: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(raw)) {
        normalized[normalizeHeader(k)] = v;
      }

      const rowNumber = idx + 2; // 1-indexed + header row
      const barcode = String(normalized.barcode ?? '').trim();
      const productName = String(normalized.product_name ?? normalized.name ?? '').trim();
      const rawUnit = normalized.unit;
      const rawPrice = normalized.default_price ?? normalized.price;
      const rawCategory = normalized.category;
      const rawActive = normalized.active;

      const errors: string[] = [];
      if (!barcode) errors.push('Missing barcode');
      if (!productName) errors.push('Missing product_name');

      const unitParsed = parseUnit(rawUnit);
      if (!String(rawUnit ?? '').trim()) {
        errors.push('Missing unit (must be kg, pcs, or pack)');
      } else if (!unitParsed.valid) {
        errors.push(`Invalid unit "${String(rawUnit)}" (expected kg, pcs, or pack)`);
      }

      const priceStr = String(rawPrice ?? '').trim();
      const priceNum = priceStr === '' ? NaN : Number(priceStr);
      if (priceStr === '') {
        errors.push('Missing default_price');
      } else if (!Number.isFinite(priceNum) || priceNum < 0) {
        errors.push(`Invalid default_price "${priceStr}"`);
      }

      const catParsed = parseCategory(rawCategory);
      if (!String(rawCategory ?? '').trim()) {
        errors.push('Missing category (must be Fruit or Vegetable)');
      } else if (!catParsed.valid) {
        errors.push(`Invalid category "${String(rawCategory)}" (expected Fruit or Vegetable)`);
      }

      const activeParsed = parseActiveFlag(rawActive);
      if (!activeParsed.valid) {
        errors.push(`Invalid active flag "${String(rawActive)}" (expected Yes/No or 1/0)`);
      }

      const lowerBarcode = barcode.toLowerCase();
      if (barcode) {
        if (seenInFile.has(lowerBarcode)) {
          errors.push(`Duplicate barcode in file (first seen at row ${seenInFile.get(lowerBarcode)})`);
        } else {
          seenInFile.set(lowerBarcode, rowNumber);
        }
      }

      const status: UploadPreviewRow['status'] =
        errors.length > 0 ? 'invalid' : existingBarcodes.has(lowerBarcode) ? 'update' : 'new';

      return {
        rowNumber,
        barcode,
        product_name: productName,
        unit: unitParsed.valid ? unitParsed.value : String(rawUnit ?? ''),
        default_price: Number.isFinite(priceNum) && priceNum >= 0 ? roundMoney(priceNum) : null,
        category: catParsed.valid ? catParsed.value : String(rawCategory ?? ''),
        active: activeParsed.value,
        status,
        errors,
      };
    });

    res.json({
      filename: req.file.originalname,
      rows: previewRows,
      summary: {
        total: previewRows.length,
        newCount: previewRows.filter((r) => r.status === 'new').length,
        updateCount: previewRows.filter((r) => r.status === 'update').length,
        invalidCount: previewRows.filter((r) => r.status === 'invalid').length,
      },
    });
  }
);

masterRouter.post('/master-upload/confirm', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { filename, rows } = req.body as { filename?: string; rows?: UploadPreviewRow[] };
  if (!Array.isArray(rows) || rows.length === 0) {
    res.status(400).json({ error: 'No rows provided for import.' });
    return;
  }

  let added = 0;
  let updated = 0;
  const failedRows: UploadPreviewRow[] = [];
  const seenBarcodes = new Set<string>();

  const runImport = db.transaction(() => {
    for (const row of rows) {
      const barcode = String(row.barcode || '').trim();
      const name = String(row.product_name || '').trim();
      const unitCheck = parseUnit(row.unit);
      const catCheck = parseCategory(row.category);
      const priceNum = row.default_price === null ? NaN : Number(row.default_price);
      const activeFlag = row.active === 0 ? 0 : 1;

      const errors: string[] = [];
      if (!barcode) errors.push('Missing barcode');
      if (!name) errors.push('Missing product_name');
      if (!unitCheck.valid) errors.push('Invalid unit');
      if (!catCheck.valid) errors.push('Invalid category');
      if (!Number.isFinite(priceNum) || priceNum < 0) errors.push('Invalid default_price');

      const lower = barcode.toLowerCase();
      if (barcode && seenBarcodes.has(lower)) {
        errors.push('Duplicate barcode in upload batch');
      }

      if (errors.length > 0 || row.status === 'invalid') {
        failedRows.push({
          ...row,
          status: 'invalid',
          errors: row.errors?.length ? row.errors : errors,
        });
        continue;
      }

      seenBarcodes.add(lower);
      const cleanPrice = roundMoney(priceNum);

      const existing = db
        .prepare('SELECT * FROM products WHERE LOWER(barcode) = LOWER(?)')
        .get(barcode) as { id: number } | undefined;

      if (existing) {
        db.prepare(
          `UPDATE products
           SET barcode = ?, name = ?, unit = ?, default_price = ?, category = ?, active = ?, updated_at = datetime('now')
           WHERE id = ?`
        ).run(barcode, name, unitCheck.value, cleanPrice, catCheck.value, activeFlag, existing.id);

        const after = db.prepare('SELECT * FROM products WHERE id = ?').get(existing.id);
        logAudit({
          userId: req.user!.id,
          username: req.user!.username,
          action: 'UPDATE',
          entityType: 'product',
          entityId: existing.id,
          oldValue: existing,
          newValue: after,
          note: `Bulk master upload (${filename || 'import'})`,
        });
        updated += 1;
      } else {
        const info = db
          .prepare('INSERT INTO products (barcode, name, unit, default_price, category, active) VALUES (?, ?, ?, ?, ?, ?)')
          .run(barcode, name, unitCheck.value, cleanPrice, catCheck.value, activeFlag);

        const created = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(info.lastInsertRowid));
        logAudit({
          userId: req.user!.id,
          username: req.user!.username,
          action: 'CREATE',
          entityType: 'product',
          entityId: Number(info.lastInsertRowid),
          newValue: created,
          note: `Bulk master upload (${filename || 'import'})`,
        });
        added += 1;
      }
    }

    db.prepare(
      `INSERT INTO master_upload_log (uploaded_by, filename, total_rows, added_count, updated_count, failed_count, failed_rows_json)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(
      req.user!.id,
      String(filename || 'upload.xlsx'),
      rows.length,
      added,
      updated,
      failedRows.length,
      failedRows.length > 0 ? JSON.stringify(failedRows) : null
    );

    logAudit({
      userId: req.user!.id,
      username: req.user!.username,
      action: 'MASTER_UPLOAD',
      entityType: 'products',
      entityId: filename || 'upload',
      newValue: { total: rows.length, added, updated, failed: failedRows.length },
    });
  });

  runImport();

  res.json({
    total: rows.length,
    added,
    updated,
    failed: failedRows.length,
    failedRows,
  });
});

masterRouter.get('/master-upload/logs', requireAuth, requireRole('admin'), (_req, res) => {
  const rows = db
    .prepare(
      `SELECT m.*, u.username as uploaded_by_name
       FROM master_upload_log m
       JOIN users u ON u.id = m.uploaded_by
       ORDER BY m.created_at DESC
       LIMIT 50`
    )
    .all();
  res.json(rows);
});

// ---------------- BRANCHES ----------------

masterRouter.get('/branches', requireAuth, (req, res) => {
  const activeOnly = req.query.activeOnly === 'true';
  const rows = db
    .prepare(`SELECT * FROM branches ${activeOnly ? 'WHERE active = 1' : ''} ORDER BY name ASC`)
    .all();
  res.json(rows);
});

masterRouter.post('/branches', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { name, location } = req.body as { name?: string; location?: string };
  const cleanName = String(name || '').trim();
  const cleanLoc = String(location || '').trim();
  if (!cleanName) {
    res.status(400).json({ error: 'Branch name is required.' });
    return;
  }

  const dup = db.prepare('SELECT id FROM branches WHERE LOWER(name) = LOWER(?)').get(cleanName);
  if (dup) {
    res.status(409).json({ error: `Branch "${cleanName}" already exists.` });
    return;
  }

  const info = db.prepare('INSERT INTO branches (name, location, active) VALUES (?, ?, 1)').run(cleanName, cleanLoc);
  const created = db.prepare('SELECT * FROM branches WHERE id = ?').get(Number(info.lastInsertRowid));

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'branch',
    entityId: Number(info.lastInsertRowid),
    newValue: created,
  });

  res.status(201).json(created);
});

masterRouter.put('/branches/:id', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM branches WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Branch not found.' });
    return;
  }

  const { name, location } = req.body as { name?: string; location?: string };
  const cleanName = String(name || '').trim();
  const cleanLoc = String(location || '').trim();
  if (!cleanName) {
    res.status(400).json({ error: 'Branch name is required.' });
    return;
  }

  const dup = db.prepare('SELECT id FROM branches WHERE LOWER(name) = LOWER(?) AND id != ?').get(cleanName, id);
  if (dup) {
    res.status(409).json({ error: `Branch "${cleanName}" already exists.` });
    return;
  }

  db.prepare("UPDATE branches SET name = ?, location = ?, updated_at = datetime('now') WHERE id = ?").run(
    cleanName,
    cleanLoc,
    id
  );
  const updated = db.prepare('SELECT * FROM branches WHERE id = ?').get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'branch',
    entityId: id,
    oldValue: existing,
    newValue: updated,
  });

  res.json(updated);
});

masterRouter.patch('/branches/:id/toggle', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM branches WHERE id = ?').get(id) as { active: number } | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Branch not found.' });
    return;
  }

  const nextActive = existing.active === 1 ? 0 : 1;
  db.prepare("UPDATE branches SET active = ?, updated_at = datetime('now') WHERE id = ?").run(nextActive, id);
  const updated = db.prepare('SELECT * FROM branches WHERE id = ?').get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'branch',
    entityId: id,
    oldValue: { active: existing.active },
    newValue: { active: nextActive },
  });

  res.json(updated);
});

// ---------------- REASONS ----------------

masterRouter.get('/reasons', requireAuth, (req, res) => {
  const activeOnly = req.query.activeOnly === 'true';
  const rows = db
    .prepare(`SELECT * FROM reasons ${activeOnly ? 'WHERE active = 1' : ''} ORDER BY id ASC`)
    .all();
  res.json(rows);
});

masterRouter.post('/reasons', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { name, description } = req.body as { name?: string; description?: string };
  const cleanName = String(name || '').trim();
  const cleanDesc = String(description || '').trim();
  if (!cleanName) {
    res.status(400).json({ error: 'Reason name is required.' });
    return;
  }

  const dup = db.prepare('SELECT id FROM reasons WHERE LOWER(name) = LOWER(?)').get(cleanName);
  if (dup) {
    res.status(409).json({ error: `Reason "${cleanName}" already exists.` });
    return;
  }

  const info = db.prepare('INSERT INTO reasons (name, description, active) VALUES (?, ?, 1)').run(cleanName, cleanDesc);
  const created = db.prepare('SELECT * FROM reasons WHERE id = ?').get(Number(info.lastInsertRowid));

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'reason',
    entityId: Number(info.lastInsertRowid),
    newValue: created,
  });

  res.status(201).json(created);
});

masterRouter.put('/reasons/:id', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM reasons WHERE id = ?').get(id);
  if (!existing) {
    res.status(404).json({ error: 'Reason not found.' });
    return;
  }

  const { name, description } = req.body as { name?: string; description?: string };
  const cleanName = String(name || '').trim();
  const cleanDesc = String(description || '').trim();
  if (!cleanName) {
    res.status(400).json({ error: 'Reason name is required.' });
    return;
  }

  const dup = db.prepare('SELECT id FROM reasons WHERE LOWER(name) = LOWER(?) AND id != ?').get(cleanName, id);
  if (dup) {
    res.status(409).json({ error: `Reason "${cleanName}" already exists.` });
    return;
  }

  db.prepare("UPDATE reasons SET name = ?, description = ?, updated_at = datetime('now') WHERE id = ?").run(
    cleanName,
    cleanDesc,
    id
  );
  const updated = db.prepare('SELECT * FROM reasons WHERE id = ?').get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'reason',
    entityId: id,
    oldValue: existing,
    newValue: updated,
  });

  res.json(updated);
});

masterRouter.patch('/reasons/:id/toggle', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM reasons WHERE id = ?').get(id) as { active: number } | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Reason not found.' });
    return;
  }

  const nextActive = existing.active === 1 ? 0 : 1;
  db.prepare("UPDATE reasons SET active = ?, updated_at = datetime('now') WHERE id = ?").run(nextActive, id);
  const updated = db.prepare('SELECT * FROM reasons WHERE id = ?').get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'reason',
    entityId: id,
    oldValue: { active: existing.active },
    newValue: { active: nextActive },
  });

  res.json(updated);
});

// ---------------- USERS ----------------

const USER_SELECT_SQL = `
  SELECT u.id, u.username, u.full_name, u.role, u.branch_id, b.name as branch_name,
         u.email, u.phone, u.must_change_password, u.last_login_at,
         u.failed_login_attempts, u.locked_until, u.active,
         CASE WHEN u.password_hash IS NOT NULL THEN 1 ELSE 0 END as has_password,
         u.created_at, u.updated_at
  FROM users u
  LEFT JOIN branches b ON b.id = u.branch_id
`;

function mapUserRow(r: Record<string, unknown>) {
  return {
    ...r,
    must_change_password: Boolean(r.must_change_password),
    has_password: Boolean(r.has_password),
  };
}

masterRouter.get('/users', requireAuth, requireRole('admin'), (_req, res) => {
  const rows = db.prepare(`${USER_SELECT_SQL} ORDER BY u.id ASC`).all() as Array<Record<string, unknown>>;
  res.json(rows.map(mapUserRow));
});

masterRouter.post('/users', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { username, full_name, password, role, branch_id, email, phone } = req.body as {
    username?: string;
    full_name?: string;
    password?: string;
    role?: UserRole;
    branch_id?: number | null;
    email?: string;
    phone?: string;
  };

  const cleanUsername = String(username || '').trim();
  const cleanName = String(full_name || '').trim();
  const cleanEmail = String(email || '').trim().slice(0, 120);
  const cleanPhone = String(phone || '').trim().slice(0, 40);

  if (!cleanUsername || !cleanName) {
    res.status(400).json({ error: 'Username and full name are required.' });
    return;
  }
  const pwCheck = validatePasswordPolicy(password);
  if (!pwCheck.valid || !password) {
    res.status(400).json({ error: pwCheck.error || 'Invalid temporary password.' });
    return;
  }
  if (!role || !['admin', 'manager', 'branch'].includes(role)) {
    res.status(400).json({ error: 'Role must be admin, manager, or branch.' });
    return;
  }

  let resolvedBranchId: number | null = null;
  if (role === 'branch') {
    if (!branch_id) {
      res.status(400).json({ error: 'Assigned branch is required for branch users.' });
      return;
    }
    const branchExists = db.prepare('SELECT id FROM branches WHERE id = ?').get(Number(branch_id));
    if (!branchExists) {
      res.status(400).json({ error: 'Selected branch does not exist.' });
      return;
    }
    resolvedBranchId = Number(branch_id);
  }

  const dup = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?)').get(cleanUsername);
  if (dup) {
    res.status(409).json({ error: `Username "${cleanUsername}" already exists.` });
    return;
  }

  const hash = hashPassword(password);
  const info = db
    .prepare(
      `INSERT INTO users (username, full_name, password_hash, role, branch_id, email, phone, must_change_password, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1)`
    )
    .run(cleanUsername, cleanName, hash, role, resolvedBranchId, cleanEmail, cleanPhone);

  const created = db
    .prepare(`${USER_SELECT_SQL} WHERE u.id = ?`)
    .get(Number(info.lastInsertRowid)) as Record<string, unknown>;

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'user',
    entityId: Number(info.lastInsertRowid),
    newValue: created,
    note: 'Created user with temporary password (must change on first sign-in)',
  });

  res.status(201).json(mapUserRow(created));
});

masterRouter.put('/users/:id', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db
    .prepare('SELECT id, username, full_name, role, branch_id, email, phone, active FROM users WHERE id = ?')
    .get(id) as
    | { id: number; username: string; full_name: string; role: UserRole; branch_id: number | null; email: string; phone: string; active: number }
    | undefined;

  if (!existing) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const { full_name, role, branch_id, email, phone } = req.body as {
    full_name?: string;
    role?: UserRole;
    branch_id?: number | null;
    email?: string;
    phone?: string;
  };

  const cleanName = String(full_name || '').trim();
  const cleanEmail = email !== undefined ? String(email || '').trim().slice(0, 120) : existing.email;
  const cleanPhone = phone !== undefined ? String(phone || '').trim().slice(0, 40) : existing.phone;

  if (!cleanName) {
    res.status(400).json({ error: 'Full name is required.' });
    return;
  }
  if (!role || !['admin', 'manager', 'branch'].includes(role)) {
    res.status(400).json({ error: 'Invalid role.' });
    return;
  }
  if (existing.username === 'admin' && role !== 'admin') {
    res.status(400).json({ error: 'Primary admin user role cannot be downgraded.' });
    return;
  }

  let resolvedBranchId: number | null = null;
  if (role === 'branch') {
    if (!branch_id) {
      res.status(400).json({ error: 'Assigned branch is required for branch users.' });
      return;
    }
    const branchExists = db.prepare('SELECT id FROM branches WHERE id = ?').get(Number(branch_id));
    if (!branchExists) {
      res.status(400).json({ error: 'Selected branch does not exist.' });
      return;
    }
    resolvedBranchId = Number(branch_id);
  }

  db.prepare(
    "UPDATE users SET full_name = ?, role = ?, branch_id = ?, email = ?, phone = ?, updated_at = datetime('now') WHERE id = ?"
  ).run(cleanName, role, resolvedBranchId, cleanEmail, cleanPhone, id);

  const updated = db.prepare(`${USER_SELECT_SQL} WHERE u.id = ?`).get(id) as Record<string, unknown>;

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'user',
    entityId: id,
    oldValue: existing,
    newValue: updated,
  });

  res.json(mapUserRow(updated));
});

masterRouter.post('/users/:id/reset-password', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT id, username FROM users WHERE id = ?').get(id) as
    | { id: number; username: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const { password } = req.body as { password?: string };
  const pwCheck = validatePasswordPolicy(password);
  if (!pwCheck.valid || !password) {
    res.status(400).json({ error: pwCheck.error || 'Invalid temporary password.' });
    return;
  }

  const hash = hashPassword(password);
  db.transaction(() => {
    db.prepare(
      "UPDATE users SET password_hash = ?, must_change_password = 1, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?"
    ).run(hash, id);
    db.prepare(
      "UPDATE password_reset_requests SET status = 'resolved', resolved_by = ?, resolved_at = datetime('now') WHERE user_id = ? AND status = 'pending'"
    ).run(req.user!.id, id);
  })();
  deleteUserSessions(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'RESET_PASSWORD',
    entityType: 'user',
    entityId: id,
    note: `Temporary password issued for ${existing.username} (must change on next sign-in)`,
  });

  res.json({ ok: true });
});

masterRouter.post('/users/:id/reset-link', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT id, username, active FROM users WHERE id = ?').get(id) as
    | { id: number; username: string; active: number }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  if (existing.active !== 1) {
    res.status(400).json({ error: 'Reactivate this user before generating a reset link.' });
    return;
  }

  const rawToken = crypto.randomBytes(24).toString('hex');
  const tokenHash = hashResetToken(rawToken);
  const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000).toISOString();

  db.transaction(() => {
    db.prepare("UPDATE password_reset_tokens SET used_at = datetime('now') WHERE user_id = ? AND used_at IS NULL").run(id);
    db.prepare('INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)').run(
      id,
      tokenHash,
      expiresAt
    );
  })();

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'GENERATE_RESET_LINK',
    entityType: 'user',
    entityId: id,
    note: `Generated one-time 30-minute reset link for ${existing.username}`,
  });

  res.json({
    ok: true,
    username: existing.username,
    token: rawToken,
    expires_at: expiresAt,
  });
});

masterRouter.post('/users/bulk-branch-logins', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { reissueAll } = (req.body || {}) as { reissueAll?: boolean };
  const issued: Array<{
    id: number;
    username: string;
    full_name: string;
    role: string;
    branch_name: string | null;
    temp_password: string;
  }> = [];

  const bulkTx = db.transaction(() => {
    // Ensure Head Office Manager exists
    const hoManager = db.prepare("SELECT id FROM users WHERE username = 'ho_manager'").get();
    if (!hoManager) {
      db.prepare(
        "INSERT INTO users (username, full_name, password_hash, role, branch_id, must_change_password, active) VALUES ('ho_manager', 'Head Office Manager', NULL, 'manager', NULL, 1, 1)"
      ).run();
    }

    // Ensure every active branch has a branch user account
    const activeBranches = db
      .prepare('SELECT id, name FROM branches WHERE active = 1 ORDER BY name ASC')
      .all() as Array<{ id: number; name: string }>;

    for (const b of activeBranches) {
      const existingForBranch = db
        .prepare("SELECT id FROM users WHERE role = 'branch' AND branch_id = ?")
        .get(b.id);
      if (!existingForBranch) {
        const slug = b.name
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '_')
          .replace(/^_+|_+$/g, '');
        let uname = `branch_${slug}`;
        const collision = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?)').get(uname);
        if (collision) {
          uname = `${uname}_${b.id}`;
        }
        db.prepare(
          "INSERT INTO users (username, full_name, password_hash, role, branch_id, must_change_password, active) VALUES (?, ?, NULL, 'branch', ?, 1, 1)"
        ).run(uname, `${b.name} Receiver`, b.id);
      }
    }

    const targets = db
      .prepare(
        `SELECT u.id, u.username, u.full_name, u.role, u.password_hash, b.name as branch_name
         FROM users u
         LEFT JOIN branches b ON b.id = u.branch_id
         WHERE u.active = 1 AND u.role IN ('branch', 'manager')
         ORDER BY u.role DESC, b.name ASC, u.username ASC`
      )
      .all() as Array<{
      id: number;
      username: string;
      full_name: string;
      role: string;
      password_hash: string | null;
      branch_name: string | null;
    }>;

    for (const t of targets) {
      if (!t.password_hash || reissueAll) {
        const tempPassword = generateTempPassword(10);
        const hash = hashPassword(tempPassword);
        db.prepare(
          "UPDATE users SET password_hash = ?, must_change_password = 1, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?"
        ).run(hash, t.id);
        deleteUserSessions(t.id);
        issued.push({
          id: t.id,
          username: t.username,
          full_name: t.full_name,
          role: t.role,
          branch_name: t.branch_name,
          temp_password: tempPassword,
        });
      }
    }
  });

  bulkTx();

  if (issued.length > 0) {
    logAudit({
      userId: req.user!.id,
      username: req.user!.username,
      action: 'RESET_PASSWORD',
      entityType: 'user',
      entityId: 'bulk',
      note: `Issued temporary passwords for ${issued.length} staff account(s): ${issued.map((i) => i.username).join(', ')}`,
    });
  }

  res.json({ issued });
});

masterRouter.get('/password-reset-requests', requireAuth, requireRole('admin'), (_req, res) => {
  const rows = db
    .prepare(
      `SELECT pr.*, u.full_name, u.role, u.email, u.phone, b.name as branch_name
       FROM password_reset_requests pr
       JOIN users u ON u.id = pr.user_id
       LEFT JOIN branches b ON b.id = u.branch_id
       WHERE pr.status = 'pending'
       ORDER BY pr.requested_at DESC`
    )
    .all();
  res.json(rows);
});

masterRouter.post('/password-reset-requests/:id/dismiss', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare("SELECT id, username FROM password_reset_requests WHERE id = ? AND status = 'pending'").get(id) as
    | { id: number; username: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Pending reset request not found.' });
    return;
  }

  db.prepare(
    "UPDATE password_reset_requests SET status = 'dismissed', resolved_by = ?, resolved_at = datetime('now') WHERE id = ?"
  ).run(req.user!.id, id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'DISMISS_RESET_REQUEST',
    entityType: 'password_reset_request',
    entityId: id,
    note: `Dismissed reset request for ${existing.username}`,
  });

  res.json({ ok: true });
});

masterRouter.patch('/users/:id/toggle', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  if (id === req.user!.id) {
    res.status(400).json({ error: 'You cannot deactivate your own account.' });
    return;
  }

  const existing = db.prepare('SELECT id, username, active FROM users WHERE id = ?').get(id) as
    | { id: number; username: string; active: number }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const nextActive = existing.active === 1 ? 0 : 1;
  db.prepare("UPDATE users SET active = ?, updated_at = datetime('now') WHERE id = ?").run(nextActive, id);
  if (nextActive === 0) {
    deleteUserSessions(id);
  }

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'user',
    entityId: id,
    oldValue: { active: existing.active },
    newValue: { active: nextActive },
    note: nextActive === 0 ? `Deactivated ${existing.username}` : `Reactivated ${existing.username}`,
  });

  res.json({ ok: true, active: nextActive });
});

// ---------------- SETTINGS & AUDIT LOG ----------------

masterRouter.get('/settings', requireAuth, (_req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all() as Array<{ key: string; value: string }>;
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;
  res.json({
    alert_threshold_pct: Number(map.alert_threshold_pct ?? '5'),
    company_name: map.company_name ?? 'KM Trading',
  });
});

masterRouter.put('/settings', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const { alert_threshold_pct, company_name } = req.body as {
    alert_threshold_pct?: number;
    company_name?: string;
  };

  const threshold = Number(alert_threshold_pct);
  if (!Number.isFinite(threshold) || threshold < 0 || threshold > 100) {
    res.status(400).json({ error: 'Alert threshold must be between 0 and 100.' });
    return;
  }

  const prevRow = db.prepare("SELECT value FROM settings WHERE key = 'alert_threshold_pct'").get() as
    | { value: string }
    | undefined;

  db.prepare(
    `INSERT INTO settings (key, value, updated_by, updated_at)
     VALUES ('alert_threshold_pct', ?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_by = excluded.updated_by, updated_at = datetime('now')`
  ).run(String(threshold), req.user!.id);

  if (company_name && company_name.trim()) {
    db.prepare(
      `INSERT INTO settings (key, value, updated_by, updated_at)
       VALUES ('company_name', ?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_by = excluded.updated_by, updated_at = datetime('now')`
    ).run(company_name.trim(), req.user!.id);
  }

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE_SETTING',
    entityType: 'settings',
    entityId: 'alert_threshold_pct',
    oldValue: { alert_threshold_pct: Number(prevRow?.value ?? 5) },
    newValue: { alert_threshold_pct: threshold },
  });

  res.json({ alert_threshold_pct: threshold });
});

masterRouter.get('/audit-logs', requireAuth, requireRole('admin'), (req, res) => {
  const search = String(req.query.search || '').trim();
  const action = String(req.query.action || '').trim();
  const entityType = String(req.query.entityType || '').trim();

  const clauses: string[] = [];
  const params: unknown[] = [];

  if (action) {
    clauses.push('action = ?');
    params.push(action);
  }
  if (entityType) {
    clauses.push('entity_type = ?');
    params.push(entityType);
  }
  if (search) {
    clauses.push('(username LIKE ? OR entity_id LIKE ? OR note LIKE ? OR old_value_json LIKE ? OR new_value_json LIKE ?)');
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }

  const where = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
  const rows = db
    .prepare(`SELECT * FROM audit_log ${where} ORDER BY id DESC LIMIT 300`)
    .all(...params);
  res.json(rows);
});

// ---------------- PROJECT SOURCE ZIP EXPORT ----------------

const EXPORT_ROOT_FILES = [
  'package.json',
  'bun.lock',
  'tsconfig.json',
  'vite.config.ts',
  'metadata.json',
  'index.html',
  'server.ts',
  '.env.example',
  '.gitignore',
  'README.md',
  'favicon.ico',
];

const EXPORT_DIRS = ['src', 'server', 'public', 'tests'];

const IGNORED_NAMES = new Set([
  'node_modules',
  'dist',
  'dev-dist',
  'data',
  'android-app',
  '.git',
  '.aistudio',
  '.DS_Store',
]);

function isAllowedExportFile(name: string): boolean {
  if (IGNORED_NAMES.has(name)) return false;
  if (name.startsWith('.env') && name !== '.env.example') return false;
  const lower = name.toLowerCase();
  if (
    lower.endsWith('.db') ||
    lower.endsWith('.db-wal') ||
    lower.endsWith('.db-shm') ||
    lower.endsWith('.sqlite') ||
    lower.endsWith('.sqlite3') ||
    lower.endsWith('.zip') ||
    lower.endsWith('.log')
  ) {
    return false;
  }
  return true;
}

function addDirectoryToZip(zipFolder: JSZip, rootDir: string, dirPath: string, relPrefix: string, stats: { count: number }) {
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    if (!isAllowedExportFile(entry.name)) continue;
    const fullPath = path.resolve(dirPath, entry.name);
    if (!fullPath.startsWith(rootDir + path.sep)) continue;
    const lstat = fs.lstatSync(fullPath);
    if (lstat.isSymbolicLink()) continue;

    const entryRel = relPrefix ? `${relPrefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      addDirectoryToZip(zipFolder, rootDir, fullPath, entryRel, stats);
    } else if (entry.isFile()) {
      zipFolder.file(entryRel, fs.readFileSync(fullPath));
      stats.count += 1;
    }
  }
}

masterRouter.get('/project/export-zip', requireAuth, requireRole('admin'), async (req: AuthenticatedRequest, res) => {
  try {
    const rootDir = path.resolve(process.cwd());
    const zip = new JSZip();
    const pkgFolder = zip.folder('km-trading-web-app');
    if (!pkgFolder) {
      res.status(500).json({ error: 'Failed to initialize ZIP archive.' });
      return;
    }

    const stats = { count: 0 };

    for (const fileName of EXPORT_ROOT_FILES) {
      if (!isAllowedExportFile(fileName)) continue;
      const fullPath = path.resolve(rootDir, fileName);
      if (!fullPath.startsWith(rootDir + path.sep)) continue;
      if (fs.existsSync(fullPath)) {
        const lstat = fs.lstatSync(fullPath);
        if (!lstat.isSymbolicLink() && lstat.isFile()) {
          pkgFolder.file(fileName, fs.readFileSync(fullPath));
          stats.count += 1;
        }
      }
    }

    for (const dirName of EXPORT_DIRS) {
      const dirPath = path.resolve(rootDir, dirName);
      if (!dirPath.startsWith(rootDir + path.sep)) continue;
      if (fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory()) {
        addDirectoryToZip(pkgFolder, rootDir, dirPath, dirName, stats);
      }
    }

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    logAudit({
      userId: req.user!.id,
      username: req.user!.username,
      action: 'EXPORT_PROJECT_ZIP',
      entityType: 'project',
      entityId: 'km-trading-web-app',
      note: `Exported web application source archive (${stats.count} files, ${zipBuffer.length} bytes)`,
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="km-trading-web-app.zip"');
    res.send(zipBuffer);
  } catch (err) {
    console.error('Project ZIP export failed:', err);
    res.status(500).json({ error: 'Failed to generate project ZIP archive.' });
  }
});
