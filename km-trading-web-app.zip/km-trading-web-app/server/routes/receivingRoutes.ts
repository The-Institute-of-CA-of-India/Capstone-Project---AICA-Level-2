import { Router } from 'express';
import { AuthenticatedRequest, requireAuth, requireRole } from '../auth';
import { db, getDayLockStatus, getTodayDateString, logAudit, roundMoney, roundQty } from '../db';
import type { ReceivingEntry } from '../../src/types';

export const receivingRouter = Router();

function isValidDateString(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

function normalizeEntryUnit(raw: unknown): 'kg' | 'pcs' | 'pack' | null {
  const s = String(raw || '').trim().toLowerCase();
  if (s === 'kg') return 'kg';
  if (s === 'pcs' || s === 'pc' || s === 'piece') return 'pcs';
  if (s === 'pack' || s === 'pkt' || s === 'packet') return 'pack';
  return null;
}

function getAlertThreshold(): number {
  const row = db.prepare("SELECT value FROM settings WHERE key = 'alert_threshold_pct'").get() as
    | { value: string }
    | undefined;
  const val = Number(row?.value ?? '5');
  return Number.isFinite(val) ? val : 5;
}

function fetchReceivingEntries(filters: {
  date?: string;
  startDate?: string;
  endDate?: string;
  branchId?: number | null;
  productId?: number | null;
  reasonId?: number | null;
  documentNumber?: string | null;
}): ReceivingEntry[] {
  const clauses: string[] = [];
  const params: unknown[] = [];

  if (filters.date) {
    clauses.push('ri.entry_date = ?');
    params.push(filters.date);
  }
  if (filters.startDate) {
    clauses.push('ri.entry_date >= ?');
    params.push(filters.startDate);
  }
  if (filters.endDate) {
    clauses.push('ri.entry_date <= ?');
    params.push(filters.endDate);
  }
  if (filters.branchId) {
    clauses.push('ri.branch_id = ?');
    params.push(filters.branchId);
  }
  if (filters.productId) {
    clauses.push('ri.product_id = ?');
    params.push(filters.productId);
  }
  if (filters.reasonId) {
    clauses.push('ri.reason_id = ?');
    params.push(filters.reasonId);
  }
  if (filters.documentNumber) {
    clauses.push('LOWER(rd.document_number) LIKE LOWER(?)');
    params.push(`%${filters.documentNumber.trim()}%`);
  }

  const where = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
  return db
    .prepare(
      `SELECT
         ri.*,
         rd.document_number,
         b.name as branch_name,
         r.name as reason_name,
         u.username as created_by_name
       FROM receiving_items ri
       JOIN receiving_documents rd ON rd.id = ri.document_id
       JOIN branches b ON b.id = ri.branch_id
       LEFT JOIN reasons r ON r.id = ri.reason_id
       JOIN users u ON u.id = ri.created_by
       ${where}
       ORDER BY ri.entry_date DESC, rd.document_number ASC, ri.id DESC`
    )
    .all(...params) as ReceivingEntry[];
}

// ---------------- DAY LOCK ----------------

receivingRouter.get('/days/:date', requireAuth, (req, res) => {
  const date = req.params.date;
  if (!isValidDateString(date)) {
    res.status(400).json({ error: 'Invalid date format (expected YYYY-MM-DD).' });
    return;
  }

  const lockInfo = getDayLockStatus(date);
  let lockedByName: string | null = null;
  let reopenedByName: string | null = null;

  if (lockInfo.row?.locked_by) {
    const u = db.prepare('SELECT full_name FROM users WHERE id = ?').get(lockInfo.row.locked_by) as
      | { full_name: string }
      | undefined;
    lockedByName = u?.full_name ?? null;
  }
  if (lockInfo.row?.reopened_by) {
    const u = db.prepare('SELECT full_name FROM users WHERE id = ?').get(lockInfo.row.reopened_by) as
      | { full_name: string }
      | undefined;
    reopenedByName = u?.full_name ?? null;
  }

  res.json({
    entry_date: date,
    status: lockInfo.status,
    auto_locked: lockInfo.auto_locked,
    locked_by_name: lockedByName,
    locked_at: lockInfo.row?.locked_at ?? null,
    reopened_by_name: reopenedByName,
    reopened_at: lockInfo.row?.reopened_at ?? null,
    reopen_reason: lockInfo.row?.reopen_reason ?? null,
    server_today: getTodayDateString(),
  });
});

receivingRouter.post('/days/:date/close', requireAuth, requireRole('admin', 'manager'), (req: AuthenticatedRequest, res) => {
  const date = req.params.date;
  if (!isValidDateString(date)) {
    res.status(400).json({ error: 'Invalid date format.' });
    return;
  }

  const prev = getDayLockStatus(date);
  if (prev.status === 'locked' && !prev.auto_locked) {
    res.status(400).json({ error: 'This date is already locked.' });
    return;
  }

  db.prepare(
    `INSERT INTO daily_lock (entry_date, status, locked_by, locked_at)
     VALUES (?, 'locked', ?, datetime('now'))
     ON CONFLICT(entry_date) DO UPDATE SET
       status = 'locked',
       locked_by = excluded.locked_by,
       locked_at = datetime('now')`
  ).run(date, req.user!.id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'LOCK_DAY',
    entityType: 'daily_lock',
    entityId: date,
    oldValue: { status: prev.status },
    newValue: { status: 'locked' },
    note: `Day ${date} closed and locked`,
  });

  res.json({ ok: true, entry_date: date, status: 'locked' });
});

receivingRouter.post('/days/:date/reopen', requireAuth, requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const date = req.params.date;
  if (!isValidDateString(date)) {
    res.status(400).json({ error: 'Invalid date format.' });
    return;
  }

  const { reason } = req.body as { reason?: string };
  const cleanReason = String(reason || '').trim();
  if (cleanReason.length < 3) {
    res.status(400).json({ error: 'A reopen reason (at least 3 characters) is mandatory.' });
    return;
  }

  const prev = getDayLockStatus(date);
  db.prepare(
    `INSERT INTO daily_lock (entry_date, status, reopened_by, reopened_at, reopen_reason)
     VALUES (?, 'open', ?, datetime('now'), ?)
     ON CONFLICT(entry_date) DO UPDATE SET
       status = 'open',
       reopened_by = excluded.reopened_by,
       reopened_at = datetime('now'),
       reopen_reason = excluded.reopen_reason`
  ).run(date, req.user!.id, cleanReason);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'REOPEN_DAY',
    entityType: 'daily_lock',
    entityId: date,
    oldValue: { status: prev.status },
    newValue: { status: 'open', reopen_reason: cleanReason },
    note: cleanReason,
  });

  res.json({ ok: true, entry_date: date, status: 'open', reopen_reason: cleanReason });
});

// ---------------- RECEIVING ENTRIES ----------------

receivingRouter.get('/receiving', requireAuth, (req: AuthenticatedRequest, res) => {
  const date = String(req.query.date || getTodayDateString());
  if (!isValidDateString(date)) {
    res.status(400).json({ error: 'Invalid date.' });
    return;
  }

  let branchId: number | null = req.query.branchId ? Number(req.query.branchId) : null;
  if (req.user!.role === 'branch') {
    if (!req.user!.branch_id) {
      res.status(403).json({ error: 'No branch assigned to your account.' });
      return;
    }
    branchId = req.user!.branch_id;
  }

  const documentNumber = req.query.documentNumber ? String(req.query.documentNumber) : null;
  const rows = fetchReceivingEntries({ date, branchId, documentNumber });
  res.json(rows);
});

receivingRouter.post('/receiving/quick-product', requireAuth, requireRole('admin', 'branch'), (req: AuthenticatedRequest, res) => {
  const { barcode, name, unit, category } = req.body as {
    barcode?: string;
    name?: string;
    unit?: string;
    category?: string;
  };

  const cleanBarcode = String(barcode || '').trim();
  const cleanName = String(name || '').trim();
  if (!cleanBarcode || !cleanName) {
    res.status(400).json({ error: 'Both barcode and product name are required to create a new product.' });
    return;
  }

  const resolvedUnit = unit ? normalizeEntryUnit(unit) : 'kg';
  if (!resolvedUnit) {
    res.status(400).json({ error: 'Unit must be kg, pcs, or pack.' });
    return;
  }

  const rawCat = String(category || 'Vegetable').trim().toLowerCase();
  const resolvedCategory = rawCat === 'fruit' || rawCat === 'fruits' ? 'Fruit' : rawCat === 'vegetable' || rawCat === 'vegetables' || rawCat === 'veg' ? 'Vegetable' : null;
  if (!resolvedCategory) {
    res.status(400).json({ error: 'Category must be Fruit or Vegetable.' });
    return;
  }

  const existing = db.prepare('SELECT * FROM products WHERE LOWER(barcode) = LOWER(?)').get(cleanBarcode) as
    | { id: number; barcode: string; name: string }
    | undefined;
  if (existing) {
    res.status(409).json({
      error: `Barcode "${cleanBarcode}" already belongs to "${existing.name}".`,
      existingProduct: existing,
    });
    return;
  }

  const info = db
    .prepare('INSERT INTO products (barcode, name, unit, default_price, category, active) VALUES (?, ?, ?, 0, ?, 1)')
    .run(cleanBarcode, cleanName, resolvedUnit, resolvedCategory);

  const created = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(info.lastInsertRowid));
  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'product',
    entityId: Number(info.lastInsertRowid),
    newValue: created,
    note: 'Quick-created from Daily Receiving entry screen',
  });

  res.status(201).json(created);
});

receivingRouter.post('/receiving', requireAuth, requireRole('admin', 'branch'), (req: AuthenticatedRequest, res) => {
  const {
    entry_date,
    branch_id,
    document_number,
    product_id,
    unit,
    transferred_qty,
    received_qty,
    unit_price,
    transferred_value,
    received_value,
    value_overridden,
    reason_id,
    remarks,
  } = req.body as {
    entry_date?: string;
    branch_id?: number;
    document_number?: string;
    product_id?: number;
    unit?: string;
    transferred_qty?: number;
    received_qty?: number;
    unit_price?: number;
    transferred_value?: number;
    received_value?: number;
    value_overridden?: boolean;
    reason_id?: number | null;
    remarks?: string;
  };

  const cleanDate = String(entry_date || getTodayDateString());
  if (!isValidDateString(cleanDate)) {
    res.status(400).json({ error: 'Invalid entry date.' });
    return;
  }

  const dayLock = getDayLockStatus(cleanDate);
  if (dayLock.status !== 'open') {
    res.status(403).json({ error: `Day ${cleanDate} is locked. Entries cannot be added.` });
    return;
  }

  if (req.user!.role === 'branch' && !req.user!.branch_id) {
    res.status(403).json({ error: 'No branch assigned to your account.' });
    return;
  }
  const resolvedBranchId = req.user!.role === 'branch' ? req.user!.branch_id : Number(branch_id);
  if (!resolvedBranchId) {
    res.status(400).json({ error: 'Branch is required.' });
    return;
  }

  const branchRow = db.prepare('SELECT * FROM branches WHERE id = ? AND active = 1').get(resolvedBranchId);
  if (!branchRow) {
    res.status(400).json({ error: 'Selected branch is inactive or does not exist.' });
    return;
  }

  const cleanDoc = String(document_number || '').trim();
  if (!cleanDoc) {
    res.status(400).json({ error: 'Document number (GRN / Transfer No.) is required.' });
    return;
  }

  const productRow = db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(Number(product_id)) as
    | { id: number; barcode: string; name: string; unit: string; default_price: number; category: string }
    | undefined;
  if (!productRow) {
    res.status(400).json({ error: 'Selected product is inactive or does not exist.' });
    return;
  }

  let resolvedUnit = productRow.unit;
  if (unit !== undefined && unit !== null && String(unit).trim() !== '') {
    const parsedUnit = normalizeEntryUnit(unit);
    if (!parsedUnit) {
      res.status(400).json({ error: 'Unit must be kg, pcs, or pack.' });
      return;
    }
    resolvedUnit = parsedUnit;
  }

  const tQty = Number(transferred_qty);
  const rQty = Number(received_qty);
  const hasPrice = unit_price !== undefined && unit_price !== null && String(unit_price).trim() !== '';
  const price = hasPrice ? Number(unit_price) : NaN;

  if (!Number.isFinite(tQty) || tQty < 0 || !Number.isFinite(rQty) || rQty < 0) {
    res.status(400).json({ error: 'Transferred and received quantities must be non-negative numbers.' });
    return;
  }
  if (!hasPrice || !Number.isFinite(price) || price < 0) {
    res.status(400).json({ error: 'Unit price is mandatory and must be a non-negative number.' });
    return;
  }

  const cleanTQty = roundQty(tQty);
  const cleanRQty = roundQty(rQty);
  const diffQty = roundQty(cleanTQty - cleanRQty);
  const cleanPrice = roundMoney(price);

  let resolvedReasonId: number | null = reason_id ? Number(reason_id) : null;
  if (Math.abs(diffQty) > 0.0001) {
    if (!resolvedReasonId) {
      res.status(400).json({ error: 'A reason is required whenever transferred and received quantities differ.' });
      return;
    }
    const reasonRow = db.prepare('SELECT id FROM reasons WHERE id = ? AND active = 1').get(resolvedReasonId);
    if (!reasonRow) {
      res.status(400).json({ error: 'Selected reason is inactive or invalid.' });
      return;
    }
  } else {
    resolvedReasonId = null;
  }

  let tVal = roundMoney(cleanTQty * cleanPrice);
  let rVal = roundMoney(cleanRQty * cleanPrice);
  const isOverridden = Boolean(value_overridden);

  if (isOverridden) {
    const manualTVal = Number(transferred_value);
    const manualRVal = Number(received_value);
    if (!Number.isFinite(manualTVal) || manualTVal < 0 || !Number.isFinite(manualRVal) || manualRVal < 0) {
      res.status(400).json({ error: 'Overridden values must be non-negative numbers.' });
      return;
    }
    tVal = roundMoney(manualTVal);
    rVal = roundMoney(manualRVal);
  }
  const diffVal = roundMoney(tVal - rVal);
  const cleanRemarks = String(remarks || '').trim();

  const createTx = db.transaction(() => {
    let doc = db
      .prepare('SELECT id FROM receiving_documents WHERE entry_date = ? AND branch_id = ? AND document_number = ?')
      .get(cleanDate, resolvedBranchId, cleanDoc) as { id: number } | undefined;

    if (!doc) {
      const docInfo = db
        .prepare('INSERT INTO receiving_documents (entry_date, branch_id, document_number, created_by) VALUES (?, ?, ?, ?)')
        .run(cleanDate, resolvedBranchId, cleanDoc, req.user!.id);
      doc = { id: Number(docInfo.lastInsertRowid) };
    }

    const itemInfo = db
      .prepare(
        `INSERT INTO receiving_items (
           document_id, entry_date, branch_id, product_id,
           barcode_snapshot, product_name_snapshot, unit_snapshot, category_snapshot,
           transferred_qty, received_qty, difference_qty, unit_price,
           transferred_value, received_value, difference_value, value_overridden,
           reason_id, remarks, created_by, updated_by
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        doc.id,
        cleanDate,
        resolvedBranchId,
        productRow.id,
        productRow.barcode,
        productRow.name,
        resolvedUnit,
        productRow.category,
        cleanTQty,
        cleanRQty,
        diffQty,
        cleanPrice,
        tVal,
        rVal,
        diffVal,
        isOverridden ? 1 : 0,
        resolvedReasonId,
        cleanRemarks,
        req.user!.id,
        req.user!.id
      );

    return Number(itemInfo.lastInsertRowid);
  });

  const newId = createTx();
  const created = db
    .prepare(
      `SELECT ri.*, rd.document_number, b.name as branch_name, r.name as reason_name, u.username as created_by_name
       FROM receiving_items ri
       JOIN receiving_documents rd ON rd.id = ri.document_id
       JOIN branches b ON b.id = ri.branch_id
       LEFT JOIN reasons r ON r.id = ri.reason_id
       JOIN users u ON u.id = ri.created_by
       WHERE ri.id = ?`
    )
    .get(newId);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CREATE',
    entityType: 'receiving_item',
    entityId: newId,
    newValue: created,
  });

  res.status(201).json(created);
});

receivingRouter.put('/receiving/:id', requireAuth, requireRole('admin', 'branch'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM receiving_items WHERE id = ?').get(id) as
    | (ReceivingEntry & { document_id: number })
    | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Entry not found.' });
    return;
  }

  if (req.user!.role === 'branch' && existing.branch_id !== req.user!.branch_id) {
    res.status(403).json({ error: 'You can only edit entries belonging to your branch.' });
    return;
  }

  const dayLock = getDayLockStatus(existing.entry_date);
  if (dayLock.status !== 'open') {
    res.status(403).json({ error: `Day ${existing.entry_date} is locked. Entries cannot be modified.` });
    return;
  }

  const {
    document_number,
    product_id,
    unit,
    transferred_qty,
    received_qty,
    unit_price,
    transferred_value,
    received_value,
    value_overridden,
    reason_id,
    remarks,
  } = req.body as {
    document_number?: string;
    product_id?: number;
    unit?: string;
    transferred_qty?: number;
    received_qty?: number;
    unit_price?: number;
    transferred_value?: number;
    received_value?: number;
    value_overridden?: boolean;
    reason_id?: number | null;
    remarks?: string;
  };

  const cleanDoc = String(document_number || '').trim();
  if (!cleanDoc) {
    res.status(400).json({ error: 'Document number is required.' });
    return;
  }

  const productRow = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(product_id || existing.product_id)) as
    | { id: number; barcode: string; name: string; unit: string; default_price: number; category: string }
    | undefined;
  if (!productRow) {
    res.status(400).json({ error: 'Product not found.' });
    return;
  }

  let resolvedUnit = productRow.unit;
  if (unit !== undefined && unit !== null && String(unit).trim() !== '') {
    const parsedUnit = normalizeEntryUnit(unit);
    if (!parsedUnit) {
      res.status(400).json({ error: 'Unit must be kg, pcs, or pack.' });
      return;
    }
    resolvedUnit = parsedUnit;
  }

  const tQty = Number(transferred_qty);
  const rQty = Number(received_qty);
  const hasPrice = unit_price !== undefined && unit_price !== null && String(unit_price).trim() !== '';
  const price = hasPrice ? Number(unit_price) : NaN;

  if (!Number.isFinite(tQty) || tQty < 0 || !Number.isFinite(rQty) || rQty < 0 || !hasPrice || !Number.isFinite(price) || price < 0) {
    res.status(400).json({ error: 'Quantities and mandatory unit price must be non-negative numbers.' });
    return;
  }

  const cleanTQty = roundQty(tQty);
  const cleanRQty = roundQty(rQty);
  const diffQty = roundQty(cleanTQty - cleanRQty);
  const cleanPrice = roundMoney(price);

  let resolvedReasonId: number | null = reason_id ? Number(reason_id) : null;
  if (Math.abs(diffQty) > 0.0001) {
    if (!resolvedReasonId) {
      res.status(400).json({ error: 'A reason is required whenever transferred and received quantities differ.' });
      return;
    }
    const reasonRow = db.prepare('SELECT id FROM reasons WHERE id = ?').get(resolvedReasonId);
    if (!reasonRow) {
      res.status(400).json({ error: 'Invalid reason selected.' });
      return;
    }
  } else {
    resolvedReasonId = null;
  }

  let tVal = roundMoney(cleanTQty * cleanPrice);
  let rVal = roundMoney(cleanRQty * cleanPrice);
  const isOverridden = Boolean(value_overridden);
  if (isOverridden) {
    const manualTVal = Number(transferred_value);
    const manualRVal = Number(received_value);
    if (!Number.isFinite(manualTVal) || manualTVal < 0 || !Number.isFinite(manualRVal) || manualRVal < 0) {
      res.status(400).json({ error: 'Overridden values must be non-negative numbers.' });
      return;
    }
    tVal = roundMoney(manualTVal);
    rVal = roundMoney(manualRVal);
  }
  const diffVal = roundMoney(tVal - rVal);
  const cleanRemarks = String(remarks || '').trim();

  const updateTx = db.transaction(() => {
    let doc = db
      .prepare('SELECT id FROM receiving_documents WHERE entry_date = ? AND branch_id = ? AND document_number = ?')
      .get(existing.entry_date, existing.branch_id, cleanDoc) as { id: number } | undefined;

    if (!doc) {
      const docInfo = db
        .prepare('INSERT INTO receiving_documents (entry_date, branch_id, document_number, created_by) VALUES (?, ?, ?, ?)')
        .run(existing.entry_date, existing.branch_id, cleanDoc, req.user!.id);
      doc = { id: Number(docInfo.lastInsertRowid) };
    }

    db.prepare(
      `UPDATE receiving_items SET
         document_id = ?,
         product_id = ?,
         barcode_snapshot = ?,
         product_name_snapshot = ?,
         unit_snapshot = ?,
         category_snapshot = ?,
         transferred_qty = ?,
         received_qty = ?,
         difference_qty = ?,
         unit_price = ?,
         transferred_value = ?,
         received_value = ?,
         difference_value = ?,
         value_overridden = ?,
         reason_id = ?,
         remarks = ?,
         updated_by = ?,
         updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      doc.id,
      productRow.id,
      productRow.barcode,
      productRow.name,
      resolvedUnit,
      productRow.category,
      cleanTQty,
      cleanRQty,
      diffQty,
      cleanPrice,
      tVal,
      rVal,
      diffVal,
      isOverridden ? 1 : 0,
      resolvedReasonId,
      cleanRemarks,
      req.user!.id,
      id
    );
  });

  updateTx();

  const updated = db
    .prepare(
      `SELECT ri.*, rd.document_number, b.name as branch_name, r.name as reason_name, u.username as created_by_name
       FROM receiving_items ri
       JOIN receiving_documents rd ON rd.id = ri.document_id
       JOIN branches b ON b.id = ri.branch_id
       LEFT JOIN reasons r ON r.id = ri.reason_id
       JOIN users u ON u.id = ri.created_by
       WHERE ri.id = ?`
    )
    .get(id);

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'UPDATE',
    entityType: 'receiving_item',
    entityId: id,
    oldValue: existing,
    newValue: updated,
  });

  res.json(updated);
});

receivingRouter.delete('/receiving/:id', requireAuth, requireRole('admin', 'branch'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM receiving_items WHERE id = ?').get(id) as
    | { id: number; entry_date: string; branch_id: number; document_id: number }
    | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Entry not found.' });
    return;
  }

  if (req.user!.role === 'branch' && existing.branch_id !== req.user!.branch_id) {
    res.status(403).json({ error: 'You can only delete entries belonging to your branch.' });
    return;
  }

  const dayLock = getDayLockStatus(existing.entry_date);
  if (dayLock.status !== 'open') {
    res.status(403).json({ error: `Day ${existing.entry_date} is locked. Entries cannot be deleted.` });
    return;
  }

  db.prepare('DELETE FROM receiving_items WHERE id = ?').run(id);
  const remaining = db
    .prepare('SELECT COUNT(*) as c FROM receiving_items WHERE document_id = ?')
    .get(existing.document_id) as { c: number };
  if (remaining.c === 0) {
    db.prepare('DELETE FROM receiving_documents WHERE id = ?').run(existing.document_id);
  }

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'DELETE',
    entityType: 'receiving_item',
    entityId: id,
    oldValue: existing,
  });

  res.json({ ok: true });
});

// ---------------- REPORTS & DASHBOARD ----------------

receivingRouter.get('/reports/dashboard', requireAuth, (req: AuthenticatedRequest, res) => {
  const date = String(req.query.date || getTodayDateString());
  if (!isValidDateString(date)) {
    res.status(400).json({ error: 'Invalid date.' });
    return;
  }

  const threshold = getAlertThreshold();
  if (req.user!.role === 'branch' && !req.user!.branch_id) {
    res.status(403).json({ error: 'No branch assigned to your account.' });
    return;
  }
  const branchScope = req.user!.role === 'branch' ? req.user!.branch_id : null;
  const entries = fetchReceivingEntries({ date, branchId: branchScope });
  const dayStatus = getDayLockStatus(date).status;

  let transferredQty = 0;
  let receivedQty = 0;
  let differenceQty = 0;
  let transferredValue = 0;
  let receivedValue = 0;
  let differenceValue = 0;

  for (const e of entries) {
    transferredQty += e.transferred_qty;
    receivedQty += e.received_qty;
    differenceQty += e.difference_qty;
    transferredValue += e.transferred_value;
    receivedValue += e.received_value;
    differenceValue += e.difference_value;
  }

  const overallLossPct = transferredQty > 0 ? roundMoney((differenceQty / transferredQty) * 100) : 0;

  const branchFilterSql = branchScope ? 'AND b.id = ?' : '';
  const branchParams = branchScope ? [date, branchScope] : [date];

  const branchRows = db
    .prepare(
      `SELECT
         b.id as branch_id,
         b.name as branch_name,
         b.location as branch_location,
         COUNT(ri.id) as entry_count,
         COALESCE(SUM(ri.transferred_qty), 0) as transferred_qty,
         COALESCE(SUM(ri.received_qty), 0) as received_qty,
         COALESCE(SUM(ri.difference_qty), 0) as difference_qty,
         COALESCE(SUM(ri.transferred_value), 0) as transferred_value,
         COALESCE(SUM(ri.received_value), 0) as received_value,
         COALESCE(SUM(ri.difference_value), 0) as difference_value
       FROM branches b
       LEFT JOIN receiving_items ri ON ri.branch_id = b.id AND ri.entry_date = ?
       WHERE b.active = 1 ${branchFilterSql}
       GROUP BY b.id
       ORDER BY difference_value DESC`
    )
    .all(...branchParams) as Array<{
    branch_id: number;
    branch_name: string;
    branch_location: string;
    entry_count: number;
    transferred_qty: number;
    received_qty: number;
    difference_qty: number;
    transferred_value: number;
    received_value: number;
    difference_value: number;
  }>;

  const branchStats = branchRows
    .map((b) => {
      const lossPct = b.transferred_qty > 0 ? roundMoney((b.difference_qty / b.transferred_qty) * 100) : 0;
      return {
        ...b,
        transferred_qty: roundQty(b.transferred_qty),
        received_qty: roundQty(b.received_qty),
        difference_qty: roundQty(b.difference_qty),
        transferred_value: roundMoney(b.transferred_value),
        received_value: roundMoney(b.received_value),
        difference_value: roundMoney(b.difference_value),
        loss_pct: lossPct,
        is_alert: Math.abs(lossPct) > threshold && b.entry_count > 0,
      };
    })
    .sort((a, b) => b.loss_pct - a.loss_pct);

  const flaggedEntries = entries
    .map((e) => {
      const lossPct = e.transferred_qty > 0 ? roundMoney((e.difference_qty / e.transferred_qty) * 100) : 0;
      return { ...e, loss_pct: lossPct };
    })
    .filter((e) => Math.abs(e.loss_pct) > threshold);

  // Top shortage products (across last 30 days or selected date? Show recent 30 days up to date for repeated shortages!)
  const dObj = new Date(`${date}T00:00:00`);
  dObj.setDate(dObj.getDate() - 30);
  const thirtyDaysAgo = new Intl.DateTimeFormat('en-CA', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(dObj);

  const prodScopeSql = branchScope ? 'AND ri.branch_id = ?' : '';
  const prodParams = branchScope ? [thirtyDaysAgo, date, branchScope] : [thirtyDaysAgo, date];

  const topShortageProducts = db
    .prepare(
      `SELECT
         ri.product_id,
         MAX(ri.barcode_snapshot) as barcode,
         MAX(ri.product_name_snapshot) as product_name,
         MAX(ri.unit_snapshot) as unit,
         COUNT(*) as shortage_count,
         ROUND(SUM(ri.difference_qty), 3) as total_shortage_qty,
         ROUND(SUM(ri.difference_value), 2) as total_loss_value
       FROM receiving_items ri
       WHERE ri.entry_date BETWEEN ? AND ?
         AND ri.difference_qty > 0
         ${prodScopeSql}
       GROUP BY ri.product_id
       ORDER BY shortage_count DESC, total_loss_value DESC
       LIMIT 6`
    )
    .all(...prodParams);

  const topReasons = db
    .prepare(
      `SELECT
         r.id as reason_id,
         r.name as reason_name,
         COUNT(*) as occurrence_count,
         ROUND(SUM(ri.difference_qty), 3) as total_difference_qty,
         ROUND(SUM(ri.difference_value), 2) as total_difference_value
       FROM receiving_items ri
       JOIN reasons r ON r.id = ri.reason_id
       WHERE ri.entry_date BETWEEN ? AND ?
         AND ri.difference_qty != 0
         ${prodScopeSql}
       GROUP BY r.id
       ORDER BY occurrence_count DESC, total_difference_value DESC`
    )
    .all(...prodParams);

  res.json({
    date,
    dayStatus,
    alertThresholdPct: threshold,
    totals: {
      entryCount: entries.length,
      transferredQty: roundQty(transferredQty),
      receivedQty: roundQty(receivedQty),
      differenceQty: roundQty(differenceQty),
      transferredValue: roundMoney(transferredValue),
      receivedValue: roundMoney(receivedValue),
      differenceValue: roundMoney(differenceValue),
      lossPct: overallLossPct,
    },
    branchStats,
    flaggedEntries,
    topShortageProducts,
    topReasons,
  });
});

receivingRouter.get('/reports/daily', requireAuth, (req: AuthenticatedRequest, res) => {
  const date = String(req.query.date || getTodayDateString());
  const startDate = req.query.startDate ? String(req.query.startDate) : undefined;
  const endDate = req.query.endDate ? String(req.query.endDate) : undefined;
  let branchId = req.query.branchId ? Number(req.query.branchId) : null;
  if (req.user!.role === 'branch') {
    if (!req.user!.branch_id) {
      res.status(403).json({ error: 'No branch assigned to your account.' });
      return;
    }
    branchId = req.user!.branch_id;
  }
  const productId = req.query.productId ? Number(req.query.productId) : null;
  const reasonId = req.query.reasonId ? Number(req.query.reasonId) : null;

  const entries = fetchReceivingEntries({
    date: startDate || endDate ? undefined : date,
    startDate,
    endDate,
    branchId,
    productId,
    reasonId,
  });

  const threshold = getAlertThreshold();
  let transferredQty = 0;
  let receivedQty = 0;
  let differenceQty = 0;
  let transferredValue = 0;
  let receivedValue = 0;
  let differenceValue = 0;

  const enriched = entries.map((e) => {
    transferredQty += e.transferred_qty;
    receivedQty += e.received_qty;
    differenceQty += e.difference_qty;
    transferredValue += e.transferred_value;
    receivedValue += e.received_value;
    differenceValue += e.difference_value;
    const lossPct = e.transferred_qty > 0 ? roundMoney((e.difference_qty / e.transferred_qty) * 100) : 0;
    return {
      ...e,
      loss_pct: lossPct,
      is_alert: Math.abs(lossPct) > threshold,
    };
  });

  res.json({
    entries: enriched,
    alertThresholdPct: threshold,
    totals: {
      transferredQty: roundQty(transferredQty),
      receivedQty: roundQty(receivedQty),
      differenceQty: roundQty(differenceQty),
      transferredValue: roundMoney(transferredValue),
      receivedValue: roundMoney(receivedValue),
      differenceValue: roundMoney(differenceValue),
      lossPct: transferredQty > 0 ? roundMoney((differenceQty / transferredQty) * 100) : 0,
    },
  });
});

receivingRouter.get('/reports/consolidated', requireAuth, (req: AuthenticatedRequest, res) => {
  const date = String(req.query.date || getTodayDateString());
  const startDate = req.query.startDate ? String(req.query.startDate) : date;
  const endDate = req.query.endDate ? String(req.query.endDate) : date;
  const productId = req.query.productId ? Number(req.query.productId) : null;
  const reasonId = req.query.reasonId ? Number(req.query.reasonId) : null;
  if (req.user!.role === 'branch' && !req.user!.branch_id) {
    res.status(403).json({ error: 'No branch assigned to your account.' });
    return;
  }
  const branchScope = req.user!.role === 'branch' ? req.user!.branch_id : req.query.branchId ? Number(req.query.branchId) : null;

  const entries = fetchReceivingEntries({
    startDate,
    endDate,
    branchId: branchScope,
    productId,
    reasonId,
  });

  const branches = db
    .prepare(`SELECT * FROM branches ${branchScope ? 'WHERE id = ?' : 'WHERE active = 1'} ORDER BY name ASC`)
    .all(...(branchScope ? [branchScope] : [])) as Array<{ id: number; name: string; location: string }>;

  const threshold = getAlertThreshold();
  const map = new Map<
    number,
    {
      branch_id: number;
      branch_name: string;
      branch_location: string;
      entry_count: number;
      doc_count: number;
      docs: Set<string>;
      transferred_qty: number;
      received_qty: number;
      difference_qty: number;
      transferred_value: number;
      received_value: number;
      difference_value: number;
    }
  >();

  for (const b of branches) {
    map.set(b.id, {
      branch_id: b.id,
      branch_name: b.name,
      branch_location: b.location,
      entry_count: 0,
      doc_count: 0,
      docs: new Set(),
      transferred_qty: 0,
      received_qty: 0,
      difference_qty: 0,
      transferred_value: 0,
      received_value: 0,
      difference_value: 0,
    });
  }

  for (const e of entries) {
    let agg = map.get(e.branch_id);
    if (!agg) {
      agg = {
        branch_id: e.branch_id,
        branch_name: e.branch_name,
        branch_location: '',
        entry_count: 0,
        doc_count: 0,
        docs: new Set(),
        transferred_qty: 0,
        received_qty: 0,
        difference_qty: 0,
        transferred_value: 0,
        received_value: 0,
        difference_value: 0,
      };
      map.set(e.branch_id, agg);
    }
    agg.entry_count += 1;
    agg.docs.add(`${e.entry_date}::${e.document_number}`);
    agg.transferred_qty += e.transferred_qty;
    agg.received_qty += e.received_qty;
    agg.difference_qty += e.difference_qty;
    agg.transferred_value += e.transferred_value;
    agg.received_value += e.received_value;
    agg.difference_value += e.difference_value;
  }

  let grandTQty = 0;
  let grandRQty = 0;
  let grandDQty = 0;
  let grandTVal = 0;
  let grandRVal = 0;
  let grandDVal = 0;
  let grandEntries = 0;

  const rows = Array.from(map.values()).map((a) => {
    const lossPct = a.transferred_qty > 0 ? roundMoney((a.difference_qty / a.transferred_qty) * 100) : 0;
    grandEntries += a.entry_count;
    grandTQty += a.transferred_qty;
    grandRQty += a.received_qty;
    grandDQty += a.difference_qty;
    grandTVal += a.transferred_value;
    grandRVal += a.received_value;
    grandDVal += a.difference_value;
    return {
      branch_id: a.branch_id,
      branch_name: a.branch_name,
      branch_location: a.branch_location,
      entry_count: a.entry_count,
      doc_count: a.docs.size,
      transferred_qty: roundQty(a.transferred_qty),
      received_qty: roundQty(a.received_qty),
      difference_qty: roundQty(a.difference_qty),
      transferred_value: roundMoney(a.transferred_value),
      received_value: roundMoney(a.received_value),
      difference_value: roundMoney(a.difference_value),
      loss_pct: lossPct,
      is_alert: Math.abs(lossPct) > threshold && a.entry_count > 0,
    };
  });

  res.json({
    startDate,
    endDate,
    alertThresholdPct: threshold,
    rows,
    grandTotal: {
      entry_count: grandEntries,
      transferred_qty: roundQty(grandTQty),
      received_qty: roundQty(grandRQty),
      difference_qty: roundQty(grandDQty),
      transferred_value: roundMoney(grandTVal),
      received_value: roundMoney(grandRVal),
      difference_value: roundMoney(grandDVal),
      loss_pct: grandTQty > 0 ? roundMoney((grandDQty / grandTQty) * 100) : 0,
    },
  });
});

receivingRouter.get('/reports/monthly', requireAuth, (req: AuthenticatedRequest, res) => {
  const month = String(req.query.month || getTodayDateString().slice(0, 7));
  if (!/^\d{4}-\d{2}$/.test(month)) {
    res.status(400).json({ error: 'Invalid month format (expected YYYY-MM).' });
    return;
  }

  const startDate = req.query.startDate ? String(req.query.startDate) : `${month}-01`;
  const endDate = req.query.endDate ? String(req.query.endDate) : `${month}-31`;
  let branchId = req.query.branchId ? Number(req.query.branchId) : null;
  if (req.user!.role === 'branch') {
    if (!req.user!.branch_id) {
      res.status(403).json({ error: 'No branch assigned to your account.' });
      return;
    }
    branchId = req.user!.branch_id;
  }
  const productId = req.query.productId ? Number(req.query.productId) : null;
  const reasonId = req.query.reasonId ? Number(req.query.reasonId) : null;

  const entries = fetchReceivingEntries({
    startDate,
    endDate,
    branchId,
    productId,
    reasonId,
  });

  const threshold = getAlertThreshold();
  const byBranchMap = new Map<number, any>();
  const byProductMap = new Map<number, any>();
  const byReasonMap = new Map<string, any>();
  const byDayMap = new Map<string, any>();

  let totalTQty = 0;
  let totalRQty = 0;
  let totalDQty = 0;
  let totalTVal = 0;
  let totalRVal = 0;
  let totalDVal = 0;

  for (const e of entries) {
    totalTQty += e.transferred_qty;
    totalRQty += e.received_qty;
    totalDQty += e.difference_qty;
    totalTVal += e.transferred_value;
    totalRVal += e.received_value;
    totalDVal += e.difference_value;

    // By branch
    const bItem = byBranchMap.get(e.branch_id) || {
      branch_id: e.branch_id,
      branch_name: e.branch_name,
      entry_count: 0,
      transferred_qty: 0,
      received_qty: 0,
      difference_qty: 0,
      transferred_value: 0,
      received_value: 0,
      difference_value: 0,
    };
    bItem.entry_count += 1;
    bItem.transferred_qty += e.transferred_qty;
    bItem.received_qty += e.received_qty;
    bItem.difference_qty += e.difference_qty;
    bItem.transferred_value += e.transferred_value;
    bItem.received_value += e.received_value;
    bItem.difference_value += e.difference_value;
    byBranchMap.set(e.branch_id, bItem);

    // By product
    const pItem = byProductMap.get(e.product_id) || {
      product_id: e.product_id,
      barcode: e.barcode_snapshot,
      product_name: e.product_name_snapshot,
      unit: e.unit_snapshot,
      entry_count: 0,
      transferred_qty: 0,
      received_qty: 0,
      difference_qty: 0,
      transferred_value: 0,
      received_value: 0,
      difference_value: 0,
    };
    pItem.entry_count += 1;
    pItem.transferred_qty += e.transferred_qty;
    pItem.received_qty += e.received_qty;
    pItem.difference_qty += e.difference_qty;
    pItem.transferred_value += e.transferred_value;
    pItem.received_value += e.received_value;
    pItem.difference_value += e.difference_value;
    byProductMap.set(e.product_id, pItem);

    // By reason (only variances or 'Matched' bucket)
    const rKey = e.reason_id ? String(e.reason_id) : 'MATCHED';
    const rItem = byReasonMap.get(rKey) || {
      reason_id: e.reason_id,
      reason_name: e.reason_name || 'Exact Match (No Variance)',
      entry_count: 0,
      transferred_qty: 0,
      received_qty: 0,
      difference_qty: 0,
      difference_value: 0,
    };
    rItem.entry_count += 1;
    rItem.transferred_qty += e.transferred_qty;
    rItem.received_qty += e.received_qty;
    rItem.difference_qty += e.difference_qty;
    rItem.difference_value += e.difference_value;
    byReasonMap.set(rKey, rItem);

    // By day
    const dItem = byDayMap.get(e.entry_date) || {
      entry_date: e.entry_date,
      entry_count: 0,
      transferred_qty: 0,
      received_qty: 0,
      difference_qty: 0,
      transferred_value: 0,
      received_value: 0,
      difference_value: 0,
    };
    dItem.entry_count += 1;
    dItem.transferred_qty += e.transferred_qty;
    dItem.received_qty += e.received_qty;
    dItem.difference_qty += e.difference_qty;
    dItem.transferred_value += e.transferred_value;
    dItem.received_value += e.received_value;
    dItem.difference_value += e.difference_value;
    byDayMap.set(e.entry_date, dItem);
  }

  const finalize = (arr: any[]) =>
    arr.map((row) => {
      const lossPct = row.transferred_qty > 0 ? roundMoney((row.difference_qty / row.transferred_qty) * 100) : 0;
      return {
        ...row,
        transferred_qty: roundQty(row.transferred_qty),
        received_qty: roundQty(row.received_qty),
        difference_qty: roundQty(row.difference_qty),
        transferred_value: row.transferred_value !== undefined ? roundMoney(row.transferred_value) : undefined,
        received_value: row.received_value !== undefined ? roundMoney(row.received_value) : undefined,
        difference_value: roundMoney(row.difference_value),
        loss_pct: lossPct,
        is_alert: Math.abs(lossPct) > threshold,
      };
    });

  res.json({
    month,
    startDate,
    endDate,
    alertThresholdPct: threshold,
    byBranch: finalize(Array.from(byBranchMap.values())).sort((a, b) => b.difference_value - a.difference_value),
    byProduct: finalize(Array.from(byProductMap.values())).sort((a, b) => b.difference_value - a.difference_value),
    byReason: finalize(Array.from(byReasonMap.values())).sort((a, b) => b.entry_count - a.entry_count),
    byDay: finalize(Array.from(byDayMap.values())).sort((a, b) => a.entry_date.localeCompare(b.entry_date)),
    totals: {
      entryCount: entries.length,
      transferredQty: roundQty(totalTQty),
      receivedQty: roundQty(totalRQty),
      differenceQty: roundQty(totalDQty),
      transferredValue: roundMoney(totalTVal),
      receivedValue: roundMoney(totalRVal),
      differenceValue: roundMoney(totalDVal),
      lossPct: totalTQty > 0 ? roundMoney((totalDQty / totalTQty) * 100) : 0,
    },
  });
});
