import crypto from 'crypto';
import { Router } from 'express';
import {
  AuthenticatedRequest,
  LOCKOUT_DURATION_MINUTES,
  MAX_FAILED_LOGIN_ATTEMPTS,
  RESET_TOKEN_TTL_MINUTES,
  clearSessionCookie,
  createSession,
  deleteSession,
  deleteUserSessions,
  hashPassword,
  hashResetToken,
  loadUserById,
  parseSessionCookie,
  requireAuth,
  setSessionCookie,
  validatePasswordPolicy,
  verifyConstantTime,
  verifyPassword,
} from '../auth';
import { db, getTodayDateString, logAudit } from '../db';

export const authRouter = Router();

interface LoginDbRow {
  id: number;
  username: string;
  password_hash: string | null;
  active: number;
  role: string;
  failed_login_attempts: number;
  locked_until: string | null;
  must_change_password: number;
}

function isAccountLocked(row: { locked_until: string | null }): { locked: boolean; minutesRemaining: number } {
  if (!row.locked_until) return { locked: false, minutesRemaining: 0 };
  const lockMs = Date.parse(row.locked_until);
  if (!Number.isFinite(lockMs)) return { locked: false, minutesRemaining: 0 };
  const diffMs = lockMs - Date.now();
  if (diffMs <= 0) return { locked: false, minutesRemaining: 0 };
  return { locked: true, minutesRemaining: Math.max(1, Math.ceil(diffMs / 60000)) };
}

function recordFailedLogin(userRow: LoginDbRow, contextNote: string): { lockedNow: boolean; attemptsLeft: number } {
  const currentLocked = isAccountLocked(userRow);
  const nextAttempts = currentLocked.locked ? MAX_FAILED_LOGIN_ATTEMPTS : (userRow.failed_login_attempts || 0) + 1;
  if (nextAttempts >= MAX_FAILED_LOGIN_ATTEMPTS) {
    const lockedUntil = new Date(Date.now() + LOCKOUT_DURATION_MINUTES * 60 * 1000).toISOString();
    db.prepare(
      "UPDATE users SET failed_login_attempts = ?, locked_until = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(nextAttempts, lockedUntil, userRow.id);

    logAudit({
      userId: userRow.id,
      username: userRow.username,
      action: 'LOGIN_LOCKED',
      entityType: 'user',
      entityId: userRow.id,
      note: `Account locked for ${LOCKOUT_DURATION_MINUTES} minutes after ${nextAttempts} failed attempts (${contextNote})`,
    });
    return { lockedNow: true, attemptsLeft: 0 };
  }

  db.prepare("UPDATE users SET failed_login_attempts = ?, updated_at = datetime('now') WHERE id = ?").run(
    nextAttempts,
    userRow.id
  );
  logAudit({
    userId: userRow.id,
    username: userRow.username,
    action: 'LOGIN_FAILED',
    entityType: 'user',
    entityId: userRow.id,
    note: `Failed login attempt ${nextAttempts} of ${MAX_FAILED_LOGIN_ATTEMPTS} (${contextNote})`,
  });
  return { lockedNow: false, attemptsLeft: MAX_FAILED_LOGIN_ATTEMPTS - nextAttempts };
}

authRouter.get('/status', (_req, res) => {
  const hasEnvAdmin = Boolean(process.env.ADMIN_INITIAL_PASSWORD && process.env.ADMIN_INITIAL_PASSWORD.trim().length > 0);
  const adminRow = db
    .prepare("SELECT id, password_hash FROM users WHERE username = 'admin'")
    .get() as { id: number; password_hash: string | null } | undefined;

  const needsAdminSetup = !hasEnvAdmin && (!adminRow || !adminRow.password_hash);
  res.json({ needsAdminSetup, hasEnvAdmin });
});

authRouter.post('/setup-admin', (req, res) => {
  const hasEnvAdmin = Boolean(process.env.ADMIN_INITIAL_PASSWORD && process.env.ADMIN_INITIAL_PASSWORD.trim().length > 0);
  if (hasEnvAdmin) {
    res.status(409).json({ error: 'Admin password is configured via environment settings.' });
    return;
  }

  const { password, full_name } = req.body as { password?: string; full_name?: string };
  const pwCheck = validatePasswordPolicy(password);
  if (!pwCheck.valid || !password) {
    res.status(400).json({ error: pwCheck.error || 'Invalid password.' });
    return;
  }

  const setupTx = db.transaction(() => {
    const adminRow = db
      .prepare("SELECT id, password_hash FROM users WHERE username = 'admin'")
      .get() as { id: number; password_hash: string | null } | undefined;

    if (adminRow && adminRow.password_hash) {
      return null;
    }

    const hash = hashPassword(password);
    const displayName = full_name && full_name.trim() ? full_name.trim() : 'Head Office Administrator';
    const nowIso = new Date().toISOString();

    if (adminRow) {
      db.prepare(
        "UPDATE users SET password_hash = ?, full_name = ?, must_change_password = 0, last_login_at = ?, active = 1, updated_at = datetime('now') WHERE id = ?"
      ).run(hash, displayName, nowIso, adminRow.id);
      return adminRow.id;
    } else {
      const info = db
        .prepare(
          "INSERT INTO users (username, full_name, password_hash, role, branch_id, must_change_password, last_login_at, active) VALUES ('admin', ?, ?, 'admin', NULL, 0, ?, 1)"
        )
        .run(displayName, hash, nowIso);
      return Number(info.lastInsertRowid);
    }
  });

  const adminId = setupTx();
  if (!adminId) {
    res.status(409).json({ error: 'Admin account has already been claimed.' });
    return;
  }

  logAudit({
    userId: adminId,
    username: 'admin',
    action: 'SETUP_ADMIN',
    entityType: 'user',
    entityId: adminId,
    note: 'Initial Head Office Admin password claimed',
  });

  const user = loadUserById(adminId);
  const sessionId = createSession(adminId, true);
  setSessionCookie(req, res, sessionId, true);
  res.json({
    token: sessionId,
    user: user ? { ...user, remember_me: true } : null,
    server_today: getTodayDateString(),
  });
});

authRouter.post('/login', (req, res) => {
  const { username, password, rememberMe } = req.body as {
    username?: string;
    password?: string;
    rememberMe?: boolean;
  };
  if (!username || !password || typeof username !== 'string' || typeof password !== 'string') {
    res.status(400).json({ error: 'Username (or email) and password are required.' });
    return;
  }

  const cleanIdentifier = username.trim();
  const userRow = db
    .prepare(
      `SELECT id, username, password_hash, active, role, failed_login_attempts, locked_until, must_change_password
       FROM users
       WHERE LOWER(username) = LOWER(?) OR (email != '' AND LOWER(email) = LOWER(?))
       ORDER BY id ASC
       LIMIT 1`
    )
    .get(cleanIdentifier, cleanIdentifier) as LoginDbRow | undefined;

  if (!userRow) {
    res.status(401).json({ error: 'Invalid username or password.' });
    return;
  }

  if (userRow.active !== 1) {
    logAudit({
      userId: userRow.id,
      username: userRow.username,
      action: 'LOGIN_FAILED',
      entityType: 'user',
      entityId: userRow.id,
      note: 'Deactivated account attempted sign in',
    });
    res.status(403).json({ error: 'This account has been deactivated. Contact Head Office Admin.' });
    return;
  }

  const lockState = isAccountLocked(userRow);
  if (lockState.locked) {
    res.status(423).json({
      error: `Account temporarily locked due to repeated failed sign-in attempts. Try again in ${lockState.minutesRemaining} minute(s), or ask Head Office Admin to reset your password.`,
    });
    return;
  }

  const envAdminPass = process.env.ADMIN_INITIAL_PASSWORD?.trim();
  let valid = false;

  if (userRow.username === 'admin' && envAdminPass) {
    valid = verifyConstantTime(password, envAdminPass);
  } else if (userRow.password_hash) {
    valid = verifyPassword(password, userRow.password_hash);
  } else {
    res.status(403).json({
      error: 'No password has been issued for this account yet. Ask Head Office Admin to issue a temporary password.',
    });
    return;
  }

  if (!valid) {
    const outcome = recordFailedLogin(userRow, 'sign-in');
    if (outcome.lockedNow) {
      res.status(423).json({
        error: `Account locked for ${LOCKOUT_DURATION_MINUTES} minutes after ${MAX_FAILED_LOGIN_ATTEMPTS} failed sign-in attempts.`,
      });
      return;
    }
    res.status(401).json({
      error: `Invalid username or password. ${outcome.attemptsLeft} attempt(s) remaining before 15-minute lockout.`,
    });
    return;
  }

  const nowIso = new Date().toISOString();
  db.prepare(
    "UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = ?, updated_at = datetime('now') WHERE id = ?"
  ).run(nowIso, userRow.id);

  const persistSession = Boolean(rememberMe);
  const sessionId = createSession(userRow.id, persistSession);
  setSessionCookie(req, res, sessionId, persistSession);

  logAudit({
    userId: userRow.id,
    username: userRow.username,
    action: 'LOGIN_SUCCESS',
    entityType: 'user',
    entityId: userRow.id,
    note: persistSession ? 'Signed in (Remember Me: 30 days)' : 'Signed in (Session + 30-min inactivity lock)',
  });

  const user = loadUserById(userRow.id);
  res.json({
    token: sessionId,
    user: user ? { ...user, remember_me: persistSession } : null,
    server_today: getTodayDateString(),
  });
});

authRouter.post('/logout', (req: AuthenticatedRequest, res) => {
  const header = req.headers.authorization;
  const bearerToken = header && header.startsWith('Bearer ') ? header.slice('Bearer '.length).trim() : null;
  const cookieToken = parseSessionCookie(req);
  const sessionId = bearerToken || cookieToken;

  if (sessionId) {
    const sess = db.prepare('SELECT user_id FROM sessions WHERE id = ?').get(sessionId) as
      | { user_id: number }
      | undefined;
    if (sess) {
      const u = loadUserById(sess.user_id);
      if (u) {
        logAudit({
          userId: u.id,
          username: u.username,
          action: 'LOGOUT',
          entityType: 'user',
          entityId: u.id,
          note: 'User signed out',
        });
      }
    }
    deleteSession(sessionId);
  }
  clearSessionCookie(req, res);
  res.json({ ok: true });
});

authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ user: req.user, server_today: getTodayDateString() });
});

authRouter.post('/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
  const { currentPassword, newPassword } = req.body as { currentPassword?: string; newPassword?: string };
  if (typeof currentPassword !== 'string' || !currentPassword) {
    res.status(400).json({ error: 'Current password is required.' });
    return;
  }

  const pwCheck = validatePasswordPolicy(newPassword);
  if (!pwCheck.valid || !newPassword) {
    res.status(400).json({ error: pwCheck.error || 'Invalid new password.' });
    return;
  }
  if (currentPassword === newPassword) {
    res.status(400).json({ error: 'New password must be different from your current password.' });
    return;
  }

  const envAdminPass = process.env.ADMIN_INITIAL_PASSWORD?.trim();
  if (req.user!.username === 'admin' && envAdminPass) {
    res.status(400).json({ error: 'Admin password is controlled via environment settings (ADMIN_INITIAL_PASSWORD).' });
    return;
  }

  const row = db
    .prepare('SELECT id, username, password_hash FROM users WHERE id = ?')
    .get(req.user!.id) as { id: number; username: string; password_hash: string | null } | undefined;

  if (!row || !row.password_hash || !verifyPassword(currentPassword, row.password_hash)) {
    res.status(400).json({ error: 'Current password is incorrect.' });
    return;
  }

  const newHash = hashPassword(newPassword);
  db.transaction(() => {
    db.prepare(
      "UPDATE users SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?"
    ).run(newHash, row.id);
    db.prepare(
      "UPDATE password_reset_requests SET status = 'resolved', resolved_by = ?, resolved_at = datetime('now') WHERE user_id = ? AND status = 'pending'"
    ).run(req.user!.id, row.id);
    db.prepare("UPDATE password_reset_tokens SET used_at = datetime('now') WHERE user_id = ? AND used_at IS NULL").run(
      row.id
    );
  })();

  logAudit({
    userId: req.user!.id,
    username: req.user!.username,
    action: 'CHANGE_PASSWORD',
    entityType: 'user',
    entityId: row.id,
    note: req.user!.must_change_password ? 'User changed required temporary password' : 'User updated own password',
  });

  const updatedUser = loadUserById(row.id);
  res.json({
    ok: true,
    user: updatedUser ? { ...updatedUser, remember_me: req.user!.remember_me } : req.user,
  });
});

authRouter.post('/change-password-login', (req, res) => {
  const { username, currentPassword, newPassword } = req.body as {
    username?: string;
    currentPassword?: string;
    newPassword?: string;
  };

  if (
    typeof username !== 'string' ||
    typeof currentPassword !== 'string' ||
    !username.trim() ||
    !currentPassword
  ) {
    res.status(400).json({ error: 'Username (or email) and current password are required.' });
    return;
  }

  const pwCheck = validatePasswordPolicy(newPassword);
  if (!pwCheck.valid || !newPassword) {
    res.status(400).json({ error: pwCheck.error || 'Invalid new password.' });
    return;
  }
  if (currentPassword === newPassword) {
    res.status(400).json({ error: 'New password must be different from your current password.' });
    return;
  }

  const cleanIdentifier = username.trim();
  const envAdminPass = process.env.ADMIN_INITIAL_PASSWORD?.trim();
  if (cleanIdentifier.toLowerCase() === 'admin' && envAdminPass) {
    res.status(400).json({ error: 'Admin password is controlled via environment settings (ADMIN_INITIAL_PASSWORD).' });
    return;
  }

  const row = db
    .prepare(
      `SELECT id, username, password_hash, active, role, failed_login_attempts, locked_until, must_change_password
       FROM users
       WHERE LOWER(username) = LOWER(?) OR (email != '' AND LOWER(email) = LOWER(?))
       ORDER BY id ASC
       LIMIT 1`
    )
    .get(cleanIdentifier, cleanIdentifier) as LoginDbRow | undefined;

  if (!row) {
    res.status(401).json({ error: 'Invalid username or current password.' });
    return;
  }

  if (row.active !== 1) {
    res.status(403).json({ error: 'This account has been deactivated. Contact Head Office Admin.' });
    return;
  }

  const lockState = isAccountLocked(row);
  if (lockState.locked) {
    res.status(423).json({
      error: `Account temporarily locked. Try again in ${lockState.minutesRemaining} minute(s).`,
    });
    return;
  }

  if (!row.password_hash || !verifyPassword(currentPassword, row.password_hash)) {
    const outcome = recordFailedLogin(row, 'change-password-login');
    if (outcome.lockedNow) {
      res.status(423).json({
        error: `Account locked for ${LOCKOUT_DURATION_MINUTES} minutes after ${MAX_FAILED_LOGIN_ATTEMPTS} failed attempts.`,
      });
      return;
    }
    res.status(401).json({ error: 'Invalid username or current password.' });
    return;
  }

  const newHash = hashPassword(newPassword);
  db.transaction(() => {
    db.prepare(
      "UPDATE users SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?"
    ).run(newHash, row.id);
    db.prepare(
      "UPDATE password_reset_requests SET status = 'resolved', resolved_by = ?, resolved_at = datetime('now') WHERE user_id = ? AND status = 'pending'"
    ).run(row.id, row.id);
    db.prepare("UPDATE password_reset_tokens SET used_at = datetime('now') WHERE user_id = ? AND used_at IS NULL").run(
      row.id
    );
  })();
  deleteUserSessions(row.id);

  logAudit({
    userId: row.id,
    username: row.username,
    action: 'CHANGE_PASSWORD',
    entityType: 'user',
    entityId: row.id,
    note: 'User changed password from sign-in screen',
  });

  res.json({ ok: true });
});

authRouter.post('/forgot-password', (req, res) => {
  const { username, identifier, note } = req.body as { username?: string; identifier?: string; note?: string };
  const rawId = typeof identifier === 'string' && identifier.trim() ? identifier : username;
  if (typeof rawId !== 'string' || !rawId.trim()) {
    res.status(400).json({ error: 'Username or registered email is required.' });
    return;
  }

  const cleanIdentifier = rawId.trim().slice(0, 120);
  const cleanNote = typeof note === 'string' ? note.trim().slice(0, 250) : '';

  const userRow = db
    .prepare(
      `SELECT id, username, active
       FROM users
       WHERE LOWER(username) = LOWER(?) OR (email != '' AND LOWER(email) = LOWER(?))
       ORDER BY id ASC
       LIMIT 1`
    )
    .get(cleanIdentifier, cleanIdentifier) as { id: number; username: string; active: number } | undefined;

  if (userRow && userRow.active === 1) {
    const recentPending = db
      .prepare(
        "SELECT id FROM password_reset_requests WHERE user_id = ? AND status = 'pending' AND requested_at >= datetime('now', '-10 minutes')"
      )
      .get(userRow.id) as { id: number } | undefined;

    if (!recentPending) {
      const info = db
        .prepare("INSERT INTO password_reset_requests (user_id, username, note, status) VALUES (?, ?, ?, 'pending')")
        .run(userRow.id, userRow.username, cleanNote);

      const rawToken = crypto.randomBytes(24).toString('hex');
      const tokenHash = hashResetToken(rawToken);
      const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000).toISOString();
      db.prepare('INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)').run(
        userRow.id,
        tokenHash,
        expiresAt
      );

      logAudit({
        userId: userRow.id,
        username: userRow.username,
        action: 'FORGOT_PASSWORD_REQUEST',
        entityType: 'password_reset_request',
        entityId: Number(info.lastInsertRowid),
        note: cleanNote ? `Reset requested: ${cleanNote}` : 'Password reset requested from sign-in screen',
      });
    }
  }

  // Never disclose account existence; clearly explain manual Head Office path since email sending is unavailable
  res.json({
    ok: true,
    message:
      'Your reset request has been logged. Automated email delivery is not configured in this deployment — please contact Head Office Admin to receive a temporary password or one-time 30-minute reset link.',
  });
});

authRouter.get('/reset-token/:token', (req, res) => {
  const token = String(req.params.token || '').trim();
  if (!token) {
    res.status(400).json({ error: 'Reset link token is missing.' });
    return;
  }

  const tokenHash = hashResetToken(token);
  const row = db
    .prepare(
      `SELECT prt.id, prt.expires_at, prt.used_at, u.username, u.full_name, u.active
       FROM password_reset_tokens prt
       JOIN users u ON u.id = prt.user_id
       WHERE prt.token_hash = ?`
    )
    .get(tokenHash) as
    | { id: number; expires_at: string; used_at: string | null; username: string; full_name: string; active: number }
    | undefined;

  if (!row || row.used_at || row.active !== 1 || Date.now() > Date.parse(row.expires_at)) {
    res.status(400).json({ error: 'This reset link is invalid, already used, or has expired (30-minute limit).' });
    return;
  }

  res.json({ valid: true, username: row.username, full_name: row.full_name });
});

authRouter.post('/reset-token', (req, res) => {
  const { token, newPassword } = req.body as { token?: string; newPassword?: string };
  if (typeof token !== 'string' || !token.trim()) {
    res.status(400).json({ error: 'Reset token is required.' });
    return;
  }

  const pwCheck = validatePasswordPolicy(newPassword);
  if (!pwCheck.valid || !newPassword) {
    res.status(400).json({ error: pwCheck.error || 'Invalid password.' });
    return;
  }

  const tokenHash = hashResetToken(token.trim());
  const row = db
    .prepare(
      `SELECT prt.id, prt.user_id, prt.expires_at, prt.used_at, u.username, u.active
       FROM password_reset_tokens prt
       JOIN users u ON u.id = prt.user_id
       WHERE prt.token_hash = ?`
    )
    .get(tokenHash) as
    | { id: number; user_id: number; expires_at: string; used_at: string | null; username: string; active: number }
    | undefined;

  if (!row || row.used_at || row.active !== 1 || Date.now() > Date.parse(row.expires_at)) {
    res.status(400).json({ error: 'This reset link is invalid, already used, or has expired (30-minute limit).' });
    return;
  }

  const newHash = hashPassword(newPassword);
  db.transaction(() => {
    db.prepare(
      "UPDATE users SET password_hash = ?, must_change_password = 0, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?"
    ).run(newHash, row.user_id);
    db.prepare("UPDATE password_reset_tokens SET used_at = datetime('now') WHERE id = ?").run(row.id);
    db.prepare(
      "UPDATE password_reset_requests SET status = 'resolved', resolved_by = ?, resolved_at = datetime('now') WHERE user_id = ? AND status = 'pending'"
    ).run(row.user_id, row.user_id);
  })();
  deleteUserSessions(row.user_id);

  logAudit({
    userId: row.user_id,
    username: row.username,
    action: 'PASSWORD_RESET_BY_LINK',
    entityType: 'user',
    entityId: row.user_id,
    note: 'Password reset completed via one-time 30-minute link',
  });

  res.json({ ok: true, username: row.username });
});
