AICA Level 2 Capstone Project - Batch AICA-L2B110
CA Anandita Kaur Anand (M.No. 511918)
Project: Partner Dashboard - Assignments & Billing

Contents:
1. Partner_Dashboard_Capstone_Report.docx - project report
2. Partner_Dashboard_App.html - the working app

How to run the app:
Double-click Partner_Dashboard_App.html. It opens in Chrome or Edge. No installation needed.
Sample data is pre-loaded. Use Settings to reload or clear data.
