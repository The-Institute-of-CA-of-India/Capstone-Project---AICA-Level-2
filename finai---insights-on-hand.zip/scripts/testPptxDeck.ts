import PptxGenJS from 'pptxgenjs';
import { METROPOLITAN_MALL_DATASET, SAMPLE_LEASING_DRIVERS, DEFAULT_UAE_ACCOUNT_MAPPINGS, SAMPLE_OPEN_QUESTIONS } from '../src/data/shoppingMallDataset';
import { computeFinancialEngine } from '../src/utils/financialEngine';
import { CORPORATE_THEME } from '../src/theme/themeConfig';

console.log('Testing PptxGenJS 6-Slide Generation & Validation Tests...');

// 1. Run Financial Engine on real dataset
const finData = computeFinancialEngine(
  METROPOLITAN_MALL_DATASET,
  'BUDGET',
  DEFAULT_UAE_ACCOUNT_MAPPINGS,
  { aedThreshold: 250000, pctThreshold: 5.0 },
  'AED',
  'MTD',
  SAMPLE_LEASING_DRIVERS
);

const { metrics, waterfallSteps, balanceSheetCheck, topAdverseDrivers, topFavourableDrivers, opexSubCategories } = finData;

console.log(`EBITDA Actual: AED ${metrics.ebitdaActual}`);
console.log(`EBITDA Benchmark: AED ${metrics.ebitdaBenchmark}`);
console.log(`EBITDA Variance: AED ${metrics.ebitdaVariance}`);

// Check 1: EBITDA bridge reconciles to exactly 0.00 AED
const revVar = metrics.revenueActual - metrics.revenueBenchmark;
const cogsVar = -(metrics.cogsActual - metrics.cogsBenchmark);
const opexVar = -(metrics.opexActual - metrics.opexBenchmark);
const bridgeTotal = metrics.ebitdaBenchmark + revVar + cogsVar + opexVar;
const bridgeDelta = Math.abs(bridgeTotal - metrics.ebitdaActual);
console.log(`Bridge Reconciled Total: ${bridgeTotal}, Diff: ${bridgeDelta} AED`);
if (bridgeDelta !== 0) {
  throw new Error(`TEST FAILED: Bridge delta is non-zero: ${bridgeDelta}`);
}

// Check 2: Leasing decomposition exact closure
const occDelta = (SAMPLE_LEASING_DRIVERS.occupancyPctActual - SAMPLE_LEASING_DRIVERS.occupancyPctBenchmark) / 100;
const rateB = SAMPLE_LEASING_DRIVERS.baseRentBenchmark / ((SAMPLE_LEASING_DRIVERS.occupancyPctBenchmark / 100) * SAMPLE_LEASING_DRIVERS.glaSqmBenchmark);
const occEffect = occDelta * SAMPLE_LEASING_DRIVERS.glaSqmBenchmark * rateB;
const glaEffect = (SAMPLE_LEASING_DRIVERS.glaSqmActual - SAMPLE_LEASING_DRIVERS.glaSqmBenchmark) * (SAMPLE_LEASING_DRIVERS.occupancyPctActual / 100) * rateB;
const rateA = SAMPLE_LEASING_DRIVERS.baseRentActual / ((SAMPLE_LEASING_DRIVERS.occupancyPctActual / 100) * SAMPLE_LEASING_DRIVERS.glaSqmActual);
const rateEffect = (rateA - rateB) * (SAMPLE_LEASING_DRIVERS.occupancyPctActual / 100) * SAMPLE_LEASING_DRIVERS.glaSqmActual;
const torEffect = SAMPLE_LEASING_DRIVERS.torActual - SAMPLE_LEASING_DRIVERS.torBenchmark;
const otherEffect = metrics.revenueVariance - (occEffect + glaEffect + rateEffect + torEffect);
const leasingSum = occEffect + glaEffect + rateEffect + torEffect + otherEffect;
const leasingDiff = Math.abs(leasingSum - metrics.revenueVariance);
console.log(`Leasing decomposition sum: ${leasingSum}, Net Rev Var: ${metrics.revenueVariance}, Diff: ${leasingDiff} AED`);
if (leasingDiff > 0.01) {
  throw new Error(`TEST FAILED: Leasing decomposition does not match Net Revenue Variance: ${leasingDiff}`);
}

// Check 3: Zero-crossing waterfall calculation
// Test function for stacked column waterfall with floating bars and zero-crossing
function computeWaterfallSeries(bars: { label: string; value: number; isTotal?: boolean }[]) {
  const labels: string[] = [];
  const baseValues: number[] = [];
  const increaseValues: number[] = [];
  const decreaseValues: number[] = [];
  const totalValues: number[] = [];

  let currentLevel = 0;

  bars.forEach((bar, idx) => {
    labels.push(bar.label);

    if (bar.isTotal) {
      // Total column: starts from 0 up to bar.value
      baseValues.push(0);
      increaseValues.push(0);
      decreaseValues.push(0);
      totalValues.push(bar.value);
      currentLevel = bar.value;
    } else {
      totalValues.push(0);
      const prev = currentLevel;
      const next = prev + bar.value;

      if (bar.value >= 0) {
        // Increase bar
        if (prev >= 0) {
          baseValues.push(prev);
          increaseValues.push(bar.value);
          decreaseValues.push(0);
        } else if (next >= 0) {
          // Crosses zero upward (prev < 0, next >= 0)
          baseValues.push(0);
          increaseValues.push(next);
          decreaseValues.push(Math.abs(prev));
        } else {
          // Stays negative (prev < 0, next < 0)
          baseValues.push(next);
          increaseValues.push(bar.value);
          decreaseValues.push(0);
        }
      } else {
        // Decrease bar (bar.value < 0)
        const absVal = Math.abs(bar.value);
        if (next >= 0) {
          baseValues.push(next);
          increaseValues.push(0);
          decreaseValues.push(absVal);
        } else if (prev >= 0) {
          // Crosses zero downward (prev >= 0, next < 0)
          baseValues.push(0);
          increaseValues.push(0);
          decreaseValues.push(prev + absVal);
        } else {
          // Stays negative
          baseValues.push(prev);
          increaseValues.push(0);
          decreaseValues.push(absVal);
        }
      }
      currentLevel = next;
    }
  });

  return { labels, baseValues, increaseValues, decreaseValues, totalValues };
}

// Test zero-crossing scenario
const zeroCrossingBars = [
  { label: 'Start', value: 2.0, isTotal: true },
  { label: 'Step 1 (Drop across 0)', value: -5.0 }, // 2.0 -> -3.0 (crosses 0)
  { label: 'Step 2 (Climb across 0)', value: 4.0 },  // -3.0 -> +1.0 (crosses 0)
  { label: 'Final Total', value: 1.0, isTotal: true },
];
const zeroResult = computeWaterfallSeries(zeroCrossingBars);
console.log('Zero-crossing test computed series successfully:', zeroResult);

// Check 4: Block export on failed tie-out
function verifyTieOutBeforeExport(actualFromMetrics: number, actualFromBridge: number) {
  const diff = Math.abs(actualFromMetrics - actualFromBridge);
  if (diff > 0.001) {
    throw new Error(`Export blocked: EBITDA bridge discrepancy of AED ${diff.toFixed(2)} detected. Benchmark to actual bridge does not tie out to 0 fils.`);
  }
  return true;
}

try {
  verifyTieOutBeforeExport(metrics.ebitdaActual, bridgeTotal);
  console.log('Valid tie-out check passed successfully.');
} catch (e: any) {
  throw new Error(`TEST FAILED: Valid tie-out check unexpectedly threw: ${e.message}`);
}

let blockedCaught = false;
try {
  verifyTieOutBeforeExport(metrics.ebitdaActual, bridgeTotal + 1000);
} catch (e: any) {
  blockedCaught = true;
  console.log('Simulated tie-out discrepancy blocked export as required:', e.message);
}
if (!blockedCaught) {
  throw new Error('TEST FAILED: Export was not blocked when discrepancy was introduced');
}

// 5. Test PptxGenJS generation of all 6 slides in Node
async function testDeckGeneration() {
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_16x9';

  // Slide 1: Executive Summary
  const s1 = pptx.addSlide();
  s1.addText('EBITDA AED 26.8M, AED 3.1M below budget, driven by retail vacancy', {
    x: 0.8, y: 0.4, w: 11.5, h: 0.5, fontSize: 16, bold: true, color: '0F172A'
  });
  s1.addNotes('Talking points: 1) Executive summary. [Sources] Engine: computeFinancialEngine (financialEngine.ts)');

  // Slide 2: EBITDA Bridge Stacked Column
  const s2 = pptx.addSlide();
  const bridgeBars = [
    { label: 'Budget EBITDA', value: 29.85, isTotal: true },
    { label: 'Occupancy', value: -0.72 },
    { label: 'GLA', value: 0.0 },
    { label: 'Rate', value: -0.28 },
    { label: 'TOR', value: -0.90 },
    { label: 'Other Rev', value: 0.15 },
    { label: 'Direct Costs', value: -0.20 },
    { label: 'OPEX', value: -1.05 },
    { label: 'Actual EBITDA', value: 26.85, isTotal: true },
  ];
  const wf = computeWaterfallSeries(bridgeBars);
  const chartData = [
    { name: 'Base', labels: wf.labels, values: wf.baseValues },
    { name: 'Favourable', labels: wf.labels, values: wf.increaseValues },
    { name: 'Adverse', labels: wf.labels, values: wf.decreaseValues },
    { name: 'Total', labels: wf.labels, values: wf.totalValues },
  ];
  s2.addChart(pptx.ChartType.bar, chartData, {
    x: 0.8, y: 1.2, w: 11.73, h: 5.2,
    barDir: 'col',
    barGrouping: 'stacked',
    chartColors: ['FFFFFF', '10B981', 'EF4444', '0F172A'],
    showValue: true,
  });

  // Slide 3: Revenue Drivers Tree + TOR Bar Chart
  const s3 = pptx.addSlide();
  s3.addShape(pptx.ShapeType.roundRect, { x: 0.8, y: 1.5, w: 5.0, h: 1.0, fill: { color: 'F1F5F9' } });
  s3.addText('Occupied GLA: 117,750 sqm (▼ -1.9%)', { x: 0.9, y: 1.6, w: 4.8, h: 0.8, fontSize: 11 });
  s3.addChart(pptx.ChartType.bar, [
    { name: 'TOR Variance (AED M)', labels: ['Fashion', 'Jewellery', 'Electronics', 'Dept Stores', 'F&B'], values: [-0.42, -0.28, -0.12, -0.08, 0.02] }
  ], {
    x: 6.2, y: 1.5, w: 6.3, h: 5.0,
    barDir: 'col',
    chartColors: ['EF4444'],
    showValue: true,
  });

  // Slide 4: Cost & Margin Horizontal Bar Chart
  const s4 = pptx.addSlide();
  s4.addChart(pptx.ChartType.bar, [
    { name: 'OPEX Variance (AED k)', labels: ['Utilities [Contr]', 'Events [Contr]', 'Media [Contr]', 'Insurance [Struct]', 'Legal [Contr]'], values: [620, 280, 240, 110, -230] }
  ], {
    x: 0.8, y: 2.2, w: 11.73, h: 4.5,
    barDir: 'bar',
    chartColors: ['334155'],
    showValue: true,
  });

  // Slide 5: Risks & Opportunities Table + Outlook
  const s5 = pptx.addSlide();
  s5.addTable([
    [{ text: 'Risk / Opportunity' }, { text: 'Impact (AED M)' }, { text: 'Prob' }, { text: 'Owner' }],
    [{ text: 'Chilled Water Tariff Escalation' }, { text: '-0.4' }, { text: 'High' }, { text: 'VP Ops' }],
    [{ text: 'Tenant Sub-Metering Recovery' }, { text: '+0.3' }, { text: 'High' }, { text: 'VP Ops' }],
    [{ text: 'Net Exposure' }, { text: '-0.1' }, { text: '—' }, { text: 'Calculated' }],
  ], {
    x: 0.8, y: 1.5, w: 7.0, h: 3.0,
    border: { pt: 0.5, color: 'E2E8F0' },
  });

  // Slide 6: Decisions & Action Tracker Table
  const s6 = pptx.addSlide();
  s6.addTable([
    [{ text: 'Ref' }, { text: 'Action Item' }, { text: 'Owner' }, { text: 'Due Date' }, { text: 'Status' }],
    [{ text: 'Q-01' }, { text: 'Chilled Water Sub-Metering Recovery' }, { text: 'VP Ops' }, { text: '2026-11-15' }, { text: '✓ On track' }],
    [{ text: 'Q-02' }, { text: 'Retail Turnover Category Audit' }, { text: 'Head Leasing' }, { text: '2026-11-20' }, { text: '! At risk' }],
  ], {
    x: 0.8, y: 3.5, w: 11.73, h: 2.8,
    border: { pt: 0.5, color: 'E2E8F0' },
  });

  // Generate buffer
  const buffer = await pptx.write({ outputType: 'nodebuffer' });
  console.log(`Generated test presentation successfully. Size: ${(buffer as Buffer).length} bytes`);
}

await testDeckGeneration();
console.log('DECK GENERATION TEST COMPLETE!');
