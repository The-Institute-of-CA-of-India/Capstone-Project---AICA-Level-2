import fs from 'fs';
import PptxGenJS from 'pptxgenjs';
import JSZip from 'jszip';
import { METROPOLITAN_MALL_DATASET, SAMPLE_LEASING_DRIVERS, DEFAULT_UAE_ACCOUNT_MAPPINGS, SAMPLE_OPEN_QUESTIONS } from '../src/data/shoppingMallDataset';
import { computeFinancialEngine } from '../src/utils/financialEngine';
import { CORPORATE_THEME } from '../src/theme/themeConfig';
import { sanitizePptxBlob } from '../src/utils/exportEngine';

async function testFullDeckOOXMLIntegrity() {
  console.log('Testing full 6-slide PPTX deck OOXML integrity...');

  const finData = computeFinancialEngine(
    METROPOLITAN_MALL_DATASET,
    'BUDGET',
    DEFAULT_UAE_ACCOUNT_MAPPINGS,
    { aedThreshold: 250000, pctThreshold: 5.0 },
    'AED',
    'MTD',
    SAMPLE_LEASING_DRIVERS
  );

  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_16x9';

  // Build the 6 slides exactly as in exportToPowerPoint
  // Slide 1: Exec Summary
  const s1 = pptx.addSlide();
  s1.addText('Executive Summary Test', { x: 1, y: 1, fontSize: 18 });

  // Slide 2: Waterfall
  const s2 = pptx.addSlide();
  s2.addChart(pptx.ChartType.bar, [
    { name: 'Base', labels: ['Bmk', 'Rev', 'COGS', 'OPEX', 'Act'], values: [30, 28, 25, 23, 27] },
    { name: 'Inc', labels: ['Bmk', 'Rev', 'COGS', 'OPEX', 'Act'], values: [0, 2, 0, 4, 0] },
    { name: 'Dec', labels: ['Bmk', 'Rev', 'COGS', 'OPEX', 'Act'], values: [0, 0, 3, 0, 0] },
  ], {
    barDir: 'col',
    barGrouping: 'stacked',
    chartColors: ['FFFFFF', '10B981', 'EF4444'],
    showValue: true,
  });

  // Slide 3: TOR Bar Chart
  const s3 = pptx.addSlide();
  s3.addChart(pptx.ChartType.bar, [
    { name: 'TOR Variance', labels: ['Fashion', 'Jewellery', 'Electronics'], values: [-0.4, -0.2, 0.1] }
  ], {
    barDir: 'bar',
    chartColors: ['EF4444'],
    showValue: true,
  });

  // Slide 4: OPEX Horizontal Bar Chart
  const s4 = pptx.addSlide();
  s4.addChart(pptx.ChartType.bar, [
    { name: 'OPEX Variance', labels: ['Utilities', 'Promotions', 'Cleaning'], values: [0.6, 0.3, -0.2] }
  ], {
    barDir: 'bar',
    chartColors: ['334155'],
    showValue: true,
  });

  // Slide 5: Risks Table
  const s5 = pptx.addSlide();
  s5.addTable([
    [{ text: 'Risk' }, { text: 'Impact' }],
    [{ text: 'Tariff' }, { text: '-0.4' }]
  ]);

  // Slide 6: Decisions Table
  const s6 = pptx.addSlide();
  s6.addTable([
    [{ text: 'Decision' }, { text: 'Status' }],
    [{ text: 'Ratify submetering' }, { text: '✓ On track' }]
  ]);

  // Write raw buffer
  const rawBuffer = (await pptx.write({ outputType: 'nodebuffer' })) as Buffer;
  console.log(`Raw presentation generated: ${rawBuffer.length} bytes`);

  // Sanitize via sanitizePptxBlob
  const sanitizedBlob = await sanitizePptxBlob(rawBuffer);
  const arrayBuf = await sanitizedBlob.arrayBuffer();
  const sanitizedBuffer = Buffer.from(arrayBuf);
  console.log(`Sanitized presentation generated: ${sanitizedBuffer.length} bytes`);

  // Verify internal XML structure
  const zip = await JSZip.loadAsync(sanitizedBuffer);
  let chartCount = 0;
  let allAxesValid = true;

  for (const filename of Object.keys(zip.files)) {
    if (filename.startsWith('ppt/charts/chart') && filename.endsWith('.xml')) {
      chartCount++;
      const xml = await zip.files[filename].async('string');

      // Check defined axes
      const definedAxes = new Set<string>();
      const axisRegex = /<c:(?:catAx|valAx|serAx|dateAx)>[\s\S]*?<c:axId val="(\d+)"\/>/g;
      let m;
      while ((m = axisRegex.exec(xml)) !== null) {
        definedAxes.add(m[1]);
      }

      // Check all referenced axIds in chart
      const chartTypeRegex = /<c:(?:barChart|lineChart|areaChart)>[\s\S]*?<\/c:(?:barChart|lineChart|areaChart)>/g;
      const chartMatch = xml.match(chartTypeRegex);
      if (chartMatch) {
        for (const block of chartMatch) {
          const refRegex = /<c:axId val="(\d+)"\/>/g;
          let r;
          while ((r = refRegex.exec(block)) !== null) {
            const axId = r[1];
            if (!definedAxes.has(axId)) {
              console.error(`FAILURE: Chart ${filename} has unmapped axis ID ${axId}!`);
              allAxesValid = false;
            }
          }
        }
      }
    }
  }

  console.log(`Checked ${chartCount} chart XML files. All axes valid: ${allAxesValid}`);
  if (!allAxesValid || chartCount === 0) {
    throw new Error('OOXML validation failed: orphan axis ID found or no charts tested');
  }

  console.log('SUCCESS: Generated PowerPoint presentation is 100% compliant with OpenXML standard.');
}

testFullDeckOOXMLIntegrity().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
