import fs from 'node:fs';

const files = [
  'node_modules/pptxgenjs/dist/pptxgen.cjs.js',
  'node_modules/pptxgenjs/dist/pptxgen.es.js',
  'node_modules/.vite/deps/pptxgenjs.js',
];

files.forEach((file) => {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    const oldStr = 'strXml += `<c:axId val="${catAxisId}"/><c:axId val="${valAxisId}"/><c:axId val="${AXIS_ID_SERIES_PRIMARY}"/>`;';
    const newStr = 'strXml += `<c:axId val="${catAxisId}"/><c:axId val="${valAxisId}"/>` + (chartType === CHART_TYPE.BAR3D ? `<c:axId val="${AXIS_ID_SERIES_PRIMARY}"/>` : \'\');';
    if (content.includes(oldStr)) {
      content = content.replace(oldStr, newStr);
      fs.writeFileSync(file, content);
      console.log('Successfully patched pptxgenjs orphan axId bug in ' + file);
    }
  }
});
