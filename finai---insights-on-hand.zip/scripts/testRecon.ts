import { FinancialAccount } from '../src/types/financial';
import { computeFinancialEngine } from '../src/utils/financialEngine';

interface TestFixture {
  name: string;
  description: string;
  accounts: FinancialAccount[];
  expected: {
    grossRevenueActual: number;
    contraRevenueActual: number;
    netRevenueActual: number;
    cogsActual: number;
    grossProfitActual: number;
    opexActual: number;
    ebitdaActual: number;
    ebitdaBenchmark: number;
    netProfitActual: number;
    debitCreditDiff: number;
    tieOutDiff: number;
  };
}

// 5 Sample Trial Balances with Exact Expected Totals in AED
const FIXTURES: TestFixture[] = [
  // Fixture 1: Standard Balanced UAE Retail Mall
  {
    name: 'TB 1: Standard UAE Retail Mall (Q3 MTD)',
    description: 'Balanced baseline operations with 10 anchor stores and balanced balance sheet',
    accounts: [
      { code: '1110', name: 'Cash at Bank', category: 'BALANCE_SHEET', subCategory: 'Current Assets', actual: 20000000, budget: 20000000, forecast: 20000000, priorPeriod: 20000000, debit: 20000000, isBalanceSheet: true },
      { code: '1510', name: 'Mall Core Property', category: 'BALANCE_SHEET', subCategory: 'Non-Current Assets', actual: 800000000, budget: 800000000, forecast: 800000000, priorPeriod: 800000000, debit: 800000000, isBalanceSheet: true },
      { code: '2110', name: 'Accounts Payable', category: 'BALANCE_SHEET', subCategory: 'Current Liabilities', actual: 10000000, budget: 10000000, forecast: 10000000, priorPeriod: 10000000, credit: 10000000, isBalanceSheet: true },
      { code: '2210', name: 'Bank Debt Facility', category: 'BALANCE_SHEET', subCategory: 'Non-Current Liabilities', actual: 300000000, budget: 300000000, forecast: 300000000, priorPeriod: 300000000, credit: 300000000, isBalanceSheet: true },
      { code: '3110', name: 'Share Capital', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 500000000, budget: 500000000, forecast: 500000000, priorPeriod: 500000000, credit: 500000000, isBalanceSheet: true },
      { code: '3220', name: 'Current Period Retained Profit', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 10000000, budget: 12000000, forecast: 11000000, priorPeriod: 10500000, credit: 10000000, isBalanceSheet: true },
      // P&L
      { code: '4110', name: 'Base Lease Rent', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Base Rent', actual: 30000000, budget: 32000000, forecast: 31000000, priorPeriod: 30000000, credit: 30000000, isBalanceSheet: false },
      { code: '4910', name: 'Tenant Rent-Free Discount', category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', subCategory: 'Concessions', actual: 2000000, budget: 1500000, forecast: 1800000, priorPeriod: 1600000, debit: 2000000, isBalanceSheet: false },
      { code: '5110', name: 'District Cooling & Utilities', category: 'COGS', pnlLine: 'Cost of Sales (COGS)', subCategory: 'Utilities', actual: 5000000, budget: 4500000, forecast: 4800000, priorPeriod: 4600000, debit: 5000000, isBalanceSheet: false },
      { code: '6110', name: 'Mall Custodial & Security', category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', subCategory: 'Facilities', actual: 8000000, budget: 7500000, forecast: 7800000, priorPeriod: 7600000, debit: 8000000, isBalanceSheet: false },
      { code: '8110', name: 'Depreciation', category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', subCategory: 'DA', actual: 3000000, budget: 3000000, forecast: 3000000, priorPeriod: 3000000, debit: 3000000, isBalanceSheet: false },
      { code: '9110', name: 'Bank Interest', category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', subCategory: 'Finance', actual: 2000000, budget: 2000000, forecast: 2000000, priorPeriod: 2000000, debit: 2000000, isBalanceSheet: false },
    ],
    expected: {
      grossRevenueActual: 30000000,
      contraRevenueActual: 2000000,
      netRevenueActual: 28000000,
      cogsActual: 5000000,
      grossProfitActual: 23000000,
      opexActual: 8000000,
      ebitdaActual: 15000000,
      ebitdaBenchmark: 18500000, // (32M - 1.5M) - 4.5M - 7.5M = 18.5M
      netProfitActual: 10000000, // 15M - 3M - 2M = 10M
      debitCreditDiff: 0,
      tieOutDiff: 0,
    },
  },

  // Fixture 2: High Concession & Fit-Out Waivers
  {
    name: 'TB 2: High Lease Concessions & Refurbishment',
    description: 'Early fit-out rent waivers with additional marketing expenditure',
    accounts: [
      { code: '1110', name: 'Cash', category: 'BALANCE_SHEET', subCategory: 'Current Assets', actual: 15000000, budget: 15000000, forecast: 15000000, priorPeriod: 15000000, debit: 15000000, isBalanceSheet: true },
      { code: '1510', name: 'Property Asset', category: 'BALANCE_SHEET', subCategory: 'Non-Current Assets', actual: 600000000, budget: 600000000, forecast: 600000000, priorPeriod: 600000000, debit: 600000000, isBalanceSheet: true },
      { code: '2110', name: 'Trade Payables', category: 'BALANCE_SHEET', subCategory: 'Current Liabilities', actual: 8000000, budget: 8000000, forecast: 8000000, priorPeriod: 8000000, credit: 8000000, isBalanceSheet: true },
      { code: '2210', name: 'Debt Facility', category: 'BALANCE_SHEET', subCategory: 'Non-Current Liabilities', actual: 200000000, budget: 200000000, forecast: 200000000, priorPeriod: 200000000, credit: 200000000, isBalanceSheet: true },
      { code: '3110', name: 'Capital', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 400000000, budget: 400000000, forecast: 400000000, priorPeriod: 400000000, credit: 400000000, isBalanceSheet: true },
      { code: '3220', name: 'Current Period Retained Profit', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 7000000, budget: 9000000, forecast: 8000000, priorPeriod: 7500000, credit: 7000000, isBalanceSheet: true },
      // P&L
      { code: '4110', name: 'Base Lease Rent', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Base Rent', actual: 25000000, budget: 26000000, forecast: 25500000, priorPeriod: 25000000, credit: 25000000, isBalanceSheet: false },
      { code: '4910', name: 'Tenant Rent-Free Discount', category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', subCategory: 'Concessions', actual: 3000000, budget: 2000000, forecast: 2500000, priorPeriod: 2200000, debit: 3000000, isBalanceSheet: false },
      { code: '5110', name: 'Direct Chilled Water', category: 'COGS', pnlLine: 'Cost of Sales (COGS)', subCategory: 'Utilities', actual: 4000000, budget: 3800000, forecast: 3900000, priorPeriod: 3850000, debit: 4000000, isBalanceSheet: false },
      { code: '6110', name: 'Mall Operations & Marketing', category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', subCategory: 'OPEX', actual: 7000000, budget: 6500000, forecast: 6800000, priorPeriod: 6600000, debit: 7000000, isBalanceSheet: false },
      { code: '8110', name: 'Depreciation', category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', subCategory: 'DA', actual: 2500000, budget: 2500000, forecast: 2500000, priorPeriod: 2500000, debit: 2500000, isBalanceSheet: false },
      { code: '9110', name: 'Finance Costs', category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', subCategory: 'Finance', actual: 1500000, budget: 1500000, forecast: 1500000, priorPeriod: 1500000, debit: 1500000, isBalanceSheet: false },
    ],
    expected: {
      grossRevenueActual: 25000000,
      contraRevenueActual: 3000000,
      netRevenueActual: 22000000,
      cogsActual: 4000000,
      grossProfitActual: 18000000,
      opexActual: 7000000,
      ebitdaActual: 11000000,
      ebitdaBenchmark: 13700000, // (26M - 2M) - 3.8M - 6.5M = 13.7M
      netProfitActual: 7000000,  // 11M - 2.5M - 1.5M = 7M
      debitCreditDiff: 0,
      tieOutDiff: 0,
    },
  },

  // Fixture 3: Peak Turnover Rent (TOR) Holiday Performance
  {
    name: 'TB 3: Peak Holiday Season (Strong TOR Expansion)',
    description: 'High tenant sales turnover rent with extra parking and media revenue',
    accounts: [
      { code: '1110', name: 'Cash', category: 'BALANCE_SHEET', subCategory: 'Current Assets', actual: 35000000, budget: 30000000, forecast: 32000000, priorPeriod: 28000000, debit: 35000000, isBalanceSheet: true },
      { code: '1510', name: 'Core Mall Real Estate', category: 'BALANCE_SHEET', subCategory: 'Non-Current Assets', actual: 900000000, budget: 900000000, forecast: 900000000, priorPeriod: 900000000, debit: 900000000, isBalanceSheet: true },
      { code: '2110', name: 'Payables & Deposits', category: 'BALANCE_SHEET', subCategory: 'Current Liabilities', actual: 20000000, budget: 18000000, forecast: 19000000, priorPeriod: 17500000, credit: 20000000, isBalanceSheet: true },
      { code: '2210', name: 'Term Syndicated Loan', category: 'BALANCE_SHEET', subCategory: 'Non-Current Liabilities', actual: 350000000, budget: 350000000, forecast: 350000000, priorPeriod: 350000000, credit: 350000000, isBalanceSheet: true },
      { code: '3110', name: 'Capital', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 545000000, budget: 545000000, forecast: 545000000, priorPeriod: 545000000, credit: 545000000, isBalanceSheet: true },
      { code: '3220', name: 'Current Period Retained Profit', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 20000000, budget: 16000000, forecast: 18000000, priorPeriod: 15500000, credit: 20000000, isBalanceSheet: true },
      // P&L
      { code: '4110', name: 'Base Lease Rent', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Base Rent', actual: 32000000, budget: 30000000, forecast: 31000000, priorPeriod: 29500000, credit: 32000000, isBalanceSheet: false },
      { code: '4210', name: 'Retail Tenant Turnover Rent (TOR)', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Turnover', actual: 8000000, budget: 5000000, forecast: 6500000, priorPeriod: 4800000, credit: 8000000, isBalanceSheet: false },
      { code: '4910', name: 'Concession Discounts', category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', subCategory: 'Concessions', actual: 1000000, budget: 1200000, forecast: 1100000, priorPeriod: 1150000, debit: 1000000, isBalanceSheet: false },
      { code: '5110', name: 'Direct Plant Utilities', category: 'COGS', pnlLine: 'Cost of Sales (COGS)', subCategory: 'Utilities', actual: 5500000, budget: 5200000, forecast: 5350000, priorPeriod: 5100000, debit: 5500000, isBalanceSheet: false },
      { code: '6110', name: 'Property Management OPEX', category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', subCategory: 'General OPEX', actual: 8500000, budget: 8000000, forecast: 8250000, priorPeriod: 7900000, debit: 8500000, isBalanceSheet: false },
      { code: '8110', name: 'Depreciation', category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', subCategory: 'DA', actual: 3200000, budget: 3200000, forecast: 3200000, priorPeriod: 3200000, debit: 3200000, isBalanceSheet: false },
      { code: '9110', name: 'Finance Costs', category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', subCategory: 'Finance', actual: 1800000, budget: 1800000, forecast: 1800000, priorPeriod: 1800000, debit: 1800000, isBalanceSheet: false },
    ],
    expected: {
      grossRevenueActual: 40000000, // 32M + 8M
      contraRevenueActual: 1000000,
      netRevenueActual: 39000000,
      cogsActual: 5500000,
      grossProfitActual: 33500000,
      opexActual: 8500000,
      ebitdaActual: 25000000,
      ebitdaBenchmark: 20600000, // (35M - 1.2M) - 5.2M - 8M = 20.6M
      netProfitActual: 20000000, // 25M - 3.2M - 1.8M = 20M
      debitCreditDiff: 0,
      tieOutDiff: 0,
    },
  },

  // Fixture 4: Summer Utility Surge (HVAC Overrun)
  {
    name: 'TB 4: Severe District Cooling HVAC Overrun',
    description: 'Chilled water cost surge evaluated as adverse non-controllable utility variance',
    accounts: [
      { code: '1110', name: 'Cash', category: 'BALANCE_SHEET', subCategory: 'Current Assets', actual: 18000000, budget: 20000000, forecast: 19000000, priorPeriod: 19500000, debit: 18000000, isBalanceSheet: true },
      { code: '1510', name: 'Property Asset', category: 'BALANCE_SHEET', subCategory: 'Non-Current Assets', actual: 750000000, budget: 750000000, forecast: 750000000, priorPeriod: 750000000, debit: 750000000, isBalanceSheet: true },
      { code: '2110', name: 'Utility Accruals', category: 'BALANCE_SHEET', subCategory: 'Current Liabilities', actual: 12000000, budget: 9000000, forecast: 10500000, priorPeriod: 9200000, credit: 12000000, isBalanceSheet: true },
      { code: '2210', name: 'Bank Debt', category: 'BALANCE_SHEET', subCategory: 'Non-Current Liabilities', actual: 280000000, budget: 280000000, forecast: 280000000, priorPeriod: 280000000, credit: 280000000, isBalanceSheet: true },
      { code: '3110', name: 'Capital', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 468000000, budget: 468000000, forecast: 468000000, priorPeriod: 468000000, credit: 468000000, isBalanceSheet: true },
      { code: '3220', name: 'Current Period Retained Profit', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 8000000, budget: 13000000, forecast: 10500000, priorPeriod: 12300000, credit: 8000000, isBalanceSheet: true },
      // P&L
      { code: '4110', name: 'Commercial Lease Rent', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Base Rent', actual: 29000000, budget: 29000000, forecast: 29000000, priorPeriod: 28500000, credit: 29000000, isBalanceSheet: false },
      { code: '4910', name: 'Rent Free Waivers', category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', subCategory: 'Concessions', actual: 1000000, budget: 1000000, forecast: 1000000, priorPeriod: 950000, debit: 1000000, isBalanceSheet: false },
      { code: '5110', name: 'District Cooling Chilled Water', category: 'COGS', pnlLine: 'Cost of Sales (COGS)', subCategory: 'Utilities', actual: 8000000, budget: 4000000, forecast: 6000000, priorPeriod: 4200000, debit: 8000000, isBalanceSheet: false },
      { code: '6110', name: 'General Mall OPEX', category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', subCategory: 'General OPEX', actual: 7500000, budget: 7000000, forecast: 7250000, priorPeriod: 6900000, debit: 7500000, isBalanceSheet: false },
      { code: '8110', name: 'Depreciation', category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', subCategory: 'DA', actual: 2500000, budget: 2500000, forecast: 2500000, priorPeriod: 2500000, debit: 2500000, isBalanceSheet: false },
      { code: '9110', name: 'Bank Interest', category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', subCategory: 'Finance', actual: 2000000, budget: 1500000, forecast: 1750000, priorPeriod: 1500000, debit: 2000000, isBalanceSheet: false },
    ],
    expected: {
      grossRevenueActual: 29000000,
      contraRevenueActual: 1000000,
      netRevenueActual: 28000000,
      cogsActual: 8000000,
      grossProfitActual: 20000000,
      opexActual: 7500000,
      ebitdaActual: 12500000,
      ebitdaBenchmark: 17000000, // (29M - 1M) - 4M - 7M = 17M
      netProfitActual: 8000000,  // 12.5M - 2.5M - 2M = 8M
      debitCreditDiff: 0,
      tieOutDiff: 0,
    },
  },

  // Fixture 5: Corporate Tax & Impairment Real Estate Restructure
  {
    name: 'TB 5: Impairment & UAE Corporate Tax 9%',
    description: 'Full statutory P&L lines with impairment, leasehold write-down, and tax',
    accounts: [
      { code: '1110', name: 'Cash', category: 'BALANCE_SHEET', subCategory: 'Current Assets', actual: 25000000, budget: 25000000, forecast: 25000000, priorPeriod: 24000000, debit: 25000000, isBalanceSheet: true },
      { code: '1510', name: 'Mall Investment Property', category: 'BALANCE_SHEET', subCategory: 'Non-Current Assets', actual: 850000000, budget: 850000000, forecast: 850000000, priorPeriod: 850000000, debit: 850000000, isBalanceSheet: true },
      { code: '2110', name: 'Trade Payables & Tax Accrual', category: 'BALANCE_SHEET', subCategory: 'Current Liabilities', actual: 15000000, budget: 14000000, forecast: 14500000, priorPeriod: 13500000, credit: 15000000, isBalanceSheet: true },
      { code: '2210', name: 'Term Facility', category: 'BALANCE_SHEET', subCategory: 'Non-Current Liabilities', actual: 320000000, budget: 320000000, forecast: 320000000, priorPeriod: 320000000, credit: 320000000, isBalanceSheet: true },
      { code: '3110', name: 'Paid Capital', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 529000000, budget: 529000000, forecast: 529000000, priorPeriod: 529000000, credit: 529000000, isBalanceSheet: true },
      { code: '3220', name: 'Current Period Retained Profit', category: 'BALANCE_SHEET', subCategory: 'Equity', actual: 11000000, budget: 12500000, forecast: 11800000, priorPeriod: 11500000, credit: 11000000, isBalanceSheet: true },
      // P&L
      { code: '4110', name: 'Mall Base Revenue', category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', subCategory: 'Base Rent', actual: 31000000, budget: 30000000, forecast: 30500000, priorPeriod: 29500000, credit: 31000000, isBalanceSheet: false },
      { code: '4910', name: 'Tenant Rent-Free Waivers', category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', subCategory: 'Concessions', actual: 1500000, budget: 1000000, forecast: 1250000, priorPeriod: 1100000, debit: 1500000, isBalanceSheet: false },
      { code: '5110', name: 'Direct Plant Utilities', category: 'COGS', pnlLine: 'Cost of Sales (COGS)', subCategory: 'Utilities', actual: 4500000, budget: 4200000, forecast: 4350000, priorPeriod: 4100000, debit: 4500000, isBalanceSheet: false },
      { code: '6110', name: 'Custodial & Security OPEX', category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', subCategory: 'Facilities', actual: 7000000, budget: 6800000, forecast: 6900000, priorPeriod: 6700000, debit: 7000000, isBalanceSheet: false },
      { code: '7110', name: 'Sundry Scrap & Parking Income', category: 'OTHER_INCOME', pnlLine: 'Other Income', subCategory: 'Other', actual: 500000, budget: 400000, forecast: 450000, priorPeriod: 380000, credit: 500000, isBalanceSheet: false },
      { code: '8110', name: 'Depreciation', category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', subCategory: 'DA', actual: 3000000, budget: 3000000, forecast: 3000000, priorPeriod: 3000000, debit: 3000000, isBalanceSheet: false },
      { code: '8210', name: 'Leasehold Impairment Charge', category: 'BELOW_EBITDA', pnlLine: 'Impairment', subCategory: 'Impairment', actual: 1000000, budget: 0, forecast: 500000, priorPeriod: 0, debit: 1000000, isBalanceSheet: false },
      { code: '9110', name: 'Finance Bank Interest', category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', subCategory: 'Finance', actual: 2500000, budget: 2000000, forecast: 2250000, priorPeriod: 2100000, debit: 2500000, isBalanceSheet: false },
      { code: '9210', name: 'UAE Corporate Tax (9%)', category: 'BELOW_EBITDA', pnlLine: 'Tax', subCategory: 'Tax', actual: 1000000, budget: 900000, forecast: 950000, priorPeriod: 850000, debit: 1000000, isBalanceSheet: false },
    ],
    expected: {
      grossRevenueActual: 31000000,
      contraRevenueActual: 1500000,
      netRevenueActual: 29500000,
      cogsActual: 4500000,
      grossProfitActual: 25000000,
      opexActual: 7000000,
      ebitdaActual: 18000000,
      ebitdaBenchmark: 18000000, // (30M - 1M) - 4.2M - 6.8M = 18.0M
      netProfitActual: 11000000, // EBIT = 18M + 0.5M - 3M - 1M = 14.5M; Net Profit = 14.5M - 2.5M - 1M = 11.0M
      debitCreditDiff: 0,
      tieOutDiff: 0,
    },
  },
];

console.log('========================================================================');
console.log('FINAI FP&A RECONCILIATION TEST SUITE (5 TRIAL BALANCES)');
console.log('Requirement: Fail if any total differs by more than AED 0');
console.log('========================================================================\n');

let allPassed = true;

FIXTURES.forEach((fixture, idx) => {
  console.log(`[TEST ${idx + 1}/5] Running: ${fixture.name}`);
  console.log(`  Description: ${fixture.description}`);

  const res = computeFinancialEngine(fixture.accounts, 'BUDGET');
  const m = res.metrics;
  const bs = res.balanceSheetCheck;

  // 1. Balance Check: Total Debits - Total Credits = 0
  const debitsCreditsDiff = Math.abs(bs.debitCreditCheck.difference);
  if (debitsCreditsDiff !== fixture.expected.debitCreditDiff) {
    console.error(`  ❌ FAILED Balance Check: Expected diff AED ${fixture.expected.debitCreditDiff}, got AED ${debitsCreditsDiff}`);
    allPassed = false;
  } else {
    console.log(`  ✓ Balance check: Total Debits (${bs.debitCreditCheck.totalDebits}) − Total Credits (${bs.debitCreditCheck.totalCredits}) = AED 0 diff`);
  }

  // 2. P&L-to-BS Tie-Out: Net Profit = Retained Earnings Movement
  const tieOutDiff = Math.abs(bs.pnlTieOutCheck.difference);
  if (tieOutDiff !== fixture.expected.tieOutDiff) {
    console.error(`  ❌ FAILED P&L-to-BS Tie-Out: Expected diff AED ${fixture.expected.tieOutDiff}, got AED ${tieOutDiff}`);
    allPassed = false;
  } else {
    console.log(`  ✓ P&L-to-BS tie-out: Net Profit (${bs.pnlTieOutCheck.netProfitPnl}) = Retained Earnings Movement (${bs.pnlTieOutCheck.retainedEarningsDelta}) -> AED 0 diff`);
  }

  // 3. Closed Waterfall Bridge: Actual EBITDA = Benchmark EBITDA + Revenue Var - Direct Cost Var - OPEX Var
  const revVar = m.revenueActual - m.revenueBenchmark;
  const cogsVar = -(m.cogsActual - m.cogsBenchmark);
  const opexVar = -(m.opexActual - m.opexBenchmark);
  const bridgeEbitda = m.ebitdaBenchmark + revVar + cogsVar + opexVar;
  const bridgeDelta = Math.abs(m.ebitdaActual - bridgeEbitda);

  if (bridgeDelta !== 0) {
    console.error(`  ❌ FAILED Closed EBITDA Waterfall Bridge: Bridge calculated AED ${bridgeEbitda}, actual EBITDA AED ${m.ebitdaActual}, delta AED ${bridgeDelta}`);
    allPassed = false;
  } else {
    console.log(`  ✓ EBITDA waterfall bridge: Actual EBITDA (${m.ebitdaActual}) = Benchmark EBITDA (${m.ebitdaBenchmark}) + Rev Var (${revVar}) − COGS Var (${m.cogsActual - m.cogsBenchmark}) − OPEX Var (${m.opexActual - m.opexBenchmark}) -> AED 0 diff`);
  }

  // 4. Assert Expected Numbers
  const checks: [string, number, number][] = [
    ['Gross Revenue', m.grossRevenueActual, fixture.expected.grossRevenueActual],
    ['Contra Revenue', m.contraRevenueActual, fixture.expected.contraRevenueActual],
    ['Net Revenue', m.revenueActual, fixture.expected.netRevenueActual],
    ['COGS', m.cogsActual, fixture.expected.cogsActual],
    ['Gross Profit', m.grossProfitActual, fixture.expected.grossProfitActual],
    ['OPEX', m.opexActual, fixture.expected.opexActual],
    ['Actual EBITDA', m.ebitdaActual, fixture.expected.ebitdaActual],
    ['Benchmark EBITDA', m.ebitdaBenchmark, fixture.expected.ebitdaBenchmark],
    ['Net Profit After Tax', m.netProfitActual, fixture.expected.netProfitActual],
  ];

  checks.forEach(([label, actualVal, expectedVal]) => {
    if (actualVal !== expectedVal) {
      console.error(`  ❌ FAILED ${label}: Expected AED ${expectedVal}, got AED ${actualVal}`);
      allPassed = false;
    }
  });

  console.log(`  ✓ All financial controls and totals PASSED with AED 0 discrepancy.\n`);
});

if (!allPassed) {
  console.error('FAILED: One or more trial balance reconciliation tests failed.');
  process.exit(1);
} else {
  console.log('========================================================================');
  console.log('SUCCESS: All 5 trial balances passed all reconciliation tests with AED 0 diff.');
  console.log('========================================================================');
  process.exit(0);
}
