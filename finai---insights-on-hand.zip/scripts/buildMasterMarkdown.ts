import fs from 'node:fs';
import { execSync } from 'node:child_process';

const files = [
  { path: 'src/types/financial.ts', desc: 'Type definitions, P&L hierarchy contracts and validation models' },
  { path: 'src/theme/themeConfig.ts', desc: 'Theme configuration, brand tokens and indicator symbols' },
  { path: 'src/utils/financialEngine.ts', desc: 'Calculation engine: EBITDA bridge, polarity rules, balance sheet tie-out' },
  { path: 'src/utils/exportEngine.ts', desc: 'Exports: ExcelJS workbook, PptxGenJS 6-slide deck, jsPDF A4 report' },
  { path: 'scripts/testRecon.ts', desc: 'Reconciliation test suite (fails on any non-zero difference)' },
  { path: 'src/utils/trialBalanceParser.ts', desc: 'CSV/XLSX parser for trial balances, account mappings and leasing drivers' },
  { path: 'src/data/shoppingMallDataset.ts', desc: 'Demo trial balances and leasing drivers (fictional malls)' },
  { path: 'server.ts', desc: 'Express backend, Gemini commentary proxy and rule-based fallback' },
  { path: 'src/App.tsx', desc: 'App state, period switching, materiality filters and routing' },
  { path: 'src/components/WaterfallBridge.tsx', desc: 'Waterfall bridge chart with reconciliation proof' },
  { path: 'src/components/BalanceSheetAuditView.tsx', desc: 'Debit/credit check and retained earnings roll-forward' },
  { path: 'src/components/PnlRollupTable.tsx', desc: 'P&L table with controllable tags, variance % and drilldowns' },
  { path: 'src/components/SlideDeckPreviewModal.tsx', desc: '16:9 six-slide board deck preview' },
  { path: 'src/components/BoardCommentaryView.tsx', desc: 'Executive commentary, open questions register and driver comparison' },
  { path: 'src/components/ExecutiveControlBar.tsx', desc: 'Period selection, materiality thresholds and export triggers' },
  { path: 'src/components/TopNav.tsx', desc: 'Navigation, theme selector, upload and deck preview' },
  { path: 'src/components/ColourPaletteModal.tsx', desc: 'Colour palette customisation with live preview' }
];

// 1. Check that every file exists before building
const missing = files.filter(f => !fs.existsSync(f.path)).map(f => f.path);
if (missing.length) {
  console.error('BUILD STOPPED. Missing files:\n' + missing.join('\n'));
  process.exit(1);
}

// 2. Run the real test suite and capture its output
let testLog = '';
let testsPassed = true;
try {
  testLog = execSync('npx tsx scripts/testRecon.ts', { encoding: 'utf8', stdio: 'pipe' });
} catch (err: any) {
  testsPassed = false;
  testLog = (err.stdout || '') + '\n' + (err.stderr || '');
}

let commit = 'not a git repository';
try { commit = execSync('git rev-parse --short HEAD', { encoding: 'utf8' }).trim(); } catch {}
const runAt = new Date().toISOString();
const status = testsPassed ? 'System check passed' : 'System check FAILED (see test log)';

const fence = '````';
const lines = (s: string) => s.split('\n').length;

// 3. Header
let doc = '# FinAI FP&A Suite: Codebase and System Review Pack\n\n';
doc += '> **Industry focus:** UAE retail mall and commercial property assets\n';
doc += '> **Currency:** AED\n';
doc += '> **Prepared by:** CA Parth Indrajit Khona\n';
doc += `> **Status:** ${status}\n`;
doc += `> **Generated:** ${runAt} | **Commit:** ${commit}\n\n---\n\n`;

// 4. File inventory
doc += '## 1. File inventory\n\n| # | File | Lines | Purpose |\n|---|---|---|---|\n';
const contents = files.map(f => fs.readFileSync(f.path, 'utf8'));
files.forEach((f, i) => {
  doc += `| ${i + 1} | \`${f.path}\` | ${lines(contents[i])} | ${f.desc} |\n`;
});

// 5. Formulas
doc += '\n---\n\n## 2. Core formulas\n\n';
doc += '1. **Trial balance check:** `Total debits − Total credits = 0` (calculated in fils as whole numbers, exact match)\n\n';
doc += '2. **Retained earnings roll-forward:** `Opening RE + Net profit − Dividends ± Other equity movements = Closing RE` (RE accounts taken from the mapping file, not hardcoded)\n\n';
doc += '3. **EBITDA bridge:** `Actual EBITDA = Benchmark EBITDA + Net revenue variance − Direct cost variance − OPEX variance` (Other income sits below EBITDA unless the setting says otherwise)\n\n';
doc += '4. **Variance %:** `(Actual − Benchmark) / |Benchmark| × 100`\n';
doc += '   - Show "n.m." only if Benchmark = 0, or Actual ≠ 0 and its sign differs from Benchmark. Actual = 0 shows −100%.\n\n';
doc += '5. **Margin shift:** `Actual margin % − Benchmark margin %`, shown in percentage points (pp). Example: 42.6% to 41.3% = −1.3 pp.\n\n';
doc += '6. **PDF centre point:** `14 + 269 / 2 = 148.5 mm` (A4 landscape, 297 mm wide)\n\n';
doc += '7. **Leasing breakdown** (all amounts on the same period basis):\n';
doc += '   - `Occupancy = (Occ_A − Occ_B) × GLA_B × Rate_B`\n';
doc += '   - `GLA = (GLA_A − GLA_B) × Occ_A × Rate_B`\n';
doc += '   - `Rate = (Rate_A − Rate_B) × Occ_A × GLA_A`\n';
doc += '   - `TOR = TOR_A − TOR_B`\n';
doc += '   - `Other = Net revenue variance − (Occupancy + GLA + Rate + TOR)` (always shown, so the total reconciles)\n\n';

// 6. Source code
doc += '---\n\n## 3. Source code\n\n';
files.forEach((f, i) => {
  const lang = f.path.endsWith('.tsx') ? 'tsx' : 'typescript';
  const c = contents[i];
  doc += `### 3.${i + 1} \`${f.path}\` (${lines(c)} lines)\n\n> ${f.desc}\n\n`;
  doc += `${fence}${lang}\n${c}${c.endsWith('\n') ? '' : '\n'}${fence}\n\n---\n\n`;
});

// 7. Real test output
doc += `## 4. Test output (npm run test:recon, run at ${runAt})\n\n`;
doc += `${fence}text\n${testLog.trim()}\n${fence}\n\n`;
doc += `**Result:** ${status}\n\n---\n\nPrepared by CA Parth Indrajit Khona\n`;

fs.writeFileSync('FINAI_COMPLETE_SOURCE_CODEBASE.md', doc, 'utf8');
console.log(`Build complete: ${lines(doc)} lines. ${status}.`);
if (!testsPassed) process.exit(1);
