# FinAI Institutional FP&A Suite — System Specification (v2.0)
**Target Industry:** UAE Retail & Mall Real Estate (Asset Management & Mall Operating Companies)  
**Target Executive Audience:** Chief Financial Officer (CFO), Audit Committee & Board of Directors  
**Currencies:** AED (Default Reporting Currency), USD, EUR, GBP  
**Reporting Periods:** MTD (Month-to-Date), YTD (Year-to-Date), Full-Year (FY)  
**Governance Protocol:** Deterministic Financial Control & Semantic Evidence Gate  

---

## 1. Operating Constitution & Precedence Hierarchy

In all financial computations, commentary generation, and boardroom presentations, the system strictly enforces the following four-tier conflict resolution hierarchy:

$$\text{Source Financial Data} \succ \text{Accounting Logic} \succ \text{Narrative} \succ \text{Visual Presentation}$$

1. **Source Financial Data & Accounting Logic Always Win:** If a discrepancy arises between narrative text and ledger numbers, the narrative is rewritten to match the ledger.
2. **Deterministic Pre-Control Gate:** Executive presentations and board commentary are never compiled until the trial balance has passed both core balance sheet tests.
3. **Anti-Hallucination Evidence Boundary:** If source financial data does not establish why a variance occurred, the system never invents a cause. It presents the verified financial fact and converts the unanswered root cause into an open management inquiry with an assigned owner and due date.
4. **Minimum Necessary Commentary:** The objective is not to maximize narrative volume. The objective is to generate the minimum amount of commentary needed to explain the financial facts accurately and drive decisive executive action.

---

## 2. Core Mathematical Formulas (Written in Full Plain Text)

All mathematical operations are calculated at full floating-point precision and rounded ONLY at the display boundary.

### 2.1 Balance Check (Trial Balance Integrity)
$$\text{Total Debits} - \text{Total Credits} = 0$$
- In an unclosed trial balance, the sum of all debit balances must equal the sum of all credit balances with exactly 0.00 AED discrepancy.
- Pass Condition: `|Total Debits − Total Credits| < 1.00 AED`.
- System Status: Displays **"System check passed"** or **"System check failed"** with the exact difference amount.

### 2.2 Balance Sheet-to-P&L Tie-Out Check
$$\text{Net Profit (P&L)} = \text{Current-period movement in Retained Earnings (or the profit line in the balance sheet)}$$
- The Net Profit After Tax derived from the P&L hierarchy must equal the movement in Account 3220 (Current Period Retained Earnings) on the balance sheet.
- Pass Condition: `|Net Profit (P&L) − Movement in Retained Earnings| < 1.00 AED`.
- System Status: Displays **"System check passed"** or **"System check failed"** with the exact difference amount.

### 2.3 Margin Shifts (Expressed Exclusively in Percentage Points)
Margin changes must always be expressed in percentage points (`pp`), never in percent (`%`):
$$\text{Margin Shift} = \text{Actual Margin \%} - \text{Benchmark Margin \%}$$
*Plain Text Example:*  
$$\text{Gross Margin } 42.6\% \rightarrow 41.3\% = -1.3\text{ pp}$$

### 2.4 Closed EBITDA Variance Waterfall Bridge
$$\text{Actual EBITDA} = \text{Benchmark EBITDA} + \text{Revenue Variance} - \text{Direct Cost Variance} - \text{OPEX Variance}$$
- Must reconcile to exactly 0.00 difference against delivered EBITDA:
  - $\text{Revenue Variance} = \text{Actual Net Revenue} - \text{Benchmark Net Revenue}$ (Positive variance expands EBITDA)
  - $\text{Direct Cost Variance} = \text{Actual COGS} - \text{Benchmark COGS}$ (Cost overrun decreases EBITDA)
  - $\text{OPEX Variance} = \text{Actual OPEX} - \text{Benchmark OPEX}$ (Cost overrun decreases EBITDA)
$$\text{Closed Bridge Discrepancy} = \text{Actual EBITDA} - (\text{Benchmark EBITDA} + \text{Revenue Variance} - \text{Direct Cost Variance} - \text{OPEX Variance}) = 0.00\text{ AED}$$

### 2.5 Safe Variance Percentage Formula
$$\text{Variance \%} = \begin{cases} \text{"n.m." (Not Meaningful)}, & \text{if Benchmark} = 0 \\ \text{"n.m." (Not Meaningful)}, & \text{if Sign}(\text{Actual}) \neq \text{Sign}(\text{Benchmark}) \\ \frac{\text{Actual} - \text{Benchmark}}{|\text{Benchmark}|} \times 100, & \text{otherwise} \end{cases}$$

### 2.6 Rounding Rule & Display Reconciliation
- Calculate all aggregations and variances at full floating-point precision.
- Round ONLY at the presentation boundary:
  - Boardroom Views & Slides: Values displayed in AED Millions with 1 decimal place (e.g., `AED 48.1M`).
  - Excel Detail Sheets: Values formatted in AED Thousands (e.g., `48,050`).
- If the sum of rounded parts does not equal the rounded total due to decimal rounding, a visible **"Rounding Adjustment"** line is added to reconcile the display. Totals are never forced or distorted.

### 2.7 PDF Landscape Centering Geometry
$$\text{x} = \text{Left Margin} + \frac{\text{Usable Width}}{2} = 14\text{ mm} + \frac{269\text{ mm}}{2} = 148.5\text{ mm}$$
- Document format: A4 Landscape ($297\text{ mm} \times 210\text{ mm}$).
- Usable printable width: $269\text{ mm}$ (with $14\text{ mm}$ left and right margins).
- All table headers, major section banners, and action titles are centered at exactly $x = 148.5\text{ mm}$ using `{ align: 'center' }`.

---

## 3. Account Mapping Architecture & P&L Line Classification

The engine eliminates hardcoded account ranges by providing an uploadable Account Mapping table:

$$\text{Account Code} \rightarrow \text{P\&L Line} \rightarrow \text{Tier} \rightarrow \text{Controllable (Yes/No)} \rightarrow \text{Sign (1 or -1)}$$

Standard Chart of Accounts (COA) ranges (1000–9999) serve solely as a fallback template when no custom mapping is uploaded.

### 3.1 Standard P&L Line Structure:
1. **Gross Commercial Revenue:** Base lease rents (Anchor, In-line, F&B, Entertainment), Specialty leasing & Kiosks, CAM recoveries, Media advertising, Parking fees.
2. **Contra-revenue:** Tenant rent-free amortisation, fit-out waivers, tenant discounts, and bad-debt provisions.
3. **Net Commercial Revenue:** $\text{Gross Revenue} - \text{Contra-revenue}$.
4. **Direct Cost of Sales (COGS):** Mall electricity, district cooling chilled water, municipal water/sewerage, HVAC and MEP plant maintenance, elevator/escalator contracts.
5. **Gross Profit:** $\text{Net Commercial Revenue} - \text{COGS}$.
6. **Operating Expenses (OPEX):** Custodial cleaning, security personnel & CCTV monitoring, waste disposal, marketing campaigns, property management salaries, IT ERP software, property asset insurance, legal dispute arbitration.
7. **Operational EBITDA:** $\text{Gross Profit} - \text{OPEX}$.
8. **Rounding Adjustment:** Display line when rounded parts do not sum to rounded total.
9. **Other Operational Income:** Sundry tenant admin fees, recycling scrap income.
10. **Depreciation & Amortisation:** Property structure, plant & equipment (Tagged "Non-controllable", evaluated as costs: higher = adverse).
11. **Operating Profit (EBIT):** $\text{EBITDA} + \text{Other Income} - \text{D\&A} - \text{IFRS 16} - \text{Impairment} + \text{FX}$.
12. **IFRS 16 Lease Effects:** Right-of-use land lease asset depreciation.
13. **Impairment Charges:** Leasehold fit-out impairments.
14. **FX Gains/Losses:** Foreign currency procurement movements.
15. **Finance Costs (Split):** Bank syndicated term loan interest (EIBOR) and IFRS 16 lease liability accretion (Tagged "Non-controllable", higher = adverse).
16. **Tax (Split):** UAE Federal Corporate Tax at 9% statutory rate (Tagged "Non-controllable", higher = adverse).
17. **Net Profit After Tax:** $\text{EBIT} - \text{Finance Costs} - \text{Tax}$.

### 3.2 Blocking Unmapped Accounts Alert
If the uploaded trial balance contains any GL code absent from the active mapping table, the engine triggers a blocking **"Unmapped Accounts"** alert modal and halts calculations until resolved.

---

## 4. Materiality Filter & Controllability Governance

### 4.1 User-Configurable Materiality Thresholds
A variance is qualified for executive commentary and driver ranking ONLY if it meets both criteria simultaneously:
$$|\text{Dollar Variance}| \ge \text{AED Threshold (Default: 250,000 AED)}$$
$$\text{AND } |\text{Variance \%}| \ge \text{Percentage Threshold (Default: 5.0\%) or is "n.m."}$$

### 4.2 Cost Polarity & Controllability Tags
- **Revenue & Margins:** $\text{Actual} > \text{Benchmark} = \text{FAVOURABLE}$ (Expansion); $\text{Actual} < \text{Benchmark} = \text{ADVERSE}$ (Shortfall).
- **COGS & OPEX:** $\text{Actual} > \text{Benchmark} = \text{ADVERSE}$ (Cost Overrun); $\text{Actual} < \text{Benchmark} = \text{FAVOURABLE}$ (Savings).
- **Depreciation, Finance Costs & Tax:** Evaluated as costs ($\text{Actual} > \text{Benchmark} = \text{ADVERSE}$), tagged explicitly as **"Non-controllable"** rather than "Neutral".
- **Zero Pill & Glyph Pairing Discipline:** Color is NEVER used as the sole indicator. Every favorable metric is paired with `▲ +`, and every adverse metric is paired with `▼ -`.

---

## 5. Governance, AI Fallback & Data Privacy Protocol

### 5.1 Elimination of Promotional & Compliance Vocabulary
Per user governance directives, the terms *"audit-grade"*, *"audit-verified"*, *"certified"*, *"certification"*, and *"statutory compliance"* are prohibited across the user interface, export engines, and documentation. The standardized status indicator is:
$$\text{"System check passed"} \quad \text{or} \quad \text{"System check failed"}$$

### 5.2 Visible AI Fallback & Model Environment Configuration
- The LLM model is read dynamically from the environment variable:
  $$\text{MODEL\_NAME} = \text{process.env.GEMINI\_MODEL} \parallel \text{'gemini-3.8-flash'}$$
- Every narrative output displays an explicit source badge:
  - `Commentary source: AI (gemini-3.8-flash)`
  - `Commentary source: Rule-based (Data Privacy Enabled)`
  - `Commentary source: Rule-based (AI unavailable: Quota or API offline)` with the exact logged reason.

### 5.3 Data Privacy Policy
- An on-screen toggle **"Send data to external AI"** defaults to **OFF**.
- When toggled **OFF**, financial numbers and trial balances are processed entirely in-memory using deterministic rule-based financial models, with zero external network transmission.

### 5.4 Corporate Theme & H Luxury Brand Palette Configuration
The application centralizes all brand styling in `src/theme/themeConfig.ts`, featuring the official **H Brand Heritage & Luxury** guidelines extracted directly from the design artifact (`media_1793295521012_a3e97650.png`), alongside institutional options:
- **H Orange:** `#FF6600` (RGB 255, 102, 0) — Signature brand heritage, energy & recognition
- **Ébène (Deep Brown):** `#3B2F2A` (RGB 59, 47, 42) — Luxury, refinement, headers & depth
- **Gris Perle:** `#C9C4BC` (RGB 201, 196, 188) — Balance, elegance, surfaces
- **Ivoire:** `#F8F6F1` (RGB 248, 246, 241) — Clean, timeless main backgrounds
- **Anthracite:** `#1F1F1F` (RGB 31, 31, 31) — Headings & high-contrast typography
- **Or (Gold):** `#D4AF37` (RGB 212, 175, 55) — Icons, buttons & accents
- **Success Green:** `#10B981` (paired strictly with `▲ +`)
- **Error Red:** `#EF4444` (paired strictly with `▼ -`)
- **Neutral Grey:** `#9CA3AF`
- **Border:** `#E5E7EB`
- **Zero-Ambiguity Polarity Rule:** Color is never the sole indicator; every variance metric is paired with `▲ +` or `▼ -`.
- **Live Theme Manager & Showcase:** Includes an on-screen visual swatch ribbon (`ColourPaletteShowcase.tsx`), real-time custom hex override inputs, and multi-format deliverable mapping for Excel, PowerPoint, and PDF.

---

## 6. Boardroom Deliverables Specification

### 6.1 Excel Workbook (.xlsx via ExcelJS)
- **Sheet 1: Executive P&L:** Major macro lines with CPA double-underline on Gross Profit, Operational EBITDA, and Net Profit. Text wrapping disabled (`wrapText: false`). Gray gridlines hidden (`showGridLines: false`). Numbers formatted in AED Thousands using:
  `_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)`
- **Sheet 2: Detailed P&L Rollups:** Complete GL code rollups, controllability tags, variance %, and category contribution. Text wrapping disabled (`wrapText: false`).
- **Sheet 3: Balance Sheet Checks:** Detailed reporting of Test 1 (Debits − Credits = 0) and Test 2 (Net Profit = Retained Earnings Movement), showing exact differences and `System check passed` status.
- **Sheet 4: Board Commentary:** Narrative executive briefings and action items formatted with text wrapping enabled (`wrapText: true`) and top alignment (`vertical: 'top'`).

### 6.2 Executive Board Deck (6 Slides Only via PptxGenJS)
The presentation is redesigned to a strict 6-slide structure:
- **Slide 1: Title & Mandate:** Executive presentation title, reporting period, currency, and System check passed badge.
- **Slide 2: So-What:** One concise headline takeaway (Action title stating conclusion with a number $\le 90$ characters) + 3 KPI cards (Net Revenue, Operational EBITDA, EBITDA Margin pp).
- **Slide 3: EBITDA Bridge (Native Editable PowerPoint Chart):** Stacked column waterfall bridge created as a native, fully editable Microsoft Office Chart object (`pptx.ChartType.col`), not static shapes or cards.
- **Slide 4: Top Drivers:** Adverse vs. Favourable variance drivers (top 5 each after materiality filter).
- **Slide 5: Open Questions & Actions:** Governance register showing Item, Inquiry Question, Owner, Due Date, and Status.
- **Slide 6: Appendix:** Full comprehensive P&L statement table. (Balance sheet tests are maintained exclusively in Excel).
- **Typography & Formatting Rules:**
  - `shrinkText` is removed completely.
  - Character limits strictly enforced: Headline $\le 90$ characters; Card narrative $\le 160$ characters.
  - Truncated text appends `…` in the presentation layer and automatically saves the full un-truncated text into PowerPoint speaker notes (`slide.addNotes`).

### 6.3 Landscape PDF Dossier (jsPDF + AutoTable)
- Orientation: A4 Landscape ($297\text{ mm} \times 210\text{ mm}$, usable width $269\text{ mm}$).
- Centered Headlines: All section banners and table titles positioned at $x = 148.5\text{ mm}$ (`{ align: 'center' }`).
- Numbers formatted in AED Millions with 1 decimal place.

---

## 7. Advanced UAE Retail Mall Features

### 7.1 Closed-Loop Governance & Management Explanations
Unexplained variances generate an action item with Owner, Due date, and Status (`Open` | `Answered` | `Closed`). Once management answers a question, the answer is permanently stored and automatically reused in next month's commentary, tagged explicitly as **"Management explanation"**.

### 7.2 Leasing Drivers & 3-Way Revenue Decomposition
When optional leasing driver schedules (Occupancy %, GLA sqm, Tenant Sales, Base Rent, Turnover Rent) are uploaded:
$$\text{Occupancy Effect} = (\text{Actual Occupancy \%} - \text{Benchmark Occupancy \%}) \times \text{Benchmark Base Rent}$$
$$\text{Rate Effect} = (\text{Actual Base Rent} - \text{Benchmark Base Rent}) - \text{Occupancy Effect}$$
$$\text{Turnover Rent (TOR) Effect} = \text{Actual TOR} - \text{Benchmark TOR}$$
$$\text{Reconciliation Delta} = \text{Total Revenue Variance} - (\text{Occupancy Effect} + \text{Rate Effect} + \text{TOR Effect} + \text{Sundry}) = 0.00\text{ AED}$$
*Pillar Rule:* Without uploaded driver data, the system is strictly prohibited from claiming a volume or price cause.

### 7.3 "What Changed Since Last Month" Panel
Compares the current run against the prior saved monthly run to identify:
- **New Items:** Material variances appearing for the first time this period.
- **Resolved Items:** Variances that normalized back within tolerance.
- **Worsening Items:** Adverse pressures that expanded in magnitude since last month.

---

## 8. Automated Reconciliation Test Suite (`npm run test:recon`)

The codebase ships with a test suite in `scripts/testRecon.ts` containing 5 sample trial balances (`tb-01` through `tb-05`) with expected outputs in JSON format. The test script verifies:
1. `Total Debits − Total Credits = 0` (Exact diff = 0.00 AED)
2. `Net Profit (P&L) = Movement in Retained Earnings` (Exact diff = 0.00 AED)
3. `Delivered EBITDA = Benchmark EBITDA + Rev Var − COGS Var − OPEX Var` (Exact diff = 0.00 AED)
4. All category sums and metrics match expected values with 0 discrepancy.
If any total differs by more than 0.00 AED, the script exits with an error code and halts the build.
