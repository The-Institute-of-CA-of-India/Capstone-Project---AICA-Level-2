/**
 * FinAI Institutional FP&A Theme Configuration
 * Single source of truth for neutral corporate palette.
 * Easily overridden here for re-branding.
 *
 * Rules:
 * - Neutral corporate palette (Slate / Navy / Charcoal / Cool Gray)
 * - Never rely on color alone: every favourable/adverse metric is paired with ▲/▼ and +/-
 */

export interface BrandToken {
  name: string;
  hex: string;
  rgb: string;
  role: string;
  textDark?: boolean;
}

export interface CorporateTheme {
  id: string;
  name: string;
  description: string;
  brandTag?: string;
  brandTokens?: BrandToken[];
  colors: {
    // Brand & Structure
    primary: string;         // Main brand color
    primaryLight: string;
    secondary: string;
    accent: string;
    mutedText: string;
    border: string;
    borderDark: string;
    surfaceLight: string;
    cardLight: string;
    surfaceDark: string;
    cardDark: string;

    // Variance Polarity Colors (paired always with glyphs)
    favourable: string;
    favourableBg: string;
    favourableDarkBg: string;
    adverse: string;
    adverseBg: string;
    adverseDarkBg: string;
    neutral: string;
    neutralBg: string;

    // Special brand tokens
    ebene?: string;
    ivoire?: string;
    grisPerle?: string;
    anthracite?: string;
    gold?: string;
  };

  // Symbols to guarantee color is never the sole indicator
  indicators: {
    favourable: string;      // '▲ +'
    adverse: string;         // '▼ -'
    neutral: string;         // '—'
  };

  // Pre-formatted palettes for export engines
  excel: {
    headerFill: string;      // ARGB
    headerText: string;      // ARGB
    subHeaderFill: string;   // ARGB
    subHeaderText: string;   // ARGB
    borderGrid: string;      // ARGB
    favFill: string;         // ARGB
    favText: string;         // ARGB
    advFill: string;         // ARGB
    advText: string;         // ARGB
  };

  pptx: {
    primary: string;
    secondary: string;
    accent: string;
    surface: string;
    cardBg: string;
    border: string;
    textDark: string;
    textMuted: string;
    fav: string;
    adv: string;
    neutral: string;
  };

  pdf: {
    primaryRgb: [number, number, number];
    secondaryRgb: [number, number, number];
    textDarkRgb: [number, number, number];
    textMutedRgb: [number, number, number];
    borderRgb: [number, number, number];
    favRgb: [number, number, number];
    advRgb: [number, number, number];
    bgLightRgb: [number, number, number];
  };
}

export const CORPORATE_PALETTES: Record<string, CorporateTheme> = {
  'hermes-luxury': {
    id: 'hermes-luxury',
    name: 'H Brand Heritage & Luxury',
    description: 'Official H Brand Guidelines: Signature H Orange (#FF6600), Ébène (#3B2F2A), Gris Perle (#C9C4BC), Ivoire (#F8F6F1), Anthracite (#1F1F1F), and Or Gold (#D4AF37).',
    brandTag: 'H',
    brandTokens: [
      { name: 'H Orange', hex: '#FF6600', rgb: '255, 102, 0', role: 'Signature brand heritage, recognition & energy' },
      { name: 'Ébène', hex: '#3B2F2A', rgb: '59, 47, 42', role: 'Luxury & refinement. Used for text, accents, depth' },
      { name: 'Gris Perle', hex: '#C9C4BC', rgb: '201, 196, 188', role: 'Balance & elegance. Used for surfaces, backgrounds', textDark: true },
      { name: 'Ivoire', hex: '#F8F6F1', rgb: '248, 246, 241', role: 'Clean & timeless. Used for main backgrounds', textDark: true },
      { name: 'Anthracite', hex: '#1F1F1F', rgb: '31, 31, 31', role: 'Text & contrast. Used for headings, key information' },
      { name: 'Or (Gold)', hex: '#D4AF37', rgb: '212, 175, 55', role: 'Accent & highlights. Used for icons, buttons, highlights', textDark: true },
      { name: 'Success Green', hex: '#10B981', rgb: '16, 185, 129', role: 'Favourable variance (paired with ▲ +)' },
      { name: 'Error Red', hex: '#EF4444', rgb: '239, 68, 68', role: 'Adverse variance (paired with ▼ -)' },
    ],
    colors: {
      primary: '#FF6600',
      primaryLight: '#FF8533',
      secondary: '#3B2F2A',
      accent: '#D4AF37',
      mutedText: '#6B7280',
      border: '#E5E7EB',
      borderDark: '#3B2F2A',
      surfaceLight: '#F8F6F1',
      cardLight: '#FFFFFF',
      surfaceDark: '#1F1F1F',
      cardDark: '#2C221E',

      favourable: '#10B981',
      favourableBg: '#D1FAE5',
      favourableDarkBg: '#064E3B',
      adverse: '#EF4444',
      adverseBg: '#FEE2E2',
      adverseDarkBg: '#7F1D1D',
      neutral: '#9CA3AF',
      neutralBg: '#F8F6F1',

      ebene: '#3B2F2A',
      ivoire: '#F8F6F1',
      grisPerle: '#C9C4BC',
      anthracite: '#1F1F1F',
      gold: '#D4AF37',
    },
    indicators: {
      favourable: '▲ +',
      adverse: '▼ -',
      neutral: '—',
    },
    excel: {
      headerFill: 'FFFF6600',    // H Orange
      headerText: 'FFFFFFFF',    // White
      subHeaderFill: 'FFF8F6F1', // Ivoire
      subHeaderText: 'FF3B2F2A', // Ébène
      borderGrid: 'FFE5E7EB',    // Gris border
      favFill: 'FFD1FAE5',
      favText: 'FF065F46',
      advFill: 'FFFEE2E2',
      advText: 'FF991B1B',
    },
    pptx: {
      primary: '3B2F2A',         // Ébène header
      secondary: 'FF6600',       // H Orange
      accent: 'D4AF37',          // Or Gold
      surface: 'F8F6F1',         // Ivoire
      cardBg: 'FFFFFF',
      border: 'E5E7EB',
      textDark: '1F1F1F',        // Anthracite
      textMuted: '9CA3AF',
      fav: '10B981',
      adv: 'EF4444',
      neutral: '9CA3AF',
    },
    pdf: {
      primaryRgb: [255, 102, 0],     // H Orange
      secondaryRgb: [59, 47, 42],    // Ébène
      textDarkRgb: [31, 31, 31],     // Anthracite
      textMutedRgb: [156, 163, 175], // Neutral Grey
      borderRgb: [229, 231, 235],    // Border
      favRgb: [16, 185, 129],        // Success Green
      advRgb: [239, 68, 68],         // Error Red
      bgLightRgb: [248, 246, 241],   // Ivoire
    },
  },

  'institutional-slate': {
    id: 'institutional-slate',
    name: 'Institutional Slate & Navy',
    description: 'Executive standard for UAE real estate boards. Deep slate-900 with subtle cool gray and sapphire accents.',
    colors: {
      primary: '#0F172A',
      primaryLight: '#1E293B',
      secondary: '#334155',
      accent: '#2563EB',
      mutedText: '#64748B',
      border: '#E2E8F0',
      borderDark: '#1E293B',
      surfaceLight: '#F8FAFC',
      cardLight: '#FFFFFF',
      surfaceDark: '#0B0F17',
      cardDark: '#131B26',

      favourable: '#16A34A',
      favourableBg: '#DCFCE7',
      favourableDarkBg: '#052E16',
      adverse: '#DC2626',
      adverseBg: '#FEE2E2',
      adverseDarkBg: '#450A0A',
      neutral: '#64748B',
      neutralBg: '#F1F5F9',
    },
    indicators: {
      favourable: '▲ +',
      adverse: '▼ -',
      neutral: '—',
    },
    excel: {
      headerFill: 'FF0F172A',
      headerText: 'FFFFFFFF',
      subHeaderFill: 'FFF1F5F9',
      subHeaderText: 'FF0F172A',
      borderGrid: 'FFE2E8F0',
      favFill: 'FFDCFCE7',
      favText: 'FF15803D',
      advFill: 'FFFEE2E2',
      advText: 'FFB91C1C',
    },
    pptx: {
      primary: '0F172A',
      secondary: '334155',
      accent: '2563EB',
      surface: 'F8FAFC',
      cardBg: 'FFFFFF',
      border: 'E2E8F0',
      textDark: '0F172A',
      textMuted: '64748B',
      fav: '16A34A',
      adv: 'DC2626',
      neutral: '64748B',
    },
    pdf: {
      primaryRgb: [15, 23, 42],
      secondaryRgb: [51, 65, 85],
      textDarkRgb: [15, 23, 42],
      textMutedRgb: [100, 116, 139],
      borderRgb: [226, 232, 240],
      favRgb: [22, 163, 74],
      advRgb: [220, 38, 38],
      bgLightRgb: [248, 250, 252],
    },
  },

  'difc-graphite': {
    id: 'difc-graphite',
    name: 'DIFC Executive Graphite & Emerald',
    description: 'Financial center aesthetic. Midnight charcoal foundation with refined emerald green accents.',
    colors: {
      primary: '#111827',
      primaryLight: '#1F2937',
      secondary: '#374151',
      accent: '#059669',
      mutedText: '#6B7280',
      border: '#E5E7EB',
      borderDark: '#1F2937',
      surfaceLight: '#F9FAFB',
      cardLight: '#FFFFFF',
      surfaceDark: '#080C14',
      cardDark: '#111827',

      favourable: '#10B981',
      favourableBg: '#D1FAE5',
      favourableDarkBg: '#064E3B',
      adverse: '#EF4444',
      adverseBg: '#FEE2E2',
      adverseDarkBg: '#7F1D1D',
      neutral: '#6B7280',
      neutralBg: '#F3F4F6',
    },
    indicators: {
      favourable: '▲ +',
      adverse: '▼ -',
      neutral: '—',
    },
    excel: {
      headerFill: 'FF111827',
      headerText: 'FFFFFFFF',
      subHeaderFill: 'FFF3F4F6',
      subHeaderText: 'FF111827',
      borderGrid: 'FFE5E7EB',
      favFill: 'FFD1FAE5',
      favText: 'FF065F46',
      advFill: 'FFFEE2E2',
      advText: 'FF991B1B',
    },
    pptx: {
      primary: '111827',
      secondary: '374151',
      accent: '059669',
      surface: 'F9FAFB',
      cardBg: 'FFFFFF',
      border: 'E5E7EB',
      textDark: '111827',
      textMuted: '6B7280',
      fav: '10B981',
      adv: 'EF4444',
      neutral: '6B7280',
    },
    pdf: {
      primaryRgb: [17, 24, 39],
      secondaryRgb: [55, 65, 81],
      textDarkRgb: [17, 24, 39],
      textMutedRgb: [107, 114, 128],
      borderRgb: [229, 231, 235],
      favRgb: [16, 185, 129],
      advRgb: [239, 68, 68],
      bgLightRgb: [249, 250, 251],
    },
  },

  'dubai-sapphire': {
    id: 'dubai-sapphire',
    name: 'Dubai Marina Sapphire',
    description: 'Deep maritime navy with sharp azure highlights and cool slate structural lines.',
    colors: {
      primary: '#0C4A6E',
      primaryLight: '#075985',
      secondary: '#0369A1',
      accent: '#0284C7',
      mutedText: '#64748B',
      border: '#E0F2FE',
      borderDark: '#0C4A6E',
      surfaceLight: '#F0F9FF',
      cardLight: '#FFFFFF',
      surfaceDark: '#041726',
      cardDark: '#082F49',

      favourable: '#16A34A',
      favourableBg: '#DCFCE7',
      favourableDarkBg: '#052E16',
      adverse: '#DC2626',
      adverseBg: '#FEE2E2',
      adverseDarkBg: '#450A0A',
      neutral: '#64748B',
      neutralBg: '#F1F5F9',
    },
    indicators: {
      favourable: '▲ +',
      adverse: '▼ -',
      neutral: '—',
    },
    excel: {
      headerFill: 'FF0C4A6E',
      headerText: 'FFFFFFFF',
      subHeaderFill: 'FFF0F9FF',
      subHeaderText: 'FF0C4A6E',
      borderGrid: 'FFE0F2FE',
      favFill: 'FFDCFCE7',
      favText: 'FF15803D',
      advFill: 'FFFEE2E2',
      advText: 'FFB91C1C',
    },
    pptx: {
      primary: '0C4A6E',
      secondary: '0369A1',
      accent: '0284C7',
      surface: 'F0F9FF',
      cardBg: 'FFFFFF',
      border: 'BAE6FD',
      textDark: '0C4A6E',
      textMuted: '64748B',
      fav: '16A34A',
      adv: 'DC2626',
      neutral: '64748B',
    },
    pdf: {
      primaryRgb: [12, 74, 110],
      secondaryRgb: [3, 105, 161],
      textDarkRgb: [12, 74, 110],
      textMutedRgb: [100, 116, 139],
      borderRgb: [224, 242, 254],
      favRgb: [22, 163, 74],
      advRgb: [220, 38, 38],
      bgLightRgb: [240, 249, 255],
    },
  },

  'abu-dhabi-prestige': {
    id: 'abu-dhabi-prestige',
    name: 'Abu Dhabi Prestige Bronze',
    description: 'Warm stone and desert bronze tones tailored for sovereign asset managers and prestigious mall holdings.',
    colors: {
      primary: '#1C1917',
      primaryLight: '#292524',
      secondary: '#44403C',
      accent: '#D97706',
      mutedText: '#78716C',
      border: '#E7E5E4',
      borderDark: '#292524',
      surfaceLight: '#FAFAF9',
      cardLight: '#FFFFFF',
      surfaceDark: '#0C0A09',
      cardDark: '#1C1917',

      favourable: '#15803D',
      favourableBg: '#DCFCE7',
      favourableDarkBg: '#052E16',
      adverse: '#B91C1C',
      adverseBg: '#FEE2E2',
      adverseDarkBg: '#450A0A',
      neutral: '#78716C',
      neutralBg: '#F5F5F4',
    },
    indicators: {
      favourable: '▲ +',
      adverse: '▼ -',
      neutral: '—',
    },
    excel: {
      headerFill: 'FF1C1917',
      headerText: 'FFFFFFFF',
      subHeaderFill: 'FFF5F5F4',
      subHeaderText: 'FF1C1917',
      borderGrid: 'FFE7E5E4',
      favFill: 'FFDCFCE7',
      favText: 'FF15803D',
      advFill: 'FFFEE2E2',
      advText: 'FFB91C1C',
    },
    pptx: {
      primary: '1C1917',
      secondary: '44403C',
      accent: 'D97706',
      surface: 'FAFAF9',
      cardBg: 'FFFFFF',
      border: 'E7E5E4',
      textDark: '1C1917',
      textMuted: '78716C',
      fav: '15803D',
      adv: 'B91C1C',
      neutral: '78716C',
    },
    pdf: {
      primaryRgb: [28, 25, 23],
      secondaryRgb: [68, 64, 60],
      textDarkRgb: [28, 25, 23],
      textMutedRgb: [120, 113, 108],
      borderRgb: [231, 229, 228],
      favRgb: [21, 128, 61],
      advRgb: [185, 28, 28],
      bgLightRgb: [250, 250, 249],
    },
  },
};

export const DEFAULT_THEME_ID = 'hermes-luxury';

// Default singleton theme for direct import backwards-compatibility
export const CORPORATE_THEME: CorporateTheme = CORPORATE_PALETTES['hermes-luxury'];
