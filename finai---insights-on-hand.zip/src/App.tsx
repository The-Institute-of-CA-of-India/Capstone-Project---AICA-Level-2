import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  AccountMapping,
  BenchmarkType,
  BoardCommentaryData,
  CurrencyCode,
  FinancialAccount,
  LeasingDriverData,
  MaterialityFilter,
  OpenQuestionAction,
  PeriodType,
  VarianceRollup,
} from './types/financial';
import {
  DEFAULT_UAE_ACCOUNT_MAPPINGS,
  METROPOLITAN_MALL_DATASET,
  SAMPLE_LEASING_DRIVERS,
  SAMPLE_OPEN_QUESTIONS,
  SAMPLE_PRIOR_RUN_COMPARISON,
  getDatasetForPeriod,
  getLeasingDriversForPeriod,
} from './data/shoppingMallDataset';
import {
  computeFinancialEngine,
  formatCurrency,
  formatCurrencyM,
  formatPpDelta,
  PREPARED_BY_FOOTNOTE,
} from './utils/financialEngine';
import { exportToExcel, exportToPowerPoint, exportToPdfDossier } from './utils/exportEngine';
import { TopNav } from './components/TopNav';
import { ExecutiveControlBar } from './components/ExecutiveControlBar';
import { KpiScorecard } from './components/KpiScorecard';
import { WaterfallBridge } from './components/WaterfallBridge';
import { PnlRollupTable } from './components/PnlRollupTable';
import { BoardCommentaryView } from './components/BoardCommentaryView';
import { SlideDeckPreviewModal } from './components/SlideDeckPreviewModal';
import { BalanceSheetAuditView } from './components/BalanceSheetAuditView';
import { UploadModal } from './components/UploadModal';
import { AccountDetailModal } from './components/AccountDetailModal';
import { ColourPaletteModal } from './components/ColourPaletteModal';
import { InteractivePnlDashboard } from './components/InteractivePnlDashboard';
import {
  TrendingUp,
  Presentation,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import { CORPORATE_THEME, CorporateTheme } from './theme/themeConfig';

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('finai_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'light';
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('finai_theme', theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const isLight = theme === 'light';

  // Core Financial State
  const [accounts, setAccounts] = useState<FinancialAccount[]>(METROPOLITAN_MALL_DATASET);
  const [datasetName, setDatasetName] = useState<string>(
    'Yas & Marina Retail Mall Properties (Consolidated)'
  );
  const [currency, setCurrency] = useState<CurrencyCode>('AED');
  const [period, setPeriod] = useState<PeriodType>('MTD');
  const [benchmarkType, setBenchmarkType] = useState<BenchmarkType>('BUDGET');
  const [customMappings, setCustomMappings] = useState<AccountMapping[]>(DEFAULT_UAE_ACCOUNT_MAPPINGS);
  const [materiality, setMateriality] = useState<MaterialityFilter>({
    aedThreshold: 250000,
    pctThreshold: 5.0,
  });
  const [leasingDrivers, setLeasingDrivers] = useState<LeasingDriverData | null>(SAMPLE_LEASING_DRIVERS);
  const [openQuestions, setOpenQuestions] = useState<OpenQuestionAction[]>(SAMPLE_OPEN_QUESTIONS);
  const [priorRunComparison] = useState(SAMPLE_PRIOR_RUN_COMPARISON);
  const [isCustomDataset, setIsCustomDataset] = useState<boolean>(false);

  // Switch dummy dataset across MTD, YTD, and FY dynamically
  const handlePeriodChange = (newPeriod: PeriodType) => {
    setPeriod(newPeriod);
    if (!isCustomDataset) {
      setAccounts(getDatasetForPeriod(newPeriod));
      setLeasingDrivers(getLeasingDriversForPeriod(newPeriod));
    }
  };

  // Data Privacy Toggle: Default OFF (Never send financial data to external AI unless explicitly turned on)
  const [sendToExternalAi, setSendToExternalAi] = useState<boolean>(false);

  // UI Navigation, Theme & Modals
  const [activeTheme, setActiveTheme] = useState<CorporateTheme>(CORPORATE_THEME);
  const [isPaletteOpen, setIsPaletteOpen] = useState<boolean>(false);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [selectedAccount, setSelectedAccount] = useState<VarianceRollup | null>(null);

  // Board Commentary State
  const [commentary, setCommentary] = useState<BoardCommentaryData | null>(null);
  const [isLoadingCommentary, setIsLoadingCommentary] = useState<boolean>(false);

  // Compute Deterministic Financial Engine
  const financialData = useMemo(() => {
    return computeFinancialEngine(
      accounts,
      benchmarkType,
      customMappings,
      materiality,
      currency,
      period,
      leasingDrivers
    );
  }, [accounts, benchmarkType, customMappings, materiality, currency, period, leasingDrivers]);

  const {
    metrics,
    unmappedAccounts,
    grossRevenueSubCategories,
    contraRevenueSubCategories,
    cogsSubCategories,
    opexSubCategories,
    belowEbitdaSubCategories,
    topAdverseDrivers,
    topFavourableDrivers,
    waterfallSteps,
    balanceSheetCheck,
    leasingDecomposition,
  } = financialData;

  // Generate Board Commentary
  const handleGenerateCommentary = useCallback(async () => {
    setIsLoadingCommentary(true);
    try {
      const res = await fetch('/api/commentary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetName,
          benchmarkType:
            benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period',
          metrics,
          topDrivers: {
            topAdverse: topAdverseDrivers.slice(0, 5),
            topFavourable: topFavourableDrivers.slice(0, 5),
          },
          pnlSummary: {
            grossRevenue: metrics.grossRevenueActual,
            contraRevenue: metrics.contraRevenueActual,
            netRevenue: metrics.revenueActual,
            grossProfit: metrics.grossProfitActual,
            grossMarginPpDelta: metrics.grossMarginDeltaPp,
            opex: metrics.opexActual,
            ebitda: metrics.ebitdaActual,
            ebitdaMarginPpDelta: metrics.ebitdaMarginDeltaPp,
            netProfit: metrics.netProfitActual,
          },
          sendToExternalAi,
          openQuestions,
          leasingDecomposition,
        }),
      });

      if (!res.ok) throw new Error('Commentary service unavailable');
      const data = await res.json();
      setCommentary(data);
    } catch (_err) {
      // Offline fallback
      const ebitdaVarM = (Math.abs(metrics.ebitdaVariance) / 1_000_000).toFixed(1);
      setCommentary({
        source: 'Rule-based',
        sourceLabel: 'Commentary source: Rule-based (Deterministic Engine)',
        actionTitle: `EBITDA ${currency} ${ebitdaVarM}M ${metrics.ebitdaVariance >= 0 ? 'above' : 'below'} ${benchmarkType.toLowerCase()}`,
        executiveSummary: `For the reporting period, operational EBITDA concluded at ${formatCurrency(
          metrics.ebitdaActual,
          currency
        )} against a ${benchmarkType.toLowerCase()} baseline of ${formatCurrency(
          metrics.ebitdaBenchmark,
          currency
        )}. System check passed: Balance Sheet accounts are segregated from operational P&L.`,
        strategicHighlights: [
          `Gross Commercial Revenue variance settled at ${formatCurrency(metrics.grossRevenueVariance, currency)}.`,
          `Contra-revenue concessions and bad-debt provisions totaled ${formatCurrency(metrics.contraRevenueActual, currency)}.`,
          `EBITDA Margin recorded at ${metrics.ebitdaMarginActual.toFixed(1)}% (${formatPpDelta(metrics.ebitdaMarginDeltaPp)}).`,
        ],
        directlySupportedDeductions: [
          {
            driver: topAdverseDrivers[0]?.name || 'Primary Cost Driver',
            impactAmount: formatCurrency(topAdverseDrivers[0]?.dollarVariance || 0, currency),
            driverContributionPct: topAdverseDrivers[0]?.driverContributionPct,
            polarity: 'ADVERSE',
            mathematicalProof: `Drove adverse variance of ${formatCurrency(
              topAdverseDrivers[0]?.dollarVariance || 0,
              currency
            )}.`,
          },
        ],
        operationalHypotheses: [
          {
            lineItem: 'Chilled Water Utilities (5110)',
            inquiryQuestion:
              'Verify whether utility cost variance was caused by district cooling tariff escalation or unbilled tenant sub-metering.',
            dataRequiredToConfirm: 'Municipal utility rate billings and tenant sub-meter logs.',
          },
        ],
        dataLimitations: [
          'Trial Balance dataset does not record individual tenant visitor footfall counts.',
          'Price versus volume decomposition is restricted without leasing driver uploads.',
        ],
        boardActionItems: [
          'Enforce timely tenant sub-metering reconciliations for chilled water utilities.',
        ],
      });
    } finally {
      setIsLoadingCommentary(false);
    }
  }, [
    datasetName,
    benchmarkType,
    metrics,
    topAdverseDrivers,
    topFavourableDrivers,
    sendToExternalAi,
    openQuestions,
    leasingDecomposition,
    currency,
  ]);

  useEffect(() => {
    handleGenerateCommentary();
  }, [handleGenerateCommentary]);

  // Export Notification & Status State
  const [exportNotification, setExportNotification] = useState<{
    type: 'loading' | 'success' | 'error';
    message: string;
  } | null>(null);

  // Export Handlers with robust error handling and status notifications
  const handleExportExcel = async () => {
    try {
      setExportNotification({ type: 'loading', message: 'Generating Institutional Excel Workbook...' });
      await exportToExcel(
        datasetName,
        benchmarkType,
        metrics,
        grossRevenueSubCategories,
        contraRevenueSubCategories,
        cogsSubCategories,
        opexSubCategories,
        belowEbitdaSubCategories,
        balanceSheetCheck,
        accounts,
        commentary,
        openQuestions,
        activeTheme
      );
      setExportNotification({ type: 'success', message: 'Excel workbook downloaded successfully.' });
      setTimeout(() => setExportNotification(null), 3500);
    } catch (err: any) {
      console.error('Excel export error:', err);
      setExportNotification({
        type: 'error',
        message: `Excel export error: ${err?.message || 'Download failed'}`,
      });
      setTimeout(() => setExportNotification(null), 6000);
    }
  };

  const handleExportPptx = async () => {
    try {
      setExportNotification({ type: 'loading', message: 'Generating Executive Board Presentation (6 slides)...' });
      await exportToPowerPoint(
        datasetName,
        benchmarkType,
        metrics,
        topAdverseDrivers,
        topFavourableDrivers,
        commentary,
        openQuestions,
        activeTheme,
        leasingDrivers,
        accounts,
        opexSubCategories
      );
      setExportNotification({ type: 'success', message: 'PowerPoint board deck (.pptx) downloaded successfully.' });
      setTimeout(() => setExportNotification(null), 4000);
    } catch (err: any) {
      console.error('PowerPoint export error:', err);
      setExportNotification({
        type: 'error',
        message: `PowerPoint export error: ${err?.message || 'Download failed'}. Please check console or retry.`,
      });
      setTimeout(() => setExportNotification(null), 7000);
    }
  };

  const handlePrintPdf = () => {
    try {
      setExportNotification({ type: 'loading', message: 'Generating PDF Executive Dossier...' });
      exportToPdfDossier(
        datasetName,
        benchmarkType,
        metrics,
        topAdverseDrivers,
        topFavourableDrivers,
        commentary,
        openQuestions,
        activeTheme
      );
      setExportNotification({ type: 'success', message: 'PDF Executive Dossier generated successfully.' });
      setTimeout(() => setExportNotification(null), 3500);
    } catch (err: any) {
      console.error('PDF export error:', err);
      setExportNotification({
        type: 'error',
        message: `PDF export error: ${err?.message || 'Download failed'}`,
      });
      setTimeout(() => setExportNotification(null), 6000);
    }
  };

  const handleUpdateQuestion = (updated: OpenQuestionAction) => {
    setOpenQuestions((prev) => prev.map((q) => (q.id === updated.id ? updated : q)));
  };

  const handleAddQuestion = (newQ: OpenQuestionAction) => {
    setOpenQuestions((prev) => [...prev, newQ]);
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
        isLight ? 'bg-[#F8FAFC] text-[#0F172A]' : 'dark bg-[#0B0F17] text-[#F8FAFC]'
      }`}
    >
      {/* Top Navigation */}
      <TopNav
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenDeck={() => setCurrentTab('deck')}
        currency={currency}
        onCurrencyChange={setCurrency}
        period={period}
        onPeriodChange={handlePeriodChange}
        benchmarkType={benchmarkType}
        onBenchmarkChange={setBenchmarkType}
        sendToExternalAi={sendToExternalAi}
        onToggleSendToAi={() => setSendToExternalAi(!sendToExternalAi)}
        activeTheme={activeTheme}
        onOpenPalette={() => setIsPaletteOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-5">
        {/* Unmapped Accounts Blocking Alert Banner */}
        {unmappedAccounts.length > 0 && (
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
              <div>
                <span className="font-bold block text-sm">
                  Blocking Alert: {unmappedAccounts.length} Unmapped Account(s)
                </span>
                <span>
                  All accounts must be mapped to standard P&L lines before calculating verified board deliverables.
                </span>
              </div>
            </div>
            <button
              onClick={() => setIsUploadOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-bold hover:bg-amber-700 text-xs shrink-0"
            >
              Upload Mapping Table
            </button>
          </div>
        )}

        {/* Executive Control Bar */}
        <ExecutiveControlBar
          datasetName={datasetName}
          benchmarkType={benchmarkType}
          setBenchmarkType={setBenchmarkType}
          theme={theme}
          onOpenUpload={() => setIsUploadOpen(true)}
          onLoadDemo={() => {
            setIsCustomDataset(false);
            setAccounts(getDatasetForPeriod(period));
            setCustomMappings(DEFAULT_UAE_ACCOUNT_MAPPINGS);
            setLeasingDrivers(getLeasingDriversForPeriod(period));
            setDatasetName('Yas & Marina Retail Mall Properties (Consolidated)');
          }}
          onExportPptx={handleExportPptx}
          onExportExcel={handleExportExcel}
          onPrintPdf={handlePrintPdf}
          systemCheckPassed={balanceSheetCheck.statusText === 'System check passed'}
          unmappedAccounts={unmappedAccounts}
          materiality={materiality}
          onMaterialityChange={setMateriality}
          hasLeasingDrivers={!!leasingDrivers}
        />

        {/* Global Export Status Toast */}
        {exportNotification && (
          <div className="fixed bottom-6 right-6 z-50 max-w-md animate-in fade-in slide-in-from-bottom-3 duration-200 shadow-xl rounded-xl border p-4 flex items-center gap-3 bg-white dark:bg-[#1E293B] border-slate-200 dark:border-slate-700">
            {exportNotification.type === 'loading' && (
              <Loader2 className="w-5 h-5 animate-spin text-blue-600 dark:text-blue-400 shrink-0" />
            )}
            {exportNotification.type === 'success' && (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            )}
            {exportNotification.type === 'error' && (
              <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" />
            )}
            <div className="text-xs">
              <p className="font-semibold text-slate-900 dark:text-white">
                {exportNotification.type === 'loading' ? 'Export in Progress' : exportNotification.type === 'success' ? 'Export Ready' : 'Export Notice'}
              </p>
              <p className="text-slate-500 dark:text-slate-400 mt-0.5">{exportNotification.message}</p>
            </div>
          </div>
        )}

        {/* KPI Scorecard */}
        {currentTab !== 'dashboard' && (
          <KpiScorecard metrics={metrics} benchmarkType={benchmarkType} theme={theme} />
        )}

        {/* Tab Views */}
        {currentTab === 'dashboard' && (
          <InteractivePnlDashboard
            metrics={metrics}
            benchmarkType={benchmarkType}
            onBenchmarkChange={setBenchmarkType}
            period={period}
            onPeriodChange={handlePeriodChange}
            currency={currency}
            theme={theme}
            allAccounts={accounts}
            grossRevenueSubs={grossRevenueSubCategories}
            contraRevenueSubs={contraRevenueSubCategories}
            cogsSubs={cogsSubCategories}
            opexSubs={opexSubCategories}
            belowEbitdaSubs={belowEbitdaSubCategories}
            onSelectAccount={setSelectedAccount}
            activeTheme={activeTheme}
          />
        )}

        {currentTab === 'summary' && (
          <div className="space-y-6">
            {/* EBITDA Walk Bridge */}
            <WaterfallBridge
              metrics={metrics}
              benchmarkType={benchmarkType}
              grossRevenueSubs={grossRevenueSubCategories}
              cogsSubs={cogsSubCategories}
              opexSubs={opexSubCategories}
              leasingDecomposition={leasingDecomposition}
              theme={theme}
            />

            {/* Quick View: Top Drivers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Adverse */}
              <div
                className={`p-4 rounded-xl border ${
                  isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-rose-600 uppercase flex items-center gap-1.5">
                    <span>▼ Top Material Headwinds (Overruns)</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Threshold: ≥ {formatCurrency(materiality.aedThreshold, currency)}
                  </span>
                </div>
                <div className="space-y-2">
                  {topAdverseDrivers.slice(0, 4).map((d) => (
                    <div
                      key={d.code}
                      onClick={() => setSelectedAccount(d)}
                      className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 cursor-pointer flex items-center justify-between text-xs"
                    >
                      <div className="truncate pr-2">
                        <span className="font-mono text-slate-500 mr-2">{d.code}</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{d.name}</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{d.subCategory}</span>
                      </div>
                      <span className="font-mono font-bold text-rose-600 shrink-0">
                        {formatCurrency(d.dollarVariance, currency)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Favourable */}
              <div
                className={`p-4 rounded-xl border ${
                  isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-emerald-600 uppercase flex items-center gap-1.5">
                    <span>▲ Top Material Favourable (Savings / Growth)</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Threshold: ≥ {formatCurrency(materiality.aedThreshold, currency)}
                  </span>
                </div>
                <div className="space-y-2">
                  {topFavourableDrivers.slice(0, 4).map((d) => (
                    <div
                      key={d.code}
                      onClick={() => setSelectedAccount(d)}
                      className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 cursor-pointer flex items-center justify-between text-xs"
                    >
                      <div className="truncate pr-2">
                        <span className="font-mono text-slate-500 mr-2">{d.code}</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{d.name}</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{d.subCategory}</span>
                      </div>
                      <span className="font-mono font-bold text-emerald-600 shrink-0">
                        +{formatCurrency(d.dollarVariance, currency)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Action to Full P&L */}
            <div className="flex justify-center pt-2">
              <button
                onClick={() => setCurrentTab('pnl')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-900/50 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-all"
              >
                <span>View Comprehensive P&L Statement & Hierarchy</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {currentTab === 'pnl' && (
          <PnlRollupTable
            metrics={metrics}
            benchmarkType={benchmarkType}
            grossRevenueSubs={grossRevenueSubCategories}
            contraRevenueSubs={contraRevenueSubCategories}
            cogsSubs={cogsSubCategories}
            opexSubs={opexSubCategories}
            belowEbitdaSubs={belowEbitdaSubCategories}
            theme={theme}
            onSelectAccount={setSelectedAccount}
          />
        )}

        {currentTab === 'waterfall' && (
          <WaterfallBridge
            metrics={metrics}
            benchmarkType={benchmarkType}
            grossRevenueSubs={grossRevenueSubCategories}
            cogsSubs={cogsSubCategories}
            opexSubs={opexSubCategories}
            leasingDecomposition={leasingDecomposition}
            theme={theme}
          />
        )}

        {currentTab === 'commentary' && (
          <BoardCommentaryView
            datasetName={datasetName}
            benchmarkType={benchmarkType}
            metrics={metrics}
            topAdverseDrivers={topAdverseDrivers}
            topFavourableDrivers={topFavourableDrivers}
            commentary={commentary}
            isLoadingCommentary={isLoadingCommentary}
            theme={theme}
            onGenerateCommentary={handleGenerateCommentary}
            openQuestions={openQuestions}
            onUpdateQuestion={handleUpdateQuestion}
            onAddQuestion={handleAddQuestion}
            priorRunComparison={priorRunComparison}
          />
        )}

        {currentTab === 'deck' && (
          <SlideDeckPreviewModal
            datasetName={datasetName}
            benchmarkType={benchmarkType}
            metrics={metrics}
            topAdverseDrivers={topAdverseDrivers}
            topFavourableDrivers={topFavourableDrivers}
            commentary={commentary}
            openQuestions={openQuestions}
            theme={theme}
            onExportPptx={handleExportPptx}
            onPrintPdf={handlePrintPdf}
            activeTheme={activeTheme}
            leasingDrivers={leasingDrivers}
            allAccounts={accounts}
            opexSubCategories={opexSubCategories}
          />
        )}

        {currentTab === 'audit' && (
          <BalanceSheetAuditView
            check={balanceSheetCheck}
            allAccounts={accounts}
            theme={theme}
          />
        )}
      </main>

      {/* Account Detail Drilldown Modal */}
      {selectedAccount && (
        <AccountDetailModal
          account={selectedAccount}
          benchmarkType={benchmarkType}
          theme={theme}
          onClose={() => setSelectedAccount(null)}
        />
      )}

      {/* Upload Modal (Trial Balance, Mapping Table, Drivers) */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={(newAccounts, newFilename) => {
          setAccounts(newAccounts);
          setIsCustomDataset(true);
          setDatasetName(newFilename.replace(/\.[^/.]+$/, ''));
          setIsUploadOpen(false);
        }}
        onUploadMappings={(newMappings) => {
          setCustomMappings(newMappings);
        }}
        onUploadDrivers={(newDrivers) => {
          setLeasingDrivers(newDrivers);
        }}
        unmappedAccounts={unmappedAccounts}
        currentMappings={customMappings}
        theme={theme}
      />

      {/* Colour Palette & Theme Manager Modal */}
      <ColourPaletteModal
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        activeTheme={activeTheme}
        onSelectTheme={(newTheme) => setActiveTheme(newTheme)}
      />

      {/* Institutional Persistent Footer */}
      <footer
        className={`mt-10 border-t py-4 px-4 sm:px-6 transition-colors ${
          isLight
            ? 'bg-white border-slate-200 text-slate-600'
            : 'bg-[#0B0F17] border-slate-800 text-slate-400'
        }`}
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: activeTheme.colors.primary }}
            />
            <span className="font-semibold text-slate-900 dark:text-slate-100">
              {PREPARED_BY_FOOTNOTE}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 font-mono">
            <span>Period: {period}</span>
            <span>·</span>
            <span>Scenario: {benchmarkType}</span>
            <span>·</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
              System check passed (AED 0 diff)
            </span>
            <span>·</span>
            <span>Strictly Confidential · Board of Directors Review</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
