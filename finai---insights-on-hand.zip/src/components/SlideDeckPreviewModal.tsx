import React, { useState } from 'react';
import {
  BenchmarkType,
  BoardCommentaryData,
  FinancialAccount,
  LeasingDriverData,
  MacroPnlMetrics,
  OpenQuestionAction,
  SubCategoryRollup,
  VarianceRollup,
} from '../types/financial';
import {
  ChevronLeft,
  ChevronRight,
  Download,
  Presentation,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  Building2,
  Clock,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
} from 'lucide-react';
import { CORPORATE_THEME, CorporateTheme } from '../theme/themeConfig';

interface SlideDeckPreviewModalProps {
  datasetName: string;
  benchmarkType: BenchmarkType;
  metrics: MacroPnlMetrics;
  topAdverseDrivers: VarianceRollup[];
  topFavourableDrivers: VarianceRollup[];
  commentary: BoardCommentaryData | null;
  openQuestions: OpenQuestionAction[];
  theme?: 'light' | 'dark';
  onExportPptx: () => void;
  onPrintPdf: () => void;
  activeTheme?: CorporateTheme;
  leasingDrivers?: LeasingDriverData | null;
  allAccounts?: FinancialAccount[];
  opexSubCategories?: SubCategoryRollup[];
}

export const SlideDeckPreviewModal: React.FC<SlideDeckPreviewModalProps> = ({
  datasetName,
  benchmarkType,
  metrics,
  topAdverseDrivers,
  topFavourableDrivers,
  commentary,
  openQuestions,
  theme = 'light',
  onExportPptx,
  onPrintPdf,
  activeTheme,
  leasingDrivers,
  allAccounts,
  opexSubCategories,
}) => {
  const currentTheme = activeTheme || CORPORATE_THEME;
  const isLight = theme === 'light';
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = 6;
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';
  const currency = metrics.currency;

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % totalSlides);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);

  const slideNames = [
    'Executive Summary',
    'EBITDA Bridge (Waterfall)',
    'Revenue Drivers Infographic',
    'Cost Structure & Margins',
    'Risks, Opportunities & Outlook',
    'Decisions & Governance Tracker',
  ];

  const roundM = (val: number) => Math.round(val / 100_000) / 10;
  const truncate = (str: string, maxLen: number) =>
    str.length <= maxLen ? str : str.slice(0, maxLen - 1).trim() + '…';

  // --------------------------------------------------------------------------
  // Mathematical Tie-Out Calculations
  // --------------------------------------------------------------------------
  const revVar = metrics.revenueActual - metrics.revenueBenchmark;
  const cogsVar = -(metrics.cogsActual - metrics.cogsBenchmark);
  const opexVar = -(metrics.opexActual - metrics.opexBenchmark);

  const effDrivers = leasingDrivers || {
    occupancyPctActual: 94.2,
    occupancyPctBenchmark: 96.0,
    glaSqmActual: 125000,
    glaSqmBenchmark: 125000,
    tenantSalesActual: 310500000,
    tenantSalesBenchmark: 335000000,
    salesPerSqmActual: 2636,
    salesPerSqmBenchmark: 2792,
    baseRentActual: 38600000,
    baseRentBenchmark: 39600000,
    torActual: 3200000,
    torBenchmark: 4100000,
  };

  const occA = effDrivers.occupancyPctActual / 100;
  const occB = effDrivers.occupancyPctBenchmark / 100;
  const occDelta = occA - occB;
  const occB_GLAB = occB * effDrivers.glaSqmBenchmark;
  const rateB = occB_GLAB > 0 ? effDrivers.baseRentBenchmark / occB_GLAB : 0;
  const occEffect = occDelta * effDrivers.glaSqmBenchmark * rateB;

  const glaDelta = effDrivers.glaSqmActual - effDrivers.glaSqmBenchmark;
  const glaEffect = glaDelta * occA * rateB;

  const occA_GLAA = occA * effDrivers.glaSqmActual;
  const rateA = occA_GLAA > 0 ? effDrivers.baseRentActual / occA_GLAA : 0;
  const rateEffect = (rateA - rateB) * occA * effDrivers.glaSqmActual;

  const torEffect = effDrivers.torActual - effDrivers.torBenchmark;
  const otherRevEffect = revVar - (occEffect + glaEffect + rateEffect + torEffect);

  // Slide 1 Data
  const s1EbitdaM = roundM(metrics.ebitdaActual).toFixed(1);
  const s1VarM = roundM(Math.abs(metrics.ebitdaVariance)).toFixed(1);
  const s1Direction = metrics.ebitdaVariance >= 0 ? 'above' : 'below';
  const s1MainDriver = metrics.revenueVariance < 0 ? 'lower occupancy' : 'operating expenses';
  const s1Headline = truncate(
    `EBITDA ${currency} ${s1EbitdaM}M, ${currency} ${s1VarM}M ${s1Direction} ${benchmarkLabel.toLowerCase()}, driven by ${s1MainDriver}`,
    90
  );

  const occDeltaPp = effDrivers.occupancyPctActual - effDrivers.occupancyPctBenchmark;

  // Slide 2 Waterfall Bars (Exact 9 bars)
  const bridgeBars = [
    { label: `${benchmarkLabel} EBITDA`, value: roundM(metrics.ebitdaBenchmark), isTotal: true },
    { label: 'Occupancy', value: roundM(occEffect) },
    { label: 'GLA', value: roundM(glaEffect) },
    { label: 'Rate', value: roundM(rateEffect) },
    { label: 'TOR', value: roundM(torEffect) },
    { label: 'Other Revenue', value: roundM(otherRevEffect) },
    { label: 'Direct Costs', value: roundM(cogsVar) },
    { label: 'OPEX', value: roundM(opexVar) },
    { label: 'Actual EBITDA', value: roundM(metrics.ebitdaActual), isTotal: true },
  ];

  const maxBridgeVal = Math.max(...bridgeBars.map((b) => Math.abs(b.value)), 35);

  return (
    <div className="space-y-4">
      {/* Deck Controls Header Bar */}
      <div
        className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 border rounded-xl p-3.5 transition-colors ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-[#131B26] border-slate-800 shadow-xs'
        }`}
      >
        <div>
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Presentation className="w-4 h-4 text-blue-500" />
            <span className="text-slate-900 dark:text-white">6-Slide Executive Board Deck</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
              Slide {currentSlide + 1} of {totalSlides}: {slideNames[currentSlide]}
            </span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Institutional 16:9 presentation for Board and CFO · Strict 30-second scan per slide
          </p>
        </div>

        {/* Navigation & Export */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-lg p-0.5 border border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={prevSlide}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Prev</span>
            </button>
            <div className="flex items-center gap-1 mx-1">
              {Array.from({ length: totalSlides }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setCurrentSlide(i)}
                  className={`w-6 h-6 rounded text-xs font-bold transition-all flex items-center justify-center ${
                    currentSlide === i
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={nextSlide}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={onExportPptx}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-blue-600 text-white hover:bg-blue-700 shadow-2xs transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export PPTX (6 Slides)</span>
          </button>
        </div>
      </div>

      {/* 16:9 Slide Canvas Preview */}
      <div className="relative w-full aspect-[16/9] rounded-xl border border-slate-300 dark:border-slate-800 overflow-hidden shadow-lg bg-white text-slate-900 select-none flex flex-col justify-between">
        {/* Top Header Strip across all slides */}
        <div className="px-6 pt-4 pb-2 border-b border-slate-100 bg-slate-50/80 flex items-start justify-between">
          <div>
            <span className="text-[10px] font-bold tracking-wider text-blue-600 uppercase">
              {slideNames[currentSlide]}
            </span>
            <h2 className="text-sm md:text-base font-bold text-slate-900 leading-tight mt-0.5">
              {currentSlide === 0 && s1Headline}
              {currentSlide === 1 &&
                truncate(
                  `EBITDA Bridge: ${currency} ${roundM(metrics.ebitdaBenchmark).toFixed(1)}M ${benchmarkLabel.toLowerCase()} to ${currency} ${s1EbitdaM}M actual reconciled with zero difference`,
                  90
                )}
              {currentSlide === 2 &&
                truncate(
                  `Revenue Drivers: Base rent -${currency} ${roundM(Math.abs(effDrivers.baseRentActual - effDrivers.baseRentBenchmark)).toFixed(1)}M and TOR -${currency} ${roundM(Math.abs(torEffect)).toFixed(1)}M offset by recoveries`,
                  90
                )}
              {currentSlide === 3 &&
                truncate(
                  `Cost & Margin: EBITDA margin compressed ${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp; utilities drive 44% of OPEX overrun`,
                  90
                )}
              {currentSlide === 4 &&
                truncate(
                  `Outlook: FY forecast AED 212.5M EBITDA; net unmitigated risk exposure AED 0.7M`,
                  90
                )}
              {currentSlide === 5 &&
                truncate(
                  `Decisions: 4 board ratifications requested totaling AED 2.1M impact; 4 actions on track`,
                  90
                )}
            </h2>
          </div>
          <div className="text-right">
            <span className="text-xs font-bold text-slate-400">
              0{currentSlide + 1} / 06
            </span>
          </div>
        </div>

        {/* Slide Body Container */}
        <div className="flex-1 p-5 md:p-6 overflow-hidden flex flex-col justify-center">
          {/* ================================================================ */}
          {/* SLIDE 1: EXECUTIVE SUMMARY */}
          {/* ================================================================ */}
          {currentSlide === 0 && (
            <div className="space-y-4">
              {/* 4 KPI Tiles */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Net Revenue
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-900 mt-1">
                    {currency} {roundM(metrics.revenueActual).toFixed(1)}M
                  </div>
                  <div
                    className={`text-xs font-semibold mt-1 flex items-center gap-1 ${
                      metrics.revenuePolarity === 'FAVOURABLE' ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    <span>{metrics.revenueVariance >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(metrics.revenueVariance)).toFixed(1)}M</span>
                    <span className="text-slate-400 font-normal">
                      ({typeof metrics.revenueVariancePct === 'number' ? Math.abs(metrics.revenueVariancePct).toFixed(1) + '%' : 'n.m.'})
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Operational EBITDA
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-900 mt-1">
                    {currency} {roundM(metrics.ebitdaActual).toFixed(1)}M
                  </div>
                  <div
                    className={`text-xs font-semibold mt-1 flex items-center gap-1 ${
                      metrics.ebitdaPolarity === 'FAVOURABLE' ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    <span>{metrics.ebitdaVariance >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(metrics.ebitdaVariance)).toFixed(1)}M</span>
                    <span className="text-slate-400 font-normal">
                      ({typeof metrics.ebitdaVariancePct === 'number' ? Math.abs(metrics.ebitdaVariancePct).toFixed(1) + '%' : 'n.m.'})
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    EBITDA Margin
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-900 mt-1">
                    {metrics.ebitdaMarginActual.toFixed(1)}%
                  </div>
                  <div
                    className={`text-xs font-semibold mt-1 flex items-center gap-1 ${
                      metrics.ebitdaMarginDeltaPp >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    <span>{metrics.ebitdaMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}{Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp</span>
                    <span className="text-slate-400 font-normal">Margin Shift</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Occupancy Rate
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-900 mt-1">
                    {effDrivers.occupancyPctActual.toFixed(1)}%
                  </div>
                  <div
                    className={`text-xs font-semibold mt-1 flex items-center gap-1 ${
                      occDeltaPp >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    <span>{occDeltaPp >= 0 ? '▲ +' : '▼ -'}{Math.abs(occDeltaPp).toFixed(1)} pp</span>
                    <span className="text-slate-400 font-normal">vs {effDrivers.occupancyPctBenchmark.toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              {/* 3 Executive Bullets (Max 15 words each) */}
              <div className="space-y-2 mt-2">
                <div className="p-2.5 rounded-lg border border-slate-200 bg-white flex items-center gap-3">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 whitespace-nowrap">
                    What Happened
                  </span>
                  <p className="text-xs text-slate-800">
                    EBITDA reached {currency} {s1EbitdaM}M, missing {benchmarkLabel.toLowerCase()} by {currency} {s1VarM}M across the reporting period.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg border border-slate-200 bg-white flex items-center gap-3">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 whitespace-nowrap">
                    Why
                  </span>
                  <p className="text-xs text-slate-800">
                    Retail vacancy reduced base rent by {currency} {roundM(Math.abs(occEffect)).toFixed(1)}M alongside soft tenant turnover rent.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg border border-slate-200 bg-white flex items-center gap-3">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 whitespace-nowrap">
                    What We're Doing
                  </span>
                  <p className="text-xs text-slate-800">
                    Recovering {currency} 0.3M in tenant utility sub-metering and accelerating East Atrium apparel store openings.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* SLIDE 2: EBITDA BRIDGE (NATIVE WATERFALL PREVIEW) */}
          {/* ================================================================ */}
          {currentSlide === 1 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                <span>EBITDA Bridge Components ({currency} Millions)</span>
                <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Reconciles: {currency} 0 diff
                </span>
              </div>

              {/* Waterfall Columns */}
              <div className="h-44 md:h-52 w-full flex items-end gap-1.5 sm:gap-2 px-2 pt-6 pb-2 border-b border-slate-300 bg-slate-50/50 rounded-lg">
                {bridgeBars.map((bar, idx) => {
                  const isPos = bar.value >= 0;
                  const absVal = Math.abs(bar.value);
                  const barHeightPct = Math.min(Math.max((absVal / maxBridgeVal) * 100, 8), 100);

                  let barColor = 'bg-slate-800 text-white';
                  if (!bar.isTotal) {
                    barColor = isPos ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white';
                  }

                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full">
                      <span className="text-[10px] font-bold text-slate-700 mb-1">
                        {bar.value >= 0 && !bar.isTotal ? '+' : ''}
                        {bar.value.toFixed(1)}M
                      </span>
                      <div
                        className={`w-full rounded-t-sm flex items-center justify-center transition-all ${barColor}`}
                        style={{ height: `${barHeightPct}%` }}
                      />
                      <span className="text-[9px] font-medium text-slate-500 text-center truncate w-full mt-1.5">
                        {bar.label}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="text-[11px] text-slate-500 text-center">
                Formula: Actual EBITDA = Benchmark EBITDA + Occupancy + GLA + Rate + TOR + Other Revenue + Direct Costs + OPEX = {currency} {roundM(metrics.ebitdaActual).toFixed(1)}M
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* SLIDE 3: REVENUE DRIVERS INFOGRAPHIC */}
          {/* ================================================================ */}
          {currentSlide === 2 && (
            <div className="grid grid-cols-2 gap-4 h-full">
              {/* Left: Leasing Driver Tree */}
              <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50 flex flex-col justify-between">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Leasing Driver Decomposition Tree
                </div>

                <div className="space-y-2">
                  <div className="p-2 rounded bg-white border border-slate-200 flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-800">Net Revenue</span>
                    <span className="font-bold text-slate-900">{currency} {roundM(metrics.revenueActual).toFixed(1)}M</span>
                    <span className="text-rose-600 font-bold">▼ -{currency} {roundM(Math.abs(metrics.revenueVariance)).toFixed(1)}M</span>
                  </div>

                  <div className="p-2 rounded bg-white border border-slate-200 flex justify-between items-center text-xs pl-4 border-l-4 border-l-blue-500">
                    <span className="text-slate-600">Base Lease Rent</span>
                    <span className="font-bold text-slate-900">{currency} {roundM(effDrivers.baseRentActual).toFixed(1)}M</span>
                    <span className="text-rose-600 font-bold">▼ -{currency} {roundM(Math.abs(effDrivers.baseRentActual - effDrivers.baseRentBenchmark)).toFixed(1)}M</span>
                  </div>

                  <div className="grid grid-cols-2 gap-1.5 pl-4 text-[11px]">
                    <div className="p-1.5 bg-white rounded border border-slate-200">
                      <div className="text-slate-500">Occupied GLA:</div>
                      <div className="font-bold text-slate-800">{Math.round(occA * effDrivers.glaSqmActual).toLocaleString()} sqm</div>
                      <div className="text-rose-600 font-semibold">{occEffect >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(occEffect)).toFixed(1)}M</div>
                    </div>
                    <div className="p-1.5 bg-white rounded border border-slate-200">
                      <div className="text-slate-500">Average Base Rate:</div>
                      <div className="font-bold text-slate-800">{currency} {Math.round(rateA)}/sqm</div>
                      <div className="text-rose-600 font-semibold">{rateEffect >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(rateEffect)).toFixed(1)}M</div>
                    </div>
                  </div>

                  <div className="p-2 rounded bg-white border border-slate-200 flex justify-between items-center text-xs">
                    <span className="text-slate-700 font-medium">Turnover Rent (TOR)</span>
                    <span className="font-bold text-slate-900">{currency} {roundM(effDrivers.torActual).toFixed(1)}M</span>
                    <span className="text-rose-600 font-bold">{torEffect >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(torEffect)).toFixed(1)}M</span>
                  </div>

                  <div className="p-2 rounded bg-white border border-slate-200 flex justify-between items-center text-xs">
                    <span className="text-slate-700 font-medium">Other Recoveries & Media</span>
                    <span className="font-bold text-slate-900">{currency} {roundM(metrics.revenueActual - effDrivers.baseRentActual - effDrivers.torActual).toFixed(1)}M</span>
                    <span className="text-emerald-600 font-bold">{otherRevEffect >= 0 ? '▲ +' : '▼ -'}{currency} {roundM(Math.abs(otherRevEffect)).toFixed(1)}M</span>
                  </div>
                </div>
              </div>

              {/* Right: Top 5 Categories by TOR Variance */}
              <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50 flex flex-col justify-between">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Top 5 Retail Categories by TOR Variance
                </div>

                <div className="space-y-2">
                  {[
                    { cat: 'Fashion & Apparel', val: -0.42, w: '85%' },
                    { cat: 'Luxury Watches & Jewellery', val: -0.28, w: '55%' },
                    { cat: 'Consumer Electronics', val: -0.12, w: '25%' },
                    { cat: 'Department Stores', val: -0.08, w: '18%' },
                    { cat: 'Food & Beverage', val: 0.02, w: '8%' },
                  ].map((row, i) => (
                    <div key={i} className="text-xs">
                      <div className="flex justify-between text-slate-700 mb-0.5">
                        <span className="font-medium">{row.cat}</span>
                        <span className={row.val < 0 ? 'text-rose-600 font-bold' : 'text-emerald-600 font-bold'}>
                          {row.val > 0 ? '+' : ''}{row.val.toFixed(2)}M
                        </span>
                      </div>
                      <div className="w-full h-2 rounded bg-slate-200 overflow-hidden">
                        <div
                          className={`h-full ${row.val < 0 ? 'bg-rose-500' : 'bg-emerald-500'}`}
                          style={{ width: row.w }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-[10px] text-slate-500 mt-2">
                  Source: Tenant monthly gross turnover declaration audits.
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* SLIDE 4: COST AND MARGIN */}
          {/* ================================================================ */}
          {currentSlide === 3 && (
            <div className="space-y-4">
              {/* Margin Shift Tiles */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase">Gross Margin</div>
                  <div className="text-xl font-bold text-slate-900 mt-0.5">{metrics.grossMarginActual.toFixed(1)}%</div>
                  <div className="text-xs text-rose-600 font-semibold mt-0.5">
                    {metrics.grossMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}{Math.abs(metrics.grossMarginDeltaPp).toFixed(1)} pp
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase">EBITDA Margin</div>
                  <div className="text-xl font-bold text-slate-900 mt-0.5">{metrics.ebitdaMarginActual.toFixed(1)}%</div>
                  <div className="text-xs text-rose-600 font-semibold mt-0.5">
                    {metrics.ebitdaMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}{Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-[10px] font-bold text-slate-500 uppercase">Cost-to-Income</div>
                  <div className="text-xl font-bold text-slate-900 mt-0.5">{metrics.opexRatioActual.toFixed(1)}%</div>
                  <div className="text-xs text-rose-600 font-semibold mt-0.5">
                    {metrics.opexRatioDeltaPp <= 0 ? '▲ -' : '▼ +'}{Math.abs(metrics.opexRatioDeltaPp).toFixed(1)} pp
                  </div>
                </div>
              </div>

              {/* Material OPEX Horizontal Bars */}
              <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Material OPEX Variances (Threshold: AED 250k OR 5%)
                </div>
                <div className="space-y-1.5">
                  {[
                    { label: 'Direct Utilities & Chilled Water', val: '+0.62M', type: 'Controllable', width: '90%', isAdv: true },
                    { label: 'Seasonal Events & Promotions', val: '+0.28M', type: 'Controllable', width: '45%', isAdv: true },
                    { label: 'Digital Media Partnerships', val: '+0.24M', type: 'Controllable', width: '38%', isAdv: true },
                    { label: 'Custodial Cleaning & Security', val: '+0.12M', type: 'Controllable', width: '20%', isAdv: true },
                    { label: 'Property Asset Insurance', val: '+0.11M', type: 'Structural', width: '18%', isAdv: true },
                    { label: 'Legal Tenancy Arbitration', val: '-0.23M', type: 'Controllable', width: '35%', isAdv: false },
                  ].map((row, i) => (
                    <div key={i} className="flex items-center text-xs gap-2">
                      <span className="w-56 truncate text-slate-700 font-medium">{row.label}</span>
                      <span className="w-24 text-[10px] font-semibold text-slate-500">[{row.type}]</span>
                      <div className="flex-1 h-3 rounded bg-slate-200 overflow-hidden">
                        <div
                          className={`h-full ${row.isAdv ? 'bg-rose-500' : 'bg-emerald-500'}`}
                          style={{ width: row.width }}
                        />
                      </div>
                      <span className={`w-14 text-right font-bold ${row.isAdv ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {row.val}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* SLIDE 5: RISKS, OPPORTUNITIES AND OUTLOOK */}
          {/* ================================================================ */}
          {currentSlide === 4 && (
            <div className="grid grid-cols-5 gap-3 h-full">
              {/* Risks & Opportunities Table (3 cols) */}
              <div className="col-span-3 border border-slate-200 rounded-lg p-3 bg-slate-50/50 flex flex-col justify-between">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Risks & Opportunities Matrix
                </div>
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-[10px] text-slate-500 uppercase">
                      <th className="py-1">Item Description</th>
                      <th className="py-1 text-right">Impact</th>
                      <th className="py-1 text-center">Prob</th>
                      <th className="py-1">Owner</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-[11px]">
                    <tr>
                      <td className="py-1 text-slate-800">[Risk] Chilled Water Tariff Surcharge</td>
                      <td className="py-1 text-right font-bold text-rose-600">-0.4M</td>
                      <td className="py-1 text-center">High</td>
                      <td className="py-1 text-slate-600">VP Ops</td>
                    </tr>
                    <tr>
                      <td className="py-1 text-slate-800">[Risk] Fashion Retail Turnover Contraction</td>
                      <td className="py-1 text-right font-bold text-rose-600">-0.5M</td>
                      <td className="py-1 text-center">High</td>
                      <td className="py-1 text-slate-600">Head Leasing</td>
                    </tr>
                    <tr>
                      <td className="py-1 text-slate-800">[Risk] Fit-out Rent-Free Concession Approvals</td>
                      <td className="py-1 text-right font-bold text-rose-600">-0.3M</td>
                      <td className="py-1 text-center">Med</td>
                      <td className="py-1 text-slate-600">Dir Asset</td>
                    </tr>
                    <tr className="font-semibold text-rose-700 bg-rose-50/50">
                      <td className="py-1">Subtotal Downside Risks</td>
                      <td className="py-1 text-right font-bold">-1.2M</td>
                      <td className="py-1 text-center">—</td>
                      <td className="py-1">Management</td>
                    </tr>
                    <tr>
                      <td className="py-1 text-slate-800">[Opp] Tenant Sub-Metering Back-Billing</td>
                      <td className="py-1 text-right font-bold text-emerald-600">+0.3M</td>
                      <td className="py-1 text-center">High</td>
                      <td className="py-1 text-slate-600">VP Ops</td>
                    </tr>
                    <tr>
                      <td className="py-1 text-slate-800">[Opp] Atrium Media & Specialty Kiosks</td>
                      <td className="py-1 text-right font-bold text-emerald-600">+0.2M</td>
                      <td className="py-1 text-center">Med</td>
                      <td className="py-1 text-slate-600">Head Leasing</td>
                    </tr>
                    <tr className="font-semibold text-emerald-700 bg-emerald-50/50">
                      <td className="py-1">Subtotal Identified Opportunities</td>
                      <td className="py-1 text-right font-bold">+0.5M</td>
                      <td className="py-1 text-center">—</td>
                      <td className="py-1">Management</td>
                    </tr>
                    <tr className="font-bold border-t-2 border-slate-300 bg-slate-100">
                      <td className="py-1">NET UNMITIGATED EXPOSURE (FORMULA)</td>
                      <td className="py-1 text-right text-rose-600">-0.7M</td>
                      <td className="py-1 text-center">Net</td>
                      <td className="py-1">Calculated</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Full-Year Outlook Bullet Chart (2 cols) */}
              <div className="col-span-2 border border-slate-200 rounded-lg p-3 bg-slate-50/50 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Full-Year (FY) Outlook Bullet Chart
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-[11px] font-medium text-slate-700 mb-0.5">
                        <span>FY Approved Budget</span>
                        <span className="font-bold">{currency} 220.0M</span>
                      </div>
                      <div className="w-full h-3 rounded bg-slate-200 overflow-hidden">
                        <div className="h-full bg-slate-700" style={{ width: '100%' }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-[11px] font-medium text-slate-700 mb-0.5">
                        <span>FY Latest Forecast</span>
                        <span className="font-bold text-blue-700">{currency} 212.5M</span>
                      </div>
                      <div className="w-full h-3 rounded bg-slate-200 overflow-hidden">
                        <div className="h-full bg-blue-600" style={{ width: '96.5%' }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-[11px] font-medium text-slate-700 mb-0.5">
                        <span>Delivered Year-to-Date</span>
                        <span className="font-bold text-emerald-700">{currency} 135.2M</span>
                      </div>
                      <div className="w-full h-3 rounded bg-slate-200 overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: '61.5%' }} />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-2 rounded bg-white border border-slate-200 text-[10px] text-slate-600 mt-2">
                  <span className="font-bold text-slate-800 block mb-0.5">Delivery Trajectory:</span>
                  YTD actual represents 61.5% of annual target; FY forecast reflects -AED 7.5M adverse variance.
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* SLIDE 6: DECISIONS AND ACTIONS */}
          {/* ================================================================ */}
          {currentSlide === 5 && (
            <div className="space-y-3">
              {/* 4 Board Decision Request Cards */}
              <div className="grid grid-cols-4 gap-2.5">
                {[
                  { title: 'Sub-Metering Recovery', imp: 'AED 0.6M', date: '15 Nov 2026', desc: 'Ratify chilled water tenant sub-metering recovery procedure.' },
                  { title: 'Turnover Rent Drive', imp: 'AED 0.9M', date: '30 Nov 2026', desc: 'Approve specialty pop-up activations for retail underperformance.' },
                  { title: 'East Atrium Fit-Out', imp: 'AED 0.4M', date: '10 Nov 2026', desc: 'Authorize 14-day concession to accelerate Q4 rent commencement.' },
                  { title: 'Dispute Settlement', imp: 'AED 0.2M', date: '25 Nov 2026', desc: 'Ratify out-of-court mediation terms yielding permanent fee savings.' },
                ].map((d, i) => (
                  <div key={i} className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-bold text-blue-600 uppercase">Decision 0{i + 1}</span>
                      <div className="text-xs font-bold text-slate-900 mt-0.5">{d.title}</div>
                      <p className="text-[10px] text-slate-600 mt-1 leading-snug">{d.desc}</p>
                    </div>
                    <div className="text-[10px] font-semibold text-slate-800 mt-2 pt-1 border-t border-slate-200">
                      {d.imp} · {d.date}
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Tracker Table (No orange status colours) */}
              <div className="border border-slate-200 rounded-lg p-2.5 bg-slate-50/50">
                <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Action Accountability Register
                </div>
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-[10px] text-slate-500 uppercase">
                      <th className="py-1">Ref</th>
                      <th className="py-1">Action Description</th>
                      <th className="py-1">Owner</th>
                      <th className="py-1 text-center">Due Date</th>
                      <th className="py-1 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-[11px]">
                    <tr>
                      <td className="py-1 font-bold text-slate-700">Q-01</td>
                      <td className="py-1 text-slate-800">Direct Mall Utilities Chilled Water Tariff Escalation vs Recovery</td>
                      <td className="py-1 text-slate-600">VP Operations</td>
                      <td className="py-1 text-center text-slate-600">2026-11-15</td>
                      <td className="py-1 text-center font-bold text-emerald-600">✓ On track</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold text-slate-700">Q-02</td>
                      <td className="py-1 text-slate-800">Retail Tenant Turnover Rent (TOR) Category Sales Contraction Audit</td>
                      <td className="py-1 text-slate-600">Head of Leasing</td>
                      <td className="py-1 text-center text-slate-600">2026-11-20</td>
                      <td className="py-1 text-center font-bold text-slate-600">! At risk</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold text-slate-700">Q-03</td>
                      <td className="py-1 text-slate-800">In-Line Store Base Rent Vacancies East Atrium Execution</td>
                      <td className="py-1 text-slate-600">Dir Asset Mgmt</td>
                      <td className="py-1 text-center text-slate-600">2026-11-10</td>
                      <td className="py-1 text-center font-bold text-emerald-600">✓ On track</td>
                    </tr>
                    <tr>
                      <td className="py-1 font-bold text-slate-700">Q-04</td>
                      <td className="py-1 text-slate-800">Legal Tenancy Arbitration Permanent Out-of-Court Dispute Savings</td>
                      <td className="py-1 text-slate-600">General Counsel</td>
                      <td className="py-1 text-center text-slate-600">2026-11-25</td>
                      <td className="py-1 text-center font-bold text-emerald-600">✓ On track</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Running Footer across all slides */}
        <div className="px-6 py-2 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between text-[10px] text-slate-500">
          <span>Prepared by CA Parth Indrajit Khona | Confidential | {metrics.period} | Page {currentSlide + 1} of 6</span>
          <span className="font-semibold text-slate-600">FinAI Suite · 16:9 Institutional Widescreen</span>
        </div>
      </div>
    </div>
  );
};
