import React from 'react';
import { BenchmarkType, MacroPnlMetrics } from '../types/financial';
import { formatCurrencyM, formatPpDelta } from '../utils/financialEngine';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface KpiScorecardProps {
  metrics: MacroPnlMetrics;
  benchmarkType: BenchmarkType;
  theme?: 'light' | 'dark';
}

export const KpiScorecard: React.FC<KpiScorecardProps> = ({
  metrics,
  benchmarkType,
  theme = 'light',
}) => {
  const isLight = theme === 'light';
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';
  const currency = metrics.currency;

  const cards = [
    {
      label: 'Gross Commercial Revenue',
      actual: formatCurrencyM(metrics.grossRevenueActual, currency),
      benchmark: formatCurrencyM(metrics.grossRevenueBenchmark, currency),
      varianceDollar: metrics.grossRevenueVariance,
      displayVariance:
        typeof metrics.grossRevenueVariancePct === 'number'
          ? `${Math.abs(metrics.grossRevenueVariancePct).toFixed(1)}%`
          : 'n.m.',
      polarity: metrics.grossRevenuePolarity,
      subtext: `${benchmarkLabel}: ${formatCurrencyM(metrics.grossRevenueBenchmark, currency)}`,
    },
    {
      label: 'Net Revenue (Excl. Concessions)',
      actual: formatCurrencyM(metrics.revenueActual, currency),
      benchmark: formatCurrencyM(metrics.revenueBenchmark, currency),
      varianceDollar: metrics.revenueVariance,
      displayVariance:
        typeof metrics.revenueVariancePct === 'number'
          ? `${Math.abs(metrics.revenueVariancePct).toFixed(1)}%`
          : 'n.m.',
      polarity: metrics.revenuePolarity,
      subtext: `Contra: ${formatCurrencyM(metrics.contraRevenueActual, currency)}`,
    },
    {
      label: 'Gross Profit & Margin',
      actual: `${metrics.grossMarginActual.toFixed(1)}%`,
      benchmark: `${metrics.grossMarginBenchmark.toFixed(1)}%`,
      varianceDollar: metrics.grossProfitVariance,
      displayVariance: `${Math.abs(metrics.grossMarginDeltaPp).toFixed(1)} pp`,
      polarity: metrics.grossProfitPolarity,
      subtext: `GP: ${formatCurrencyM(metrics.grossProfitActual, currency)}`,
      isMargin: true,
    },
    {
      label: 'Operational EBITDA',
      actual: formatCurrencyM(metrics.ebitdaActual, currency),
      benchmark: formatCurrencyM(metrics.ebitdaBenchmark, currency),
      varianceDollar: metrics.ebitdaVariance,
      displayVariance: `${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp`,
      polarity: metrics.ebitdaPolarity,
      subtext: `Margin: ${metrics.ebitdaMarginActual.toFixed(1)}% (${formatPpDelta(metrics.ebitdaMarginDeltaPp)})`,
      isMargin: true,
    },
    {
      label: 'Net Profit After Tax',
      actual: formatCurrencyM(metrics.netProfitActual, currency),
      benchmark: formatCurrencyM(metrics.netProfitBenchmark, currency),
      varianceDollar: metrics.netProfitVariance,
      displayVariance: `${Math.abs(metrics.netMarginDeltaPp).toFixed(1)} pp`,
      polarity: metrics.netProfitPolarity,
      subtext: `Net Margin: ${metrics.netMarginActual.toFixed(1)}%`,
      isMargin: true,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
      {cards.map((card, idx) => {
        const isFav = card.polarity === 'FAVOURABLE';
        const isAdv = card.polarity === 'ADVERSE';
        const symbol = isFav ? '▲ +' : isAdv ? '▼ -' : '— ';

        return (
          <div
            key={idx}
            className={`rounded-xl p-4 flex flex-col justify-between border transition-all ${
              isLight
                ? 'bg-white border-[#E2E8F0] shadow-2xs hover:border-slate-400'
                : 'bg-[#131B26] border-[#1E293B] shadow-2xs hover:border-slate-700'
            }`}
          >
            <div>
              <div
                className={`text-xs font-semibold mb-1 tracking-wide ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                {card.label}
              </div>
              <div
                className={`text-2xl font-bold tabular-nums tracking-tight ${
                  isLight ? 'text-[#0F172A]' : 'text-white'
                }`}
              >
                {card.actual}
              </div>
            </div>

            <div
              className={`mt-3 pt-2.5 border-t flex items-center justify-between text-xs ${
                isLight ? 'border-slate-100' : 'border-slate-800'
              }`}
            >
              <span
                className={`tabular-nums text-[11px] truncate max-w-[125px] ${
                  isLight ? 'text-slate-500' : 'text-slate-400'
                }`}
              >
                {card.subtext}
              </span>
              <div
                className={`flex items-center gap-1 font-bold tabular-nums ${
                  isFav
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : isAdv
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-slate-400'
                }`}
              >
                <span>{symbol}</span>
                <span>{card.displayVariance}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
