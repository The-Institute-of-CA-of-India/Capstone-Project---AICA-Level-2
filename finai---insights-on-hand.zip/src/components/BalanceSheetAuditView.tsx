import React from 'react';
import { BalanceSheetValidationCheck, FinancialAccount } from '../types/financial';
import { formatCurrency, PREPARED_BY_FOOTNOTE } from '../utils/financialEngine';
import { ShieldCheck, ShieldAlert, CheckCircle2, Lock, Scale, ArrowRightLeft } from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface BalanceSheetAuditViewProps {
  check: BalanceSheetValidationCheck;
  allAccounts: FinancialAccount[];
  theme?: 'light' | 'dark';
}

export const BalanceSheetAuditView: React.FC<BalanceSheetAuditViewProps> = ({
  check,
  allAccounts,
  theme = 'light',
}) => {
  const isLight = theme === 'light';
  const bsAccounts = allAccounts.filter((a) => a.isBalanceSheet);

  return (
    <div className="space-y-6">
      {/* Top Status Card */}
      <div
        className={`rounded-xl p-5 border shadow-xs transition-colors ${
          isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                check.statusText === 'System check passed'
                  ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-600 border border-rose-500/30'
              }`}
            >
              {check.statusText === 'System check passed' ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider text-slate-500 font-bold block">
                Financial Controls Verification
              </span>
              <h2 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                Balance Sheet Isolation & Accounting Tie-Out Proof
              </h2>
            </div>
          </div>

          <div>
            <span
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold ${
                check.statusText === 'System check passed'
                  ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                  : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{check.statusText.toUpperCase()}</span>
            </span>
          </div>
        </div>

        {/* The 2 Core Balance Sheet Tests */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Test 1: Balance Check (Debits - Credits = 0) */}
          <div
            className={`p-4 rounded-lg border ${
              check.debitCreditCheck.passed
                ? 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-300 dark:border-rose-800'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-blue-500" />
                <span>Test 1: Balance Check</span>
              </span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                  check.debitCreditCheck.passed
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                }`}
              >
                {check.debitCreditCheck.passed ? 'System check passed' : 'System check failed'}
              </span>
            </div>

            <p className="font-mono text-xs text-slate-600 dark:text-slate-400">
              Total Debits − Total Credits = 0
            </p>

            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Total Debits:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {formatCurrency(check.debitCreditCheck.totalDebits)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Total Credits:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {formatCurrency(check.debitCreditCheck.totalCredits)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Exact Diff:</span>
                <span
                  className={`font-mono font-bold ${
                    check.debitCreditCheck.passed ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {formatCurrency(check.debitCreditCheck.difference)}
                </span>
              </div>
            </div>
          </div>

          {/* Test 2: P&L-to-BS Tie-Out */}
          <div
            className={`p-4 rounded-lg border ${
              check.pnlTieOutCheck.passed
                ? 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-300 dark:border-rose-800'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <ArrowRightLeft className="w-4 h-4 text-blue-500" />
                <span>Test 2: P&L-to-BS Tie-Out</span>
              </span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                  check.pnlTieOutCheck.passed
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                }`}
              >
                {check.pnlTieOutCheck.passed ? 'System check passed' : 'System check failed'}
              </span>
            </div>

            <p className="font-mono text-xs text-slate-600 dark:text-slate-400">
              Net Profit (P&L) = Movement in Retained Earnings
            </p>

            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">P&L Net Profit:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {formatCurrency(check.pnlTieOutCheck.netProfitPnl)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Retained Earnings:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {formatCurrency(check.pnlTieOutCheck.retainedEarningsDelta)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Exact Diff:</span>
                <span
                  className={`font-mono font-bold ${
                    check.pnlTieOutCheck.passed ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {formatCurrency(check.pnlTieOutCheck.difference)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Breakdown Cards */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
            <span className="text-slate-500 font-semibold block">Assets Excluded (1000s):</span>
            <span className="text-lg font-bold font-mono text-slate-900 dark:text-white block mt-1">
              {formatCurrency(check.assetDebitSum)}
            </span>
            <span className="text-slate-400 text-[11px] block mt-0.5">Debit balances segregated</span>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
            <span className="text-slate-500 font-semibold block">Liabilities Excluded (2000s):</span>
            <span className="text-lg font-bold font-mono text-slate-900 dark:text-white block mt-1">
              {formatCurrency(check.liabilityCreditSum)}
            </span>
            <span className="text-slate-400 text-[11px] block mt-0.5">Credit balances segregated</span>
          </div>

          <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
            <span className="text-slate-500 font-semibold block">Equity Accounts (3000s):</span>
            <span className="text-lg font-bold font-mono text-slate-900 dark:text-white block mt-1">
              {formatCurrency(check.equityCreditSum)}
            </span>
            <span className="text-slate-400 text-[11px] block mt-0.5">Capital & Retained Earnings</span>
          </div>
        </div>
      </div>

      {/* Table of Excluded Accounts */}
      <div
        className={`rounded-xl border shadow-xs overflow-hidden transition-colors ${
          isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
        }`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Excluded Balance Sheet Accounts Register ({bsAccounts.length} Total Accounts)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Verified as 100% isolated from Operational EBITDA, COGS, and OPEX totals.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr
                className={`border-b font-bold text-[11px] uppercase tracking-wider ${
                  isLight ? 'bg-slate-50 text-slate-600' : 'bg-slate-900 text-slate-400'
                }`}
              >
                <th className="py-2.5 px-3 w-20">Code</th>
                <th className="py-2.5 px-3">Account Description</th>
                <th className="py-2.5 px-3 w-40">Subcategory</th>
                <th className="py-2.5 px-3 text-right w-36">Actual Balance</th>
                <th className="py-2.5 px-3 w-44">Isolation Verification</th>
              </tr>
            </thead>
            <tbody>
              {bsAccounts.map((acc) => (
                <tr
                  key={acc.code}
                  className={`border-b transition-colors ${
                    isLight ? 'border-slate-100 hover:bg-slate-50' : 'border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-500">{acc.code}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800 dark:text-slate-200">
                    {acc.name}
                  </td>
                  <td className="py-2.5 px-3 text-slate-500">{acc.subCategory}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold">
                    {formatCurrency(acc.actual)}
                  </td>
                  <td className="py-2.5 px-3 text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Isolated from P&L</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="pt-2 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 border-t border-slate-200 dark:border-slate-800">
        <span className="font-medium">{PREPARED_BY_FOOTNOTE}</span>
        <span className="font-mono text-[11px]">Balance Sheet Reconciled · Difference = 0.00 AED</span>
      </div>
    </div>
  );
};
