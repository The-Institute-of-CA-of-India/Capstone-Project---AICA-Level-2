import React from 'react';
import { BenchmarkType, VarianceRollup } from '../types/financial';
import { formatCurrency } from '../utils/financialEngine';
import { X } from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface AccountDetailModalProps {
  account: VarianceRollup | null;
  benchmarkType: BenchmarkType;
  theme?: 'light' | 'dark';
  onClose: () => void;
}

export const AccountDetailModal: React.FC<AccountDetailModalProps> = ({
  account,
  benchmarkType,
  theme = 'light',
  onClose,
}) => {
  if (!account) return null;

  const isLight = theme === 'light';
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';
  const isFav = account.polarity === 'FAVOURABLE';
  const isAdv = account.polarity === 'ADVERSE';
  const symbol = isFav ? '▲ +' : isAdv ? '▼ -' : '— ';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`border rounded-xl w-full max-w-lg overflow-hidden shadow-2xl transition-colors ${
          isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#131B26] border-slate-800 text-white'
        }`}
      >
        {/* Header */}
        <div
          className={`px-5 py-3.5 border-b flex items-center justify-between ${
            isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div>
            <div className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">
              GL Account Drilldown · {account.code}
            </div>
            <h3 className="text-sm font-bold mt-0.5">{account.name}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs tabular-nums">
          <div className="grid grid-cols-2 gap-3">
            <div
              className={`p-3 rounded-lg border ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <span className="block text-[10px] font-semibold text-slate-400 uppercase">
                Actual Balance
              </span>
              <span className="text-lg font-bold block mt-0.5">
                {formatCurrency(account.actual)}
              </span>
            </div>
            <div
              className={`p-3 rounded-lg border ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              <span className="block text-[10px] font-semibold text-slate-400 uppercase">
                {benchmarkLabel} Baseline
              </span>
              <span className="text-lg font-bold block mt-0.5 text-slate-500">
                {formatCurrency(account.benchmark)}
              </span>
            </div>
          </div>

          <div
            className={`p-3.5 rounded-lg border space-y-2 ${
              isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900/60 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Dollar Variance:</span>
              <span
                className={`font-bold tabular-nums ${
                  isFav
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : isAdv
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-slate-500'
                }`}
              >
                {symbol}
                {formatCurrency(Math.abs(account.dollarVariance))}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Percentage Variance:</span>
              <span
                className={`font-bold tabular-nums ${
                  isFav
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : isAdv
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-slate-500'
                }`}
              >
                {account.displayPct === 'n.m.' ? '— n.m.' : `${symbol}${account.displayPct.replace(/^[+-]/, '')}`}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Controllability:</span>
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                {account.controllable ? 'Controllable (Operational)' : 'Non-controllable (Structural)'}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Category Contribution:</span>
              <span className="font-bold tabular-nums">
                {Math.abs(account.driverContributionPct).toFixed(1)}%
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
              <span className="text-slate-500 font-medium">Directional Polarity:</span>
              <span
                className={`font-bold uppercase ${
                  isFav
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : isAdv
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-slate-500'
                }`}
              >
                {isFav ? '▲ Favourable' : isAdv ? '▼ Adverse' : '— Neutral'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
