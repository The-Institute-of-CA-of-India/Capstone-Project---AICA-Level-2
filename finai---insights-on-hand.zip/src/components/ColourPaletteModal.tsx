import React, { useState } from 'react';
import { X, Check, Palette, Sparkles, FileSpreadsheet, Presentation, FileText, RefreshCw, Award, Info } from 'lucide-react';
import { CorporateTheme, CORPORATE_PALETTES } from '../theme/themeConfig';

interface ColourPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTheme: CorporateTheme;
  onSelectTheme: (theme: CorporateTheme) => void;
}

export const ColourPaletteModal: React.FC<ColourPaletteModalProps> = ({
  isOpen,
  onClose,
  activeTheme,
  onSelectTheme,
}) => {
  const [selectedId, setSelectedId] = useState(activeTheme.id || 'hermes-luxury');
  const [customPrimary, setCustomPrimary] = useState(activeTheme.colors.primary);
  const [customAccent, setCustomAccent] = useState(activeTheme.colors.accent);

  if (!isOpen) return null;

  const currentTheme = CORPORATE_PALETTES[selectedId] || activeTheme;

  const handleApplyPreset = (theme: CorporateTheme) => {
    setSelectedId(theme.id);
    setCustomPrimary(theme.colors.primary);
    setCustomAccent(theme.colors.accent);
    onSelectTheme(theme);
  };

  const handleApplyCustom = () => {
    const updatedTheme: CorporateTheme = {
      ...currentTheme,
      name: `${currentTheme.name} (Customised)`,
      colors: {
        ...currentTheme.colors,
        primary: customPrimary,
        accent: customAccent,
      },
      excel: {
        ...currentTheme.excel,
        headerFill: `FF${customPrimary.replace('#', '')}`,
      },
      pptx: {
        ...currentTheme.pptx,
        primary: customPrimary.replace('#', ''),
        accent: customAccent.replace('#', ''),
      },
    };
    onSelectTheme(updatedTheme);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white dark:bg-[#181412] border border-[#CBD5E1] dark:border-[#3B2F2A] rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto text-[#0F172A] dark:text-[#F8FAFC]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0] dark:border-[#3B2F2A]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#FF6600] text-white flex items-center justify-center font-bold text-lg shadow-sm">
              H
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight">Institutional Colour Palette & Theme Manager</h2>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-orange-500/10 text-[#FF6600] border border-orange-500/20">
                  Brand Guidelines Spec
                </span>
              </div>
              <p className="text-xs text-[#64748B] dark:text-[#9CA3AF]">
                Centralised corporate brand palette for Web UI, Excel models, Board slides, and PDF dossiers.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#64748B] hover:text-[#0F172A] dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Active Palette Overview */}
          <div className="p-4 rounded-xl bg-[#F8F6F1] dark:bg-[#201A17] border border-[#E5E7EB] dark:border-[#3B2F2A]">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div>
                <span className="text-[10px] font-extrabold tracking-wider uppercase text-[#FF6600]">
                  Currently Active Palette
                </span>
                <h3 className="text-base font-bold">{activeTheme.name}</h3>
                <p className="text-xs text-[#64748B] dark:text-[#9CA3AF] mt-0.5">
                  {activeTheme.description || 'Verified corporate configuration'}
                </p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
                <Check className="w-3.5 h-3.5" />
                <span>Live Across Web, Excel, PPTX, PDF</span>
              </div>
            </div>

            {/* Core Swatches Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 pt-2">
              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.primary }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Primary</span>
                <span className="text-[11px] font-mono font-bold block text-[#FF6600] truncate">{activeTheme.colors.primary}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.secondary }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Ébène</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.secondary}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.accent }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Or Gold</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.accent}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs flex items-center justify-center text-white font-bold text-xs" style={{ backgroundColor: activeTheme.colors.favourable }}>
                  ▲ +
                </div>
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Favourable</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.favourable}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs flex items-center justify-center text-white font-bold text-xs" style={{ backgroundColor: activeTheme.colors.adverse }}>
                  ▼ -
                </div>
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Adverse</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.adverse}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.surfaceLight }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Ivoire</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.surfaceLight}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.surfaceDark }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Anthracite</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.surfaceDark}</span>
              </div>

              <div className="p-2 rounded-md bg-white dark:bg-[#151210] border border-[#E5E7EB] dark:border-[#3B2F2A]">
                <div className="w-full h-8 rounded mb-1.5 border border-black/10 shadow-2xs" style={{ backgroundColor: activeTheme.colors.border }} />
                <span className="text-[9px] font-bold block uppercase text-[#64748B] truncate">Border</span>
                <span className="text-[11px] font-mono font-bold block truncate">{activeTheme.colors.border}</span>
              </div>
            </div>
          </div>

          {/* Official Artifact Reference Callout */}
          <div className="p-4 rounded-xl border border-orange-300 dark:border-orange-900/50 bg-gradient-to-r from-orange-500/10 via-amber-500/5 to-transparent">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-[#FF6600] text-white shrink-0 mt-0.5 shadow-xs">
                <Award className="w-5 h-5" />
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-[#0F172A] dark:text-white">
                    H Brand Heritage (Referenced from Artifact Guidelines)
                  </h4>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#FF6600] text-white">
                    Verified Match
                  </span>
                </div>
                <p className="text-[#64748B] dark:text-[#9CA3AF]">
                  Extracted from <code className="font-mono text-[#FF6600]">media_1793295521012_a3e97650.png</code> in artifacts:
                  "H Orange #FF6600 (Signature colour), Ébène #3B2F2A (Luxury & refinement), Gris Perle #C9C4BC, Ivoire #F8F6F1, Anthracite #1F1F1F, Or #D4AF37."
                </p>
                <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px]">
                  <span><strong>Typography:</strong> Playfair Display (Titles) / Inter (Body & UI)</span>
                  <span><strong>Brand Personality:</strong> Timeless, Elegant, Craftsmanship, Authentic, Exclusive</span>
                </div>
              </div>
            </div>
          </div>

          {/* Available Corporate Theme Presets */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#64748B] dark:text-[#9CA3AF] mb-3">
              Corporate Theme Presets (Click any card to immediately switch system palette)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.values(CORPORATE_PALETTES).map((pal) => {
                const isSelected = activeTheme.id === pal.id;
                const isPalHermes = pal.id === 'hermes-luxury';

                return (
                  <button
                    key={pal.id}
                    onClick={() => handleApplyPreset(pal)}
                    className={`p-4 rounded-xl border text-left transition-all relative ${
                      isSelected
                        ? isPalHermes
                          ? 'border-[#FF6600] bg-orange-50/50 dark:bg-orange-950/20 shadow-md ring-2 ring-[#FF6600]/40'
                          : 'border-blue-600 dark:border-blue-500 bg-blue-50/40 dark:bg-blue-950/20 shadow-xs ring-1 ring-blue-500'
                        : 'border-[#E2E8F0] dark:border-[#3B2F2A] hover:border-[#FF6600] bg-white dark:bg-[#1E1917]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold">{pal.name}</span>
                        {isPalHermes && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#FF6600] text-white">
                            Default
                          </span>
                        )}
                      </div>
                      {isSelected && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#FF6600] text-white flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>Active</span>
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#64748B] dark:text-[#9CA3AF] mb-3 line-clamp-2">
                      {pal.description}
                    </p>
                    {/* Swatches preview */}
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10" style={{ backgroundColor: pal.colors.primary }} title="Primary" />
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10" style={{ backgroundColor: pal.colors.secondary }} title="Secondary" />
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10" style={{ backgroundColor: pal.colors.accent }} title="Accent" />
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10 flex items-center justify-center text-white text-[9px] font-bold" style={{ backgroundColor: pal.colors.favourable }} title="Favourable ▲ +">
                        ▲
                      </div>
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10 flex items-center justify-center text-white text-[9px] font-bold" style={{ backgroundColor: pal.colors.adverse }} title="Adverse ▼ -">
                        ▼
                      </div>
                      <div className="w-6 h-6 rounded-md shadow-2xs border border-black/10" style={{ backgroundColor: pal.colors.surfaceLight }} title="Surface" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Export Deliverables Palette Mapping */}
          <div className="p-4 rounded-xl bg-[#F8FAFC] dark:bg-[#1E1917] border border-[#E2E8F0] dark:border-[#3B2F2A]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#64748B] dark:text-[#9CA3AF] mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#FF6600]" />
              <span>Multi-Format Deliverables Palette Integration</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-white dark:bg-[#151210] border border-[#E2E8F0] dark:border-[#3B2F2A]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5 text-[#FF6600]">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Excel Workbook (.xlsx)</span>
                </div>
                <ul className="space-y-1 text-[11px] text-[#64748B] dark:text-[#9CA3AF]">
                  <li>Header Fill: <code className="font-mono text-[#FF6600] font-bold">{activeTheme.excel.headerFill}</code></li>
                  <li>Subheader Fill: <code className="font-mono">{activeTheme.excel.subHeaderFill}</code></li>
                  <li>Grid Border: <code className="font-mono">{activeTheme.excel.borderGrid}</code></li>
                  <li>Accounting Format: <code className="font-mono">_(* #,##0_)</code></li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-[#151210] border border-[#E2E8F0] dark:border-[#3B2F2A]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5 text-[#3B2F2A] dark:text-[#D4AF37]">
                  <Presentation className="w-4 h-4" />
                  <span>PowerPoint Deck (6 Slides)</span>
                </div>
                <ul className="space-y-1 text-[11px] text-[#64748B] dark:text-[#9CA3AF]">
                  <li>Slide Canvas: <code className="font-mono">{activeTheme.pptx.surface}</code></li>
                  <li>Waterfall Primary: <code className="font-mono">{activeTheme.pptx.primary}</code></li>
                  <li>Waterfall Secondary: <code className="font-mono text-[#FF6600] font-bold">{activeTheme.pptx.secondary}</code></li>
                  <li>Fav / Adv: <code className="font-mono">#{activeTheme.pptx.fav} / #{activeTheme.pptx.adv}</code></li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-[#151210] border border-[#E2E8F0] dark:border-[#3B2F2A]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5 text-[#10B981]">
                  <FileText className="w-4 h-4" />
                  <span>PDF Landscape Dossier</span>
                </div>
                <ul className="space-y-1 text-[11px] text-[#64748B] dark:text-[#9CA3AF]">
                  <li>Primary RGB: <code className="font-mono font-bold">[{activeTheme.pdf.primaryRgb.join(', ')}]</code></li>
                  <li>Secondary RGB: <code className="font-mono">[{activeTheme.pdf.secondaryRgb.join(', ')}]</code></li>
                  <li>Centered Title: <code className="font-mono">x = 148.5mm</code></li>
                  <li>Usable Width: <code className="font-mono">269mm (A4)</code></li>
                </ul>
              </div>
            </div>
          </div>

          {/* Quick Custom Override Inputs */}
          <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#64748B] dark:text-[#9CA3AF] mb-3">
              Custom Hex Override (Live Fine-Tuning)
            </h4>
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold">Primary Brand:</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={customPrimary}
                    onChange={(e) => setCustomPrimary(e.target.value)}
                    className="w-7 h-7 rounded border border-neutral-300 dark:border-neutral-700 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={customPrimary}
                    onChange={(e) => setCustomPrimary(e.target.value)}
                    className="text-xs font-mono px-2 py-1 rounded border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-black w-24 font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold">Accent Tone:</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={customAccent}
                    onChange={(e) => setCustomAccent(e.target.value)}
                    className="w-7 h-7 rounded border border-neutral-300 dark:border-neutral-700 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={customAccent}
                    onChange={(e) => setCustomAccent(e.target.value)}
                    className="text-xs font-mono px-2 py-1 rounded border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-black w-24 font-bold"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleApplyCustom}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#FF6600] text-white hover:bg-[#e05a00] transition-colors shadow-xs ml-auto"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Apply Custom Colors</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-[#E2E8F0] dark:border-[#3B2F2A] bg-[#F8F6F1] dark:bg-[#151210]">
          <span className="text-xs text-[#64748B] dark:text-[#9CA3AF] flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-[#FF6600]" />
            <span>Rule: Every red/green metric is strictly accompanied by <strong className="text-emerald-600 dark:text-emerald-400">▲ +</strong> or <strong className="text-rose-600 dark:text-rose-400">▼ -</strong>.</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#FF6600] text-white hover:bg-[#e05a00] transition-colors shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
