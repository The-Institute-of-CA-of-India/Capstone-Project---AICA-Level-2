import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import {
  AccountMapping,
  FinancialAccount,
  LeasingDriverData,
  UnmappedAccountAlert,
} from '../types/financial';
import {
  parseAccountMappingCsv,
  parseLeasingDriversCsv,
  parseTrialBalanceWorkbook,
} from '../utils/trialBalanceParser';
import { formatCurrency } from '../utils/financialEngine';
import {
  Upload,
  X,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle,
  Download,
  AlertTriangle,
  Layers,
  FileText,
  Building,
} from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (accounts: FinancialAccount[], filename: string) => void;
  onUploadMappings?: (mappings: AccountMapping[]) => void;
  onUploadDrivers?: (drivers: LeasingDriverData) => void;
  unmappedAccounts?: UnmappedAccountAlert[];
  currentMappings?: AccountMapping[];
  theme?: 'light' | 'dark';
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
  onUploadMappings,
  onUploadDrivers,
  unmappedAccounts = [],
  currentMappings = [],
  theme = 'light',
}) => {
  const isLight = theme === 'light';
  const [activeTab, setActiveTab] = useState<'tb' | 'mapping' | 'drivers'>('tb');
  const [dragActive, setDragActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Trial Balance Upload
  const handleTbFile = (file: File) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const parseRes = parseTrialBalanceWorkbook(workbook);

        if (parseRes.accounts.length === 0) {
          setErrorMsg('No readable GL accounts found in trial balance.');
          return;
        }

        onUploadSuccess(parseRes.accounts, file.name);
        setSuccessMsg(`Successfully parsed ${parseRes.accounts.length} accounts from ${file.name}.`);
      } catch (err: any) {
        setErrorMsg(`Failed to parse file: ${err.message || 'Unknown format'}`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Handle Account Mapping CSV Upload
  const handleMappingFile = (file: File) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const mappings = parseAccountMappingCsv(text);
        if (mappings.length === 0) {
          setErrorMsg('No valid account mapping rows found.');
          return;
        }
        if (onUploadMappings) {
          onUploadMappings(mappings);
          setSuccessMsg(`Successfully loaded ${mappings.length} custom account mappings.`);
        }
      } catch (err: any) {
        setErrorMsg(`Failed to parse mapping CSV: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  // Handle Leasing Drivers CSV Upload
  const handleDriversFile = (file: File) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const drivers = parseLeasingDriversCsv(text);
        if (onUploadDrivers) {
          onUploadDrivers(drivers);
          setSuccessMsg('Successfully loaded leasing drivers schedule (Occupancy, GLA, Sales, Base & TOR Rent).');
        }
      } catch (err: any) {
        setErrorMsg(`Failed to parse drivers CSV: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (activeTab === 'tb') handleTbFile(file);
      else if (activeTab === 'mapping') handleMappingFile(file);
      else handleDriversFile(file);
    }
  };

  // Download Sample Templates
  const downloadMappingTemplate = () => {
    const csvContent =
      'Account Code,P&L Line,Tier,Controllable,Sign,Subcategory,Name\n' +
      '4110,Gross Commercial Revenue,REVENUE,No,1,Base Lease Revenue,Anchor Tenant Base Rent\n' +
      '4120,Gross Commercial Revenue,REVENUE,Yes,1,Base Lease Revenue,In-Line Store Base Rent\n' +
      '4210,Gross Commercial Revenue,REVENUE,No,1,Turnover & Specialty,Retail Tenant Turnover Rent (TOR)\n' +
      '4910,Contra-revenue,CONTRA_REVENUE,No,1,Lease Concessions,Tenant Rent-Free Amortisation\n' +
      '5110,Cost of Sales (COGS),COGS,Yes,1,Mall Utilities,Direct Mall Electricity & Chilled Water\n' +
      '6110,Operating Expenses (OPEX),OPEX,Yes,1,Facility Services,Facilities Custodial Cleaning & Waste\n' +
      '8110,Depreciation & Amortisation,BELOW_EBITDA,No,1,Depreciation,Core Building & Plant Depreciation\n' +
      '9110,Finance Costs,BELOW_EBITDA,No,1,Finance Costs,Term Loan Bank Interest\n' +
      '9210,Tax,BELOW_EBITDA,No,1,Tax,UAE Federal Corporate Tax\n' +
      '1110,Balance Sheet,BALANCE_SHEET,No,1,Current Assets,Cash at Bank\n' +
      '3220,Balance Sheet,BALANCE_SHEET,No,1,Equity,Current Period Retained Profit\n';

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'account_mapping_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadDriversTemplate = () => {
    const csvContent =
      'Metric,Actual,Benchmark,Unit\n' +
      'occupancy_pct,94.2,96.0,%\n' +
      'gla_sqm,125000,125000,sqm\n' +
      'tenant_sales,310500000,335000000,AED\n' +
      'sales_per_sqm,2636,2792,AED/sqm\n' +
      'base_rent,38600000,39600000,AED\n' +
      'turnover_rent_tor,3200000,4100000,AED\n';

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'leasing_drivers_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div
        className={`w-full max-w-2xl rounded-xl border p-5 shadow-2xl transition-colors ${
          isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#131B26] border-slate-700 text-white'
        }`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Upload className="w-4 h-4 text-blue-500" />
            <h2 className="text-base font-bold">Data Upload & Mapping Center</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Unmapped Accounts Blocking Alert (if any) */}
        {unmappedAccounts.length > 0 && (
          <div className="mt-3 p-3.5 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 text-xs">
            <div className="flex items-center gap-2 font-bold text-amber-800 dark:text-amber-300 mb-1">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Blocking Alert: {unmappedAccounts.length} Unmapped Account(s) Detected</span>
            </div>
            <p className="text-amber-700 dark:text-amber-400 mb-2">
              Accounting governance requires 100% GL classification before calculating executive models. Please upload an updated account mapping table.
            </p>
            <div className="max-h-28 overflow-y-auto font-mono text-[11px] bg-white dark:bg-slate-900 p-2 rounded border border-amber-200 dark:border-amber-900">
              {unmappedAccounts.map((u, i) => (
                <div key={i} className="flex justify-between py-0.5">
                  <span>{u.code} — {u.name}</span>
                  <span className="font-bold">{formatCurrency(u.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab Selection */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 mt-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('tb')}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'tb'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>1. Trial Balance</span>
          </button>
          <button
            onClick={() => setActiveTab('mapping')}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'mapping'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>2. Account Mapping Table</span>
          </button>
          <button
            onClick={() => setActiveTab('drivers')}
            className={`pb-2 px-3 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'drivers'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>3. Leasing Drivers (Optional)</span>
          </button>
        </div>

        {/* Tab 1: Trial Balance Upload */}
        {activeTab === 'tb' && (
          <div className="py-4 space-y-3">
            <p className="text-xs text-slate-500">
              Upload your UAE retail entity trial balance (.xlsx, .xls, .csv). Supports single-column balances or debit/credit pairs.
            </p>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : isLight
                  ? 'border-slate-300 hover:border-slate-400 bg-slate-50'
                  : 'border-slate-700 hover:border-slate-600 bg-slate-900/40'
              }`}
              onClick={() => {
                const el = document.getElementById('tb-file-input');
                el?.click();
              }}
            >
              <FileSpreadsheet className="w-8 h-8 mx-auto text-blue-500 mb-2" />
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Drag and drop Trial Balance file here, or click to browse
              </p>
              <p className="text-[11px] text-slate-400 mt-1">Accepts Excel (.xlsx, .xls) and CSV (.csv)</p>
              <input
                id="tb-file-input"
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleTbFile(e.target.files[0]);
                  }
                }}
              />
            </div>
          </div>
        )}

        {/* Tab 2: Account Mapping Table Upload */}
        {activeTab === 'mapping' && (
          <div className="py-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Upload custom mapping table: Account code → P&L line → Tier → Controllable → Sign
              </span>
              <button
                type="button"
                onClick={downloadMappingTemplate}
                className="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
              >
                <Download className="w-3 h-3" />
                <span>Template CSV</span>
              </button>
            </div>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : isLight
                  ? 'border-slate-300 hover:border-slate-400 bg-slate-50'
                  : 'border-slate-700 hover:border-slate-600 bg-slate-900/40'
              }`}
              onClick={() => {
                const el = document.getElementById('mapping-file-input');
                el?.click();
              }}
            >
              <Layers className="w-8 h-8 mx-auto text-blue-500 mb-2" />
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Drag and drop Account Mapping CSV here, or click to browse
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Currently {currentMappings.length} accounts mapped in active template
              </p>
              <input
                id="mapping-file-input"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleMappingFile(e.target.files[0]);
                  }
                }}
              />
            </div>
          </div>
        )}

        {/* Tab 3: Leasing Drivers Upload */}
        {activeTab === 'drivers' && (
          <div className="py-4 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Upload leasing operational drivers: Occupancy %, GLA sqm, Tenant Sales, Base Rent & TOR.
              </span>
              <button
                type="button"
                onClick={downloadDriversTemplate}
                className="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
              >
                <Download className="w-3 h-3" />
                <span>Template CSV</span>
              </button>
            </div>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : isLight
                  ? 'border-slate-300 hover:border-slate-400 bg-slate-50'
                  : 'border-slate-700 hover:border-slate-600 bg-slate-900/40'
              }`}
              onClick={() => {
                const el = document.getElementById('drivers-file-input');
                el?.click();
              }}
            >
              <Building className="w-8 h-8 mx-auto text-blue-500 mb-2" />
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Drag and drop Leasing Drivers CSV here, or click to browse
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Enables 3-way variance decomposition (Occupancy, Rate & TOR effects)
              </p>
              <input
                id="drivers-file-input"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleDriversFile(e.target.files[0]);
                  }
                }}
              />
            </div>
          </div>
        )}

        {/* Status Messages */}
        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Footer */}
        <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-bold rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:opacity-90"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
