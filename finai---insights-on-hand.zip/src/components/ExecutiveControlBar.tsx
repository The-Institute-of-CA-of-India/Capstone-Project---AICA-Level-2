import React from 'react';
import {
  Building2,
  ShieldCheck,
  ShieldAlert,
  Presentation,
  FileSpreadsheet,
  Download,
  Upload,
  RefreshCw,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import { BenchmarkType, MaterialityFilter, UnmappedAccountAlert } from '../types/financial';

interface ExecutiveControlBarProps {
  datasetName: string;
  benchmarkType: BenchmarkType;
  setBenchmarkType: (type: BenchmarkType) => void;
  theme: 'light' | 'dark';
  onOpenUpload: () => void;
  onLoadDemo: () => void;
  onExportPptx: () => void;
  onExportExcel: () => void;
  onPrintPdf: () => void;
  systemCheckPassed: boolean;
  unmappedAccounts: UnmappedAccountAlert[];
  materiality: MaterialityFilter;
  onMaterialityChange: (m: MaterialityFilter) => void;
  hasLeasingDrivers: boolean;
}

export const ExecutiveControlBar: React.FC<ExecutiveControlBarProps> = ({
  datasetName,
  benchmarkType,
  setBenchmarkType,
  theme,
  onOpenUpload,
  onLoadDemo,
  onExportPptx,
  onExportExcel,
  onPrintPdf,
  systemCheckPassed,
  unmappedAccounts,
  materiality,
  onMaterialityChange,
  hasLeasingDrivers,
}) => {
  const isLight = theme === 'light';

  return (
    <div
      className={`rounded-xl border p-4 sm:p-5 shadow-xs transition-colors duration-200 space-y-4 ${
        isLight
          ? 'bg-white border-[#E2E8F0] text-[#0F172A]'
          : 'bg-[#131B26] border-[#1E293B] text-[#F8FAFC]'
      }`}
    >
      {/* Upper Row: Entity Info, Status Badges & Deliverable Exports */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#E2E8F0] dark:border-[#1E293B]">
        {/* Entity Title & Status */}
        <div className="flex items-start sm:items-center gap-3.5">
          <div
            className={`p-2.5 rounded-lg border shrink-0 ${
              isLight
                ? 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0F172A]'
                : 'bg-[#0B0F17] border-[#1E293B] text-white'
            }`}
          >
            <Building2 className="w-5 h-5" />
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-base sm:text-lg font-bold tracking-tight ${isLight ? 'text-[#0F172A]' : 'text-white'}`}>
                {datasetName}
              </span>

              {/* System Check Status Badge */}
              {systemCheckPassed ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-md">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>System check passed</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 px-2 py-0.5 rounded-md">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>System check failed</span>
                </span>
              )}

              {/* Unmapped accounts blocking alert badge */}
              {unmappedAccounts.length > 0 ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 px-2 py-0.5 rounded-md">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{unmappedAccounts.length} Unmapped Accounts</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-0.5 rounded-md">
                  <span>Mapping: 100% Resolved</span>
                </span>
              )}

              {/* Leasing Drivers Status */}
              {hasLeasingDrivers && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 px-2 py-0.5 rounded-md">
                  <span>Leasing Drivers Active</span>
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs">
              <button
                onClick={onLoadDemo}
                className={`inline-flex items-center gap-1 font-medium transition-colors ${
                  isLight ? 'text-[#64748B] hover:text-[#0F172A]' : 'text-[#94A3B8] hover:text-white'
                }`}
                title="Reload standard UAE Retail Mall dataset"
              >
                <RefreshCw className="w-3 h-3 text-blue-500" />
                <span>Reload Mall Sample</span>
              </button>
              <span className="text-neutral-400">·</span>
              <button
                onClick={onOpenUpload}
                className={`inline-flex items-center gap-1 font-medium transition-colors ${
                  isLight ? 'text-[#64748B] hover:text-[#0F172A]' : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                <Upload className="w-3 h-3 text-blue-500" />
                <span>Upload Trial Balance / Mapping / Drivers</span>
              </button>
            </div>
          </div>
        </div>

        {/* Deliverables Download Hub */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <span className={`text-xs font-semibold uppercase tracking-wider hidden sm:inline ${isLight ? 'text-[#64748B]' : 'text-[#94A3B8]'}`}>
            Deliverables:
          </span>
          <button
            onClick={onExportPptx}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#0F172A] hover:bg-[#1E293B] dark:bg-blue-600 dark:hover:bg-blue-700 rounded-lg transition-all shadow-2xs active:scale-[0.98]"
            title="Download 6-Slide Executive PowerPoint Deck (.pptx)"
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>PowerPoint (6 Slides)</span>
          </button>
          <button
            onClick={onExportExcel}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all active:scale-[0.98] ${
              isLight
                ? 'bg-white border-[#E2E8F0] text-[#0F172A] hover:bg-neutral-50 shadow-2xs'
                : 'bg-[#1E293B] border-[#334155] text-white hover:bg-[#334155]'
            }`}
            title="Download Excel Workbook with CPA formatting and balance sheet checks"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Excel Model (.xlsx)</span>
          </button>
          <button
            onClick={onPrintPdf}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all active:scale-[0.98] ${
              isLight
                ? 'bg-white border-[#E2E8F0] text-[#0F172A] hover:bg-neutral-50 shadow-2xs'
                : 'bg-[#1E293B] border-[#334155] text-white hover:bg-[#334155]'
            }`}
            title="Download Landscape PDF Dossier"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>PDF Dossier</span>
          </button>
        </div>
      </div>

      {/* Lower Row: Materiality Threshold Controls & Baseline Context */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Materiality Filter */}
        <div className="flex items-center gap-2">
          <Sliders className="w-3.5 h-3.5 text-blue-500" />
          <span className="font-semibold text-slate-700 dark:text-slate-300">Materiality Filter:</span>
          <label className="flex items-center gap-1 text-slate-500">
            <span>Variance ≥ AED</span>
            <input
              type="number"
              step="50000"
              value={materiality.aedThreshold}
              onChange={(e) =>
                onMaterialityChange({
                  ...materiality,
                  aedThreshold: Math.max(0, Number(e.target.value) || 0),
                })
              }
              className={`w-24 px-1.5 py-0.5 text-xs rounded border font-semibold ${
                isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </label>
          <label className="flex items-center gap-1 text-slate-500">
            <span>AND ≥</span>
            <input
              type="number"
              step="1"
              value={materiality.pctThreshold}
              onChange={(e) =>
                onMaterialityChange({
                  ...materiality,
                  pctThreshold: Math.max(0, Number(e.target.value) || 0),
                })
              }
              className={`w-14 px-1.5 py-0.5 text-xs rounded border font-semibold ${
                isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span>%</span>
          </label>
        </div>

        {/* Benchmark Baseline Switch */}
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700 dark:text-slate-300">Benchmark Baseline:</span>
          <div
            className={`flex items-center rounded-lg p-0.5 border text-xs font-semibold ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800 border-slate-700'
            }`}
          >
            {(['BUDGET', 'FORECAST', 'PRIOR_PERIOD'] as BenchmarkType[]).map((b) => (
              <button
                key={b}
                onClick={() => setBenchmarkType(b)}
                className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                  benchmarkType === b
                    ? isLight
                      ? 'bg-white text-slate-900 shadow-2xs font-bold'
                      : 'bg-slate-700 text-white shadow-2xs font-bold'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {b === 'BUDGET' ? 'Budget' : b === 'FORECAST' ? 'Forecast' : 'Prior Year'}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
