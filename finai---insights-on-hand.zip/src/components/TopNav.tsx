import React from 'react';
import {
  Upload,
  Presentation,
  Sun,
  Moon,
  TrendingUp,
  BarChart3,
  FileText,
  ShieldCheck,
  LayoutDashboard,
  Lock,
  Sparkles,
  Palette,
  Activity,
} from 'lucide-react';
import { BenchmarkType, CurrencyCode, PeriodType } from '../types/financial';
import { CorporateTheme } from '../theme/themeConfig';

interface TopNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onOpenUpload: () => void;
  onOpenDeck: () => void;
  currency: CurrencyCode;
  onCurrencyChange: (c: CurrencyCode) => void;
  period: PeriodType;
  onPeriodChange: (p: PeriodType) => void;
  benchmarkType: BenchmarkType;
  onBenchmarkChange: (b: BenchmarkType) => void;
  sendToExternalAi: boolean;
  onToggleSendToAi: () => void;
  activeTheme: CorporateTheme;
  onOpenPalette: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  setCurrentTab,
  theme,
  onToggleTheme,
  onOpenUpload,
  onOpenDeck,
  currency,
  onCurrencyChange,
  period,
  onPeriodChange,
  benchmarkType,
  onBenchmarkChange,
  sendToExternalAi,
  onToggleSendToAi,
  activeTheme,
  onOpenPalette,
}) => {
  const isLight = theme === 'light';

  const navItems = [
    { id: 'dashboard', label: 'Interactive Dashboard', icon: BarChart3 },
    { id: 'summary', label: 'Executive Summary', icon: LayoutDashboard },
    { id: 'pnl', label: 'P&L Statement', icon: TrendingUp },
    { id: 'waterfall', label: 'Waterfall Bridge', icon: Activity },
    { id: 'commentary', label: 'Board Commentary', icon: FileText },
    { id: 'deck', label: '6-Slide Board Deck', icon: Presentation },
    { id: 'audit', label: 'System Validation', icon: ShieldCheck },
  ];

  return (
    <header
      className={`border-b sticky top-0 z-30 backdrop-blur-md px-3 sm:px-6 py-2 transition-colors duration-200 ${
        isLight
          ? 'bg-[#F8FAFC]/95 border-[#E2E8F0] text-[#0F172A]'
          : 'bg-[#0B0F17]/95 border-[#1E293B] text-[#F8FAFC]'
      }`}
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand Wordmark (Neutral Corporate) */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm tracking-wider shadow-xs transition-colors"
            style={{ backgroundColor: activeTheme.colors.primary }}
          >
            {activeTheme.id === 'hermes-luxury' ? 'H' : 'FA'}
          </div>
          <div className="flex flex-col">
            <span className={`text-base font-bold tracking-tight leading-none ${isLight ? 'text-[#0F172A]' : 'text-white'}`}>
              FinAI
            </span>
            <span className={`text-[10px] font-semibold tracking-wider uppercase mt-0.5 ${isLight ? 'text-[#64748B]' : 'text-[#94A3B8]'}`}>
              UAE Retail & Mall Real Estate FP&A
            </span>
          </div>
        </div>

        {/* Global Controls: Currency, Period, Benchmark */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Currency Selector */}
          <select
            value={currency}
            onChange={(e) => onCurrencyChange(e.target.value as CurrencyCode)}
            className={`text-xs font-semibold px-2 py-1 rounded-md border shadow-2xs transition-colors ${
              isLight
                ? 'bg-white border-[#E2E8F0] text-[#0F172A]'
                : 'bg-[#131B26] border-[#1E293B] text-white'
            }`}
            title="Active Reporting Currency"
          >
            <option value="AED">AED (Dirhams)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
          </select>

          {/* Period Selector */}
          <div
            className={`flex items-center rounded-md p-0.5 border text-xs font-semibold ${
              isLight ? 'bg-[#F1F5F9] border-[#E2E8F0]' : 'bg-[#131B26] border-[#1E293B]'
            }`}
          >
            {(['MTD', 'YTD', 'FY'] as PeriodType[]).map((p) => (
              <button
                key={p}
                onClick={() => onPeriodChange(p)}
                className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                  period === p
                    ? isLight
                      ? 'bg-white text-[#0F172A] shadow-2xs font-bold'
                      : 'bg-[#1E293B] text-white shadow-2xs font-bold'
                    : isLight
                    ? 'text-[#64748B] hover:text-[#0F172A]'
                    : 'text-[#94A3B8] hover:text-white'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Benchmark Selector */}
          <select
            value={benchmarkType}
            onChange={(e) => onBenchmarkChange(e.target.value as BenchmarkType)}
            className={`text-xs font-semibold px-2 py-1 rounded-md border shadow-2xs transition-colors ${
              isLight
                ? 'bg-white border-[#E2E8F0] text-[#0F172A]'
                : 'bg-[#131B26] border-[#1E293B] text-white'
            }`}
            title="Comparison Benchmark Baseline"
          >
            <option value="BUDGET">Budget Baseline</option>
            <option value="FORECAST">Forecast Baseline</option>
            <option value="PRIOR_PERIOD">Prior Year Baseline</option>
          </select>

          {/* Data Privacy Toggle: Send Data to External AI (Default OFF) */}
          <button
            type="button"
            onClick={onToggleSendToAi}
            title={
              sendToExternalAi
                ? 'Data Privacy: External AI Enabled (Gemini)'
                : 'Data Privacy: External AI Disabled (Rule-Based Engine Active)'
            }
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border transition-all ${
              sendToExternalAi
                ? 'bg-blue-500/10 border-blue-500/40 text-blue-600 dark:text-blue-400'
                : isLight
                ? 'bg-neutral-100 border-neutral-300 text-neutral-700'
                : 'bg-neutral-800/60 border-neutral-700 text-neutral-300'
            }`}
          >
            {sendToExternalAi ? (
              <>
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                <span className="hidden lg:inline">AI Online</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="hidden lg:inline">Rule-based (Private)</span>
              </>
            )}
          </button>
        </div>

        {/* Navigation Tabs */}
        <nav
          className={`hidden md:flex items-center gap-1 text-xs font-semibold ${
            isLight ? 'text-[#64748B]' : 'text-[#94A3B8]'
          }`}
        >
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all whitespace-nowrap ${
                  isActive
                    ? isLight
                      ? 'bg-white text-[#0F172A] shadow-2xs border border-[#E2E8F0] font-bold'
                      : 'bg-[#1E293B] text-white shadow-2xs border border-[#334155] font-bold'
                    : isLight
                    ? 'hover:text-[#0F172A] hover:bg-neutral-100'
                    : 'hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Actions: Palette Selector, Upload, Deck Preview, Theme */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Corporate Colour Palette Button */}
          <button
            type="button"
            onClick={onOpenPalette}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md border transition-all ${
              isLight
                ? 'bg-white border-[#CBD5E1] text-[#0F172A] hover:bg-neutral-50 shadow-2xs'
                : 'bg-[#181412] border-[#3B2F2A] text-white hover:bg-[#28201C]'
            }`}
            title={`Active Palette: ${activeTheme.name}. Click to view or customize colour palette.`}
          >
            <Palette className="w-3.5 h-3.5 text-[#FF6600]" />
            <span className="hidden sm:inline font-bold">Palette: {activeTheme.id === 'hermes-luxury' ? 'H' : activeTheme.name.split(' ')[0]}</span>
            <div className="flex items-center -space-x-1 pl-0.5" title="Corporate Swatches">
              <span
                className="w-2.5 h-2.5 rounded-full border border-white dark:border-black shrink-0"
                style={{ backgroundColor: activeTheme.colors.primary }}
              />
              <span
                className="w-2.5 h-2.5 rounded-full border border-white dark:border-black shrink-0"
                style={{ backgroundColor: activeTheme.colors.secondary }}
              />
              <span
                className="w-2.5 h-2.5 rounded-full border border-white dark:border-black shrink-0"
                style={{ backgroundColor: activeTheme.colors.accent }}
              />
              <span
                className="w-2.5 h-2.5 rounded-full border border-white dark:border-black shrink-0"
                style={{ backgroundColor: activeTheme.colors.favourable }}
              />
            </div>
          </button>

          <button
            onClick={onOpenUpload}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md border transition-all ${
              isLight
                ? 'bg-white border-[#E2E8F0] text-[#0F172A] hover:bg-neutral-50 shadow-2xs'
                : 'bg-[#131B26] border-[#1E293B] text-white hover:bg-[#1E293B]'
            }`}
            title="Upload Trial Balance, Account Mapping or Leasing Drivers"
          >
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span className="hidden sm:inline">Upload</span>
          </button>

          <button
            onClick={onOpenDeck}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold rounded-md bg-[#0F172A] dark:bg-white text-white dark:text-[#0F172A] shadow-xs hover:opacity-90 transition-all"
            title="Preview 6-Slide Executive Deck"
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>Deck</span>
          </button>

          {/* Theme Switcher */}
          <button
            type="button"
            onClick={onToggleTheme}
            className={`p-1.5 rounded-md border transition-colors ${
              isLight ? 'bg-white border-[#E2E8F0] text-[#0F172A]' : 'bg-[#131B26] border-[#1E293B] text-white'
            }`}
            title="Toggle Light / Dark mode"
          >
            {isLight ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </header>
  );
};
