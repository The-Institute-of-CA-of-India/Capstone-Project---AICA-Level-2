import React, { useState } from 'react';
import {
  BenchmarkType,
  BoardCommentaryData,
  MacroPnlMetrics,
  OpenQuestionAction,
  PriorRunComparison,
  VarianceRollup,
} from '../types/financial';
import { formatCurrency, formatCurrencyM, formatPpDelta } from '../utils/financialEngine';
import {
  Sparkles,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
  Send,
  RefreshCw,
  ShieldCheck,
  History,
  Lock,
  Plus,
} from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface BoardCommentaryViewProps {
  datasetName: string;
  benchmarkType: BenchmarkType;
  metrics: MacroPnlMetrics;
  topAdverseDrivers: VarianceRollup[];
  topFavourableDrivers: VarianceRollup[];
  commentary: BoardCommentaryData | null;
  isLoadingCommentary: boolean;
  theme?: 'light' | 'dark';
  onGenerateCommentary: () => void;
  openQuestions: OpenQuestionAction[];
  onUpdateQuestion: (q: OpenQuestionAction) => void;
  onAddQuestion: (q: OpenQuestionAction) => void;
  priorRunComparison: PriorRunComparison;
}

export const BoardCommentaryView: React.FC<BoardCommentaryViewProps> = ({
  datasetName,
  benchmarkType,
  metrics,
  topAdverseDrivers,
  topFavourableDrivers,
  commentary,
  isLoadingCommentary,
  theme = 'light',
  onGenerateCommentary,
  openQuestions,
  onUpdateQuestion,
  onAddQuestion,
  priorRunComparison,
}) => {
  const isLight = theme === 'light';
  const currency = metrics.currency;
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';

  const [inquiryQuestion, setInquiryQuestion] = useState('');
  const [inquiryAnswer, setInquiryAnswer] = useState<string | null>(null);
  const [isAsking, setIsAsking] = useState(false);

  // New question form state
  const [showNewQModal, setShowNewQModal] = useState(false);
  const [newItem, setNewItem] = useState('');
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newOwner, setNewOwner] = useState('');
  const [newDueDate, setNewDueDate] = useState('2026-11-30');

  // Answer editing state
  const [answeringId, setAnsweringId] = useState<string | null>(null);
  const [answerDraft, setAnswerDraft] = useState('');

  const handleAskInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryQuestion.trim() || isAsking) return;

    setIsAsking(true);
    try {
      const res = await fetch('/api/drilldown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: inquiryQuestion,
          benchmarkType: benchmarkLabel,
          accountData: {
            topAdverse: topAdverseDrivers.slice(0, 5),
            topFav: topFavourableDrivers.slice(0, 5),
          },
          context: {
            datasetName,
            metrics,
          },
        }),
      });

      if (!res.ok) throw new Error('Failed to query engine');
      const data = await res.json();
      setInquiryAnswer(data.answer);
    } catch (_err) {
      setInquiryAnswer(
        'Inquiry processed with rule-based engine. Specific root-cause confirmation requires detailed sub-ledger journal schedules.'
      );
    } finally {
      setIsAsking(false);
    }
  };

  const handleSaveAnswer = (q: OpenQuestionAction) => {
    onUpdateQuestion({
      ...q,
      status: 'Answered',
      answerText: answerDraft,
      isManagementExplanation: true,
    });
    setAnsweringId(null);
    setAnswerDraft('');
  };

  const handleCreateNewQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.trim() || !newQuestionText.trim()) return;

    const newQ: OpenQuestionAction = {
      id: `Q-0${openQuestions.length + 1}`,
      item: newItem.trim(),
      question: newQuestionText.trim(),
      owner: newOwner.trim() || 'CFO / Management',
      dueDate: newDueDate,
      status: 'Open',
      answerText: '',
      isManagementExplanation: false,
    };

    onAddQuestion(newQ);
    setShowNewQModal(false);
    setNewItem('');
    setNewQuestionText('');
    setNewOwner('');
  };

  const sourceLabel = commentary?.sourceLabel || 'Commentary source: Rule-based (Deterministic FP&A Engine)';
  const isAi = commentary?.source === 'AI';

  return (
    <div className="space-y-6">
      {/* Top Banner: Commentary Source & Governance */}
      <div
        className={`rounded-xl p-4 sm:p-5 border transition-colors ${
          isLight ? 'bg-white border-slate-200 shadow-xs' : 'bg-[#131B26] border-slate-800 shadow-xs'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold ${
                  isAi
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                    : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                }`}
              >
                {isAi ? <Sparkles className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{sourceLabel}</span>
              </span>

              {commentary?.sourceReason && (
                <span className="text-[11px] text-slate-500">({commentary.sourceReason})</span>
              )}
            </div>

            {/* Action Title with conclusion and number */}
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-2">
              {commentary?.actionTitle ||
                `EBITDA ${currency} ${(Math.abs(metrics.ebitdaVariance) / 1_000_000).toFixed(1)}M ${
                  metrics.ebitdaVariance >= 0 ? 'above' : 'below'
                } ${benchmarkLabel.toLowerCase()}`}
            </h2>
          </div>

          <button
            onClick={onGenerateCommentary}
            disabled={isLoadingCommentary}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-[#0F172A] hover:bg-[#1E293B] dark:bg-blue-600 dark:hover:bg-blue-700 rounded-lg disabled:opacity-50 transition-all shadow-2xs shrink-0"
          >
            {isLoadingCommentary ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>{isLoadingCommentary ? 'Synthesizing...' : 'Recompute Commentary'}</span>
          </button>
        </div>
      </div>

      {/* Executive Summary Card */}
      <div
        className={`rounded-xl p-5 border transition-colors ${
          isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
        }`}
      >
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
          Executive Briefing to Board of Directors
        </h3>
        <p className="text-sm leading-relaxed text-slate-800 dark:text-slate-200">
          {commentary?.executiveSummary ||
            `For the reporting period, operational EBITDA concluded at ${formatCurrency(
              metrics.ebitdaActual,
              currency
            )} against a ${benchmarkLabel.toLowerCase()} of ${formatCurrency(
              metrics.ebitdaBenchmark,
              currency
            )}. System check passed: Balance Sheet accounts are isolated and the closed EBITDA bridge reconciles to 0.00 difference.`}
        </p>

        {commentary?.strategicHighlights && commentary.strategicHighlights.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Key Strategic Takeaways:
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
              {commentary.strategicHighlights.map((hl, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-blue-500 font-bold">•</span>
                  <span>{hl}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* "What Changed Since Last Month" Panel */}
      {priorRunComparison?.hasPriorRun && (
        <div
          className={`rounded-xl p-5 border transition-colors ${
            isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
          }`}
        >
          <div className="flex items-center gap-2 mb-3">
            <History className="w-4 h-4 text-blue-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              What Changed Since Last Month ({priorRunComparison.priorPeriodLabel})
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* New Items */}
            <div className="p-3 rounded-lg bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900">
              <span className="text-xs font-bold text-blue-800 dark:text-blue-300 block mb-2">
                New Material Items (This Month)
              </span>
              <ul className="space-y-2 text-xs">
                {priorRunComparison.newItems.map((item, idx) => (
                  <li key={idx} className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <span className="truncate pr-2">{item.name}</span>
                    <span
                      className={`font-mono font-bold shrink-0 ${
                        item.polarity === 'FAVOURABLE' ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {item.dollarVariance >= 0 ? '+' : ''}
                      {formatCurrencyM(item.dollarVariance, currency)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Resolved Items */}
            <div className="p-3 rounded-lg bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900">
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block mb-2">
                Resolved Variances (Normalized)
              </span>
              <ul className="space-y-2 text-xs">
                {priorRunComparison.resolvedItems.map((item, idx) => (
                  <li key={idx} className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <span className="truncate pr-2">{item.name}</span>
                    <span className="font-mono text-emerald-600 font-bold shrink-0">Resolved</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Worsening Items */}
            <div className="p-3 rounded-lg bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900">
              <span className="text-xs font-bold text-rose-800 dark:text-rose-300 block mb-2">
                Worsening Variance Pressures
              </span>
              <ul className="space-y-2 text-xs">
                {priorRunComparison.worseningItems.map((item, idx) => (
                  <li key={idx} className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <span className="truncate pr-2">{item.name}</span>
                    <span className="font-mono text-rose-600 font-bold shrink-0">
                      {formatCurrencyM(item.changeDelta, currency)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Closed-Loop Governance: Open Questions & Actions */}
      <div
        className={`rounded-xl p-5 border transition-colors ${
          isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Closed-Loop Governance: Open Questions & Management Explanations
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Unanswered variances converted into accountability questions. Answered questions automatically become Management Explanations in subsequent cycles.
            </p>
          </div>

          <button
            onClick={() => setShowNewQModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Action Item</span>
          </button>
        </div>

        {/* Questions Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr
                className={`border-b font-bold text-[11px] uppercase tracking-wider ${
                  isLight ? 'bg-slate-50 text-slate-600' : 'bg-slate-900 text-slate-400'
                }`}
              >
                <th className="py-2.5 px-3 w-16">Ref</th>
                <th className="py-2.5 px-3 w-48">Target Item</th>
                <th className="py-2.5 px-3">Inquiry Question & Management Explanation</th>
                <th className="py-2.5 px-3 w-36">Owner</th>
                <th className="py-2.5 px-3 w-28">Due Date</th>
                <th className="py-2.5 px-3 w-28">Status</th>
                <th className="py-2.5 px-3 w-24 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {openQuestions.map((q) => (
                <tr
                  key={q.id}
                  className={`border-b transition-colors ${
                    isLight ? 'border-slate-100 hover:bg-slate-50' : 'border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <td className="py-3 px-3 font-mono font-bold text-slate-500">{q.id}</td>
                  <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">{q.item}</td>
                  <td className="py-3 px-3">
                    <p className="text-slate-700 dark:text-slate-300 font-medium">{q.question}</p>
                    {q.answerText && (
                      <div className="mt-1.5 p-2 rounded bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900">
                        <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 uppercase block">
                          Management Explanation:
                        </span>
                        <p className="text-emerald-900 dark:text-emerald-200 text-xs mt-0.5">{q.answerText}</p>
                      </div>
                    )}
                    {answeringId === q.id && (
                      <div className="mt-2 space-y-2">
                        <textarea
                          rows={2}
                          placeholder="Enter verified management explanation..."
                          value={answerDraft}
                          onChange={(e) => setAnswerDraft(e.target.value)}
                          className={`w-full p-2 text-xs rounded border font-medium ${
                            isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                          }`}
                        />
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleSaveAnswer(q)}
                            className="px-2.5 py-1 text-xs font-bold rounded bg-emerald-600 text-white hover:bg-emerald-700"
                          >
                            Save Explanation
                          </button>
                          <button
                            onClick={() => setAnsweringId(null)}
                            className="px-2.5 py-1 text-xs text-slate-500 hover:text-slate-800"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{q.owner}</td>
                  <td className="py-3 px-3 font-mono text-slate-500">{q.dueDate}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        q.status === 'Answered'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : q.status === 'Closed'
                          ? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {q.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    {answeringId !== q.id && (
                      <button
                        onClick={() => {
                          setAnsweringId(q.id);
                          setAnswerDraft(q.answerText || '');
                        }}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                      >
                        {q.answerText ? 'Edit' : 'Answer'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Drilldown Inquiry Bar */}
      <div
        className={`rounded-xl p-5 border transition-colors ${
          isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
        }`}
      >
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
          Interactive CFO Analytical Inquiry
        </h3>
        <p className="text-xs text-slate-500 mb-3">
          Ask specific variance inquiries. Root causes not present in the trial balance will be converted to required management schedules.
        </p>

        <form onSubmit={handleAskInquiry} className="flex gap-2">
          <input
            type="text"
            placeholder="e.g. Why did utility costs overrun budget in Q3?"
            value={inquiryQuestion}
            onChange={(e) => setInquiryQuestion(e.target.value)}
            className={`flex-1 px-3 py-2 text-xs rounded-lg border font-medium ${
              isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
            }`}
          />
          <button
            type="submit"
            disabled={isAsking || !inquiryQuestion.trim()}
            className="px-4 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 transition-all flex items-center gap-1.5"
          >
            {isAsking ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            <span>Ask</span>
          </button>
        </form>

        {inquiryAnswer && (
          <div className="mt-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
            {inquiryAnswer}
          </div>
        )}
      </div>

      {/* New Question Modal */}
      {showNewQModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div
            className={`w-full max-w-lg rounded-xl border p-5 shadow-xl ${
              isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-slate-900 border-slate-700 text-white'
            }`}
          >
            <h3 className="text-base font-bold mb-3">Add Governance Action Item</h3>
            <form onSubmit={handleCreateNewQuestion} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-500 font-semibold mb-1">Target Account / Line Item:</label>
                <input
                  type="text"
                  placeholder="e.g. In-Line Store Base Rent (4120)"
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  className={`w-full p-2 rounded border font-medium ${
                    isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                  required
                />
              </div>

              <div>
                <label className="block text-slate-500 font-semibold mb-1">Inquiry Question for Management:</label>
                <textarea
                  rows={3}
                  placeholder="What is the precise management question to be investigated?"
                  value={newQuestionText}
                  onChange={(e) => setNewQuestionText(e.target.value)}
                  className={`w-full p-2 rounded border font-medium ${
                    isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Assigned Owner:</label>
                  <input
                    type="text"
                    placeholder="e.g. Head of Leasing"
                    value={newOwner}
                    onChange={(e) => setNewOwner(e.target.value)}
                    className={`w-full p-2 rounded border font-medium ${
                      isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Due Date:</label>
                  <input
                    type="date"
                    value={newDueDate}
                    onChange={(e) => setNewDueDate(e.target.value)}
                    className={`w-full p-2 rounded border font-medium ${
                      isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewQModal(false)}
                  className="px-3 py-1.5 rounded text-slate-500 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-blue-600 text-white font-bold hover:bg-blue-700"
                >
                  Create Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
