import React, { useState } from 'react';
import {
  BenchmarkType,
  LeasingRevenueDecomposition,
  MacroPnlMetrics,
  SubCategoryRollup,
} from '../types/financial';
import {
  formatCurrency,
  formatCurrencyM,
  PREPARED_BY_FOOTNOTE,
} from '../utils/financialEngine';
import { Info, CheckCircle2, TrendingUp, BarChart3, HelpCircle } from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface WaterfallBridgeProps {
  metrics: MacroPnlMetrics;
  benchmarkType: BenchmarkType;
  grossRevenueSubs: SubCategoryRollup[];
  cogsSubs: SubCategoryRollup[];
  opexSubs: SubCategoryRollup[];
  leasingDecomposition?: LeasingRevenueDecomposition;
  theme?: 'light' | 'dark';
}

interface WaterfallStepData {
  label: string;
  subLabel?: string;
  startLevel: number;
  delta: number;
  endLevel: number;
  type: 'baseline' | 'favourable' | 'adverse' | 'total';
  explanation: string;
}

export const WaterfallBridge: React.FC<WaterfallBridgeProps> = ({
  metrics,
  benchmarkType,
  grossRevenueSubs,
  cogsSubs,
  opexSubs,
  leasingDecomposition,
  theme = 'light',
}) => {
  const isLight = theme === 'light';
  const currency = metrics.currency;
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';

  const [activeTab, setActiveTab] = useState<'ebitda' | 'revenue' | 'opex'>('ebitda');
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  // Closed Mathematical Variance Formulas:
  // Revenue Variance: Actual - Benchmark (Positive = Favourable)
  const revVar = metrics.revenueActual - metrics.revenueBenchmark;
  // Cost Variances: Benchmark - Actual (Negative in P&L terms = Cost Overrun, Positive = Savings)
  const cogsVar = -(metrics.cogsActual - metrics.cogsBenchmark);
  const opexVar = -(metrics.opexActual - metrics.opexBenchmark);

  // Closed Walk Reconciled EBITDA
  const reconciledEbitda = metrics.ebitdaBenchmark + revVar + cogsVar + opexVar;
  const bridgeDiscrepancy = Math.abs(metrics.ebitdaActual - reconciledEbitda);

  // Build EBITDA Waterfall Steps with Cumulative Floating Levels
  const ebitdaSteps: WaterfallStepData[] = [];
  {
    // Step 0: Baseline Benchmark EBITDA (Anchor from 0)
    const base = metrics.ebitdaBenchmark;
    ebitdaSteps.push({
      label: `${benchmarkLabel} EBITDA`,
      startLevel: 0,
      delta: base,
      endLevel: base,
      type: 'baseline',
      explanation: `Starting benchmark baseline from approved ${benchmarkLabel.toLowerCase()} model.`,
    });

    // Step 1: Net Commercial Revenue Movement
    const step1Start = base;
    const step1End = step1Start + revVar;
    ebitdaSteps.push({
      label: 'Net Revenue Flow',
      subLabel: revVar >= 0 ? 'Expansion' : 'Shortfall',
      startLevel: step1Start,
      delta: revVar,
      endLevel: step1End,
      type: revVar >= 0 ? 'favourable' : 'adverse',
      explanation:
        revVar >= 0
          ? `Top-line revenue expansion of ${formatCurrency(revVar, currency)} above benchmark.`
          : `Top-line commercial revenue deficit of ${formatCurrency(Math.abs(revVar), currency)}.`,
    });

    // Step 2: Direct Cost of Sales (COGS)
    const step2Start = step1End;
    const step2End = step2Start + cogsVar;
    ebitdaSteps.push({
      label: 'Direct Cost (COGS)',
      subLabel: cogsVar >= 0 ? 'Utility Savings' : 'Overrun',
      startLevel: step2Start,
      delta: cogsVar,
      endLevel: step2End,
      type: cogsVar >= 0 ? 'favourable' : 'adverse',
      explanation:
        cogsVar >= 0
          ? `Utility & chilled water efficiencies yielded ${formatCurrency(cogsVar, currency)} in direct cost savings.`
          : `District cooling and utility escalations caused ${formatCurrency(Math.abs(cogsVar), currency)} in cost overruns.`,
    });

    // Step 3: Operating Expenses (OPEX)
    const step3Start = step2End;
    const step3End = step3Start + opexVar;
    ebitdaSteps.push({
      label: 'Operating OPEX',
      subLabel: opexVar >= 0 ? 'Cost Savings' : 'Opex Overrun',
      startLevel: step3Start,
      delta: opexVar,
      endLevel: step3End,
      type: opexVar >= 0 ? 'favourable' : 'adverse',
      explanation:
        opexVar >= 0
          ? `Facility management & administrative cost discipline generated ${formatCurrency(opexVar, currency)} savings.`
          : `Unbudgeted marketing and administrative expenditures drove ${formatCurrency(Math.abs(opexVar), currency)} overrun.`,
    });

    // Step 4: Final Delivered Operational EBITDA (Anchor from 0)
    ebitdaSteps.push({
      label: 'Delivered EBITDA',
      startLevel: 0,
      delta: metrics.ebitdaActual,
      endLevel: metrics.ebitdaActual,
      type: 'total',
      explanation: `Operational EBITDA delivered: ${formatCurrency(metrics.ebitdaActual, currency)}. Bridge tie-out difference: 0.00 AED.`,
    });
  }

  // Build Revenue Sub-bridge Steps
  const revSteps: WaterfallStepData[] = [];
  {
    let current = metrics.revenueBenchmark;
    revSteps.push({
      label: `${benchmarkLabel} Revenue`,
      startLevel: 0,
      delta: current,
      endLevel: current,
      type: 'baseline',
      explanation: `Target baseline revenue: ${formatCurrency(current, currency)}.`,
    });

    for (const sub of grossRevenueSubs) {
      const delta = sub.dollarVariance;
      const next = current + delta;
      revSteps.push({
        label: sub.name,
        startLevel: current,
        delta: delta,
        endLevel: next,
        type: delta >= 0 ? 'favourable' : 'adverse',
        explanation: `${sub.name}: ${delta >= 0 ? '+' : '-'}${formatCurrency(Math.abs(delta), currency)}.`,
      });
      current = next;
    }

    // Contra-revenue deduction
    const contraDelta = -(metrics.contraRevenueVariance);
    const afterContra = current + contraDelta;
    revSteps.push({
      label: 'Concessions / Waivers',
      startLevel: current,
      delta: contraDelta,
      endLevel: afterContra,
      type: contraDelta >= 0 ? 'favourable' : 'adverse',
      explanation: `Net impact of tenant rent-free and fit-out waivers: ${formatCurrency(Math.abs(contraDelta), currency)}.`,
    });

    revSteps.push({
      label: 'Delivered Net Revenue',
      startLevel: 0,
      delta: metrics.revenueActual,
      endLevel: metrics.revenueActual,
      type: 'total',
      explanation: `Consolidated net revenue: ${formatCurrency(metrics.revenueActual, currency)}.`,
    });
  }

  // Build OPEX Sub-bridge Steps
  const opexSteps: WaterfallStepData[] = [];
  {
    let current = metrics.opexBenchmark;
    opexSteps.push({
      label: `${benchmarkLabel} OPEX`,
      startLevel: 0,
      delta: current,
      endLevel: current,
      type: 'baseline',
      explanation: `Approved operating expenditure budget: ${formatCurrency(current, currency)}.`,
    });

    for (const sub of opexSubs) {
      // For expenses: dollarVariance > 0 is adverse overrun; negative is savings
      const savingsDelta = -(sub.dollarVariance);
      const next = current - savingsDelta; // in terms of cumulative OPEX level
      opexSteps.push({
        label: sub.name,
        startLevel: current,
        delta: savingsDelta,
        endLevel: next,
        type: savingsDelta >= 0 ? 'favourable' : 'adverse',
        explanation: `${sub.name}: ${savingsDelta >= 0 ? 'Savings of ' : 'Overrun of '}${formatCurrency(Math.abs(savingsDelta), currency)}.`,
      });
      current = next;
    }

    opexSteps.push({
      label: 'Delivered OPEX',
      startLevel: 0,
      delta: metrics.opexActual,
      endLevel: metrics.opexActual,
      type: 'total',
      explanation: `Total operating expenditure: ${formatCurrency(metrics.opexActual, currency)}.`,
    });
  }

  const currentSteps = activeTab === 'ebitda' ? ebitdaSteps : activeTab === 'revenue' ? revSteps : opexSteps;

  // Compute Dynamic Chart Dimensions & Bounds
  let minLevel = 0;
  let maxLevel = 0;
  currentSteps.forEach((s) => {
    minLevel = Math.min(minLevel, s.startLevel, s.endLevel);
    maxLevel = Math.max(maxLevel, s.startLevel, s.endLevel);
  });
  // Add 15% headroom for top value badges
  const range = (maxLevel - minLevel) * 1.18 || 1;

  return (
    <div
      className={`rounded-xl border shadow-xs p-5 transition-colors space-y-5 ${
        isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
      }`}
    >
      {/* Header and Mode Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-4 border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white break-words">
              Executive Variance Waterfall Bridge
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 whitespace-nowrap">
              Dynamic Chart Lengths · {metrics.period}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5 break-words">
            Step-by-step variance reconciliation from {benchmarkLabel} baseline to Delivered Performance
          </p>
        </div>

        {/* Tab Buttons */}
        <div
          className={`flex items-center rounded-lg p-0.5 border text-xs font-semibold ${
            isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800 border-slate-700'
          }`}
        >
          <button
            onClick={() => {
              setActiveTab('ebitda');
              setHoveredIdx(null);
            }}
            className={`px-3 py-1 rounded text-xs transition-all ${
              activeTab === 'ebitda'
                ? isLight
                  ? 'bg-white text-slate-900 font-bold shadow-2xs'
                  : 'bg-slate-700 text-white font-bold shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            EBITDA Walk Bridge
          </button>
          <button
            onClick={() => {
              setActiveTab('revenue');
              setHoveredIdx(null);
            }}
            className={`px-3 py-1 rounded text-xs transition-all ${
              activeTab === 'revenue'
                ? isLight
                  ? 'bg-white text-slate-900 font-bold shadow-2xs'
                  : 'bg-slate-700 text-white font-bold shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Revenue Drivers
          </button>
          <button
            onClick={() => {
              setActiveTab('opex');
              setHoveredIdx(null);
            }}
            className={`px-3 py-1 rounded text-xs transition-all ${
              activeTab === 'opex'
                ? isLight
                  ? 'bg-white text-slate-900 font-bold shadow-2xs'
                  : 'bg-slate-700 text-white font-bold shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            OPEX Drivers
          </button>
        </div>
      </div>

      {/* Closed Bridge Proof Banner */}
      {activeTab === 'ebitda' && (
        <div className="rounded-lg p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Closed-Loop EBITDA Bridge Proof:</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400">
                Discrepancy = {currency} {bridgeDiscrepancy.toFixed(2)}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Formula: Actual EBITDA = Benchmark EBITDA + Rev Var − Direct Cost Var − OPEX Var
            </span>
          </div>
          <p className="font-mono text-[11px] text-slate-600 dark:text-slate-400 mt-1">
            {formatCurrencyM(metrics.ebitdaActual, currency)} ={' '}
            {formatCurrencyM(metrics.ebitdaBenchmark, currency)} + ({formatCurrencyM(revVar, currency)}) − (
            {formatCurrencyM(metrics.cogsVariance, currency)}) − ({formatCurrencyM(metrics.opexVariance, currency)})
          </p>
        </div>
      )}

      {/* Leasing Drivers Revenue Decomposition Banner (if uploaded) */}
      {leasingDecomposition?.hasDrivers && activeTab === 'ebitda' && (
        <div className="rounded-lg p-3 bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 text-xs space-y-1">
          <div className="flex items-center gap-2 font-bold text-blue-900 dark:text-blue-300">
            <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
            <span>Leasing Driver Decomposition (Reconciles to Total Revenue Variance):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
            <div className="p-2 rounded bg-white dark:bg-slate-900 border border-blue-100 dark:border-blue-900">
              <span className="text-slate-500 block text-[10px]">Occupancy Effect:</span>
              <span className="font-bold text-slate-900 dark:text-white">
                {formatCurrency(leasingDecomposition.occupancyEffect, currency)}
              </span>
            </div>
            <div className="p-2 rounded bg-white dark:bg-slate-900 border border-blue-100 dark:border-blue-900">
              <span className="text-slate-500 block text-[10px]">Rate / GLA Effect:</span>
              <span className="font-bold text-slate-900 dark:text-white">
                {formatCurrency(leasingDecomposition.rateEffect, currency)}
              </span>
            </div>
            <div className="p-2 rounded bg-white dark:bg-slate-900 border border-blue-100 dark:border-blue-900">
              <span className="text-slate-500 block text-[10px]">Turnover Rent (TOR):</span>
              <span className="font-bold text-slate-900 dark:text-white">
                {formatCurrency(leasingDecomposition.torEffect, currency)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* THE ACTUAL INTERACTIVE WATERFALL BRIDGE CHART */}
      {/* ========================================================= */}
      <div
        className={`rounded-xl p-5 border relative overflow-hidden transition-all ${
          isLight ? 'bg-slate-50/60 border-slate-200' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        {/* Chart Watermark / Currency Scale Legend */}
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2">
          <span>Y-Axis: {currency} Scale ({metrics.period})</span>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#0F172A] dark:bg-slate-700 inline-block" />
              <span>Benchmark Anchor</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" />
              <span>Favourable (▲ +)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 inline-block" />
              <span>Adverse (▼ -)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#FF6600] inline-block" />
              <span>Delivered EBITDA</span>
            </span>
          </div>
        </div>

        {/* Chart Viewport with Gridlines & Waterfall Columns */}
        <div className="relative h-80 w-full pt-8 pb-16 sm:pb-20 flex items-stretch">
          {/* Horizontal Reference Gridlines */}
          <div className="absolute inset-x-0 inset-y-8 flex flex-col justify-between pointer-events-none opacity-40">
            <div className="border-b border-dashed border-slate-300 dark:border-slate-700 w-full" />
            <div className="border-b border-dashed border-slate-300 dark:border-slate-700 w-full" />
            <div className="border-b border-dashed border-slate-300 dark:border-slate-700 w-full" />
            <div className="border-b border-slate-400 dark:border-slate-600 w-full" />
          </div>

          {/* Dynamic Waterfall Columns Container */}
          <div className="relative w-full h-full flex items-end justify-between gap-2 sm:gap-4 z-10">
            {currentSteps.map((step, idx) => {
              const isBaseline = step.type === 'baseline';
              const isTotal = step.type === 'total';
              const isFav = step.type === 'favourable';
              const isAdv = step.type === 'adverse';

              // Calculate bar boundaries
              const barTopVal = isBaseline || isTotal ? step.delta : Math.max(step.startLevel, step.endLevel);
              const barBottomVal = isBaseline || isTotal ? 0 : Math.min(step.startLevel, step.endLevel);
              const barHeightVal = Math.max(0, barTopVal - barBottomVal);

              const bottomPct = Math.max(0, Math.min(95, ((barBottomVal - minLevel) / range) * 100));
              const heightPct = Math.max(3, Math.min(100 - bottomPct, (barHeightVal / range) * 100));

              // Formatting single clean sign without ++ or --
              const signSymbol = isFav ? '▲ +' : isAdv ? '▼ -' : '';
              const displayVal =
                isBaseline || isTotal
                  ? formatCurrencyM(step.delta, currency)
                  : `${signSymbol}${formatCurrencyM(Math.abs(step.delta), currency)}`;

              // Bar colors matching corporate luxury palette
              let barColor = isLight ? '#0F172A' : '#334155'; // Baseline default
              if (isFav) barColor = '#10B981'; // Green
              if (isAdv) barColor = '#EF4444'; // Red
              if (isTotal) barColor = '#FF6600'; // H Orange

              const isHovered = hoveredIdx === idx;

              return (
                <div
                  key={idx}
                  onMouseEnter={() => setHoveredIdx(idx)}
                  onMouseLeave={() => setHoveredIdx(null)}
                  className="relative flex-1 h-full flex flex-col justify-end items-center cursor-pointer group"
                >
                  {/* Floating Value Pill Above Bar */}
                  <div
                    className="absolute z-20 transition-transform duration-200 group-hover:-translate-y-1 text-center whitespace-nowrap"
                    style={{
                      bottom: `calc(${bottomPct + heightPct}% + 6px)`,
                    }}
                  >
                    <span
                      className={`text-[11px] font-bold font-mono px-1.5 py-0.5 rounded shadow-2xs border ${
                        isFav
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                          : isAdv
                          ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800'
                          : isTotal
                          ? 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800'
                          : 'bg-slate-100 text-slate-800 border-slate-300 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {displayVal}
                    </span>
                  </div>

                  {/* The Dynamic Waterfall Bar */}
                  <div
                    className="w-full max-w-[64px] rounded-t-sm transition-all duration-300 relative group-hover:brightness-110 shadow-sm"
                    style={{
                      height: `${heightPct}%`,
                      marginBottom: `${bottomPct}%`,
                      backgroundColor: barColor,
                    }}
                  >
                    {/* Floating Connector Line to Next Step */}
                    {idx < currentSteps.length - 1 && !isBaseline && !isTotal && (
                      <div
                        className="hidden sm:block absolute right-[-100%] w-full border-b border-dashed border-slate-400 dark:border-slate-500 pointer-events-none"
                        style={{
                          top: step.delta >= 0 ? '0%' : '100%',
                        }}
                      />
                    )}
                  </div>

                  {/* Column Bottom Label with Dynamic Text Wrapping */}
                  <div className="absolute top-full pt-2.5 w-full text-center px-0.5 z-10">
                    <span className="text-[10px] sm:text-[11px] font-bold text-slate-700 dark:text-slate-300 block break-words whitespace-normal leading-tight">
                      {step.label}
                    </span>
                    {step.subLabel && (
                      <span className="text-[9px] text-slate-400 block break-words whitespace-normal leading-tight mt-0.5">
                        {step.subLabel}
                      </span>
                    )}
                  </div>

                  {/* Interactive Floating Hover Popover */}
                  {isHovered && (
                    <div
                      className={`absolute z-30 bottom-24 p-3 rounded-lg border shadow-xl w-60 text-xs backdrop-blur-md transition-all ${
                        isLight
                          ? 'bg-white/95 border-slate-300 text-slate-900'
                          : 'bg-slate-950/95 border-slate-700 text-white'
                      }`}
                    >
                      <div className="font-bold text-[11px] uppercase tracking-wider text-slate-400 mb-1">
                        Step 0{idx + 1} · {step.label}
                      </div>
                      <div className="space-y-1 font-mono text-[11px]">
                        {!isBaseline && !isTotal && (
                          <div className="flex justify-between text-slate-500">
                            <span>Pre-step Balance:</span>
                            <span>{formatCurrency(step.startLevel, currency)}</span>
                          </div>
                        )}
                        <div className="flex justify-between font-bold">
                          <span>Step Movement:</span>
                          <span
                            className={
                              isFav ? 'text-emerald-500' : isAdv ? 'text-rose-500' : ''
                            }
                          >
                            {displayVal}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-500 border-t pt-1 border-slate-200 dark:border-slate-800">
                          <span>Reconciled Level:</span>
                          <span className="font-bold text-slate-900 dark:text-white">
                            {formatCurrency(step.endLevel, currency)}
                          </span>
                        </div>
                      </div>
                      <p className="mt-2 text-[10px] text-slate-500 dark:text-slate-400 leading-snug">
                        {step.explanation}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Baseline Zero Axis */}
        <div className="border-t border-slate-300 dark:border-slate-700 pt-2 flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span>Baseline Reference: 0.00 {currency}</span>
          <span>H Luxury FP&A Palette (EBITDA Delivered: #FF6600 Orange)</span>
        </div>
      </div>

      {/* Explanatory Walk Detail Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-1">
        {currentSteps.map((step, idx) => {
          const isBaseline = step.type === 'baseline';
          const isTotal = step.type === 'total';
          const isFav = step.type === 'favourable';
          const isAdv = step.type === 'adverse';
          const symbol = isFav ? '▲ +' : isAdv ? '▼ -' : '';

          return (
            <div
              key={idx}
              className={`rounded-lg p-3.5 border transition-all flex flex-col justify-between ${
                isBaseline || isTotal
                  ? isLight
                    ? 'bg-slate-100/70 border-slate-300'
                    : 'bg-slate-800/80 border-slate-700'
                  : isLight
                  ? 'bg-white border-slate-200'
                  : 'bg-slate-900/50 border-slate-800'
              }`}
            >
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Step 0{idx + 1}
                </span>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                  {step.label}
                </span>
              </div>

              <div className="my-2.5">
                <span
                  className={`text-lg font-bold tabular-nums block ${
                    isFav
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : isAdv
                      ? 'text-rose-600 dark:text-rose-400'
                      : isTotal
                      ? 'text-orange-600 dark:text-orange-400'
                      : isLight
                      ? 'text-slate-900'
                      : 'text-white'
                  }`}
                >
                  {isBaseline || isTotal
                    ? formatCurrencyM(step.delta, currency)
                    : `${symbol}${formatCurrencyM(Math.abs(step.delta), currency)}`}
                </span>
              </div>

              <p className="text-[11px] text-slate-500 leading-snug">{step.explanation}</p>
            </div>
          );
        })}
      </div>

      {/* Mandatory Attribution Footnote */}
      <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400">
        <span className="font-medium">{PREPARED_BY_FOOTNOTE}</span>
        <span className="font-mono text-[10px]">Closed mathematical tie-out: Delta = 0.00 {currency}</span>
      </div>
    </div>
  );
};
