import React, { useState } from 'react';
import {
  BenchmarkType,
  MacroPnlMetrics,
  SubCategoryRollup,
  VarianceRollup,
} from '../types/financial';
import { formatCurrency, formatCurrencyM, formatPpDelta } from '../utils/financialEngine';
import { ChevronDown, ChevronRight, Search, SlidersHorizontal } from 'lucide-react';
import { CORPORATE_THEME } from '../theme/themeConfig';

interface PnlRollupTableProps {
  metrics: MacroPnlMetrics;
  benchmarkType: BenchmarkType;
  grossRevenueSubs: SubCategoryRollup[];
  contraRevenueSubs: SubCategoryRollup[];
  cogsSubs: SubCategoryRollup[];
  opexSubs: SubCategoryRollup[];
  belowEbitdaSubs: SubCategoryRollup[];
  theme?: 'light' | 'dark';
  onSelectAccount?: (account: VarianceRollup) => void;
}

export const PnlRollupTable: React.FC<PnlRollupTableProps> = ({
  metrics,
  benchmarkType,
  grossRevenueSubs,
  contraRevenueSubs,
  cogsSubs,
  opexSubs,
  belowEbitdaSubs,
  theme = 'light',
  onSelectAccount,
}) => {
  const isLight = theme === 'light';
  const currency = metrics.currency;
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';

  const [searchTerm, setSearchTerm] = useState('');
  const [polarityFilter, setPolarityFilter] = useState<'ALL' | 'ADVERSE' | 'FAVOURABLE'>('ALL');
  const [expandedSubs, setExpandedSubs] = useState<Record<string, boolean>>({
    'Base Lease Revenue': true,
    'Mall Utilities': true,
    'Facility Services': true,
  });

  const toggleSub = (name: string) => {
    setExpandedSubs((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const expandAll = () => {
    const next: Record<string, boolean> = {};
    [
      ...grossRevenueSubs,
      ...contraRevenueSubs,
      ...cogsSubs,
      ...opexSubs,
      ...belowEbitdaSubs,
    ].forEach((s) => {
      next[s.name] = true;
    });
    setExpandedSubs(next);
  };

  const collapseAll = () => {
    setExpandedSubs({});
  };

  const filterAccounts = (accounts: VarianceRollup[]) => {
    return accounts.filter((acc) => {
      const matchSearch =
        acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        acc.code.includes(searchTerm) ||
        acc.subCategory.toLowerCase().includes(searchTerm.toLowerCase());
      const matchPolarity = polarityFilter === 'ALL' || acc.polarity === polarityFilter;
      return matchSearch && matchPolarity;
    });
  };

  const renderAccountRow = (acc: VarianceRollup) => {
    const isFav = acc.polarity === 'FAVOURABLE';
    const isAdv = acc.polarity === 'ADVERSE';
    const isNm = acc.displayPct === 'n.m.';
    const symbol = isNm ? '— ' : isFav ? '▲ +' : isAdv ? '▼ -' : '— ';
    const cleanDisplayPct = isNm ? 'n.m.' : acc.displayPct.replace(/^[+-]/, '');

    return (
      <tr
        key={acc.code}
        onClick={() => onSelectAccount && onSelectAccount(acc)}
        className={`border-b transition-colors text-xs cursor-pointer group ${
          isLight
            ? 'border-slate-200/60 hover:bg-slate-100/70'
            : 'border-slate-800/60 hover:bg-slate-800/50'
        }`}
      >
        <td className="py-2.5 pl-8 pr-3 font-mono font-semibold text-slate-500 group-hover:text-blue-500">
          {acc.code}
        </td>
        <td className="py-2.5 px-3 font-medium">
          <div className="flex items-center gap-2">
            <span className={isLight ? 'text-slate-900' : 'text-slate-100'}>{acc.name}</span>
            <span className="text-[10px] text-slate-400">· {acc.subCategory}</span>
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-semibold ${
                acc.controllable
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'bg-neutral-100 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400'
              }`}
            >
              {acc.controllable ? 'Controllable' : 'Non-controllable'}
            </span>
          </div>
        </td>
        <td className="py-2.5 px-3 text-right font-semibold tabular-nums">
          {formatCurrency(acc.actual, currency)}
        </td>
        <td className="py-2.5 px-3 text-right font-medium tabular-nums text-slate-500">
          {formatCurrency(acc.benchmark, currency)}
        </td>
        <td
          className={`py-2.5 px-3 text-right font-bold tabular-nums ${
            isFav
              ? 'text-emerald-600 dark:text-emerald-400'
              : isAdv
              ? 'text-rose-600 dark:text-rose-400'
              : 'text-slate-500'
          }`}
        >
          {formatCurrency(acc.dollarVariance, currency)}
        </td>
        <td
          className={`py-2.5 px-3 text-right font-bold tabular-nums ${
            isFav
              ? 'text-emerald-600 dark:text-emerald-400'
              : isAdv
              ? 'text-rose-600 dark:text-rose-400'
              : 'text-slate-500'
          }`}
        >
          <span>{symbol}</span>
          <span>{cleanDisplayPct}</span>
        </td>
        <td className="py-2.5 pr-4 pl-3 text-right tabular-nums text-slate-500">
          {Math.abs(acc.driverContributionPct).toFixed(1)}%
        </td>
      </tr>
    );
  };

  const renderSubCategory = (sub: SubCategoryRollup) => {
    const isExpanded = !!expandedSubs[sub.name];
    const filteredAccs = filterAccounts(sub.accounts);
    if (searchTerm && filteredAccs.length === 0) return null;

    const isFav = sub.polarity === 'FAVOURABLE';
    const isAdv = sub.polarity === 'ADVERSE';
    const isNm = sub.displayPct === 'n.m.';
    const symbol = isNm ? '— ' : isFav ? '▲ +' : isAdv ? '▼ -' : '— ';
    const cleanDisplayPct = isNm ? 'n.m.' : sub.displayPct.replace(/^[+-]/, '');

    return (
      <React.Fragment key={sub.name}>
        <tr
          onClick={() => toggleSub(sub.name)}
          className={`border-b text-xs font-semibold cursor-pointer transition-colors ${
            isLight
              ? 'bg-slate-50 hover:bg-slate-100 border-slate-200'
              : 'bg-slate-900/60 hover:bg-slate-800 border-slate-800'
          }`}
        >
          <td className="py-2 pl-4 pr-2 w-10">
            {isExpanded ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            )}
          </td>
          <td className="py-2 px-3">
            <span className={isLight ? 'text-slate-800 font-bold' : 'text-slate-200 font-bold'}>
              {sub.name}
            </span>
            <span className="text-[11px] text-slate-400 ml-2 font-normal">
              ({sub.accounts.length} accounts)
            </span>
          </td>
          <td className="py-2 px-3 text-right tabular-nums">{formatCurrency(sub.actual, currency)}</td>
          <td className="py-2 px-3 text-right tabular-nums text-slate-500">
            {formatCurrency(sub.benchmark, currency)}
          </td>
          <td
            className={`py-2 px-3 text-right font-bold tabular-nums ${
              isFav ? 'text-emerald-600 dark:text-emerald-400' : isAdv ? 'text-rose-600 dark:text-rose-400' : 'text-slate-500'
            }`}
          >
            {formatCurrency(sub.dollarVariance, currency)}
          </td>
          <td
            className={`py-2 px-3 text-right font-bold tabular-nums ${
              isFav ? 'text-emerald-600 dark:text-emerald-400' : isAdv ? 'text-rose-600 dark:text-rose-400' : 'text-slate-500'
            }`}
          >
            <span>{symbol}</span>
            <span>{cleanDisplayPct}</span>
          </td>
          <td className="py-2 pr-4 pl-3 text-right tabular-nums text-slate-500">
            {Math.abs(sub.driverContributionPct).toFixed(1)}%
          </td>
        </tr>
        {isExpanded && filteredAccs.map(renderAccountRow)}
      </React.Fragment>
    );
  };

  const renderMacroTotalRow = (
    label: string,
    actual: number,
    benchmark: number,
    variance: number,
    displayPctOrPp: string,
    polarity: string,
    isMajor = false
  ) => {
    const isFav = polarity === 'FAVOURABLE';
    const isAdv = polarity === 'ADVERSE';
    const isNm = displayPctOrPp === 'n.m.';
    const symbol = isNm ? '— ' : isFav ? '▲ +' : isAdv ? '▼ -' : '— ';
    const cleanDisplay = isNm ? 'n.m.' : displayPctOrPp.replace(/^[+-]/, '');

    return (
      <tr
        className={`border-y text-xs font-bold ${
          isMajor
            ? isLight
              ? 'bg-slate-100 border-slate-300 text-slate-900'
              : 'bg-slate-800 border-slate-700 text-white'
            : isLight
            ? 'bg-slate-50 border-slate-200 text-slate-800'
            : 'bg-slate-900 border-slate-800 text-slate-200'
        }`}
      >
        <td colSpan={2} className="py-3 pl-4 pr-3 text-sm tracking-tight">
          {label}
        </td>
        <td className="py-3 px-3 text-right tabular-nums text-sm font-extrabold">
          {formatCurrency(actual, currency)}
        </td>
        <td className="py-3 px-3 text-right tabular-nums text-slate-500">
          {formatCurrency(benchmark, currency)}
        </td>
        <td
          className={`py-3 px-3 text-right tabular-nums font-extrabold ${
            isFav
              ? 'text-emerald-600 dark:text-emerald-400'
              : isAdv
              ? 'text-rose-600 dark:text-rose-400'
              : 'text-slate-500'
          }`}
        >
          {formatCurrency(variance, currency)}
        </td>
        <td
          className={`py-3 px-3 text-right tabular-nums font-extrabold ${
            isFav
              ? 'text-emerald-600 dark:text-emerald-400'
              : isAdv
              ? 'text-rose-600 dark:text-rose-400'
              : 'text-slate-500'
          }`}
        >
          <span>{symbol}</span>
          <span>{cleanDisplay}</span>
        </td>
        <td className="py-3 pr-4 pl-3 text-right tabular-nums text-slate-500">—</td>
      </tr>
    );
  };

  return (
    <div
      className={`rounded-xl border shadow-xs overflow-hidden transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-[#131B26] border-slate-800'
      }`}
    >
      {/* Header and Controls */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Detailed Management P&L Statement & Hierarchy
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full reconciliation with GAAP / IFRS classification, Contra-revenue, Below-EBITDA lines and variance %
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search code or account..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`pl-8 pr-3 py-1 text-xs rounded-md border font-medium ${
                isLight ? 'bg-white border-slate-300' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          {/* Polarity Filter */}
          <div
            className={`flex items-center rounded-md p-0.5 border text-xs font-semibold ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-800 border-slate-700'
            }`}
          >
            {(['ALL', 'ADVERSE', 'FAVOURABLE'] as const).map((pol) => (
              <button
                key={pol}
                onClick={() => setPolarityFilter(pol)}
                className={`px-2 py-0.5 rounded text-[11px] transition-all ${
                  polarityFilter === pol
                    ? isLight
                      ? 'bg-white text-slate-900 font-bold shadow-2xs'
                      : 'bg-slate-700 text-white font-bold shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {pol === 'ALL' ? 'All' : pol === 'ADVERSE' ? '▼ Adverse' : '▲ Favourable'}
              </button>
            ))}
          </div>

          {/* Expand / Collapse All */}
          <button
            onClick={expandAll}
            className="text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            Expand All
          </button>
          <button
            onClick={collapseAll}
            className="text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            Collapse All
          </button>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr
              className={`border-b text-[11px] font-bold uppercase tracking-wider ${
                isLight
                  ? 'bg-slate-100/80 border-slate-200 text-slate-600'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400'
              }`}
            >
              <th className="py-2.5 pl-4 pr-2 w-16">Code</th>
              <th className="py-2.5 px-3">Line Item / Account Description</th>
              <th className="py-2.5 px-3 text-right">Actual ({currency})</th>
              <th className="py-2.5 px-3 text-right">{benchmarkLabel} ({currency})</th>
              <th className="py-2.5 px-3 text-right">Variance ({currency})</th>
              <th className="py-2.5 px-3 text-right">Variance % / pp</th>
              <th className="py-2.5 pr-4 pl-3 text-right">Driver %</th>
            </tr>
          </thead>
          <tbody>
            {/* 1. Gross Commercial Revenue */}
            <tr className="bg-blue-500/5 font-bold text-xs">
              <td colSpan={7} className="py-2 pl-4 text-blue-600 dark:text-blue-400 uppercase tracking-wider text-[11px]">
                Gross Commercial Revenue
              </td>
            </tr>
            {grossRevenueSubs.map(renderSubCategory)}
            {renderMacroTotalRow(
              'Total Gross Commercial Revenue',
              metrics.grossRevenueActual,
              metrics.grossRevenueBenchmark,
              metrics.grossRevenueVariance,
              typeof metrics.grossRevenueVariancePct === 'number'
                ? `${metrics.grossRevenueVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.grossRevenuePolarity
            )}

            {/* 2. Contra-revenue */}
            <tr className="bg-amber-500/5 font-bold text-xs">
              <td colSpan={7} className="py-2 pl-4 text-amber-600 dark:text-amber-400 uppercase tracking-wider text-[11px]">
                Less: Contra-revenue (Concessions, Waivers & Bad Debt)
              </td>
            </tr>
            {contraRevenueSubs.map(renderSubCategory)}
            {renderMacroTotalRow(
              'Total Contra-revenue Deductions',
              metrics.contraRevenueActual,
              metrics.contraRevenueBenchmark,
              metrics.contraRevenueVariance,
              typeof metrics.contraRevenueVariancePct === 'number'
                ? `${metrics.contraRevenueVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.contraRevenuePolarity
            )}

            {/* 3. Net Commercial Revenue */}
            {renderMacroTotalRow(
              'Net Commercial Revenue',
              metrics.revenueActual,
              metrics.revenueBenchmark,
              metrics.revenueVariance,
              typeof metrics.revenueVariancePct === 'number'
                ? `${metrics.revenueVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.revenuePolarity,
              true
            )}

            {/* 4. Direct Cost of Sales (COGS) */}
            <tr className="bg-purple-500/5 font-bold text-xs">
              <td colSpan={7} className="py-2 pl-4 text-purple-600 dark:text-purple-400 uppercase tracking-wider text-[11px]">
                Direct Property Operating Costs (COGS)
              </td>
            </tr>
            {cogsSubs.map(renderSubCategory)}
            {renderMacroTotalRow(
              'Total Direct Cost of Sales (COGS)',
              metrics.cogsActual,
              metrics.cogsBenchmark,
              metrics.cogsVariance,
              typeof metrics.cogsVariancePct === 'number'
                ? `${metrics.cogsVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.cogsPolarity
            )}

            {/* 5. Gross Profit */}
            {renderMacroTotalRow(
              'Gross Profit',
              metrics.grossProfitActual,
              metrics.grossProfitBenchmark,
              metrics.grossProfitVariance,
              formatPpDelta(metrics.grossMarginDeltaPp),
              metrics.grossProfitPolarity,
              true
            )}

            {/* 6. Operating Expenses (OPEX) */}
            <tr className="bg-orange-500/5 font-bold text-xs">
              <td colSpan={7} className="py-2 pl-4 text-orange-600 dark:text-orange-400 uppercase tracking-wider text-[11px]">
                Operating Expenses (OPEX)
              </td>
            </tr>
            {opexSubs.map(renderSubCategory)}
            {renderMacroTotalRow(
              'Total Operating Expenses (OPEX)',
              metrics.opexActual,
              metrics.opexBenchmark,
              metrics.opexVariance,
              typeof metrics.opexVariancePct === 'number'
                ? `${metrics.opexVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.opexPolarity
            )}

            {/* 7. Operational EBITDA */}
            {renderMacroTotalRow(
              'Operational EBITDA',
              metrics.ebitdaActual,
              metrics.ebitdaBenchmark,
              metrics.ebitdaVariance,
              formatPpDelta(metrics.ebitdaMarginDeltaPp),
              metrics.ebitdaPolarity,
              true
            )}

            {/* Visible Rounding Adjustment line if display rounded parts != total */}
            {metrics.hasRoundingDifference && (
              <tr className="bg-yellow-50 dark:bg-yellow-950/20 text-xs font-semibold text-yellow-800 dark:text-yellow-300">
                <td colSpan={2} className="py-2 pl-4">
                  Rounding Adjustment (Display Sum vs Total)
                </td>
                <td className="py-2 px-3 text-right">
                  {formatCurrencyM(metrics.roundingAdjustmentDisplay * 1_000_000, currency)}
                </td>
                <td className="py-2 px-3 text-right">—</td>
                <td className="py-2 px-3 text-right">
                  {formatCurrencyM(metrics.roundingAdjustmentDisplay * 1_000_000, currency)}
                </td>
                <td className="py-2 px-3 text-right">0.0 pp</td>
                <td className="py-2 pr-4 pl-3 text-right">—</td>
              </tr>
            )}

            {/* 8. Below EBITDA Lines */}
            <tr className="bg-slate-500/5 font-bold text-xs">
              <td colSpan={7} className="py-2 pl-4 text-slate-600 dark:text-slate-400 uppercase tracking-wider text-[11px]">
                Other Income, Depreciation, Financing & Tax
              </td>
            </tr>
            {belowEbitdaSubs.map(renderSubCategory)}

            {/* Operating Profit (EBIT) */}
            {renderMacroTotalRow(
              'Operating Profit (EBIT)',
              metrics.ebitActual,
              metrics.ebitBenchmark,
              metrics.ebitVariance,
              typeof metrics.ebitVariancePct === 'number'
                ? `${metrics.ebitVariancePct.toFixed(1)}%`
                : 'n.m.',
              metrics.ebitPolarity,
              true
            )}

            {/* Net Profit After Tax */}
            {renderMacroTotalRow(
              'Net Profit After Tax',
              metrics.netProfitActual,
              metrics.netProfitBenchmark,
              metrics.netProfitVariance,
              formatPpDelta(metrics.netMarginDeltaPp),
              metrics.netProfitPolarity,
              true
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
