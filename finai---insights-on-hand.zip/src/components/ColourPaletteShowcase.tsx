import React, { useState } from 'react';
import { Palette, Check, Sparkles, ChevronDown, ChevronUp, ExternalLink, SlidersHorizontal, FileSpreadsheet, Presentation, FileText } from 'lucide-react';
import { CorporateTheme } from '../theme/themeConfig';

interface ColourPaletteShowcaseProps {
  activeTheme: CorporateTheme;
  theme: 'light' | 'dark';
  onOpenPaletteModal: () => void;
}

export const ColourPaletteShowcase: React.FC<ColourPaletteShowcaseProps> = ({
  activeTheme,
  theme,
  onOpenPaletteModal,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isLight = theme === 'light';

  // Standard brand tokens from H Brand Guidelines artifact
  const tokens = activeTheme.brandTokens || [
    { name: 'H Orange', hex: activeTheme.colors.primary, rgb: '255, 102, 0', role: 'Signature brand colour (Energy & Heritage)' },
    { name: 'Ébène', hex: activeTheme.colors.secondary, rgb: '59, 47, 42', role: 'Luxury & refinement (Text, accents, depth)' },
    { name: 'Gris Perle', hex: activeTheme.colors.grisPerle || '#C9C4BC', rgb: '201, 196, 188', role: 'Surfaces & subtle elevation', textDark: true },
    { name: 'Ivoire', hex: activeTheme.colors.surfaceLight, rgb: '248, 246, 241', role: 'Clean & timeless main backgrounds', textDark: true },
    { name: 'Anthracite', hex: activeTheme.colors.surfaceDark, rgb: '31, 31, 31', role: 'Headings & high-contrast text' },
    { name: 'Or (Gold)', hex: activeTheme.colors.accent, rgb: '212, 175, 55', role: 'Icons, buttons & golden highlights', textDark: true },
    { name: 'Success Green', hex: activeTheme.colors.favourable, rgb: '16, 185, 129', role: 'Favourable variance (▲ +)' },
    { name: 'Error Red', hex: activeTheme.colors.adverse, rgb: '239, 68, 68', role: 'Adverse variance (▼ -)' },
  ];

  const isHermes = activeTheme.id === 'hermes-luxury';

  return (
    <section
      aria-label="Corporate Colour Palette"
      className={`rounded-xl border shadow-xs transition-all duration-200 overflow-hidden ${
        isLight
          ? 'bg-white border-[#E5E7EB] text-[#1F1F1F]'
          : 'bg-[#181513] border-[#3B2F2A] text-[#F8F6F1]'
      }`}
    >
      {/* Top Banner Row */}
      <div className="px-4 py-3 sm:px-5 flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] dark:border-[#3B2F2A]/60 bg-gradient-to-r from-orange-500/5 via-amber-500/5 to-transparent">
        <div className="flex items-center gap-3">
          {/* Brand Icon Badge */}
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white shadow-xs shrink-0"
            style={{ backgroundColor: activeTheme.colors.primary }}
          >
            {isHermes ? 'H' : <Palette className="w-4 h-4 text-white" />}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-[#FF6600]">
                {activeTheme.brandTag || 'Corporate Brand Palette'}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                <Check className="w-3 h-3" />
                Active Deployed Palette
              </span>
            </div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold tracking-tight">
                {activeTheme.name}
              </h2>
              {isHermes && (
                <span className="text-xs text-[#9CA3AF] italic hidden md:inline">
                  "A lasting spirit of elegance"
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenPaletteModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border transition-all text-[#1F1F1F] dark:text-white bg-white dark:bg-[#28221F] border-[#CBD5E1] dark:border-[#4A3C35] hover:border-[#FF6600] shadow-2xs"
            title="Inspect full colour tokens, modify hex codes, or switch theme preset"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#FF6600]" />
            <span>Theme Manager</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg text-[#6B7280] dark:text-[#9CA3AF] hover:bg-neutral-100 dark:hover:bg-neutral-800/60 transition-colors"
          >
            <span>{isExpanded ? 'Hide Specs' : 'Show Specs'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Primary Swatches Ribbon (Always visible so user clearly sees their palette!) */}
      <div className="p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#6B7280] dark:text-[#9CA3AF]">
            Corporate Colour Tokens (Extracted directly from Brand Guidelines Artifact)
          </span>
          <span className="text-[11px] text-[#6B7280] dark:text-[#9CA3AF]">
            Accounting Rule: Colors always accompanied by <strong className="text-emerald-600 dark:text-emerald-400">▲ +</strong> and <strong className="text-rose-600 dark:text-rose-400">▼ -</strong>
          </span>
        </div>

        {/* Swatch Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
          {tokens.map((tok) => {
            return (
              <div
                key={tok.name}
                className={`p-2.5 rounded-lg border transition-transform hover:scale-[1.02] shadow-2xs ${
                  isLight
                    ? 'bg-neutral-50/70 border-[#E5E7EB]'
                    : 'bg-[#221C19] border-[#3B2F2A]'
                }`}
              >
                {/* Visual Swatch Color Box */}
                <div
                  className="w-full h-10 rounded-md mb-2 shadow-inner border border-black/10 flex items-center justify-center font-bold text-xs"
                  style={{
                    backgroundColor: tok.hex,
                    color: tok.textDark ? '#1F1F1F' : '#FFFFFF',
                  }}
                >
                  {tok.name.includes('Success') ? '▲ +' : tok.name.includes('Error') ? '▼ -' : ''}
                </div>

                <div className="space-y-0.5">
                  <span className="text-[11px] font-bold block truncate" title={tok.name}>
                    {tok.name}
                  </span>
                  <span className="text-[11px] font-mono font-bold block text-[#FF6600]">
                    {tok.hex}
                  </span>
                  <span className="text-[10px] text-[#9CA3AF] block font-mono">
                    RGB {tok.rgb}
                  </span>
                  <p className="text-[10px] text-[#6B7280] dark:text-[#9CA3AF] line-clamp-1 mt-1" title={tok.role}>
                    {tok.role}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expandable Technical Specification Drawer */}
      {isExpanded && (
        <div className="px-4 pb-5 sm:px-5 pt-2 border-t border-[#E5E7EB] dark:border-[#3B2F2A]/60 space-y-4 bg-black/5 dark:bg-black/20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
            {/* Excel Spec */}
            <div className={`p-3 rounded-lg border text-xs ${isLight ? 'bg-white border-[#E5E7EB]' : 'bg-[#1C1715] border-[#3B2F2A]'}`}>
              <div className="flex items-center gap-1.5 font-bold mb-2 text-[#FF6600]">
                <FileSpreadsheet className="w-4 h-4" />
                <span>Excel Workbook (.xlsx)</span>
              </div>
              <ul className="space-y-1 text-[11px] text-[#6B7280] dark:text-[#9CA3AF]">
                <li>Header Fill: <code className="font-mono text-[#FF6600] font-bold">{activeTheme.excel.headerFill}</code> (H Orange)</li>
                <li>Sub-header Fill: <code className="font-mono font-bold">{activeTheme.excel.subHeaderFill}</code> (Ivoire)</li>
                <li>Grid Border: <code className="font-mono">{activeTheme.excel.borderGrid}</code> (E5E7EB)</li>
                <li>Number Format: <code className="font-mono">_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)</code></li>
              </ul>
            </div>

            {/* PPTX Spec */}
            <div className={`p-3 rounded-lg border text-xs ${isLight ? 'bg-white border-[#E5E7EB]' : 'bg-[#1C1715] border-[#3B2F2A]'}`}>
              <div className="flex items-center gap-1.5 font-bold mb-2 text-[#3B2F2A] dark:text-[#D4AF37]">
                <Presentation className="w-4 h-4" />
                <span>PowerPoint Deck (6 Slides)</span>
              </div>
              <ul className="space-y-1 text-[11px] text-[#6B7280] dark:text-[#9CA3AF]">
                <li>Title & Ébène: <code className="font-mono font-bold">#{activeTheme.pptx.primary}</code></li>
                <li>Waterfall Accent: <code className="font-mono text-[#FF6600] font-bold">#{activeTheme.pptx.secondary}</code></li>
                <li>Gold Highlights: <code className="font-mono font-bold">#{activeTheme.pptx.accent}</code></li>
                <li>Slide Canvas: <code className="font-mono font-bold">#{activeTheme.pptx.surface}</code> (Ivoire)</li>
              </ul>
            </div>

            {/* PDF Spec */}
            <div className={`p-3 rounded-lg border text-xs ${isLight ? 'bg-white border-[#E5E7EB]' : 'bg-[#1C1715] border-[#3B2F2A]'}`}>
              <div className="flex items-center gap-1.5 font-bold mb-2 text-[#10B981]">
                <FileText className="w-4 h-4" />
                <span>PDF Dossier (Landscape)</span>
              </div>
              <ul className="space-y-1 text-[11px] text-[#6B7280] dark:text-[#9CA3AF]">
                <li>Primary RGB: <code className="font-mono font-bold">[{activeTheme.pdf.primaryRgb.join(', ')}]</code> (Orange)</li>
                <li>Accent RGB: <code className="font-mono font-bold">[{activeTheme.pdf.secondaryRgb.join(', ')}]</code> (Ébène)</li>
                <li>Centered Header: <code className="font-mono font-bold">x = 148.5mm</code> (A4 Landscape)</li>
                <li>Table AutoTable: <code className="font-mono font-bold">Usable Width = 269mm</code></li>
              </ul>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between text-xs text-[#9CA3AF] pt-1">
            <span className="italic">
              Brand Guidelines: "Crafting exceptional objects since 1837" — Integrated into FinAI Institutional FP&A Suite.
            </span>
            <button
              onClick={onOpenPaletteModal}
              className="text-[#FF6600] font-bold hover:underline inline-flex items-center gap-1"
            >
              <span>Manage Palette Tokens & Themes</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
