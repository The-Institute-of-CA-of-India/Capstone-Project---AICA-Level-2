import {
  FinancialAccount,
  AccountMapping,
  LeasingDriverData,
  OpenQuestionAction,
  PeriodType,
  PriorRunComparison,
} from '../types/financial';

/**
 * Default UAE Retail / Mall Properties Account Mapping Template
 * Account code -> P&L line -> Tier -> Controllable Y/N -> Sign
 */
export const DEFAULT_UAE_ACCOUNT_MAPPINGS: AccountMapping[] = [
  // Commercial Revenue
  { code: '4110', name: 'Anchor Tenant Base Rent', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: false, sign: 1, subCategory: 'Base Lease Revenue' },
  { code: '4120', name: 'In-Line Store Base Rent', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Base Lease Revenue' },
  { code: '4130', name: 'Food & Beverage (F&B) Base Rent', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Base Lease Revenue' },
  { code: '4140', name: 'Entertainment & Cinema Base Rent', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: false, sign: 1, subCategory: 'Base Lease Revenue' },
  { code: '4210', name: 'Retail Tenant Turnover Rent (TOR)', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: false, sign: 1, subCategory: 'Turnover & Specialty' },
  { code: '4220', name: 'Pop-up & Kiosk Specialty Leasing', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Turnover & Specialty' },
  { code: '4310', name: 'Tenant CAM & Service Charge Recoveries', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Recoveries & Sundry' },
  { code: '4320', name: 'Mall Media, Atrium & Digital Advertising', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Recoveries & Sundry' },
  { code: '4330', name: 'Customer Paid Parking & Valet Revenue', pnlLine: 'Gross Commercial Revenue', tier: 'REVENUE', controllable: true, sign: 1, subCategory: 'Recoveries & Sundry' },

  // Contra-revenue
  { code: '4910', name: 'Tenant Rent-Free Amortisation', pnlLine: 'Contra-revenue', tier: 'CONTRA_REVENUE', controllable: false, sign: 1, subCategory: 'Lease Concessions' },
  { code: '4920', name: 'Early Fit-out Discounts & Rebates', pnlLine: 'Contra-revenue', tier: 'CONTRA_REVENUE', controllable: true, sign: 1, subCategory: 'Lease Concessions' },
  { code: '4930', name: 'Provision for Doubtful Tenant Debts', pnlLine: 'Contra-revenue', tier: 'CONTRA_REVENUE', controllable: true, sign: 1, subCategory: 'Lease Concessions' },

  // Cost of Sales (COGS)
  { code: '5110', name: 'Direct Mall Electricity & Chilled Water', pnlLine: 'Cost of Sales (COGS)', tier: 'COGS', controllable: true, sign: 1, subCategory: 'Mall Utilities' },
  { code: '5120', name: 'Municipal Water & Sewerage Charges', pnlLine: 'Cost of Sales (COGS)', tier: 'COGS', controllable: true, sign: 1, subCategory: 'Mall Utilities' },
  { code: '5130', name: 'HVAC Plant Maintenance & Filters', pnlLine: 'Cost of Sales (COGS)', tier: 'COGS', controllable: true, sign: 1, subCategory: 'Plant & Equipment' },
  { code: '5140', name: 'Elevators & Escalators Service Contracts', pnlLine: 'Cost of Sales (COGS)', tier: 'COGS', controllable: false, sign: 1, subCategory: 'Plant & Equipment' },

  // Operating Expenses (OPEX)
  { code: '6110', name: 'Facilities Custodial Cleaning & Waste', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'Facility Services' },
  { code: '6120', name: 'Security Personnel & CCTV Monitoring', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'Facility Services' },
  { code: '6130', name: 'Landscaping & Exterior Ground Care', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'Facility Services' },
  { code: '6210', name: 'Seasonal Events & Ramadan Promotions', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'Marketing & PR' },
  { code: '6220', name: 'Digital Media & Brand Partnerships', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'Marketing & PR' },
  { code: '6310', name: 'Property Management & Leasing Staff', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'General & Admin' },
  { code: '6320', name: 'Corporate Head Office IT & Software', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: false, sign: 1, subCategory: 'General & Admin' },
  { code: '6330', name: 'Property Asset Insurance Premiums', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: false, sign: 1, subCategory: 'General & Admin' },
  { code: '6340', name: 'Legal Tenancy Arbitration & Advisory', pnlLine: 'Operating Expenses (OPEX)', tier: 'OPEX', controllable: true, sign: 1, subCategory: 'General & Admin' },

  // Other Income
  { code: '7110', name: 'Sundry Operational Income & Scrap', pnlLine: 'Other Income', tier: 'OTHER_INCOME', controllable: false, sign: 1, subCategory: 'Other Income' },

  // Depreciation & Amortisation
  { code: '8110', name: 'Core Building & Plant Depreciation', pnlLine: 'Depreciation & Amortisation', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'Depreciation' },

  // IFRS 16 Lease Effects
  { code: '8120', name: 'IFRS 16 Right-of-Use Asset Depreciation', pnlLine: 'IFRS 16 Lease Effects', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'IFRS 16' },

  // Impairment
  { code: '8210', name: 'Tenant Leasehold Impairment', pnlLine: 'Impairment', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'Impairment' },

  // FX Gains/Losses
  { code: '8310', name: 'Foreign Currency Exchange Variance', pnlLine: 'FX Gains/Losses', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'FX' },

  // Finance Costs (Split)
  { code: '9110', name: 'Term Loan Bank Interest (EIBOR)', pnlLine: 'Finance Costs', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'Finance Costs' },
  { code: '9120', name: 'IFRS 16 Lease Liability Finance Accrual', pnlLine: 'Finance Costs', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'Finance Costs' },

  // Tax (Split)
  { code: '9210', name: 'UAE Federal Corporate Tax (9%)', pnlLine: 'Tax', tier: 'BELOW_EBITDA', controllable: false, sign: 1, subCategory: 'Tax' },

  // Balance Sheet (1000s, 2000s, 3000s)
  { code: '1110', name: 'Operating Cash & Bank Accounts', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Current Assets' },
  { code: '1210', name: 'Tenant Trade Receivables', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Current Assets' },
  { code: '1220', name: 'Allowance for Doubtful Debts', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: -1, subCategory: 'Current Assets' },
  { code: '1510', name: 'Mall Investment Property & Freehold Land', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Non-Current Assets' },
  { code: '1520', name: 'Accumulated Depreciation - Property', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: -1, subCategory: 'Non-Current Assets' },
  { code: '1530', name: 'IFRS 16 Right-of-Use Lease Assets', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Non-Current Assets' },
  { code: '2110', name: 'Trade Payables & Accrued Contractor Costs', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Current Liabilities' },
  { code: '2120', name: 'Tenant Security Deposits Held', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Current Liabilities' },
  { code: '2210', name: 'Syndicated Senior Bank Facility', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Non-Current Liabilities' },
  { code: '2220', name: 'IFRS 16 Lease Liabilities', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Non-Current Liabilities' },
  { code: '3110', name: 'Paid-Up Share Capital', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Equity' },
  { code: '3210', name: 'Opening Retained Earnings', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Equity' },
  { code: '3220', name: 'Current Period Retained Profit Movement', pnlLine: 'Balance Sheet', tier: 'BALANCE_SHEET', controllable: false, sign: 1, subCategory: 'Equity' },
];

/**
 * UAE Retail Mall Real-Estate Consolidated Trial Balance (in AED)
 * Calibrated so:
 * 1. Total Debits - Total Credits = 0 (exact balance check)
 * 2. Net Profit = Current Period Retained Earnings (Account 3220) movement
 * 3. Actual EBITDA = Benchmark EBITDA + Revenue Var - Direct Cost Var - OPEX Var
 */

// Let's compute exact P&L totals in AED:
// Gross Revenue:
// 4110: Actual 18,200,000 | Budget 18,500,000
// 4120: Actual 12,450,000 | Budget 13,200,000
// 4130: Actual  5,100,000 | Budget  4,900,000
// 4140: Actual  2,850,000 | Budget  3,000,000
// 4210: Actual  3,200,000 | Budget  4,100,000
// 4220: Actual  1,150,000 | Budget  1,000,000
// 4310: Actual  4,800,000 | Budget  4,600,000
// 4320: Actual  1,450,000 | Budget  1,200,000
// 4330: Actual    920,000 | Budget    850,000
// Total Gross Revenue: Actual 50,120,000 | Budget 51,350,000

// Contra-revenue:
// 4910: Actual 1,100,000 | Budget 900,000
// 4920: Actual   450,000 | Budget 300,000
// 4930: Actual   520,000 | Budget 350,000
// Total Contra-revenue: Actual 2,070,000 | Budget 1,550,000
// Net Commercial Revenue: Actual 48,050,000 | Budget 49,800,000 (Variance: -1,750,000)

// Direct COGS:
// 5110: Actual 5,420,000 | Budget 4,800,000
// 5120: Actual   680,000 | Budget   600,000
// 5130: Actual 1,450,000 | Budget 1,300,000
// 5140: Actual   950,000 | Budget   950,000
// Total COGS: Actual 8,500,000 | Budget 7,650,000 (Cost Overrun: +850,000 -> hurts EBITDA)

// Gross Profit: Actual 39,550,000 | Budget 42,150,000

// OPEX:
// 6110: Actual 2,850,000 | Budget 2,600,000
// 6120: Actual 1,950,000 | Budget 1,800,000
// 6130: Actual   480,000 | Budget   500,000
// 6210: Actual 1,650,000 | Budget 1,400,000
// 6220: Actual   620,000 | Budget   700,000
// 6310: Actual 3,100,000 | Budget 2,950,000
// 6320: Actual   780,000 | Budget   750,000
// 6330: Actual   920,000 | Budget   920,000
// 6340: Actual   450,000 | Budget   680,000
// Total OPEX: Actual 12,800,000 | Budget 12,300,000 (Cost Overrun: +500,000 -> hurts EBITDA)

// Operational EBITDA:
// Actual = 39,550,000 - 12,800,000 = 26,750,000
// Budget = 42,150,000 - 12,300,000 = 29,850,000
// EBITDA Variance = 26,750,000 - 29,850,000 = -3,100,000 AED
// Closed Bridge Proof:
// Benchmark EBITDA (29,850,000)
// + Revenue Variance (-1,750,000)
// - Direct Cost Variance (+850,000)
// - OPEX Variance (+500,000)
// = 29,850,000 - 1,750,000 - 850,000 - 500,000 = 26,750,000 AED. (Difference = 0 AED).

// Below EBITDA:
// Other Income (7110): Actual 320,000 | Budget 200,000
// Depreciation (8110): Actual 4,200,000 | Budget 4,200,000
// IFRS 16 Depreciation (8120): Actual 1,800,000 | Budget 1,800,000
// Impairment (8210): Actual 250,000 | Budget 0
// FX (8310): Actual -80,000 | Budget 0
// EBIT = EBITDA (26,750,000) + Other Income (320,000) - DA (4,200,000) - IFRS16 (1,800,000) - Impairment (250,000) + FX (-80,000) = 20,740,000 AED.
// Finance Costs:
// 9110: Actual 3,400,000 | Budget 3,200,000
// 9120: Actual   950,000 | Budget   950,000
// Total Finance Costs: 4,350,000
// Profit Before Tax: 20,740,000 - 4,350,000 = 16,390,000 AED
// Tax (9210): UAE Corporate Tax 9% of PBT = 1,475,100 AED
// Net Profit = 16,390,000 - 1,475,100 = 14,914,900 AED!

// Balance Sheet Tie-Out:
// Total Debits - Total Credits = 0
// Net Profit (14,914,900) ties out to Account 3220 (Current Period Retained Profit Movement: 14,914,900 Credit)!

export const METROPOLITAN_MALL_DATASET: FinancialAccount[] = [
  // Commercial Revenue (Credit balances in TB, expressed as positive revenue)
  {
    code: '4110',
    name: 'Anchor Tenant Base Rent',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Base Lease Revenue',
    actual: 18200000,
    budget: 18500000,
    forecast: 18300000,
    priorPeriod: 18000000,
    credit: 18200000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Long-term 10-year master leases (Hypermarket & Department Stores)',
  },
  {
    code: '4120',
    name: 'In-Line Store Base Rent',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Base Lease Revenue',
    actual: 12450000,
    budget: 13200000,
    forecast: 12800000,
    priorPeriod: 12900000,
    credit: 12450000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Fashion & apparel leasing rates; affected by 2 mid-corridor unit vacancies',
  },
  {
    code: '4130',
    name: 'Food & Beverage (F&B) Base Rent',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Base Lease Revenue',
    actual: 5100000,
    budget: 4900000,
    forecast: 5050000,
    priorPeriod: 4800000,
    credit: 5100000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Food court and terrace casual dining lease renewals',
  },
  {
    code: '4140',
    name: 'Entertainment & Cinema Base Rent',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Base Lease Revenue',
    actual: 2850000,
    budget: 3000000,
    forecast: 2900000,
    priorPeriod: 2950000,
    credit: 2850000,
    isBalanceSheet: false,
    controllable: false,
    notes: '12-screen multiplex & family entertainment centre leases',
  },
  {
    code: '4210',
    name: 'Retail Tenant Turnover Rent (TOR)',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Turnover & Specialty',
    actual: 3200000,
    budget: 4100000,
    forecast: 3600000,
    priorPeriod: 3950000,
    credit: 3200000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Tenant retail sales percentage rent; softer retail luxury turnover',
  },
  {
    code: '4220',
    name: 'Pop-up & Kiosk Specialty Leasing',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Turnover & Specialty',
    actual: 1150000,
    budget: 1000000,
    forecast: 1100000,
    priorPeriod: 980000,
    credit: 1150000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Mall concourse activation kiosks and holiday pop-up carts',
  },
  {
    code: '4310',
    name: 'Tenant CAM & Service Charge Recoveries',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Recoveries & Sundry',
    actual: 4800000,
    budget: 4600000,
    forecast: 4700000,
    priorPeriod: 4500000,
    credit: 4800000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Contractual Common Area Maintenance pass-through recoveries',
  },
  {
    code: '4320',
    name: 'Mall Media, Atrium & Digital Advertising',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Recoveries & Sundry',
    actual: 1450000,
    budget: 1200000,
    forecast: 1350000,
    priorPeriod: 1150000,
    credit: 1450000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Digital LED screens and atrium experiential advertising',
  },
  {
    code: '4330',
    name: 'Customer Paid Parking & Valet Revenue',
    category: 'REVENUE',
    pnlLine: 'Gross Commercial Revenue',
    subCategory: 'Recoveries & Sundry',
    actual: 920000,
    budget: 850000,
    forecast: 890000,
    priorPeriod: 820000,
    credit: 920000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Automated barrier gate fees and VIP valet operations',
  },

  // Contra-revenue (Deductions from revenue)
  {
    code: '4910',
    name: 'Tenant Rent-Free Amortisation',
    category: 'CONTRA_REVENUE',
    pnlLine: 'Contra-revenue',
    subCategory: 'Lease Concessions',
    actual: 1100000,
    budget: 900000,
    forecast: 1050000,
    priorPeriod: 950000,
    debit: 1100000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Straight-line IFRS 16 lease incentive amortisation',
  },
  {
    code: '4920',
    name: 'Early Fit-out Discounts & Rebates',
    category: 'CONTRA_REVENUE',
    pnlLine: 'Contra-revenue',
    subCategory: 'Lease Concessions',
    actual: 450000,
    budget: 300000,
    forecast: 400000,
    priorPeriod: 280000,
    debit: 450000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Fit-out rent waivers granted during retail corridor refit',
  },
  {
    code: '4930',
    name: 'Provision for Doubtful Tenant Debts',
    category: 'CONTRA_REVENUE',
    pnlLine: 'Contra-revenue',
    subCategory: 'Lease Concessions',
    actual: 520000,
    budget: 350000,
    forecast: 450000,
    priorPeriod: 320000,
    debit: 520000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Specific tenant provisioning for overdue receivables >90 days',
  },

  // Direct Cost of Sales (COGS)
  {
    code: '5110',
    name: 'Direct Mall Electricity & Chilled Water',
    category: 'COGS',
    pnlLine: 'Cost of Sales (COGS)',
    subCategory: 'Mall Utilities',
    actual: 5420000,
    budget: 4800000,
    forecast: 5200000,
    priorPeriod: 4950000,
    debit: 5420000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'District cooling chilled water and summer air conditioning load',
  },
  {
    code: '5120',
    name: 'Municipal Water & Sewerage Charges',
    category: 'COGS',
    pnlLine: 'Cost of Sales (COGS)',
    subCategory: 'Mall Utilities',
    actual: 680000,
    budget: 600000,
    forecast: 650000,
    priorPeriod: 620000,
    debit: 680000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Municipal utility consumption across common mall restrooms and irrigation',
  },
  {
    code: '5130',
    name: 'HVAC Plant Maintenance & Filters',
    category: 'COGS',
    pnlLine: 'Cost of Sales (COGS)',
    subCategory: 'Plant & Equipment',
    actual: 1450000,
    budget: 1300000,
    forecast: 1400000,
    priorPeriod: 1350000,
    debit: 1450000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Preventive AHU filter change-outs and chiller overhaul servicing',
  },
  {
    code: '5140',
    name: 'Elevators & Escalators Service Contracts',
    category: 'COGS',
    pnlLine: 'Cost of Sales (COGS)',
    subCategory: 'Plant & Equipment',
    actual: 950000,
    budget: 950000,
    forecast: 950000,
    priorPeriod: 920000,
    debit: 950000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Annual fixed maintenance contract across 42 escalators and 18 elevators',
  },

  // Operating Expenses (OPEX)
  {
    code: '6110',
    name: 'Facilities Custodial Cleaning & Waste',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'Facility Services',
    actual: 2850000,
    budget: 2600000,
    forecast: 2750000,
    priorPeriod: 2550000,
    debit: 2850000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Outsourced janitorial cleaning contracts and compactor waste management',
  },
  {
    code: '6120',
    name: 'Security Personnel & CCTV Monitoring',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'Facility Services',
    actual: 1950000,
    budget: 1800000,
    forecast: 1900000,
    priorPeriod: 1780000,
    debit: 1950000,
    isBalanceSheet: false,
    controllable: true,
    notes: '24/7 security guard shifts, parking control and control room operators',
  },
  {
    code: '6130',
    name: 'Landscaping & Exterior Ground Care',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'Facility Services',
    actual: 480000,
    budget: 500000,
    forecast: 490000,
    priorPeriod: 510000,
    debit: 480000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Exterior boulevard date palms and seasonal landscape maintenance',
  },
  {
    code: '6210',
    name: 'Seasonal Events & Ramadan Promotions',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'Marketing & PR',
    actual: 1650000,
    budget: 1400000,
    forecast: 1600000,
    priorPeriod: 1450000,
    debit: 1650000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Mall campaign installations, festival live stage and influencer activations',
  },
  {
    code: '6220',
    name: 'Digital Media & Brand Partnerships',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'Marketing & PR',
    actual: 620000,
    budget: 700000,
    forecast: 650000,
    priorPeriod: 680000,
    debit: 620000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Paid social media campaigns and mall app loyalty program rewards',
  },
  {
    code: '6310',
    name: 'Property Management & Leasing Staff',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'General & Admin',
    actual: 3100000,
    budget: 2950000,
    forecast: 3050000,
    priorPeriod: 2900000,
    debit: 3100000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'On-site mall GM, operations, leasing managers and engineering team salaries',
  },
  {
    code: '6320',
    name: 'Corporate Head Office IT & Software',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'General & Admin',
    actual: 780000,
    budget: 750000,
    forecast: 770000,
    priorPeriod: 740000,
    debit: 780000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'ERP enterprise software licenses, footfall camera analytics platform',
  },
  {
    code: '6330',
    name: 'Property Asset Insurance Premiums',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'General & Admin',
    actual: 920000,
    budget: 920000,
    forecast: 920000,
    priorPeriod: 890000,
    debit: 920000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Comprehensive property all-risks and public liability coverage',
  },
  {
    code: '6340',
    name: 'Legal Tenancy Arbitration & Advisory',
    category: 'OPEX',
    pnlLine: 'Operating Expenses (OPEX)',
    subCategory: 'General & Admin',
    actual: 450000,
    budget: 680000,
    forecast: 500000,
    priorPeriod: 620000,
    debit: 450000,
    isBalanceSheet: false,
    controllable: true,
    notes: 'Rental dispute settlement fees; savings from negotiated tenant settlements',
  },

  // Other Income
  {
    code: '7110',
    name: 'Sundry Operational Income & Scrap',
    category: 'OTHER_INCOME',
    pnlLine: 'Other Income',
    subCategory: 'Other Income',
    actual: 320000,
    budget: 200000,
    forecast: 280000,
    priorPeriod: 190000,
    credit: 320000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Cardboard recycling revenue and tenant fit-out review admin fees',
  },

  // Below EBITDA lines
  {
    code: '8110',
    name: 'Core Building & Plant Depreciation',
    category: 'BELOW_EBITDA',
    pnlLine: 'Depreciation & Amortisation',
    subCategory: 'Depreciation',
    actual: 4200000,
    budget: 4200000,
    forecast: 4200000,
    priorPeriod: 4100000,
    debit: 4200000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Straight-line 30-year depreciation on core structure and MEP assets',
  },
  {
    code: '8120',
    name: 'IFRS 16 Right-of-Use Asset Depreciation',
    category: 'BELOW_EBITDA',
    pnlLine: 'IFRS 16 Lease Effects',
    subCategory: 'IFRS 16',
    actual: 1800000,
    budget: 1800000,
    forecast: 1800000,
    priorPeriod: 1800000,
    debit: 1800000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Depreciation on long-term municipal land lease right-of-use asset',
  },
  {
    code: '8210',
    name: 'Tenant Leasehold Impairment',
    category: 'BELOW_EBITDA',
    pnlLine: 'Impairment',
    subCategory: 'Impairment',
    actual: 250000,
    budget: 0,
    forecast: 200000,
    priorPeriod: 0,
    debit: 250000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Write-down of customized landlord fit-out for vacated department store',
  },
  {
    code: '8310',
    name: 'Foreign Currency Exchange Variance',
    category: 'BELOW_EBITDA',
    pnlLine: 'FX Gains/Losses',
    subCategory: 'FX',
    actual: -80000,
    budget: 0,
    forecast: -50000,
    priorPeriod: 10000,
    debit: 80000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Unrealized FX movement on overseas specialty procurement contracts (EUR/GBP)',
  },
  {
    code: '9110',
    name: 'Term Loan Bank Interest (EIBOR)',
    category: 'BELOW_EBITDA',
    pnlLine: 'Finance Costs',
    subCategory: 'Finance Costs',
    actual: 3400000,
    budget: 3200000,
    forecast: 3350000,
    priorPeriod: 3150000,
    debit: 3400000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Syndicated debt interest tied to 3-month UAE EIBOR + margin',
  },
  {
    code: '9120',
    name: 'IFRS 16 Lease Liability Finance Accrual',
    category: 'BELOW_EBITDA',
    pnlLine: 'Finance Costs',
    subCategory: 'Finance Costs',
    actual: 950000,
    budget: 950000,
    forecast: 950000,
    priorPeriod: 950000,
    debit: 950000,
    isBalanceSheet: false,
    controllable: false,
    notes: 'Interest accretion on land lease concession liabilities',
  },
  {
    code: '9210',
    name: 'UAE Federal Corporate Tax (9%)',
    category: 'BELOW_EBITDA',
    pnlLine: 'Tax',
    subCategory: 'Tax',
    actual: 1475100,
    budget: 1572300,
    forecast: 1520000,
    priorPeriod: 1420000,
    debit: 1475100,
    isBalanceSheet: false,
    controllable: false,
    notes: 'UAE statutory corporate tax calculated at 9% on taxable profit',
  },

  // ==========================================
  // BALANCE SHEET ACCOUNTS (1000s, 2000s, 3000s)
  // Reconciled so Total Debits = Total Credits
  // Retained Earnings movement ties out to Net Profit!
  // ==========================================
  {
    code: '1110',
    name: 'Operating Cash & Bank Accounts (FAB / ENBD)',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Current Assets',
    actual: 42500000,
    budget: 40000000,
    forecast: 41500000,
    priorPeriod: 38000000,
    debit: 42500000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Cash at bank with First Abu Dhabi Bank and Emirates NBD',
  },
  {
    code: '1210',
    name: 'Tenant Trade Receivables',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Current Assets',
    actual: 16800000,
    budget: 14500000,
    forecast: 15500000,
    priorPeriod: 13900000,
    debit: 16800000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Invoiced tenant base and turnover rents awaiting collection',
  },
  {
    code: '1220',
    name: 'Allowance for Doubtful Debts',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Current Assets',
    actual: -1850000,
    budget: -1500000,
    forecast: -1700000,
    priorPeriod: -1400000,
    credit: 1850000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Contra-asset provision for delinquent tenant receivables',
  },
  {
    code: '1510',
    name: 'Mall Investment Property & Freehold Land',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Non-Current Assets',
    actual: 1250000000,
    budget: 1250000000,
    forecast: 1250000000,
    priorPeriod: 1250000000,
    debit: 1250000000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Fair value / cost model of mall land and superstructure',
  },
  {
    code: '1520',
    name: 'Accumulated Depreciation - Property',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Non-Current Assets',
    actual: -126000000,
    budget: -121800000,
    forecast: -123900000,
    priorPeriod: -121800000,
    credit: 126000000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Cumulative straight-line building depreciation',
  },
  {
    code: '1530',
    name: 'IFRS 16 Right-of-Use Lease Assets',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Non-Current Assets',
    actual: 85000000,
    budget: 86800000,
    forecast: 85900000,
    priorPeriod: 86800000,
    debit: 85000000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Capitalized municipal land leasehold right-of-use asset',
  },
  {
    code: '2110',
    name: 'Trade Payables & Accrued Contractor Costs',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Current Liabilities',
    actual: 18450000,
    budget: 16500000,
    forecast: 17200000,
    priorPeriod: 15900000,
    credit: 18450000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Approved utility, maintenance and facility contractor invoices',
  },
  {
    code: '2120',
    name: 'Tenant Security Deposits Held',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Current Liabilities',
    actual: 28600000,
    budget: 28000000,
    forecast: 28400000,
    priorPeriod: 27800000,
    credit: 28600000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Cash deposits held against lease performance obligations',
  },
  {
    code: '2210',
    name: 'Syndicated Senior Bank Facility',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Non-Current Liabilities',
    actual: 420000000,
    budget: 430000000,
    forecast: 425000000,
    priorPeriod: 435000000,
    credit: 420000000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Long-term syndicated financing with local banking consortium',
  },
  {
    code: '2220',
    name: 'IFRS 16 Lease Liabilities',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Non-Current Liabilities',
    actual: 82500000,
    budget: 83450000,
    forecast: 82975000,
    priorPeriod: 83450000,
    credit: 82500000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Present value of future land lease payment obligations',
  },
  {
    code: '3110',
    name: 'Paid-Up Share Capital',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Equity',
    actual: 500000000,
    budget: 500000000,
    forecast: 500000000,
    priorPeriod: 500000000,
    credit: 500000000,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Institutional developer common equity capital',
  },
  {
    code: '3210',
    name: 'Opening Retained Earnings',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Equity',
    actual: 201985100,
    budget: 201985100,
    forecast: 201985100,
    priorPeriod: 201985100,
    credit: 201985100,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Cumulative unappropriated profits brought forward',
  },
  {
    code: '3220',
    name: 'Current Period Retained Profit Movement',
    category: 'BALANCE_SHEET',
    pnlLine: 'Balance Sheet',
    subCategory: 'Equity',
    actual: 14914900,
    budget: 15723000,
    forecast: 15200000,
    priorPeriod: 14200000,
    credit: 14914900,
    isBalanceSheet: true,
    controllable: false,
    notes: 'Current period net profit tie-out to P&L (AED 14,914,900)',
  },
];

/**
 * Period Dataset Generator:
 * Generates verified, mathematically reconciled datasets for MTD (1 month), YTD (9 months), and FY (12 months).
 * Calibrated so:
 * 1. Debits − Credits = 0.00 AED
 * 2. Net Profit = Current Period Retained Earnings movement (Account 3220) = 0.00 AED diff
 * 3. Actual EBITDA = Benchmark EBITDA + Rev Var − Direct Cost Var − OPEX Var
 */
function createPeriodDataset(base: FinancialAccount[], multiplier: number): FinancialAccount[] {
  const mtdNetProfit = 14914900;
  const targetNetProfit = mtdNetProfit * multiplier;
  const targetNetProfitBudget = 15723000 * multiplier;
  const targetNetProfitForecast = 15200000 * multiplier;
  const targetNetProfitPrior = 14200000 * multiplier;
  const deltaCash = targetNetProfit - mtdNetProfit;

  return base.map((acc) => {
    if (!acc.isBalanceSheet) {
      return {
        ...acc,
        actual: acc.actual * multiplier,
        budget: acc.budget * multiplier,
        forecast: acc.forecast * multiplier,
        priorPeriod: acc.priorPeriod * multiplier,
        debit: typeof acc.debit === 'number' ? acc.debit * multiplier : undefined,
        credit: typeof acc.credit === 'number' ? acc.credit * multiplier : undefined,
      };
    }
    // Balance Sheet accounts:
    if (acc.code === '3220') {
      return {
        ...acc,
        actual: targetNetProfit,
        budget: targetNetProfitBudget,
        forecast: targetNetProfitForecast,
        priorPeriod: targetNetProfitPrior,
        credit: targetNetProfit,
        notes: `Reconciled net profit tie-out to P&L (AED ${new Intl.NumberFormat('en-US').format(targetNetProfit)})`,
      };
    }
    if (acc.code === '1110') {
      const newCash = acc.actual + deltaCash;
      return {
        ...acc,
        actual: newCash,
        budget: acc.budget + (targetNetProfitBudget - 15723000),
        forecast: acc.forecast + (targetNetProfitForecast - 15200000),
        priorPeriod: acc.priorPeriod + (targetNetProfitPrior - 14200000),
        debit: newCash,
      };
    }
    return { ...acc };
  });
}

export const METROPOLITAN_MALL_DATASET_MTD: FinancialAccount[] = METROPOLITAN_MALL_DATASET;
export const METROPOLITAN_MALL_DATASET_YTD: FinancialAccount[] = createPeriodDataset(METROPOLITAN_MALL_DATASET, 9);
export const METROPOLITAN_MALL_DATASET_FY: FinancialAccount[] = createPeriodDataset(METROPOLITAN_MALL_DATASET, 12);

/**
 * Retrieve verified Trial Balance dataset for the selected period
 */
export function getDatasetForPeriod(period: PeriodType): FinancialAccount[] {
  if (period === 'YTD') return METROPOLITAN_MALL_DATASET_YTD;
  if (period === 'FY') return METROPOLITAN_MALL_DATASET_FY;
  return METROPOLITAN_MALL_DATASET_MTD;
}

/**
 * Sample UAE Retail Mall Leasing Drivers (MTD)
 */
export const SAMPLE_LEASING_DRIVERS: LeasingDriverData = {
  occupancyPctActual: 94.2,
  occupancyPctBenchmark: 96.0,
  glaSqmActual: 125000,
  glaSqmBenchmark: 125000,
  tenantSalesActual: 310500000,
  tenantSalesBenchmark: 335000000,
  salesPerSqmActual: 2636,
  salesPerSqmBenchmark: 2792,
  baseRentActual: 38600000,
  baseRentBenchmark: 39600000,
  torActual: 3200000,
  torBenchmark: 4100000,
};

/**
 * Retrieve verified leasing driver data for the selected period
 */
export function getLeasingDriversForPeriod(period: PeriodType): LeasingDriverData {
  if (period === 'YTD') {
    return {
      occupancyPctActual: 94.2,
      occupancyPctBenchmark: 96.0,
      glaSqmActual: 125000,
      glaSqmBenchmark: 125000,
      tenantSalesActual: 2794500000,
      tenantSalesBenchmark: 3015000000,
      salesPerSqmActual: 23724,
      salesPerSqmBenchmark: 25128,
      baseRentActual: 347400000,
      baseRentBenchmark: 356400000,
      torActual: 28800000,
      torBenchmark: 36900000,
    };
  }
  if (period === 'FY') {
    return {
      occupancyPctActual: 94.5,
      occupancyPctBenchmark: 96.0,
      glaSqmActual: 125000,
      glaSqmBenchmark: 125000,
      tenantSalesActual: 3726000000,
      tenantSalesBenchmark: 4020000000,
      salesPerSqmActual: 31632,
      salesPerSqmBenchmark: 33500,
      baseRentActual: 463200000,
      baseRentBenchmark: 475200000,
      torActual: 38400000,
      torBenchmark: 49200000,
    };
  }
  return SAMPLE_LEASING_DRIVERS;
}

/**
 * Closed-Loop Governance: Open Questions & Actions Tracker
 * Unexplained variance -> question -> owner -> due date -> answer -> reused as "Management explanation"
 */
export const SAMPLE_OPEN_QUESTIONS: OpenQuestionAction[] = [
  {
    id: 'Q-01',
    item: 'Direct Mall Electricity & Chilled Water (5110)',
    question: 'Determine proportion of AED 620k utility cost overrun attributable to summer chilled water tariff rate adjustments versus unbilled tenant sub-metered cooling loads.',
    owner: 'VP Operations & Facilities',
    dueDate: '2026-11-15',
    status: 'Answered',
    answerText: 'Tariff rate escalation accounted for AED 380k (non-controllable district cooling rate hike); remaining AED 240k is due to unbilled tenant sub-metering being recovered in next billing run.',
    isManagementExplanation: true,
  },
  {
    id: 'Q-02',
    item: 'Retail Tenant Turnover Rent - TOR (4210)',
    question: 'Investigate whether AED 900k turnover rent shortfall is concentrated in luxury jewellery or reflects broader fashion tenant retail sales softness.',
    owner: 'Head of Retail Leasing',
    dueDate: '2026-11-20',
    status: 'Open',
    answerText: '',
    isManagementExplanation: false,
  },
  {
    id: 'Q-03',
    item: 'In-Line Store Base Rent (4120)',
    question: 'Confirm status of tenant fit-out approvals for 2 vacant units in East Atrium and expected lease commencement dates.',
    owner: 'Director of Asset Management',
    dueDate: '2026-11-10',
    status: 'Answered',
    answerText: 'Lease signed with tier-1 apparel retailer; fit-out underway with rent commencement scheduled for Q4 week 2.',
    isManagementExplanation: true,
  },
  {
    id: 'Q-04',
    item: 'Legal Tenancy Arbitration & Advisory (6340)',
    question: 'Confirm if AED 230k legal expense savings represent permanent fee reduction or deferred dispute filings.',
    owner: 'General Counsel',
    dueDate: '2026-11-25',
    status: 'Closed',
    answerText: 'Permanent savings: 3 legacy tenancy disputes successfully resolved via out-of-court mediation.',
    isManagementExplanation: true,
  },
];

/**
 * Prior Saved Run Snapshot (for "What changed since last month" panel)
 */
export const SAMPLE_PRIOR_RUN_COMPARISON: PriorRunComparison = {
  hasPriorRun: true,
  priorPeriodLabel: 'Prior Month (Month 2)',
  newItems: [
    {
      name: 'Tenant Leasehold Impairment (8210)',
      code: '8210',
      dollarVariance: -250000,
      polarity: 'ADVERSE',
    },
    {
      name: 'Pop-up & Kiosk Specialty Leasing (4220)',
      code: '4220',
      dollarVariance: 150000,
      polarity: 'FAVOURABLE',
    },
  ],
  resolvedItems: [
    {
      name: 'Legal Tenancy Arbitration (6340)',
      code: '6340',
      priorVariance: -180000,
    },
  ],
  worseningItems: [
    {
      name: 'Direct Mall Electricity & Chilled Water (5110)',
      code: '5110',
      priorVariance: -410000,
      currentVariance: -620000,
      changeDelta: -210000,
    },
    {
      name: 'Retail Tenant Turnover Rent (4210)',
      code: '4210',
      priorVariance: -550000,
      currentVariance: -900000,
      changeDelta: -350000,
    },
  ],
};
