import * as XLSX from 'xlsx';
import {
  AccountMapping,
  AccountTier,
  FinancialAccount,
  LeasingDriverData,
  PnlLineType,
} from '../types/financial';

export interface ColumnMapping {
  codeCol: number;
  nameCol: number;
  actualCol: number;
  debitCol?: number;
  creditCol?: number;
  budgetCol?: number;
  forecastCol?: number;
  priorCol?: number;
  categoryCol?: number;
  subCategoryCol?: number;
}

export interface SheetOption {
  sheetName: string;
  rowCount: number;
  score: number;
}

export interface LivePnlPreview {
  revenue: number;
  cogs: number;
  grossProfit: number;
  opex: number;
  ebitda: number;
  netProfit: number;
  pnlCount: number;
  bsCount: number;
  summaryRowsSkipped: number;
}

export interface ParseResult {
  workbook: XLSX.WorkBook;
  sheetNames: string[];
  activeSheet: string;
  headerRowIndex: number;
  headers: string[];
  mapping: ColumnMapping;
  accounts: FinancialAccount[];
  preview: LivePnlPreview;
}

/**
 * Universal Accounting Number Parser
 * Handles:
 * - Parenthesized negatives: "(12,500.50)" -> -12500.5
 * - Trailing minus: "12500.50-" -> -12500.5
 * - Currency symbols: "AED 1,234.56", "$1,234.56"
 * - Accounting dashes / blanks: "-", "—", "N/A", "" -> 0
 * - CR / DR suffixes: "1000 CR" -> -1000, "1000 DR" -> 1000
 */
export function parseAccountingNumber(val: unknown): number {
  if (val === null || val === undefined) return 0;
  if (typeof val === 'number') {
    return isNaN(val) ? 0 : val;
  }

  let str = String(val).trim().replace(/\u00A0/g, ' ');
  if (
    !str ||
    str === '-' ||
    str === '—' ||
    str.toLowerCase() === 'n/a' ||
    str.toLowerCase() === 'null'
  ) {
    return 0;
  }

  let isNegative = false;

  // Accounting parentheses: (123.45)
  if (/^\(.*\)$/.test(str)) {
    isNegative = true;
    str = str.replace(/^\(|\)$/g, '').trim();
  } else if (str.endsWith('-')) {
    isNegative = true;
    str = str.slice(0, -1).trim();
  } else if (str.startsWith('-')) {
    isNegative = true;
    str = str.slice(1).trim();
  }

  // CR / DR notation
  const upper = str.toUpperCase();
  if (upper.endsWith('CR')) {
    isNegative = true;
    str = str.replace(/CR/i, '').trim();
  } else if (upper.endsWith('DR')) {
    str = str.replace(/DR/i, '').trim();
  }

  // European format check: e.g. 1.234,56
  if (/^\d{1,3}(\.\d{3})*,\d+$/.test(str.replace(/[^0-9.,]/g, ''))) {
    str = str.replace(/\./g, '').replace(',', '.');
  }

  // Remove currency symbols, letters, spaces, commas
  const cleaned = str.replace(/[^0-9.]/g, '');
  const parsed = parseFloat(cleaned);
  if (isNaN(parsed)) return 0;

  return isNegative ? -parsed : parsed;
}

/**
 * Disentangles combined code and description strings
 */
export function extractCodeAndName(rawCode: string, rawName: string): { code: string; name: string } {
  let code = (rawCode || '').trim();
  let name = (rawName || '').trim();

  // If code is empty but name has leading numbers
  if (!code && name) {
    const match = name.match(/^([A-Za-z0-9\-_.]+?)[\s\-:_.]+(.+)$/);
    if (match && /\d/.test(match[1])) {
      code = match[1];
      name = match[2].trim();
    }
  }

  // If name is empty but code has text
  if (!name && code) {
    const match = code.match(/^([A-Za-z0-9\-_.]+?)[\s\-:_.]+(.+)$/);
    if (match && /\d/.test(match[1])) {
      code = match[1];
      name = match[2].trim();
    } else {
      name = `Account ${code}`;
    }
  }

  return { code, name };
}

/**
 * Default Category and P&L Line inference
 */
export function inferCategoryAndType(
  code: string,
  name: string,
  explicitCategory?: string
): { category: AccountTier; pnlLine: PnlLineType; isBalanceSheet: boolean; subCategory: string } {
  const normCategory = (explicitCategory || '').toLowerCase();
  const normName = name.toLowerCase();

  // 1. Check explicit Category column
  if (normCategory) {
    if (
      normCategory.includes('asset') ||
      normCategory.includes('liabilit') ||
      normCategory.includes('equity') ||
      normCategory.includes('balance sheet') ||
      normCategory === 'bs'
    ) {
      return { category: 'BALANCE_SHEET', pnlLine: 'Balance Sheet', isBalanceSheet: true, subCategory: 'Balance Sheet' };
    }
    if (normCategory.includes('contra')) {
      return { category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', isBalanceSheet: false, subCategory: 'Lease Concessions' };
    }
    if (normCategory.includes('rev') || normCategory.includes('income') || normCategory.includes('turnover') || normCategory.includes('rent')) {
      return { category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', isBalanceSheet: false, subCategory: 'Commercial Revenue' };
    }
    if (normCategory.includes('cogs') || normCategory.includes('cost of sales') || normCategory.includes('direct cost')) {
      return { category: 'COGS', pnlLine: 'Cost of Sales (COGS)', isBalanceSheet: false, subCategory: 'Mall Utilities & Maintenance' };
    }
    if (normCategory.includes('deprec') || normCategory.includes('amort')) {
      return { category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', isBalanceSheet: false, subCategory: 'Depreciation' };
    }
    if (normCategory.includes('finance') || normCategory.includes('interest')) {
      return { category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', isBalanceSheet: false, subCategory: 'Finance Costs' };
    }
    if (normCategory.includes('tax')) {
      return { category: 'BELOW_EBITDA', pnlLine: 'Tax', isBalanceSheet: false, subCategory: 'Tax' };
    }
    if (normCategory.includes('opex') || normCategory.includes('expense')) {
      return { category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', isBalanceSheet: false, subCategory: 'General Operating' };
    }
  }

  // 2. Numeric GL code classification (1xxx-9xxx)
  const baseCodePart = code.split(/[.\-_/]/)[0] || code;
  const digitsOnly = baseCodePart.replace(/\D/g, '');

  if (digitsOnly.length >= 3) {
    const num = parseInt(digitsOnly.slice(0, 4), 10);
    const firstDigit = digitsOnly[0];

    if (firstDigit === '1' || firstDigit === '2' || firstDigit === '3') {
      return { category: 'BALANCE_SHEET', pnlLine: 'Balance Sheet', isBalanceSheet: true, subCategory: 'Balance Sheet' };
    }
    if (num >= 4900 && num < 5000) {
      return { category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', isBalanceSheet: false, subCategory: 'Lease Concessions' };
    }
    if (firstDigit === '4') {
      return { category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', isBalanceSheet: false, subCategory: 'Base Lease Revenue' };
    }
    if (firstDigit === '5') {
      return { category: 'COGS', pnlLine: 'Cost of Sales (COGS)', isBalanceSheet: false, subCategory: 'Mall Operations COGS' };
    }
    if (firstDigit === '6' || firstDigit === '7') {
      if (num >= 7000 && num < 8000) {
        return { category: 'OTHER_INCOME', pnlLine: 'Other Income', isBalanceSheet: false, subCategory: 'Other Income' };
      }
      return { category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', isBalanceSheet: false, subCategory: 'Operating Expenses' };
    }
    if (firstDigit === '8') {
      if (num >= 8200 && num < 8300) {
        return { category: 'BELOW_EBITDA', pnlLine: 'Impairment', isBalanceSheet: false, subCategory: 'Impairment' };
      }
      if (num >= 8300) {
        return { category: 'BELOW_EBITDA', pnlLine: 'FX Gains/Losses', isBalanceSheet: false, subCategory: 'FX' };
      }
      return { category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', isBalanceSheet: false, subCategory: 'Depreciation' };
    }
    if (firstDigit === '9') {
      if (num >= 9200) {
        return { category: 'BELOW_EBITDA', pnlLine: 'Tax', isBalanceSheet: false, subCategory: 'Tax' };
      }
      return { category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', isBalanceSheet: false, subCategory: 'Finance Costs' };
    }
  }

  // 3. Semantic keywords fallback
  const bsKeywords = [
    'cash', 'bank', 'receivable', 'payable', 'deposit', 'loan', 'facility', 'capital',
    'equity', 'retained', 'asset', 'liability', 'prepaid', 'accumulated'
  ];
  if (bsKeywords.some((k) => normName.includes(k))) {
    return { category: 'BALANCE_SHEET', pnlLine: 'Balance Sheet', isBalanceSheet: true, subCategory: 'Balance Sheet' };
  }

  if (normName.includes('rent-free') || normName.includes('discount') || normName.includes('doubtful debt') || normName.includes('concession')) {
    return { category: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', isBalanceSheet: false, subCategory: 'Lease Concessions' };
  }

  if (normName.includes('revenue') || normName.includes('rent') || normName.includes('turnover') || normName.includes('service charge')) {
    return { category: 'REVENUE', pnlLine: 'Gross Commercial Revenue', isBalanceSheet: false, subCategory: 'Base Lease Revenue' };
  }

  if (normName.includes('electricity') || normName.includes('chilled water') || normName.includes('cooling') || normName.includes('utility') || normName.includes('cogs')) {
    return { category: 'COGS', pnlLine: 'Cost of Sales (COGS)', isBalanceSheet: false, subCategory: 'Mall Operations COGS' };
  }

  if (normName.includes('tax')) {
    return { category: 'BELOW_EBITDA', pnlLine: 'Tax', isBalanceSheet: false, subCategory: 'Tax' };
  }
  if (normName.includes('interest') || normName.includes('finance cost')) {
    return { category: 'BELOW_EBITDA', pnlLine: 'Finance Costs', isBalanceSheet: false, subCategory: 'Finance Costs' };
  }
  if (normName.includes('deprec') || normName.includes('amort')) {
    return { category: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', isBalanceSheet: false, subCategory: 'Depreciation' };
  }

  return { category: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', isBalanceSheet: false, subCategory: 'Operating Expenses' };
}

export function isSummaryRow(text: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase();
  return (
    lower.includes('total') ||
    lower.includes('subtotal') ||
    lower.includes('grand total') ||
    lower.includes('net income') ||
    lower.includes('gross profit') ||
    lower.includes('operating profit') ||
    lower.includes('ebitda')
  );
}

/**
 * Parse Account Mapping Table CSV:
 * Account code -> P&L line -> Tier -> Controllable Y/N -> Sign
 */
export function parseAccountMappingCsv(csvText: string): AccountMapping[] {
  const lines = csvText.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
  if (lines.length <= 1) return [];

  const mappings: AccountMapping[] = [];

  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(',').map((p) => p.trim().replace(/^["']|["']$/g, ''));
    if (parts.length < 3) continue;

    const code = parts[0];
    const pnlLineRaw = parts[1] || 'Operating Expenses (OPEX)';
    const tierRaw = parts[2]?.toUpperCase() || 'OPEX';
    const controllableRaw = parts[3]?.toLowerCase();
    const signRaw = parseInt(parts[4] || '1', 10);
    const subCategory = parts[5] || undefined;
    const name = parts[6] || undefined;

    let tier: AccountTier = 'OPEX';
    if (tierRaw.includes('CONTRA')) tier = 'CONTRA_REVENUE';
    else if (tierRaw.includes('REV')) tier = 'REVENUE';
    else if (tierRaw.includes('COGS')) tier = 'COGS';
    else if (tierRaw.includes('OTHER')) tier = 'OTHER_INCOME';
    else if (tierRaw.includes('BELOW') || tierRaw.includes('EBITDA')) tier = 'BELOW_EBITDA';
    else if (tierRaw.includes('BS') || tierRaw.includes('BALANCE')) tier = 'BALANCE_SHEET';

    mappings.push({
      code,
      pnlLine: pnlLineRaw as PnlLineType,
      tier,
      controllable: controllableRaw === 'yes' || controllableRaw === 'true' || controllableRaw === 'y' || controllableRaw === '1',
      sign: signRaw === -1 ? -1 : 1,
      subCategory,
      name,
    });
  }

  return mappings;
}

/**
 * Parse Leasing Drivers CSV:
 * occupancy %, GLA sqm, tenant sales, sales per sqm, turnover rent (TOR), base rent
 */
export function parseLeasingDriversCsv(csvText: string): LeasingDriverData {
  const lines = csvText.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
  const data: LeasingDriverData = {
    occupancyPctActual: 94.2,
    occupancyPctBenchmark: 96.0,
    glaSqmActual: 125000,
    glaSqmBenchmark: 125000,
    tenantSalesActual: 310500000,
    tenantSalesBenchmark: 335000000,
    salesPerSqmActual: 2636,
    salesPerSqmBenchmark: 2792,
    baseRentActual: 38600000,
    baseRentBenchmark: 39600000,
    torActual: 3200000,
    torBenchmark: 4100000,
  };

  for (const line of lines) {
    const parts = line.split(',').map((p) => p.trim().replace(/^["']|["']$/g, ''));
    if (parts.length < 3) continue;
    const metric = parts[0].toLowerCase();
    const actual = parseAccountingNumber(parts[1]);
    const benchmark = parseAccountingNumber(parts[2]);

    if (metric.includes('occupan')) {
      data.occupancyPctActual = actual;
      data.occupancyPctBenchmark = benchmark;
    } else if (metric.includes('gla') || metric.includes('area')) {
      data.glaSqmActual = actual;
      data.glaSqmBenchmark = benchmark;
    } else if (metric.includes('sales per sqm') || metric.includes('productivity')) {
      data.salesPerSqmActual = actual;
      data.salesPerSqmBenchmark = benchmark;
    } else if (metric.includes('tenant sales') || metric.includes('retail sales')) {
      data.tenantSalesActual = actual;
      data.tenantSalesBenchmark = benchmark;
    } else if (metric.includes('base rent') || metric.includes('minimum rent')) {
      data.baseRentActual = actual;
      data.baseRentBenchmark = benchmark;
    } else if (metric.includes('turnover rent') || metric.includes('tor') || metric.includes('percentage rent')) {
      data.torActual = actual;
      data.torBenchmark = benchmark;
    }
  }

  return data;
}

/**
 * Universal Trial Balance File Parser (SheetJS)
 */
export function parseTrialBalanceWorkbook(
  workbook: XLSX.WorkBook,
  sheetName?: string
): ParseResult {
  const sheetNames = workbook.SheetNames;
  const activeSheet = sheetName || sheetNames[0];
  const worksheet = workbook.Sheets[activeSheet];

  const rawRows: unknown[][] = XLSX.utils.sheet_to_json(worksheet, {
    header: 1,
    defval: '',
    blankrows: false,
  });

  // Find header row (search first 15 rows)
  let headerRowIndex = 0;
  let headers: string[] = [];
  let mapping: ColumnMapping = {
    codeCol: 0,
    nameCol: 1,
    actualCol: 2,
  };

  for (let r = 0; r < Math.min(15, rawRows.length); r++) {
    const row = rawRows[r];
    if (!Array.isArray(row)) continue;

    const strRow = row.map((cell) => String(cell || '').trim());
    let foundCode = -1;
    let foundName = -1;
    let foundActual = -1;
    let foundDebit = -1;
    let foundCredit = -1;
    let foundBudget = -1;

    strRow.forEach((colName, cIdx) => {
      const lower = colName.toLowerCase();
      if (lower.includes('account') || lower.includes('code') || lower.includes('gl')) {
        if (foundCode === -1) foundCode = cIdx;
      }
      if (lower.includes('description') || lower.includes('name') || lower.includes('title')) {
        if (foundName === -1) foundName = cIdx;
      }
      if (lower.includes('actual') || lower.includes('balance') || lower.includes('amount')) {
        if (foundActual === -1) foundActual = cIdx;
      }
      if (lower.includes('debit') || lower === 'dr') {
        foundDebit = cIdx;
      }
      if (lower.includes('credit') || lower === 'cr') {
        foundCredit = cIdx;
      }
      if (lower.includes('budget') || lower.includes('target') || lower.includes('plan')) {
        foundBudget = cIdx;
      }
    });

    if (foundCode !== -1 || foundName !== -1 || (foundDebit !== -1 && foundCredit !== -1)) {
      headerRowIndex = r;
      headers = strRow;
      mapping = {
        codeCol: foundCode !== -1 ? foundCode : 0,
        nameCol: foundName !== -1 ? foundName : 1,
        actualCol: foundActual !== -1 ? foundActual : foundDebit !== -1 ? foundDebit : 2,
        debitCol: foundDebit !== -1 ? foundDebit : undefined,
        creditCol: foundCredit !== -1 ? foundCredit : undefined,
        budgetCol: foundBudget !== -1 ? foundBudget : undefined,
      };
      break;
    }
  }

  // Parse accounts
  const accounts: FinancialAccount[] = [];
  let summaryRowsSkipped = 0;
  let pnlCount = 0;
  let bsCount = 0;
  let revSum = 0;
  let cogsSum = 0;
  let opexSum = 0;

  for (let r = headerRowIndex + 1; r < rawRows.length; r++) {
    const row = rawRows[r];
    if (!Array.isArray(row)) continue;

    const rawCode = String(row[mapping.codeCol] || '').trim();
    const rawName = String(row[mapping.nameCol] || '').trim();
    if (!rawCode && !rawName) continue;
    if (isSummaryRow(rawCode) || isSummaryRow(rawName)) {
      summaryRowsSkipped++;
      continue;
    }

    const { code, name } = extractCodeAndName(rawCode, rawName);
    const { category, pnlLine, isBalanceSheet, subCategory } = inferCategoryAndType(code, name);

    let actual = 0;
    let debit: number | undefined;
    let credit: number | undefined;

    if (mapping.debitCol !== undefined && mapping.creditCol !== undefined) {
      debit = parseAccountingNumber(row[mapping.debitCol]);
      credit = parseAccountingNumber(row[mapping.creditCol]);

      if (category === 'REVENUE' || category === 'OTHER_INCOME') {
        actual = credit - debit;
      } else if (category === 'COGS' || category === 'OPEX' || category === 'CONTRA_REVENUE' || category === 'BELOW_EBITDA') {
        actual = debit - credit;
      } else {
        const firstDigit = code.replace(/\D/g, '')[0];
        actual = firstDigit === '1' ? debit - credit : credit - debit;
      }
    } else {
      actual = parseAccountingNumber(row[mapping.actualCol]);
    }

    const budget = mapping.budgetCol !== undefined ? parseAccountingNumber(row[mapping.budgetCol]) : actual;

    if (isBalanceSheet) {
      bsCount++;
    } else {
      pnlCount++;
      if (category === 'REVENUE') revSum += actual;
      if (category === 'CONTRA_REVENUE') revSum -= actual;
      if (category === 'COGS') cogsSum += actual;
      if (category === 'OPEX') opexSum += actual;
    }

    accounts.push({
      code: code || `GL-${accounts.length + 1}`,
      name: name || `Account ${code}`,
      category,
      pnlLine,
      subCategory,
      actual,
      budget,
      forecast: budget,
      priorPeriod: budget,
      debit,
      credit,
      isBalanceSheet,
    });
  }

  const grossProfit = revSum - cogsSum;
  const ebitda = grossProfit - opexSum;

  return {
    workbook,
    sheetNames,
    activeSheet,
    headerRowIndex,
    headers,
    mapping,
    accounts,
    preview: {
      revenue: revSum,
      cogs: cogsSum,
      grossProfit,
      opex: opexSum,
      ebitda,
      netProfit: ebitda,
      pnlCount,
      bsCount,
      summaryRowsSkipped,
    },
  };
}
