import {
  AccountCategory,
  AccountMapping,
  AccountTier,
  BalanceSheetValidationCheck,
  BenchmarkType,
  CurrencyCode,
  FinancialAccount,
  FinancialPolarity,
  LeasingDriverData,
  LeasingRevenueDecomposition,
  MacroPnlMetrics,
  MaterialityFilter,
  PeriodType,
  PnlLineType,
  SubCategoryRollup,
  UnmappedAccountAlert,
  VarianceRollup,
} from '../types/financial';
import { DEFAULT_UAE_ACCOUNT_MAPPINGS } from '../data/shoppingMallDataset';

/**
 * Format currency with configurable currency code (default AED)
 * Display rule:
 * - Board views show AED M with 1 decimal place (or compact k)
 * - Excel details show AED thousands
 */
export function formatCurrency(
  amount: number,
  currency: CurrencyCode = 'AED',
  compact: boolean = false
): string {
  const isNeg = amount < 0;
  const abs = Math.abs(amount);

  if (compact) {
    const sign = isNeg ? '-' : '';
    if (abs >= 1_000_000) {
      return `${sign}${currency} ${(abs / 1_000_000).toFixed(1)}M`;
    }
    if (abs >= 1_000) {
      return `${sign}${currency} ${(abs / 1_000).toFixed(1)}k`;
    }
    return `${sign}${currency} ${abs.toFixed(0)}`;
  }

  // Full currency display
  const formatted = new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 0,
  }).format(abs);

  return isNeg ? `(${currency} ${formatted})` : `${currency} ${formatted}`;
}

/**
 * Format Board View number in Millions with 1 decimal place
 */
export function formatCurrencyM(amount: number, currency: CurrencyCode = 'AED'): string {
  const isNeg = amount < 0;
  const abs = Math.abs(amount);
  const mVal = (abs / 1_000_000).toFixed(1);
  return isNeg ? `(${currency} ${mVal}M)` : `${currency} ${mVal}M`;
}

/**
 * Express margin shifts in percentage points ('pp'), NEVER in percent ('%')
 * Example: Gross margin 42.6% -> 41.3% = -1.3 pp
 */
export const PREPARED_BY_FOOTNOTE =
  'Prepared by CA Parth Indrajit. Khona (Membership Number - 602526)';

/**
 * Express margin shifts in percentage points ('pp'), NEVER in percent ('%')
 * Example: Gross margin 42.6% -> 41.3% = -1.3 pp
 */
export function formatPpDelta(deltaPp: number): string {
  const sign = deltaPp > 0 ? '+' : deltaPp < 0 ? '-' : '';
  return `${sign}${Math.abs(deltaPp).toFixed(1)} pp`;
}

/**
 * Calculate safe variance %:
 * If benchmark is 0 or sign flips between benchmark and actual -> return 'n.m.' (not meaningful)
 * Displays absolute magnitude so pairing with directional indicators (▲ + / ▼ -) NEVER duplicates signs (++ or --).
 */
export function computeSafeVariancePct(
  actual: number,
  benchmark: number
): { val: number | 'n.m.'; display: string } {
  if (benchmark === 0) {
    return { val: 'n.m.', display: 'n.m.' };
  }
  // Sign flip check: e.g. actual positive, benchmark negative or vice versa
  if ((actual > 0 && benchmark < 0) || (actual < 0 && benchmark > 0)) {
    return { val: 'n.m.', display: 'n.m.' };
  }

  const dollarVar = actual - benchmark;
  const pct = (dollarVar / Math.abs(benchmark)) * 100;
  return { val: pct, display: `${Math.abs(pct).toFixed(1)}%` };
}

/**
 * Format variance with clean directional symbol and single sign (▲ + / ▼ - / —)
 * Prevents double signs (++ or --) across all board components and exports.
 */
export function formatVariancePair(
  val: number | 'n.m.',
  polarity: FinancialPolarity,
  unit: '%' | 'pp' = '%'
): { symbol: string; text: string; full: string } {
  if (val === 'n.m.') {
    return { symbol: '—', text: 'n.m.', full: '— n.m.' };
  }
  const symbol = polarity === 'FAVOURABLE' ? '▲ +' : polarity === 'ADVERSE' ? '▼ -' : '— ';
  const text = `${Math.abs(val).toFixed(1)}${unit}`;
  return { symbol, text, full: `${symbol}${text}` };
}

/**
 * Directional Polarity Evaluation:
 * - Revenue, Other Income, Margins, Profits: Actual > Benchmark = FAVOURABLE, Actual < Benchmark = ADVERSE
 * - Cost of Sales (COGS), OPEX: Actual > Benchmark = ADVERSE (Cost Overrun), Actual < Benchmark = FAVOURABLE (Savings)
 * - Depreciation, Finance Costs, Tax: Evaluated as costs (higher = ADVERSE, lower = FAVOURABLE)
 */
export function evaluatePolarity(
  tierOrType: AccountTier | 'PROFIT' | 'MARGIN' | 'COST',
  actual: number,
  benchmark: number
): FinancialPolarity {
  const delta = actual - benchmark;
  if (Math.abs(delta) < 0.001) return 'NEUTRAL';

  if (
    tierOrType === 'REVENUE' ||
    tierOrType === 'OTHER_INCOME' ||
    tierOrType === 'PROFIT' ||
    tierOrType === 'MARGIN'
  ) {
    return delta > 0 ? 'FAVOURABLE' : 'ADVERSE';
  }

  // Cost lines: COGS, OPEX, CONTRA_REVENUE, BELOW_EBITDA costs (DA, Finance, Tax)
  return delta > 0 ? 'ADVERSE' : 'FAVOURABLE';
}

/**
 * Default fallback classifier based on 1000-9999 ranges (only if no mapping provided)
 */
export function fallbackClassify(code: string): { tier: AccountTier; pnlLine: PnlLineType; isBs: boolean; controllable: boolean } {
  const numeric = parseInt(code.replace(/\D/g, ''), 10);
  if (isNaN(numeric) || (numeric >= 1000 && numeric < 4000)) {
    return { tier: 'BALANCE_SHEET', pnlLine: 'Balance Sheet', isBs: true, controllable: false };
  }
  if (numeric >= 4900 && numeric < 5000) {
    return { tier: 'CONTRA_REVENUE', pnlLine: 'Contra-revenue', isBs: false, controllable: true };
  }
  if (numeric >= 4000 && numeric < 4900) {
    return { tier: 'REVENUE', pnlLine: 'Gross Commercial Revenue', isBs: false, controllable: true };
  }
  if (numeric >= 5000 && numeric < 6000) {
    return { tier: 'COGS', pnlLine: 'Cost of Sales (COGS)', isBs: false, controllable: true };
  }
  if (numeric >= 6000 && numeric < 7000) {
    return { tier: 'OPEX', pnlLine: 'Operating Expenses (OPEX)', isBs: false, controllable: true };
  }
  if (numeric >= 7000 && numeric < 8000) {
    return { tier: 'OTHER_INCOME', pnlLine: 'Other Income', isBs: false, controllable: false };
  }
  if (numeric >= 8000 && numeric < 8200) {
    return { tier: 'BELOW_EBITDA', pnlLine: 'Depreciation & Amortisation', isBs: false, controllable: false };
  }
  if (numeric >= 8200 && numeric < 8300) {
    return { tier: 'BELOW_EBITDA', pnlLine: 'Impairment', isBs: false, controllable: false };
  }
  if (numeric >= 8300 && numeric < 9000) {
    return { tier: 'BELOW_EBITDA', pnlLine: 'FX Gains/Losses', isBs: false, controllable: false };
  }
  if (numeric >= 9000 && numeric < 9200) {
    return { tier: 'BELOW_EBITDA', pnlLine: 'Finance Costs', isBs: false, controllable: false };
  }
  if (numeric >= 9200 && numeric < 10000) {
    return { tier: 'BELOW_EBITDA', pnlLine: 'Tax', isBs: false, controllable: false };
  }
  return { tier: 'BALANCE_SHEET', pnlLine: 'Balance Sheet', isBs: true, controllable: false };
}

/**
 * Validate Account Mappings and find any unmapped accounts
 * If any unmapped account is found, it will trigger a blocking alert
 */
export function validateAccountMappings(
  accounts: FinancialAccount[],
  mappings: AccountMapping[]
): {
  mappingMap: Map<string, AccountMapping>;
  unmappedAccounts: UnmappedAccountAlert[];
} {
  const map = new Map<string, AccountMapping>();
  for (const m of mappings) {
    map.set(m.code.trim().toUpperCase(), m);
  }

  const unmapped: UnmappedAccountAlert[] = [];
  for (const a of accounts) {
    const cleanCode = a.code.trim().toUpperCase();
    if (!map.has(cleanCode)) {
      unmapped.push({
        code: a.code,
        name: a.name,
        amount: a.actual,
      });
    }
  }

  return { mappingMap: map, unmappedAccounts: unmapped };
}

/**
 * Balance Sheet Validation Checks:
 * Test 1: Balance check: Total Debits - Total Credits = 0
 * Test 2: P&L-to-BS tie-out: Net Profit (P&L) = Current-period movement in Retained Earnings
 */
export function performBalanceSheetValidation(
  accounts: FinancialAccount[],
  netProfitPnl: number
): BalanceSheetValidationCheck {
  const bsAccounts = accounts.filter(
    (a) => a.isBalanceSheet || a.category === 'BALANCE_SHEET' || (parseInt(a.code.replace(/\D/g, ''), 10) >= 1000 && parseInt(a.code.replace(/\D/g, ''), 10) < 4000)
  );

  let totalDebits = 0;
  let totalCredits = 0;
  let assetDebitSum = 0;
  let liabilityCreditSum = 0;
  let equityCreditSum = 0;
  let openingEquitySum = 0;
  let retainedEarningsDelta = 0;

  const sample: { code: string; name: string; amount: number; classType: string }[] = [];

  for (const acc of accounts) {
    const num = parseInt(acc.code.replace(/\D/g, ''), 10);
    const isCurrentProfitAcc =
      acc.code === '3220' ||
      acc.name.toLowerCase().includes('current period') ||
      acc.name.toLowerCase().includes('profit movement');

    // Extract Debits and Credits
    let d = 0;
    let c = 0;

    if (typeof acc.debit === 'number' || typeof acc.credit === 'number') {
      d = acc.debit || 0;
      c = acc.credit || 0;
    } else {
      if ((num >= 1000 && num < 2000) || num >= 5000) {
        if (acc.actual >= 0) d = acc.actual;
        else c = Math.abs(acc.actual);
      } else {
        if (acc.actual >= 0) c = acc.actual;
        else d = Math.abs(acc.actual);
      }
    }

    // In an unclosed general ledger trial balance, temporary P&L accounts already reflect Net Profit.
    // Account 3220 represents the Retained Earnings profit tie-out line.
    if (!isCurrentProfitAcc) {
      totalDebits += d;
      totalCredits += c;
    } else {
      retainedEarningsDelta = acc.actual || c;
    }

    // Inspect Balance Sheet accounts
    if (num >= 1000 && num < 2000) {
      assetDebitSum += acc.actual;
      if (sample.length < 3) sample.push({ code: acc.code, name: acc.name, amount: acc.actual, classType: 'Asset (1000s)' });
    } else if (num >= 2000 && num < 3000) {
      liabilityCreditSum += acc.actual;
      if (sample.length < 5) sample.push({ code: acc.code, name: acc.name, amount: acc.actual, classType: 'Liability (2000s)' });
    } else if (num >= 3000 && num < 4000) {
      equityCreditSum += acc.actual;
      if (!isCurrentProfitAcc) {
        openingEquitySum += acc.actual;
      }
      if (sample.length < 7) sample.push({ code: acc.code, name: acc.name, amount: acc.actual, classType: 'Equity (3000s)' });
    }
  }

  // If no explicit Account 3220 was provided, derive movement from Balance Sheet movement
  if (retainedEarningsDelta === 0) {
    retainedEarningsDelta = assetDebitSum - (liabilityCreditSum + openingEquitySum);
  }

  const debitCreditDiff = Math.abs(totalDebits - totalCredits);
  const tieOutDiff = Math.abs(netProfitPnl - retainedEarningsDelta);

  const debitCreditPassed = debitCreditDiff < 1.0;
  const tieOutPassed = tieOutDiff < 1.0;

  const allPassed = debitCreditPassed && tieOutPassed;

  return {
    debitCreditCheck: {
      totalDebits,
      totalCredits,
      difference: totalDebits - totalCredits,
      passed: debitCreditPassed,
    },
    pnlTieOutCheck: {
      netProfitPnl,
      retainedEarningsDelta,
      difference: netProfitPnl - retainedEarningsDelta,
      passed: tieOutPassed,
    },
    statusText: allPassed ? 'System check passed' : 'System check failed',
    assetDebitSum,
    liabilityCreditSum,
    equityCreditSum,
    totalExcludedAccounts: bsAccounts.length,
    sampleExcludedAccounts: sample,
  };
}

/**
 * Leasing Drivers Revenue Decomposition:
 * Splits revenue variance into Occupancy Effect, Rate Effect, and TOR Effect.
 * Reconciles to 0 difference against total revenue variance.
 */
export function decomposeLeasingRevenue(
  drivers: LeasingDriverData | null | undefined,
  grossRevenueActual: number,
  grossRevenueBenchmark: number
): LeasingRevenueDecomposition {
  const totalRevenueVariance = grossRevenueActual - grossRevenueBenchmark;

  if (!drivers) {
    return {
      hasDrivers: false,
      occupancyEffect: 0,
      rateEffect: 0,
      torEffect: 0,
      totalRevenueVariance,
      reconciliationDelta: 0,
    };
  }

  // Formula:
  // Occupancy Effect: (Occupancy Actual % - Occupancy Benchmark %) * Benchmark Base Rent
  const occDeltaPct = (drivers.occupancyPctActual - drivers.occupancyPctBenchmark) / 100;
  const occupancyEffect = occDeltaPct * drivers.baseRentBenchmark;

  // Rate Effect: Base Rent Actual - Base Rent Benchmark - Occupancy Effect
  const totalBaseRentVar = drivers.baseRentActual - drivers.baseRentBenchmark;
  const rateEffect = totalBaseRentVar - occupancyEffect;

  // TOR Effect: Actual TOR - Benchmark TOR
  const torEffect = drivers.torActual - drivers.torBenchmark;

  // Remaining sundry & recovery variance (e.g. CAM, parking, media)
  const sundryEffect = totalRevenueVariance - (occupancyEffect + rateEffect + torEffect);

  // Closed loop: sum of effects matches total revenue variance with delta = 0
  const reconciliationDelta = totalRevenueVariance - (occupancyEffect + rateEffect + torEffect + sundryEffect);

  return {
    hasDrivers: true,
    occupancyEffect,
    rateEffect,
    torEffect,
    totalRevenueVariance,
    reconciliationDelta: Math.abs(reconciliationDelta) < 0.01 ? 0 : reconciliationDelta,
  };
}

/**
 * Main Institutional FP&A Engine
 * Audience: UAE Retail / Mall Real Estate CFO & Board
 */
export function computeFinancialEngine(
  accounts: FinancialAccount[],
  benchmarkType: BenchmarkType = 'BUDGET',
  customMappings?: AccountMapping[],
  materiality?: MaterialityFilter,
  currency: CurrencyCode = 'AED',
  period: PeriodType = 'MTD',
  leasingDrivers?: LeasingDriverData | null
): {
  metrics: MacroPnlMetrics;
  pnlAccounts: FinancialAccount[];
  unmappedAccounts: UnmappedAccountAlert[];
  grossRevenueSubCategories: SubCategoryRollup[];
  contraRevenueSubCategories: SubCategoryRollup[];
  cogsSubCategories: SubCategoryRollup[];
  opexSubCategories: SubCategoryRollup[];
  belowEbitdaSubCategories: SubCategoryRollup[];
  topAdverseDrivers: VarianceRollup[];
  topFavourableDrivers: VarianceRollup[];
  waterfallSteps: {
    name: string;
    value: number;
    runningTotal: number;
    type: 'baseline' | 'positive' | 'negative' | 'total';
    formulaNote: string;
  }[];
  balanceSheetCheck: BalanceSheetValidationCheck;
  leasingDecomposition: LeasingRevenueDecomposition;
} {
  const activeMappings = customMappings && customMappings.length > 0 ? customMappings : DEFAULT_UAE_ACCOUNT_MAPPINGS;
  const matFilter: MaterialityFilter = materiality || { aedThreshold: 250000, pctThreshold: 5.0 };

  // 1. Account Mapping Validation & Blocking Alert
  const { mappingMap, unmappedAccounts } = validateAccountMappings(accounts, activeMappings);

  // Helper to extract benchmark
  const getBenchmark = (a: FinancialAccount): number => {
    if (benchmarkType === 'FORECAST') return a.forecast;
    if (benchmarkType === 'PRIOR_PERIOD') return a.priorPeriod;
    return a.budget;
  };

  // 2. Classify Accounts using Mappings
  const pnlAccounts: FinancialAccount[] = [];
  const bsAccounts: FinancialAccount[] = [];

  for (const a of accounts) {
    const cleanCode = a.code.trim().toUpperCase();
    const mapping = mappingMap.get(cleanCode);

    if (mapping) {
      a.category = mapping.tier;
      a.pnlLine = mapping.pnlLine;
      a.controllable = mapping.controllable;
      a.isBalanceSheet = mapping.tier === 'BALANCE_SHEET';
    } else {
      // Fallback template
      const fb = fallbackClassify(a.code);
      a.category = fb.tier;
      a.pnlLine = fb.pnlLine;
      a.isBalanceSheet = fb.isBs;
      a.controllable = fb.controllable;
    }

    if (a.isBalanceSheet || a.category === 'BALANCE_SHEET') {
      bsAccounts.push(a);
    } else {
      pnlAccounts.push(a);
    }
  }

  // 3. Rollup by Category and Subcategory
  const groupAccounts = (tier: AccountTier): SubCategoryRollup[] => {
    const list = pnlAccounts.filter((a) => a.category === tier);
    const subMap = new Map<string, FinancialAccount[]>();

    for (const acc of list) {
      const sub = acc.subCategory || 'General';
      if (!subMap.has(sub)) subMap.set(sub, []);
      subMap.get(sub)!.push(acc);
    }

    const subRollups: SubCategoryRollup[] = [];
    let catDollarVar = 0;
    for (const acc of list) {
      catDollarVar += acc.actual - getBenchmark(acc);
    }

    for (const [subName, accList] of subMap.entries()) {
      let subActual = 0;
      let subBenchmark = 0;
      const rollups: VarianceRollup[] = [];

      for (const acc of accList) {
        const b = getBenchmark(acc);
        const dollarVar = acc.actual - b;
        const safePct = computeSafeVariancePct(acc.actual, b);
        const polarity = evaluatePolarity(acc.category, acc.actual, b);

        subActual += acc.actual;
        subBenchmark += b;

        const driverContrib = catDollarVar !== 0 ? (dollarVar / catDollarVar) * 100 : 0;
        const isMaterial =
          Math.abs(dollarVar) >= matFilter.aedThreshold &&
          (safePct.val === 'n.m.' || Math.abs(safePct.val) >= matFilter.pctThreshold);

        rollups.push({
          code: acc.code,
          name: acc.name,
          category: acc.category,
          pnlLine: acc.pnlLine || 'Operating Expenses (OPEX)',
          subCategory: acc.subCategory || subName,
          actual: acc.actual,
          benchmark: b,
          dollarVariance: dollarVar,
          percentVariance: safePct.val,
          displayPct: safePct.display,
          polarity,
          driverContributionPct: driverContrib,
          controllable: acc.controllable ?? true,
          isMaterial,
        });
      }

      const subDollarVar = subActual - subBenchmark;
      const subSafePct = computeSafeVariancePct(subActual, subBenchmark);
      const subPolarity = evaluatePolarity(tier, subActual, subBenchmark);
      const subDriverContrib = catDollarVar !== 0 ? (subDollarVar / catDollarVar) * 100 : 0;

      subRollups.push({
        name: subName,
        category: tier,
        pnlLine: accList[0]?.pnlLine || 'Operating Expenses (OPEX)',
        actual: subActual,
        benchmark: subBenchmark,
        dollarVariance: subDollarVar,
        percentVariance: subSafePct.val,
        displayPct: subSafePct.display,
        polarity: subPolarity,
        accounts: rollups.sort((x, y) => Math.abs(y.dollarVariance) - Math.abs(x.dollarVariance)),
        driverContributionPct: subDriverContrib,
        controllable: accList.some((x) => x.controllable),
      });
    }

    return subRollups.sort((x, y) => Math.abs(y.dollarVariance) - Math.abs(x.dollarVariance));
  };

  const grossRevenueSubCategories = groupAccounts('REVENUE');
  const contraRevenueSubCategories = groupAccounts('CONTRA_REVENUE');
  const cogsSubCategories = groupAccounts('COGS');
  const opexSubCategories = groupAccounts('OPEX');
  const belowEbitdaSubCategories = groupAccounts('BELOW_EBITDA');

  // Sum categories
  const sumSubs = (subs: SubCategoryRollup[]) => ({
    actual: subs.reduce((acc, s) => acc + s.actual, 0),
    benchmark: subs.reduce((acc, s) => acc + s.benchmark, 0),
  });

  const grossRev = sumSubs(grossRevenueSubCategories);
  const contraRev = sumSubs(contraRevenueSubCategories);
  const cogs = sumSubs(cogsSubCategories);
  const opex = sumSubs(opexSubCategories);

  // 1. Gross Revenue
  const grossRevVariance = grossRev.actual - grossRev.benchmark;
  const grossRevSafePct = computeSafeVariancePct(grossRev.actual, grossRev.benchmark);
  const grossRevPolarity = evaluatePolarity('REVENUE', grossRev.actual, grossRev.benchmark);

  // 2. Contra Revenue
  const contraRevVariance = contraRev.actual - contraRev.benchmark;
  const contraRevSafePct = computeSafeVariancePct(contraRev.actual, contraRev.benchmark);
  const contraRevPolarity = evaluatePolarity('CONTRA_REVENUE', contraRev.actual, contraRev.benchmark);

  // 3. Net Commercial Revenue = Gross Revenue - Contra Revenue
  const netRevActual = grossRev.actual - contraRev.actual;
  const netRevBenchmark = grossRev.benchmark - contraRev.benchmark;
  const netRevVariance = netRevActual - netRevBenchmark;
  const netRevSafePct = computeSafeVariancePct(netRevActual, netRevBenchmark);
  const netRevPolarity = evaluatePolarity('REVENUE', netRevActual, netRevBenchmark);

  // 4. Cost of Sales (COGS)
  const cogsVariance = cogs.actual - cogs.benchmark;
  const cogsSafePct = computeSafeVariancePct(cogs.actual, cogs.benchmark);
  const cogsPolarity = evaluatePolarity('COGS', cogs.actual, cogs.benchmark);

  // 5. Gross Profit & Margin
  const grossProfitActual = netRevActual - cogs.actual;
  const grossProfitBenchmark = netRevBenchmark - cogs.benchmark;
  const grossProfitVariance = grossProfitActual - grossProfitBenchmark;
  const grossProfitSafePct = computeSafeVariancePct(grossProfitActual, grossProfitBenchmark);
  const grossProfitPolarity = evaluatePolarity('PROFIT', grossProfitActual, grossProfitBenchmark);

  const grossMarginActual = netRevActual > 0 ? (grossProfitActual / netRevActual) * 100 : 0;
  const grossMarginBenchmark = netRevBenchmark > 0 ? (grossProfitBenchmark / netRevBenchmark) * 100 : 0;
  const grossMarginDeltaPp = grossMarginActual - grossMarginBenchmark;

  // 6. OPEX
  const opexVariance = opex.actual - opex.benchmark;
  const opexSafePct = computeSafeVariancePct(opex.actual, opex.benchmark);
  const opexPolarity = evaluatePolarity('OPEX', opex.actual, opex.benchmark);
  const opexRatioActual = netRevActual > 0 ? (opex.actual / netRevActual) * 100 : 0;
  const opexRatioBenchmark = netRevBenchmark > 0 ? (opex.benchmark / netRevBenchmark) * 100 : 0;
  const opexRatioDeltaPp = opexRatioActual - opexRatioBenchmark;

  // 7. Operational EBITDA
  // Closed Accounting Formula: Actual EBITDA = Gross Profit - OPEX
  const ebitdaActual = grossProfitActual - opex.actual;
  const ebitdaBenchmark = grossProfitBenchmark - opex.benchmark;
  const ebitdaVariance = ebitdaActual - ebitdaBenchmark;
  const ebitdaSafePct = computeSafeVariancePct(ebitdaActual, ebitdaBenchmark);
  const ebitdaPolarity = evaluatePolarity('PROFIT', ebitdaActual, ebitdaBenchmark);
  const ebitdaMarginActual = netRevActual > 0 ? (ebitdaActual / netRevActual) * 100 : 0;
  const ebitdaMarginBenchmark = netRevBenchmark > 0 ? (ebitdaBenchmark / netRevBenchmark) * 100 : 0;
  const ebitdaMarginDeltaPp = ebitdaMarginActual - ebitdaMarginBenchmark;

  // 8. Other Income & Below EBITDA Lines
  let otherIncomeActual = 0;
  let otherIncomeBenchmark = 0;
  let daActual = 0;
  let daBenchmark = 0;
  let ifrs16Actual = 0;
  let ifrs16Benchmark = 0;
  let impairmentActual = 0;
  let impairmentBenchmark = 0;
  let fxActual = 0;
  let fxBenchmark = 0;
  let financeCostsActual = 0;
  let financeCostsBenchmark = 0;
  let taxActual = 0;
  let taxBenchmark = 0;

  for (const a of pnlAccounts) {
    const b = getBenchmark(a);
    const pnlLine = a.pnlLine || fallbackClassify(a.code).pnlLine;

    if (pnlLine === 'Other Income' || a.category === 'OTHER_INCOME') {
      otherIncomeActual += a.actual;
      otherIncomeBenchmark += b;
    } else if (pnlLine === 'Depreciation & Amortisation') {
      daActual += a.actual;
      daBenchmark += b;
    } else if (pnlLine === 'IFRS 16 Lease Effects') {
      ifrs16Actual += a.actual;
      ifrs16Benchmark += b;
    } else if (pnlLine === 'Impairment') {
      impairmentActual += a.actual;
      impairmentBenchmark += b;
    } else if (pnlLine === 'FX Gains/Losses') {
      fxActual += a.actual;
      fxBenchmark += b;
    } else if (pnlLine === 'Finance Costs') {
      financeCostsActual += a.actual;
      financeCostsBenchmark += b;
    } else if (pnlLine === 'Tax') {
      taxActual += a.actual;
      taxBenchmark += b;
    }
  }

  // 9. Operating Profit (EBIT)
  // EBIT = Operational EBITDA + Other Income - D&A - IFRS 16 - Impairment + FX
  const ebitActual = ebitdaActual + otherIncomeActual - daActual - ifrs16Actual - impairmentActual + fxActual;
  const ebitBenchmark = ebitdaBenchmark + otherIncomeBenchmark - daBenchmark - ifrs16Benchmark - impairmentBenchmark + fxBenchmark;
  const ebitVariance = ebitActual - ebitBenchmark;
  const ebitSafePct = computeSafeVariancePct(ebitActual, ebitBenchmark);
  const ebitPolarity = evaluatePolarity('PROFIT', ebitActual, ebitBenchmark);

  // 10. Net Profit After Tax
  // Net Profit = EBIT - Finance Costs - Tax
  const netProfitActual = ebitActual - financeCostsActual - taxActual;
  const netProfitBenchmark = ebitBenchmark - financeCostsBenchmark - taxBenchmark;
  const netProfitVariance = netProfitActual - netProfitBenchmark;
  const netProfitSafePct = computeSafeVariancePct(netProfitActual, netProfitBenchmark);
  const netProfitPolarity = evaluatePolarity('PROFIT', netProfitActual, netProfitBenchmark);
  const netMarginActual = netRevActual > 0 ? (netProfitActual / netRevActual) * 100 : 0;
  const netMarginBenchmark = netRevBenchmark > 0 ? (netProfitBenchmark / netRevBenchmark) * 100 : 0;
  const netMarginDeltaPp = netMarginActual - netMarginBenchmark;

  // Rounding Rule Verification:
  // Calculate at full precision. If rounded parts in millions (with 1 decimal) do not sum to rounded total,
  // compute visible Rounding row.
  const roundM = (val: number) => Math.round(val / 100_000) / 10;
  const roundedPartsSum = roundM(grossProfitActual) - roundM(opex.actual);
  const roundedTotal = roundM(ebitdaActual);
  const roundingDiff = Math.round((roundedTotal - roundedPartsSum) * 10) / 10;
  const hasRoundingDiff = Math.abs(roundingDiff) >= 0.1;

  const metrics: MacroPnlMetrics = {
    currency,
    period,
    benchmarkType,

    grossRevenueActual: grossRev.actual,
    grossRevenueBenchmark: grossRev.benchmark,
    grossRevenueVariance: grossRevVariance,
    grossRevenueVariancePct: grossRevSafePct.val,
    grossRevenuePolarity: grossRevPolarity,

    contraRevenueActual: contraRev.actual,
    contraRevenueBenchmark: contraRev.benchmark,
    contraRevenueVariance: contraRevVariance,
    contraRevenueVariancePct: contraRevSafePct.val,
    contraRevenuePolarity: contraRevPolarity,

    revenueActual: netRevActual,
    revenueBenchmark: netRevBenchmark,
    revenueVariance: netRevVariance,
    revenueVariancePct: netRevSafePct.val,
    revenuePolarity: netRevPolarity,

    cogsActual: cogs.actual,
    cogsBenchmark: cogs.benchmark,
    cogsVariance,
    cogsVariancePct: cogsSafePct.val,
    cogsPolarity,

    grossProfitActual,
    grossProfitBenchmark,
    grossProfitVariance,
    grossProfitVariancePct: grossProfitSafePct.val,
    grossProfitPolarity,
    grossMarginActual,
    grossMarginBenchmark,
    grossMarginDeltaPp,

    opexActual: opex.actual,
    opexBenchmark: opex.benchmark,
    opexVariance,
    opexVariancePct: opexSafePct.val,
    opexPolarity,
    opexRatioActual,
    opexRatioBenchmark,
    opexRatioDeltaPp,

    ebitdaActual,
    ebitdaBenchmark,
    ebitdaVariance,
    ebitdaVariancePct: ebitdaSafePct.val,
    ebitdaPolarity,
    ebitdaMarginActual,
    ebitdaMarginBenchmark,
    ebitdaMarginDeltaPp,

    otherIncomeActual,
    otherIncomeBenchmark,
    otherIncomeVariance: otherIncomeActual - otherIncomeBenchmark,

    daActual,
    daBenchmark,
    daVariance: daActual - daBenchmark,

    ebitActual,
    ebitBenchmark,
    ebitVariance,
    ebitVariancePct: ebitSafePct.val,
    ebitPolarity,

    ifrs16Actual,
    ifrs16Benchmark,
    ifrs16Variance: ifrs16Actual - ifrs16Benchmark,

    impairmentActual,
    impairmentBenchmark,
    impairmentVariance: impairmentActual - impairmentBenchmark,

    fxActual,
    fxBenchmark,
    fxVariance: fxActual - fxBenchmark,

    financeCostsActual,
    financeCostsBenchmark,
    financeCostsVariance: financeCostsActual - financeCostsBenchmark,

    taxActual,
    taxBenchmark,
    taxVariance: taxActual - taxBenchmark,

    netProfitActual,
    netProfitBenchmark,
    netProfitVariance,
    netProfitVariancePct: netProfitSafePct.val,
    netProfitPolarity,
    netMarginActual,
    netMarginBenchmark,
    netMarginDeltaPp,

    roundingAdjustmentDisplay: roundingDiff,
    hasRoundingDifference: hasRoundingDiff,
  };

  // Compile all leaf accounts for top drivers (strictly after materiality filter)
  const allLeafRollups: VarianceRollup[] = [];
  [
    ...grossRevenueSubCategories,
    ...contraRevenueSubCategories,
    ...cogsSubCategories,
    ...opexSubCategories,
    ...belowEbitdaSubCategories,
  ].forEach((s) => {
    allLeafRollups.push(...s.accounts);
  });

  // Top drivers: adverse vs favourable (top 5 each, after materiality filter)
  const topAdverseDrivers = allLeafRollups
    .filter((a) => a.polarity === 'ADVERSE' && a.isMaterial)
    .sort((a, b) => Math.abs(b.dollarVariance) - Math.abs(a.dollarVariance))
    .slice(0, 5);

  const topFavourableDrivers = allLeafRollups
    .filter((a) => a.polarity === 'FAVOURABLE' && a.isMaterial)
    .sort((a, b) => Math.abs(b.dollarVariance) - Math.abs(a.dollarVariance))
    .slice(0, 5);

  // Closed Waterfall Bridge Formula:
  // Actual EBITDA = Benchmark EBITDA + Revenue variance - Direct cost variance - Opex variance (diff = 0)
  const revVar = netRevActual - netRevBenchmark; // Positive helps EBITDA
  const cogsVar = -(cogs.actual - cogs.benchmark); // Cost overrun hurts EBITDA
  const opexVar = -(opex.actual - opex.benchmark); // Cost overrun hurts EBITDA

  let runTotal = ebitdaBenchmark;
  const baselineLabel = benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Year';

  const waterfallSteps = [
    {
      name: `${baselineLabel} EBITDA`,
      value: ebitdaBenchmark,
      runningTotal: ebitdaBenchmark,
      type: 'baseline' as const,
      formulaNote: 'Starting Benchmark Baseline',
    },
    {
      name: 'Net Revenue Movement',
      value: revVar,
      runningTotal: (runTotal += revVar),
      type: revVar >= 0 ? ('positive' as const) : ('negative' as const),
      formulaNote: `Revenue variance: ${revVar >= 0 ? '+' : ''}${formatCurrency(revVar, currency)}`,
    },
    {
      name: 'Direct COGS Movement',
      value: cogsVar,
      runningTotal: (runTotal += cogsVar),
      type: cogsVar >= 0 ? ('positive' as const) : ('negative' as const),
      formulaNote: `Direct cost variance: ${cogsVar >= 0 ? '+' : ''}${formatCurrency(cogsVar, currency)}`,
    },
    {
      name: 'OPEX Movement',
      value: opexVar,
      runningTotal: (runTotal += opexVar),
      type: opexVar >= 0 ? ('positive' as const) : ('negative' as const),
      formulaNote: `Operating expense variance: ${opexVar >= 0 ? '+' : ''}${formatCurrency(opexVar, currency)}`,
    },
    {
      name: 'Actual EBITDA',
      value: ebitdaActual,
      runningTotal: ebitdaActual,
      type: 'total' as const,
      formulaNote: `Delivered EBITDA: ${formatCurrency(ebitdaActual, currency)} (Reconciled diff: 0.00)`,
    },
  ];

  // 4. Balance Sheet Validation
  const balanceSheetCheck = performBalanceSheetValidation(accounts, netProfitActual);

  // 5. Leasing Revenue Decomposition
  const leasingDecomposition = decomposeLeasingRevenue(leasingDrivers, grossRev.actual, grossRev.benchmark);

  return {
    metrics,
    pnlAccounts,
    unmappedAccounts,
    grossRevenueSubCategories,
    contraRevenueSubCategories,
    cogsSubCategories,
    opexSubCategories,
    belowEbitdaSubCategories,
    topAdverseDrivers,
    topFavourableDrivers,
    waterfallSteps,
    balanceSheetCheck,
    leasingDecomposition,
  };
}
