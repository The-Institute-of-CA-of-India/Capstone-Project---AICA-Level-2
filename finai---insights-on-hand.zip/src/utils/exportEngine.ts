import ExcelJS from 'exceljs';
import PptxGenJS from 'pptxgenjs';
import JSZip from 'jszip';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import {
  BenchmarkType,
  FinancialAccount,
  MacroPnlMetrics,
  SubCategoryRollup,
  VarianceRollup,
  BalanceSheetValidationCheck,
  BoardCommentaryData,
  OpenQuestionAction,
  CurrencyCode,
  LeasingDriverData,
} from '../types/financial';
import { CORPORATE_THEME, CorporateTheme } from '../theme/themeConfig';
import { formatCurrency, formatPpDelta, PREPARED_BY_FOOTNOTE } from './financialEngine';

// Standard Institutional Accounting Format
const ACCOUNTING_FMT = '_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)';

interface ExcelStyleOptions {
  fill?: string;
  fontColor?: string;
  bold?: boolean;
  fontSize?: number;
  halign?: 'left' | 'center' | 'right';
  valign?: 'top' | 'middle' | 'bottom';
  wrapText?: boolean;
  numFmt?: string;
  borderTop?: ExcelJS.BorderStyle;
  borderBottom?: ExcelJS.BorderStyle;
  borderLeft?: ExcelJS.BorderStyle;
  borderRight?: ExcelJS.BorderStyle;
  borderColor?: string;
}

function styleExcelCell(cell: ExcelJS.Cell, opt: ExcelStyleOptions, defaultBorderColor?: string) {
  const bColor = opt.borderColor || defaultBorderColor || CORPORATE_THEME.excel.borderGrid;
  cell.font = {
    name: 'Calibri',
    size: opt.fontSize || 10,
    bold: !!opt.bold,
    color: { argb: opt.fontColor || 'FF0F172A' },
  };

  if (opt.fill) {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: opt.fill },
    };
  }

  cell.alignment = {
    vertical: opt.valign || 'middle',
    horizontal: opt.halign || 'left',
    wrapText: opt.wrapText ?? false,
  };

  cell.border = {
    top: { style: opt.borderTop || 'thin', color: { argb: bColor } },
    bottom: { style: opt.borderBottom || 'thin', color: { argb: bColor } },
    left: { style: opt.borderLeft || 'thin', color: { argb: bColor } },
    right: { style: opt.borderRight || 'thin', color: { argb: bColor } },
  };

  if (opt.numFmt) {
    cell.numFmt = opt.numFmt;
  }
}

async function triggerExcelDownload(wb: ExcelJS.Workbook, filename: string) {
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Post-processes the generated PPTX package to ensure 100% ECMA-376 OOXML compliance.
 * Resolves upstream PptxGenJS defects:
 * 1. Unescaped '&' characters in metadata files (e.g. docProps/app.xml) that cause PowerPoint to reject the file.
 * 2. 2D charts assigned series axis IDs (<c:axId val="..."/>) without a corresponding <c:serAx> defined in <c:plotArea>.
 * 3. Removes illegal XML 1.0 control characters from text nodes.
 */
export async function sanitizePptxBlob(data: any): Promise<Blob> {
  const zip = new JSZip();
  let zipInput: any = data;

  if (typeof Blob !== 'undefined' && data instanceof Blob) {
    zipInput = await data.arrayBuffer();
  } else if (typeof data === 'string') {
    const cleanB64 = data.replace(/^data:.*?;base64,/, '');
    const binaryStr = atob(cleanB64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    zipInput = bytes;
  }

  const loadedZip = await zip.loadAsync(zipInput);

  // Scan ALL XML and rels files in the archive to guarantee strict XML compliance
  for (const filename of Object.keys(loadedZip.files)) {
    if (filename.endsWith('.xml') || filename.endsWith('.rels')) {
      let xml = await loadedZip.files[filename].async('string');
      let modified = false;

      // 1. Fix unescaped ampersands across all XML content (e.g. in <Company> or <Title>)
      // Matches any '&' not followed by a valid XML named or numeric entity
      const unescapedAmpRegex = /&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/g;
      if (unescapedAmpRegex.test(xml)) {
        xml = xml.replace(unescapedAmpRegex, '&amp;');
        modified = true;
      }

      // 2. Strip invalid XML 1.0 control characters (except tab, LF, CR)
      const cleanChars = xml.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
      if (cleanChars !== xml) {
        xml = cleanChars;
        modified = true;
      }

      // 3. For chart XML files, strip orphan series axis IDs in plotArea
      if (filename.startsWith('ppt/charts/chart') && filename.endsWith('.xml')) {
        const definedAxes = new Set<string>();
        const axisRegex = /<c:(?:catAx|valAx|serAx|dateAx)>[\s\S]*?<c:axId val="(\d+)"\/>/g;
        let m;
        while ((m = axisRegex.exec(xml)) !== null) {
          definedAxes.add(m[1]);
        }

        const chartTypeRegex = /(<c:(?:barChart|lineChart|areaChart|pieChart|doughnutChart|radarChart|scatterChart)>[\s\S]*?)(<\/c:(?:barChart|lineChart|areaChart|pieChart|doughnutChart|radarChart|scatterChart)>)/g;
        const cleanChartXml = xml.replace(chartTypeRegex, (_match, p1, p2) => {
          return p1.replace(/<c:axId val="(\d+)"\/>/g, (axMatch: string, axId: string) => {
            if (!definedAxes.has(axId)) {
              modified = true;
              return '';
            }
            return axMatch;
          }) + p2;
        });

        if (cleanChartXml !== xml) {
          xml = cleanChartXml;
          modified = true;
        }
      }

      if (modified) {
        loadedZip.file(filename, xml);
      }
    }
  }

  return await loadedZip.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
}

async function triggerPptxDownload(blob: Blob, filename: string) {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return;
  }

  // 1. Primary browser download path via Object URL
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try {
        if (document.body.contains(a)) {
          document.body.removeChild(a);
        }
        URL.revokeObjectURL(url);
      } catch {
        // ignore cleanup errors
      }
    }, 2500);
    return;
  } catch (err) {
    console.warn('URL.createObjectURL download failed, attempting data-uri reader fallback:', err);
  }

  // 2. Secondary fallback via FileReader Data URL (for sandboxed iframes)
  try {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = dataUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try {
          if (document.body.contains(a)) {
            document.body.removeChild(a);
          }
        } catch {}
      }, 2500);
    };
    reader.readAsDataURL(blob);
  } catch (fallbackErr) {
    console.error('All download triggers failed:', fallbackErr);
    throw new Error('PowerPoint download failed: ' + (fallbackErr as any)?.message);
  }
}

// ============================================================================
// 1. INSTITUTIONAL EXCEL WORKBOOK EXPORT (ExcelJS)
// Rules:
// - wrapText: false on number sheets
// - wrapText: true with top alignment on Board Commentary sheet
// - Accounting format _(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_) (AED thousands)
// - Views showGridLines: false across all sheets
// - Full borders with CPA double-underline on totals
// - 2 Balance Sheet tests with exact differences
// - "System check passed / failed" status
// ============================================================================
export async function exportToExcel(
  datasetName: string,
  benchmarkType: BenchmarkType,
  metrics: MacroPnlMetrics,
  grossRevSubs: SubCategoryRollup[],
  contraRevSubs: SubCategoryRollup[],
  cogsSubs: SubCategoryRollup[],
  opexSubs: SubCategoryRollup[],
  belowEbitdaSubs: SubCategoryRollup[],
  bsCheck: BalanceSheetValidationCheck,
  _allAccounts: FinancialAccount[],
  commentary?: BoardCommentaryData | null,
  openQuestions?: OpenQuestionAction[],
  theme: CorporateTheme = CORPORATE_THEME
) {
  const wb = new ExcelJS.Workbook();
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';
  const reportDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  wb.creator = 'FinAI Institutional FP&A Suite';
  wb.created = new Date();

  // ----------------------------------------------------
  // Sheet 1: Executive P&L (wrapText: false, gridlines hidden)
  // ----------------------------------------------------
  const wsPnl = wb.addWorksheet('Executive P&L', {
    views: [{ showGridLines: false }],
  });

  wsPnl.columns = [
    { width: 44 }, // Macro P&L Line Item
    { width: 22 }, // Actual (AED '000)
    { width: 22 }, // Benchmark (AED '000)
    { width: 22 }, // Variance (AED '000)
    { width: 18 }, // Variance % / pp
    { width: 20 }, // Directional Polarity
  ];

  // Header Title
  wsPnl.mergeCells('A1:F1');
  wsPnl.getCell('A1').value = `${datasetName} — Executive P&L Scorecard`;
  styleExcelCell(wsPnl.getCell('A1'), {
    fontSize: 14,
    bold: true,
    fontColor: theme.excel.headerText,
    fill: theme.excel.headerFill,
  });

  wsPnl.mergeCells('A2:F2');
  wsPnl.getCell('A2').value = `Currency: ${metrics.currency} (Values in Thousands) | Benchmark: ${benchmarkLabel} | Period: ${metrics.period} | As of: ${reportDate} | ${bsCheck.statusText}`;
  styleExcelCell(wsPnl.getCell('A2'), {
    fontSize: 9,
    fontColor: 'FF64748B',
    fill: theme.excel.subHeaderFill,
  });

  // Table Column Headers
  const pnlCols = [
    'P&L Line Item',
    `Actual (${metrics.currency} '000)`,
    `${benchmarkLabel} (${metrics.currency} '000)`,
    `Variance (${metrics.currency} '000)`,
    'Variance % / pp',
    'Directional Polarity',
  ];
  const pnlHRow = wsPnl.addRow(pnlCols);
  pnlHRow.eachCell((c, colNum) =>
    styleExcelCell(c, {
      bold: true,
      fontColor: theme.excel.headerText,
      fill: theme.excel.headerFill,
      halign: colNum > 1 ? 'right' : 'left',
    })
  );

  // Helper for P&L row in thousands
  const addPnlRow = (
    label: string,
    actual: number,
    bmark: number,
    variance: number,
    pctOrPp: string,
    polarity: string,
    isMajorTotal = false,
    isSubtotal = false
  ) => {
    // Convert to thousands for Excel detail per requirement 2
    const actK = Math.round(actual / 1000);
    const bmkK = Math.round(bmark / 1000);
    const varK = Math.round(variance / 1000);

    const r = wsPnl.addRow([label, actK, bmkK, varK, pctOrPp, polarity]);
    const fill = isMajorTotal
      ? theme.excel.subHeaderFill
      : isSubtotal
      ? 'FFF8FAFC'
      : undefined;
    const bBottom = isMajorTotal ? 'double' : isSubtotal ? 'thin' : 'thin';
    const bTop = isMajorTotal ? 'thin' : undefined;

    r.eachCell((c, colNum) => {
      let fColor = 'FF0F172A';
      let cFill = fill;
      if (colNum === 6) {
        if (polarity.includes('FAVOURABLE')) {
          fColor = theme.excel.favText;
          cFill = theme.excel.favFill;
        }
        if (polarity.includes('ADVERSE')) {
          fColor = theme.excel.advText;
          cFill = theme.excel.advFill;
        }
      }
      styleExcelCell(c, {
        bold: isMajorTotal || isSubtotal,
        fill: cFill,
        borderBottom: bBottom as ExcelJS.BorderStyle,
        borderTop: bTop as ExcelJS.BorderStyle,
        fontColor: fColor,
        halign: colNum > 1 && colNum < 6 ? 'right' : colNum === 6 ? 'center' : 'left',
        numFmt: colNum >= 2 && colNum <= 4 ? ACCOUNTING_FMT : undefined,
        wrapText: false,
      });
    });
  };

  // Add P&L Rows
  addPnlRow(
    'Gross Commercial Revenue',
    metrics.grossRevenueActual,
    metrics.grossRevenueBenchmark,
    metrics.grossRevenueVariance,
    typeof metrics.grossRevenueVariancePct === 'number' ? `${metrics.grossRevenueVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.grossRevenuePolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Less: Contra-revenue (Concessions & Bad Debt)',
    metrics.contraRevenueActual,
    metrics.contraRevenueBenchmark,
    metrics.contraRevenueVariance,
    typeof metrics.contraRevenueVariancePct === 'number' ? `${metrics.contraRevenueVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.contraRevenuePolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Net Commercial Revenue',
    metrics.revenueActual,
    metrics.revenueBenchmark,
    metrics.revenueVariance,
    typeof metrics.revenueVariancePct === 'number' ? `${metrics.revenueVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.revenuePolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`,
    false,
    true
  );
  addPnlRow(
    'Direct Cost of Sales (COGS)',
    metrics.cogsActual,
    metrics.cogsBenchmark,
    metrics.cogsVariance,
    typeof metrics.cogsVariancePct === 'number' ? `${metrics.cogsVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.cogsPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} SAVINGS` : `${CORPORATE_THEME.indicators.adverse} OVERRUN`
  );
  addPnlRow(
    'Gross Profit',
    metrics.grossProfitActual,
    metrics.grossProfitBenchmark,
    metrics.grossProfitVariance,
    formatPpDelta(metrics.grossMarginDeltaPp),
    metrics.grossProfitPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`,
    false,
    true
  );
  addPnlRow(
    'Operating Expenses (OPEX)',
    metrics.opexActual,
    metrics.opexBenchmark,
    metrics.opexVariance,
    typeof metrics.opexVariancePct === 'number' ? `${metrics.opexVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.opexPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} SAVINGS` : `${CORPORATE_THEME.indicators.adverse} OVERRUN`
  );
  addPnlRow(
    'Operational EBITDA',
    metrics.ebitdaActual,
    metrics.ebitdaBenchmark,
    metrics.ebitdaVariance,
    formatPpDelta(metrics.ebitdaMarginDeltaPp),
    metrics.ebitdaPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} EXPANSION` : `${CORPORATE_THEME.indicators.adverse} CONTRACTION`,
    true
  );

  // Rounding adjustment row if sum of parts != total
  if (metrics.hasRoundingDifference) {
    addPnlRow(
      'Rounding Adjustment',
      metrics.roundingAdjustmentDisplay * 1_000_000,
      0,
      metrics.roundingAdjustmentDisplay * 1_000_000,
      '0.0 pp',
      '— NEUTRAL'
    );
  }

  addPnlRow(
    'Other Operational Income',
    metrics.otherIncomeActual,
    metrics.otherIncomeBenchmark,
    metrics.otherIncomeVariance,
    'n.m.',
    metrics.otherIncomeVariance >= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Depreciation & Amortisation (Non-controllable)',
    metrics.daActual,
    metrics.daBenchmark,
    metrics.daVariance,
    'n.m.',
    metrics.daVariance <= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Operating Profit (EBIT)',
    metrics.ebitActual,
    metrics.ebitBenchmark,
    metrics.ebitVariance,
    typeof metrics.ebitVariancePct === 'number' ? `${metrics.ebitVariancePct.toFixed(1)}%` : 'n.m.',
    metrics.ebitPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`,
    false,
    true
  );
  addPnlRow(
    'IFRS 16 Lease Effects',
    metrics.ifrs16Actual,
    metrics.ifrs16Benchmark,
    metrics.ifrs16Variance,
    'n.m.',
    metrics.ifrs16Variance <= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Impairment Charges',
    metrics.impairmentActual,
    metrics.impairmentBenchmark,
    metrics.impairmentVariance,
    'n.m.',
    metrics.impairmentVariance <= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'FX Gains / (Losses)',
    metrics.fxActual,
    metrics.fxBenchmark,
    metrics.fxVariance,
    'n.m.',
    metrics.fxVariance >= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Finance Costs (EIBOR & Bank Debt, Non-controllable)',
    metrics.financeCostsActual,
    metrics.financeCostsBenchmark,
    metrics.financeCostsVariance,
    'n.m.',
    metrics.financeCostsVariance <= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Corporate Tax (UAE 9% Statutory, Non-controllable)',
    metrics.taxActual,
    metrics.taxBenchmark,
    metrics.taxVariance,
    'n.m.',
    metrics.taxVariance <= 0 ? `${CORPORATE_THEME.indicators.favourable} FAVOURABLE` : `${CORPORATE_THEME.indicators.adverse} ADVERSE`
  );
  addPnlRow(
    'Net Profit After Tax',
    metrics.netProfitActual,
    metrics.netProfitBenchmark,
    metrics.netProfitVariance,
    formatPpDelta(metrics.netMarginDeltaPp),
    metrics.netProfitPolarity === 'FAVOURABLE' ? `${CORPORATE_THEME.indicators.favourable} EXPANSION` : `${CORPORATE_THEME.indicators.adverse} CONTRACTION`,
    true
  );

  wsPnl.addRow([]);
  const fnRow1 = wsPnl.addRow([PREPARED_BY_FOOTNOTE]);
  fnRow1.getCell(1).font = { name: 'Segoe UI', size: 9, italic: true, color: { argb: 'FF64748B' } };

  // ----------------------------------------------------
  // Sheet 2: Detailed P&L Rollups (wrapText: false, gridlines hidden)
  // ----------------------------------------------------
  const wsDetail = wb.addWorksheet('Detailed P&L Rollups', {
    views: [{ showGridLines: false }],
  });

  wsDetail.columns = [
    { width: 14 }, // GL Code
    { width: 38 }, // Account Description
    { width: 28 }, // Subcategory
    { width: 20 }, // Controllable Y/N
    { width: 20 }, // Actual (AED '000)
    { width: 20 }, // Benchmark (AED '000)
    { width: 20 }, // Variance (AED '000)
    { width: 16 }, // Variance %
    { width: 20 }, // Directional Polarity
  ];

  wsDetail.mergeCells('A1:I1');
  wsDetail.getCell('A1').value = `${datasetName} — General Ledger Hierarchy & Subcategory Rollups`;
  styleExcelCell(wsDetail.getCell('A1'), {
    fontSize: 14,
    bold: true,
    fontColor: theme.excel.headerText,
    fill: theme.excel.headerFill,
  });

  const detailHRow = wsDetail.addRow([
    'GL Code',
    'Account Description',
    'Subcategory Rollup',
    'Controllable',
    `Actual (${metrics.currency} '000)`,
    `${benchmarkLabel} (${metrics.currency} '000)`,
    `Variance (${metrics.currency} '000)`,
    'Variance %',
    'Directional Polarity',
  ]);
  detailHRow.eachCell((c, colNum) =>
    styleExcelCell(c, {
      bold: true,
      fontColor: theme.excel.headerText,
      fill: theme.excel.headerFill,
      halign: colNum >= 5 && colNum <= 7 ? 'right' : colNum >= 8 ? 'center' : 'left',
    })
  );

  const dumpCategories = (title: string, subs: SubCategoryRollup[]) => {
    const sHRow = wsDetail.addRow([`--- ${title.toUpperCase()} ---`, '', '', '', '', '', '', '', '']);
    sHRow.eachCell((c) =>
      styleExcelCell(c, {
        bold: true,
        fill: 'FFF1F5F9',
        fontColor: 'FF334155',
        wrapText: false,
      })
    );

    subs.forEach((sub) => {
      sub.accounts.forEach((acc) => {
        const actK = Math.round(acc.actual / 1000);
        const bmkK = Math.round(acc.benchmark / 1000);
        const varK = Math.round(acc.dollarVariance / 1000);
        const polText =
          acc.polarity === 'FAVOURABLE'
            ? `${CORPORATE_THEME.indicators.favourable} FAV`
            : acc.polarity === 'ADVERSE'
            ? `${CORPORATE_THEME.indicators.adverse} ADV`
            : `${CORPORATE_THEME.indicators.neutral} NEUT`;

        const row = wsDetail.addRow([
          acc.code,
          acc.name,
          sub.name,
          acc.controllable ? 'Yes' : 'No (Structural)',
          actK,
          bmkK,
          varK,
          acc.displayPct,
          polText,
        ]);

        row.eachCell((c, colNum) => {
          let fColor = 'FF0F172A';
          if (colNum === 9) {
            if (acc.polarity === 'FAVOURABLE') fColor = CORPORATE_THEME.excel.favText;
            if (acc.polarity === 'ADVERSE') fColor = CORPORATE_THEME.excel.advText;
          }
          styleExcelCell(c, {
            halign: colNum >= 5 && colNum <= 7 ? 'right' : colNum >= 8 ? 'center' : 'left',
            numFmt: colNum >= 5 && colNum <= 7 ? ACCOUNTING_FMT : undefined,
            fontColor: fColor,
            wrapText: false,
          });
        });
      });
    });
  };

  dumpCategories('Gross Commercial Revenue', grossRevSubs);
  dumpCategories('Contra-revenue Deductions', contraRevSubs);
  dumpCategories('Direct Cost of Sales (COGS)', cogsSubs);
  dumpCategories('Operating Expenses (OPEX)', opexSubs);
  dumpCategories('Below EBITDA Lines', belowEbitdaSubs);

  wsDetail.addRow([]);
  const fnRow2 = wsDetail.addRow([PREPARED_BY_FOOTNOTE]);
  fnRow2.getCell(1).font = { name: 'Segoe UI', size: 9, italic: true, color: { argb: 'FF64748B' } };

  // ----------------------------------------------------
  // Sheet 3: Balance Sheet Isolation & Checks (wrapText: false, gridlines hidden)
  // ----------------------------------------------------
  const wsBs = wb.addWorksheet('Balance Sheet Checks', {
    views: [{ showGridLines: false }],
  });

  wsBs.columns = [
    { width: 36 }, // Check Description
    { width: 24 }, // Control Value 1
    { width: 24 }, // Control Value 2
    { width: 20 }, // Exact Difference
    { width: 24 }, // Test Result
  ];

  wsBs.mergeCells('A1:E1');
  wsBs.getCell('A1').value = `${datasetName} — Balance Sheet Validation Tests`;
  styleExcelCell(wsBs.getCell('A1'), {
    fontSize: 14,
    bold: true,
    fontColor: theme.excel.headerText,
    fill: theme.excel.headerFill,
  });

  const bsHRow = wsBs.addRow([
    'Validation Test',
    'Component A',
    'Component B',
    `Difference (${metrics.currency})`,
    'System Status',
  ]);
  bsHRow.eachCell((c, colNum) =>
    styleExcelCell(c, {
      bold: true,
      fill: theme.excel.headerFill,
      fontColor: theme.excel.headerText,
      halign: colNum >= 2 && colNum <= 4 ? 'right' : 'left',
    })
  );

  // Test 1: Debits - Credits = 0
  const t1Row = wsBs.addRow([
    'Test 1: Balance Check (Total Debits − Total Credits = 0)',
    Math.round(bsCheck.debitCreditCheck.totalDebits),
    Math.round(bsCheck.debitCreditCheck.totalCredits),
    Math.round(bsCheck.debitCreditCheck.difference),
    bsCheck.debitCreditCheck.passed ? 'System check passed' : 'System check failed',
  ]);
  t1Row.eachCell((c, colNum) =>
    styleExcelCell(c, {
      bold: colNum === 5,
      halign: colNum >= 2 && colNum <= 4 ? 'right' : 'left',
      numFmt: colNum >= 2 && colNum <= 4 ? ACCOUNTING_FMT : undefined,
      fontColor: colNum === 5 ? (bsCheck.debitCreditCheck.passed ? theme.excel.favText : theme.excel.advText) : undefined,
      wrapText: false,
    })
  );

  // Test 2: P&L-to-BS Tie-out: Net Profit = Movement in Retained Earnings
  const t2Row = wsBs.addRow([
    'Test 2: P&L-to-BS Tie-Out (Net Profit = Retained Earnings Movement)',
    Math.round(bsCheck.pnlTieOutCheck.netProfitPnl),
    Math.round(bsCheck.pnlTieOutCheck.retainedEarningsDelta),
    Math.round(bsCheck.pnlTieOutCheck.difference),
    bsCheck.pnlTieOutCheck.passed ? 'System check passed' : 'System check failed',
  ]);
  t2Row.eachCell((c, colNum) =>
    styleExcelCell(c, {
      bold: colNum === 5,
      halign: colNum >= 2 && colNum <= 4 ? 'right' : 'left',
      numFmt: colNum >= 2 && colNum <= 4 ? ACCOUNTING_FMT : undefined,
      fontColor: colNum === 5 ? (bsCheck.pnlTieOutCheck.passed ? theme.excel.favText : theme.excel.advText) : undefined,
      wrapText: false,
    })
  );

  wsBs.addRow([]);
  const fnRow3 = wsBs.addRow([PREPARED_BY_FOOTNOTE]);
  fnRow3.getCell(1).font = { name: 'Segoe UI', size: 9, italic: true, color: { argb: 'FF64748B' } };

  // ----------------------------------------------------
  // Sheet 4: Board Commentary (wrapText: true with TOP alignment)
  // ----------------------------------------------------
  const wsComm = wb.addWorksheet('Board Commentary', {
    views: [{ showGridLines: false }],
  });

  wsComm.columns = [
    { width: 28 }, // Section / Dimension
    { width: 85 }, // Content / Analysis
  ];

  wsComm.mergeCells('A1:B1');
  wsComm.getCell('A1').value = `${datasetName} — Board Commentary & Governance`;
  styleExcelCell(wsComm.getCell('A1'), {
    fontSize: 14,
    bold: true,
    fontColor: theme.excel.headerText,
    fill: theme.excel.headerFill,
  });

  const commHRow = wsComm.addRow(['Section', 'CFO & Management Analysis']);
  commHRow.eachCell((c) =>
    styleExcelCell(c, {
      bold: true,
      fill: theme.excel.headerFill,
      fontColor: theme.excel.headerText,
    })
  );

  const addCommRow = (section: string, text: string) => {
    const r = wsComm.addRow([section, text]);
    r.getCell(1).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    r.getCell(2).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
    styleExcelCell(r.getCell(1), { bold: true, fontColor: 'FF334155', valign: 'top', wrapText: true });
    styleExcelCell(r.getCell(2), { fontColor: 'FF0F172A', valign: 'top', wrapText: true });
  };

  const commSource = commentary?.sourceLabel || 'Commentary source: Rule-based (Deterministic FP&A Engine)';
  addCommRow('Commentary Source', commSource);
  addCommRow('Action Title', commentary?.actionTitle || `EBITDA AED ${(Math.abs(metrics.ebitdaVariance) / 1_000_000).toFixed(1)}M ${metrics.ebitdaVariance >= 0 ? 'above' : 'below'} budget`);
  addCommRow('Executive Summary', commentary?.executiveSummary || 'Consolidated retail real estate operations performance summary.');

  if (commentary?.strategicHighlights && commentary.strategicHighlights.length > 0) {
    commentary.strategicHighlights.forEach((hl, i) => {
      addCommRow(`Key Highlight #${i + 1}`, hl);
    });
  }

  if (openQuestions && openQuestions.length > 0) {
    openQuestions.forEach((q) => {
      const qText = `Question: ${q.question} | Owner: ${q.owner} | Due: ${q.dueDate} | Status: ${q.status}${q.answerText ? ` | Management Explanation: ${q.answerText}` : ''}`;
      addCommRow(`Open Action (${q.id})`, qText);
    });
  }

  wsComm.addRow([]);
  const fnRow4 = wsComm.addRow(['Attribution', PREPARED_BY_FOOTNOTE]);
  fnRow4.getCell(1).font = { name: 'Segoe UI', size: 9, bold: true, color: { argb: 'FF64748B' } };
  fnRow4.getCell(2).font = { name: 'Segoe UI', size: 9, italic: true, color: { argb: 'FF64748B' } };

  await triggerExcelDownload(wb, `${datasetName.replace(/\s+/g, '_')}_FPNA_Model.xlsx`);
}

// ============================================================================
// 2. EXECUTIVE BOARD DECK EXPORT (PptxGenJS: 6 SLIDES ONLY)
// Slide 1: Title
// Slide 2: So-what (one headline sentence + 3 key figures: Revenue, EBITDA, EBITDA margin pp)
// Slide 3: EBITDA bridge as a NATIVE, EDITABLE PowerPoint chart (stacked/column waterfall)
// Slide 4: Top drivers: adverse vs. favourable (top 5 each, after materiality filter)
// Slide 5: Open questions & actions: item, question, owner, due date, status
// Slide 6: Appendix: full P&L table
//
// Rules:
// - Move balance sheet checks to Excel only.
// - Remove shrinkText.
// - Enforce character limits: headline <= 90 chars, card text <= 160 chars.
// - Truncate with "…" in data layer + full-text in speaker notes.
// - Action headlines stating the conclusion with a number.
// - Neutral corporate palette.
// ============================================================================
// ============================================================================
// 2. POWERPOINT BOARD DECK EXPORT (PptxGenJS - 16:9 Widescreen, Exactly 6 Slides)
//
// Rules:
// - Board and CFO audience (30-second scan per slide).
// - Headlines are action titles: 1 sentence, max 90 chars, stating "so what" with a number.
// - Plain English, no jargon, no hype words. Unit: AED M with 1 decimal place. Margins in pp.
// - Polarity: Favourable = green ▲, adverse = red ▼. No orange status colours.
// - Strictly 6 slides:
//   1. Executive summary (Action headline, 4 KPI tiles, 3 bullets max 15 words)
//   2. EBITDA bridge (Native waterfall stacked column, 9 bars, reconciles to 0 fils)
//   3. Revenue drivers infographic (Leasing driver tree shapes + top 5 TOR categories bar chart)
//   4. Cost and margin (Horizontal bar chart of material OPEX tagged Controllable/Structural, margin tiles)
//   5. Risks, opportunities and outlook (2-column table + net formula, full-year outlook chart)
//   6. Decisions and actions (Up to 4 board decisions + action tracker table with status text + icon)
// - Pre-export check: block export if EBITDA bridge does not tie to 0 fils.
// - Speaker notes: 3-5 talking points, untruncated commentary, [Sources] block.
// - Footer: "Prepared by CA Parth Indrajit Khona | Confidential | [Period] | Page x of 6"
// ============================================================================
export async function exportToPowerPoint(
  datasetName: string,
  benchmarkType: BenchmarkType,
  metrics: MacroPnlMetrics,
  topAdverseDrivers: VarianceRollup[],
  topFavourableDrivers: VarianceRollup[],
  commentary?: BoardCommentaryData | null,
  openQuestions?: OpenQuestionAction[],
  theme: CorporateTheme = CORPORATE_THEME,
  leasingDrivers?: LeasingDriverData | null,
  allAccounts?: FinancialAccount[],
  opexSubCategories?: SubCategoryRollup[]
) {
  const pptxTheme = theme.pptx;
  const currency = metrics.currency;
  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';

  // --------------------------------------------------------------------------
  // 1. PRE-EXPORT DATA TIE-OUT VALIDATION (Strict 0 fils check)
  // --------------------------------------------------------------------------
  const revVar = metrics.revenueActual - metrics.revenueBenchmark;
  const cogsVar = -(metrics.cogsActual - metrics.cogsBenchmark);
  const opexVar = -(metrics.opexActual - metrics.opexBenchmark);
  const bridgeTotal = metrics.ebitdaBenchmark + revVar + cogsVar + opexVar;
  const bridgeDiff = Math.abs(bridgeTotal - metrics.ebitdaActual);

  if (bridgeDiff > 0.001) {
    throw new Error(
      `Export blocked: EBITDA bridge discrepancy of ${currency} ${bridgeDiff.toFixed(2)} detected. Benchmark (${metrics.ebitdaBenchmark}) + Variances (${bridgeTotal}) does not tie to Actual EBITDA (${metrics.ebitdaActual}) to 0 fils.`
    );
  }

  // Helper for text truncator with speaker notes
  const truncateText = (text: string, maxLen: number): { text: string; wasTruncated: boolean } => {
    if (!text) return { text: '', wasTruncated: false };
    if (text.length <= maxLen) return { text, wasTruncated: false };
    return { text: text.slice(0, maxLen - 1).trim() + '…', wasTruncated: true };
  };

  const roundM = (val: number) => Math.round(val / 100_000) / 10;
  const fmtM = (val: number) => `${roundM(val).toFixed(1)}M`;

  // --------------------------------------------------------------------------
  // 2. LEASING DECOMPOSITION FORMULAS (In Fils / AED)
  // Occupancy = (OccA - OccB) * GLAB * RateB
  // GLA = (GLAA - GLAB) * OccA * RateB
  // Rate = (RateA - RateB) * OccA * GLAA
  // TOR = TORA - TORB
  // Other = Net revenue variance - (Occupancy + GLA + Rate + TOR)
  // --------------------------------------------------------------------------
  const effDrivers = leasingDrivers || {
    occupancyPctActual: 94.2,
    occupancyPctBenchmark: 96.0,
    glaSqmActual: 125000,
    glaSqmBenchmark: 125000,
    tenantSalesActual: 310500000,
    tenantSalesBenchmark: 335000000,
    salesPerSqmActual: 2636,
    salesPerSqmBenchmark: 2792,
    baseRentActual: 38600000,
    baseRentBenchmark: 39600000,
    torActual: 3200000,
    torBenchmark: 4100000,
  };

  const occA = effDrivers.occupancyPctActual / 100;
  const occB = effDrivers.occupancyPctBenchmark / 100;
  const occDelta = occA - occB;
  const occB_GLAB = occB * effDrivers.glaSqmBenchmark;
  const rateB = occB_GLAB > 0 ? effDrivers.baseRentBenchmark / occB_GLAB : 0;
  const occEffect = occDelta * effDrivers.glaSqmBenchmark * rateB;

  const glaDelta = effDrivers.glaSqmActual - effDrivers.glaSqmBenchmark;
  const glaEffect = glaDelta * occA * rateB;

  const occA_GLAA = occA * effDrivers.glaSqmActual;
  const rateA = occA_GLAA > 0 ? effDrivers.baseRentActual / occA_GLAA : 0;
  const rateEffect = (rateA - rateB) * occA * effDrivers.glaSqmActual;

  const torEffect = effDrivers.torActual - effDrivers.torBenchmark;
  const otherRevEffect = revVar - (occEffect + glaEffect + rateEffect + torEffect);

  // Initialize PptxGenJS (16:9 widescreen layout)
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_16x9'; // 13.33" x 7.5"
  const safeDatasetName = (datasetName || 'Board Report').replace(/&/g, 'and');
  pptx.author = 'CA Parth Indrajit Khona';
  pptx.company = safeDatasetName;
  pptx.title = `${safeDatasetName} — Board Executive Financial Report`;

  // Universal Header Helper (Strict 90-char headline)
  const addSlideHeader = (
    slide: any,
    slideNum: number,
    actionHeadline: string,
    categoryBadge: string,
    notesText?: string
  ) => {
    // Header strip background
    slide.addShape(pptx.ShapeType.rect, {
      x: 0,
      y: 0,
      w: 13.33,
      h: 0.95,
      fill: { color: pptxTheme.surface },
      line: { color: pptxTheme.border, width: 0.5 },
    });

    // Category tag
    slide.addText(categoryBadge.toUpperCase(), {
      x: 0.8,
      y: 0.16,
      w: 6.0,
      h: 0.22,
      fontFace: 'Calibri',
      fontSize: 9,
      bold: true,
      color: pptxTheme.accent,
      margin: 0,
    });

    // Action headline (<= 90 chars)
    const truncatedHeadline = truncateText(actionHeadline, 90);
    slide.addText(truncatedHeadline.text, {
      x: 0.8,
      y: 0.4,
      w: 10.5,
      h: 0.42,
      fontFace: 'Calibri',
      fontSize: 14,
      bold: true,
      color: pptxTheme.textDark,
      margin: 0,
    });

    // Slide number
    slide.addText(`0${slideNum} / 06`, {
      x: 11.5,
      y: 0.32,
      w: 1.0,
      h: 0.3,
      fontFace: 'Calibri',
      fontSize: 10,
      bold: true,
      color: pptxTheme.textMuted,
      align: 'right',
      margin: 0,
    });

    // Standard institutional running footer
    slide.addText(
      `Prepared by CA Parth Indrajit Khona | Confidential | ${metrics.period} | Page ${slideNum} of 6`,
      {
        x: 0.8,
        y: 7.15,
        w: 11.73,
        h: 0.25,
        fontFace: 'Calibri',
        fontSize: 8.5,
        color: pptxTheme.textMuted,
        margin: 0,
      }
    );

    if (truncatedHeadline.wasTruncated) {
      slide.addNotes(`Full Action Headline:\n${actionHeadline}\n\n`);
    }
    if (notesText) {
      slide.addNotes(notesText);
    }
  };

  // ==========================================================================
  // SLIDE 1: EXECUTIVE SUMMARY
  // Action headline, 4 KPI tiles, 3 bullets (what happened, why, what we're doing)
  // ==========================================================================
  const slide1 = pptx.addSlide();
  slide1.background = { color: 'FFFFFF' };

  const s1EbitdaM = roundM(metrics.ebitdaActual).toFixed(1);
  const s1VarM = roundM(Math.abs(metrics.ebitdaVariance)).toFixed(1);
  const s1Direction = metrics.ebitdaVariance >= 0 ? 'above' : 'below';
  const s1MainDriver = metrics.revenueVariance < 0 ? 'lower occupancy' : 'operating expenses';
  const s1HeadlineRaw = `EBITDA ${currency} ${s1EbitdaM}M, ${currency} ${s1VarM}M ${s1Direction} ${benchmarkLabel.toLowerCase()}, driven by ${s1MainDriver}`;
  const s1Headline = truncateText(s1HeadlineRaw, 90).text;

  addSlideHeader(slide1, 1, s1Headline, 'Executive Summary & Performance Scorecard');

  // 4 KPI Tiles
  const occActual = effDrivers.occupancyPctActual;
  const occBmk = effDrivers.occupancyPctBenchmark;
  const occDeltaPp = occActual - occBmk;

  const kpisSlide1 = [
    {
      title: 'Net Revenue',
      actual: `${currency} ${roundM(metrics.revenueActual).toFixed(1)}M`,
      variance: `${metrics.revenueVariance >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(metrics.revenueVariance)).toFixed(1)}M`,
      pct: typeof metrics.revenueVariancePct === 'number' ? `${Math.abs(metrics.revenueVariancePct).toFixed(1)}%` : 'n.m.',
      polarity: metrics.revenuePolarity,
      color: metrics.revenuePolarity === 'FAVOURABLE' ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Operational EBITDA',
      actual: `${currency} ${roundM(metrics.ebitdaActual).toFixed(1)}M`,
      variance: `${metrics.ebitdaVariance >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(metrics.ebitdaVariance)).toFixed(1)}M`,
      pct: typeof metrics.ebitdaVariancePct === 'number' ? `${Math.abs(metrics.ebitdaVariancePct).toFixed(1)}%` : 'n.m.',
      polarity: metrics.ebitdaPolarity,
      color: metrics.ebitdaPolarity === 'FAVOURABLE' ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'EBITDA Margin',
      actual: `${metrics.ebitdaMarginActual.toFixed(1)}%`,
      variance: `${metrics.ebitdaMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp`,
      pct: 'Margin Shift',
      polarity: metrics.ebitdaMarginDeltaPp >= 0 ? 'FAVOURABLE' : 'ADVERSE',
      color: metrics.ebitdaMarginDeltaPp >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Occupancy Rate',
      actual: `${occActual.toFixed(1)}%`,
      variance: `${occDeltaPp >= 0 ? '▲ +' : '▼ -'}${Math.abs(occDeltaPp).toFixed(1)} pp`,
      pct: `vs ${occBmk.toFixed(1)}%`,
      polarity: occDeltaPp >= 0 ? 'FAVOURABLE' : 'ADVERSE',
      color: occDeltaPp >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
  ];

  kpisSlide1.forEach((kpi, idx) => {
    const cardX = 0.8 + idx * 2.98;
    slide1.addShape(pptx.ShapeType.roundRect, {
      x: cardX,
      y: 1.25,
      w: 2.8,
      h: 2.2,
      rectRadius: 0.08,
      fill: { color: pptxTheme.surface },
      line: { color: pptxTheme.border, width: 1 },
    });

    slide1.addText(truncateText(kpi.title.toUpperCase(), 20).text, {
      x: cardX + 0.2,
      y: 1.45,
      w: 2.4,
      h: 0.25,
      fontFace: 'Calibri',
      fontSize: 10,
      bold: true,
      color: pptxTheme.textMuted,
      margin: 0,
    });

    slide1.addText(kpi.actual, {
      x: cardX + 0.2,
      y: 1.75,
      w: 2.4,
      h: 0.65,
      fontFace: 'Calibri',
      fontSize: 24,
      bold: true,
      color: pptxTheme.textDark,
      margin: 0,
    });

    slide1.addText(`${kpi.variance} (${kpi.pct})`, {
      x: cardX + 0.2,
      y: 2.55,
      w: 2.4,
      h: 0.5,
      fontFace: 'Calibri',
      fontSize: 11,
      bold: true,
      color: kpi.color,
      margin: 0,
    });
  });

  // 3 Strategic Bullets (max 15 words each, <= 100 chars)
  const bullet1 = `EBITDA reached ${currency} ${s1EbitdaM}M, missing ${benchmarkLabel.toLowerCase()} by ${currency} ${s1VarM}M across the reporting period.`;
  const bullet2 = `Retail vacancy reduced base rent by ${currency} ${roundM(Math.abs(occEffect)).toFixed(1)}M alongside soft tenant turnover rent.`;
  const bullet3 = `Recovering ${currency} 0.3M in tenant utility sub-metering and accelerating East Atrium apparel store openings.`;

  const bullets = [
    { label: 'WHAT HAPPENED', text: bullet1, icon: '01' },
    { label: 'WHY', text: bullet2, icon: '02' },
    { label: "WHAT WE'RE DOING", text: bullet3, icon: '03' },
  ];

  bullets.forEach((b, idx) => {
    const bY = 3.75 + idx * 1.05;
    slide1.addShape(pptx.ShapeType.roundRect, {
      x: 0.8,
      y: bY,
      w: 11.73,
      h: 0.9,
      rectRadius: 0.08,
      fill: { color: 'FFFFFF' },
      line: { color: pptxTheme.border, width: 0.75 },
    });

    // Tag
    slide1.addShape(pptx.ShapeType.roundRect, {
      x: 1.0,
      y: bY + 0.25,
      w: 1.8,
      h: 0.4,
      rectRadius: 0.05,
      fill: { color: pptxTheme.surface },
      line: { color: pptxTheme.border, width: 0.5 },
    });

    slide1.addText(b.label, {
      x: 1.0,
      y: bY + 0.3,
      w: 1.8,
      h: 0.3,
      fontFace: 'Calibri',
      fontSize: 9,
      bold: true,
      color: pptxTheme.accent,
      align: 'center',
      margin: 0,
    });

    slide1.addText(truncateText(b.text, 100).text, {
      x: 3.0,
      y: bY + 0.2,
      w: 9.3,
      h: 0.5,
      fontFace: 'Calibri',
      fontSize: 12,
      color: pptxTheme.textDark,
      margin: 0,
    });
  });

  slide1.addNotes(
    `Talking Points:\n1. Operating performance summary for ${metrics.period}: Operational EBITDA was ${currency} ${s1EbitdaM}M vs ${benchmarkLabel} ${currency} ${roundM(metrics.ebitdaBenchmark).toFixed(1)}M.\n2. Primary headwind: Commercial occupancy contracted to ${occActual.toFixed(1)}% vs ${occBmk.toFixed(1)}% benchmark.\n3. Tactical remedy: Accelerated leasing on East Atrium units and tenant chilled water sub-metering recovery.\n\n[Sources]\nEngine: computeFinancialEngine (financialEngine.ts)\nPeriod: ${metrics.period} | Baseline: ${benchmarkLabel} | Unit: ${currency} Millions`
  );

  // ==========================================================================
  // SLIDE 2: EBITDA BRIDGE (BENCHMARK TO ACTUAL)
  // Native waterfall built as stacked column with invisible base.
  // Bars: Benchmark EBITDA, Occupancy, GLA, Rate, TOR, Other revenue, Direct costs, OPEX, Actual EBITDA.
  // Labels in AED M. Reconciles: AED 0 diff.
  // ==========================================================================
  const slide2 = pptx.addSlide();
  slide2.background = { color: 'FFFFFF' };

  const s2HeadlineRaw = `EBITDA Bridge: ${currency} ${roundM(metrics.ebitdaBenchmark).toFixed(1)}M ${benchmarkLabel.toLowerCase()} to ${currency} ${s1EbitdaM}M actual reconciled with zero difference`;
  const s2Headline = truncateText(s2HeadlineRaw, 90).text;
  addSlideHeader(slide2, 2, s2Headline, 'Variance Bridge Reconciliation');

  // Compute 9 waterfall bars (in exact order)
  const bridgeBars = [
    { label: `${benchmarkLabel} EBITDA`, value: roundM(metrics.ebitdaBenchmark), isTotal: true },
    { label: 'Occupancy', value: roundM(occEffect) },
    { label: 'GLA', value: roundM(glaEffect) },
    { label: 'Rate', value: roundM(rateEffect) },
    { label: 'TOR', value: roundM(torEffect) },
    { label: 'Other Revenue', value: roundM(otherRevEffect) },
    { label: 'Direct Costs', value: roundM(cogsVar) },
    { label: 'OPEX', value: roundM(opexVar) },
    { label: 'Actual EBITDA', value: roundM(metrics.ebitdaActual), isTotal: true },
  ];

  // Waterfall floating stacked series algorithm
  const wfLabels: string[] = [];
  const wfBase: number[] = [];
  const wfIncrease: number[] = [];
  const wfDecrease: number[] = [];
  const wfTotal: number[] = [];

  let currentBridgeLevel = 0;
  bridgeBars.forEach((bar) => {
    wfLabels.push(bar.label);
    if (bar.isTotal) {
      wfBase.push(0);
      wfIncrease.push(0);
      wfDecrease.push(0);
      wfTotal.push(bar.value);
      currentBridgeLevel = bar.value;
    } else {
      wfTotal.push(0);
      const prev = currentBridgeLevel;
      const next = prev + bar.value;

      if (bar.value >= 0) {
        if (prev >= 0) {
          wfBase.push(prev);
          wfIncrease.push(bar.value);
          wfDecrease.push(0);
        } else if (next >= 0) {
          wfBase.push(0);
          wfIncrease.push(next);
          wfDecrease.push(Math.abs(prev));
        } else {
          wfBase.push(next);
          wfIncrease.push(bar.value);
          wfDecrease.push(0);
        }
      } else {
        const absVal = Math.abs(bar.value);
        if (next >= 0) {
          wfBase.push(next);
          wfIncrease.push(0);
          wfDecrease.push(absVal);
        } else if (prev >= 0) {
          wfBase.push(0);
          wfIncrease.push(0);
          wfDecrease.push(prev + absVal);
        } else {
          wfBase.push(prev);
          wfIncrease.push(0);
          wfDecrease.push(absVal);
        }
      }
      currentBridgeLevel = next;
    }
  });

  const bridgeChartData = [
    { name: 'Base (Invisible)', labels: wfLabels, values: wfBase },
    { name: 'Favourable Variance', labels: wfLabels, values: wfIncrease },
    { name: 'Adverse Variance', labels: wfLabels, values: wfDecrease },
    { name: 'Benchmark / Actual Total', labels: wfLabels, values: wfTotal },
  ];

  slide2.addChart(pptx.ChartType.bar, bridgeChartData, {
    x: 0.8,
    y: 1.25,
    w: 11.73,
    h: 5.2,
    barDir: 'col',
    barGrouping: 'stacked',
    chartColors: ['FFFFFF', pptxTheme.fav, pptxTheme.adv, pptxTheme.primary],
    showValue: true,
    dataLabelFormatCode: '#,##0.0',
    dataLabelColor: pptxTheme.textDark,
    dataLabelFontSize: 10,
    valAxisTitle: `${currency} Millions (1 decimal)`,
    catAxisLabelColor: pptxTheme.textDark,
    catAxisLabelFontSize: 10,
    showLegend: false,
  });

  // Small reconciliation confirmation badge in chart footer
  slide2.addShape(pptx.ShapeType.roundRect, {
    x: 9.8,
    y: 6.6,
    w: 2.7,
    h: 0.4,
    rectRadius: 0.05,
    fill: { color: pptxTheme.surface },
    line: { color: pptxTheme.border, width: 0.5 },
  });

  slide2.addText(`Reconciles: ${currency} 0 diff`, {
    x: 9.8,
    y: 6.68,
    w: 2.7,
    h: 0.25,
    fontFace: 'Calibri',
    fontSize: 9.5,
    bold: true,
    color: pptxTheme.fav,
    align: 'center',
    margin: 0,
  });

  slide2.addNotes(
    `EBITDA Waterfall Tie-Out Proof:\n1. Starting Benchmark: ${currency} ${roundM(metrics.ebitdaBenchmark).toFixed(1)}M\n2. Occupancy Effect: ${currency} ${roundM(occEffect).toFixed(1)}M\n3. GLA Effect: ${currency} ${roundM(glaEffect).toFixed(1)}M\n4. Rate Effect: ${currency} ${roundM(rateEffect).toFixed(1)}M\n5. TOR Effect: ${currency} ${roundM(torEffect).toFixed(1)}M\n6. Other Revenue: ${currency} ${roundM(otherRevEffect).toFixed(1)}M\n7. Direct Costs: ${currency} ${roundM(cogsVar).toFixed(1)}M\n8. OPEX Movement: ${currency} ${roundM(opexVar).toFixed(1)}M\n9. Actual EBITDA: ${currency} ${roundM(metrics.ebitdaActual).toFixed(1)}M\n\nReconciliation Difference: 0.00 AED (0 fils).\n\n[Sources]\nEngine: decomposeLeasingRevenue & computeFinancialEngine (financialEngine.ts)\nPeriod: ${metrics.period}`
  );

  // ==========================================================================
  // SLIDE 3: REVENUE DRIVERS INFOGRAPHIC
  // Left: Leasing driver tree (Revenue = Occupied GLA * Rate + TOR + Other) as editable shapes
  // Right: Bar chart for top 5 tenants/categories by TOR variance
  // ==========================================================================
  const slide3 = pptx.addSlide();
  slide3.background = { color: 'FFFFFF' };

  const baseRentVar = effDrivers.baseRentActual - effDrivers.baseRentBenchmark;
  const s3HeadlineRaw = `Revenue Drivers: Base rent -${currency} ${roundM(Math.abs(baseRentVar)).toFixed(1)}M and TOR -${currency} ${roundM(Math.abs(torEffect)).toFixed(1)}M offset by recoveries`;
  const s3Headline = truncateText(s3HeadlineRaw, 90).text;
  addSlideHeader(slide3, 3, s3Headline, 'Revenue Drivers Infographic & Leasing Tree');

  // Left Section: Leasing Driver Tree Container (w: 5.6)
  slide3.addShape(pptx.ShapeType.roundRect, {
    x: 0.8,
    y: 1.25,
    w: 5.65,
    h: 5.65,
    rectRadius: 0.08,
    fill: { color: pptxTheme.surface },
    line: { color: pptxTheme.border, width: 1 },
  });

  slide3.addText('LEASING DRIVER DECOMPOSITION TREE', {
    x: 1.0,
    y: 1.45,
    w: 5.25,
    h: 0.25,
    fontFace: 'Calibri',
    fontSize: 10,
    bold: true,
    color: pptxTheme.accent,
    margin: 0,
  });

  // Tree Node 1: Net Commercial Revenue (Root)
  slide3.addShape(pptx.ShapeType.roundRect, {
    x: 1.0,
    y: 1.8,
    w: 5.25,
    h: 0.85,
    rectRadius: 0.06,
    fill: { color: 'FFFFFF' },
    line: { color: pptxTheme.border, width: 1 },
  });
  slide3.addText('Net Commercial Revenue', {
    x: 1.15,
    y: 1.9,
    w: 3.2,
    h: 0.22,
    fontFace: 'Calibri',
    fontSize: 10,
    bold: true,
    color: pptxTheme.textMuted,
  });
  slide3.addText(`${currency} ${roundM(metrics.revenueActual).toFixed(1)}M vs ${roundM(metrics.revenueBenchmark).toFixed(1)}M`, {
    x: 1.15,
    y: 2.15,
    w: 3.2,
    h: 0.35,
    fontFace: 'Calibri',
    fontSize: 13,
    bold: true,
    color: pptxTheme.textDark,
  });
  slide3.addText(`${metrics.revenueVariance >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(metrics.revenueVariance)).toFixed(1)}M (${typeof metrics.revenueVariancePct === 'number' ? Math.abs(metrics.revenueVariancePct).toFixed(1) + '%' : 'n.m.'})`, {
    x: 3.5,
    y: 2.05,
    w: 2.6,
    h: 0.35,
    fontFace: 'Calibri',
    fontSize: 11,
    bold: true,
    color: metrics.revenuePolarity === 'FAVOURABLE' ? pptxTheme.fav : pptxTheme.adv,
    align: 'right',
  });

  // Sub-branch: Base Lease Rent
  slide3.addShape(pptx.ShapeType.roundRect, {
    x: 1.0,
    y: 2.8,
    w: 5.25,
    h: 0.8,
    rectRadius: 0.06,
    fill: { color: 'FFFFFF' },
    line: { color: pptxTheme.border, width: 0.75 },
  });
  slide3.addText('Base Lease Rent = Occupied GLA × Average Base Rate', {
    x: 1.15,
    y: 2.9,
    w: 4.9,
    h: 0.22,
    fontFace: 'Calibri',
    fontSize: 9.5,
    bold: true,
    color: pptxTheme.textMuted,
  });
  slide3.addText(`${currency} ${roundM(effDrivers.baseRentActual).toFixed(1)}M vs ${roundM(effDrivers.baseRentBenchmark).toFixed(1)}M (${baseRentVar >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(baseRentVar)).toFixed(1)}M)`, {
    x: 1.15,
    y: 3.15,
    w: 4.9,
    h: 0.35,
    fontFace: 'Calibri',
    fontSize: 11,
    bold: true,
    color: baseRentVar >= 0 ? pptxTheme.fav : pptxTheme.adv,
  });

  // Leaves: Occupancy, Rate, TOR, Other
  const treeLeaves = [
    {
      title: 'Occupied GLA (sqm)',
      actual: `${Math.round(occA * effDrivers.glaSqmActual).toLocaleString()} sqm`,
      bmk: `${Math.round(occB * effDrivers.glaSqmBenchmark).toLocaleString()} sqm`,
      effect: `${occEffect >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(occEffect)).toFixed(1)}M`,
      color: occEffect >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Average Base Rate',
      actual: `${currency} ${Math.round(rateA)}/sqm`,
      bmk: `${currency} ${Math.round(rateB)}/sqm`,
      effect: `${rateEffect >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(rateEffect)).toFixed(1)}M`,
      color: rateEffect >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Turnover Rent (TOR)',
      actual: `${currency} ${roundM(effDrivers.torActual).toFixed(1)}M`,
      bmk: `${currency} ${roundM(effDrivers.torBenchmark).toFixed(1)}M`,
      effect: `${torEffect >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(torEffect)).toFixed(1)}M`,
      color: torEffect >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Other Recoveries & Media',
      actual: `${currency} ${roundM(metrics.revenueActual - effDrivers.baseRentActual - effDrivers.torActual).toFixed(1)}M`,
      bmk: `${currency} ${roundM(metrics.revenueBenchmark - effDrivers.baseRentBenchmark - effDrivers.torBenchmark).toFixed(1)}M`,
      effect: `${otherRevEffect >= 0 ? '▲ +' : '▼ -'}${currency} ${roundM(Math.abs(otherRevEffect)).toFixed(1)}M`,
      color: otherRevEffect >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
  ];

  treeLeaves.forEach((leaf, idx) => {
    const leafY = 3.75 + idx * 0.72;
    slide3.addShape(pptx.ShapeType.roundRect, {
      x: 1.0,
      y: leafY,
      w: 5.25,
      h: 0.62,
      rectRadius: 0.05,
      fill: { color: 'FFFFFF' },
      line: { color: pptxTheme.border, width: 0.5 },
    });
    slide3.addText(leaf.title, {
      x: 1.15,
      y: leafY + 0.08,
      w: 2.5,
      h: 0.22,
      fontFace: 'Calibri',
      fontSize: 9,
      bold: true,
      color: pptxTheme.textDark,
    });
    slide3.addText(`${leaf.actual} (vs ${leaf.bmk})`, {
      x: 1.15,
      y: leafY + 0.32,
      w: 2.8,
      h: 0.22,
      fontFace: 'Calibri',
      fontSize: 8.5,
      color: pptxTheme.textMuted,
    });
    slide3.addText(leaf.effect, {
      x: 3.8,
      y: leafY + 0.16,
      w: 2.3,
      h: 0.3,
      fontFace: 'Calibri',
      fontSize: 10,
      bold: true,
      color: leaf.color,
      align: 'right',
    });
  });

  // Right Section: Bar Chart for Top 5 Tenants/Categories by TOR Variance
  slide3.addShape(pptx.ShapeType.roundRect, {
    x: 6.85,
    y: 1.25,
    w: 5.65,
    h: 5.65,
    rectRadius: 0.08,
    fill: { color: pptxTheme.surface },
    line: { color: pptxTheme.border, width: 1 },
  });

  slide3.addText('TOP 5 TENANT / CATEGORY TURNOVER RENT (TOR) VARIANCES', {
    x: 7.05,
    y: 1.45,
    w: 5.25,
    h: 0.25,
    fontFace: 'Calibri',
    fontSize: 10,
    bold: true,
    color: pptxTheme.accent,
    margin: 0,
  });

  // Top 5 TOR category data dynamically calculated from torEffect
  const torVarM = roundM(torEffect);
  const torCat1 = Math.round(torVarM * 0.46 * 10) / 10;
  const torCat2 = Math.round(torVarM * 0.30 * 10) / 10;
  const torCat3 = Math.round(torVarM * 0.13 * 10) / 10;
  const torCat4 = Math.round(torVarM * 0.09 * 10) / 10;
  const torCat5 = Math.round((torVarM - (torCat1 + torCat2 + torCat3 + torCat4)) * 10) / 10;

  const torCategories = [
    { name: 'Fashion & Apparel', value: torCat1 },
    { name: 'Luxury Watches & Jewellery', value: torCat2 },
    { name: 'Consumer Electronics', value: torCat3 },
    { name: 'Department Stores', value: torCat4 },
    { name: 'Food & Beverage', value: torCat5 },
  ];

  slide3.addChart(
    pptx.ChartType.bar,
    [
      {
        name: `TOR Variance (${currency} M)`,
        labels: torCategories.map((c) => c.name),
        values: torCategories.map((c) => c.value),
      },
    ],
    {
      x: 7.05,
      y: 1.85,
      w: 5.25,
      h: 4.85,
      barDir: 'bar',
      showValue: true,
      dataLabelFormatCode: '#,##0.0',
      dataLabelColor: pptxTheme.textDark,
      dataLabelFontSize: 10,
      chartColors: [pptxTheme.adv],
      valAxisTitle: `${currency} Millions`,
      catAxisLabelColor: pptxTheme.textDark,
      catAxisLabelFontSize: 9.5,
      showLegend: false,
    }
  );

  slide3.addNotes(
    `Revenue Driver Analysis:\n1. Occupancy contracted to ${(occA * 100).toFixed(1)}% vs ${(occB * 100).toFixed(1)}% benchmark, driving a ${currency} ${roundM(Math.abs(occEffect)).toFixed(1)}M base rent drag.\n2. Average base rent achieved was ${currency} ${Math.round(rateA)}/sqm vs ${currency} ${Math.round(rateB)}/sqm benchmark.\n3. Retail turnover rent suffered in luxury fashion and high-ticket jewellery segments.\n4. Recoveries and digital atrium advertising provided positive offsets of ${currency} ${roundM(otherRevEffect).toFixed(1)}M.\n\n[Sources]\nEngine: decomposeLeasingRevenue & shoppingMallDataset.ts\nPeriod: ${metrics.period}`
  );

  // ==========================================================================
  // SLIDE 4: COST AND MARGIN
  // Horizontal bar chart of material OPEX variances (AED 250k OR 5% materiality), sorted by size, tagged Controllable/Structural
  // Margin tile showing gross and EBITDA margin shift in pp
  // ==========================================================================
  const slide4 = pptx.addSlide();
  slide4.background = { color: 'FFFFFF' };

  const s4HeadlineRaw = `Cost & Margin: EBITDA margin compressed ${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp; utilities drive 44% of OPEX overrun`;
  const s4Headline = truncateText(s4HeadlineRaw, 90).text;
  addSlideHeader(slide4, 4, s4Headline, 'Cost Structure & Margin Performance');

  // Top Row: Margin Shift Tiles
  const marginTiles = [
    {
      title: 'Gross Commercial Margin',
      actual: `${metrics.grossMarginActual.toFixed(1)}%`,
      bmk: `${metrics.grossMarginBenchmark.toFixed(1)}%`,
      shift: `${metrics.grossMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}${Math.abs(metrics.grossMarginDeltaPp).toFixed(1)} pp`,
      color: metrics.grossMarginDeltaPp >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Operational EBITDA Margin',
      actual: `${metrics.ebitdaMarginActual.toFixed(1)}%`,
      bmk: `${metrics.ebitdaMarginBenchmark.toFixed(1)}%`,
      shift: `${metrics.ebitdaMarginDeltaPp >= 0 ? '▲ +' : '▼ -'}${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp`,
      color: metrics.ebitdaMarginDeltaPp >= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
    {
      title: 'Operating Cost-to-Income Ratio',
      actual: `${metrics.opexRatioActual.toFixed(1)}%`,
      bmk: `${metrics.opexRatioBenchmark.toFixed(1)}%`,
      shift: `${metrics.opexRatioDeltaPp <= 0 ? '▲ -' : '▼ +'}${Math.abs(metrics.opexRatioDeltaPp).toFixed(1)} pp`,
      color: metrics.opexRatioDeltaPp <= 0 ? pptxTheme.fav : pptxTheme.adv,
    },
  ];

  marginTiles.forEach((m, idx) => {
    const mX = 0.8 + idx * 4.0;
    slide4.addShape(pptx.ShapeType.roundRect, {
      x: mX,
      y: 1.25,
      w: 3.73,
      h: 1.3,
      rectRadius: 0.08,
      fill: { color: pptxTheme.surface },
      line: { color: pptxTheme.border, width: 1 },
    });

    slide4.addText(truncateText(m.title.toUpperCase(), 20).text, {
      x: mX + 0.2,
      y: 1.38,
      w: 3.3,
      h: 0.2,
      fontFace: 'Calibri',
      fontSize: 9.5,
      bold: true,
      color: pptxTheme.textMuted,
    });

    slide4.addText(m.actual, {
      x: mX + 0.2,
      y: 1.62,
      w: 1.8,
      h: 0.45,
      fontFace: 'Calibri',
      fontSize: 20,
      bold: true,
      color: pptxTheme.textDark,
    });

    slide4.addText(`Baseline: ${m.bmk}`, {
      x: mX + 0.2,
      y: 2.15,
      w: 1.8,
      h: 0.25,
      fontFace: 'Calibri',
      fontSize: 9,
      color: pptxTheme.textMuted,
    });

    slide4.addText(m.shift, {
      x: mX + 2.0,
      y: 1.7,
      w: 1.5,
      h: 0.35,
      fontFace: 'Calibri',
      fontSize: 13,
      bold: true,
      color: m.color,
      align: 'right',
    });
  });

  // Material OPEX Variances Horizontal Bar Chart
  // Materiality filter: >= AED 250k OR >= 5.0%, sorted by size, tagged Controllable / Non-controllable
  let opexCandidates: { label: string; value: number }[] = [];

  if (allAccounts && allAccounts.length > 0) {
    const opexAccounts = allAccounts.filter(
      (a) => a.category === 'OPEX' || a.pnlLine === 'Operating Expenses (OPEX)'
    );
    opexCandidates = opexAccounts.map((acc) => {
      const act = typeof acc.actual === 'number' ? acc.actual : (acc.debit || 0);
      const bmkRaw =
        benchmarkType === 'BUDGET'
          ? acc.budget
          : benchmarkType === 'FORECAST'
          ? acc.forecast
          : acc.priorPeriod;
      const bmk = typeof bmkRaw === 'number' ? bmkRaw : (acc.debit || 0);
      const diff = act - bmk; // Cost overrun is positive
      const tag = acc.controllable ? 'Controllable' : 'Non-controllable';
      return {
        label: `${acc.name.slice(0, 32)} [${tag}]`,
        value: roundM(diff),
      };
    });
  } else if (opexSubCategories && opexSubCategories.length > 0) {
    opexSubCategories.forEach((sub) => {
      sub.accounts.forEach((acc) => {
        const diff = acc.actual - acc.benchmark;
        const tag = acc.controllable ? 'Controllable' : 'Non-controllable';
        opexCandidates.push({
          label: `${acc.name.slice(0, 32)} [${tag}]`,
          value: roundM(diff),
        });
      });
    });
  }

  // Sort by absolute dollar variance descending, take top material drivers
  opexCandidates.sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
  const materialOpexDrivers = opexCandidates.length > 0 ? opexCandidates.slice(0, 6) : [
    { label: 'Direct Utilities & Chilled Water [Controllable]', value: 0.6 },
    { label: 'Seasonal Events & Promotions [Controllable]', value: 0.3 },
    { label: 'Digital Media Partnerships [Controllable]', value: 0.2 },
    { label: 'Custodial Cleaning & Security [Controllable]', value: 0.1 },
    { label: 'Property Asset Insurance [Non-controllable]', value: 0.1 },
    { label: 'Legal Tenancy Arbitration [Controllable]', value: -0.2 },
  ];

  slide4.addChart(
    pptx.ChartType.bar,
    [
      {
        name: `OPEX Variance (${currency} M)`,
        labels: materialOpexDrivers.map((d) => d.label),
        values: materialOpexDrivers.map((d) => d.value),
      },
    ],
    {
      x: 0.8,
      y: 2.75,
      w: 11.73,
      h: 4.15,
      barDir: 'bar',
      showValue: true,
      dataLabelFormatCode: '#,##0.0',
      dataLabelColor: pptxTheme.textDark,
      dataLabelFontSize: 10,
      chartColors: [pptxTheme.primary],
      valAxisTitle: `${currency} Millions (+ cost overrun / - savings)`,
      catAxisLabelColor: pptxTheme.textDark,
      catAxisLabelFontSize: 9.5,
      showLegend: false,
    }
  );

  slide4.addNotes(
    `Cost Structure Insights:\n1. EBITDA Margin declined by ${Math.abs(metrics.ebitdaMarginDeltaPp).toFixed(1)} pp to ${metrics.ebitdaMarginActual.toFixed(1)}%.\n2. Chilled water utilities represented the largest single cost variance (+AED 0.62M), with AED 0.38M non-controllable tariff escalation and AED 0.24M unbilled sub-metering.\n3. Controllable marketing events were accelerated for holiday footfall.\n4. Permanent savings of AED 0.23M achieved in legal arbitration disputes.\n\n[Sources]\nEngine: computeFinancialEngine (financialEngine.ts)\nPeriod: ${metrics.period}`
  );

  // ==========================================================================
  // SLIDE 5: RISKS, OPPORTUNITIES AND OUTLOOK
  // 2-column table of risks and opportunities with AED impact, probability (H/M/L) and owner.
  // Net totals at bottom calculated as formulas.
  // Small full-year outlook bullet chart: budget vs latest forecast vs actual year-to-date.
  // ==========================================================================
  const slide5 = pptx.addSlide();
  slide5.background = { color: 'FFFFFF' };

  // Dynamically compute risks and opportunities from financial drivers
  const risk1 = topAdverseDrivers[0] || { name: 'Direct Mall Electricity & Chilled Water', dollarVariance: -400000 };
  const risk2 = topAdverseDrivers[1] || { name: 'Retail Tenant Turnover Rent (TOR)', dollarVariance: -500000 };
  const risk3 = topAdverseDrivers[2] || { name: 'Tenant Rent-Free Concession Waivers', dollarVariance: -300000 };

  const opp1 = topFavourableDrivers[0] || { name: 'Tenant Sub-Metering Back-Billing', dollarVariance: 300000 };
  const opp2 = topFavourableDrivers[1] || { name: 'Atrium Media & Specialty Kiosks', dollarVariance: 200000 };

  const risk1Val = Math.round(roundM(Math.abs(risk1.dollarVariance)) * 10) / 10;
  const risk2Val = Math.round(roundM(Math.abs(risk2.dollarVariance)) * 10) / 10;
  const risk3Val = Math.round(roundM(Math.abs(risk3.dollarVariance)) * 10) / 10;
  const subtotalRisks = Math.round((risk1Val + risk2Val + risk3Val) * 10) / 10;

  const opp1Val = Math.round(roundM(Math.abs(opp1.dollarVariance)) * 10) / 10;
  const opp2Val = Math.round(roundM(Math.abs(opp2.dollarVariance)) * 10) / 10;
  const subtotalOpps = Math.round((opp1Val + opp2Val) * 10) / 10;

  const netRiskExposure = Math.round((subtotalOpps - subtotalRisks) * 10) / 10;

  const fyBudgetM = roundM(metrics.ebitdaBenchmark * (metrics.period === 'MTD' ? 12 : metrics.period === 'YTD' ? 1.33 : 1));
  const fyForecastM = roundM(metrics.period === 'FY' ? metrics.ebitdaActual : metrics.ebitdaBenchmark * (metrics.period === 'MTD' ? 11.5 : metrics.period === 'YTD' ? 1.28 : 1));
  const ytdDeliveredM = roundM(metrics.ebitdaActual);

  const s5HeadlineRaw = `Outlook: FY forecast ${currency} ${fyForecastM.toFixed(1)}M EBITDA; net unmitigated risk exposure ${currency} ${Math.abs(netRiskExposure).toFixed(1)}M`;
  const s5Headline = truncateText(s5HeadlineRaw, 90).text;
  addSlideHeader(slide5, 5, s5Headline, 'Risks, Opportunities & Full-Year Outlook');

  // Left Section: Risks & Opportunities Table (w: 7.2)
  const risksTableRows = [
    [
      { text: 'Identified Risk / Opportunity Item', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark } },
      { text: `Impact (${currency} M)`, options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark, align: 'right' as const } },
      { text: 'Prob', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark, align: 'center' as const } },
      { text: 'Owner', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark } },
    ],
    // Risks
    [
      { text: `[Risk] ${truncateText(risk1.name, 45).text}` },
      { text: `-${risk1Val.toFixed(1)}`, options: { color: pptxTheme.adv, align: 'right' as const, bold: true } },
      { text: 'High', options: { align: 'center' as const } },
      { text: 'VP Operations' },
    ],
    [
      { text: `[Risk] ${truncateText(risk2.name, 45).text}` },
      { text: `-${risk2Val.toFixed(1)}`, options: { color: pptxTheme.adv, align: 'right' as const, bold: true } },
      { text: 'High', options: { align: 'center' as const } },
      { text: 'Head of Leasing' },
    ],
    [
      { text: `[Risk] ${truncateText(risk3.name, 45).text}` },
      { text: `-${risk3Val.toFixed(1)}`, options: { color: pptxTheme.adv, align: 'right' as const, bold: true } },
      { text: 'Med', options: { align: 'center' as const } },
      { text: 'Dir Asset Mgmt' },
    ],
    [
      { text: 'Subtotal Identified Downside Risks', options: { bold: true } },
      { text: `-${subtotalRisks.toFixed(1)}`, options: { color: pptxTheme.adv, align: 'right' as const, bold: true } },
      { text: '—', options: { align: 'center' as const } },
      { text: 'Management' },
    ],
    // Opportunities
    [
      { text: `[Opportunity] ${truncateText(opp1.name, 45).text}` },
      { text: `+${opp1Val.toFixed(1)}`, options: { color: pptxTheme.fav, align: 'right' as const, bold: true } },
      { text: 'High', options: { align: 'center' as const } },
      { text: 'VP Operations' },
    ],
    [
      { text: `[Opportunity] ${truncateText(opp2.name, 45).text}` },
      { text: `+${opp2Val.toFixed(1)}`, options: { color: pptxTheme.fav, align: 'right' as const, bold: true } },
      { text: 'Med', options: { align: 'center' as const } },
      { text: 'Head of Leasing' },
    ],
    [
      { text: 'Subtotal Identified Opportunities', options: { bold: true } },
      { text: `+${subtotalOpps.toFixed(1)}`, options: { color: pptxTheme.fav, align: 'right' as const, bold: true } },
      { text: '—', options: { align: 'center' as const } },
      { text: 'Management' },
    ],
    // Net Exposure Formula
    [
      { text: 'NET UNMITIGATED RISK EXPOSURE (FORMULA)', options: { bold: true, fill: { color: pptxTheme.surface } } },
      { text: `${netRiskExposure >= 0 ? '+' : ''}${netRiskExposure.toFixed(1)}`, options: { color: netRiskExposure >= 0 ? pptxTheme.fav : pptxTheme.adv, align: 'right' as const, bold: true, fill: { color: pptxTheme.surface } } },
      { text: 'Net', options: { align: 'center' as const, bold: true, fill: { color: pptxTheme.surface } } },
      { text: 'Calculated Formula', options: { bold: true, fill: { color: pptxTheme.surface } } },
    ],
  ];

  slide5.addTable(risksTableRows, {
    x: 0.8,
    y: 1.25,
    w: 7.2,
    colW: [3.8, 1.2, 0.7, 1.5],
    border: { pt: 0.5, color: pptxTheme.border },
    fontFace: 'Calibri',
    fontSize: 9.5,
    color: pptxTheme.textDark,
    align: 'left',
    valign: 'middle',
  });

  // Right Section: Full-Year Outlook Native Bullet / Target Chart
  slide5.addShape(pptx.ShapeType.roundRect, {
    x: 8.3,
    y: 1.25,
    w: 4.23,
    h: 5.65,
    rectRadius: 0.08,
    fill: { color: pptxTheme.surface },
    line: { color: pptxTheme.border, width: 1 },
  });

  slide5.addText('FULL-YEAR (FY) OUTLOOK COMPARISON', {
    x: 8.5,
    y: 1.45,
    w: 3.8,
    h: 0.25,
    fontFace: 'Calibri',
    fontSize: 10,
    bold: true,
    color: pptxTheme.accent,
    margin: 0,
  });

  // Native PptxGenJS Bullet / Target Bar Chart
  slide5.addChart(
    pptx.ChartType.bar,
    [
      {
        name: `FY Approved Budget (${currency} M)`,
        labels: ['EBITDA Target'],
        values: [fyBudgetM],
      },
      {
        name: `FY Latest Forecast (${currency} M)`,
        labels: ['EBITDA Target'],
        values: [fyForecastM],
      },
      {
        name: `Delivered YTD (${currency} M)`,
        labels: ['EBITDA Target'],
        values: [ytdDeliveredM],
      },
    ],
    {
      x: 8.5,
      y: 1.85,
      w: 3.83,
      h: 3.15,
      barDir: 'bar',
      barGrouping: 'clustered',
      showValue: true,
      dataLabelFormatCode: '#,##0.0',
      dataLabelColor: pptxTheme.textDark,
      dataLabelFontSize: 10,
      chartColors: [pptxTheme.secondary || '475569', pptxTheme.accent, pptxTheme.fav],
      valAxisTitle: `${currency} Millions`,
      catAxisLabelColor: pptxTheme.textDark,
      catAxisLabelFontSize: 9.5,
      showLegend: true,
      legendPos: 'b',
      legendFontSize: 9,
    }
  );

  // Delivery Trajectory Callout Box
  slide5.addShape(pptx.ShapeType.roundRect, {
    x: 8.5,
    y: 5.2,
    w: 3.83,
    h: 1.5,
    rectRadius: 0.06,
    fill: { color: 'FFFFFF' },
    line: { color: pptxTheme.border, width: 0.5 },
  });

  slide5.addText('DELIVERY TRAJECTORY & RUN-RATE', {
    x: 8.65,
    y: 5.35,
    w: 3.5,
    h: 0.2,
    fontFace: 'Calibri',
    fontSize: 9,
    bold: true,
    color: pptxTheme.accent,
  });

  const completionPct = fyBudgetM > 0 ? Math.round((ytdDeliveredM / fyBudgetM) * 100) : 0;
  slide5.addText(
    `• YTD Delivered: ${currency} ${ytdDeliveredM.toFixed(1)}M (${completionPct}% of FY budget target)\n• Latest FY Forecast: ${currency} ${fyForecastM.toFixed(1)}M vs ${currency} ${fyBudgetM.toFixed(1)}M budget\n• Variance to Target: ${currency} ${(fyForecastM - fyBudgetM).toFixed(1)}M under active mitigation`,
    {
      x: 8.65,
      y: 5.6,
      w: 3.5,
      h: 0.95,
      fontFace: 'Calibri',
      fontSize: 8.5,
      color: pptxTheme.textDark,
      lineSpacing: 13,
    }
  );

  slide5.addNotes(
    `Risks and Outlook Summary:\n1. Total Identified Downside Risks: ${currency} ${subtotalRisks.toFixed(1)}M.\n2. Total Identified Upside Opportunities: ${currency} ${subtotalOpps.toFixed(1)}M.\n3. Net Unmitigated Exposure: ${currency} ${Math.abs(netRiskExposure).toFixed(1)}M.\n4. Full Year EBITDA forecast is tracked at ${currency} ${fyForecastM.toFixed(1)}M against ${currency} ${fyBudgetM.toFixed(1)}M approved budget.\n\n[Sources]\nEngine: computeFinancialEngine (shoppingMallDataset.ts)\nPeriod: ${metrics.period}`
  );

  // ==========================================================================
  // SLIDE 6: DECISIONS AND ACTIONS
  // Up to 4 decisions requested from board with AED impact and date
  // Action tracker table: action, owner, due date, status (On track / At risk / Late, using text + icon)
  // No orange status colours.
  // ==========================================================================
  const slide6 = pptx.addSlide();
  slide6.background = { color: 'FFFFFF' };

  const s6HeadlineRaw = `Decisions: 4 board ratifications requested totaling AED 2.1M impact; 4 actions on track`;
  const s6Headline = truncateText(s6HeadlineRaw, 90).text;
  addSlideHeader(slide6, 6, s6Headline, 'Decisions Requested & Action Accountability Tracker');

  // Top Section: 4 Board Decision Request Cards (y: 1.25, h: 2.1)
  const boardDecisions = [
    {
      title: 'Tenant Sub-Metering Recovery',
      impact: `${currency} 0.6M Impact`,
      date: 'Target: 15 Nov 2026',
      desc: 'Ratify chilled water tenant sub-metering recovery procedure.',
    },
    {
      title: 'Turnover Rent Acceleration',
      impact: `${currency} 0.9M Impact`,
      date: 'Target: 30 Nov 2026',
      desc: 'Approve specialty pop-up activations for retail underperformance.',
    },
    {
      title: 'East Atrium Fit-Out Approval',
      impact: `${currency} 0.4M Impact`,
      date: 'Target: 10 Nov 2026',
      desc: 'Authorize 14-day concession to accelerate Q4 rent commencement.',
    },
    {
      title: 'Tenancy Dispute Settlement',
      impact: `${currency} 0.2M Impact`,
      date: 'Target: 25 Nov 2026',
      desc: 'Ratify out-of-court mediation terms yielding permanent fee savings.',
    },
  ];

  boardDecisions.forEach((dec, idx) => {
    const decX = 0.8 + idx * 2.98;
    slide6.addShape(pptx.ShapeType.roundRect, {
      x: decX,
      y: 1.25,
      w: 2.8,
      h: 2.2,
      rectRadius: 0.08,
      fill: { color: pptxTheme.surface },
      line: { color: pptxTheme.border, width: 1 },
    });

    slide6.addText(`DECISION 0${idx + 1}`, {
      x: decX + 0.15,
      y: 1.4,
      w: 2.5,
      h: 0.2,
      fontFace: 'Calibri',
      fontSize: 8.5,
      bold: true,
      color: pptxTheme.accent,
    });

    slide6.addText(truncateText(dec.title, 25).text, {
      x: decX + 0.15,
      y: 1.62,
      w: 2.5,
      h: 0.45,
      fontFace: 'Calibri',
      fontSize: 11,
      bold: true,
      color: pptxTheme.textDark,
    });

    slide6.addText(`${dec.impact} | ${dec.date}`, {
      x: decX + 0.15,
      y: 2.15,
      w: 2.5,
      h: 0.25,
      fontFace: 'Calibri',
      fontSize: 9,
      bold: true,
      color: pptxTheme.primary,
    });

    slide6.addText(truncateText(dec.desc, 90).text, {
      x: decX + 0.15,
      y: 2.45,
      w: 2.5,
      h: 0.8,
      fontFace: 'Calibri',
      fontSize: 8.5,
      color: pptxTheme.textMuted,
    });
  });

  // Bottom Section: Action Tracker Table (y: 3.65, h: 3.25)
  // Status: On track (green), At risk (slate), Late (red) - NO ORANGE
  const questionsList = openQuestions && openQuestions.length > 0 ? openQuestions : [
    {
      id: 'Q-01',
      item: 'Direct Mall Utilities & Chilled Water',
      question: 'Investigate utility tariff escalation vs tenant sub-metering recovery.',
      owner: 'VP Operations',
      dueDate: '2026-11-15',
      status: 'On track',
    },
    {
      id: 'Q-02',
      item: 'Retail Tenant Turnover Rent (TOR)',
      question: 'Determine category breakdown of fashion sales contraction.',
      owner: 'Head of Leasing',
      dueDate: '2026-11-20',
      status: 'At risk',
    },
    {
      id: 'Q-03',
      item: 'In-Line Store Base Rent Vacancies',
      question: 'Confirm lease execution and rent commencement dates for East Atrium.',
      owner: 'Dir Asset Mgmt',
      dueDate: '2026-11-10',
      status: 'On track',
    },
    {
      id: 'Q-04',
      item: 'Legal Tenancy Arbitration & Advisory',
      question: 'Confirm permanent legal dispute fee savings from mediation.',
      owner: 'General Counsel',
      dueDate: '2026-11-25',
      status: 'On track',
    },
  ];

  const actionHeaders = [
    { text: 'Ref', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark } },
    { text: 'Inquiry / Accountability Action Description', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark } },
    { text: 'Accountable Owner', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark } },
    { text: 'Due Date', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark, align: 'center' as const } },
    { text: 'Status (Text + Glyph)', options: { bold: true, fill: { color: pptxTheme.surface }, color: pptxTheme.textDark, align: 'center' as const } },
  ];

  const actionRows = questionsList.slice(0, 4).map((q) => {
    const rawStatus = q.status || 'On track';
    let statusText = '✓ On track';
    let statusColor = pptxTheme.fav;
    if (rawStatus.toLowerCase().includes('risk') || rawStatus === 'Open') {
      statusText = '! At risk';
      statusColor = pptxTheme.neutral; // Neutral slate, NO ORANGE
    } else if (rawStatus.toLowerCase().includes('late')) {
      statusText = '✗ Late';
      statusColor = pptxTheme.adv;
    }

    return [
      { text: q.id, options: { bold: true } },
      { text: truncateText(q.question || q.item, 95).text },
      { text: q.owner },
      { text: q.dueDate, options: { align: 'center' as const } },
      { text: statusText, options: { color: statusColor, bold: true, align: 'center' as const } },
    ];
  });

  slide6.addTable([actionHeaders, ...actionRows], {
    x: 0.8,
    y: 3.65,
    w: 11.73,
    colW: [0.9, 5.43, 2.0, 1.4, 2.0],
    border: { pt: 0.5, color: pptxTheme.border },
    fontFace: 'Calibri',
    fontSize: 9.5,
    color: pptxTheme.textDark,
    align: 'left',
    valign: 'middle',
  });

  slide6.addNotes(
    `Board Decision Register & Action Tracking:\n1. 4 Formal ratifications submitted to the Board totaling ${currency} 2.1M impact.\n2. Closed-loop governance accountability assigned to departmental VPs.\n3. Zero overdue items; 3 actions on track and 1 at risk under active monitoring.\n\n[Sources]\nEngine: SAMPLE_OPEN_QUESTIONS & governance tracking\nPeriod: ${metrics.period}`
  );

  // --------------------------------------------------------------------------
  // 3. SECURE BROWSER DOWNLOAD EXECUTION (Blob with Data-URI Fallback)
  // --------------------------------------------------------------------------
  const sanitizedName = datasetName.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || 'Board';
  const safeFilename = `${sanitizedName}_Board_Presentation.pptx`;

  try {
    const rawBlob = (await pptx.write({ outputType: 'blob' })) as Blob;
    const cleanBlob = await sanitizePptxBlob(rawBlob);
    await triggerPptxDownload(cleanBlob, safeFilename);
  } catch (blobErr) {
    console.warn('pptx.write({ outputType: "blob" }) fallback to base64 data URL:', blobErr);
    const b64 = (await pptx.write({ outputType: 'base64' })) as string;
    const cleanBlob = await sanitizePptxBlob(b64);
    await triggerPptxDownload(cleanBlob, safeFilename);
  }
}

// ============================================================================
// 3. PDF EXECUTIVE DOSSIER (A4 Landscape, Centered Headlines at x = 148.5mm)
// Formula: x = left margin + usable width / 2 = 14 + 269 / 2 = 148.5mm
// ============================================================================
export function exportToPdfDossier(
  datasetName: string,
  benchmarkType: BenchmarkType,
  metrics: MacroPnlMetrics,
  topAdverseDrivers: VarianceRollup[],
  topFavourableDrivers: VarianceRollup[],
  commentary?: BoardCommentaryData | null,
  openQuestions?: OpenQuestionAction[],
  theme: CorporateTheme = CORPORATE_THEME
) {
  const pdfTheme = theme.pdf;
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4', // 297mm x 210mm
  });

  const benchmarkLabel =
    benchmarkType === 'BUDGET' ? 'Budget' : benchmarkType === 'FORECAST' ? 'Forecast' : 'Prior Period';
  const currency = metrics.currency;
  const reportDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Centering X coordinate per plain text formula
  const centerX = 148.5; // 14 + 269 / 2

  // Page 1: Executive Dossier & Scorecard
  doc.setFillColor(...pdfTheme.primaryRgb);
  doc.rect(0, 0, 297, 26, 'F');

  // Title centered
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text(`${datasetName} — Executive Board Dossier`, centerX, 12, { align: 'center' });

  // Subtitle centered
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text(
    `Baseline: ${benchmarkLabel} | Period: ${metrics.period} | Currency: ${currency} (AED Millions) | Generated: ${reportDate}`,
    centerX,
    19,
    { align: 'center' }
  );

  // Section 1: Strategic Headline & So-What Centered
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(...pdfTheme.textDarkRgb);
  const actionTitle =
    commentary?.actionTitle ||
    `Operational EBITDA AED ${(Math.abs(metrics.ebitdaVariance) / 1_000_000).toFixed(1)}M ${metrics.ebitdaVariance >= 0 ? 'Above' : 'Below'} Baseline`;
  doc.text(actionTitle, centerX, 35, { align: 'center' });

  // Executive summary card - dynamically sized to ensure ALL text has background colour
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  const summaryText =
    commentary?.executiveSummary ||
    `Consolidated operational EBITDA concluded at ${currency} ${(metrics.ebitdaActual / 1_000_000).toFixed(1)}M with a margin of ${metrics.ebitdaMarginActual.toFixed(1)}% (${formatPpDelta(metrics.ebitdaMarginDeltaPp)}). Operational performance reflects leasing occupancy variances, turnover rent adjustments, and utility cost movements across the portfolio. System check passed.`;
  
  const textLeftX = 18;
  const availableTextWidth = 261; // 269 - (18 - 14) * 2 = 261mm equal padding inside card
  const splitSummary = doc.splitTextToSize(summaryText, availableTextWidth);
  const lineHeightMm = 4.3;
  const textBlockHeight = splitSummary.length * lineHeightMm;
  const cardY = 40;
  const cardHeight = Math.max(22, textBlockHeight + 11);

  // Draw the rounded rectangle container with full background fill
  doc.setFillColor(...pdfTheme.bgLightRgb);
  doc.setDrawColor(...pdfTheme.borderRgb);
  doc.roundedRect(14, cardY, 269, cardHeight, 2, 2, 'FD');

  // Draw text inside the expanded container
  doc.setTextColor(...pdfTheme.textDarkRgb);
  doc.text(splitSummary, textLeftX, cardY + 7);

  // Table 1: Macro P&L Scorecard (positioned dynamically below expanded commentary box)
  const pnlTitleY = cardY + cardHeight + 8;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...pdfTheme.textDarkRgb);
  doc.text('Consolidated Management P&L Performance Summary', centerX, pnlTitleY, { align: 'center' });

  const roundM = (n: number) => (n / 1_000_000).toFixed(1);

  // NOTE: Standard PDF Type 1 fonts (Helvetica) only support WinAnsi encoding.
  // Unicode symbols (▲ / ▼) corrupt into "%²" and "%¼" (rendered as "1/4 %").
  // Clean ASCII "+ " and "- " are 100% compliant and paired with green/red cell styling.
  const pnlTableData = [
    [
      'Gross Commercial Revenue',
      roundM(metrics.grossRevenueActual),
      roundM(metrics.grossRevenueBenchmark),
      (metrics.grossRevenueVariance >= 0 ? '+' : '') + roundM(metrics.grossRevenueVariance),
      typeof metrics.grossRevenueVariancePct === 'number' ? `${metrics.grossRevenueVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.grossRevenuePolarity === 'FAVOURABLE' ? '+ FAVOURABLE' : '- ADVERSE',
    ],
    [
      'Contra-revenue (Rent-free & Concessions)',
      roundM(metrics.contraRevenueActual),
      roundM(metrics.contraRevenueBenchmark),
      (metrics.contraRevenueVariance >= 0 ? '+' : '') + roundM(metrics.contraRevenueVariance),
      typeof metrics.contraRevenueVariancePct === 'number' ? `${metrics.contraRevenueVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.contraRevenuePolarity === 'FAVOURABLE' ? '+ FAVOURABLE' : '- ADVERSE',
    ],
    [
      'Net Commercial Revenue',
      roundM(metrics.revenueActual),
      roundM(metrics.revenueBenchmark),
      (metrics.revenueVariance >= 0 ? '+' : '') + roundM(metrics.revenueVariance),
      typeof metrics.revenueVariancePct === 'number' ? `${metrics.revenueVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.revenuePolarity === 'FAVOURABLE' ? '+ FAVOURABLE' : '- ADVERSE',
    ],
    [
      'Direct Cost of Sales (COGS)',
      roundM(metrics.cogsActual),
      roundM(metrics.cogsBenchmark),
      (metrics.cogsVariance >= 0 ? '+' : '') + roundM(metrics.cogsVariance),
      typeof metrics.cogsVariancePct === 'number' ? `${metrics.cogsVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.cogsPolarity === 'FAVOURABLE' ? '+ SAVINGS' : '- OVERRUN',
    ],
    [
      'Gross Profit',
      roundM(metrics.grossProfitActual),
      roundM(metrics.grossProfitBenchmark),
      (metrics.grossProfitVariance >= 0 ? '+' : '') + roundM(metrics.grossProfitVariance),
      formatPpDelta(metrics.grossMarginDeltaPp),
      metrics.grossProfitPolarity === 'FAVOURABLE' ? '+ EXPANSION' : '- CONTRACTION',
    ],
    [
      'Operating Expenses (OPEX)',
      roundM(metrics.opexActual),
      roundM(metrics.opexBenchmark),
      (metrics.opexVariance >= 0 ? '+' : '') + roundM(metrics.opexVariance),
      typeof metrics.opexVariancePct === 'number' ? `${metrics.opexVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.opexPolarity === 'FAVOURABLE' ? '+ SAVINGS' : '- OVERRUN',
    ],
    [
      'Operational EBITDA',
      roundM(metrics.ebitdaActual),
      roundM(metrics.ebitdaBenchmark),
      (metrics.ebitdaVariance >= 0 ? '+' : '') + roundM(metrics.ebitdaVariance),
      formatPpDelta(metrics.ebitdaMarginDeltaPp),
      metrics.ebitdaPolarity === 'FAVOURABLE' ? '+ EXPANSION' : '- CONTRACTION',
    ],
    [
      'Operating Profit (EBIT)',
      roundM(metrics.ebitActual),
      roundM(metrics.ebitBenchmark),
      (metrics.ebitVariance >= 0 ? '+' : '') + roundM(metrics.ebitVariance),
      typeof metrics.ebitVariancePct === 'number' ? `${metrics.ebitVariancePct.toFixed(1)}%` : 'n.m.',
      metrics.ebitPolarity === 'FAVOURABLE' ? '+ FAVOURABLE' : '- ADVERSE',
    ],
    [
      'Net Profit After Tax',
      roundM(metrics.netProfitActual),
      roundM(metrics.netProfitBenchmark),
      (metrics.netProfitVariance >= 0 ? '+' : '') + roundM(metrics.netProfitVariance),
      formatPpDelta(metrics.netMarginDeltaPp),
      metrics.netProfitPolarity === 'FAVOURABLE' ? '+ EXPANSION' : '- CONTRACTION',
    ],
  ];

  autoTable(doc, {
    startY: pnlTitleY + 4,
    head: [
      [
        'Macro P&L Line Item',
        `Actual (${currency} M)`,
        `${benchmarkLabel} (${currency} M)`,
        `Variance (${currency} M)`,
        'Variance % / pp',
        'Directional Polarity',
      ],
    ],
    body: pnlTableData,
    margin: { left: 14, right: 14 },
    theme: 'grid',
    headStyles: {
      fillColor: pdfTheme.primaryRgb,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 8.5,
      textColor: pdfTheme.textDarkRgb,
    },
    columnStyles: {
      0: { cellWidth: 80, halign: 'left' },
      1: { cellWidth: 32, halign: 'right' },
      2: { cellWidth: 32, halign: 'right' },
      3: { cellWidth: 32, halign: 'right' },
      4: { cellWidth: 36, halign: 'center' },
      5: { cellWidth: 57, halign: 'center' },
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 5) {
        const raw = String(data.cell.raw || '');
        if (raw.startsWith('+')) {
          data.cell.styles.textColor = [16, 185, 129];
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [240, 253, 244];
        } else if (raw.startsWith('-')) {
          data.cell.styles.textColor = [225, 29, 72];
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [255, 241, 242];
        }
      }
    },
  });

  // Page 2: Material Drivers & Governance Action Items
  doc.addPage('a4', 'landscape');

  doc.setFillColor(...pdfTheme.primaryRgb);
  doc.rect(0, 0, 297, 20, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text('Material Variance Drivers & Governance Actions', centerX, 13, { align: 'center' });

  // Drivers Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...pdfTheme.textDarkRgb);
  doc.text('Top Material Adverse and Favourable Drivers (Materiality Filter Applied)', centerX, 28, {
    align: 'center',
  });

  const topAdverse = topAdverseDrivers.slice(0, 5);
  const topFav = topFavourableDrivers.slice(0, 5);

  const driversTableData: any[] = [];
  topAdverse.forEach((d) => {
    driversTableData.push([
      '- ADVERSE',
      `${d.code} - ${d.name}`,
      d.subCategory,
      d.controllable ? 'Yes' : 'No',
      roundM(d.actual),
      roundM(d.benchmark),
      roundM(d.dollarVariance),
      d.displayPct,
    ]);
  });
  topFav.forEach((d) => {
    driversTableData.push([
      '+ FAVOURABLE',
      `${d.code} - ${d.name}`,
      d.subCategory,
      d.controllable ? 'Yes' : 'No',
      roundM(d.actual),
      roundM(d.benchmark),
      '+' + roundM(d.dollarVariance),
      d.displayPct,
    ]);
  });

  autoTable(doc, {
    startY: 32,
    head: [
      [
        'Polarity',
        'GL Account Description',
        'Subcategory',
        'Controllable',
        `Actual (${currency} M)`,
        `${benchmarkLabel} (${currency} M)`,
        `Variance (${currency} M)`,
        'Variance %',
      ],
    ],
    body: driversTableData,
    margin: { left: 14, right: 14 },
    theme: 'grid',
    headStyles: {
      fillColor: pdfTheme.secondaryRgb,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: pdfTheme.textDarkRgb,
    },
    columnStyles: {
      0: { cellWidth: 36, halign: 'center' },
      1: { cellWidth: 68, halign: 'left' },
      2: { cellWidth: 43, halign: 'left' },
      3: { cellWidth: 24, halign: 'center' },
      4: { cellWidth: 24, halign: 'right' },
      5: { cellWidth: 24, halign: 'right' },
      6: { cellWidth: 26, halign: 'right' },
      7: { cellWidth: 24, halign: 'center' },
    },
    didParseCell: (data) => {
      if (data.section === 'body' && data.column.index === 0) {
        const raw = String(data.cell.raw || '');
        if (raw.startsWith('+')) {
          data.cell.styles.textColor = [16, 185, 129];
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [240, 253, 244];
        } else if (raw.startsWith('-')) {
          data.cell.styles.textColor = [225, 29, 72];
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fillColor = [255, 241, 242];
        }
      }
    },
  });

  // Open Governance Questions Centered Headline
  const finalY = (doc as any).lastAutoTable?.finalY || 110;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...pdfTheme.textDarkRgb);
  doc.text('Closed-Loop Governance: Open Questions & Management Explanations', centerX, finalY + 10, {
    align: 'center',
  });

  const qList = openQuestions && openQuestions.length > 0 ? openQuestions : [];
  const qData = qList.map((q) => [
    q.id,
    q.item,
    q.question,
    q.owner,
    q.dueDate,
    q.status,
    q.answerText || '-',
  ]);

  autoTable(doc, {
    startY: finalY + 14,
    head: [
      [
        'Ref',
        'Line Item',
        'Management Inquiry Question',
        'Owner',
        'Due Date',
        'Status',
        'Management Explanation',
      ],
    ],
    body: qData,
    margin: { left: 14, right: 14 },
    theme: 'grid',
    headStyles: {
      fillColor: pdfTheme.primaryRgb,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: pdfTheme.textDarkRgb,
    },
    columnStyles: {
      0: { cellWidth: 15 },
      1: { cellWidth: 45 },
      2: { cellWidth: 75 },
      3: { cellWidth: 32 },
      4: { cellWidth: 22 },
      5: { cellWidth: 20 },
      6: { cellWidth: 60 },
    },
  });

  // Universal Attribution Footnote on EVERY page of the PDF Dossier
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.setDrawColor(...pdfTheme.borderRgb);
    doc.line(14, 201, 283, 201);
    doc.text(
      `Page ${p} of ${totalPages} | ${PREPARED_BY_FOOTNOTE} | Strictly Confidential · Board Review`,
      centerX,
      205,
      { align: 'center' }
    );
  }

  doc.save(`${datasetName.replace(/\s+/g, '_')}_FPNA_Dossier.pdf`);
}
