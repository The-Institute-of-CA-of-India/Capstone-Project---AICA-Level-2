/**
 * FinAI Cache-Buster & Version Invalidation Engine
 * Prevents users from getting stuck on stale production bundles after deployments.
 */

const RELOAD_THROTTLE_MS = 15_000;
const SESSION_RELOAD_KEY = 'finai_last_chunk_reload_ts';
const SESSION_VERSION_KEY = 'finai_app_version';

export function getAppBuildInfo() {
  const buildId = typeof __APP_BUILD_ID__ !== 'undefined' ? __APP_BUILD_ID__ : 'dev';
  const buildTime = typeof __APP_BUILD_TIME__ !== 'undefined' ? __APP_BUILD_TIME__ : 'dev';
  return { buildId, buildTime };
}

function safeReload() {
  const now = Date.now();
  const lastReload = sessionStorage.getItem(SESSION_RELOAD_KEY);

  if (!lastReload || now - Number(lastReload) > RELOAD_THROTTLE_MS) {
    sessionStorage.setItem(SESSION_RELOAD_KEY, String(now));
    // Hard reload bypassing local browser HTTP cache
    window.location.reload();
  }
}

export function initCacheBuster() {
  const { buildId } = getAppBuildInfo();

  // Store active version in session
  if (buildId && buildId !== 'dev') {
    sessionStorage.setItem(SESSION_VERSION_KEY, buildId);
  }

  // 1. Vite official chunk preload error listener
  window.addEventListener('vite:preloadError', (event) => {
    console.warn('[FinAI CacheBuster] Stale chunk detected via vite:preloadError. Reloading latest bundle...', event);
    safeReload();
  });

  // 2. Global uncaught promise handler for dynamic import chunk failures
  window.addEventListener('unhandledrejection', (event) => {
    const errorMsg = event.reason?.message || (typeof event.reason === 'string' ? event.reason : '');
    const isChunkFailure =
      errorMsg.includes('Failed to fetch dynamically imported module') ||
      errorMsg.includes('Loading chunk') ||
      errorMsg.includes('error loading dynamically imported module') ||
      event.reason?.name === 'ChunkLoadError';

    if (isChunkFailure) {
      console.warn('[FinAI CacheBuster] Dynamic chunk fetch failed. Triggering fresh bundle load...', errorMsg);
      safeReload();
    }
  });

  // 3. Tab focus & visibility change version validator
  // When a user returns to an existing tab after a new deployment, check if server has updated
  let lastCheckedTs = Date.now();
  const checkServerVersion = async () => {
    const now = Date.now();
    // Only check at most once every 60 seconds
    if (now - lastCheckedTs < 60_000) return;
    lastCheckedTs = now;

    try {
      const res = await fetch(`/api/version?t=${now}`, {
        cache: 'no-store',
        headers: { 'Cache-Control': 'no-cache', Pragma: 'no-cache' },
      });
      if (!res.ok) return;
      const data = await res.json();
      const serverVersion = data?.version;

      if (serverVersion && serverVersion !== 'dev' && buildId !== 'dev' && serverVersion !== buildId) {
        console.info(`[FinAI CacheBuster] Newer version detected (${serverVersion} vs ${buildId}). Reloading...`);
        safeReload();
      }
    } catch {
      // Offline or network blip; ignore safely
    }
  };

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      checkServerVersion();
    }
  });

  window.addEventListener('focus', () => {
    checkServerVersion();
  });
}
