import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initCacheBuster } from './utils/versionCheck.ts';

initCacheBuster();

createRoot(document.getElementById('root')!).render(<App />);

