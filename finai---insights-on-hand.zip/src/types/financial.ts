/**
 * FinAI Institutional FP&A Suite - Financial Types & Contracts
 * Audience: UAE Retail / Mall Real Estate Business (AED, IFRS, Mall Operations)
 */

export type CurrencyCode = 'AED' | 'USD' | 'EUR' | 'GBP';
export type PeriodType = 'MTD' | 'YTD' | 'FY';
export type BenchmarkType = 'BUDGET' | 'FORECAST' | 'PRIOR_PERIOD';
export type FinancialPolarity = 'FAVOURABLE' | 'ADVERSE' | 'NEUTRAL';

/**
 * Account mapping tier hierarchy
 */
export type AccountTier =
  | 'REVENUE'
  | 'CONTRA_REVENUE'
  | 'COGS'
  | 'OPEX'
  | 'OTHER_INCOME'
  | 'BELOW_EBITDA'
  | 'BALANCE_SHEET';

export type AccountCategory = AccountTier;

/**
 * Formal P&L line classifications
 */
export type PnlLineType =
  | 'Gross Commercial Revenue'
  | 'Contra-revenue'
  | 'Cost of Sales (COGS)'
  | 'Operating Expenses (OPEX)'
  | 'Other Income'
  | 'Depreciation & Amortisation'
  | 'IFRS 16 Lease Effects'
  | 'Impairment'
  | 'FX Gains/Losses'
  | 'Finance Costs'
  | 'Tax'
  | 'Balance Sheet';

/**
 * Account Mapping definition (uploadable / editable)
 * Account code -> P&L line -> Tier -> Controllable Y/N -> Sign
 */
export interface AccountMapping {
  code: string;
  pnlLine: PnlLineType;
  tier: AccountTier;
  controllable: boolean;
  sign: 1 | -1; // 1 for normal, -1 for reverse sign
  subCategory?: string;
  name?: string;
}

export interface UnmappedAccountAlert {
  code: string;
  name: string;
  amount: number;
}

/**
 * Raw Financial Account in General Ledger / Trial Balance
 */
export interface FinancialAccount {
  code: string;
  name: string;
  category: AccountTier;
  pnlLine?: PnlLineType;
  subCategory: string;
  actual: number;
  budget: number;
  forecast: number;
  priorPeriod: number;
  debit?: number;
  credit?: number;
  isBalanceSheet: boolean;
  controllable?: boolean;
  notes?: string;
}

/**
 * Variance Rollup with safe percentage ('n.m.' when benchmark is 0 or sign flips)
 */
export interface VarianceRollup {
  code: string;
  name: string;
  category: AccountTier;
  pnlLine: PnlLineType;
  subCategory: string;
  actual: number;
  benchmark: number;
  dollarVariance: number;
  percentVariance: number | 'n.m.';
  displayPct: string;
  polarity: FinancialPolarity;
  driverContributionPct: number;
  controllable: boolean;
  isMaterial: boolean;
  isSubtotal?: boolean;
  isMacroTotal?: boolean;
}

export interface SubCategoryRollup {
  name: string;
  category: AccountTier;
  pnlLine: PnlLineType;
  actual: number;
  benchmark: number;
  dollarVariance: number;
  percentVariance: number | 'n.m.';
  displayPct: string;
  polarity: FinancialPolarity;
  accounts: VarianceRollup[];
  driverContributionPct: number;
  controllable: boolean;
}

/**
 * Macro P&L metrics with all required P&L lines
 * Calculate at full precision, round only for display
 */
export interface MacroPnlMetrics {
  currency: CurrencyCode;
  period: PeriodType;
  benchmarkType: BenchmarkType;

  // 1. Gross Revenue
  grossRevenueActual: number;
  grossRevenueBenchmark: number;
  grossRevenueVariance: number;
  grossRevenueVariancePct: number | 'n.m.';
  grossRevenuePolarity: FinancialPolarity;

  // 2. Contra-revenue (rent-free, tenant discounts, bad-debt provisions)
  contraRevenueActual: number;
  contraRevenueBenchmark: number;
  contraRevenueVariance: number;
  contraRevenueVariancePct: number | 'n.m.';
  contraRevenuePolarity: FinancialPolarity;

  // 3. Net Commercial Revenue (Gross - Contra)
  revenueActual: number;
  revenueBenchmark: number;
  revenueVariance: number;
  revenueVariancePct: number | 'n.m.';
  revenuePolarity: FinancialPolarity;

  // 4. Direct Cost of Sales (COGS)
  cogsActual: number;
  cogsBenchmark: number;
  cogsVariance: number;
  cogsVariancePct: number | 'n.m.';
  cogsPolarity: FinancialPolarity;

  // 5. Gross Profit & Margin
  grossProfitActual: number;
  grossProfitBenchmark: number;
  grossProfitVariance: number;
  grossProfitVariancePct: number | 'n.m.';
  grossProfitPolarity: FinancialPolarity;
  grossMarginActual: number;
  grossMarginBenchmark: number;
  grossMarginDeltaPp: number;

  // 6. OPEX (Operating Expenses)
  opexActual: number;
  opexBenchmark: number;
  opexVariance: number;
  opexVariancePct: number | 'n.m.';
  opexPolarity: FinancialPolarity;
  opexRatioActual: number;
  opexRatioBenchmark: number;
  opexRatioDeltaPp: number;

  // 7. Operational EBITDA
  ebitdaActual: number;
  ebitdaBenchmark: number;
  ebitdaVariance: number;
  ebitdaVariancePct: number | 'n.m.';
  ebitdaPolarity: FinancialPolarity;
  ebitdaMarginActual: number;
  ebitdaMarginBenchmark: number;
  ebitdaMarginDeltaPp: number;

  // 8. Other Income
  otherIncomeActual: number;
  otherIncomeBenchmark: number;
  otherIncomeVariance: number;

  // 9. Depreciation & Amortisation (Non-controllable cost)
  daActual: number;
  daBenchmark: number;
  daVariance: number;

  // 10. Operating Profit (EBIT)
  ebitActual: number;
  ebitBenchmark: number;
  ebitVariance: number;
  ebitVariancePct: number | 'n.m.';
  ebitPolarity: FinancialPolarity;

  // 11. IFRS 16 Lease Effects
  ifrs16Actual: number;
  ifrs16Benchmark: number;
  ifrs16Variance: number;

  // 12. Impairment Charges
  impairmentActual: number;
  impairmentBenchmark: number;
  impairmentVariance: number;

  // 13. FX Gains / Losses
  fxActual: number;
  fxBenchmark: number;
  fxVariance: number;

  // 14. Finance Costs (Non-controllable cost)
  financeCostsActual: number;
  financeCostsBenchmark: number;
  financeCostsVariance: number;

  // 15. Tax (UAE Corporate Tax, Non-controllable cost)
  taxActual: number;
  taxBenchmark: number;
  taxVariance: number;

  // 16. Net Profit After Tax
  netProfitActual: number;
  netProfitBenchmark: number;
  netProfitVariance: number;
  netProfitVariancePct: number | 'n.m.';
  netProfitPolarity: FinancialPolarity;
  netMarginActual: number;
  netMarginBenchmark: number;
  netMarginDeltaPp: number;

  // Rounding adjustment row if sum of rounded components != rounded total
  roundingAdjustmentDisplay: number;
  hasRoundingDifference: boolean;
}

/**
 * Balance Sheet validation tests:
 * Test 1: Total Debits - Total Credits = 0
 * Test 2: Net Profit (P&L) = Movement in Retained Earnings
 */
export interface BalanceSheetValidationCheck {
  debitCreditCheck: {
    totalDebits: number;
    totalCredits: number;
    difference: number;
    passed: boolean;
  };
  pnlTieOutCheck: {
    netProfitPnl: number;
    retainedEarningsDelta: number;
    difference: number;
    passed: boolean;
  };
  statusText: 'System check passed' | 'System check failed';
  assetDebitSum: number;
  liabilityCreditSum: number;
  equityCreditSum: number;
  totalExcludedAccounts: number;
  sampleExcludedAccounts: { code: string; name: string; amount: number; classType: string }[];
}

/**
 * Materiality filter settings (user editable)
 */
export interface MaterialityFilter {
  aedThreshold: number; // default 250,000 AED
  pctThreshold: number; // default 5.0%
}

/**
 * Leasing Drivers & Variance Decomposition
 * Optional driver upload for UAE retail / mall business
 */
export interface LeasingDriverData {
  occupancyPctActual: number;      // e.g. 94.2%
  occupancyPctBenchmark: number;   // e.g. 96.0%
  glaSqmActual: number;            // Gross Leasable Area e.g. 125,000 sqm
  glaSqmBenchmark: number;
  tenantSalesActual: number;       // AED
  tenantSalesBenchmark: number;
  salesPerSqmActual: number;       // AED/sqm
  salesPerSqmBenchmark: number;
  baseRentActual: number;          // AED
  baseRentBenchmark: number;
  torActual: number;               // Turnover Rent AED
  torBenchmark: number;
}

export interface LeasingRevenueDecomposition {
  hasDrivers: boolean;
  occupancyEffect: number;         // Delta due to vacant / occupied GLA
  rateEffect: number;              // Delta due to base rent rate / sqm
  torEffect: number;               // Delta due to tenant retail sales turnover rent
  totalRevenueVariance: number;
  reconciliationDelta: number;     // Must be exactly 0
}

/**
 * Open Questions & Actions tracker
 * Closed-loop governance: unexplained variance -> question -> owner -> due date -> answer -> reused
 */
export interface OpenQuestionAction {
  id: string;
  item: string;
  question: string;
  owner: string;
  dueDate: string;
  status: 'Open' | 'Answered' | 'Closed';
  answerText?: string;
  isManagementExplanation?: boolean;
}

/**
 * What changed since last month (comparison against prior saved run)
 */
export interface PriorRunComparison {
  hasPriorRun: boolean;
  priorPeriodLabel?: string;
  newItems: {
    name: string;
    code: string;
    dollarVariance: number;
    polarity: FinancialPolarity;
  }[];
  resolvedItems: {
    name: string;
    code: string;
    priorVariance: number;
  }[];
  worseningItems: {
    name: string;
    code: string;
    priorVariance: number;
    currentVariance: number;
    changeDelta: number;
  }[];
}

/**
 * Board Commentary Data
 */
export interface BoardCommentaryData {
  source: 'AI' | 'Rule-based';
  sourceLabel: string;
  sourceReason?: string;
  actionTitle: string; // Action headline stating conclusion with a number <= 90 chars
  executiveSummary: string;
  strategicHighlights: string[];
  directlySupportedDeductions: {
    driver: string;
    impactAmount: string;
    driverContributionPct?: number;
    polarity: string;
    mathematicalProof: string;
  }[];
  operationalHypotheses: {
    lineItem: string;
    inquiryQuestion: string;
    dataRequiredToConfirm: string;
    recommendedManagementAction?: string;
    department?: string;
  }[];
  dataLimitations: string[];
  boardActionItems: string[];
  openQuestions?: OpenQuestionAction[];
  leasingDecomposition?: LeasingRevenueDecomposition;
  priorRunComparison?: PriorRunComparison;
}
