# FinAI Institutional FP&A Suite — System Architecture, Financial Logic & Formatting Specification

> **Document Purpose**: Complete, audit-grade architectural specification of the FinAI Institutional FP&A platform, encompassing financial control logic, GAAP/IFRS accounting rules, mathematical reconciliation formulas, data structures, UI layouts, and export engine mechanics (Excel `.xlsx`, PowerPoint `.pptx`, and PDF Dossier). Prepared for independent technical and financial peer review.

---

## 1. Core Operating Constitution & Precedence Rules

### 1.1 The Priority Order of Precedence
When an apparent discrepancy occurs across layers, the platform enforces a strict, immutable resolution hierarchy:
$$\mathbf{Source\ Financial\ Data} \succ \mathbf{Accounting\ Logic} \succ \mathbf{Narrative\ Analysis} \succ \mathbf{Visual\ Presentation}$$

1. **Source Financial Data**: Raw Trial Balance debit and credit postings are the immutable ground truth.
2. **Accounting Logic**: Strict GAAP / IFRS classification rules, double-entry balance constraints, and sign conventions govern aggregation.
3. **Narrative Analysis**: Commentary is restricted to directly supported mathematical deductions.
4. **Visual Presentation**: Presentation formats (charts, tables, deck slides) must conform to underlying data; numbers are never rounded, truncated, or forced to fit a visual box.

### 1.2 Anti-Hallucination & Semantic Evidence Boundary
- **Directly Supported Deductions**: Observations verifiable strictly by arithmetic within the dataset (e.g., *"In-Line Base Rent shortfall of $340,000 drove 54.2% of the commercial revenue deficit"*).
- **Operational Hypotheses (Unanswered Root Causes)**: If the Trial Balance cannot explain *why* a variance occurred (e.g., whether an electricity overrun was driven by weather degree-days or tariff escalation), **the engine is strictly forbidden from inventing a cause**. It must present the financial fact and convert the root cause into a precise management question with specified audit evidence required to verify.
- **Commentary Minimization Principle**: The objective is not to maximize prose volume. The objective is to produce the minimum necessary commentary to explain the financial variance accurately and drive decisive management action.

---

## 2. General Ledger Classification & Financial Control Logic

### 2.1 Balance Sheet Quarantine & Exclusion (1000s–3000s)
In accordance with GAAP/IFRS, Balance Sheet accounts must **never** leak into operational P&L or OPEX calculations.

| Account Range | Classification | Normal Balance | Treatment | Audit Gate |
| :--- | :--- | :---: | :--- | :--- |
| **1000–1999** | Assets (Cash, AR, Fixed Assets) | Debit | Isolated from P&L | Excluded from OPEX / EBITDA |
| **2000–2999** | Liabilities (AP, Debt, Accruals) | Credit | Isolated from P&L | Excluded from OPEX / EBITDA |
| **3000–3999** | Equity (Retained Earnings, Capital) | Credit | Isolated from P&L | Excluded from OPEX / EBITDA |

**Balance Sheet Net Verification Formula**:
$$\Delta_{\text{BS}} = \sum \text{Debit}_{\text{Assets (1000s)}} - \left( \sum \text{Credit}_{\text{Liabilities (2000s)}} + \sum \text{Credit}_{\text{Equity (3000s)}} \right) = \$0.00$$

### 2.2 Operational P&L Accounts (4000s–9000s)
All P&L accounts are classified into five mutually exclusive tiers:

| Tier | Account Range | Name | Polarity Rule | Reporting Destination |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1** | `4000–4999` | Gross Commercial Revenue | Actual > Benchmark = Favourable (🟢) | Gross Revenue |
| **Tier 2** | `5000–5999` | Cost of Direct Services (COGS) | Actual > Benchmark = Adverse (🔴) | COGS / Direct Costs |
| **Tier 3** | `6000–7999` | Total Operating Expenses (OPEX) | Actual > Benchmark = Adverse (🔴) | Operating Expenditures |
| **Tier 4** | `8000–8999` | Depreciation & Amortization | Neutral (Non-cash allocation) | Below EBITDA / Above EBIT |
| **Tier 5** | `9000–9999` | Net Financing Costs & Taxes | Neutral (Statutory / Capital structure)| Below EBIT / Above Net Profit |

### 2.3 Contextual Financial Polarity Evaluation
Financial polarity is evaluated contextually, not by pure mathematical sign:
```typescript
export function evaluatePolarity(
  category: AccountCategory | 'PROFIT' | 'MARGIN',
  actual: number,
  benchmark: number
): FinancialPolarity {
  const delta = actual - benchmark;
  if (Math.abs(delta) < 0.001) return 'NEUTRAL';

  // Revenue, Gross Profit, EBITDA, Net Profit: Higher is Favourable
  if (category === 'REVENUE' || category === 'PROFIT' || category === 'MARGIN') {
    return delta > 0 ? 'FAVOURABLE' : 'ADVERSE';
  }

  // Cost of Sales & Operating Expenses (OPEX): Lower is Favourable
  return delta > 0 ? 'ADVERSE' : 'FAVOURABLE';
}
```

### 2.4 Margin Shift Convention (Percentage Points)
Margin movements are **strictly expressed in percentage points (`pp`) with 1 decimal place**, never as a percentage:
$$\Delta\text{Margin (pp)} = \text{Actual Margin \%} - \text{Benchmark Margin \%}$$
*Example*: Gross margin shifting from $70.3\%$ to $69.0\%$ is recorded as **`-1.3 pp`**, not `-1.85%`.

---

## 3. Mathematical Hierarchy & Closed Waterfall Reconciliation

### 3.1 P&L Core Mathematical Hierarchy
```
1. Gross Revenue             = Σ (Accounts 4000s)
2. Cost of Direct Services   = Σ (Accounts 5000s)
3. Gross Profit              = Gross Revenue - Cost of Direct Services
4. Gross Margin %            = (Gross Profit / Gross Revenue) × 100
5. Total Operating Expenses  = Σ (Accounts 6000s–7999)
6. OPEX-to-Revenue Ratio %   = (Total OPEX / Gross Revenue) × 100
7. Operational EBITDA        = Gross Profit - Total Operating Expenses
8. EBITDA Margin %           = (Operational EBITDA / Gross Revenue) × 100
9. Depreciation & Amort.     = Σ (Accounts 8000s)
10. Operating Profit (EBIT)  = Operational EBITDA - Depreciation & Amortization
11. Financing Costs & Tax    = Σ (Accounts 9000s)
12. Net Profit After Tax     = Operating Profit (EBIT) - Financing Costs & Tax
13. Net Margin %             = (Net Profit After Tax / Gross Revenue) × 100
```

### 3.2 Closed Waterfall Walk (Benchmark to Actual EBITDA)
Every component of the EBITDA variance walk reconciles with zero mathematical leakage:
$$\text{Actual EBITDA} = \text{Benchmark EBITDA} + \Delta\text{Revenue} - \Delta\text{COGS} - \Delta\text{OPEX}$$
$$\text{Reconciliation Check: } \Delta_{\text{Walk}} = \left| \text{Actual EBITDA} - \left( \text{Benchmark EBITDA} + \Delta\text{Revenue} - \Delta\text{COGS} - \Delta\text{OPEX} \right) \right| = \$0.00$$

Where:
- $\Delta\text{Revenue} = \text{Actual Revenue} - \text{Benchmark Revenue}$ ($+$ is accretive)
- $\Delta\text{COGS} = \text{Actual COGS} - \text{Benchmark COGS}$ (Cost overrun is dilutive)
- $\Delta\text{OPEX} = \text{Actual OPEX} - \text{Benchmark OPEX}$ (Cost overrun is dilutive)

---

## 4. Institutional Excel Workpaper Specification (`.xlsx`)

### 4.1 Engine & Configuration
- **Library**: `exceljs` (pure OpenXML engine).
- **Gridline Governance**: `views: [{ showGridLines: false }]` configured on **every** worksheet. Default Excel gray guidelines are suppressed; borders define table boundaries.
- **Text Wrapping Discipline**: `wrapText: false` strictly enforced across all cells. Every line item and account title renders on a single, continuous, professional row.
- **Standard Number Format**:
  $$\texttt{\_(* \#,\#\#0\_);\_(* (\#,\#\#0);\_(* "-"??\_);\_(@\_)}$$
  - Positive numbers: formatted with thousands separators and positive spacing (` 1,250,000 `).
  - Negative numbers: enclosed in standard accounting parentheses (` (320,000) `).
  - Zero balances: formatted as a dash (` - `).
- **Percentages**: `0.0%` with standard 1-decimal-place precision.
- **Margin Deltas**: `+0.0\ \p\p;-0.0\ \p\p;0.0\ \p\p`.

### 4.2 Excel Color Palette (ARGB Hex)
- **Primary Header Banner**: H Orange `FFFF6600` (Text: Bold White `FFFFFFFF`, 12pt).
- **Table Column Headers**: Deep Ébène `FF161311` (Text: Bold White `FFFFFFFF`, 10pt, medium border `FF3B2F2A`).
- **Section Dividers**: Warm Anthracite `FF2E2622` (Text: Gold `FFD4AF37`, 10pt bold).
- **Subtotal & Total Rows (Gross Profit, EBITDA, Net Profit)**: Soft Gold Cream `FFFEF3C7` (Text: Bold Dark `FF161311`, top border `thin`, bottom border **`double`**).
- **Favourable Polarity Cells**: Soft Mint `FFDCFCE7` (Text: Bold Green `FF15803D`).
- **Adverse Polarity Cells**: Soft Rose `FFFEE2E2` (Text: Bold Red `FFB91C1C`).
- **Alternating Data Rows**: Subtle warm off-white `FFFAF8F5` and pure white `FFFFFFFF`.
- **Standard Cell Grid Borders**: Subtle warm gray `FFE5E0D8` (thin).

### 4.3 Sheet-by-Sheet Workpaper Architecture
1. **Sheet 1: `Executive P&L`**
   - Widths: Line Item: 44, Actual: 22, Benchmark: 22, Variance: 22, Var %/pp: 18, Polarity: 18.
   - Rows: Title Banner (Row 1), Metadata Block (Rows 2–5), Table Header (Row 7), Macro Line Items (Rows 8–23).
   - Double-underline bottom border on Gross Profit, Operational EBITDA, and Net Profit After Tax.
2. **Sheet 2: `Detailed P&L Rollups`**
   - Widths: Code: 16, Name: 50, Classification: 24, Actual: 20, Benchmark: 20, Variance: 20, Var %: 16, Contrib %: 18, Polarity: 16.
   - Hierarchical rollups: Revenue Categories $\rightarrow$ Direct COGS $\rightarrow$ OPEX $\rightarrow$ Below EBITDA.
   - Subtotals highlighted in Gold Cream with double underline.
3. **Sheet 3: `BS Exclusion Audit`**
   - Widths: Code: 16, Name: 50, Classification: 24, Balance: 26, Inclusion Status: 36.
   - Audit assurance banner (Green `FF10B981`) certifying 100% isolation of 1000s, 2000s, and 3000s.
4. **Sheet 4: `Board Commentary`**
   - Widths: Topic: 36, Narrative: 70, Required Audit Trail: 40, Recommended Action: 50.
   - Structured register of Executive Briefing, Grounded Deductions, CFO Inquiry Register, and Board Directives.

---

## 5. PowerPoint Presentation Specification (`.pptx`)

### 5.1 Presentation Framework
- **Aspect Ratio**: 16:9 Widescreen (`13.33" × 7.5"`).
- **Margins**: 0.8" left/right, printable width `11.73"`.
- **Engine**: `PptxGenJS`.
- **Typography**: Calibri (standard cross-platform rendering).
- **Palette**: Deep Ébène (`#161311`), Card Surface (`#211C19`), Border (`#382E28`), H Orange (`#FF6600`), Gold (`#D4AF37`), Green (`#10B981`), Red (`#EF4444`), Ivoire (`#F8F6F1`), Gris Perle (`#C9C4BC`).

### 5.2 10-Slide FP&A Storytelling Deck Architecture
1. **Slide 1 — Title & Executive Governance Context**:
   - Mandate header, 38pt bold title, 4 metadata cards (Entity, Baseline, Period, BS Isolation), Gold audit assurance seal.
2. **Slide 2 — Executive Synthesis & "The So What?" (CFO 30-Second Elevator Pitch)**:
   - Full-width bold takeaway banner; 3 strategic pillars:
     1. *Top-Line Revenue Velocity* (Volume vs. Rate)
     2. *Direct Cost Absorption & Gross Margin Defense*
     3. *Overhead Discipline & EBITDA Conversion*
3. **Slide 3 — Macro Performance Scorecard & Metric Walk**:
   - 4 large KPI stat cards (Actual, Baseline, Variance dollar badge, Margin pp shift badge).
   - Audited macro P&L table with zebra shading, highlighted totals, and directional polarity indicators.
4. **Slide 4 — Revenue-to-EBITDA Variance Bridge (The Core FP&A Waterfall)**:
   - 5 sequential visual waterfall cards: `Baseline EBITDA` $\rightarrow$ `Revenue Impact` $\rightarrow$ `Direct COGS Variance` $\rightarrow$ `OPEX Overheads` $\rightarrow$ `Delivered EBITDA`.
   - Directional connector flow arrows (`→`), green accretive and red dilutive indicators.
5. **Slide 5 — Key Strategic Highlights & Critical Observations**:
   - 2×3 grid of spacious cards with numbered pill badges (`01`–`06`), vertical centering, responsive text wrapping (`wrap: true, shrinkText: true`), and zero rigid line-spacing conflicts.
6. **Slide 6 — Key Variance Drivers Deep-Dive (Adverse vs. Favourable)**:
   - Side-by-side comparative layout: Left column Adverse (Red), Right column Favourable (Green).
   - Dedicated card heights (`1.45"`) with independent account name (`0.52"`) and contribution subtext (`0.36"`) containers.
7. **Slide 7 — Directly Supported Deductions & Mathematical Evidence**:
   - 4 horizontal audit-verified deduction cards with polarity badges, driver title, impact amount, and arithmetic proof string.
8. **Slide 8 — CFO Governance & Operational Inquiry Register**:
   - Structured table mapping line item, root cause hypothesis, required documentary proof, and recommended management action.
9. **Slide 9 — CFO & Board Governance Directives**:
   - 4 priority directives for the upcoming quarter with milestone targets and governance tags.
10. **Slide 10 — Appendix: Balance Sheet Segregation & Audit Certification**:
    - 3 verification cards for Assets (1000s), Liabilities (2000s), and Equity (3000s) with statutory compliance certification.

---

## 6. PDF Executive Board Dossier Specification

### 6.1 Layout & Geometry
- **Format**: A4 Landscape (`297mm × 210mm`).
- **Printable Area**: Left margin: 14mm, Right margin: 14mm $\rightarrow$ **269mm usable width**.
- **Engine**: `jsPDF` + `jspdf-autotable`.
- **Top Accent Line**: H Orange stripe across the full 297mm width.
- **Centered Table Headlines**: Every section header, table title, and box title is mathematically centered across the 269mm printable area at:
  $$x_{\text{center}} = 14 + \frac{269}{2} = 148.5\text{ mm}, \quad \text{align: 'center'}$$

### 6.2 3-Page Document Structure
1. **Page 1: Executive Cover & Macro Financial Performance**:
   - Centered document title and metadata subtitle.
   - Executive Briefing box (269mm wide) with centered title.
   - 4 Key KPI Scorecard tiles across width (63.5mm width each, 5mm gap).
   - Centered Headline: `MACRO FINANCIAL SCORECARD & AUDITED P&L BREAKDOWN`.
   - Full 269mm Macro P&L table with calibrated column widths (89mm line item, 36mm per numerical column).
2. **Page 2: Key Variance Drivers & Grounded Deductions**:
   - Centered Page Title.
   - Strategic Highlights box (269mm wide) with centered title.
   - Centered Headline: `TOP ADVERSE DRIVERS (Cost Overruns & Revenue Shortfalls)`.
   - Top Adverse Drivers Table (269mm width, calibrated 8-column layout).
   - Centered Headline: `TOP FAVOURABLE DRIVERS (Revenue Expansion & Cost Savings)`.
   - Top Favourable Drivers Table (269mm width).
   - Centered Headline: `DIRECTLY SUPPORTED MATHEMATICAL DEDUCTIONS (AUDIT-VERIFIED EVIDENCE)`.
   - Grounded Deductions Table (269mm width).
3. **Page 3: Operational Inquiries, Balance Sheet Proof & Directives**:
   - Centered Page Title.
   - Centered Headline: `CFO OPERATIONAL INQUIRY REGISTER (UNCONFIRMED HYPOTHESES)`.
   - Operational Inquiry Table (269mm width).
   - Balance Sheet Isolation Audit Proof Box (269mm wide, green border) with centered title.
   - Centered Headline: `CFO & AUDIT COMMITTEE BOARD DIRECTIVES`.
   - 4 numbered priority directive cards across 269mm width.

---

## 7. Web Application Component Hierarchy & State Flow

```
src/
├── App.tsx                        // Root orchestrator: state, theme, tabs, export handlers
├── types/
│   └── financial.ts               // TypeScript interfaces: FinancialAccount, MacroPnlMetrics, etc.
├── utils/
│   ├── financialEngine.ts         // Deterministic computation engine, polarity, BS audit, waterfall
│   ├── exportEngine.ts            // ExcelJS (.xlsx), PptxGenJS (.pptx), jsPDF (landscape PDF)
│   └── trialBalanceParser.ts      // CSV/XLSX parser: debit/credit auto-detection, sign normalization
├── components/
│   ├── TopNav.tsx                 // Header brand, dataset title, theme toggle, export quick-actions
│   ├── ExecutiveControlBar.tsx    // Benchmark baseline switcher (Budget/Forecast/Prior), dataset actions
│   ├── KpiScorecard.tsx           // 4 primary metric cards with 1 decimal place pp deltas
│   ├── WaterfallBridge.tsx        // Interactive SVG waterfall walk (Revenue to EBITDA)
│   ├── PnlRollupTable.tsx         // Collapsible GAAP P&L table with search, category totals, drill-down
│   ├── BoardCommentaryView.tsx    // Certified Financial Control Gate, Executive Synthesis, Inquiry Register
│   ├── SlideDeckPreviewModal.tsx  // High-fidelity interactive 16:9 presentation preview modal
│   ├── BalanceSheetAuditView.tsx  // 1000s–3000s segregation proof, debit/credit audit register
│   ├── UploadModal.tsx            // TB upload modal with live column mapping and sign preview
│   └── AccountDetailModal.tsx     // Single-account variance breakdown and inquiry drill-down
└── server.ts                      // Express + Vite, Gemini API commentary endpoint + deterministic fallback
```

### 7.1 Server API & Fallback Resilience
- **Route `/api/commentary`**: Calls Gemini (`gemini-3.8-flash`) with structured JSON schema enforcing anti-hallucination and precedence rules.
- **Zero-Failure Fallback**: If the Gemini API key is missing, network fails, or the free-tier quota is exhausted (HTTP 429), the server seamlessly transitions to the built-in deterministic institutional commentary engine (`buildDeterministicBoardCommentary`). The client never crashes and never presents an error screen.

---

## 8. Summary of Solved Architectural Deficiencies

| Layer | Previous Defect | Engineered Resolution |
| :--- | :--- | :--- |
| **Excel Export** | Gridlines visible; text wrapped across cells making rows uneven. | Migrated to `exceljs`; configured `views: [{ showGridLines: false }]` to completely hide gridlines; enforced `wrapText: false` on all cells for clean single-line rows; applied standard accounting number format `_(* #,##0_);_(* (#,##0);_(* "-"??_);_(@_)` and CPA double underlines. |
| **PowerPoint Export**| Overlapping text boxes on Slide 4; rigid line-spacing; cramped layouts. | Re-architected into 10-slide FP&A storytelling presentation with 16:9 widescreen layout; expanded card bounds; auto-fitting text containers (`wrap: true, shrinkText: true`); added visual waterfall bridge. |
| **PDF Dossier** | Portrait orientation causing data to be cut off; left-aligned headers. | Converted to A4 Landscape (`297mm × 210mm`) with 269mm usable width; centered all section and table headlines (`x = 148.5mm`); proportional column widths ensuring zero text truncation. |
| **Data Integrity** | Potential Balance Sheet leakage into OPEX. | Automated quarantine of accounts 1000s–3000s; verified mathematical reconciliation delta of $0.00. |
| **Commentary** | Risk of AI speculating on unestablished root causes. | Semantic Truth Gate: factual reporting of variances; unanswered root causes converted into targeted CFO inquiry questions. |
