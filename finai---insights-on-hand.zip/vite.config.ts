import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { defineConfig } from 'vite';

const BUILD_TIME = new Date().toISOString();
const BUILD_ID = process.env.BUILD_ID || `v-${Date.now().toString(36)}`;

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'finai-version-manifest',
        writeBundle(options) {
          const outDir = options.dir || path.resolve(import.meta.dirname, 'dist');
          if (!fs.existsSync(outDir)) {
            fs.mkdirSync(outDir, { recursive: true });
          }
          fs.writeFileSync(
            path.resolve(outDir, 'version.json'),
            JSON.stringify(
              {
                version: BUILD_ID,
                buildTime: BUILD_TIME,
              },
              null,
              2
            )
          );
        },
      },
    ],
    define: {
      __APP_BUILD_TIME__: JSON.stringify(BUILD_TIME),
      __APP_BUILD_ID__: JSON.stringify(BUILD_ID),
    },
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    build: {
      emptyOutDir: true,
      rollupOptions: {
        output: {
          entryFileNames: 'assets/[name]-[hash].js',
          chunkFileNames: 'assets/[name]-[hash].js',
          assetFileNames: 'assets/[name]-[hash].[ext]',
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
