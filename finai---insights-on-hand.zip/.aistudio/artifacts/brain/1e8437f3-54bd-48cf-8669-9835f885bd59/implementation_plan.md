# FinAI — Institutional FP&A Board Commentary & Trial Balance Engine

FinAI is an executive-grade financial analysis platform engineered for Chief Financial Officers (CFOs) and institutional FP&A Directors. It ingests verified Corporate Trial Balances, General Ledgers, and Management P&L datasets to deliver auditable, mathematically reconciled variance bridges, waterfall storytelling, and board-ready commentary with strict anti-hallucination boundaries.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and user experience choices have been aligned based on your clarifying answers and institutional FP&A standards:

- **Confirmed Comparison Baseline**: Multi-column Trial Balance structure supporting **Actual vs. Budget**, **Actual vs. Forecast**, and **Actual vs. Prior Period (YoY/PoP)** with dynamic benchmark switching.
- **Confirmed Presentation Mode**: **Institutional Executive Deck** featuring board-level waterfall variance bridges, category contribution infographics, and mathematically grounded commentary sections.
- **Confirmed Default Dataset**: **Metropolitan Mall Properties Group (Commercial Real Estate & Shopping Malls)** featuring tenant base rents, percentage turnover rents, common area maintenance (CAM), facilities operations, property taxes, anchor tenant dynamics, and strict chart-of-accounts hierarchy.
- **Strict Financial Polarity Engine**: Revenue/Margin expansions are marked Favourable (🟢), while Cost/OPEX overruns are strictly Adverse (🔴), and all margin differentials are expressed in percentage points (`pp`), never `%`.
- **Anti-Hallucination Evidence Governance**: Commentary strictly bifurcates into **"Directly Supported"** (verifiable arithmetic rollups and driver % contributions) and **"Hypothesis / Unconfirmed"** (operational inquiries flagged for CFO management inquiry).
- **Executive Deliverables**: Real-time interactive generation and download in **PPTX (Board Presentation Slides)**, **PDF (Executive Memo / Print-Ready Board Dossier)**, and **Excel (.xlsx Multi-Tab Auditable Financial Model with Variance Formats)**.

---

### 1. Overview & Core Concept

- **What It Does**: FinAI automates the transition from raw, noisy Trial Balance data (GL accounts 1000–9000) to an audit-ready, boardroom-worthy FP&A narrative. It filters Balance Sheet accounts (1000s–3000s), organizes P&L lines (4000s–9000s) into standard GAAP/IFRS tiers, isolates variance drivers via mathematical sensitivity analysis, and renders board slides, executive memo summaries, interactive waterfall charts, and multi-format exports.
- **Target Audience**: Chief Financial Officers, VP/Directors of FP&A, Institutional Finance Committees, Board Audit Chairs, and Financial Controllers.
- **Key Value**: Eliminates manual spreadsheet commentary errors, enforces mathematical integrity across rollup hierarchies, prevents narrative hallucination, and compresses days of board deck preparation into seconds.

---

### 2. User Experience & Visual Design

FinAI follows the **Universal Frontend Design Constitution** and **Enterprise SaaS & Dashboard Guidelines**, utilizing a crisp, authoritative institutional aesthetic (slate canvas, tabular typography, zero-pill discipline, hairline dividers, and single-elevation depth).

#### Visual Identity & Theme Tokens
- **Canvas & Surfaces**: Dominant clean canvas (`#0F172A` deep navy slate / `#F8FAFC` crisp off-white light mode toggleable; default high-contrast institutional dark slate `#0B0F19` with structural surfaces `#111827` and border `#1F2937`).
- **Accent & Polarity Budget**: 
  - Favourable variance: Emerald Green (`#10B981` / `#059669`)
  - Adverse variance: Crimson Red (`#EF4444` / `#DC2626`)
  - Benchmark neutral / Primary Brand: Institutional Indigo/Cobalt (`#3B82F6` / `#2563EB`)
- **Typography & Tabular Discipline**:
  - Display & Headings: `Plus Jakarta Sans` / `Outfit` (clean geometric authority, `text-wrap: balance`).
  - Body & Financial Labels: `Public Sans` / `DM Sans` (clean 13px–15px readability).
  - Numbers, Rates, Variances & Rollups: Strictly `font-mono tabular-nums` (`IBM Plex Mono` / `JetBrains Mono`) for decimal alignment.
  - Zero-pill metadata: All status tags, periods, entity names, and currency codes rendered with unboxed typographic separators (`·`, `/`).

#### Key User Flows & Viewport Architecture
1. **Header & Top Bar Contract**:
   - Single-element Brand Wordmark: `FinAI Institutional FP&A`
   - Navigation links: `Executive Summary` · `P&L Rollup & Audit` · `Variance Waterfall` · `Board Commentary` · `Export Center`
   - Primary Action: `Upload Trial Balance` button & `Load Shopping Malls Demo` preset trigger.
2. **TB Ingestion & Data Sanitation Rail**:
   - Drag-and-drop CSV / Excel parser with auto-column mapping (Account Code, Account Name, Actual, Budget, Forecast, Prior Period).
   - Instant Balance Sheet Filter Verification Log: Audits and proves total Asset (1000s), Liability (2000s), and Equity (3000s) lines excluded from P&L operations.
   - Reconciliation Status: Proves $\sum \text{Revenue} - \text{COGS} - \text{OPEX} = \text{EBITDA}$ rolls up with zero rounding discrepancy.
3. **Institutional Executive Dashboard & Storytelling**:
   - **Board KPI Strip**: Revenue, Gross Margin (with `pp` delta), OPEX Ratio, EBITDA, Net Operating Income (NOI), and Net Margin.
   - **Interactive Waterfall Variance Bridge**: Visualizing step-by-step walk from Budget/Prior to Actuals across Gross Margin drivers, Fixed Cost shifts, and G&A variances.
   - **Strict Polarity Variance Table**: Multi-level collapsible tree grid (Macro Level $\rightarrow$ Sub-category $\rightarrow$ Leaf Account) with absolute variance ($\$$) and relative variance ($\%$ or $\text{pp}$).
4. **Auditable Board Commentary Console**:
   - **Executive Memo**: 3-minute CFO briefing synthesized for the Board of Directors.
   - **Directly Supported Drivers**: Mathematically proven driver rankings (e.g. "Anchor Tenant Concession Discounts accounted for 42.1% of base revenue contraction").
   - **Hypothesis & Management Inquiry Registry**: Non-speculative operational questions for the upcoming controller/management meeting.
   - **AI Deep Inquiry**: Powered by server-side Gemini 3.8 Flash with strict system instructions prohibiting external hallucination and mandating numeric grounding.
5. **Boardroom Export Suite**:
   - **Executive Slide Deck (PPTX)**: Generated via client-side presentation builder with slide titles, bulleted evidence, KPI stat callouts, and clean styling.
   - **Print-Ready Board Dossier (PDF)**: Clean layout with page breaks, audit disclaimers, and header/footer metadata.
   - **Multi-Tab FP&A Model (Excel .xlsx)**: Formatted workpaper containing Summary P&L, Variance Bridge, Detailed Leaf Trial Balance, and Account Mapping.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Client-Side Excel/CSV Parsing & Model Reconciliation**
  - *Chosen Approach*: Execute Trial Balance parsing, standard chart-of-accounts mapping, and mathematical reconciliation directly in the browser using high-performance parsing libraries (`xlsx`, `papaparse`).
  - *Why*: Provides sub-second feedback on large trial balance sheets (up to thousands of rows), protects sensitive corporate financial data from unnecessary network hops, and guarantees instant zero-latency filtering.
- **Decision 2: Strict Dual-Engine Commentary (Deterministic Math + Grounded LLM)**
  - *Chosen Approach*: The primary variance numbers, driver rankings, and polarity flags are calculated via deterministic TypeScript financial algorithms. Gemini 3.8 Flash is invoked via server-side API (`/api/commentary`) solely to structure executive narrative tone while adhering to strict prompt boundaries that ban hallucinated causes.
  - *Why*: CFOs and audit committees require 100% mathematical verifiability; pure LLM calculations risk arithmetic drift.
- **Decision 3: Dedicated Commercial Real Estate (Shopping Malls) Preset**
  - *Chosen Approach*: Provide a rich, realistic trial balance for "Metropolitan Mall Properties Group" with 75+ accounts covering Base Rent, Tenant Turnovers, CAM Recoveries, Food Court & Kiosk licensing, Parking & Ancillary, Security, HVAC/Utilities, Asset Management fees, and Lease Commissions.
  - *Why*: Fulfills the user's specific request for shopping malls with authentic industry accounts and clear variance storylines (e.g., footfall-driven percentage rent headwinds offset by utility cost containment).

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        FinAI Executive Frontend                        │
├────────────────────────────────────────────────────────────────────────┤
│  Top Navigation (Brand Wordmark · Nav Anchors · Upload / Demo CTA)    │
├────────────────────────────────────────────────────────────────────────┤
│  Ingestion & Audit Engine:                                             │
│    • CSV / XLSX Parser & Schema Auto-Detector                         │
│    • Balance Sheet Isolator (1000s-3000s Excluded & Reconciled)       │
│    • P&L Tree Builder (4000s-9000s Clean Rollups, Zero Double-Count)  │
├────────────────────────────────────────────────────────────────────────┤
│  Financial Polarity & Variance Calculator:                             │
│    • Directional Impact Engine (Rev: Fav/Adv, Cost: Fav/Adv)           │
│    • Percentage Point ('pp') Margin Differential Logic                 │
│    • Driver Contribution Ranking (e.g. Account X drove Y% of variance) │
├──────────────────────────┬─────────────────────────────────────────────┤
│ Visual Infographics:     │ Board Narrative & Analysis:                 │
│  • P&L Waterfall Bridge  │  • Directly Supported Mathematical Facts    │
│  • Cost Rollup Breakdown │  • Unconfirmed Operational Hypotheses       │
│  • Polarity Heatmap Grid │  • Server-Side Gemini FP&A Commentary API   │
├──────────────────────────┴─────────────────────────────────────────────┤
│ Export Engine:                                                         │
│  • PPTX Generator (Board Presentation Slides)                          │
│  • PDF / Print Media Stylesheet (Dossier Layout)                       │
│  • Excel XLSX Workbook Generator (Tabbed FP&A Workpaper)               │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │ POST /api/commentary
                                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│               Express Server (Node.js / tsx runtime)                  │
├────────────────────────────────────────────────────────────────────────┤
│  @google/genai SDK (gemini-3.8-flash)                                  │
│  System Instructions: Strict GAAP/IFRS polarity, anti-hallucination,  │
│  no ungrounded external assumptions, auditable executive CFO tone      │
└────────────────────────────────────────────────────────────────────────┘
```

#### Financial Data Schema & Rollup Hierarchy
```typescript
interface FinancialAccount {
  code: string;               // e.g. "4110"
  name: string;               // e.g. "In-Line Specialty Tenant Base Rent"
  category: 'REVENUE' | 'COGS' | 'OPEX' | 'BELOW_EBITDA';
  subCategory: string;        // e.g. "Fixed Minimum Rent", "Facility Ops"
  actual: number;             // Period Actual
  budget: number;             // Annualized or Period Budget
  forecast: number;           // Latest Q3 Forecast
  priorPeriod: number;        // Prior Year Actual (Q3 PY)
  isBalanceSheet: boolean;    // true if code < 4000 (Assets/Liab/Equity)
}

interface VarianceRollup {
  account: FinancialAccount;
  dollarVariance: number;
  percentVariance: number;
  percentagePointsDelta?: number; // strictly for margin lines
  polarity: 'FAVOURABLE' | 'ADVERSE' | 'NEUTRAL';
  driverContributionPct: number;  // % contribution to total parent variance
}
```

---

### 5. Implementation Stages & Verification Plan

1. **Backend Server Setup**:
   - Create Express server (`server.ts`) hosting static Vite build and `/api/commentary` endpoint.
   - Configure `@google/genai` with `gemini-3.8-flash` and strict anti-hallucination system prompt.
   - Update `package.json` with necessary parsing & export libraries (`xlsx`, `pptxgenjs`, `jspdf`) and `"start": "node server.ts"`.
2. **Deterministic Financial Calculation Engine**:
   - Implement `financialEngine.ts`: Trial Balance validation, Balance Sheet 1000s–3000s filter with audit check, mathematical parent/child hierarchy rollup without double-counting, strict polarity logic, and driver contribution percentage math.
3. **Shopping Malls Institutional Dataset**:
   - Implement `shoppingMallDataset.ts`: Comprehensive Trial Balance for "Metropolitan Mall Properties Group" with realistic Q3 Actuals, Budget, Forecast, and Prior Period figures, complete with 1000s–3000s balance sheet accounts for verification.
4. **Executive Dashboard & Infographics**:
   - Build responsive layout with Top Bar Contract, Benchmark Switcher (Budget vs Forecast vs Prior Period), KPI Cards with `pp` badges, Interactive SVG/Canvas Waterfall Bridge, and Multi-Level Drilldown Table.
5. **Board Commentary & Anti-Hallucination Reviewer**:
   - Structured sections: Executive Briefing, Mathematically Supported Drivers, and CFO Operational Hypotheses Registry.
   - Interactive prompt tool allowing CFO to ask specific drill-down questions against the verified data.
6. **Multi-Format Export Suite**:
   - Instant 1-click downloads for PPTX, Excel XLSX (with tabs: Executive Summary, P&L Waterfall, and Detailed Trial Balance), and print-ready PDF preview.
7. **Build & Quality Verification**:
   - Run `compile_applet` and test edge cases (zero division in variance, missing prior periods, balance sheet separation).
