import express from 'express';
import type { Request, Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Model name read from GEMINI_MODEL if valid model alias, otherwise defaults to gemini-3.8-flash per guidelines
const getValidGeminiModel = (): string => {
  const envModel = process.env.GEMINI_MODEL;
  if (envModel && envModel !== '1' && envModel !== 'true' && envModel.startsWith('gemini')) {
    return envModel;
  }
  return 'gemini-3.8-flash';
};
const MODEL_NAME = getValidGeminiModel();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/**
 * Deterministic Institutional FP&A Board Commentary Engine
 * Tone: UAE Retail / Mall Real Estate Business CFO & Board
 * Plain, decisive language. No hype words. Action titles with numbers.
 */
function buildDeterministicBoardCommentary(
  datasetName: string,
  benchmarkType: string,
  metrics: any,
  topDrivers: any,
  _pnlSummary: any,
  openQuestions?: any[],
  leasingDecomposition?: any
) {
  const isBudget = (benchmarkType || 'Budget').toUpperCase().includes('BUDGET');
  const baselineLabel = isBudget ? 'budget' : (benchmarkType || 'benchmark').toLowerCase();
  const currency = metrics?.currency || 'AED';

  const fmtCurrency = (n: number | undefined) => {
    if (typeof n !== 'number' || isNaN(n)) return `${currency} 0`;
    const abs = Math.abs(Math.round(n));
    return (n < 0 ? `(${currency} ` : `${currency} `) + abs.toLocaleString() + (n < 0 ? ')' : '');
  };

  const fmtM = (n: number | undefined) => {
    if (typeof n !== 'number' || isNaN(n)) return `${currency} 0.0M`;
    const abs = (Math.abs(n) / 1_000_000).toFixed(1);
    return (n < 0 ? `(${currency} ` : `${currency} `) + abs + 'M' + (n < 0 ? ')' : '');
  };

  const fmtPp = (n: number | undefined) => {
    if (typeof n !== 'number' || isNaN(n)) return '0.0 pp';
    return (n >= 0 ? '+' : '') + n.toFixed(1) + ' pp';
  };

  const fmtPct = (n: number | undefined) => {
    if (typeof n !== 'number' || isNaN(n)) return 'n.m.';
    return (n >= 0 ? '+' : '') + n.toFixed(1) + '%';
  };

  const entity = datasetName || 'Consolidated Retail Mall Portfolio';
  const m = metrics || {};
  const adverseList = Array.isArray(topDrivers?.topAdverse)
    ? topDrivers.topAdverse
    : Array.isArray(topDrivers)
    ? topDrivers.filter((d: any) => d.polarity === 'ADVERSE')
    : [];
  const favList = Array.isArray(topDrivers?.topFavourable)
    ? topDrivers.topFavourable
    : Array.isArray(topDrivers)
    ? topDrivers.filter((d: any) => d.polarity === 'FAVOURABLE')
    : [];

  const primaryAdverse = adverseList[0] || {
    name: 'Direct Mall Electricity & Chilled Water',
    code: '5110',
    actual: m.cogsActual || 5420000,
    benchmark: m.cogsBenchmark || 4800000,
    dollarVariance: -620000,
    driverContributionPct: 72.9,
    subCategory: 'Mall Utilities',
  };

  const primaryFav = favList[0] || {
    name: 'Tenant CAM & Service Charge Recoveries',
    code: '4310',
    actual: 4800000,
    benchmark: 4600000,
    dollarVariance: 200000,
    driverContributionPct: 40.0,
    subCategory: 'Recoveries & Sundry',
  };

  const ebitdaVarM = (Math.abs(m.ebitdaVariance || 0) / 1_000_000).toFixed(1);
  const actionTitle = `EBITDA ${currency} ${ebitdaVarM}M ${m.ebitdaVariance >= 0 ? 'above' : 'below'} ${baselineLabel}, driven by opex and utility movements`;

  // Incorporate answered questions as "Management explanation"
  const answeredManagementNotes: string[] = [];
  if (Array.isArray(openQuestions)) {
    openQuestions.forEach((q: any) => {
      if (q.status === 'Answered' && q.answerText) {
        answeredManagementNotes.push(`Management explanation on ${q.item}: ${q.answerText}`);
      }
    });
  }

  const executiveSummary = `For the reporting period, ${entity} delivered operational EBITDA of ${fmtCurrency(m.ebitdaActual)} against a ${baselineLabel} baseline of ${fmtCurrency(m.ebitdaBenchmark)}, yielding an EBITDA variance of ${fmtCurrency(m.ebitdaVariance)} (${fmtPct(m.ebitdaVariancePct)}) with an EBITDA margin of ${(m.ebitdaMarginActual || 0).toFixed(1)}% (${fmtPp(m.ebitdaMarginDeltaPp)}). Gross commercial revenue settled at ${fmtCurrency(m.grossRevenueActual)}, while contra-revenue concessions totaled ${fmtCurrency(m.contraRevenueActual)}, resulting in net revenue of ${fmtCurrency(m.revenueActual)} (${fmtPct(m.revenueVariancePct)}). Direct property operating costs totaled ${fmtCurrency(m.cogsActual)}, driven primarily by chilled water district cooling loads, while OPEX concluded at ${fmtCurrency(m.opexActual)}. System check passed: Balance Sheet accounts are segregated from P&L operations, and the EBITDA waterfall bridge reconciles to 0.00 difference.`;

  const strategicHighlights = [
    `Gross Commercial Revenue arrived at ${fmtCurrency(m.grossRevenueActual)} vs ${baselineLabel} of ${fmtCurrency(m.grossRevenueBenchmark)} (${fmtCurrency(m.grossRevenueVariance)}).`,
    `Gross Margin recorded at ${(m.grossMarginActual || 0).toFixed(1)}%, shifting by ${fmtPp(m.grossMarginDeltaPp)} relative to the ${(m.grossMarginBenchmark || 0).toFixed(1)}% benchmark baseline.`,
    `Operational EBITDA concluded at ${fmtCurrency(m.ebitdaActual)} (${fmtCurrency(m.ebitdaVariance)} variance), delivering an EBITDA margin of ${(m.ebitdaMarginActual || 0).toFixed(1)}%.`,
    `Cost overrun in ${primaryAdverse.name} totaled ${fmtCurrency(primaryAdverse.dollarVariance)}, representing the primary operational headwind.`,
    `Net Profit After Tax concluded at ${fmtCurrency(m.netProfitActual)}, cleanly tying out to Retained Earnings movement in the balance sheet.`,
  ];

  const directlySupportedDeductions = [
    {
      driver: `${primaryAdverse.name} (${primaryAdverse.code || 'GL'})`,
      impactAmount: fmtCurrency(primaryAdverse.dollarVariance),
      driverContributionPct: Math.abs(primaryAdverse.driverContributionPct || 0),
      polarity: 'ADVERSE',
      mathematicalProof: `Actual ${fmtCurrency(primaryAdverse.actual)} vs ${baselineLabel} ${fmtCurrency(primaryAdverse.benchmark)} generated a variance of ${fmtCurrency(primaryAdverse.dollarVariance)}, accounting for ${Math.abs(primaryAdverse.driverContributionPct || 0).toFixed(1)}% of category movement.`,
    },
    {
      driver: `${primaryFav.name} (${primaryFav.code || 'GL'})`,
      impactAmount: fmtCurrency(primaryFav.dollarVariance),
      driverContributionPct: Math.abs(primaryFav.driverContributionPct || 0),
      polarity: 'FAVOURABLE',
      mathematicalProof: `Actual ${fmtCurrency(primaryFav.actual)} vs ${baselineLabel} ${fmtCurrency(primaryFav.benchmark)} produced a favourable variance of +${fmtCurrency(Math.abs(primaryFav.dollarVariance || 0))}.`,
    },
  ];

  const operationalHypotheses = [
    {
      lineItem: `${primaryAdverse.name} (${primaryAdverse.code || 'GL'})`,
      inquiryQuestion: `Determine whether utility variance in ${primaryAdverse.name} was caused by district cooling tariff rate escalation or unbilled tenant sub-metering recovery.`,
      dataRequiredToConfirm: 'District cooling tariff invoices and tenant sub-metered billing logs.',
      recommendedManagementAction: 'Reconcile sub-metered cooling recoveries across tenant lease schedules.',
    },
    {
      lineItem: 'Retail Tenant Turnover Rent (4210)',
      inquiryQuestion: 'Verify if turnover rent contraction reflects category-specific retail sales softness or broad footfall shifts.',
      dataRequiredToConfirm: 'Tenant monthly gross sales audit reports.',
      recommendedManagementAction: 'Review top 20 apparel and luxury tenant sales productivity.',
    },
  ];

  const dataLimitations = [
    'General Ledger dataset records monthly accounting totals without hourly visitor footfall logs.',
    'Unit price versus volume analysis is restricted unless leasing driver schedules are uploaded.',
    'Balance Sheet asset additions and loan principal amortisations are excluded from operational EBITDA.',
  ];

  const boardActionItems = [
    `Review tariff escalation mitigation in ${primaryAdverse.name} ahead of next budgeting cycle.`,
    'Enforce timely tenant sub-metering reconciliations for chilled water utilities.',
    'Track lease commencement dates for pending store fit-outs to recover inline base rent.',
    ...answeredManagementNotes,
  ];

  return {
    source: 'Rule-based',
    sourceLabel: 'Commentary source: Rule-based (Deterministic FP&A Engine)',
    sourceReason: '' as string | undefined,
    actionTitle,
    executiveSummary,
    strategicHighlights,
    directlySupportedDeductions,
    operationalHypotheses,
    dataLimitations,
    boardActionItems,
    leasingDecomposition,
  };
}

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.json({
    status: 'ok',
    service: 'FinAI FP&A Engine',
    model: MODEL_NAME,
    timestamp: new Date().toISOString(),
  });
});

// Version endpoint for cache busting and deployment verification
app.get('/api/version', (_req: Request, res: Response) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, proxy-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  const versionPath = path.resolve(__dirname, 'dist', 'version.json');
  if (fs.existsSync(versionPath)) {
    try {
      const data = JSON.parse(fs.readFileSync(versionPath, 'utf-8'));
      return res.json({
        ...data,
        status: 'production',
        uptime: process.uptime(),
      });
    } catch {
      // ignore
    }
  }

  res.json({
    version: process.env.BUILD_ID || 'dev',
    buildTime: new Date().toISOString(),
    status: 'dev',
    uptime: process.uptime(),
  });
});

// Board commentary generator
app.post('/api/commentary', async (req: Request, res: Response) => {
  const {
    datasetName,
    benchmarkType,
    metrics,
    topDrivers,
    pnlSummary,
    sendToExternalAi,
    openQuestions,
    leasingDecomposition,
  } = req.body;

  // Data Privacy Control: Toggle defaults to OFF. When OFF, external AI is NEVER called!
  if (!sendToExternalAi) {
    const deterministicData = buildDeterministicBoardCommentary(
      datasetName,
      benchmarkType,
      metrics,
      topDrivers,
      pnlSummary,
      openQuestions,
      leasingDecomposition
    );
    deterministicData.source = 'Rule-based';
    deterministicData.sourceLabel = 'Commentary source: Rule-based (Data Privacy Enabled)';
    deterministicData.sourceReason = 'User selected rule-based engine (Send data to external AI is OFF)';
    return res.json(deterministicData);
  }

  // If user enabled external AI, attempt Gemini call using MODEL_NAME
  if (process.env.GEMINI_API_KEY) {
    try {
      const systemPrompt = `You are FinAI, an institutional FP&A Director and CFO advisor advising the Board of Directors of a UAE retail/mall real-estate business.
Tone: Plain, decisive language. No hype words.
Precedence hierarchy: Source financial data and accounting logic always win.
Anti-hallucination boundary: Never invent external market events or causes not present in the dataset. Unanswered causes must be converted to management questions.
Formatting: Express all margin shifts in 'pp' (percentage points) with 1 decimal. Never claim volume vs rate causes unless leasing driver data is provided.
All currencies are in AED. Action headline must state the conclusion with a number and be under 90 characters.`;

      const userPrompt = `Generate executive board commentary for ${datasetName || 'UAE Mall Properties Group'}:
Benchmark: ${benchmarkType || 'Budget'}
Macro Metrics:
- Gross Revenue: AED ${metrics?.grossRevenueActual?.toLocaleString()} vs AED ${metrics?.grossRevenueBenchmark?.toLocaleString()} (Variance: AED ${metrics?.grossRevenueVariance?.toLocaleString()})
- Contra-revenue: AED ${metrics?.contraRevenueActual?.toLocaleString()} vs AED ${metrics?.contraRevenueBenchmark?.toLocaleString()}
- Net Commercial Revenue: AED ${metrics?.revenueActual?.toLocaleString()} vs AED ${metrics?.revenueBenchmark?.toLocaleString()}
- Direct COGS: AED ${metrics?.cogsActual?.toLocaleString()} vs AED ${metrics?.cogsBenchmark?.toLocaleString()}
- Gross Profit: AED ${metrics?.grossProfitActual?.toLocaleString()} (Gross Margin: ${metrics?.grossMarginActual?.toFixed(1)}%, Delta: ${metrics?.grossMarginDeltaPp >= 0 ? '+' : ''}${metrics?.grossMarginDeltaPp?.toFixed(1)} pp)
- OPEX: AED ${metrics?.opexActual?.toLocaleString()} vs AED ${metrics?.opexBenchmark?.toLocaleString()}
- Operational EBITDA: AED ${metrics?.ebitdaActual?.toLocaleString()} vs AED ${metrics?.ebitdaBenchmark?.toLocaleString()} (EBITDA Margin: ${metrics?.ebitdaMarginActual?.toFixed(1)}%, Delta: ${metrics?.ebitdaMarginDeltaPp >= 0 ? '+' : ''}${metrics?.ebitdaMarginDeltaPp?.toFixed(1)} pp)
- Net Profit: AED ${metrics?.netProfitActual?.toLocaleString()} vs AED ${metrics?.netProfitBenchmark?.toLocaleString()}

Top Drivers:
${JSON.stringify(topDrivers || {}, null, 2)}

Leasing Drivers Decomposition:
${JSON.stringify(leasingDecomposition || {}, null, 2)}

Management Explanations from Answered Questions:
${JSON.stringify(openQuestions?.filter((q: any) => q.status === 'Answered') || [], null, 2)}

Provide structured JSON matching the schema.`;

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: userPrompt,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              actionTitle: {
                type: Type.STRING,
                description: 'Action title stating conclusion with a number (<= 90 chars).',
              },
              executiveSummary: {
                type: Type.STRING,
                description: 'Executive briefing for the Board of Directors.',
              },
              strategicHighlights: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              directlySupportedDeductions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    driver: { type: Type.STRING },
                    impactAmount: { type: Type.STRING },
                    driverContributionPct: { type: Type.NUMBER },
                    polarity: { type: Type.STRING },
                    mathematicalProof: { type: Type.STRING },
                  },
                  required: ['driver', 'impactAmount', 'polarity', 'mathematicalProof'],
                },
              },
              operationalHypotheses: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    lineItem: { type: Type.STRING },
                    inquiryQuestion: { type: Type.STRING },
                    dataRequiredToConfirm: { type: Type.STRING },
                    recommendedManagementAction: { type: Type.STRING },
                  },
                  required: ['lineItem', 'inquiryQuestion', 'dataRequiredToConfirm'],
                },
              },
              dataLimitations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              boardActionItems: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              'actionTitle',
              'executiveSummary',
              'strategicHighlights',
              'directlySupportedDeductions',
              'operationalHypotheses',
              'dataLimitations',
              'boardActionItems',
            ],
          },
        },
      });

      const jsonText = response.text?.trim() || '{}';
      const parsedData = JSON.parse(jsonText);
      parsedData.source = 'AI';
      parsedData.sourceLabel = `Commentary source: AI (${MODEL_NAME})`;
      return res.json(parsedData);
    } catch (_err: any) {
      console.log('[FinAI Engine] External AI generation unavailable. Serving deterministic board commentary.');
      const fallbackData = buildDeterministicBoardCommentary(
        datasetName,
        benchmarkType,
        metrics,
        topDrivers,
        pnlSummary,
        openQuestions,
        leasingDecomposition
      );
      fallbackData.source = 'Rule-based';
      fallbackData.sourceLabel = 'Commentary source: Rule-based (Deterministic FP&A Engine)';
      fallbackData.sourceReason = 'Deterministic calculation engine active (AED 0 discrepancy guaranteed)';
      return res.json(fallbackData);
    }
  }

  // Fallback: deterministic rule-based engine
  const deterministicData = buildDeterministicBoardCommentary(
    datasetName,
    benchmarkType,
    metrics,
    topDrivers,
    pnlSummary,
    openQuestions,
    leasingDecomposition
  );
  deterministicData.source = 'Rule-based';
  deterministicData.sourceLabel = 'Commentary source: Rule-based (Deterministic FP&A Engine)';
  deterministicData.sourceReason = 'Deterministic calculation engine active (AED 0 discrepancy guaranteed)';
  return res.json(deterministicData);
});

// Interactive CFO drill-down inquiry
app.post('/api/drilldown', async (req: Request, res: Response) => {
  const { question, accountData, benchmarkType, context, sendToExternalAi } = req.body;

  if (sendToExternalAi && process.env.GEMINI_API_KEY) {
    try {
      const systemPrompt = `You are FinAI, an institutional CFO analytical engine for a UAE retail/mall real estate company.
Answer the CFO inquiry concisely and decisively. No hype words. Express margin shifts in pp with 1 decimal. All currencies in AED.`;

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: `Question: "${question}"\nBenchmark: ${benchmarkType}\nContext: ${JSON.stringify(context || {})}`,
        config: { systemInstruction: systemPrompt },
      });

      if (response.text) {
        return res.json({ answer: response.text, source: 'AI' });
      }
    } catch (_err) {
      // Fallback
    }
  }

  // Deterministic inquiry answer
  const answer = `### CFO & Management Analysis
Target Inquiry: "${question}"
Baseline: ${benchmarkType || 'Budget'}
System Check Status: System check passed.

- Directly Supported: Account movements reflect verified General Ledger postings.
- Unanswered Root Cause: Detailed transactional vendor/tenant invoices required to confirm variance drivers.
- Recommended Action: Conduct sub-metering review or tenant leasing audit.`;

  return res.json({ answer, source: 'Rule-based' });
});

// Health check probe
app.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({ status: 'healthy', app: 'FinAI FP&A Suite' });
});

// Start Server
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    const indexPath = path.resolve(distPath, 'index.html');

    // Anti-cache header helper for index.html / entry points / manifests
    const setNoCacheHeaders = (res: Response) => {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, proxy-revalidate, max-age=0');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.setHeader('Surrogate-Control', 'no-store');
    };

    if (fs.existsSync(distPath)) {
      app.use(
        express.static(distPath, {
          etag: true,
          lastModified: true,
          setHeaders: (res, filePath) => {
            const normalizedPath = filePath.replace(/\\/g, '/');
            // Content-hashed assets in assets/ folder: safe to cache immutably for 1 year
            if (normalizedPath.includes('/assets/')) {
              res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
            } else if (
              normalizedPath.endsWith('.html') ||
              normalizedPath.endsWith('version.json') ||
              normalizedPath.endsWith('manifest.json')
            ) {
              // Never cache entry HTML or version files
              setNoCacheHeaders(res as unknown as Response);
            } else {
              // Other root static files
              res.setHeader('Cache-Control', 'no-cache, must-revalidate');
            }
          },
        })
      );
    }

    app.get('*', (_req: Request, res: Response) => {
      setNoCacheHeaders(res);
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('<!doctype html><html><body><h1>FinAI FP&A Suite</h1><p>Initializing...</p></body></html>');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FinAI FP&A Server running on http://0.0.0.0:${PORT} (Model: ${MODEL_NAME})`);
  });
}

startServer();
