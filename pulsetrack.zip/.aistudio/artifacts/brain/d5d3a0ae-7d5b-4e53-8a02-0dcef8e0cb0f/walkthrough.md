# Security Summary

**Reviewed Files**: 28
**Issues Resolved**: 5

### Issues Resolved
| Area | File | Line | What Was Happening | Impact | Status | How It Was Fixed |
|---|---|---|---|---|---|---|
| CSV Export Formula Safety | `app/src/main/java/com/example/data/repository/FitnessRepository.kt` | 617 | Workout titles (including imported Health Connect titles) were written into CSV exports with only quote escaping, allowing spreadsheet formula characters or newlines to be interpreted when opened. | Medium | Fixed | Added `FitnessCalculators.sanitizeCsvCell` to normalize line breaks, neutralize leading `=`, `+`, `-`, `@`, tab, and carriage return characters, and quote-escape values before export. |
| PII in Error Logs | `app/src/main/java/com/example/data/remote/FirestoreErrorHandler.kt` | 29 | Firestore error handling serialized the signed-in user's email, provider emails, and full UID into `Log.e` system logs in all build variants. | Medium | Fixed | Redacted user IDs from logged document paths, removed email and provider metadata from log payloads, and restricted detailed error strings to debug builds only. |
| Cross-Account Local Isolation | `app/src/main/java/com/example/data/local/FitnessDao.kt` | 50 | Local Room workout queries/deletes lacked `userId` ownership filters, `custom_exercises` keyed only on exercise name, Health Connect import IDs were not scoped per user, and sign-out did not clear stored user preferences. | Medium | Fixed | Added `userId` clauses across Room DAO workout operations, migrated `custom_exercises` to a composite `(userId, name)` key, scoped Health Connect IDs per account, and cleared session preferences plus active timer notifications on sign-out. |
| Account Deletion Re-Auth Guard | `app/src/main/java/com/example/data/repository/FitnessRepository.kt` | 635 | Permanent account deletion wiped Firestore cloud records and local Room/DataStore storage before checking whether the user's Google sign-in was recent enough for Firebase Auth deletion to succeed. | Medium | Fixed | Added Credential Manager re-authentication in `AuthHelper` / `HealthSettingsScreen` and enforced owner UID plus sign-in freshness checks in `deleteAccountAndAllData` prior to deleting cloud or local data. |
| Backup & Device Transfer Rules | `app/src/main/res/xml/data_extraction_rules.xml` | 6 | Android 12+ cloud-backup and device-transfer extraction rules contained only commented placeholders, leaving local SQLite and DataStore files outside explicit exclusion rules. | Low | Fixed | Configured explicit exclusions for databases, shared preferences, and DataStore files in both `data_extraction_rules.xml` and `backup_rules.xml`. |

### Safeguards Verified
| Area | File | How It's Protected |
|---|---|---|
| Cloud Access & Rules | `firestore.rules` | Denies all access by default and enforces authenticated owner-only access (`request.auth.uid == userId`), immutable `createdAt`/`userId`, strict schema keys, and numeric bounds. |
| Authentication Flow | `app/src/main/java/com/example/ui/auth/AuthHelper.kt` | Uses Jetpack Credential Manager with Google Sign-In (`GetSignInWithGoogleOption` / `GetGoogleIdOption`) with no hardcoded tokens or anonymous auth. |
| External Health Connect Input | `app/src/main/java/com/example/data/healthconnect/HealthConnectManager.kt` | Trims and bounds external session titles (100 chars) and notes (500 chars), validates durations/metrics, and scopes imported IDs to the signed-in user. |
| Manifest & Components | `app/src/main/AndroidManifest.xml` | Keeps `ActiveWorkoutService` unexported (`exported="false"`), gates Android 14+ permission usage rationale behind `START_VIEW_PERMISSION_USAGE`, and sets `allowBackup="false"`. |
| Intent & PendingIntent Safety | `app/src/main/java/com/example/service/ActiveWorkoutService.kt` | Uses explicit component intents and `PendingIntent.FLAG_IMMUTABLE` for workout timer notifications. |

## PoC Verification

### 1. CSV Formula Injection in Workout Export

#### Summary
| Field | Value |
|---|---|
| Issue Type | Spreadsheet Formula Injection on Export |
| Impact | Medium |
| Affected File | `app/src/main/java/com/example/data/repository/FitnessRepository.kt:617` |
| Test Scenario | Exporting a workout whose title is `=HYPERLINK("https://evil.example","Click")` or `  =1+1` via `exportWorkoutsCsv`. |

#### How It Was Fixed
`FitnessRepository.exportWorkoutsCsv` now routes text cells through `FitnessCalculators.sanitizeCsvCell`, which flattens embedded carriage returns/newlines, prefixes any value whose raw or whitespace-trimmed first character is `=`, `+`, `-`, `@`, `\t`, or `\r` with a single quote (`'`), and doubles internal double quotes.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | Malicious title `=HYPERLINK("https://evil.example","Click")` enters `exportWorkoutsCsv` (`FitnessRepository.kt:622`). | Passed to `sanitizeCsvCell` |
| 2 | `FitnessCalculators.sanitizeCsvCell` (`FitnessCalculators.kt:179-196`) detects leading `=` in `CSV_FORMULA_PREFIXES`, prepends `'`, and escapes quotes to `""`. | Neutralized as `"'=HYPERLINK(""https://evil.example"",""Click"")"` |
| 3 | Verified via `PulseTrackQaSuiteTest.qa12_csvSanitizerNeutralizesFormulaInjectionAndRowSplitting` in `gradle :app:testDebugUnitTest`. | **Handled Safely** |

---

### 2. Sensitive Account Info in Firestore Error Logs

#### Summary
| Field | Value |
|---|---|
| Issue Type | Sensitive Account Data Logged in Release Builds |
| Impact | Medium |
| Affected File | `app/src/main/java/com/example/data/remote/FirestoreErrorHandler.kt:29` |
| Test Scenario | Any Firestore offline failure or permission rejection triggers `handleFirestoreError(exception, operationType, "users/<uid>/workouts")`. |

#### How It Was Fixed
`handleFirestoreError` now strips user IDs via `redactFirestorePath`, omits `email`, `providerInfo`, and `tenantId` completely, and emits only the operation type, Firestore error code, and redacted path in release builds.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | Firestore error calls `handleFirestoreError` (`FirestoreErrorHandler.kt:29`). | Enters sanitizer |
| 2 | `redactFirestorePath` (`FirestoreErrorHandler.kt:20-27`) replaces the UID segment after `users/` with `<redacted-uid>`, and no `email` or `providerData` fields are read (`FirestoreErrorHandler.kt:41-55`). | PII stripped |
| 3 | Release log prints only `"Firestore <op> failed (<code >) on users/<redacted-uid>/..."`. | **Handled Safely** |

---

### 3. Cross-Account Local Storage & Session Isolation

#### Summary
| Field | Value |
|---|---|
| Issue Type | Cross-Account Cache Collision on Shared Devices |
| Impact | Medium |
| Affected File | `app/src/main/java/com/example/data/local/FitnessDao.kt:50` |
| Test Scenario | User A signs out with active preferences/custom exercises, then User B signs in or imports Health Connect sessions on the same device. |

#### How It Was Fixed
Scoped `getWorkoutWithSets`, `deleteSetsForWorkout`, `deleteWorkoutById`, and `markWorkoutSynced` with `AND userId = :userId`; updated `CustomExerciseEntity` to composite primary keys `(userId, name)` via `MIGRATION_2_3`; prefixed Health Connect IDs with the user's UID fragment; cleared session preferences and stopped `ActiveWorkoutService` on sign-out; and prevented `ensureUserInitialized` from inheriting prior user settings.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | User A taps Sign Out (`MainActivity.kt:376-385`). | Calls `clearSessionOnSignOut()` |
| 2 | `FitnessRepository.clearSessionOnSignOut` (`FitnessRepository.kt:630-633`) stops `ActiveWorkoutService` and clears DataStore preferences; `ensureUserInitialized` (`FitnessRepository.kt:120-128`) creates clean `UserProfileSettings` for User B. | Session isolated |
| 3 | Any subsequent Room workout lookup/delete or custom exercise save runs scoped by `userId` (`FitnessDao.kt:50-77`, `RoomEntities.kt:84-94`). | **Handled Safely** |

---

### 4. Premature Data Wipe on Stale-Session Account Deletion

#### Summary
| Field | Value |
|---|---|
| Issue Type | Non-Atomic Destructive Account Deletion |
| Impact | Medium |
| Affected File | `app/src/main/java/com/example/data/repository/FitnessRepository.kt:635` |
| Test Scenario | User taps "Delete Permanently" more than 5 minutes after signing in, which previously erased Firestore and local data before `currentUser.delete()` failed for stale login. |

#### How It Was Fixed
Added `AuthHelper.hasRecentSignIn()` and `AuthHelper.reauthenticateWithGoogle()` in `HealthSettingsScreen` before invoking deletion, plus UID ownership and sign-in freshness verification inside `FitnessRepository.deleteAccountAndAllData` prior to deleting any cloud or local records.

#### Step-by-Step Trace
| Step | What Happens in the Code | Outcome |
|---|---|---|
| 1 | User confirms "Delete Permanently" (`HealthSettingsScreen.kt:486-507`). | Checks `AuthHelper.hasRecentSignIn()` |
| 2 | If sign-in is older than 4 minutes, `AuthHelper.reauthenticateWithGoogle` prompts Credential Manager re-verification before invoking `onDeleteAccount()`. | Fresh token ensured |
| 3 | `deleteAccountAndAllData` (`FitnessRepository.kt:635-652`) re-verifies `currentUser.uid == userId` and sign-in recency before calling `deleteAllUserCloudData()`, clearing Room/DataStore, and deleting the Auth user. | **Handled Safely** |
