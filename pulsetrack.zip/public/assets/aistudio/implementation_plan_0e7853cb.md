# PulseTrack — Native Android Master Prompt & Implementation Plan (Kotlin + Jetpack Compose + Health Connect)

> [!TIP]
> **How to Start Your New Session**: Open a new Google AI Studio chat, select **Build an Android app** (as shown in your screenshot), and paste this entire specification (starting from **Persona, Objective & Master Prompt Components** down to **Section e**) as your initial prompt. All PWA/web assumptions have been removed—this blueprint targets a 100% native Android app ready to compile to `.apk` and `.aab` for the Google Play Store.

---

### User Review & Critical Decisions

- **Platform Pivot Confirmed**: Pure **Native Android** application (Kotlin, Jetpack Compose, Material 3 / Material You) targeting Android 8.0+ (API 26+) through Android 15/16 (API 35/36) — zero PWA or web wrapper.
- **Auth & Cloud Persistence (Firebase Chosen Over Supabase for Speed)**: **Firebase Authentication (Google Sign-In / Credential Manager)** + **Cloud Firestore** paired with local **Room** offline-first caching. Firebase is significantly faster for a 2-hour build inside Google AI Studio because it integrates natively without manual Postgres/RLS SQL setup, custom Google OAuth plumbing, or hand-rolled offline sync queues.
- **Google Health Connect (2-Hour MVP Scoping)**: Uses native **Android Health Connect SDK** (`androidx.health.connect:connect-client`). To fit cleanly within a **2-hour build**, Phase 1 implements **Read Daily Steps (`StepsRecord`) + Read/Write Workouts (`ExerciseSessionRecord`, `TotalCaloriesBurnedRecord`)** plus `HealthConnectClient.getSdkStatus()` availability checking; advanced continuous `HeartRateRecord` streams and multi-wearable conflict merging are deferred to v1.1. *(Note: Testing Health Connect requires a physical Android 14+ phone or API 34+ emulator, and Play Store review of Health Connect declarations takes additional days after upload.)*
- **Added Missing Essentials**: Pre-seeded exercise catalog + 1-tap templates (`Push`, `Pull`, `Legs`, `5K Run`), full Edit/Delete support for logged workouts with automatic PR/metric recalculation, and Play Store-mandatory **Delete Account & Data** + Privacy Policy screen.
- **Play Store Readiness**: Configured for release signing, R8 shrinking/obfuscation, and building both a testable `.apk` and a Play Store `.aab` (Android App Bundle).

---

### Persona, Objective & Master Prompt Components

- **AI Builder Persona (System Role for New Session)**:
  - Act as a Principal Android Engineer & Mobile Product Designer specializing in Kotlin, Jetpack Compose, Material 3 (Material You), Room, Hilt, Firebase, Android Health Connect, and Google Play release engineering.
- **Target End-User Persona**:
  - *Primary Persona*: Android fitness users (ages 18–45) training in gyms and outdoors who want fast, one-handed set logging, automatic daily step counting, reliable offline storage, and native Health Connect sync across watches and health apps without subscription clutter.
- **Core Objective**:
  - Build **PulseTrack**, a production-grade native Android fitness application that lets users sign in with Google, track daily steps automatically, log strength and cardio workouts with live timers and PR detection, visualize longitudinal health trends, sync bidirectionally with Android Health Connect, and build a Play Store-ready `.apk` / `.aab`.
- **Non-Functional & Architectural Constraints**:
  - Single-activity Jetpack Compose architecture with unidirectional data flow (UDF) and ViewModel `StateFlow` state holders.
  - Offline-first Room database as local single source of truth, synchronized cleanly with Cloud Firestore when online.
  - Strictly avoid deprecated APIs (`GoogleFit`, `AsyncTask`, legacy `PreferenceManager`, or hardcoded secrets in source files).
  - Full adherence to Google Play Health Apps policy (explicit Health Connect permission rationale activity and clear user consent toggles).

---

### a. COMPLETE UI/UX REDESIGN

- **Visual Identity & Dark Athletic Material You Palette (60-30-10 Discipline)**:
  - *60% Dominant OLED Canvas*: Deep obsidian charcoal (`#0D1015`) background for battery efficiency and zero glare in dim gyms.
  - *30% Structural Surfaces*: Tonal Material 3 dark containers (`#161B22` surfaceContainer, `#1E2530` surfaceContainerHigh, `#262F3D` surfaceContainerHighest) with subtle `1dp` hairline borders (`#2A3240`)—no stacked cards-within-cards or thick left accent stripes.
  - *10% High-Intent Accent Budget*: Volt Lime (`#C8F135`) reserved strictly for primary FABs, active step progress rings, and selected navigation indicators; Sky Cyan (`#38BDF8`) reserved for cardio and step comparison chart series; Amber (`#F59E0B`) and Coral (`#F43F5E`) paired with explicit text labels for warnings/errors.
  - *Optional Dynamic Color Support*: Toggleable Material You wallpaper dynamic theming on Android 12+ (`dynamicDarkColorScheme`) defaulting to the curated Dark Athletic palette.
- **Typography & Tabular Discipline**:
  - *Display & Section Headings*: Bold geometric sans (`Outfit` bundled font resource) with crisp hierarchy.
  - *Body & Controls*: Clean readable sans (`Plus Jakarta Sans` bundled font resource) with WCAG AA dark-mode contrast.
  - *Metrics, Timers & Tables*: Monospace (`JetBrains Mono`) with `fontFeatureSettings = "tnum"` (tabular figures) on all step counts, weights, reps, paces, and countdown timers to prevent layout jitter.
  - *Zero-Pill Metadata*: Dates, workout types, durations, and calorie totals render as clean inline text separated by `·` (e.g., `Strength · 48 min · 320 kcal`) rather than cluttered pill badges.
- **Thumb-Zone Ergonomics & Navigation Structure**:
  - *Bottom NavigationBar*: 4 primary destinations (`Today`, `Workouts`, `Progress`, `Health & Profile`) with `48dp` minimum touch targets.
  - *Primary Floating Action Button (FAB)*: Bottom-right Volt Lime CTA to launch the Workout Logger immediately from any primary screen.
  - *ModalBottomSheet Flows*: Slide-up sheets for quick step adjustments, rest timer controls, exercise picking, and Health Connect sync details.
- **Screen-by-Screen UX Flows**:
  - *1. Welcome & Google Sign-In*: Clean athletic sign-in screen using Android Credential Manager + Firebase Auth, followed by quick onboarding for units (`kg/km` vs `lbs/mi`), daily step target, and weekly workout goal.
  - *2. Today Dashboard*: Horizontal 7-day calendar strip, hero animated Step Goal Ring (`Canvas` arc) with remaining steps readout, active streak counter, quick step entry (`+500`, `+1,000`, custom), and today's completed workouts.
  - *3. Active Workout Logger*: Tabbed Strength vs. Cardio logger:
    - **Strength**: Curated exercise library + custom exercise dialog, dynamic set rows (`Set #`, `Weight`, `Reps`, `Done` checkbox), live session stopwatch, and integrated rest countdown timer (`60s` / `90s` / `120s` / custom) with optional vibration/chime alert.
    - **Cardio**: Activity selector (`Run`, `Cycle`, `Walk`, `HIIT`, `Swim`), live/manual duration, distance, auto-calculated pace, heart rate, and calorie estimate.
  - *4. Progress & Health Analytics*: Time-range filter (`7D`, `30D`, `90D`), custom Compose `Canvas` daily step bar chart with dashed goal threshold line, strength tonnage & estimated 1RM progression chart by exercise, Personal Records (PR) trophy list, and muscle-group distribution breakdown.
  - *5. Health Connect & Settings Hub*: Native Health Connect permission status & one-tap sync trigger, granular data-type toggles (Steps, Workouts, Calories, Heart Rate), unit & goal editors, CSV/JSON local backup export, and account management.
- **Motion & States**:
  - Crisp `animateFloatAsState` / spring transitions (`<= 200ms`) on progress rings, set checkoffs, and bottom sheets; shimmer/loading states, actionable empty states, offline sync indicator banner, and celebratory PR snackbars.

---

### b. FUNCTIONALITY AND ACCURACY

- **Workout Logging, Templates & PR Engine**:
  - *Pre-Seeded Catalog & Templates*: Ships with 30+ common strength/cardio exercises and 1-tap starter templates (`Push Day`, `Pull Day`, `Leg Day`, `Quick Run`) so first-time users can log a workout in under 10 seconds.
  - *Strength Precision*: Tracks exercise name, muscle group (`Chest`, `Back`, `Legs`, `Shoulders`, `Arms`, `Core`, `Full Body`), individual sets (`weightKg`, `reps`, `isCompleted`, `isWarmup`), and total working tonnage (`sum(weight × reps)` excluding warmups).
  - *Edit & Delete Integrity*: Full editing and deletion of saved workouts and individual sets, automatically recomputing daily active minutes, calories, and PR flags.
  - *Estimated 1RM & PR Detection*: Applies the Epley formula (`1RM = weight × (1 + reps / 30)` for `reps > 1`, or `weight` for `1RM`) against historical Room/Firestore records to detect and flag new Max Weight and Estimated 1RM PRs on completion.
  - *Cardio Precision*: Computes exact pace (`totalSeconds / distance`) formatted cleanly as `MM:SS /km` or `MM:SS /mi`, validates positive bounds, and estimates calories via MET values when wearable calories are unavailable.
  - *Drift-Free Timers*: Computes elapsed workout duration and rest countdowns against `SystemClock.elapsedRealtime()` so screen lock or app backgrounding never causes timer drift, backed by a lightweight Foreground Service notification during active workouts.
- **Native Step Tracking Accuracy**:
  - *Hardware Step Sensor*: Reads `Sensor.TYPE_STEP_COUNTER` (cumulative steps since boot) with delta baseline persisted in DataStore/Room so device reboots and midnight calendar rollovers (`LocalDate`) never lose or double-count daily steps.
  - *Background Sync*: Schedules periodic `WorkManager` workers to flush daily step deltas and sync pending workouts to Firestore and Health Connect reliably.
- **Android Health Connect Accuracy (2-Hour MVP Scope)**:
  - *SDK Availability Guard*: Checks `HealthConnectClient.getSdkStatus(context)` (`SDK_AVAILABLE` vs. `SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED`) and shows a guided Play Store install prompt on Android 9–13 devices lacking Health Connect.
  - *Canonical Mapping*: Maps directly to Jetpack Health Connect record types: `StepsRecord`, `ExerciseSessionRecord`, `DistanceRecord`, and `TotalCaloriesBurnedRecord` (with `HeartRateRecord` scheduled for v1.1).
  - *Deduplication*: Uses deterministic `metadata.clientRecordId` keys on writes and timestamp/package-origin filtering on reads so syncing with Google Fit, Samsung Health, or Wear OS never creates duplicate steps or workouts.
- **Canonical Units & Account Compliance**:
  - Stores all weights (`kg`) and distances (`km`) in canonical SI units inside Room and Firestore; converts cleanly on display (`1 kg = 2.20462 lbs`, `1 km = 0.621371 mi`) and enforces realistic input bounds before saving.
  - Provides Play Store-compliant **Delete Account & Cloud Data** flow inside Settings alongside a clear Privacy Policy view.

---

### c. TECHNICAL IMPLEMENTATION

- **Architecture & Component Diagram**:

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    Jetpack Compose UI (Material 3)                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │
│  │ TodayScreen  │  │ WorkoutSheet │  │ ProgressView │  │ HealthHub   │  │
│  │ - Step Ring  │  │ - Sets/Reps  │  │ - Bar Chart  │  │ - HC Perms  │  │
│  │ - Date Strip │  │ - Rest Timer │  │ - 1RM Trend  │  │ - Sync Ctrl │  │
│  │ - Quick Step │  │ - Cardio Log │  │ - Muscle Map │  │ - Settings  │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬──────┘  │
└─────────┼─────────────────┼─────────────────┼─────────────────┼─────────┘
          │                 │                 │                 │
┌─────────▼─────────────────▼─────────────────▼─────────────────▼─────────┐
│                  ViewModels (Hilt + StateFlow + UDF)                    │
│       TodayViewModel · WorkoutViewModel · AnalyticsViewModel · AuthVM   │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼─────────────────────────────────────┐
│               Offline-First Domain & Repository Layer                   │
│  ┌──────────────────────┐ ┌───────────────────┐ ┌────────────────────┐  │
│  │  FitnessRepository   │ │ HealthConnectMgr  │ │ StepSensorManager  │  │
│  │  - PR & 1RM Engine   │ │ - Connect Client  │ │ - TYPE_STEP_COUNTER│  │
│  │  - Unit Converter    │ │ - Record Mapper   │ │ - Midnight Rollover│  │
│  └──────────┬───────────┘ └─────────┬─────────┘ └─────────┬──────────┘  │
└─────────────┼───────────────────────┼─────────────────────┼─────────────┘
              │                       │                     │
┌─────────────▼───────────┐ ┌─────────▼─────────┐ ┌─────────▼──────────┐
│  Room DB (Local Truth)  │ │  Android Health   │ │  Cloud Firestore   │
│  + WorkManager Sync     │ │  Connect Platform │ │  & Firebase Auth   │
└─────────────────────────┘ └───────────────────┘ └────────────────────┘
```

- **Android Tech Stack & Dependencies**:
  - *Language & UI*: Kotlin, Jetpack Compose BOM, Material 3 (`material3`), Compose Navigation (`navigation-compose`), Compose `Canvas` for custom charts.
  - *Architecture & DI*: Hilt (`hilt-android`, `hilt-navigation-compose`), Kotlin Coroutines & Flow, ViewModel, Jetpack DataStore (Preferences).
  - *Local Persistence & Background*: Room (`room-runtime`, `room-ktx`, KSP) + WorkManager (`work-runtime-ktx`, `hilt-work`) + Foreground Service for active workout/step tracking.
  - *Health & Sensors*: Jetpack Health Connect (`androidx.health.connect:connect-client`) + Android `SensorManager` (`TYPE_STEP_COUNTER`, `ACTIVITY_RECOGNITION` permission).
  - *Cloud & Auth*: Firebase BoM (`firebase-auth`, `firebase-firestore`) + Android Credential Manager (`androidx.credentials`) for Google Sign-In.
- **Data Model & Firestore Security**:
  - *Room Entities*: `UserPreferencesEntity`, `DailyMetricEntity` (`dateKey`, `steps`, `activeMinutes`, `caloriesBurned`, `syncedToCloud`), `WorkoutEntity` (`id`, `type`, `title`, `startedAt`, `durationMin`, `distanceKm`, `calories`, `avgHeartRate`, `source`, `syncStatus`), `ExerciseSetEntity` (`workoutId`, `exerciseName`, `muscleGroup`, `setIndex`, `weightKg`, `reps`, `completed`, `isPr`).
  - *Firestore Structure*: `/users/{uid}` profile, `/users/{uid}/workouts/{workoutId}`, `/users/{uid}/dailyMetrics/{YYYY-MM-DD}` protected by strict owner-only `firestore.rules` (`request.auth.uid == userId`) with field-type and range validation.
- **Interactive State Mapping & Permissions**:
  - Handles runtime permissions gracefully with clear rationale UI before system dialogs (`ACTIVITY_RECOGNITION`, `POST_NOTIFICATIONS` for active workout/rest timer alerts, and Health Connect `PermissionController.createRequestPermissionResultContract()`).
  - Includes `HealthConnectRationaleActivity` handling `androidx.health.ACTION_SHOW_PERMISSIONS_RATIONALE` and Android 14+ `VIEW_PERMISSION_USAGE` intent filters required by Play Store Health Connect review.
- **Play Store Build & Signing Configuration**:
  - Configure `applicationId`, `versionCode`, `versionName`, `compileSdk = 35/36`, `targetSdk = 35/36`, `minSdk = 26`, R8 release minification (`isMinifyEnabled = true`, `proguard-rules.pro`), adaptive launcher icon (`mipmap-anydpi-v26`), and release signing config wired via environment/keystore properties (never hardcoded).

---

### d. FINAL DELIVERABLES

- **Complete Native Android Studio / Gradle Project**:
  - Full Kotlin + Jetpack Compose codebase cleanly organized across UI, ViewModel, Domain, Data/Room, Health Connect, Sensor, and Firebase layers.
- **Core Application Modules**:
  - Google Sign-In onboarding & settings flow.
  - Today Dashboard with animated step ring, 7-day selector, quick step actions, and workout summary.
  - Live Strength & Cardio Workout Logger with curated + custom exercise library, drift-free rest timer, and automatic PR detection.
  - Progress Analytics with `7D`/`30D`/`90D` Compose `Canvas` charts (steps vs. goal, lift volume & 1RM trends, muscle-group balance, PR history).
  - Bidirectional Android Health Connect sync & hardware step counter integration.
- **Backend & Security Assets**:
  - Firebase Firestore security rules (`firestore.rules`) enforcing user-scoped read/write isolation and schema validation.
- **Play Store Release Artifacts**:
  - Production Gradle build configuration capable of generating both a debug/release `.apk` (for direct Android phone sideloading) and a signed `.aab` (for Google Play Console upload), plus Play Console Health Connect declaration checklist.

---

### e. EXECUTION PRIORITY & SEQUENCE

- **Phase 1 — Gradle, Dependencies & Firebase Setup (0:00–0:20)**:
  - Initialize Android Gradle configuration (Kotlin, Compose BOM, Material 3, Hilt, Room, WorkManager, Health Connect SDK, Firebase Auth/Firestore, Credential Manager).
  - Configure `AndroidManifest.xml` with `ACTIVITY_RECOGNITION`, `FOREGROUND_SERVICE`, `POST_NOTIFICATIONS`, Health Connect `<queries>` & permission declarations, and `HealthConnectRationaleActivity`.
  - Provision Firebase Auth (Google Sign-In) & Cloud Firestore and deploy owner-only `firestore.rules`.
- **Phase 2 — Data Layer, Room & Hardware Step Sensor (0:20–0:45)**:
  - Implement Room database, DAOs, pre-seeded exercise catalog, and DataStore preferences.
  - Implement `FitnessRepository` with offline-first sync, Epley 1RM/PR engine, edit/delete recalculation, and `StepSensorManager` (reboot/midnight delta safety).
- **Phase 3 — Dark Athletic Material You Compose UI (0:45–1:25)**:
  - Configure Material 3 dark theme tokens (`#0D1015`, `#161B22`, `#C8F135`, `#38BDF8`), typography (`Outfit`, `Plus Jakarta Sans`, `JetBrains Mono`), and bottom navigation scaffold.
  - Build Sign-In/Onboarding, Today Dashboard (step ring + 7-day strip + quick steps), Active Workout Logger BottomSheet (templates + sets + drift-free rest timer), and Progress Analytics `Canvas` charts.
- **Phase 4 — Health Connect MVP Integration & Account Compliance (1:25–1:45)**:
  - Implement `HealthConnectManager` (`getSdkStatus()` guard, permission request flow, Read `StepsRecord`, Read/Write `ExerciseSessionRecord` + `TotalCaloriesBurnedRecord`, deduplication).
  - Wire Settings, CSV/JSON local export, Privacy Policy link, and Play Store-required **Delete Account & Data** flow.
- **Phase 5 — Verification & Play Store APK/AAB Build (1:45–2:00)**:
  - Run unit tests for PR calculation, unit conversion, and step midnight rollover.
  - Verify Gradle compilation (`./gradlew assembleDebug` / `bundleRelease`), lint checks, and R8 release rules so the project builds cleanly into an `.apk` and Play Store `.aab`.
