const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function buildValidProfile(uid, ts) {
  return {
    userId: uid,
    displayName: "Alex Rivera",
    email: "alex@example.com",
    unitSystem: "METRIC",
    dailyStepGoal: 10000,
    weeklyWorkoutGoal: 4,
    useDynamicColor: false,
    hcSyncSteps: true,
    hcSyncWorkouts: true,
    hcSyncCalories: true,
    onboardingCompleted: true,
    createdAt: ts,
    updatedAt: ts,
  };
}

function buildValidDailyMetric(uid, dateKey, ts) {
  return {
    userId: uid,
    dateKey,
    steps: 6420,
    manualAdjustmentSteps: 500,
    activeMinutes: 45,
    caloriesBurned: 420,
    stepGoal: 10000,
    createdAt: ts,
    updatedAt: ts,
  };
}

function buildValidWorkout(uid, ts) {
  return {
    userId: uid,
    workoutType: "STRENGTH",
    title: "Push Day",
    dateKey: "2026-11-22",
    startedAtMs: 1795400000000,
    durationMinutes: 52,
    caloriesBurned: 340,
    distanceKm: 0.0,
    avgHeartRate: 128,
    totalVolumeKg: 4850.0,
    cardioActivity: "",
    notes: "Strong bench press session",
    source: "PULSETRACK",
    prCount: 1,
    sets: [
      {
        exerciseName: "Barbell Bench Press",
        muscleGroup: "Chest",
        setIndex: 1,
        weightKg: 80.0,
        reps: 8,
        completed: true,
        warmup: false,
        pr: true,
      },
    ],
    createdAt: ts,
    updatedAt: ts,
  };
}

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const ts = new Date(Date.now() - 2000);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).set(buildValidProfile(ALICE_UID, ts)));
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("workouts").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").get());
});

test("UserProfile: owner can create, update allowed fields, and delete; rejects shadow fields & cross-user", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(buildValidProfile(ALICE_UID, created))
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      dailyStepGoal: 12000,
      unitSystem: "IMPERIAL",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject immutable createdAt modification
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      dailyStepGoal: 9000,
      updatedAt: new Date(Date.now() + 60000),
    })
  );

  // Cross-user read/write/delete denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ dailyStepGoal: 5000, updatedAt: new Date(Date.now() - 1000) }));
  await assertFails(bobDb.collection("users").doc(ALICE_UID).delete());

  // Blanket users list denied
  await assertFails(aliceDb.collection("users").get());
});

test("DailyMetric: owner can create, partial update, list, and delete; enforces dateKey parity", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const dateKey = "2026-11-22";

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").doc(dateKey).set(
      buildValidDailyMetric(ALICE_UID, dateKey, created)
    )
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").doc(dateKey).update({
      steps: 7420,
      manualAdjustmentSteps: 1500,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").get()
  );

  // Reject mismatched dateKey vs doc ID
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").doc("2026-11-23").set(
      buildValidDailyMetric(ALICE_UID, "2026-11-22", created)
    )
  );

  // Reject negative steps
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").doc(dateKey).update({
      steps: -10,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user list/read denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("dailyMetrics").doc(dateKey).get());
});

test("Workout: owner can create, edit, list, and delete; rejects @DocumentId id key and invalid fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_1").set(
      buildValidWorkout(ALICE_UID, created)
    )
  );

  // Edit workout
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_1").update({
      title: "Heavy Push Day",
      durationMinutes: 60,
      totalVolumeKg: 5200.5,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // List workouts (matches Kotlin query)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").get()
  );

  // Reject payload containing @DocumentId "id" key
  const badWithId = buildValidWorkout(ALICE_UID, created);
  badWithId.id = "w_push_2";
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_2").set(badWithId)
  );

  // Reject invalid workoutType
  const badType = buildValidWorkout(ALICE_UID, created);
  badType.workoutType = "YOGA_UNKNOWN";
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_3").set(badType)
  );

  // Cross-user access denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("workouts").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_1").delete());

  // Owner delete succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("workouts").doc("w_push_1").delete()
  );
});
