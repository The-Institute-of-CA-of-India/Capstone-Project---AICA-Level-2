package com.example

import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.util.FitnessCalculators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FitnessCalculatorsTest {

    @Test
    fun epley1Rm_handlesSingleAndMultipleReps() {
        assertEquals(100.0, FitnessCalculators.calculateEpley1Rm(100.0, 1), 0.01)
        assertEquals(126.67, FitnessCalculators.calculateEpley1Rm(100.0, 8), 0.05)
        assertEquals(0.0, FitnessCalculators.calculateEpley1Rm(0.0, 10), 0.001)
        assertEquals(0.0, FitnessCalculators.calculateEpley1Rm(80.0, 0), 0.001)
    }

    @Test
    fun workingTonnage_excludesWarmupAndIncompleteSets() {
        val sets = listOf(
            ExerciseSetItem("1", "Squat", MuscleGroup.LEGS, 1, 60.0, 10, completed = true, warmup = true),
            ExerciseSetItem("2", "Squat", MuscleGroup.LEGS, 2, 100.0, 5, completed = true, warmup = false),
            ExerciseSetItem("3", "Squat", MuscleGroup.LEGS, 3, 100.0, 5, completed = false, warmup = false)
        )
        assertEquals(500.0, FitnessCalculators.calculateWorkingTonnageKg(sets), 0.01)
    }

    @Test
    fun unitConversion_roundTripsCleanly() {
        val lbs = FitnessCalculators.kgToDisplay(100.0, UnitSystem.IMPERIAL)
        assertEquals(220.462, lbs, 0.01)
        assertEquals(100.0, FitnessCalculators.displayToKg(lbs, UnitSystem.IMPERIAL), 0.01)

        val miles = FitnessCalculators.kmToDisplay(5.0, UnitSystem.IMPERIAL)
        assertEquals(3.1068, miles, 0.01)
        assertEquals(5.0, FitnessCalculators.displayToKm(miles, UnitSystem.IMPERIAL), 0.01)
    }

    @Test
    fun cardioPace_formatsMetricAndImperialCorrectly() {
        assertEquals("5:00 /km", FitnessCalculators.formatPace(25, 5.0, UnitSystem.METRIC))
        assertEquals("--:-- /km", FitnessCalculators.formatPace(25, 0.0, UnitSystem.METRIC))
        val calories = FitnessCalculators.estimateCardioCalories(CardioActivity.RUN, 30, 75.0)
        assertTrue(calories in 350..420)
    }

    @Test
    fun stepSensorDelta_handlesFirstReadNormalRebootAndMidnightRollover() {
        // 1. First read initializes baseline with 0 delta
        val first = FitnessCalculators.calculateStepSensorDelta(
            currentBootSteps = 4500L,
            lastBootSteps = -1L,
            lastDateKey = "",
            todayDateKey = "2026-11-22"
        )
        assertEquals(0, first.deltaSteps)
        assertEquals(4500L, first.newBootStepsBaseline)
        assertFalse(first.dateRolledOver)

        // 2. Normal increment on same day
        val normal = FitnessCalculators.calculateStepSensorDelta(
            currentBootSteps = 5250L,
            lastBootSteps = 4500L,
            lastDateKey = "2026-11-22",
            todayDateKey = "2026-11-22"
        )
        assertEquals(750, normal.deltaSteps)
        assertEquals(5250L, normal.newBootStepsBaseline)
        assertFalse(normal.dateRolledOver)

        // 3. Device rebooted (counter reset below lastBootSteps)
        val reboot = FitnessCalculators.calculateStepSensorDelta(
            currentBootSteps = 320L,
            lastBootSteps = 5250L,
            lastDateKey = "2026-11-22",
            todayDateKey = "2026-11-22"
        )
        assertEquals(320, reboot.deltaSteps)
        assertEquals(320L, reboot.newBootStepsBaseline)

        // 4. Midnight date rollover
        val rollover = FitnessCalculators.calculateStepSensorDelta(
            currentBootSteps = 5400L,
            lastBootSteps = 5250L,
            lastDateKey = "2026-11-22",
            todayDateKey = "2026-11-23"
        )
        assertEquals(150, rollover.deltaSteps)
        assertTrue(rollover.dateRolledOver)
    }
}
