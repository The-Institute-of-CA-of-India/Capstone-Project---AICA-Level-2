package com.example

import com.example.data.local.DailyMetricEntity
import com.example.data.local.ExerciseSetEntity
import com.example.data.local.WorkoutEntity
import com.example.data.remote.FirestorePayloadMapper
import com.example.data.remote.FirestoreUserProfile
import com.example.data.remote.FirestoreWorkout
import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.UserProfileSettings
import com.example.domain.model.WorkoutSource
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * End-to-End QA Debugging Suite for PulseTrack:
 * - Validates 100+ Strength & Cardio exercise catalog integrity
 * - Validates every calculator, timer formatter, and sensor edge case
 * - Validates Firestore DTO mappings against firestore.rules constraints
 * - Validates Health Connect / Workout / Custom Exercise / Unit / PR workflows
 */
class PulseTrackQaSuiteTest {

    @Test
    fun qa01_exerciseCatalogHasAtLeast100TotalStrengthAndCardioExercises() {
        val total = ExerciseCatalog.defaultExercises.size
        val strengthCount = ExerciseCatalog.defaultStrengthExercises.size
        val cardioCount = ExerciseCatalog.defaultCardioExercises.size

        assertTrue("Expected >= 100 exercises in total, got $total", total >= 100)
        assertEquals(108, total)
        assertEquals(80, strengthCount)
        assertEquals(28, cardioCount)
        assertEquals(total, strengthCount + cardioCount)
    }

    @Test
    fun qa02_exerciseCatalogHasNoDuplicatesAndCoversAllMuscleAndCardioGroups() {
        val distinctKeys = ExerciseCatalog.defaultExercises
            .map { "${it.workoutType.name}_${it.name.trim().lowercase()}" }
            .toSet()
        assertEquals(
            "Duplicate exercise keys detected in ExerciseCatalog",
            ExerciseCatalog.defaultExercises.size,
            distinctKeys.size
        )

        val coveredMuscles = ExerciseCatalog.defaultStrengthExercises.map { it.muscleGroup }.toSet()
        assertEquals(MuscleGroup.entries.toSet(), coveredMuscles)

        val coveredCardio = ExerciseCatalog.defaultCardioExercises.map { it.cardioActivity }.toSet()
        assertEquals(CardioActivity.entries.toSet(), coveredCardio)

        ExerciseCatalog.defaultExercises.forEach { item ->
            assertTrue("Blank exercise name", item.name.isNotBlank())
            if (item.workoutType == WorkoutType.CARDIO) {
                assertTrue("Cardio MET out of range for ${item.name}", item.met in 3.0..15.0)
                assertTrue(
                    "Cardio exercise name '${item.name}' exceeds Firestore 40-char cardioActivity rule",
                    item.name.length <= 40
                )
            }
        }
    }

    @Test
    fun qa03_starterTemplatesReferenceValidCatalogExercises() {
        val allNames = ExerciseCatalog.defaultExercises.map { it.name.lowercase() }.toSet()
        assertEquals(4, ExerciseCatalog.starterTemplates.size)

        ExerciseCatalog.starterTemplates.forEach { tpl ->
            assertTrue(tpl.title.isNotBlank())
            if (tpl.type == WorkoutType.STRENGTH) {
                assertTrue("Strength template ${tpl.id} has no exercises", tpl.exercises.isNotEmpty())
                tpl.exercises.forEach { ex ->
                    assertTrue(
                        "Template ${tpl.id} references missing exercise '${ex.exerciseName}'",
                        ex.exerciseName.lowercase() in allNames
                    )
                    assertTrue(ex.defaultSets > 0)
                    assertTrue(ex.defaultReps > 0)
                }
            } else {
                assertTrue(
                    "Cardio template ${tpl.id} references missing exercise '${tpl.cardioExerciseName}'",
                    tpl.cardioExerciseName.lowercase() in allNames
                )
                assertTrue(tpl.defaultDurationMin > 0)
            }
        }
    }

    @Test
    fun qa04_cardioActivityFromRawResolvesAll28CardioExercises() {
        ExerciseCatalog.defaultCardioExercises.forEach { cardio ->
            val resolved = CardioActivity.fromRaw(cardio.name)
            assertEquals(
                "CardioActivity.fromRaw failed to resolve '${cardio.name}'",
                cardio.cardioActivity,
                resolved
            )
        }
        assertEquals(CardioActivity.RUN, CardioActivity.fromRaw(null))
        assertEquals(CardioActivity.RUN, CardioActivity.fromRaw("unknown_activity"))
    }

    @Test
    fun qa05_pickerSearchAndFilteringWorksAcrossAll108Exercises() {
        val customCardio = ExerciseCatalogItem(
            name = "Assault AirRunner Intervals",
            muscleGroup = MuscleGroup.LEGS,
            workoutType = WorkoutType.CARDIO,
            cardioActivity = CardioActivity.RUN,
            met = 11.2,
            isCustom = true
        )
        val catalog = ExerciseCatalog.defaultExercises + customCardio

        val benchResults = catalog.filter {
            it.workoutType == WorkoutType.STRENGTH && it.name.contains("bench", ignoreCase = true)
        }
        assertTrue("Expected multiple bench exercises", benchResults.size >= 4)

        val rowResults = catalog.filter {
            it.workoutType == WorkoutType.CARDIO && it.cardioActivity == CardioActivity.ROW
        }
        assertEquals(2, rowResults.size)

        val customMatch = catalog.firstOrNull { it.name == "Assault AirRunner Intervals" && it.isCustom }
        assertNotNull(customMatch)
    }

    @Test
    fun qa06_cardioCaloriesAndPaceRespondToCustomMetAndUnits() {
        val recoveryJog = ExerciseCatalog.defaultCardioExercises.first { it.name == "Recovery Jog" }
        val sprintIntervals = ExerciseCatalog.defaultCardioExercises.first { it.name == "Track Sprint Intervals" }

        val calLow = FitnessCalculators.estimateCardioCalories(
            activity = recoveryJog.cardioActivity,
            durationMinutes = 30,
            customMet = recoveryJog.met
        )
        val calHigh = FitnessCalculators.estimateCardioCalories(
            activity = sprintIntervals.cardioActivity,
            durationMinutes = 30,
            customMet = sprintIntervals.met
        )
        assertTrue("Sprint intervals ($calHigh) should burn more than recovery jog ($calLow)", calHigh > calLow)
        assertEquals(0, FitnessCalculators.estimateCardioCalories(CardioActivity.RUN, 0))

        assertEquals("6:00 /km", FitnessCalculators.formatPace(30, 5.0, UnitSystem.METRIC))
        assertEquals("--:-- /mi", FitnessCalculators.formatPace(0, 5.0, UnitSystem.IMPERIAL))
    }

    @Test
    fun qa07_timerFormattingAndStrengthCaloriesHandleBoundaryInputs() {
        assertEquals("00:00", FitnessCalculators.formatTimerSeconds(0))
        assertEquals("00:00", FitnessCalculators.formatTimerSeconds(-5))
        assertEquals("01:30", FitnessCalculators.formatTimerSeconds(90))
        assertEquals("1:05:09", FitnessCalculators.formatTimerSeconds(3909))

        assertEquals(0, FitnessCalculators.estimateStrengthCalories(0, 0))
        val cals = FitnessCalculators.estimateStrengthCalories(45, 15)
        assertTrue("Strength calories $cals outside expected bounds", cals in 150..500)
    }

    @Test
    fun qa08_dailyMetricEntityTotalStepsClampingAndPrecedence() {
        val m1 = DailyMetricEntity(
            userId = "u1",
            dateKey = "2026-11-22",
            hardwareSteps = 6000,
            healthConnectSteps = 7200,
            manualAdjustmentSteps = 1000
        )
        // Uses max(hardware, healthConnect) + manual
        assertEquals(8200, m1.totalSteps)

        val overflow = DailyMetricEntity(
            userId = "u1",
            dateKey = "2026-11-22",
            hardwareSteps = 240_000,
            healthConnectSteps = 0,
            manualAdjustmentSteps = 50_000
        )
        assertEquals(250_000, overflow.totalSteps)
    }

    @Test
    fun qa09_firestorePayloadMapperEnforcesSchemaAndRulesBounds() {
        val profile = UserProfileSettings(
            userId = "uid_123",
            displayName = "   ",
            email = "athlete@example.com",
            unitSystem = UnitSystem.IMPERIAL,
            dailyStepGoal = 999_999,
            weeklyWorkoutGoal = 99,
            useDynamicColor = true,
            hcSyncSteps = true,
            hcSyncWorkouts = false,
            hcSyncCalories = true,
            onboardingCompleted = true
        )
        val createProfile = FirestorePayloadMapper.userProfileCreateMap(profile, "uid_123")
        assertEquals("Athlete", createProfile["displayName"])
        assertEquals(100_000, createProfile["dailyStepGoal"])
        assertEquals(14, createProfile["weeklyWorkoutGoal"])
        assertFalse("Firestore map must not use 'is'-prefixed boolean keys", createProfile.keys.any { it.startsWith("is") })

        val workout = WorkoutEntity(
            id = "w_1",
            userId = "uid_123",
            workoutType = WorkoutType.CARDIO.name,
            title = "A".repeat(150),
            dateKey = "2026-11-22",
            startedAtMs = -10L,
            durationMinutes = 5000,
            caloriesBurned = 99999,
            distanceKm = 5000.0,
            avgHeartRate = 400,
            totalVolumeKg = 999_999.0,
            cardioActivity = "X".repeat(80),
            notes = "N".repeat(600),
            source = WorkoutSource.PULSETRACK.name,
            prCount = 500
        )
        val sets = (1..120).map { idx ->
            ExerciseSetEntity(
                id = "s_$idx",
                workoutId = "w_1",
                userId = "uid_123",
                exerciseName = "Barbell Back Squat",
                muscleGroup = MuscleGroup.LEGS.name,
                setIndex = idx,
                weightKg = 100.0,
                reps = 5,
                completed = true,
                warmup = false,
                pr = false
            )
        }
        val workoutMap = FirestorePayloadMapper.workoutCreateMap(workout, sets, "uid_123")
        assertEquals(100, (workoutMap["title"] as String).length)
        assertEquals(1L, workoutMap["startedAtMs"])
        assertEquals(1440, workoutMap["durationMinutes"])
        assertEquals(15000, workoutMap["caloriesBurned"])
        assertEquals(1000.0, workoutMap["distanceKm"])
        assertEquals(260, workoutMap["avgHeartRate"])
        assertEquals(500000.0, workoutMap["totalVolumeKg"])
        assertEquals(40, (workoutMap["cardioActivity"] as String).length)
        assertEquals(500, (workoutMap["notes"] as String).length)
        assertEquals(100, workoutMap["prCount"])
        assertEquals(100, (workoutMap["sets"] as List<*>).size)
    }

    @Test
    fun qa10_firestoreDtoRoundTripResilientToNullOrUnknownValues() {
        val dtoProfile = FirestoreUserProfile(
            id = "u1",
            userId = "u1",
            displayName = "",
            unitSystem = "UNKNOWN",
            dailyStepGoal = 50L,
            weeklyWorkoutGoal = 50L
        ).toDomain()
        assertEquals("Athlete", dtoProfile.displayName)
        assertEquals(UnitSystem.METRIC, dtoProfile.unitSystem)
        assertEquals(1000, dtoProfile.dailyStepGoal)
        assertEquals(14, dtoProfile.weeklyWorkoutGoal)

        val dtoWorkout = FirestoreWorkout(
            id = "w_remote",
            userId = "u1",
            workoutType = "UNKNOWN",
            title = "",
            dateKey = "2026-11-22",
            startedAtMs = 1000L,
            durationMinutes = 0L,
            source = "UNKNOWN",
            sets = listOf(
                mapOf(
                    "exerciseName" to "Deadlift",
                    "muscleGroup" to "BACK",
                    "setIndex" to 1L,
                    "weightKg" to 140,
                    "reps" to 5L,
                    "completed" to true,
                    "warmup" to false,
                    "pr" to true
                )
            )
        ).toEntities()
        assertEquals(WorkoutType.STRENGTH.name, dtoWorkout.first.workoutType)
        assertEquals("Workout", dtoWorkout.first.title)
        assertEquals(1, dtoWorkout.first.durationMinutes)
        assertEquals(1, dtoWorkout.second.size)
        assertEquals(140.0, dtoWorkout.second.first().weightKg, 0.01)
    }

    @Test
    fun qa11_domainEnumFromRawFallbacksWorkCleanly() {
        assertEquals(MuscleGroup.FULL_BODY, MuscleGroup.fromRaw("invalid"))
        assertEquals(MuscleGroup.CHEST, MuscleGroup.fromRaw("chest"))
        assertEquals(WorkoutType.STRENGTH, WorkoutType.fromRaw("invalid"))
        assertEquals(WorkoutSource.PULSETRACK, WorkoutSource.fromRaw("invalid"))
        assertEquals(UnitSystem.METRIC, UnitSystem.fromRaw("invalid"))
    }

    @Test
    fun qa12_csvSanitizerNeutralizesFormulaInjectionAndRowSplitting() {
        assertEquals("\"'=HYPERLINK(\"\"https://evil.example\"\",\"\"Click\"\")\"", FitnessCalculators.sanitizeCsvCell("=HYPERLINK(\"https://evil.example\",\"Click\")"))
        assertEquals("\"'+1+1\"", FitnessCalculators.sanitizeCsvCell("+1+1"))
        assertEquals("\"'-cmd|' /C calc'!A0\"", FitnessCalculators.sanitizeCsvCell("-cmd|' /C calc'!A0"))
        assertEquals("\"'@SUM(1+1)\"", FitnessCalculators.sanitizeCsvCell("@SUM(1+1)"))
        assertEquals("\"'\t=1+1\"", FitnessCalculators.sanitizeCsvCell("\t=1+1"))
        assertEquals("\"'  =1+1\"", FitnessCalculators.sanitizeCsvCell("  =1+1"))
        assertEquals("\"Upper Body Push\"", FitnessCalculators.sanitizeCsvCell("Upper\r\nBody\nPush"))
    }

    @Test
    fun qa13_entityIdAndDateKeyValidatorsBlockTraversalAndMalformedInputs() {
        assertTrue(FitnessCalculators.isValidEntityId("w_push_123-abc"))
        assertFalse(FitnessCalculators.isValidEntityId(""))
        assertFalse(FitnessCalculators.isValidEntityId("../users/bob_uid/workouts/w1"))
        assertFalse(FitnessCalculators.isValidEntityId("w/123"))
        assertFalse(FitnessCalculators.isValidEntityId("a".repeat(129)))

        assertEquals("2026-11-22", FitnessCalculators.sanitizeDateKey("2026-11-22"))
        val today = FitnessCalculators.todayDateKey()
        assertEquals(today, FitnessCalculators.sanitizeDateKey("../../2026-11-22"))
        assertEquals(today, FitnessCalculators.sanitizeDateKey("invalid-date"))
    }
}
