package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.outlined.ShowChart
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.WorkoutType
import com.example.ui.auth.AuthHelper
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.OnboardingScreen
import com.example.ui.screens.HealthSettingsScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.screens.WorkoutLoggerSheet
import com.example.ui.screens.WorkoutsScreen
import com.example.ui.theme.PulseTrackTheme
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.PulseTrackViewModel
import com.example.ui.viewmodel.WorkoutLoggerViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

private enum class TopDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    TODAY("today", "Today", Icons.Filled.Home, Icons.Outlined.Home),
    WORKOUTS("workouts", "Workouts", Icons.Filled.FitnessCenter, Icons.Outlined.FitnessCenter),
    PROGRESS("progress", "Progress", Icons.AutoMirrored.Filled.ShowChart, Icons.AutoMirrored.Outlined.ShowChart),
    HEALTH("health", "Health", Icons.Filled.MonitorHeart, Icons.Outlined.MonitorHeart)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PulseTrackRoot()
        }
    }
}

@Composable
fun PulseTrackRoot() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        PulseTrackTheme {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                }
            )
        }
    } else {
        key(user.uid) {
            AuthenticatedAppContent(
                currentUserId = user.uid,
                displayName = user.displayName ?: "Athlete",
                email = user.email ?: ""
            )
        }
    }
}

@Composable
private fun AuthenticatedAppContent(
    currentUserId: String,
    displayName: String,
    email: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val mainViewModel: PulseTrackViewModel = viewModel(
        key = "main_$currentUserId",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as PulseTrackApplication
                val c = app.container
                PulseTrackViewModel(
                    repository = c.fitnessRepository,
                    healthConnectManager = c.healthConnectManager,
                    stepSensorManager = c.stepSensorManager,
                    currentUserId = currentUserId,
                    initialDisplayName = displayName,
                    initialEmail = email
                )
            }
        }
    )

    val loggerViewModel: WorkoutLoggerViewModel = viewModel(
        key = "logger_$currentUserId",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as PulseTrackApplication
                val c = app.container
                WorkoutLoggerViewModel(
                    appContext = app.applicationContext,
                    repository = c.fitnessRepository,
                    preferencesStore = c.preferencesStore,
                    currentUserId = currentUserId
                )
            }
        }
    )

    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
    val draft by loggerViewModel.draft.collectAsStateWithLifecycle()

    PulseTrackTheme(useDynamicColor = uiState.settings.useDynamicColor) {
        if (!uiState.settings.onboardingCompleted) {
            OnboardingScreen(
                displayName = uiState.settings.displayName,
                initialUnitSystem = uiState.settings.unitSystem,
                initialStepGoal = uiState.settings.dailyStepGoal,
                initialWorkoutGoal = uiState.settings.weeklyWorkoutGoal,
                onComplete = { unit, stepGoal, workoutGoal ->
                    mainViewModel.completeOnboarding(unit, stepGoal, workoutGoal)
                }
            )
            return@PulseTrackTheme
        }

        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: TopDestination.TODAY.route
        val snackbarHostState = remember { SnackbarHostState() }
        var showWorkoutSheet by remember { mutableStateOf(false) }

        LaunchedEffect(uiState.statusMessage, uiState.errorMessage) {
            val msg = uiState.errorMessage ?: uiState.statusMessage
            if (msg != null) {
                snackbarHostState.showSnackbar(msg)
                mainViewModel.clearBannerMessages()
            }
        }

        val appContainer = (context.applicationContext as PulseTrackApplication).container

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = {
                            loggerViewModel.startNewSession(uiState.selectedDateKey, WorkoutType.STRENGTH)
                            showWorkoutSheet = true
                        },
                        containerColor = VoltLime,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.testTag("log_workout_fab")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Log Workout"
                        )
                    }
                },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        ) {
                            TopDestination.entries.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(dest.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                        selectedTextColor = VoltLime,
                                        indicatorColor = VoltLime,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    ),
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        ) {
                            TopDestination.entries.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(dest.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = { Text(dest.label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                        selectedTextColor = VoltLime,
                                        indicatorColor = VoltLime,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    )
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        NavHost(
                            navController = navController,
                            startDestination = TopDestination.TODAY.route
                        ) {
                            composable(TopDestination.TODAY.route) {
                                TodayScreen(
                                    uiState = uiState,
                                    onSelectDate = mainViewModel::selectDate,
                                    onAddManualSteps = mainViewModel::addManualSteps,
                                    onStartTemplate = { tpl ->
                                        loggerViewModel.startFromTemplate(tpl, uiState.selectedDateKey)
                                        showWorkoutSheet = true
                                    },
                                    onEditWorkout = { w ->
                                        loggerViewModel.loadForEdit(w)
                                        showWorkoutSheet = true
                                    },
                                    onDeleteWorkout = mainViewModel::deleteWorkout,
                                    onStepPermissionChanged = mainViewModel::notifyStepPermissionChanged
                                )
                            }
                            composable(TopDestination.WORKOUTS.route) {
                                WorkoutsScreen(
                                    uiState = uiState,
                                    onStartBlankWorkout = { type ->
                                        loggerViewModel.startNewSession(uiState.selectedDateKey, type)
                                        showWorkoutSheet = true
                                    },
                                    onStartTemplate = { tpl ->
                                        loggerViewModel.startFromTemplate(tpl, uiState.selectedDateKey)
                                        showWorkoutSheet = true
                                    },
                                    onStartFromExercise = { item ->
                                        loggerViewModel.startFromExercise(item, uiState.selectedDateKey)
                                        showWorkoutSheet = true
                                    },
                                    onCreateCustomExercise = mainViewModel::addCustomExercise,
                                    onEditWorkout = { w ->
                                        loggerViewModel.loadForEdit(w)
                                        showWorkoutSheet = true
                                    },
                                    onDeleteWorkout = mainViewModel::deleteWorkout
                                )
                            }
                            composable(TopDestination.PROGRESS.route) {
                                ProgressScreen(
                                    uiState = uiState,
                                    onRangeSelected = mainViewModel::setProgressRange,
                                    onSelectPrExercise = mainViewModel::selectPrExercise
                                )
                            }
                            composable(TopDestination.HEALTH.route) {
                                HealthSettingsScreen(
                                    uiState = uiState,
                                    healthConnectManager = appContainer.healthConnectManager,
                                    onUpdateSettings = mainViewModel::updateSettings,
                                    onRefreshHcStatus = mainViewModel::refreshHealthConnectStatus,
                                    onSyncHealthConnect = mainViewModel::syncHealthConnect,
                                    onExportJson = mainViewModel::exportBackupJson,
                                    onExportCsv = mainViewModel::exportWorkoutsCsv,
                                    onSignOut = {
                                        appContainer.stepSensorManager.stopListening()
                                        AuthHelper.signOut(
                                            credentialManager = credentialManager,
                                            scope = scope,
                                            onBeforeSignOut = {
                                                appContainer.fitnessRepository.clearSessionOnSignOut()
                                            }
                                        )
                                    },
                                    onDeleteAccount = {
                                        mainViewModel.deleteAccountAndData {
                                            AuthHelper.signOut(credentialManager, scope)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            if (showWorkoutSheet) {
                WorkoutLoggerSheet(
                    draft = draft,
                    unitSystem = uiState.settings.unitSystem,
                    exerciseCatalog = uiState.exerciseCatalog,
                    viewModel = loggerViewModel,
                    onCreateCustomExercise = mainViewModel::addCustomExercise,
                    onSaved = { res ->
                        showWorkoutSheet = false
                        val msg = buildString {
                            append("Workout saved")
                            if (res.newPrCount > 0) append(" · ${res.newPrCount} new PR!")
                            if (res.syncedToHealthConnect) append(" · Synced to Health Connect")
                            if (!res.syncedToCloud) append(" · Queued for cloud sync")
                        }
                        mainViewModel.showStatus(msg)
                    },
                    onDismiss = { showWorkoutSheet = false }
                )
            }
        }
    }
}
