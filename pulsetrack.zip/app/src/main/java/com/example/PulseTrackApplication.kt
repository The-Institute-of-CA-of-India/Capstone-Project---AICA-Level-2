package com.example

import android.app.Application
import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.healthconnect.HealthConnectManager
import com.example.data.local.PulseTrackDatabase
import com.example.data.preferences.UserPreferencesStore
import com.example.data.remote.FirestoreSyncSource
import com.example.data.repository.FitnessRepository
import com.example.data.sensor.StepSensorManager
import com.example.data.sync.SyncWorker
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import java.util.concurrent.TimeUnit

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val database: PulseTrackDatabase = PulseTrackDatabase.getInstance(appContext)
    val preferencesStore: UserPreferencesStore = UserPreferencesStore(appContext)
    val firestoreSyncSource: FirestoreSyncSource = FirestoreSyncSource(appContext)
    val healthConnectManager: HealthConnectManager = HealthConnectManager(appContext)
    val fitnessRepository: FitnessRepository = FitnessRepository(
        context = appContext,
        dao = database.fitnessDao(),
        preferencesStore = preferencesStore,
        firestoreSync = firestoreSyncSource,
        healthConnectManager = healthConnectManager
    )
    val stepSensorManager: StepSensorManager = StepSensorManager(
        context = appContext,
        preferencesStore = preferencesStore,
        onDailyStepsDelta = { dateKey, deltaSteps, _ ->
            val uid = Firebase.auth.currentUser?.uid
            if (!uid.isNullOrBlank()) {
                fitnessRepository.recordHardwareStepDelta(uid, dateKey, deltaSteps)
            }
        }
    )
}

class PulseTrackApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        schedulePeriodicSync()
    }

    private fun schedulePeriodicSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<SyncWorker>(1, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "pulsetrack_periodic_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
