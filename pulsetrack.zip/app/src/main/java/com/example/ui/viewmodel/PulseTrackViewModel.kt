package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.healthconnect.HealthConnectManager
import com.example.data.healthconnect.HealthConnectStatus
import com.example.data.healthconnect.HealthConnectAvailability
import com.example.data.repository.FitnessRepository
import com.example.data.sensor.StepSensorManager
import com.example.domain.model.CardioActivity
import com.example.domain.model.DailyMetric
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.ExercisePrSummary
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.UserProfileSettings
import com.example.domain.model.WorkoutLog
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PulseTrackUiState(
    val settings: UserProfileSettings = UserProfileSettings(),
    val workouts: List<WorkoutLog> = emptyList(),
    val dailyMetrics: List<DailyMetric> = emptyList(),
    val exerciseCatalog: List<ExerciseCatalogItem> = ExerciseCatalog.defaultExercises,
    val personalRecords: List<ExercisePrSummary> = emptyList(),
    val selectedDateKey: String = FitnessCalculators.todayDateKey(),
    val progressRangeDays: Int = 7,
    val selectedPrExercise: String? = null,
    val healthConnectStatus: HealthConnectStatus = HealthConnectStatus(HealthConnectAvailability.UNAVAILABLE),
    val isSyncingHc: Boolean = false,
    val isHardwareSensorAvailable: Boolean = false,
    val hasStepPermission: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null
)

private data class TransientUiState(
    val selectedDateKey: String = FitnessCalculators.todayDateKey(),
    val progressRangeDays: Int = 7,
    val selectedPrExercise: String? = null,
    val hcStatus: HealthConnectStatus = HealthConnectStatus(HealthConnectAvailability.UNAVAILABLE),
    val isSyncingHc: Boolean = false,
    val hasStepPermission: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null
)

class PulseTrackViewModel(
    private val repository: FitnessRepository,
    private val healthConnectManager: HealthConnectManager,
    private val stepSensorManager: StepSensorManager,
    private val currentUserId: String,
    initialDisplayName: String,
    initialEmail: String
) : ViewModel() {

    private val transientState = MutableStateFlow(
        TransientUiState(
            hasStepPermission = stepSensorManager.hasActivityRecognitionPermission()
        )
    )

    val uiState: StateFlow<PulseTrackUiState> = combine(
        repository.settingsFlow,
        repository.observeWorkouts(currentUserId),
        repository.observeDailyMetrics(currentUserId),
        repository.observeExerciseCatalog(currentUserId),
        transientState
    ) { settings, workouts, metrics, catalog, transient ->
        val prs = repository.computePersonalRecords(workouts)
        val defaultExercise = transient.selectedPrExercise
            ?.takeIf { name -> prs.any { it.exerciseName == name } }
            ?: prs.firstOrNull()?.exerciseName
        PulseTrackUiState(
            settings = settings,
            workouts = workouts,
            dailyMetrics = metrics,
            exerciseCatalog = catalog,
            personalRecords = prs,
            selectedDateKey = transient.selectedDateKey,
            progressRangeDays = transient.progressRangeDays,
            selectedPrExercise = defaultExercise,
            healthConnectStatus = transient.hcStatus,
            isSyncingHc = transient.isSyncingHc,
            isHardwareSensorAvailable = stepSensorManager.isHardwareSensorAvailable,
            hasStepPermission = transient.hasStepPermission,
            statusMessage = transient.statusMessage,
            errorMessage = transient.errorMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = PulseTrackUiState(
            isHardwareSensorAvailable = stepSensorManager.isHardwareSensorAvailable,
            hasStepPermission = stepSensorManager.hasActivityRecognitionPermission()
        )
    )

    init {
        viewModelScope.launch {
            repository.ensureUserInitialized(currentUserId, initialDisplayName, initialEmail)
            repository.flushPendingToCloud(currentUserId)
        }
        viewModelScope.launch {
            repository.startCloudSyncListeners(currentUserId)
        }
        viewModelScope.launch {
            repository.startDailyMetricsSyncListener(currentUserId)
        }
        refreshHealthConnectStatus()
        if (stepSensorManager.hasActivityRecognitionPermission()) {
            stepSensorManager.startListeningIfPermitted()
        }
    }

    fun selectDate(dateKey: String) {
        transientState.update { it.copy(selectedDateKey = dateKey) }
    }

    fun setProgressRange(days: Int) {
        transientState.update { it.copy(progressRangeDays = days) }
    }

    fun selectPrExercise(exerciseName: String) {
        transientState.update { it.copy(selectedPrExercise = exerciseName) }
    }

    fun clearBannerMessages() {
        transientState.update { it.copy(statusMessage = null, errorMessage = null) }
    }

    fun notifyStepPermissionChanged() {
        val granted = stepSensorManager.hasActivityRecognitionPermission()
        transientState.update { it.copy(hasStepPermission = granted) }
        if (granted) {
            stepSensorManager.startListeningIfPermitted()
        }
    }

    fun addManualSteps(dateKey: String, deltaSteps: Int) {
        viewModelScope.launch {
            val res = repository.addManualSteps(currentUserId, dateKey, deltaSteps)
            if (res.isSuccess) {
                transientState.update { it.copy(statusMessage = "+%,d steps added".format(deltaSteps)) }
            } else {
                transientState.update { it.copy(statusMessage = "+%,d steps saved offline (will sync)".format(deltaSteps)) }
            }
        }
    }

    fun deleteWorkout(workoutId: String) {
        viewModelScope.launch {
            val res = repository.deleteWorkout(currentUserId, workoutId)
            if (res.isSuccess) {
                transientState.update { it.copy(statusMessage = "Workout deleted & PRs recalculated") }
            } else {
                transientState.update { it.copy(statusMessage = "Workout removed locally; cloud sync queued") }
            }
        }
    }

    fun completeOnboarding(unitSystem: UnitSystem, stepGoal: Int, workoutGoal: Int) {
        viewModelScope.launch {
            val current = uiState.value.settings
            val updated = current.copy(
                userId = currentUserId,
                unitSystem = unitSystem,
                dailyStepGoal = stepGoal.coerceIn(1000, 100000),
                weeklyWorkoutGoal = workoutGoal.coerceIn(1, 14),
                onboardingCompleted = true
            )
            repository.saveProfileSettings(updated)
        }
    }

    fun updateSettings(updated: UserProfileSettings) {
        viewModelScope.launch {
            val res = repository.saveProfileSettings(updated.copy(userId = currentUserId))
            if (res.isFailure) {
                Log.w("PulseTrackVM", "Settings saved locally; cloud sync queued")
            }
        }
    }

    fun addCustomExercise(
        name: String,
        muscleGroup: MuscleGroup,
        workoutType: WorkoutType = WorkoutType.STRENGTH,
        cardioActivity: CardioActivity = CardioActivity.RUN
    ) {
        viewModelScope.launch {
            repository.addCustomExercise(currentUserId, name, muscleGroup, workoutType, cardioActivity)
            transientState.update { it.copy(statusMessage = "Added \"$name\" to catalog") }
        }
    }

    fun refreshHealthConnectStatus() {
        viewModelScope.launch {
            val status = healthConnectManager.getStatus()
            transientState.update { it.copy(hcStatus = status) }
        }
    }

    fun syncHealthConnect() {
        viewModelScope.launch {
            transientState.update { it.copy(isSyncingHc = true, errorMessage = null) }
            val result = repository.syncWithHealthConnect(currentUserId)
            val updatedStatus = healthConnectManager.getStatus()
            transientState.update { state ->
                if (result.isSuccess) {
                    state.copy(
                        isSyncingHc = false,
                        hcStatus = updatedStatus,
                        statusMessage = result.getOrNull() ?: "Health Connect synced"
                    )
                } else {
                    state.copy(
                        isSyncingHc = false,
                        hcStatus = updatedStatus,
                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "Health Connect sync failed"
                    )
                }
            }
        }
    }

    suspend fun exportBackupJson(): String = repository.exportBackupJson(currentUserId)

    suspend fun exportWorkoutsCsv(): String = repository.exportWorkoutsCsv(currentUserId)

    fun deleteAccountAndData(onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                stepSensorManager.stopListening()
                val res = repository.deleteAccountAndAllData(currentUserId)
                if (res.isSuccess) {
                    onComplete()
                } else {
                    val err = res.exceptionOrNull()?.localizedMessage ?: "Re-sign in required before deleting account."
                    transientState.update { it.copy(errorMessage = err) }
                }
            } catch (e: CancellationException) {
                throw e
            }
        }
    }

    fun showStatus(message: String) {
        transientState.update { it.copy(statusMessage = message) }
    }
}
