package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 60% Dominant OLED Dark Canvas
val ObsidianBackground = Color(0xFF0D1015)

// 30% Structural Surfaces
val SurfaceObsidian = Color(0xFF11151C)
val SurfaceContainerObsidian = Color(0xFF161B22)
val SurfaceContainerHighObsidian = Color(0xFF1E2530)
val SurfaceContainerHighestObsidian = Color(0xFF262F3D)
val HairlineBorder = Color(0xFF2A3240)

// 10% High-Intent Accents
val VoltLime = Color(0xFFC8F135)
val OnVoltLime = Color(0xFF101600)
val VoltLimeContainer = Color(0xFF273306)
val OnVoltLimeContainer = Color(0xFFDCFA6B)

val SkyCyan = Color(0xFF38BDF8)
val OnSkyCyan = Color(0xFF001F2E)
val SkyCyanContainer = Color(0xFF0B2F42)
val OnSkyCyanContainer = Color(0xFFA5E3FF)

// Semantic Status Colors
val AmberWarning = Color(0xFFF59E0B)
val CoralError = Color(0xFFF43F5E)
val OnCoralError = Color(0xFFFFFFFF)
val CoralErrorContainer = Color(0xFF42101B)

// Text Hierarchy (WCAG AA on Obsidian)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
