package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TabularMetricStyle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.PulseTrackUiState
import java.time.LocalDate

@Composable
fun ProgressScreen(
    uiState: PulseTrackUiState,
    onRangeSelected: (Int) -> Unit,
    onSelectPrExercise: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val rangeDays = uiState.progressRangeDays
    val todayKey = FitnessCalculators.todayDateKey()
    val dateKeys = remember(rangeDays, todayKey) { FitnessCalculators.dateKeysBack(rangeDays) }
    val metricsByDate = remember(uiState.dailyMetrics) { uiState.dailyMetrics.associateBy { it.dateKey } }
    val stepSeries = remember(dateKeys, metricsByDate) {
        dateKeys.map { key -> key to (metricsByDate[key]?.steps ?: 0) }
    }
    val stepGoal = uiState.settings.dailyStepGoal

    val cutoffDate = remember(rangeDays, todayKey) {
        LocalDate.now().minusDays((rangeDays - 1).toLong()).toString()
    }
    val rangeWorkouts = remember(uiState.workouts, cutoffDate) {
        uiState.workouts.filter { it.dateKey >= cutoffDate }.sortedBy { it.startedAtMs }
    }

    val totalWorkouts = rangeWorkouts.size
    val totalTonnageKg = rangeWorkouts.sumOf { it.totalVolumeKg }
    val avgSteps = if (stepSeries.isNotEmpty()) stepSeries.sumOf { it.second } / stepSeries.size else 0

    // Muscle group set distribution
    val muscleCounts = remember(rangeWorkouts) {
        val counts = mutableMapOf<MuscleGroup, Int>()
        rangeWorkouts.filter { it.type == WorkoutType.STRENGTH }.forEach { w ->
            w.sets.filter { it.completed && !it.warmup }.forEach { set ->
                counts[set.muscleGroup] = (counts[set.muscleGroup] ?: 0) + 1
            }
        }
        counts.entries.sortedByDescending { it.value }
    }
    val totalMuscleSets = muscleCounts.sumOf { it.value }.coerceAtLeast(1)

    // 1RM progression points for selected exercise
    val selectedExercise = uiState.selectedPrExercise
    val oneRmSeries = remember(uiState.workouts, selectedExercise) {
        if (selectedExercise == null) emptyList()
        else uiState.workouts
            .sortedBy { it.startedAtMs }
            .mapNotNull { w ->
                val best = w.sets
                    .filter { it.exerciseName == selectedExercise && it.completed && !it.warmup && it.weightKg > 0 && it.reps > 0 }
                    .maxOfOrNull { FitnessCalculators.calculateEpley1Rm(it.weightKg, it.reps) }
                best?.let { w.dateKey to it }
            }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ANALYTICS",
                            style = MaterialTheme.typography.labelLarge,
                            color = SkyCyan
                        )
                        Text(
                            text = "Progress & PRs",
                            style = MaterialTheme.typography.headlineLarge
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(7, 30, 90).forEach { days ->
                            FilterChip(
                                selected = rangeDays == days,
                                onClick = { onRangeSelected(days) },
                                label = { Text("${days}D") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VoltLime,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Summary KPI Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AnalyticsStatBox(
                        label = "Avg Steps",
                        value = "%,d".format(avgSteps),
                        accent = SkyCyan,
                        modifier = Modifier.weight(1f)
                    )
                    AnalyticsStatBox(
                        label = "Sessions",
                        value = totalWorkouts.toString(),
                        accent = VoltLime,
                        modifier = Modifier.weight(1f)
                    )
                    AnalyticsStatBox(
                        label = "Volume",
                        value = FitnessCalculators.formatWeight(totalTonnageKg, uiState.settings.unitSystem),
                        accent = AmberWarning,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Daily Steps Bar Chart
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Daily Steps vs Goal", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "Goal %,d".format(stepGoal),
                                style = MaterialTheme.typography.labelMedium,
                                color = VoltLime
                            )
                        }
                        StepBarChart(
                            values = stepSeries.map { it.second },
                            goal = stepGoal,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                    }
                }
            }

            // Strength 1RM Progression Chart
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Estimated 1RM Progression (Epley)",
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (uiState.personalRecords.isEmpty()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(vertical = 12.dp)
                            ) {
                                Icon(Icons.Filled.ShowChart, contentDescription = null, tint = TextMuted)
                                Text(
                                    text = "Complete strength sets to unlock your 1RM trend curve.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(uiState.personalRecords.take(8), key = { it.exerciseName }) { pr ->
                                    FilterChip(
                                        selected = selectedExercise == pr.exerciseName,
                                        onClick = { onSelectPrExercise(pr.exerciseName) },
                                        label = { Text(pr.exerciseName) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = SkyCyan,
                                            selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                                        )
                                    )
                                }
                            }
                            OneRmLineChart(
                                points = oneRmSeries.map { it.second },
                                unitSystem = uiState.settings.unitSystem,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                            )
                        }
                    }
                }
            }

            // Muscle Group Balance
            if (muscleCounts.isNotEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Muscle Group Balance (${rangeDays}D)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            muscleCounts.forEach { (group, count) ->
                                val fraction = count.toFloat() / totalMuscleSets.toFloat()
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(group.label, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "$count sets",
                                            style = TabularMetricStyle.copy(
                                                fontSize = MaterialTheme.typography.labelMedium.fontSize,
                                                color = TextSecondary
                                            )
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = { fraction },
                                        color = VoltLime,
                                        trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(7.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Personal Records Trophy List
            item {
                Text(
                    text = "Personal Records (All Time)",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            if (uiState.personalRecords.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Text(
                            text = "No PRs recorded yet. Complete working sets in the Workout Logger to automatically calculate your max weight and Epley 1RM.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(18.dp)
                        )
                    }
                }
            } else {
                items(uiState.personalRecords, key = { it.exerciseName }) { pr ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.EmojiEvents,
                                contentDescription = "Personal Record",
                                tint = AmberWarning,
                                modifier = Modifier.size(22.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(pr.exerciseName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${pr.muscleGroup.label} · ${pr.achievedDateKey}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "1RM ${FitnessCalculators.formatWeight(pr.bestEstimated1RmKg, uiState.settings.unitSystem)}",
                                    style = TabularMetricStyle.copy(
                                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                        color = VoltLime
                                    )
                                )
                                Text(
                                    text = "Max ${FitnessCalculators.formatWeight(pr.maxWeightKg, uiState.settings.unitSystem)} × ${pr.bestRepsAtMax}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalyticsStatBox(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Text(
                text = value,
                style = TabularMetricStyle.copy(
                    fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    color = accent
                )
            )
        }
    }
}

@Composable
private fun StepBarChart(
    values: List<Int>,
    goal: Int,
    modifier: Modifier = Modifier
) {
    val trackBg = MaterialTheme.colorScheme.surfaceContainerHighest
    Canvas(modifier = modifier) {
        if (values.isEmpty()) return@Canvas
        val maxVal = maxOf(goal, values.maxOrNull() ?: 1).coerceAtLeast(1)
        val count = values.size
        val slotWidth = size.width / count
        val barWidth = (slotWidth * 0.62f).coerceIn(3.dp.toPx(), 24.dp.toPx())
        val bottomY = size.height - 6.dp.toPx()
        val chartHeight = size.height - 14.dp.toPx()

        // Goal dashed threshold line
        val goalY = bottomY - (goal.toFloat() / maxVal) * chartHeight
        drawLine(
            color = VoltLime.copy(alpha = 0.55f),
            start = Offset(0f, goalY),
            end = Offset(size.width, goalY),
            strokeWidth = 1.5.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
        )

        values.forEachIndexed { idx, steps ->
            val ratio = (steps.toFloat() / maxVal).coerceIn(0f, 1f)
            val barHeight = (ratio * chartHeight).coerceAtLeast(if (steps > 0) 4.dp.toPx() else 2.dp.toPx())
            val x = idx * slotWidth + (slotWidth - barWidth) / 2f
            val y = bottomY - barHeight
            val color = when {
                steps >= goal -> VoltLime
                steps > 0 -> SkyCyan
                else -> trackBg
            }
            drawRoundRect(
                color = color,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }
    }
}

@Composable
private fun OneRmLineChart(
    points: List<Double>,
    unitSystem: UnitSystem,
    modifier: Modifier = Modifier
) {
    if (points.isEmpty()) return
    val converted = points.map { FitnessCalculators.kgToDisplay(it, unitSystem) }
    val minVal = (converted.minOrNull() ?: 0.0) * 0.9
    val maxVal = (converted.maxOrNull() ?: 1.0) * 1.05
    val span = (maxVal - minVal).coerceAtLeast(1.0)

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(modifier = modifier) {
            val pad = 10.dp.toPx()
            val w = size.width - pad * 2
            val h = size.height - pad * 2
            if (converted.size == 1) {
                drawCircle(
                    color = SkyCyan,
                    radius = 6.dp.toPx(),
                    center = Offset(size.width / 2f, size.height / 2f)
                )
                return@Canvas
            }
            val path = Path()
            val coords = converted.mapIndexed { idx, value ->
                val x = pad + (idx.toFloat() / (converted.size - 1)) * w
                val y = pad + h - ((value - minVal) / span).toFloat() * h
                Offset(x, y)
            }
            coords.forEachIndexed { idx, pt ->
                if (idx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(
                path = path,
                color = SkyCyan,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            coords.forEach { pt ->
                drawCircle(color = VoltLime, radius = 4.5.dp.toPx(), center = pt)
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Start: ${FitnessCalculators.formatWeight(points.first(), unitSystem)}",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
            Text(
                text = "Latest: ${FitnessCalculators.formatWeight(points.last(), unitSystem)}",
                style = MaterialTheme.typography.labelMedium,
                color = VoltLime
            )
        }
    }
}
