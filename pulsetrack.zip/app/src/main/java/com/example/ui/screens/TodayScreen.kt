package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.UnitSystem
import com.example.domain.model.WorkoutLog
import com.example.domain.model.WorkoutTemplate
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TabularMetricStyle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.PulseTrackUiState
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    uiState: PulseTrackUiState,
    onSelectDate: (String) -> Unit,
    onAddManualSteps: (String, Int) -> Unit,
    onStartTemplate: (WorkoutTemplate) -> Unit,
    onEditWorkout: (WorkoutLog) -> Unit,
    onDeleteWorkout: (String) -> Unit,
    onStepPermissionChanged: () -> Unit,
    modifier: Modifier = Modifier
) {
    val todayKey = FitnessCalculators.todayDateKey()
    val selectedDateKey = uiState.selectedDateKey
    val metricsByDate = remember(uiState.dailyMetrics) {
        uiState.dailyMetrics.associateBy { it.dateKey }
    }
    val selectedMetric = metricsByDate[selectedDateKey]
    val stepGoal = selectedMetric?.stepGoal ?: uiState.settings.dailyStepGoal
    val currentSteps = selectedMetric?.steps ?: 0
    val activeMinutes = selectedMetric?.activeMinutes ?: 0
    val calories = selectedMetric?.caloriesBurned ?: 0
    val remainingSteps = (stepGoal - currentSteps).coerceAtLeast(0)

    val dayWorkouts = remember(uiState.workouts, selectedDateKey) {
        uiState.workouts.filter { it.dateKey == selectedDateKey }
    }

    val streakDays = remember(uiState.dailyMetrics, uiState.workouts) {
        computeActiveStreak(uiState)
    }

    var showCustomStepSheet by remember { mutableStateOf(false) }
    var pendingDeleteWorkout by remember { mutableStateOf<WorkoutLog?>(null) }

    val activityPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        onStepPermissionChanged()
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (selectedDateKey == todayKey) "TODAY" else selectedDateKey,
                            style = MaterialTheme.typography.labelLarge,
                            color = VoltLime
                        )
                        Text(
                            text = "Hey, ${uiState.settings.displayName.substringBefore(" ")}",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = "Active streak",
                                tint = AmberWarning,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "${streakDays}d streak",
                                style = TabularMetricStyle.copy(
                                    fontSize = MaterialTheme.typography.labelLarge.fontSize,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            // 7-day calendar strip
            item {
                val weekDates = remember(todayKey) {
                    (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    weekDates.forEach { date ->
                        val key = date.toString()
                        val isSelected = key == selectedDateKey
                        val dayMetric = metricsByDate[key]
                        val metGoal = (dayMetric?.steps ?: 0) >= (dayMetric?.stepGoal ?: uiState.settings.dailyStepGoal)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) VoltLime else MaterialTheme.colorScheme.surfaceContainer,
                            border = if (isSelected) null else BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .clickable { onSelectDate(key) }
                                .testTag("day_chip_$key")
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = date.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.US),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else TextSecondary
                                )
                                Text(
                                    text = date.dayOfMonth.toString(),
                                    style = TabularMetricStyle.copy(
                                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Box(
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(5.dp)
                                ) {
                                    if (metGoal) {
                                        Canvas(modifier = Modifier.fillMaxSize()) {
                                            drawCircle(
                                                color = if (isSelected) androidx.compose.ui.graphics.Color(0xFF101600) else VoltLime
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Activity recognition permission prompt if needed on Android 10+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && !uiState.hasStepPermission) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        border = BorderStroke(1.dp, SkyCyan.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Sensors,
                                contentDescription = "Step sensor permission",
                                tint = SkyCyan
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable automatic step counting",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Allow Physical Activity access to count daily steps from your device sensor.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            TextButton(
                                onClick = {
                                    activityPermissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
                                },
                                modifier = Modifier.testTag("grant_step_permission_button")
                            ) {
                                Text("Enable", color = VoltLime, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Hero Step Ring Card
            item {
                StepGoalHeroCard(
                    steps = currentSteps,
                    stepGoal = stepGoal,
                    remainingSteps = remainingSteps,
                    activeMinutes = activeMinutes,
                    calories = calories,
                    onQuickAdd = { delta -> onAddManualSteps(selectedDateKey, delta) },
                    onOpenCustom = { showCustomStepSheet = true }
                )
            }

            // Quick-start templates row
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Quick Start Workout",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(ExerciseCatalog.starterTemplates, key = { it.id }) { tpl ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                border = BorderStroke(1.dp, HairlineBorder),
                                modifier = Modifier
                                    .clickable { onStartTemplate(tpl) }
                                    .testTag("template_${tpl.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = tpl.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = VoltLime
                                    )
                                    Text(
                                        text = tpl.subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Selected Day Workouts
            item {
                Text(
                    text = if (selectedDateKey == todayKey) "Today's Workouts" else "Workouts · $selectedDateKey",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (dayWorkouts.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FitnessCenter,
                                contentDescription = "No workouts logged",
                                tint = TextMuted,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "No workouts logged yet",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Tap a quick-start template above or the + button to log strength sets or cardio.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            } else {
                items(dayWorkouts, key = { it.id }) { workout ->
                    WorkoutSummaryRow(
                        workout = workout,
                        unitSystem = uiState.settings.unitSystem,
                        onEdit = { onEditWorkout(workout) },
                        onDelete = { pendingDeleteWorkout = workout }
                    )
                }
            }
        }
    }

    if (showCustomStepSheet) {
        var customStepsText by remember { mutableStateOf("2000") }
        val parsedSteps = customStepsText.toIntOrNull()?.coerceIn(0, 50000) ?: 0
        ModalBottomSheet(
            onDismissRequest = { showCustomStepSheet = false },
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Add Manual Steps",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Log treadmill, indoor walk, or missed pocket steps for $selectedDateKey.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value = customStepsText,
                    onValueChange = { input ->
                        customStepsText = input.filter { it.isDigit() }.take(6)
                    },
                    label = { Text("Steps to add") },
                    isError = parsedSteps <= 0,
                    supportingText = {
                        if (parsedSteps <= 0) Text("Enter 1 to 50,000 steps")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_steps_input")
                )
                Button(
                    onClick = {
                        if (parsedSteps > 0) {
                            onAddManualSteps(selectedDateKey, parsedSteps)
                            showCustomStepSheet = false
                        }
                    },
                    enabled = parsedSteps > 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VoltLime,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_custom_steps_button")
                ) {
                    Text("Add Steps", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    pendingDeleteWorkout?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeleteWorkout = null },
            title = { Text("Delete workout?") },
            text = {
                Text("This removes \"${target.title}\" and recalculates your personal records and daily active minutes.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteWorkout(target.id)
                        pendingDeleteWorkout = null
                    },
                    modifier = Modifier.testTag("today_confirm_delete_button")
                ) {
                    Text("Delete", color = CoralError)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteWorkout = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun StepGoalHeroCard(
    steps: Int,
    stepGoal: Int,
    remainingSteps: Int,
    activeMinutes: Int,
    calories: Int,
    onQuickAdd: (Int) -> Unit,
    onOpenCustom: () -> Unit
) {
    val progressTarget = (steps.toFloat() / stepGoal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progressTarget,
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "step_ring_progress"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceContainerHighest

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, HairlineBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(204.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 16.dp.toPx()
                    val inset = strokeWidth / 2f
                    val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                    drawArc(
                        color = trackColor,
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = VoltLime,
                        startAngle = 135f,
                        sweepAngle = 270f * animatedProgress,
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.DirectionsWalk,
                        contentDescription = "Steps",
                        tint = VoltLime,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "%,d".format(steps),
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.displayLarge.fontSize,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.testTag("today_step_count")
                    )
                    Text(
                        text = if (remainingSteps == 0) "Goal reached" else "%,d left of %,d".format(remainingSteps, stepGoal),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (remainingSteps == 0) VoltLime else TextSecondary
                    )
                }
            }

            // Secondary inline stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Timer,
                        contentDescription = "Active minutes",
                        tint = SkyCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "$activeMinutes min active",
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.bodyMedium.fontSize,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocalFireDepartment,
                        contentDescription = "Calories burned",
                        tint = AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "%,d kcal".format(calories),
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.bodyMedium.fontSize,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            // Quick step adjustment row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onQuickAdd(500) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("quick_add_500")
                ) {
                    Text("+500", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
                }
                OutlinedButton(
                    onClick = { onQuickAdd(1000) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("quick_add_1000")
                ) {
                    Text("+1,000", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
                }
                OutlinedButton(
                    onClick = onOpenCustom,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("quick_add_custom")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Custom steps",
                        tint = VoltLime,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Custom", style = MaterialTheme.typography.labelLarge, color = VoltLime)
                }
            }
        }
    }
}

@Composable
fun WorkoutSummaryRow(
    workout: WorkoutLog,
    unitSystem: UnitSystem,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val metaLine = buildString {
        append(workout.type.label)
        append(" · ")
        append("${workout.durationMinutes} min")
        if (workout.type == WorkoutType.STRENGTH && workout.totalVolumeKg > 0.0) {
            append(" · ")
            append(FitnessCalculators.formatWeight(workout.totalVolumeKg, unitSystem))
        } else if (workout.type == WorkoutType.CARDIO && workout.distanceKm > 0.0) {
            append(" · ")
            append(FitnessCalculators.formatDistance(workout.distanceKm, unitSystem))
        }
        append(" · ")
        append("${workout.caloriesBurned} kcal")
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() }
            .testTag("workout_card_${workout.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (workout.type == WorkoutType.STRENGTH) VoltLime.copy(alpha = 0.14f) else SkyCyan.copy(alpha = 0.14f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (workout.type == WorkoutType.STRENGTH) Icons.Filled.FitnessCenter else Icons.AutoMirrored.Filled.DirectionsWalk,
                        contentDescription = workout.type.label,
                        tint = if (workout.type == WorkoutType.STRENGTH) VoltLime else SkyCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = workout.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (workout.prCount > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.EmojiEvents,
                                contentDescription = "Personal record",
                                tint = AmberWarning,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "${workout.prCount} PR",
                                style = MaterialTheme.typography.labelMedium,
                                color = AmberWarning
                            )
                        }
                    }
                }
                Text(
                    text = metaLine,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            IconButton(
                onClick = onEdit,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = "Edit workout",
                    tint = TextSecondary
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "Delete workout",
                    tint = TextMuted
                )
            }
        }
    }
}

private fun computeActiveStreak(uiState: PulseTrackUiState): Int {
    val activeDates = buildSet {
        uiState.workouts.forEach { add(it.dateKey) }
        uiState.dailyMetrics.filter { it.steps >= it.stepGoal }.forEach { add(it.dateKey) }
    }
    var streak = 0
    var cursor = LocalDate.now()
    while (activeDates.contains(cursor.toString())) {
        streak++
        cursor = cursor.minusDays(1)
    }
    return streak
}
