package com.example.ui.screens

import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.health.connect.client.PermissionController
import com.example.HealthConnectRationaleActivity
import com.example.data.healthconnect.HealthConnectAvailability
import com.example.data.healthconnect.HealthConnectManager
import com.example.domain.model.UnitSystem
import com.example.domain.model.UserProfileSettings
import com.example.ui.auth.AuthHelper
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TabularMetricStyle
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.PulseTrackUiState
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun HealthSettingsScreen(
    uiState: PulseTrackUiState,
    healthConnectManager: HealthConnectManager,
    onUpdateSettings: (UserProfileSettings) -> Unit,
    onRefreshHcStatus: () -> Unit,
    onSyncHealthConnect: () -> Unit,
    onExportJson: suspend () -> String,
    onExportCsv: suspend () -> String,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val settings = uiState.settings
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var deleteError by remember { mutableStateOf<String?>(null) }

    val hcPermissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) { _ ->
        onRefreshHcStatus()
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "HEALTH & PROFILE",
                        style = MaterialTheme.typography.labelLarge,
                        color = VoltLime
                    )
                    Text(
                        text = settings.displayName,
                        style = MaterialTheme.typography.headlineLarge
                    )
                    if (settings.email.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CloudDone,
                                contentDescription = "Cloud synced",
                                tint = SkyCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = settings.email,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Health Connect Card
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MonitorHeart,
                                contentDescription = "Health Connect",
                                tint = SkyCyan
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Android Health Connect", style = MaterialTheme.typography.titleMedium)
                                val statusLabel = when (uiState.healthConnectStatus.availability) {
                                    HealthConnectAvailability.AVAILABLE ->
                                        if (uiState.healthConnectStatus.allRequiredGranted) "Connected · Permissions active"
                                        else "Available · Permissions needed"
                                    HealthConnectAvailability.UPDATE_REQUIRED -> "App install or update required"
                                    HealthConnectAvailability.UNAVAILABLE -> "Unavailable on this device"
                                }
                                Text(
                                    text = statusLabel,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (uiState.healthConnectStatus.allRequiredGranted) VoltLime else TextSecondary
                                )
                            }
                        }

                        when (uiState.healthConnectStatus.availability) {
                            HealthConnectAvailability.AVAILABLE -> {
                                if (!uiState.healthConnectStatus.allRequiredGranted) {
                                    Button(
                                        onClick = {
                                            hcPermissionLauncher.launch(healthConnectManager.requiredPermissions)
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = SkyCyan,
                                            contentColor = MaterialTheme.colorScheme.onSecondary
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("grant_hc_permissions_button")
                                    ) {
                                        Text("Connect Health Connect", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Button(
                                        onClick = onSyncHealthConnect,
                                        enabled = !uiState.isSyncingHc,
                                        shape = RoundedCornerShape(14.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = VoltLime,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("sync_hc_button")
                                    ) {
                                        if (uiState.isSyncingHc) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(18.dp),
                                                strokeWidth = 2.dp,
                                                color = MaterialTheme.colorScheme.onPrimary
                                            )
                                        } else {
                                            Icon(Icons.Filled.Sync, contentDescription = "Sync now")
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Sync Steps & Workouts Now", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                            HealthConnectAvailability.UPDATE_REQUIRED -> {
                                OutlinedButton(
                                    onClick = {
                                        runCatching {
                                            context.startActivity(healthConnectManager.buildInstallProviderIntent())
                                        }
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Install / Update Health Connect")
                                }
                            }
                            HealthConnectAvailability.UNAVAILABLE -> {
                                Text(
                                    text = "Health Connect requires Android 9+ with Google Play services. PulseTrack continues tracking locally via device sensors and Firestore.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AmberWarning
                                )
                            }
                        }

                        // Granular Health Connect Toggles
                        ToggleSettingRow(
                            title = "Sync Daily Steps",
                            subtitle = "Read aggregated steps from wearables",
                            checked = settings.hcSyncSteps,
                            onCheckedChange = { onUpdateSettings(settings.copy(hcSyncSteps = it)) }
                        )
                        ToggleSettingRow(
                            title = "Sync Workouts",
                            subtitle = "Write logged workouts & import external sessions",
                            checked = settings.hcSyncWorkouts,
                            onCheckedChange = { onUpdateSettings(settings.copy(hcSyncWorkouts = it)) }
                        )
                        ToggleSettingRow(
                            title = "Sync Calories",
                            subtitle = "Include total calories burned on workout sync",
                            checked = settings.hcSyncCalories,
                            onCheckedChange = { onUpdateSettings(settings.copy(hcSyncCalories = it)) }
                        )
                    }
                }
            }

            // Units & Goals Card
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Units & Targets", style = MaterialTheme.typography.titleMedium)

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            UnitSystem.entries.forEach { unit ->
                                FilterChip(
                                    selected = settings.unitSystem == unit,
                                    onClick = { onUpdateSettings(settings.copy(unitSystem = unit)) },
                                    label = {
                                        Text(if (unit == UnitSystem.METRIC) "Metric (kg · km)" else "Imperial (lbs · mi)")
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VoltLime,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        var sliderStepGoal by remember(settings.dailyStepGoal) {
                            mutableIntStateOf(settings.dailyStepGoal.coerceIn(3000, 25000))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Daily Step Goal", style = MaterialTheme.typography.bodyLarge)
                            Text(
                                text = "%,d".format(sliderStepGoal),
                                style = TabularMetricStyle.copy(
                                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                    color = VoltLime
                                )
                            )
                        }
                        Slider(
                            value = sliderStepGoal.toFloat(),
                            onValueChange = { raw ->
                                sliderStepGoal = ((raw / 500f).roundToInt() * 500).coerceIn(3000, 25000)
                            },
                            onValueChangeFinished = {
                                if (sliderStepGoal != settings.dailyStepGoal) {
                                    onUpdateSettings(settings.copy(dailyStepGoal = sliderStepGoal))
                                }
                            },
                            valueRange = 3000f..25000f,
                            colors = SliderDefaults.colors(thumbColor = VoltLime, activeTrackColor = VoltLime)
                        )

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            ToggleSettingRow(
                                title = "Material You Dynamic Accent",
                                subtitle = "Blend system wallpaper tones on Android 12+",
                                checked = settings.useDynamicColor,
                                onCheckedChange = { onUpdateSettings(settings.copy(useDynamicColor = it)) }
                            )
                        }
                    }
                }
            }

            // Backup, Privacy & Account Actions
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Backup, Privacy & Account", style = MaterialTheme.typography.titleMedium)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val csv = onExportCsv()
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/csv"
                                            putExtra(Intent.EXTRA_SUBJECT, "PulseTrack Workouts CSV")
                                            putExtra(Intent.EXTRA_TEXT, csv)
                                        }
                                        runCatching {
                                            context.startActivity(Intent.createChooser(shareIntent, "Export CSV"))
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export CSV")
                            }

                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val json = onExportJson()
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/json"
                                            putExtra(Intent.EXTRA_SUBJECT, "PulseTrack Backup JSON")
                                            putExtra(Intent.EXTRA_TEXT, json)
                                        }
                                        runCatching {
                                            context.startActivity(Intent.createChooser(shareIntent, "Export JSON"))
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export JSON")
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                context.startActivity(Intent(context, HealthConnectRationaleActivity::class.java))
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Filled.PrivacyTip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Privacy Policy & Health Connect Disclosures")
                        }

                        OutlinedButton(
                            onClick = onSignOut,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign Out")
                        }

                        TextButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("delete_account_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteForever,
                                contentDescription = "Delete account",
                                tint = CoralError,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete Account & All Cloud Data", color = CoralError)
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = {
                showDeleteConfirm = false
                deleteError = null
            },
            title = { Text("Delete Account & Data?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This permanently erases your Firestore cloud workouts, daily step history, profile settings, and local cache. This action cannot be undone.")
                    if (deleteError != null) {
                        Text(
                            text = deleteError ?: "",
                            color = CoralError,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        deleteError = null
                        if (AuthHelper.hasRecentSignIn()) {
                            showDeleteConfirm = false
                            onDeleteAccount()
                        } else {
                            AuthHelper.reauthenticateWithGoogle(
                                context = context,
                                credentialManager = credentialManager,
                                scope = scope,
                                onReauthSuccess = {
                                    showDeleteConfirm = false
                                    onDeleteAccount()
                                },
                                onReauthError = { msg ->
                                    deleteError = msg
                                },
                                onReauthCancelled = {
                                    deleteError = "Verification cancelled."
                                }
                            )
                        }
                    }
                ) {
                    Text("Delete Permanently", color = CoralError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        deleteError = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ToggleSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = VoltLime
            )
        )
    }
}
