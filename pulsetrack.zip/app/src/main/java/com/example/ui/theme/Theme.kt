package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

val PulseTrackDarkColorScheme = darkColorScheme(
    primary = VoltLime,
    onPrimary = OnVoltLime,
    primaryContainer = VoltLimeContainer,
    onPrimaryContainer = OnVoltLimeContainer,
    secondary = SkyCyan,
    onSecondary = OnSkyCyan,
    secondaryContainer = SkyCyanContainer,
    onSecondaryContainer = OnSkyCyanContainer,
    tertiary = AmberWarning,
    background = ObsidianBackground,
    onBackground = TextPrimary,
    surface = SurfaceObsidian,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceContainerHighObsidian,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = ObsidianBackground,
    surfaceContainerLow = SurfaceObsidian,
    surfaceContainer = SurfaceContainerObsidian,
    surfaceContainerHigh = SurfaceContainerHighObsidian,
    surfaceContainerHighest = SurfaceContainerHighestObsidian,
    outline = HairlineBorder,
    outlineVariant = HairlineBorder,
    error = CoralError,
    onError = OnCoralError,
    errorContainer = CoralErrorContainer
)

val PulseTrackShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PulseTrackTheme(
    useDynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = if (useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context).copy(
            background = ObsidianBackground,
            surface = SurfaceObsidian,
            surfaceContainer = SurfaceContainerObsidian,
            surfaceContainerHigh = SurfaceContainerHighObsidian,
            surfaceContainerHighest = SurfaceContainerHighestObsidian,
            outline = HairlineBorder,
            outlineVariant = HairlineBorder
        )
    } else {
        PulseTrackDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = PulseTrackShapes,
        content = content
    )
}
