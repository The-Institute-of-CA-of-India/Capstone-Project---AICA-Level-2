package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.repository.SaveWorkoutResult
import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TabularMetricStyle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.ActiveWorkoutDraft
import com.example.ui.viewmodel.WorkoutLoggerViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutLoggerSheet(
    draft: ActiveWorkoutDraft,
    unitSystem: UnitSystem,
    exerciseCatalog: List<ExerciseCatalogItem>,
    viewModel: WorkoutLoggerViewModel,
    onCreateCustomExercise: (String, MuscleGroup, WorkoutType, CardioActivity) -> Unit,
    onSaved: (SaveWorkoutResult) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var pickerMode by remember { mutableStateOf<WorkoutType?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainer
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 720.dp)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header + Stopwatch
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (draft.editingWorkoutId == null) "ACTIVE WORKOUT" else "EDIT WORKOUT",
                            style = MaterialTheme.typography.labelLarge,
                            color = VoltLime
                        )
                        Text(
                            text = if (draft.useStopwatchDuration) {
                                FitnessCalculators.formatTimerSeconds(draft.elapsedSeconds)
                            } else {
                                "${draft.manualDurationMin} min"
                            },
                            style = TabularMetricStyle.copy(
                                fontSize = MaterialTheme.typography.headlineLarge.fontSize,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (draft.editingWorkoutId == null) {
                            OutlinedButton(
                                onClick = { viewModel.toggleStopwatch() },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, HairlineBorder),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("toggle_stopwatch_button")
                            ) {
                                Icon(
                                    imageVector = if (draft.isStopwatchRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = if (draft.isStopwatchRunning) "Pause timer" else "Start timer",
                                    tint = VoltLime,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (draft.isStopwatchRunning) "Pause" else "Start",
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("close_logger_button")
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Close logger")
                        }
                    }
                }
            }

            // Tabbed Strength vs Cardio switch
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WorkoutType.entries.forEach { wType ->
                        val selected = draft.type == wType
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.setWorkoutType(wType) },
                            label = {
                                Text(
                                    wType.label,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (wType == WorkoutType.STRENGTH) VoltLime else SkyCyan,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("workout_type_${wType.name.lowercase()}")
                        )
                    }
                }
            }

            // Title input
            item {
                OutlinedTextField(
                    value = draft.title,
                    onValueChange = { viewModel.setTitle(it) },
                    label = { Text("Workout title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("workout_title_input")
                )
            }

            // Rest Timer Strip (Strength)
            if (draft.type == WorkoutType.STRENGTH) {
                item {
                    RestTimerBar(
                        remainingSeconds = draft.restRemainingSeconds,
                        onStartRest = { viewModel.startRestTimer(it) },
                        onCancelRest = { viewModel.cancelRestTimer() }
                    )
                }

                // Grouped exercises & set rows
                val grouped = draft.sets.groupBy { it.exerciseName }
                grouped.forEach { (exerciseName, sets) ->
                    item(key = "header_$exerciseName") {
                        val muscle = sets.firstOrNull()?.muscleGroup ?: MuscleGroup.FULL_BODY
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = exerciseName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = VoltLime
                                )
                                Text(
                                    text = muscle.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary
                                )
                            }
                            TextButton(
                                onClick = { viewModel.addExerciseToSession(exerciseName, muscle) }
                            ) {
                                Text("+ Add Set", color = SkyCyan)
                            }
                        }
                    }

                    items(sets, key = { it.id }) { setItem ->
                        SetInputRow(
                            setItem = setItem,
                            displayIndex = sets.indexOf(setItem) + 1,
                            unitSystem = unitSystem,
                            onWeightChange = { viewModel.updateSetWeight(setItem.id, it, unitSystem) },
                            onRepsChange = { viewModel.updateSetReps(setItem.id, it) },
                            onToggleWarmup = { viewModel.toggleSetWarmup(setItem.id) },
                            onToggleCompleted = { viewModel.toggleSetCompleted(setItem.id) },
                            onDelete = { viewModel.removeSet(setItem.id) }
                        )
                    }
                }

                item {
                    val strengthCount = remember(exerciseCatalog) {
                        exerciseCatalog.count { it.workoutType == WorkoutType.STRENGTH }
                    }
                    OutlinedButton(
                        onClick = { pickerMode = WorkoutType.STRENGTH },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, VoltLime.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("add_exercise_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Add exercise", tint = VoltLime)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Add Strength Exercise ($strengthCount)",
                            color = VoltLime,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                // Cardio Logger
                item {
                    CardioLoggerSection(
                        draft = draft,
                        unitSystem = unitSystem,
                        cardioCount = exerciseCatalog.count { it.workoutType == WorkoutType.CARDIO },
                        viewModel = viewModel,
                        onOpenCardioPicker = { pickerMode = WorkoutType.CARDIO }
                    )
                }
            }

            // Duration override & Notes
            item {
                var durationStr by remember(draft.editingWorkoutId, draft.startedAtMs) {
                    mutableStateOf(draft.manualDurationMin.toString())
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = durationStr,
                        onValueChange = { raw ->
                            val clean = raw.filter { it.isDigit() }.take(4)
                            durationStr = clean
                            clean.toIntOrNull()?.takeIf { it > 0 }?.let {
                                viewModel.setManualDurationMinutes(it)
                            }
                        },
                        label = { Text("Duration (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("workout_duration_input")
                    )
                    FilterChip(
                        selected = draft.useStopwatchDuration,
                        onClick = { viewModel.setUseStopwatchDuration(!draft.useStopwatchDuration) },
                        label = { Text("Use Live Timer") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VoltLime,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("use_live_timer_chip")
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = draft.notes,
                    onValueChange = { viewModel.setNotes(it) },
                    label = { Text("Session notes (optional)") },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("workout_notes_input")
                )
            }

            if (draft.validationError != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = draft.validationError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onError,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = { viewModel.saveWorkout(onSaved) },
                    enabled = !draft.isSaving,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VoltLime,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("save_workout_button")
                ) {
                    if (draft.isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Filled.Check, contentDescription = "Save workout")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (draft.editingWorkoutId == null) "Finish & Save Workout" else "Update Workout",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.navigationBarsPadding().height(20.dp))
            }
        }
    }

    pickerMode?.let { mode ->
        ExerciseCatalogPickerDialog(
            catalog = exerciseCatalog,
            initialWorkoutType = mode,
            lockWorkoutType = true,
            onSelect = { item ->
                if (item.workoutType == WorkoutType.CARDIO) {
                    viewModel.selectCardioExercise(item)
                } else {
                    viewModel.addExerciseToSession(item.name, item.muscleGroup)
                }
                pickerMode = null
            },
            onCreateCustom = { name, group, wType, cardioAct ->
                onCreateCustomExercise(name, group, wType, cardioAct)
                if (wType == WorkoutType.CARDIO) {
                    viewModel.selectCardioExercise(
                        ExerciseCatalogItem(
                            name = name,
                            muscleGroup = group,
                            workoutType = WorkoutType.CARDIO,
                            cardioActivity = cardioAct,
                            met = cardioAct.met,
                            isCustom = true
                        )
                    )
                } else {
                    viewModel.addExerciseToSession(name, group)
                }
                pickerMode = null
            },
            onDismiss = { pickerMode = null }
        )
    }
}

@Composable
private fun RestTimerBar(
    remainingSeconds: Int,
    onStartRest: (Int) -> Unit,
    onCancelRest: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        border = BorderStroke(1.dp, if (remainingSeconds > 0) SkyCyan else HairlineBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Timer,
                    contentDescription = "Rest countdown",
                    tint = if (remainingSeconds > 0) SkyCyan else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = if (remainingSeconds > 0) {
                        "Rest ${FitnessCalculators.formatTimerSeconds(remainingSeconds.toLong())}"
                    } else {
                        "Rest Timer"
                    },
                    style = TabularMetricStyle.copy(
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        color = if (remainingSeconds > 0) SkyCyan else MaterialTheme.colorScheme.onSurface
                    )
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (remainingSeconds > 0) {
                    TextButton(
                        onClick = onCancelRest,
                        modifier = Modifier.testTag("skip_rest_button")
                    ) {
                        Text("Skip", color = AmberWarning)
                    }
                } else {
                    listOf(60, 90, 120).forEach { sec ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier
                                .clickable { onStartRest(sec) }
                                .testTag("rest_preset_${sec}s")
                        ) {
                            Text(
                                text = "${sec}s",
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetInputRow(
    setItem: ExerciseSetItem,
    displayIndex: Int,
    unitSystem: UnitSystem,
    onWeightChange: (Double) -> Unit,
    onRepsChange: (Int) -> Unit,
    onToggleWarmup: () -> Unit,
    onToggleCompleted: () -> Unit,
    onDelete: () -> Unit
) {
    val displayWeight = FitnessCalculators.kgToDisplay(setItem.weightKg, unitSystem)
    var weightText by remember(setItem.id, unitSystem) {
        mutableStateOf(
            if (displayWeight <= 0.0) "" else String.format(Locale.US, "%.1f", displayWeight).removeSuffix(".0")
        )
    }
    var repsText by remember(setItem.id) {
        mutableStateOf(if (setItem.reps <= 0) "" else setItem.reps.toString())
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (setItem.completed) VoltLime.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceContainerHigh,
        border = BorderStroke(1.dp, if (setItem.completed) VoltLime.copy(alpha = 0.5f) else HairlineBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (setItem.warmup) AmberWarning.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier
                    .size(34.dp)
                    .clickable { onToggleWarmup() }
                    .testTag("warmup_toggle_${setItem.id}")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (setItem.warmup) "W" else "$displayIndex",
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.labelLarge.fontSize,
                            color = if (setItem.warmup) AmberWarning else MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            OutlinedTextField(
                value = weightText,
                onValueChange = { raw ->
                    val filtered = raw.filter { it.isDigit() || it == '.' }.take(6)
                    weightText = filtered
                    onWeightChange(filtered.toDoubleOrNull() ?: 0.0)
                },
                label = { Text(unitSystem.weightLabel) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
                value = repsText,
                onValueChange = { raw ->
                    val filtered = raw.filter { it.isDigit() }.take(3)
                    repsText = filtered
                    onRepsChange(filtered.toIntOrNull() ?: 0)
                },
                label = { Text("Reps") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(0.8f)
            )

            Checkbox(
                checked = setItem.completed,
                onCheckedChange = { onToggleCompleted() },
                colors = CheckboxDefaults.colors(
                    checkedColor = VoltLime,
                    checkmarkColor = MaterialTheme.colorScheme.onPrimary
                )
            )

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "Remove set",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun CardioLoggerSection(
    draft: ActiveWorkoutDraft,
    unitSystem: UnitSystem,
    cardioCount: Int,
    viewModel: WorkoutLoggerViewModel,
    onOpenCardioPicker: () -> Unit
) {
    val displayDist = FitnessCalculators.kmToDisplay(draft.distanceKm, unitSystem)
    var distStr by remember(draft.editingWorkoutId, draft.startedAtMs, unitSystem) {
        mutableStateOf(String.format(Locale.US, "%.2f", displayDist))
    }
    var hrStr by remember(draft.editingWorkoutId, draft.startedAtMs) {
        mutableStateOf(if (draft.avgHeartRate > 0) draft.avgHeartRate.toString() else "")
    }
    val effectiveDuration = if (draft.useStopwatchDuration) {
        ((draft.elapsedSeconds / 60L).toInt()).coerceAtLeast(1)
    } else {
        draft.manualDurationMin
    }
    val livePace = FitnessCalculators.formatPace(effectiveDuration, draft.distanceKm, unitSystem)
    val estCalories = FitnessCalculators.estimateCardioCalories(
        activity = draft.cardioActivity,
        durationMinutes = effectiveDuration,
        customMet = draft.cardioMet
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Selected Cardio Exercise Picker Card (28+ cardio training exercises)
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, SkyCyan.copy(alpha = 0.55f)),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenCardioPicker() }
                .testTag("choose_cardio_exercise_button")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.DirectionsRun,
                        contentDescription = "Cardio exercise",
                        tint = SkyCyan
                    )
                    Column {
                        Text(
                            text = draft.cardioExerciseName.ifBlank { draft.cardioActivity.label },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${draft.cardioActivity.label} · ${String.format(Locale.US, "%.1f", draft.cardioMet)} MET",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
                Text(
                    text = "Browse ($cardioCount)",
                    style = MaterialTheme.typography.labelLarge,
                    color = SkyCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CardioActivity.entries) { activity ->
                FilterChip(
                    selected = draft.cardioActivity == activity,
                    onClick = { viewModel.setCardioActivity(activity) },
                    label = { Text(activity.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = SkyCyan,
                        selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                    )
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = distStr,
                onValueChange = { raw ->
                    val clean = raw.filter { it.isDigit() || it == '.' }.take(6)
                    distStr = clean
                    clean.toDoubleOrNull()?.let { viewModel.setDistanceFromDisplay(it, unitSystem) }
                },
                label = { Text("Distance (${unitSystem.distanceLabel})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hrStr,
                onValueChange = { raw ->
                    val clean = raw.filter { it.isDigit() }.take(3)
                    hrStr = clean
                    viewModel.setAvgHeartRate(clean.toIntOrNull() ?: 0)
                },
                label = { Text("Avg HR (bpm)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Calculated Pace", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text(
                        text = livePace,
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.titleLarge.fontSize,
                            color = SkyCyan
                        )
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Est. Burn", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text(
                        text = "$estCalories kcal",
                        style = TabularMetricStyle.copy(
                            fontSize = MaterialTheme.typography.titleLarge.fontSize,
                            color = VoltLime
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun ExerciseCatalogPickerDialog(
    catalog: List<ExerciseCatalogItem>,
    initialWorkoutType: WorkoutType? = WorkoutType.STRENGTH,
    lockWorkoutType: Boolean = false,
    onSelect: (ExerciseCatalogItem) -> Unit,
    onCreateCustom: (String, MuscleGroup, WorkoutType, CardioActivity) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var activeTypeFilter by remember(initialWorkoutType) { mutableStateOf(initialWorkoutType) }
    var selectedMuscle by remember { mutableStateOf<MuscleGroup?>(null) }
    var selectedCardio by remember { mutableStateOf<CardioActivity?>(null) }
    var creatingCustom by remember { mutableStateOf(false) }
    var customName by remember { mutableStateOf("") }
    var customWorkoutType by remember(initialWorkoutType) {
        mutableStateOf(initialWorkoutType ?: WorkoutType.STRENGTH)
    }
    var customGroup by remember { mutableStateOf(MuscleGroup.FULL_BODY) }
    var customCardioActivity by remember { mutableStateOf(CardioActivity.RUN) }

    val filtered = remember(catalog, query, activeTypeFilter, selectedMuscle, selectedCardio) {
        catalog.filter { item ->
            val typeMatch = activeTypeFilter == null || item.workoutType == activeTypeFilter
            val subFilterMatch = when (activeTypeFilter) {
                WorkoutType.STRENGTH -> selectedMuscle == null || item.muscleGroup == selectedMuscle
                WorkoutType.CARDIO -> selectedCardio == null || item.cardioActivity == selectedCardio
                null -> true
            }
            val queryMatch = query.isBlank() ||
                item.name.contains(query, ignoreCase = true) ||
                item.muscleGroup.label.contains(query, ignoreCase = true) ||
                item.cardioActivity.label.contains(query, ignoreCase = true)
            typeMatch && subFilterMatch && queryMatch
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = when {
                        creatingCustom -> "New Custom Exercise"
                        activeTypeFilter == WorkoutType.CARDIO -> "Cardio Exercises (${filtered.size})"
                        activeTypeFilter == WorkoutType.STRENGTH -> "Strength Exercises (${filtered.size})"
                        else -> "Exercise Library (${filtered.size})"
                    }
                )
                if (!creatingCustom) {
                    Text(
                        text = "${catalog.size} total exercises available",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                }
            }
        },
        text = {
            if (creatingCustom) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WorkoutType.entries.forEach { wType ->
                            FilterChip(
                                selected = customWorkoutType == wType,
                                onClick = { customWorkoutType = wType },
                                label = { Text(wType.label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it.take(80) },
                        label = { Text("Exercise name") },
                        singleLine = true,
                        isError = customName.isBlank(),
                        supportingText = {
                            if (customName.isBlank()) Text("Enter a name to save")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_exercise_name_input")
                    )
                    if (customWorkoutType == WorkoutType.STRENGTH) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(MuscleGroup.entries) { group ->
                                FilterChip(
                                    selected = customGroup == group,
                                    onClick = { customGroup = group },
                                    label = { Text(group.label) }
                                )
                            }
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(CardioActivity.entries) { act ->
                                FilterChip(
                                    selected = customCardioActivity == act,
                                    onClick = { customCardioActivity = act },
                                    label = { Text(act.label) }
                                )
                            }
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("Search strength & cardio") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("exercise_search_input")
                    )
                    if (!lockWorkoutType) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = activeTypeFilter == null,
                                onClick = {
                                    activeTypeFilter = null
                                    selectedMuscle = null
                                    selectedCardio = null
                                },
                                label = { Text("All (${catalog.size})") }
                            )
                            FilterChip(
                                selected = activeTypeFilter == WorkoutType.STRENGTH,
                                onClick = {
                                    activeTypeFilter = WorkoutType.STRENGTH
                                    selectedCardio = null
                                },
                                label = { Text("Strength (${catalog.count { it.workoutType == WorkoutType.STRENGTH }})") }
                            )
                            FilterChip(
                                selected = activeTypeFilter == WorkoutType.CARDIO,
                                onClick = {
                                    activeTypeFilter = WorkoutType.CARDIO
                                    selectedMuscle = null
                                },
                                label = { Text("Cardio (${catalog.count { it.workoutType == WorkoutType.CARDIO }})") }
                            )
                        }
                    }

                    if (activeTypeFilter == WorkoutType.STRENGTH) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedMuscle == null,
                                    onClick = { selectedMuscle = null },
                                    label = { Text("All") }
                                )
                            }
                            items(MuscleGroup.entries) { group ->
                                FilterChip(
                                    selected = selectedMuscle == group,
                                    onClick = { selectedMuscle = group },
                                    label = { Text(group.label) }
                                )
                            }
                        }
                    } else if (activeTypeFilter == WorkoutType.CARDIO) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item {
                                FilterChip(
                                    selected = selectedCardio == null,
                                    onClick = { selectedCardio = null },
                                    label = { Text("All") }
                                )
                            }
                            items(CardioActivity.entries) { act ->
                                FilterChip(
                                    selected = selectedCardio == act,
                                    onClick = { selectedCardio = act },
                                    label = { Text(act.label) }
                                )
                            }
                        }
                    }

                    if (filtered.isEmpty()) {
                        Text(
                            text = "No matching exercises. Tap + Custom Exercise below to create one.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        LazyColumn(modifier = Modifier.heightIn(max = 280.dp)) {
                            items(
                                filtered,
                                key = { "${it.workoutType.name}_${it.name.lowercase()}" }
                            ) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelect(item) }
                                        .padding(vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                        Text(item.name, style = MaterialTheme.typography.bodyLarge)
                                        val tagText = if (item.workoutType == WorkoutType.CARDIO) {
                                            "Cardio · ${item.cardioActivity.label} · ${String.format(Locale.US, "%.1f", item.met)} MET"
                                        } else {
                                            "Strength · ${item.muscleGroup.label}"
                                        }
                                        Text(
                                            text = tagText,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (item.workoutType == WorkoutType.CARDIO) SkyCyan else TextSecondary
                                        )
                                    }
                                    if (item.isCustom) {
                                        Text(
                                            text = "Custom",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = VoltLime
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (creatingCustom) {
                TextButton(
                    enabled = customName.trim().isNotEmpty(),
                    onClick = {
                        val trimmed = customName.trim()
                        if (trimmed.isNotEmpty()) {
                            onCreateCustom(trimmed, customGroup, customWorkoutType, customCardioActivity)
                        }
                    },
                    modifier = Modifier.testTag("confirm_custom_exercise_button")
                ) {
                    Text(
                        text = "Add & Select",
                        color = if (customName.trim().isNotEmpty()) VoltLime else TextMuted
                    )
                }
            } else {
                TextButton(
                    onClick = { creatingCustom = true },
                    modifier = Modifier.testTag("new_custom_exercise_button")
                ) {
                    Text("+ Custom Exercise", color = VoltLime)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (creatingCustom) creatingCustom = false else onDismiss()
                }
            ) {
                Text(if (creatingCustom) "Back" else "Cancel")
            }
        }
    )
}
