package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.WorkoutLog
import com.example.domain.model.WorkoutTemplate
import com.example.domain.model.WorkoutType
import com.example.ui.theme.CoralError
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import com.example.ui.viewmodel.PulseTrackUiState

@Composable
fun WorkoutsScreen(
    uiState: PulseTrackUiState,
    onStartBlankWorkout: (WorkoutType) -> Unit,
    onStartTemplate: (WorkoutTemplate) -> Unit,
    onStartFromExercise: (ExerciseCatalogItem) -> Unit,
    onCreateCustomExercise: (String, MuscleGroup, WorkoutType, CardioActivity) -> Unit,
    onEditWorkout: (WorkoutLog) -> Unit,
    onDeleteWorkout: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var filterType by remember { mutableStateOf<WorkoutType?>(null) }
    var pendingDeleteWorkout by remember { mutableStateOf<WorkoutLog?>(null) }
    var showExerciseLibrary by remember { mutableStateOf(false) }

    val filteredWorkouts = remember(uiState.workouts, filterType) {
        if (filterType == null) uiState.workouts
        else uiState.workouts.filter { it.type == filterType }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "TRAINING LOG",
                        style = MaterialTheme.typography.labelLarge,
                        color = VoltLime
                    )
                    Text(
                        text = "Workouts & Templates",
                        style = MaterialTheme.typography.headlineLarge
                    )
                }
            }

            // Starter templates
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "1-Tap Starter Templates",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextSecondary
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ExerciseCatalog.starterTemplates, key = { it.id }) { tpl ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                border = BorderStroke(1.dp, HairlineBorder),
                                modifier = Modifier
                                    .clickable { onStartTemplate(tpl) }
                                    .testTag("workouts_template_${tpl.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = tpl.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = VoltLime
                                    )
                                    Text(
                                        text = tpl.subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick launch Strength or Cardio + 100+ Exercise Library browser
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onStartBlankWorkout(WorkoutType.STRENGTH) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = VoltLime
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("new_strength_button")
                        ) {
                            Text("+ Strength")
                        }
                        Button(
                            onClick = { onStartBlankWorkout(WorkoutType.CARDIO) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.secondary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("new_cardio_button")
                        ) {
                            Text("+ Cardio")
                        }
                    }

                    val strengthTotal = uiState.exerciseCatalog.count { it.workoutType == WorkoutType.STRENGTH }
                    val cardioTotal = uiState.exerciseCatalog.count { it.workoutType == WorkoutType.CARDIO }
                    OutlinedButton(
                        onClick = { showExerciseLibrary = true },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SkyCyan.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("browse_exercise_library_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Browse exercise library",
                            tint = SkyCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Browse Exercise Library (${uiState.exerciseCatalog.size}: $strengthTotal Strength · $cardioTotal Cardio)",
                            color = SkyCyan,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            // Filter row
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filterType == null,
                        onClick = { filterType = null },
                        label = { Text("All (${uiState.workouts.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VoltLime,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                    FilterChip(
                        selected = filterType == WorkoutType.STRENGTH,
                        onClick = { filterType = WorkoutType.STRENGTH },
                        label = { Text("Strength") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VoltLime,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                    FilterChip(
                        selected = filterType == WorkoutType.CARDIO,
                        onClick = { filterType = WorkoutType.CARDIO },
                        label = { Text("Cardio") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary,
                            selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                        )
                    )
                }
            }

            if (filteredWorkouts.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FitnessCenter,
                                contentDescription = "No workouts",
                                tint = TextMuted,
                                modifier = Modifier.size(32.dp)
                            )
                            Text("No matching workouts", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "Launch a starter template, browse 100+ exercises, or log a custom session.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredWorkouts, key = { it.id }) { workout ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "${workout.dateKey} · ${workout.source.label}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextMuted
                        )
                        WorkoutSummaryRow(
                            workout = workout,
                            unitSystem = uiState.settings.unitSystem,
                            onEdit = { onEditWorkout(workout) },
                            onDelete = { pendingDeleteWorkout = workout }
                        )
                    }
                }
            }
        }
    }

    if (showExerciseLibrary) {
        ExerciseCatalogPickerDialog(
            catalog = uiState.exerciseCatalog,
            initialWorkoutType = null,
            lockWorkoutType = false,
            onSelect = { item ->
                showExerciseLibrary = false
                onStartFromExercise(item)
            },
            onCreateCustom = { name, group, wType, cardioAct ->
                onCreateCustomExercise(name, group, wType, cardioAct)
                showExerciseLibrary = false
                onStartFromExercise(
                    ExerciseCatalogItem(
                        name = name,
                        muscleGroup = group,
                        workoutType = wType,
                        cardioActivity = cardioAct,
                        met = if (wType == WorkoutType.CARDIO) cardioAct.met else 5.0,
                        isCustom = true
                    )
                )
            },
            onDismiss = { showExerciseLibrary = false }
        )
    }

    pendingDeleteWorkout?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeleteWorkout = null },
            title = { Text("Delete workout?") },
            text = {
                Text("This removes \"${target.title}\" and recalculates your personal records and daily active minutes.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteWorkout(target.id)
                        pendingDeleteWorkout = null
                    },
                    modifier = Modifier.testTag("confirm_delete_workout_button")
                ) {
                    Text("Delete", color = CoralError)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteWorkout = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
