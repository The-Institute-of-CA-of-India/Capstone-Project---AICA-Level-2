package com.example.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.UnitSystem
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.SkyCyan
import com.example.ui.theme.TabularMetricStyle
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoltLime
import kotlin.math.roundToInt

@Composable
fun OnboardingScreen(
    displayName: String,
    initialUnitSystem: UnitSystem,
    initialStepGoal: Int,
    initialWorkoutGoal: Int,
    onComplete: (UnitSystem, Int, Int) -> Unit
) {
    var selectedUnit by remember { mutableStateOf(initialUnitSystem) }
    var stepGoal by remember { mutableIntStateOf(initialStepGoal.coerceIn(3000, 25000)) }
    var workoutGoal by remember { mutableIntStateOf(initialWorkoutGoal.coerceIn(1, 7)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 560.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "WELCOME, ${displayName.uppercase()}",
                style = MaterialTheme.typography.labelLarge,
                color = VoltLime
            )
            Text(
                text = "Set your training baseline",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Customize units and weekly targets. You can change these anytime in Health & Profile.",
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary
            )

            // Units selection
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, HairlineBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Measurement Units",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        UnitSystem.entries.forEach { unit ->
                            val selected = selectedUnit == unit
                            FilterChip(
                                selected = selected,
                                onClick = { selectedUnit = unit },
                                label = {
                                    Text(
                                        if (unit == UnitSystem.METRIC) "Metric (kg · km)" else "Imperial (lbs · mi)",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VoltLime,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Daily step goal
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, HairlineBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Step Target",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "%,d".format(stepGoal),
                            style = TabularMetricStyle.copy(
                                fontSize = MaterialTheme.typography.headlineMedium.fontSize,
                                color = VoltLime
                            )
                        )
                    }
                    Slider(
                        value = stepGoal.toFloat(),
                        onValueChange = { raw ->
                            stepGoal = ((raw / 500f).roundToInt() * 500).coerceIn(3000, 25000)
                        },
                        valueRange = 3000f..25000f,
                        colors = SliderDefaults.colors(
                            thumbColor = VoltLime,
                            activeTrackColor = VoltLime
                        )
                    )
                }
            }

            // Weekly workout goal
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, HairlineBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Weekly Workouts",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "$workoutGoal / week",
                            style = TabularMetricStyle.copy(
                                fontSize = MaterialTheme.typography.headlineMedium.fontSize,
                                color = SkyCyan
                            )
                        )
                    }
                    Slider(
                        value = workoutGoal.toFloat(),
                        onValueChange = { raw ->
                            workoutGoal = raw.roundToInt().coerceIn(1, 7)
                        },
                        valueRange = 1f..7f,
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = SkyCyan,
                            activeTrackColor = SkyCyan
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { onComplete(selectedUnit, stepGoal, workoutGoal) },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VoltLime,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("complete_onboarding_button")
            ) {
                Text(
                    text = "Start Training",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
