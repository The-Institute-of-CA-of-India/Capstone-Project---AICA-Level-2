package com.example.ui.viewmodel

import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.preferences.ActiveTimerSnapshot
import com.example.data.preferences.UserPreferencesStore
import com.example.data.repository.FitnessRepository
import com.example.data.repository.SaveWorkoutResult
import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.WorkoutLog
import com.example.domain.model.WorkoutTemplate
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import com.example.service.ActiveWorkoutService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class ActiveWorkoutDraft(
    val editingWorkoutId: String? = null,
    val type: WorkoutType = WorkoutType.STRENGTH,
    val title: String = "Strength Session",
    val dateKey: String = FitnessCalculators.todayDateKey(),
    val startedAtMs: Long = System.currentTimeMillis(),
    val manualDurationMin: Int = 35,
    val useStopwatchDuration: Boolean = true,
    val cardioActivity: CardioActivity = CardioActivity.RUN,
    val cardioExerciseName: String = "Outdoor Road Run",
    val cardioMet: Double = CardioActivity.RUN.met,
    val distanceKm: Double = 5.0,
    val avgHeartRate: Int = 0,
    val manualCalories: Int = 0,
    val notes: String = "",
    val sets: List<ExerciseSetItem> = listOf(
        ExerciseSetItem(
            id = UUID.randomUUID().toString(),
            exerciseName = "Barbell Bench Press",
            muscleGroup = MuscleGroup.CHEST,
            setIndex = 1,
            weightKg = 60.0,
            reps = 8,
            completed = false
        )
    ),
    val isStopwatchRunning: Boolean = false,
    val elapsedSeconds: Long = 0L,
    val restRemainingSeconds: Int = 0,
    val restTotalSeconds: Int = 90,
    val isSaving: Boolean = false,
    val validationError: String? = null
)

class WorkoutLoggerViewModel(
    private val appContext: Context,
    private val repository: FitnessRepository,
    private val preferencesStore: UserPreferencesStore,
    private val currentUserId: String
) : ViewModel() {

    private val _draft = MutableStateFlow(ActiveWorkoutDraft())
    val draft: StateFlow<ActiveWorkoutDraft> = _draft.asStateFlow()

    private var stopwatchStartElapsedMs = 0L
    private var stopwatchAccumulatedMs = 0L
    private var restEndElapsedMs = 0L
    private var restVibrated = false

    init {
        viewModelScope.launch {
            val saved = preferencesStore.activeTimerFlow.first()
            stopwatchStartElapsedMs = saved.workoutStartElapsedMs
            stopwatchAccumulatedMs = saved.workoutAccumulatedMs
            restEndElapsedMs = saved.restTimerEndElapsedMs
            _draft.update {
                it.copy(
                    isStopwatchRunning = saved.isWorkoutRunning,
                    restTotalSeconds = saved.restTimerTotalSeconds
                )
            }
        }
        startTickerLoop()
    }

    private fun startTickerLoop() {
        viewModelScope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val elapsedMs = if (_draft.value.isStopwatchRunning && stopwatchStartElapsedMs > 0L) {
                    stopwatchAccumulatedMs + (now - stopwatchStartElapsedMs).coerceAtLeast(0L)
                } else {
                    stopwatchAccumulatedMs
                }
                val restLeftSec = if (restEndElapsedMs > now) {
                    ((restEndElapsedMs - now + 999L) / 1000L).toInt()
                } else {
                    if (restEndElapsedMs > 0L && !restVibrated) {
                        restVibrated = true
                        restEndElapsedMs = 0L
                        triggerRestCompleteVibration()
                        persistTimerSnapshot()
                    }
                    0
                }
                _draft.update {
                    it.copy(
                        elapsedSeconds = elapsedMs / 1000L,
                        restRemainingSeconds = restLeftSec
                    )
                }
                delay(250L)
            }
        }
    }

    fun startNewSession(
        dateKey: String = FitnessCalculators.todayDateKey(),
        initialType: WorkoutType = WorkoutType.STRENGTH
    ) {
        resetTimers(stopForegroundService = initialType != WorkoutType.STRENGTH)
        _draft.value = ActiveWorkoutDraft(
            editingWorkoutId = null,
            type = initialType,
            title = if (initialType == WorkoutType.STRENGTH) "Strength Session" else "Outdoor Road Run",
            dateKey = dateKey,
            startedAtMs = System.currentTimeMillis(),
            useStopwatchDuration = initialType == WorkoutType.STRENGTH,
            manualDurationMin = if (initialType == WorkoutType.STRENGTH) 40 else 30,
            cardioActivity = CardioActivity.RUN,
            cardioExerciseName = "Outdoor Road Run",
            cardioMet = CardioActivity.RUN.met,
            sets = if (initialType == WorkoutType.STRENGTH) listOf(
                ExerciseSetItem(
                    id = UUID.randomUUID().toString(),
                    exerciseName = "Barbell Bench Press",
                    muscleGroup = MuscleGroup.CHEST,
                    setIndex = 1,
                    weightKg = 60.0,
                    reps = 8,
                    completed = false
                )
            ) else emptyList()
        )
        if (initialType == WorkoutType.STRENGTH) {
            startStopwatch()
        }
    }

    fun startFromExercise(item: ExerciseCatalogItem, dateKey: String = FitnessCalculators.todayDateKey()) {
        if (item.workoutType == WorkoutType.CARDIO) {
            resetTimers(stopForegroundService = true)
            _draft.value = ActiveWorkoutDraft(
                editingWorkoutId = null,
                type = WorkoutType.CARDIO,
                title = item.name,
                dateKey = dateKey,
                startedAtMs = System.currentTimeMillis(),
                useStopwatchDuration = false,
                manualDurationMin = 30,
                cardioActivity = item.cardioActivity,
                cardioExerciseName = item.name,
                cardioMet = item.met,
                distanceKm = if (item.cardioActivity in setOf(CardioActivity.HIIT, CardioActivity.CLIMB)) 0.0 else 5.0,
                sets = emptyList()
            )
        } else {
            resetTimers(stopForegroundService = false)
            _draft.value = ActiveWorkoutDraft(
                editingWorkoutId = null,
                type = WorkoutType.STRENGTH,
                title = item.name,
                dateKey = dateKey,
                startedAtMs = System.currentTimeMillis(),
                useStopwatchDuration = true,
                manualDurationMin = 40,
                sets = listOf(
                    ExerciseSetItem(
                        id = UUID.randomUUID().toString(),
                        exerciseName = item.name,
                        muscleGroup = item.muscleGroup,
                        setIndex = 1,
                        weightKg = 20.0,
                        reps = 10,
                        completed = false
                    )
                )
            )
            startStopwatch()
        }
    }

    fun startFromTemplate(template: WorkoutTemplate, dateKey: String = FitnessCalculators.todayDateKey()) {
        resetTimers(stopForegroundService = template.type != WorkoutType.STRENGTH)
        val sets = template.exercises.flatMap { ex ->
            (1..ex.defaultSets).map { idx ->
                ExerciseSetItem(
                    id = UUID.randomUUID().toString(),
                    exerciseName = ex.exerciseName,
                    muscleGroup = ex.muscleGroup,
                    setIndex = idx,
                    weightKg = ex.defaultWeightKg,
                    reps = ex.defaultReps,
                    completed = false
                )
            }
        }
        _draft.value = ActiveWorkoutDraft(
            editingWorkoutId = null,
            type = template.type,
            title = template.title,
            dateKey = dateKey,
            startedAtMs = System.currentTimeMillis(),
            manualDurationMin = template.defaultDurationMin,
            useStopwatchDuration = template.type == WorkoutType.STRENGTH,
            cardioActivity = template.cardioActivity,
            cardioExerciseName = template.cardioExerciseName,
            cardioMet = template.cardioActivity.met,
            distanceKm = template.defaultDistanceKm,
            sets = sets
        )
        if (template.type == WorkoutType.STRENGTH) {
            startStopwatch()
        }
    }

    fun loadForEdit(workout: WorkoutLog) {
        resetTimers()
        val matchedCatalog = ExerciseCatalog.defaultCardioExercises.firstOrNull {
            it.name.equals(workout.cardioActivity, ignoreCase = true)
        }
        val activity = matchedCatalog?.cardioActivity ?: CardioActivity.fromRaw(workout.cardioActivity)
        _draft.value = ActiveWorkoutDraft(
            editingWorkoutId = workout.id,
            type = workout.type,
            title = workout.title,
            dateKey = workout.dateKey,
            startedAtMs = workout.startedAtMs,
            manualDurationMin = workout.durationMinutes,
            useStopwatchDuration = false,
            cardioActivity = activity,
            cardioExerciseName = workout.cardioActivity.ifBlank { activity.label },
            cardioMet = matchedCatalog?.met ?: activity.met,
            distanceKm = workout.distanceKm,
            avgHeartRate = workout.avgHeartRate,
            manualCalories = workout.caloriesBurned,
            notes = workout.notes,
            sets = workout.sets
        )
    }

    fun setWorkoutType(type: WorkoutType) {
        _draft.update { current ->
            val newUseStopwatch = if (current.editingWorkoutId == null && current.elapsedSeconds < 60L) {
                type == WorkoutType.STRENGTH
            } else {
                current.useStopwatchDuration
            }
            val newTitle = if (current.editingWorkoutId == null) {
                if (type == WorkoutType.STRENGTH) "Strength Session" else current.cardioExerciseName
            } else current.title
            current.copy(
                type = type,
                title = newTitle,
                useStopwatchDuration = newUseStopwatch,
                validationError = null
            )
        }
    }

    fun setTitle(title: String) {
        _draft.update { it.copy(title = title.take(100), validationError = null) }
    }

    fun setCardioActivity(activity: CardioActivity) {
        val defaultExercise = ExerciseCatalog.defaultCardioExercises.firstOrNull { it.cardioActivity == activity }
        val exerciseName = defaultExercise?.name ?: "${activity.label} Session"
        val met = defaultExercise?.met ?: activity.met
        _draft.update {
            val defaultTitle = if (it.editingWorkoutId == null) exerciseName else it.title
            it.copy(
                cardioActivity = activity,
                cardioExerciseName = exerciseName,
                cardioMet = met,
                title = defaultTitle,
                validationError = null
            )
        }
    }

    fun selectCardioExercise(item: ExerciseCatalogItem) {
        _draft.update {
            val defaultTitle = if (it.editingWorkoutId == null) item.name else it.title
            it.copy(
                cardioActivity = item.cardioActivity,
                cardioExerciseName = item.name,
                cardioMet = item.met,
                title = defaultTitle,
                validationError = null
            )
        }
    }

    fun setManualDurationMinutes(minutes: Int) {
        _draft.update { it.copy(manualDurationMin = minutes.coerceIn(1, 1440), useStopwatchDuration = false) }
    }

    fun setUseStopwatchDuration(useStopwatch: Boolean) {
        _draft.update { it.copy(useStopwatchDuration = useStopwatch) }
    }

    fun setDistanceFromDisplay(displayDistance: Double, unitSystem: UnitSystem) {
        val km = FitnessCalculators.displayToKm(displayDistance.coerceIn(0.0, 1000.0), unitSystem)
        _draft.update { it.copy(distanceKm = km) }
    }

    fun setAvgHeartRate(hr: Int) {
        _draft.update { it.copy(avgHeartRate = hr.coerceIn(0, 260)) }
    }

    fun setManualCalories(calories: Int) {
        _draft.update { it.copy(manualCalories = calories.coerceIn(0, 15000)) }
    }

    fun setNotes(notes: String) {
        _draft.update { it.copy(notes = notes.take(500)) }
    }

    fun addExerciseToSession(name: String, muscleGroup: MuscleGroup) {
        val existingLast = _draft.value.sets.lastOrNull { it.exerciseName.equals(name, ignoreCase = true) }
        val newSet = ExerciseSetItem(
            id = UUID.randomUUID().toString(),
            exerciseName = name,
            muscleGroup = muscleGroup,
            setIndex = _draft.value.sets.count { it.exerciseName.equals(name, ignoreCase = true) } + 1,
            weightKg = existingLast?.weightKg ?: 20.0,
            reps = existingLast?.reps ?: 10,
            completed = false
        )
        _draft.update { it.copy(sets = it.sets + newSet, validationError = null) }
    }

    fun updateSetWeight(setId: String, displayWeight: Double, unitSystem: UnitSystem) {
        val kg = FitnessCalculators.displayToKg(displayWeight.coerceIn(0.0, 2000.0), unitSystem)
        _draft.update { state ->
            state.copy(sets = state.sets.map { if (it.id == setId) it.copy(weightKg = kg) else it })
        }
    }

    fun updateSetReps(setId: String, reps: Int) {
        _draft.update { state ->
            state.copy(sets = state.sets.map { if (it.id == setId) it.copy(reps = reps.coerceIn(0, 500)) else it })
        }
    }

    fun toggleSetWarmup(setId: String) {
        _draft.update { state ->
            state.copy(sets = state.sets.map { if (it.id == setId) it.copy(warmup = !it.warmup) else it })
        }
    }

    fun toggleSetCompleted(setId: String) {
        var becameCompleted = false
        _draft.update { state ->
            state.copy(sets = state.sets.map {
                if (it.id == setId) {
                    becameCompleted = !it.completed
                    it.copy(completed = !it.completed)
                } else it
            })
        }
        if (becameCompleted) {
            startRestTimer(_draft.value.restTotalSeconds)
        }
    }

    fun removeSet(setId: String) {
        _draft.update { state ->
            state.copy(sets = state.sets.filterNot { it.id == setId })
        }
    }

    fun toggleStopwatch() {
        if (_draft.value.isStopwatchRunning) {
            val now = SystemClock.elapsedRealtime()
            stopwatchAccumulatedMs += (now - stopwatchStartElapsedMs).coerceAtLeast(0L)
            stopwatchStartElapsedMs = 0L
            _draft.update { it.copy(isStopwatchRunning = false) }
            ActiveWorkoutService.stop(appContext)
        } else {
            startStopwatch()
        }
        persistTimerSnapshot()
    }

    private fun startStopwatch() {
        stopwatchStartElapsedMs = SystemClock.elapsedRealtime()
        _draft.update { it.copy(isStopwatchRunning = true) }
        ActiveWorkoutService.start(
            appContext,
            title = _draft.value.title,
            subtitle = "Workout timer active"
        )
        persistTimerSnapshot()
    }

    fun startRestTimer(seconds: Int) {
        val safeSec = seconds.coerceIn(5, 600)
        restVibrated = false
        restEndElapsedMs = SystemClock.elapsedRealtime() + safeSec * 1000L
        _draft.update { it.copy(restTotalSeconds = safeSec, restRemainingSeconds = safeSec) }
        persistTimerSnapshot()
    }

    fun cancelRestTimer() {
        restEndElapsedMs = 0L
        restVibrated = true
        _draft.update { it.copy(restRemainingSeconds = 0) }
        persistTimerSnapshot()
    }

    fun resetTimers(stopForegroundService: Boolean = true) {
        stopwatchStartElapsedMs = 0L
        stopwatchAccumulatedMs = 0L
        restEndElapsedMs = 0L
        restVibrated = true
        _draft.update { it.copy(isStopwatchRunning = false, elapsedSeconds = 0L, restRemainingSeconds = 0) }
        if (stopForegroundService) {
            ActiveWorkoutService.stop(appContext)
        }
        persistTimerSnapshot()
    }

    fun saveWorkout(onSaved: (SaveWorkoutResult) -> Unit) {
        val current = _draft.value
        val computedDuration = if (current.useStopwatchDuration) {
            ((current.elapsedSeconds / 60L).toInt()).coerceAtLeast(1)
        } else {
            current.manualDurationMin.coerceIn(1, 1440)
        }

        if (current.type == WorkoutType.STRENGTH && current.sets.isEmpty()) {
            _draft.update { it.copy(validationError = "Add at least one set before saving.") }
            return
        }
        if (current.type == WorkoutType.CARDIO && computedDuration <= 0) {
            _draft.update { it.copy(validationError = "Enter a valid duration greater than 0.") }
            return
        }

        val estimatedCalories = if (current.manualCalories > 0) {
            current.manualCalories
        } else if (current.type == WorkoutType.CARDIO) {
            FitnessCalculators.estimateCardioCalories(
                activity = current.cardioActivity,
                durationMinutes = computedDuration,
                customMet = current.cardioMet
            )
        } else {
            val completedWorking = current.sets.count { it.completed && !it.warmup }
            FitnessCalculators.estimateStrengthCalories(computedDuration, completedWorking)
        }

        viewModelScope.launch {
            _draft.update { it.copy(isSaving = true, validationError = null) }
            val result = repository.saveWorkout(
                userId = currentUserId,
                existingWorkoutId = current.editingWorkoutId,
                type = current.type,
                title = current.title,
                dateKey = current.dateKey,
                startedAtMs = current.startedAtMs,
                durationMinutes = computedDuration,
                caloriesBurned = estimatedCalories,
                distanceKm = if (current.type == WorkoutType.CARDIO) current.distanceKm else 0.0,
                avgHeartRate = current.avgHeartRate,
                cardioActivity = if (current.type == WorkoutType.CARDIO) {
                    current.cardioExerciseName.ifBlank { current.cardioActivity.label }
                } else "",
                notes = current.notes,
                sets = if (current.type == WorkoutType.STRENGTH) current.sets else emptyList()
            )
            _draft.update { it.copy(isSaving = false) }
            result.onSuccess { saveRes ->
                resetTimers()
                onSaved(saveRes)
            }.onFailure { err ->
                _draft.update { it.copy(validationError = err.localizedMessage ?: "Failed to save workout.") }
            }
        }
    }

    private fun persistTimerSnapshot() {
        viewModelScope.launch {
            preferencesStore.saveActiveTimer(
                ActiveTimerSnapshot(
                    isWorkoutRunning = _draft.value.isStopwatchRunning,
                    workoutStartElapsedMs = stopwatchStartElapsedMs,
                    workoutAccumulatedMs = stopwatchAccumulatedMs,
                    restTimerEndElapsedMs = restEndElapsedMs,
                    restTimerTotalSeconds = _draft.value.restTotalSeconds
                )
            )
        }
    }

    private fun triggerRestCompleteVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val mgr = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                mgr?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(250L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vib = appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vib?.vibrate(VibrationEffect.createOneShot(250L, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        if (!_draft.value.isStopwatchRunning) {
            ActiveWorkoutService.stop(appContext)
        }
    }
}
