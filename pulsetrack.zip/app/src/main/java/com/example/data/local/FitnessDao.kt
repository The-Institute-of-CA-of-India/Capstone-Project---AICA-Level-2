package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class WorkoutWithSets(
    @androidx.room.Embedded val workout: WorkoutEntity,
    @androidx.room.Relation(
        parentColumn = "id",
        entityColumn = "workoutId"
    )
    val sets: List<ExerciseSetEntity>
)

@Dao
interface FitnessDao {
    @Query("SELECT * FROM daily_metrics WHERE userId = :userId ORDER BY dateKey DESC")
    fun observeAllDailyMetrics(userId: String): Flow<List<DailyMetricEntity>>

    @Query("SELECT * FROM daily_metrics WHERE userId = :userId AND dateKey = :dateKey LIMIT 1")
    fun observeDailyMetric(userId: String, dateKey: String): Flow<DailyMetricEntity?>

    @Query("SELECT * FROM daily_metrics WHERE userId = :userId AND dateKey = :dateKey LIMIT 1")
    suspend fun getDailyMetric(userId: String, dateKey: String): DailyMetricEntity?

    @Query("SELECT * FROM daily_metrics WHERE userId = :userId AND syncedToCloud = 0")
    suspend fun getUnsyncedDailyMetrics(userId: String): List<DailyMetricEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyMetric(metric: DailyMetricEntity)

    @Transaction
    @Query("SELECT * FROM workouts WHERE userId = :userId ORDER BY startedAtMs DESC")
    fun observeWorkoutsWithSets(userId: String): Flow<List<WorkoutWithSets>>

    @Transaction
    @Query("SELECT * FROM workouts WHERE userId = :userId ORDER BY startedAtMs DESC")
    suspend fun getWorkoutsWithSetsOnce(userId: String): List<WorkoutWithSets>

    @Transaction
    @Query("SELECT * FROM workouts WHERE userId = :userId AND dateKey = :dateKey ORDER BY startedAtMs DESC")
    fun observeWorkoutsForDate(userId: String, dateKey: String): Flow<List<WorkoutWithSets>>

    @Transaction
    @Query("SELECT * FROM workouts WHERE id = :workoutId AND userId = :userId LIMIT 1")
    suspend fun getWorkoutWithSets(workoutId: String, userId: String): WorkoutWithSets?

    @Query("SELECT * FROM workouts WHERE userId = :userId AND syncStatus != 'SYNCED'")
    suspend fun getPendingWorkouts(userId: String): List<WorkoutEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkout(workout: WorkoutEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSets(sets: List<ExerciseSetEntity>)

    @Query("DELETE FROM exercise_sets WHERE workoutId = :workoutId AND userId = :userId")
    suspend fun deleteSetsForWorkout(workoutId: String, userId: String)

    @Transaction
    suspend fun upsertWorkoutWithSets(workout: WorkoutEntity, sets: List<ExerciseSetEntity>) {
        insertWorkout(workout)
        deleteSetsForWorkout(workout.id, workout.userId)
        if (sets.isNotEmpty()) {
            insertSets(sets)
        }
    }

    @Query("DELETE FROM workouts WHERE id = :workoutId AND userId = :userId")
    suspend fun deleteWorkoutById(workoutId: String, userId: String)

    @Query("UPDATE workouts SET syncStatus = 'SYNCED' WHERE id = :workoutId AND userId = :userId")
    suspend fun markWorkoutSynced(workoutId: String, userId: String)

    @Query("UPDATE daily_metrics SET syncedToCloud = 1 WHERE userId = :userId AND dateKey = :dateKey")
    suspend fun markDailyMetricSynced(userId: String, dateKey: String)

    @Query("SELECT * FROM custom_exercises WHERE userId = :userId ORDER BY name ASC")
    fun observeCustomExercises(userId: String): Flow<List<CustomExerciseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomExercise(exercise: CustomExerciseEntity)

    @Query("DELETE FROM exercise_sets WHERE userId = :userId")
    suspend fun clearSetsForUser(userId: String)

    @Query("DELETE FROM workouts WHERE userId = :userId")
    suspend fun clearWorkoutsForUser(userId: String)

    @Query("DELETE FROM daily_metrics WHERE userId = :userId")
    suspend fun clearDailyMetricsForUser(userId: String)

    @Query("DELETE FROM custom_exercises WHERE userId = :userId")
    suspend fun clearCustomExercisesForUser(userId: String)

    @Transaction
    suspend fun clearAllUserData(userId: String) {
        clearSetsForUser(userId)
        clearWorkoutsForUser(userId)
        clearDailyMetricsForUser(userId)
        clearCustomExercisesForUser(userId)
    }
}
