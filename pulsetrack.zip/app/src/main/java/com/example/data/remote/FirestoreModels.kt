package com.example.data.remote

import androidx.annotation.Keep
import com.example.data.local.DailyMetricEntity
import com.example.data.local.ExerciseSetEntity
import com.example.data.local.WorkoutEntity
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UnitSystem
import com.example.domain.model.UserProfileSettings
import com.example.domain.model.WorkoutSource
import com.example.domain.model.WorkoutType
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class FirestoreUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Athlete",
    val email: String = "",
    val unitSystem: String = "METRIC",
    val dailyStepGoal: Long = 10000L,
    val weeklyWorkoutGoal: Long = 4L,
    val useDynamicColor: Boolean = false,
    val hcSyncSteps: Boolean = true,
    val hcSyncWorkouts: Boolean = true,
    val hcSyncCalories: Boolean = true,
    val onboardingCompleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toDomain(): UserProfileSettings = UserProfileSettings(
        userId = userId,
        displayName = displayName.ifBlank { "Athlete" },
        email = email,
        unitSystem = UnitSystem.fromRaw(unitSystem),
        dailyStepGoal = dailyStepGoal.toInt().coerceIn(1000, 100000),
        weeklyWorkoutGoal = weeklyWorkoutGoal.toInt().coerceIn(1, 14),
        useDynamicColor = useDynamicColor,
        hcSyncSteps = hcSyncSteps,
        hcSyncWorkouts = hcSyncWorkouts,
        hcSyncCalories = hcSyncCalories,
        onboardingCompleted = onboardingCompleted
    )
}

@Keep
@IgnoreExtraProperties
data class FirestoreDailyMetric(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dateKey: String = "",
    val steps: Long = 0L,
    val manualAdjustmentSteps: Long = 0L,
    val activeMinutes: Long = 0L,
    val caloriesBurned: Long = 0L,
    val stepGoal: Long = 10000L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreWorkout(
    @DocumentId val id: String = "",
    val userId: String = "",
    val workoutType: String = "STRENGTH",
    val title: String = "",
    val dateKey: String = "",
    val startedAtMs: Long = 0L,
    val durationMinutes: Long = 1L,
    val caloriesBurned: Long = 0L,
    val distanceKm: Double = 0.0,
    val avgHeartRate: Long = 0L,
    val totalVolumeKg: Double = 0.0,
    val cardioActivity: String = "",
    val notes: String = "",
    val source: String = "PULSETRACK",
    val prCount: Long = 0L,
    val sets: List<Map<String, Any>> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntities(): Pair<WorkoutEntity, List<ExerciseSetEntity>> {
        val workoutEntity = WorkoutEntity(
            id = id,
            userId = userId,
            workoutType = WorkoutType.fromRaw(workoutType).name,
            title = title.ifBlank { "Workout" },
            dateKey = dateKey,
            startedAtMs = startedAtMs,
            durationMinutes = durationMinutes.toInt().coerceIn(1, 1440),
            caloriesBurned = caloriesBurned.toInt().coerceIn(0, 15000),
            distanceKm = distanceKm.coerceIn(0.0, 1000.0),
            avgHeartRate = avgHeartRate.toInt().coerceIn(0, 260),
            totalVolumeKg = totalVolumeKg.coerceIn(0.0, 500000.0),
            cardioActivity = cardioActivity,
            notes = notes,
            source = WorkoutSource.fromRaw(source).name,
            prCount = prCount.toInt().coerceIn(0, 100),
            syncStatus = "SYNCED",
            updatedAtMs = (updatedAt ?: createdAt)?.toDate()?.time ?: System.currentTimeMillis()
        )

        val setEntities = sets.mapIndexed { idx, map ->
            val setIdx = (map["setIndex"] as? Number)?.toInt() ?: (idx + 1)
            val exerciseName = (map["exerciseName"] as? String).orEmpty().ifBlank { "Exercise" }
            val muscleGroup = MuscleGroup.fromRaw(map["muscleGroup"] as? String).name
            val weightKg = (map["weightKg"] as? Number)?.toDouble() ?: 0.0
            val reps = (map["reps"] as? Number)?.toInt() ?: 0
            val completed = map["completed"] as? Boolean ?: true
            val warmup = map["warmup"] as? Boolean ?: false
            val pr = map["pr"] as? Boolean ?: false
            ExerciseSetEntity(
                id = "${id}_set_${idx}_${setIdx}",
                workoutId = id,
                userId = userId,
                exerciseName = exerciseName,
                muscleGroup = muscleGroup,
                setIndex = setIdx,
                weightKg = weightKg,
                reps = reps,
                completed = completed,
                warmup = warmup,
                pr = pr
            )
        }
        return workoutEntity to setEntities
    }
}

object FirestorePayloadMapper {
    fun userProfileCreateMap(settings: UserProfileSettings, uid: String): Map<String, Any> {
        val base = mutableMapOf<String, Any>(
            "userId" to uid,
            "displayName" to settings.displayName.trim().take(80).ifBlank { "Athlete" },
            "unitSystem" to settings.unitSystem.name,
            "dailyStepGoal" to settings.dailyStepGoal.coerceIn(1000, 100000),
            "weeklyWorkoutGoal" to settings.weeklyWorkoutGoal.coerceIn(1, 14),
            "useDynamicColor" to settings.useDynamicColor,
            "hcSyncSteps" to settings.hcSyncSteps,
            "hcSyncWorkouts" to settings.hcSyncWorkouts,
            "hcSyncCalories" to settings.hcSyncCalories,
            "onboardingCompleted" to settings.onboardingCompleted,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (settings.email.isNotBlank()) {
            base["email"] = settings.email.trim().take(160)
        }
        return base
    }

    fun userProfileUpdateMap(settings: UserProfileSettings): Map<String, Any> {
        val map = mutableMapOf<String, Any>(
            "displayName" to settings.displayName.trim().take(80).ifBlank { "Athlete" },
            "unitSystem" to settings.unitSystem.name,
            "dailyStepGoal" to settings.dailyStepGoal.coerceIn(1000, 100000),
            "weeklyWorkoutGoal" to settings.weeklyWorkoutGoal.coerceIn(1, 14),
            "useDynamicColor" to settings.useDynamicColor,
            "hcSyncSteps" to settings.hcSyncSteps,
            "hcSyncWorkouts" to settings.hcSyncWorkouts,
            "hcSyncCalories" to settings.hcSyncCalories,
            "onboardingCompleted" to settings.onboardingCompleted,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (settings.email.isNotBlank()) {
            map["email"] = settings.email.trim().take(160)
        }
        return map
    }

    fun dailyMetricCreateMap(metric: DailyMetricEntity, uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "dateKey" to metric.dateKey,
        "steps" to metric.totalSteps.coerceIn(0, 250000),
        "manualAdjustmentSteps" to metric.manualAdjustmentSteps.coerceIn(0, 100000),
        "activeMinutes" to metric.activeMinutes.coerceIn(0, 1440),
        "caloriesBurned" to metric.caloriesBurned.coerceIn(0, 30000),
        "stepGoal" to metric.stepGoal.coerceIn(1000, 100000),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    fun dailyMetricUpdateMap(metric: DailyMetricEntity): Map<String, Any> = mapOf(
        "steps" to metric.totalSteps.coerceIn(0, 250000),
        "manualAdjustmentSteps" to metric.manualAdjustmentSteps.coerceIn(0, 100000),
        "activeMinutes" to metric.activeMinutes.coerceIn(0, 1440),
        "caloriesBurned" to metric.caloriesBurned.coerceIn(0, 30000),
        "stepGoal" to metric.stepGoal.coerceIn(1000, 100000),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    private fun serializeSets(sets: List<ExerciseSetEntity>): List<Map<String, Any>> {
        return sets.take(100).map { set ->
            mapOf(
                "exerciseName" to set.exerciseName.trim().take(80),
                "muscleGroup" to set.muscleGroup,
                "setIndex" to set.setIndex,
                "weightKg" to set.weightKg.coerceIn(0.0, 2000.0),
                "reps" to set.reps.coerceIn(0, 500),
                "completed" to set.completed,
                "warmup" to set.warmup,
                "pr" to set.pr
            )
        }
    }

    fun workoutCreateMap(workout: WorkoutEntity, sets: List<ExerciseSetEntity>, uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "workoutType" to workout.workoutType,
            "title" to workout.title.trim().take(100).ifBlank { "Workout" },
            "dateKey" to workout.dateKey,
            "startedAtMs" to workout.startedAtMs.coerceAtLeast(1L),
            "durationMinutes" to workout.durationMinutes.coerceIn(1, 1440),
            "caloriesBurned" to workout.caloriesBurned.coerceIn(0, 15000),
            "distanceKm" to workout.distanceKm.coerceIn(0.0, 1000.0),
            "avgHeartRate" to workout.avgHeartRate.coerceIn(0, 260),
            "totalVolumeKg" to workout.totalVolumeKg.coerceIn(0.0, 500000.0),
            "cardioActivity" to workout.cardioActivity.trim().take(40),
            "notes" to workout.notes.trim().take(500),
            "source" to workout.source,
            "prCount" to workout.prCount.coerceIn(0, 100),
            "sets" to serializeSets(sets),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    fun workoutUpdateMap(workout: WorkoutEntity, sets: List<ExerciseSetEntity>): Map<String, Any> {
        return mapOf(
            "workoutType" to workout.workoutType,
            "title" to workout.title.trim().take(100).ifBlank { "Workout" },
            "dateKey" to workout.dateKey,
            "startedAtMs" to workout.startedAtMs.coerceAtLeast(1L),
            "durationMinutes" to workout.durationMinutes.coerceIn(1, 1440),
            "caloriesBurned" to workout.caloriesBurned.coerceIn(0, 15000),
            "distanceKm" to workout.distanceKm.coerceIn(0.0, 1000.0),
            "avgHeartRate" to workout.avgHeartRate.coerceIn(0, 260),
            "totalVolumeKg" to workout.totalVolumeKg.coerceIn(0.0, 500000.0),
            "cardioActivity" to workout.cardioActivity.trim().take(40),
            "notes" to workout.notes.trim().take(500),
            "source" to workout.source,
            "prCount" to workout.prCount.coerceIn(0, 100),
            "sets" to serializeSets(sets),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}
