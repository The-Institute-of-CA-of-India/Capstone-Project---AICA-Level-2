package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.UnitSystem
import com.example.domain.model.UserProfileSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.pulseTrackDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "pulsetrack_prefs"
)

data class StepSensorBaseline(
    val lastBootSteps: Long = -1L,
    val lastDateKey: String = ""
)

data class ActiveTimerSnapshot(
    val isWorkoutRunning: Boolean = false,
    val workoutStartElapsedMs: Long = 0L,
    val workoutAccumulatedMs: Long = 0L,
    val restTimerEndElapsedMs: Long = 0L,
    val restTimerTotalSeconds: Int = 90
)

class UserPreferencesStore(private val context: Context) {
    private object Keys {
        val USER_ID = stringPreferencesKey("user_id")
        val DISPLAY_NAME = stringPreferencesKey("display_name")
        val EMAIL = stringPreferencesKey("email")
        val UNIT_SYSTEM = stringPreferencesKey("unit_system")
        val DAILY_STEP_GOAL = intPreferencesKey("daily_step_goal")
        val WEEKLY_WORKOUT_GOAL = intPreferencesKey("weekly_workout_goal")
        val USE_DYNAMIC_COLOR = booleanPreferencesKey("use_dynamic_color")
        val HC_SYNC_STEPS = booleanPreferencesKey("hc_sync_steps")
        val HC_SYNC_WORKOUTS = booleanPreferencesKey("hc_sync_workouts")
        val HC_SYNC_CALORIES = booleanPreferencesKey("hc_sync_calories")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")

        val STEP_LAST_BOOT_COUNT = longPreferencesKey("step_last_boot_count")
        val STEP_LAST_DATE_KEY = stringPreferencesKey("step_last_date_key")

        val TIMER_RUNNING = booleanPreferencesKey("timer_running")
        val TIMER_START_ELAPSED_MS = longPreferencesKey("timer_start_elapsed_ms")
        val TIMER_ACCUMULATED_MS = longPreferencesKey("timer_accumulated_ms")
        val REST_END_ELAPSED_MS = longPreferencesKey("rest_end_elapsed_ms")
        val REST_TOTAL_SECONDS = intPreferencesKey("rest_total_seconds")
    }

    val settingsFlow: Flow<UserProfileSettings> = context.pulseTrackDataStore.data.map { prefs ->
        UserProfileSettings(
            userId = prefs[Keys.USER_ID] ?: "",
            displayName = prefs[Keys.DISPLAY_NAME] ?: "Athlete",
            email = prefs[Keys.EMAIL] ?: "",
            unitSystem = UnitSystem.fromRaw(prefs[Keys.UNIT_SYSTEM]),
            dailyStepGoal = (prefs[Keys.DAILY_STEP_GOAL] ?: 10000).coerceIn(1000, 100000),
            weeklyWorkoutGoal = (prefs[Keys.WEEKLY_WORKOUT_GOAL] ?: 4).coerceIn(1, 14),
            useDynamicColor = prefs[Keys.USE_DYNAMIC_COLOR] ?: false,
            hcSyncSteps = prefs[Keys.HC_SYNC_STEPS] ?: true,
            hcSyncWorkouts = prefs[Keys.HC_SYNC_WORKOUTS] ?: true,
            hcSyncCalories = prefs[Keys.HC_SYNC_CALORIES] ?: true,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false
        )
    }

    val activeTimerFlow: Flow<ActiveTimerSnapshot> = context.pulseTrackDataStore.data.map { prefs ->
        ActiveTimerSnapshot(
            isWorkoutRunning = prefs[Keys.TIMER_RUNNING] ?: false,
            workoutStartElapsedMs = prefs[Keys.TIMER_START_ELAPSED_MS] ?: 0L,
            workoutAccumulatedMs = prefs[Keys.TIMER_ACCUMULATED_MS] ?: 0L,
            restTimerEndElapsedMs = prefs[Keys.REST_END_ELAPSED_MS] ?: 0L,
            restTimerTotalSeconds = prefs[Keys.REST_TOTAL_SECONDS] ?: 90
        )
    }

    suspend fun updateSettings(settings: UserProfileSettings) {
        context.pulseTrackDataStore.edit { prefs ->
            prefs[Keys.USER_ID] = settings.userId
            prefs[Keys.DISPLAY_NAME] = settings.displayName
            prefs[Keys.EMAIL] = settings.email
            prefs[Keys.UNIT_SYSTEM] = settings.unitSystem.name
            prefs[Keys.DAILY_STEP_GOAL] = settings.dailyStepGoal.coerceIn(1000, 100000)
            prefs[Keys.WEEKLY_WORKOUT_GOAL] = settings.weeklyWorkoutGoal.coerceIn(1, 14)
            prefs[Keys.USE_DYNAMIC_COLOR] = settings.useDynamicColor
            prefs[Keys.HC_SYNC_STEPS] = settings.hcSyncSteps
            prefs[Keys.HC_SYNC_WORKOUTS] = settings.hcSyncWorkouts
            prefs[Keys.HC_SYNC_CALORIES] = settings.hcSyncCalories
            prefs[Keys.ONBOARDING_COMPLETED] = settings.onboardingCompleted
        }
    }

    suspend fun getStepBaseline(): StepSensorBaseline {
        val prefs = context.pulseTrackDataStore.data.first()
        return StepSensorBaseline(
            lastBootSteps = prefs[Keys.STEP_LAST_BOOT_COUNT] ?: -1L,
            lastDateKey = prefs[Keys.STEP_LAST_DATE_KEY] ?: ""
        )
    }

    suspend fun saveStepBaseline(bootSteps: Long, dateKey: String) {
        context.pulseTrackDataStore.edit { prefs ->
            prefs[Keys.STEP_LAST_BOOT_COUNT] = bootSteps
            prefs[Keys.STEP_LAST_DATE_KEY] = dateKey
        }
    }

    suspend fun saveActiveTimer(snapshot: ActiveTimerSnapshot) {
        context.pulseTrackDataStore.edit { prefs ->
            prefs[Keys.TIMER_RUNNING] = snapshot.isWorkoutRunning
            prefs[Keys.TIMER_START_ELAPSED_MS] = snapshot.workoutStartElapsedMs
            prefs[Keys.TIMER_ACCUMULATED_MS] = snapshot.workoutAccumulatedMs
            prefs[Keys.REST_END_ELAPSED_MS] = snapshot.restTimerEndElapsedMs
            prefs[Keys.REST_TOTAL_SECONDS] = snapshot.restTimerTotalSeconds
        }
    }

    suspend fun clearAll() {
        context.pulseTrackDataStore.edit { it.clear() }
    }
}
