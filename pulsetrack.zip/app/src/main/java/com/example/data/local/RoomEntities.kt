package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_metrics",
    primaryKeys = ["userId", "dateKey"]
)
data class DailyMetricEntity(
    val userId: String,
    val dateKey: String,
    val hardwareSteps: Int = 0,
    val healthConnectSteps: Int = 0,
    val manualAdjustmentSteps: Int = 0,
    val activeMinutes: Int = 0,
    val caloriesBurned: Int = 0,
    val stepGoal: Int = 10000,
    val syncedToCloud: Boolean = false,
    val updatedAtMs: Long = System.currentTimeMillis()
) {
    val totalSteps: Int
        get() = (maxOf(hardwareSteps, healthConnectSteps) + manualAdjustmentSteps).coerceIn(0, 250_000)
}

@Entity(
    tableName = "workouts",
    indices = [
        Index(value = ["userId", "dateKey"]),
        Index(value = ["userId", "startedAtMs"])
    ]
)
data class WorkoutEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val workoutType: String,
    val title: String,
    val dateKey: String,
    val startedAtMs: Long,
    val durationMinutes: Int,
    val caloriesBurned: Int,
    val distanceKm: Double,
    val avgHeartRate: Int,
    val totalVolumeKg: Double,
    val cardioActivity: String,
    val notes: String,
    val source: String,
    val prCount: Int,
    val syncStatus: String = "PENDING", // PENDING | SYNCED
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "exercise_sets",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutEntity::class,
            parentColumns = ["id"],
            childColumns = ["workoutId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["workoutId"]),
        Index(value = ["userId", "exerciseName"])
    ]
)
data class ExerciseSetEntity(
    @PrimaryKey val id: String,
    val workoutId: String,
    val userId: String,
    val exerciseName: String,
    val muscleGroup: String,
    val setIndex: Int,
    val weightKg: Double,
    val reps: Int,
    val completed: Boolean,
    val warmup: Boolean,
    val pr: Boolean
)

@Entity(
    tableName = "custom_exercises",
    primaryKeys = ["userId", "name"]
)
data class CustomExerciseEntity(
    val name: String,
    val userId: String,
    val muscleGroup: String,
    val workoutType: String = "STRENGTH",
    val cardioActivity: String = "RUN"
)
