package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write"),
}

private fun redactFirestorePath(path: String?): String? {
    if (path.isNullOrBlank()) return path
    val segments = path.split("/")
    return segments.mapIndexed { idx, seg ->
        if (idx > 0 && segments[idx - 1] == "users" && seg.isNotBlank()) "<redacted-uid>" else seg
    }.joinToString("/")
}

fun handleFirestoreError(
    exception: Throwable,
    operationType: OperationType,
    path: String?
): String {
    val causes = generateSequence(exception) { it.cause }
    val rootError = causes.firstOrNull { it is FirebaseFirestoreException }
        ?: causes.firstOrNull { it !is CancellationException }
        ?: exception

    val errorCode = (rootError as? FirebaseFirestoreException)?.code?.name
        ?: rootError::class.simpleName
        ?: "UNKNOWN"
    val safePath = redactFirestorePath(path)

    val errorInfoJson = JSONObject().apply {
        put("errorCode", errorCode)
        put("operationType", operationType.value)
        put("path", safePath)
        put("authenticated", Firebase.auth.currentUser != null)
        if (BuildConfig.DEBUG) {
            put("error", rootError.message ?: rootError.toString())
        }
    }

    val jsonString = errorInfoJson.toString()
    if (BuildConfig.DEBUG) {
        Log.w("FirestoreError", "Firestore Error: $jsonString")
    } else {
        Log.e("FirestoreError", "Firestore ${operationType.value} failed ($errorCode) on $safePath")
    }
    return jsonString
}
