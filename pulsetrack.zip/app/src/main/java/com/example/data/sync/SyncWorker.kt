package com.example.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.PulseTrackApplication
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class SyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val uid = Firebase.auth.currentUser?.uid ?: return Result.success()
        val app = applicationContext as? PulseTrackApplication ?: return Result.retry()
        return try {
            app.container.fitnessRepository.flushPendingToCloud(uid)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
