package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.local.DailyMetricEntity
import com.example.data.local.ExerciseSetEntity
import com.example.data.local.WorkoutEntity
import com.example.domain.model.UserProfileSettings
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreSyncSource(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfileSettings?> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Signed-in user mismatch" }
        val docRef = db.collection("users").document(uid)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        FirestoreUserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )?.toDomain()
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    fun observeWorkouts(userId: String): Flow<List<Pair<WorkoutEntity, List<ExerciseSetEntity>>>> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/workouts"
        emitAll(
            db.collection("users").document(uid).collection("workouts")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreWorkout::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).map { it.toEntities() }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeDailyMetrics(userId: String): Flow<List<FirestoreDailyMetric>> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Signed-in user mismatch" }
        val path = "users/$uid/dailyMetrics"
        emitAll(
            db.collection("users").document(uid).collection("dailyMetrics")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FirestoreDailyMetric::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun upsertUserProfile(settings: UserProfileSettings): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
            docPath = docRef.path
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(FirestorePayloadMapper.userProfileUpdateMap(settings)).await()
            } else {
                docRef.set(FirestorePayloadMapper.userProfileCreateMap(settings, uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertDailyMetric(metric: DailyMetricEntity): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/dailyMetrics/${metric.dateKey}"
        return try {
            val uid = requireUserId()
            require(metric.userId == uid) { "User ID mismatch for daily metric" }
            val docRef = db.collection("users").document(uid)
                .collection("dailyMetrics").document(metric.dateKey)
            docPath = docRef.path
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(FirestorePayloadMapper.dailyMetricUpdateMap(metric)).await()
            } else {
                docRef.set(FirestorePayloadMapper.dailyMetricCreateMap(metric, uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertWorkout(workout: WorkoutEntity, sets: List<ExerciseSetEntity>): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/workouts/${workout.id}"
        return try {
            val uid = requireUserId()
            require(workout.userId == uid) { "User ID mismatch for workout" }
            require(workout.id.isNotBlank()) { "Workout ID cannot be blank" }
            val docRef = db.collection("users").document(uid)
                .collection("workouts").document(workout.id)
            docPath = docRef.path
            val existing = docRef.get().await()
            if (existing.exists()) {
                docRef.update(FirestorePayloadMapper.workoutUpdateMap(workout, sets)).await()
            } else {
                docRef.set(FirestorePayloadMapper.workoutCreateMap(workout, sets, uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteWorkout(workoutId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/workouts/$workoutId"
        return try {
            val uid = requireUserId()
            require(workoutId.isNotBlank()) { "Workout ID cannot be blank" }
            val docRef = db.collection("users").document(uid)
                .collection("workouts").document(workoutId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteAllUserCloudData(): Result<Unit> {
        var currentPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val userDoc = db.collection("users").document(uid)

            currentPath = "users/$uid/workouts"
            val workoutsSnap = userDoc.collection("workouts").get().await()
            for (doc in workoutsSnap.documents) {
                doc.reference.delete().await()
            }

            currentPath = "users/$uid/dailyMetrics"
            val metricsSnap = userDoc.collection("dailyMetrics").get().await()
            for (doc in metricsSnap.documents) {
                doc.reference.delete().await()
            }

            currentPath = "users/$uid"
            userDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, currentPath)
            Result.failure(e)
        }
    }
}
