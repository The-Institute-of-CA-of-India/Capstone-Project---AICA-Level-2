package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        DailyMetricEntity::class,
        WorkoutEntity::class,
        ExerciseSetEntity::class,
        CustomExerciseEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class PulseTrackDatabase : RoomDatabase() {
    abstract fun fitnessDao(): FitnessDao

    companion object {
        @Volatile
        private var INSTANCE: PulseTrackDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE custom_exercises ADD COLUMN workoutType TEXT NOT NULL DEFAULT 'STRENGTH'"
                )
                db.execSQL(
                    "ALTER TABLE custom_exercises ADD COLUMN cardioActivity TEXT NOT NULL DEFAULT 'RUN'"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS custom_exercises_new (
                        name TEXT NOT NULL,
                        userId TEXT NOT NULL,
                        muscleGroup TEXT NOT NULL,
                        workoutType TEXT NOT NULL DEFAULT 'STRENGTH',
                        cardioActivity TEXT NOT NULL DEFAULT 'RUN',
                        PRIMARY KEY(userId, name)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    INSERT OR REPLACE INTO custom_exercises_new (name, userId, muscleGroup, workoutType, cardioActivity)
                    SELECT name, userId, muscleGroup, workoutType, cardioActivity FROM custom_exercises
                    """.trimIndent()
                )
                db.execSQL("DROP TABLE custom_exercises")
                db.execSQL("ALTER TABLE custom_exercises_new RENAME TO custom_exercises")
            }
        }

        fun getInstance(context: Context): PulseTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PulseTrackDatabase::class.java,
                    "pulsetrack_offline.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
