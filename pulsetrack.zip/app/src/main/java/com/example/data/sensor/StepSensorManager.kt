package com.example.data.sensor

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.preferences.UserPreferencesStore
import com.example.domain.util.FitnessCalculators
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class StepSensorManager(
    private val context: Context,
    private val preferencesStore: UserPreferencesStore,
    private val onDailyStepsDelta: suspend (dateKey: String, deltaSteps: Int, rolledOver: Boolean) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val stepSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var isListening = false

    val isHardwareSensorAvailable: Boolean
        get() = stepSensor != null

    fun hasActivityRecognitionPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACTIVITY_RECOGNITION
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun startListeningIfPermitted() {
        if (isListening || stepSensor == null || !hasActivityRecognitionPermission()) return
        val registered = sensorManager?.registerListener(
            this,
            stepSensor,
            SensorManager.SENSOR_DELAY_NORMAL
        ) ?: false
        isListening = registered
        Log.d(TAG, "TYPE_STEP_COUNTER listener started: $registered")
    }

    fun stopListening() {
        if (!isListening) return
        sensorManager?.unregisterListener(this)
        isListening = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val rawValue = event?.values?.firstOrNull()?.toLong() ?: return
        scope.launch {
            mutex.withLock {
                val today = FitnessCalculators.todayDateKey()
                val baseline = preferencesStore.getStepBaseline()
                val delta = FitnessCalculators.calculateStepSensorDelta(
                    currentBootSteps = rawValue,
                    lastBootSteps = baseline.lastBootSteps,
                    lastDateKey = baseline.lastDateKey,
                    todayDateKey = today
                )
                preferencesStore.saveStepBaseline(delta.newBootStepsBaseline, today)
                if (delta.deltaSteps > 0 || delta.dateRolledOver) {
                    onDailyStepsDelta(today, delta.deltaSteps, delta.dateRolledOver)
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        private const val TAG = "StepSensorManager"
    }
}
