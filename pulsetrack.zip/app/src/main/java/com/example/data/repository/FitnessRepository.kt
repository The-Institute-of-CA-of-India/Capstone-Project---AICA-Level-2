package com.example.data.repository

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.BuildConfig
import com.example.data.healthconnect.HealthConnectManager
import com.example.data.local.CustomExerciseEntity
import com.example.data.local.DailyMetricEntity
import com.example.data.local.ExerciseSetEntity
import com.example.data.local.FitnessDao
import com.example.data.local.WorkoutEntity
import com.example.data.local.WorkoutWithSets
import com.example.data.preferences.UserPreferencesStore
import com.example.data.remote.FirestoreSyncSource
import com.example.data.sync.SyncWorker
import com.example.domain.model.CardioActivity
import com.example.domain.model.DailyMetric
import com.example.domain.model.ExerciseCatalog
import com.example.domain.model.ExerciseCatalogItem
import com.example.domain.model.ExercisePrSummary
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.MuscleGroup
import com.example.domain.model.UserProfileSettings
import com.example.domain.model.WorkoutLog
import com.example.domain.model.WorkoutSource
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import com.example.service.ActiveWorkoutService
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

data class SaveWorkoutResult(
    val workoutId: String,
    val newPrCount: Int,
    val syncedToCloud: Boolean,
    val syncedToHealthConnect: Boolean
)

class FitnessRepository(
    private val context: Context,
    private val dao: FitnessDao,
    private val preferencesStore: UserPreferencesStore,
    private val firestoreSync: FirestoreSyncSource,
    private val healthConnectManager: HealthConnectManager
) {
    val settingsFlow: Flow<UserProfileSettings> = preferencesStore.settingsFlow

    fun observeWorkouts(userId: String): Flow<List<WorkoutLog>> {
        if (userId.isBlank()) return kotlinx.coroutines.flow.flowOf(emptyList())
        return dao.observeWorkoutsWithSets(userId).map { list ->
            list.map { it.toDomain() }
        }
    }

    fun observeDailyMetrics(userId: String): Flow<List<DailyMetric>> {
        if (userId.isBlank()) return kotlinx.coroutines.flow.flowOf(emptyList())
        return dao.observeAllDailyMetrics(userId).map { list ->
            list.map { it.toDomain() }
        }
    }

    fun observeExerciseCatalog(userId: String): Flow<List<ExerciseCatalogItem>> {
        if (userId.isBlank()) return kotlinx.coroutines.flow.flowOf(ExerciseCatalog.defaultExercises)
        return dao.observeCustomExercises(userId).map { custom ->
            val customItems = custom.map {
                val type = WorkoutType.fromRaw(it.workoutType)
                val cardio = CardioActivity.fromRaw(it.cardioActivity)
                ExerciseCatalogItem(
                    name = it.name,
                    muscleGroup = MuscleGroup.fromRaw(it.muscleGroup),
                    workoutType = type,
                    cardioActivity = cardio,
                    met = if (type == WorkoutType.CARDIO) cardio.met else 5.0,
                    isCustom = true
                )
            }
            (ExerciseCatalog.defaultExercises + customItems).distinctBy {
                "${it.workoutType.name}_${it.name.lowercase()}"
            }
        }
    }

    suspend fun addCustomExercise(
        userId: String,
        name: String,
        muscleGroup: MuscleGroup,
        workoutType: WorkoutType = WorkoutType.STRENGTH,
        cardioActivity: CardioActivity = CardioActivity.RUN
    ) {
        val cleanName = name.trim().take(80)
        if (userId.isBlank() || cleanName.isBlank()) return
        dao.insertCustomExercise(
            CustomExerciseEntity(
                name = cleanName,
                userId = userId,
                muscleGroup = muscleGroup.name,
                workoutType = workoutType.name,
                cardioActivity = cardioActivity.name
            )
        )
    }

    suspend fun ensureUserInitialized(userId: String, displayName: String, email: String) {
        if (userId.isBlank()) return
        val current = preferencesStore.settingsFlow.first()
        if (current.userId != userId) {
            preferencesStore.updateSettings(
                UserProfileSettings(
                    userId = userId,
                    displayName = displayName.ifBlank { "Athlete" },
                    email = email
                )
            )
        }
        // Pull cloud profile if available
        try {
            val remoteProfile = firestoreSync.observeUserProfile(userId)
                .catch { e -> if (e is CancellationException) throw e }
                .first()
            if (remoteProfile != null) {
                preferencesStore.updateSettings(
                    remoteProfile.copy(
                        userId = userId,
                        email = remoteProfile.email.ifBlank { email }
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Profile bootstrap offline or unavailable: ${e.message}")
        }
    }

    suspend fun startCloudSyncListeners(userId: String) {
        if (userId.isBlank()) return
        // Collect remote workouts & daily metrics into Room safely; cancellation propagates naturally.
        try {
            firestoreSync.observeWorkouts(userId)
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.w(TAG, "Cloud workout sync paused: ${e.message}")
                }
                .collect { remotePairs ->
                    for ((entity, sets) in remotePairs) {
                        if (entity.userId != userId) continue
                        val local = dao.getWorkoutWithSets(entity.id, userId)
                        if (local == null || (local.workout.syncStatus == "SYNCED" && entity.updatedAtMs >= local.workout.updatedAtMs)) {
                            dao.upsertWorkoutWithSets(entity, sets)
                        }
                    }
                }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "observeWorkouts collector exited: ${e.message}")
        }
    }

    suspend fun startDailyMetricsSyncListener(userId: String) {
        if (userId.isBlank()) return
        try {
            firestoreSync.observeDailyMetrics(userId)
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.w(TAG, "Cloud dailyMetrics sync paused: ${e.message}")
                }
                .collect { remoteMetrics ->
                    for (remote in remoteMetrics) {
                        val local = dao.getDailyMetric(userId, remote.dateKey)
                        val remoteSteps = remote.steps.toInt().coerceIn(0, 250_000)
                        val remoteManual = remote.manualAdjustmentSteps.toInt().coerceIn(0, 100_000)
                        if (local == null) {
                            dao.upsertDailyMetric(
                                DailyMetricEntity(
                                    userId = userId,
                                    dateKey = remote.dateKey,
                                    hardwareSteps = (remoteSteps - remoteManual).coerceAtLeast(0),
                                    healthConnectSteps = 0,
                                    manualAdjustmentSteps = remoteManual,
                                    activeMinutes = remote.activeMinutes.toInt().coerceIn(0, 1440),
                                    caloriesBurned = remote.caloriesBurned.toInt().coerceIn(0, 30000),
                                    stepGoal = remote.stepGoal.toInt().coerceIn(1000, 100000),
                                    syncedToCloud = true
                                )
                            )
                        } else if (local.syncedToCloud && remoteSteps > local.totalSteps) {
                            dao.upsertDailyMetric(
                                local.copy(
                                    hardwareSteps = maxOf(local.hardwareSteps, (remoteSteps - local.manualAdjustmentSteps).coerceAtLeast(0)),
                                    activeMinutes = maxOf(local.activeMinutes, remote.activeMinutes.toInt()),
                                    caloriesBurned = maxOf(local.caloriesBurned, remote.caloriesBurned.toInt()),
                                    syncedToCloud = true
                                )
                            )
                        }
                    }
                }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "observeDailyMetrics collector exited: ${e.message}")
        }
    }

    suspend fun saveProfileSettings(settings: UserProfileSettings): Result<Unit> {
        preferencesStore.updateSettings(settings)
        // Also update today's stepGoal in Room
        val today = FitnessCalculators.todayDateKey()
        if (settings.userId.isNotBlank()) {
            val existingMetric = dao.getDailyMetric(settings.userId, today)
            if (existingMetric != null) {
                dao.upsertDailyMetric(
                    existingMetric.copy(
                        stepGoal = settings.dailyStepGoal,
                        syncedToCloud = false,
                        updatedAtMs = System.currentTimeMillis()
                    )
                )
            }
        }
        val res = firestoreSync.upsertUserProfile(settings)
        if (res.isFailure) {
            scheduleBackgroundSync()
        }
        return res
    }

    suspend fun recordHardwareStepDelta(userId: String, dateKey: String, deltaSteps: Int) {
        if (userId.isBlank()) return
        val settings = preferencesStore.settingsFlow.first()
        val existing = dao.getDailyMetric(userId, dateKey)
        val updated = if (existing == null) {
            DailyMetricEntity(
                userId = userId,
                dateKey = dateKey,
                hardwareSteps = deltaSteps.coerceAtLeast(0),
                stepGoal = settings.dailyStepGoal,
                syncedToCloud = false
            )
        } else {
            existing.copy(
                hardwareSteps = (existing.hardwareSteps + deltaSteps).coerceIn(0, 250_000),
                stepGoal = settings.dailyStepGoal,
                syncedToCloud = false,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        dao.upsertDailyMetric(updated)
        scheduleBackgroundSync()
    }

    suspend fun addManualSteps(userId: String, dateKey: String, deltaSteps: Int): Result<Unit> {
        if (userId.isBlank() || deltaSteps <= 0) return Result.failure(IllegalArgumentException("Invalid step amount"))
        val safeDateKey = FitnessCalculators.sanitizeDateKey(dateKey)
        val settings = preferencesStore.settingsFlow.first()
        val existing = dao.getDailyMetric(userId, safeDateKey)
        val updated = if (existing == null) {
            DailyMetricEntity(
                userId = userId,
                dateKey = safeDateKey,
                manualAdjustmentSteps = deltaSteps.coerceIn(0, 100_000),
                stepGoal = settings.dailyStepGoal,
                syncedToCloud = false
            )
        } else {
            existing.copy(
                manualAdjustmentSteps = (existing.manualAdjustmentSteps + deltaSteps).coerceIn(0, 100_000),
                stepGoal = settings.dailyStepGoal,
                syncedToCloud = false,
                updatedAtMs = System.currentTimeMillis()
            )
        }
        dao.upsertDailyMetric(updated)
        val cloudRes = firestoreSync.upsertDailyMetric(updated)
        if (cloudRes.isSuccess) {
            dao.markDailyMetricSynced(userId, safeDateKey)
        } else {
            scheduleBackgroundSync()
        }
        return cloudRes
    }

    suspend fun saveWorkout(
        userId: String,
        existingWorkoutId: String?,
        type: WorkoutType,
        title: String,
        dateKey: String,
        startedAtMs: Long,
        durationMinutes: Int,
        caloriesBurned: Int,
        distanceKm: Double,
        avgHeartRate: Int,
        cardioActivity: String,
        notes: String,
        sets: List<ExerciseSetItem>
    ): Result<SaveWorkoutResult> {
        if (userId.isBlank()) return Result.failure(IllegalStateException("User must be signed in"))
        val safeDateKey = FitnessCalculators.sanitizeDateKey(dateKey)
        val workoutId = existingWorkoutId?.takeIf { FitnessCalculators.isValidEntityId(it) }
            ?: "w_${UUID.randomUUID().toString().replace("-", "").take(16)}"

        if (existingWorkoutId != null) {
            val owned = dao.getWorkoutWithSets(workoutId, userId)
            if (owned == null) {
                return Result.failure(SecurityException("Workout record does not belong to the signed-in user"))
            }
        }

        val cleanTitle = title.trim().take(100).ifBlank {
            if (type == WorkoutType.STRENGTH) "Strength Session" else "${cardioActivity.ifBlank { "Cardio" }} Session"
        }
        val safeDuration = durationMinutes.coerceIn(1, 1440)
        val safeDistance = distanceKm.coerceIn(0.0, 1000.0)
        val safeHr = avgHeartRate.coerceIn(0, 260)
        val safeCalories = caloriesBurned.coerceIn(0, 15000)
        val totalVolume = if (type == WorkoutType.STRENGTH) {
            FitnessCalculators.calculateWorkingTonnageKg(sets)
        } else 0.0

        val workoutEntity = WorkoutEntity(
            id = workoutId,
            userId = userId,
            workoutType = type.name,
            title = cleanTitle,
            dateKey = safeDateKey,
            startedAtMs = startedAtMs.coerceAtLeast(1L),
            durationMinutes = safeDuration,
            caloriesBurned = safeCalories,
            distanceKm = safeDistance,
            avgHeartRate = safeHr,
            totalVolumeKg = totalVolume,
            cardioActivity = cardioActivity.trim().take(40),
            notes = notes.trim().take(500),
            source = WorkoutSource.PULSETRACK.name,
            prCount = 0,
            syncStatus = "PENDING",
            updatedAtMs = System.currentTimeMillis()
        )

        val setEntities = sets.take(100).mapIndexed { index, set ->
            ExerciseSetEntity(
                id = set.id.ifBlank { "${workoutId}_s_${index + 1}" },
                workoutId = workoutId,
                userId = userId,
                exerciseName = set.exerciseName.trim().take(80),
                muscleGroup = set.muscleGroup.name,
                setIndex = index + 1,
                weightKg = set.weightKg.coerceIn(0.0, 2000.0),
                reps = set.reps.coerceIn(0, 500),
                completed = set.completed,
                warmup = set.warmup,
                pr = false
            )
        }

        dao.upsertWorkoutWithSets(workoutEntity, setEntities)

        // Recalculate PRs & daily metric totals deterministically
        val affectedDates = setOf(safeDateKey)
        recalculatePrsAndDailyMetrics(userId, affectedDates)

        val updatedWorkoutWithSets = dao.getWorkoutWithSets(workoutId, userId)
        val finalWorkout = updatedWorkoutWithSets?.workout ?: workoutEntity
        val finalSets = updatedWorkoutWithSets?.sets ?: setEntities

        val cloudRes = firestoreSync.upsertWorkout(finalWorkout, finalSets)
        val syncedToCloud = cloudRes.isSuccess
        if (syncedToCloud) {
            dao.markWorkoutSynced(workoutId, userId)
        } else {
            scheduleBackgroundSync()
        }

        val settings = preferencesStore.settingsFlow.first()
        var syncedToHc = false
        if (settings.hcSyncWorkouts && existingWorkoutId == null) {
            syncedToHc = healthConnectManager.writeWorkout(finalWorkout)
        }

        return Result.success(
            SaveWorkoutResult(
                workoutId = workoutId,
                newPrCount = finalWorkout.prCount,
                syncedToCloud = syncedToCloud,
                syncedToHealthConnect = syncedToHc
            )
        )
    }

    suspend fun deleteWorkout(userId: String, workoutId: String): Result<Unit> {
        if (userId.isBlank() || !FitnessCalculators.isValidEntityId(workoutId)) {
            return Result.failure(IllegalArgumentException("Missing or invalid workout identifier"))
        }
        val existing = dao.getWorkoutWithSets(workoutId, userId)
        val affectedDate = existing?.workout?.dateKey
        dao.deleteWorkoutById(workoutId, userId)
        if (affectedDate != null) {
            recalculatePrsAndDailyMetrics(userId, setOf(affectedDate))
        } else {
            recalculatePrsAndDailyMetrics(userId, emptySet())
        }
        val cloudRes = firestoreSync.deleteWorkout(workoutId)
        if (cloudRes.isFailure) {
            scheduleBackgroundSync()
        }
        return cloudRes
    }

    /**
     * Re-evaluates all Personal Records chronologically and updates daily workout activeMinutes/calories.
     * Ensures editing or deleting a workout leaves zero stale PR flags or stale daily totals.
     */
    suspend fun recalculatePrsAndDailyMetrics(userId: String, extraDatesToRefresh: Set<String> = emptySet()) {
        val allWorkouts = dao.getWorkoutsWithSetsOnce(userId).sortedBy { it.workout.startedAtMs }
        val best1Rm = mutableMapOf<String, Double>()
        val bestWeight = mutableMapOf<String, Double>()
        val datesToSync = extraDatesToRefresh.toMutableSet()

        for (item in allWorkouts) {
            val w = item.workout
            datesToSync.add(w.dateKey)
            var prHits = 0
            val updatedSets = item.sets.sortedBy { it.setIndex }.map { set ->
                val key = set.exerciseName.trim().lowercase()
                val isWorking = set.completed && !set.warmup && set.weightKg > 0.0 && set.reps > 0
                val isPr = if (isWorking) {
                    val epley = FitnessCalculators.calculateEpley1Rm(set.weightKg, set.reps)
                    val prev1Rm = best1Rm[key] ?: 0.0
                    val prevWeight = bestWeight[key] ?: 0.0
                    val beat = (epley > prev1Rm + 0.01) || (set.weightKg > prevWeight + 0.01)
                    if (epley > prev1Rm) best1Rm[key] = epley
                    if (set.weightKg > prevWeight) bestWeight[key] = set.weightKg
                    // Only flag PR if user had a prior baseline OR this is a meaningful first lift?
                    // First logged lift sets the baseline; subsequent lifts beating it or first max > 0 count!
                    beat && prevWeight > 0.0
                } else {
                    false
                }
                if (isPr) prHits++
                set.copy(pr = isPr)
            }
            val newTonnage = if (w.workoutType == WorkoutType.STRENGTH.name) {
                updatedSets.filter { it.completed && !it.warmup }.sumOf { it.weightKg * it.reps }
            } else {
                w.totalVolumeKg
            }
            if (prHits != w.prCount || newTonnage != w.totalVolumeKg || updatedSets != item.sets) {
                dao.upsertWorkoutWithSets(
                    w.copy(prCount = prHits, totalVolumeKg = newTonnage),
                    updatedSets
                )
            }
        }

        // Recompute daily activeMinutes & caloriesBurned from workouts for affected dates
        val settings = preferencesStore.settingsFlow.first()
        val groupedByDate = allWorkouts.groupBy { it.workout.dateKey }
        for (dateKey in datesToSync) {
            val dayWorkouts = groupedByDate[dateKey].orEmpty()
            val activeMin = dayWorkouts.sumOf { it.workout.durationMinutes }.coerceIn(0, 1440)
            val workoutCals = dayWorkouts.sumOf { it.workout.caloriesBurned }.coerceIn(0, 30000)
            val existing = dao.getDailyMetric(userId, dateKey)
            val stepCals = ((existing?.totalSteps ?: 0) * 0.04).toInt()
            val totalCals = (workoutCals + stepCals).coerceIn(0, 30000)
            if (existing != null || activeMin > 0 || totalCals > 0) {
                val updated = (existing ?: DailyMetricEntity(
                    userId = userId,
                    dateKey = dateKey,
                    stepGoal = settings.dailyStepGoal
                )).copy(
                    activeMinutes = activeMin,
                    caloriesBurned = totalCals,
                    syncedToCloud = false,
                    updatedAtMs = System.currentTimeMillis()
                )
                dao.upsertDailyMetric(updated)
                val cloudRes = firestoreSync.upsertDailyMetric(updated)
                if (cloudRes.isSuccess) {
                    dao.markDailyMetricSynced(userId, dateKey)
                }
            }
        }
    }

    suspend fun syncWithHealthConnect(userId: String): Result<String> {
        if (userId.isBlank()) return Result.failure(IllegalStateException("User not signed in"))
        val status = healthConnectManager.getStatus()
        if (!status.allRequiredGranted) {
            return Result.failure(IllegalStateException("Health Connect permissions not granted"))
        }
        val settings = preferencesStore.settingsFlow.first()
        var importedCount = 0

        // 1. Read today's and last 7 days' steps from Health Connect
        if (settings.hcSyncSteps) {
            val today = LocalDate.now()
            for (offset in 0L..6L) {
                val date = today.minusDays(offset)
                val dateKey = date.toString()
                val hcSteps = healthConnectManager.readDailySteps(date)
                if (hcSteps > 0) {
                    val existing = dao.getDailyMetric(userId, dateKey)
                    val updated = (existing ?: DailyMetricEntity(
                        userId = userId,
                        dateKey = dateKey,
                        stepGoal = settings.dailyStepGoal
                    )).copy(
                        healthConnectSteps = maxOf(existing?.healthConnectSteps ?: 0, hcSteps),
                        syncedToCloud = false,
                        updatedAtMs = System.currentTimeMillis()
                    )
                    dao.upsertDailyMetric(updated)
                    val res = firestoreSync.upsertDailyMetric(updated)
                    if (res.isSuccess) dao.markDailyMetricSynced(userId, dateKey)
                }
            }
        }

        // 2. Import external workouts from Health Connect (deduplicated)
        if (settings.hcSyncWorkouts) {
            val externalWorkouts = healthConnectManager.readExternalWorkouts(userId, daysBack = 30)
            for (ext in externalWorkouts) {
                val existing = dao.getWorkoutWithSets(ext.id, userId)
                if (existing == null) {
                    dao.upsertWorkoutWithSets(ext, emptyList())
                    firestoreSync.upsertWorkout(ext, emptyList()).onSuccess {
                        dao.markWorkoutSynced(ext.id, userId)
                    }
                    importedCount++
                }
            }
            if (importedCount > 0) {
                recalculatePrsAndDailyMetrics(userId)
            }
        }

        return Result.success("Synced steps & imported $importedCount external workouts")
    }

    suspend fun flushPendingToCloud(userId: String) {
        if (userId.isBlank()) return
        val pendingWorkouts = dao.getPendingWorkouts(userId)
        for (workout in pendingWorkouts) {
            val withSets = dao.getWorkoutWithSets(workout.id, userId) ?: continue
            firestoreSync.upsertWorkout(withSets.workout, withSets.sets).onSuccess {
                dao.markWorkoutSynced(workout.id, userId)
            }
        }
        val pendingMetrics = dao.getUnsyncedDailyMetrics(userId)
        for (metric in pendingMetrics) {
            firestoreSync.upsertDailyMetric(metric).onSuccess {
                dao.markDailyMetricSynced(userId, metric.dateKey)
            }
        }
    }

    suspend fun exportBackupJson(userId: String): String {
        val settings = preferencesStore.settingsFlow.first()
        val workouts = dao.getWorkoutsWithSetsOnce(userId)
        val metrics = dao.observeAllDailyMetrics(userId).first()

        val root = JSONObject()
        root.put("exportedAt", System.currentTimeMillis())
        root.put("app", "PulseTrack")
        root.put("unitSystem", settings.unitSystem.name)
        root.put("dailyStepGoal", settings.dailyStepGoal)

        val metricsArray = JSONArray()
        for (m in metrics) {
            metricsArray.put(JSONObject().apply {
                put("dateKey", m.dateKey)
                put("steps", m.totalSteps)
                put("activeMinutes", m.activeMinutes)
                put("caloriesBurned", m.caloriesBurned)
                put("stepGoal", m.stepGoal)
            })
        }
        root.put("dailyMetrics", metricsArray)

        val workoutsArray = JSONArray()
        for (w in workouts) {
            workoutsArray.put(JSONObject().apply {
                put("id", w.workout.id)
                put("title", w.workout.title)
                put("type", w.workout.workoutType)
                put("dateKey", w.workout.dateKey)
                put("durationMinutes", w.workout.durationMinutes)
                put("caloriesBurned", w.workout.caloriesBurned)
                put("distanceKm", w.workout.distanceKm)
                put("totalVolumeKg", w.workout.totalVolumeKg)
                put("source", w.workout.source)
                put("setsCount", w.sets.size)
            })
        }
        root.put("workouts", workoutsArray)
        return root.toString(2)
    }

    suspend fun exportWorkoutsCsv(userId: String): String {
        val workouts = dao.getWorkoutsWithSetsOnce(userId)
        val sb = StringBuilder("Date,Title,Type,DurationMin,Calories,DistanceKm,VolumeKg,PRs,Source\n")
        for (item in workouts) {
            val w = item.workout
            val safeDate = FitnessCalculators.sanitizeCsvCell(w.dateKey)
            val safeTitle = FitnessCalculators.sanitizeCsvCell(w.title)
            val safeType = FitnessCalculators.sanitizeCsvCell(w.workoutType)
            val safeSource = FitnessCalculators.sanitizeCsvCell(w.source)
            sb.append("$safeDate,$safeTitle,$safeType,${w.durationMinutes},${w.caloriesBurned},${w.distanceKm},${w.totalVolumeKg},${w.prCount},$safeSource\n")
        }
        return sb.toString()
    }

    suspend fun clearSessionOnSignOut() {
        ActiveWorkoutService.stop(context)
        preferencesStore.clearAll()
    }

    suspend fun deleteAccountAndAllData(userId: String): Result<Unit> {
        return try {
            val currentUser = Firebase.auth.currentUser
                ?: return Result.failure(IllegalStateException("User must be signed in to delete account."))
            if (currentUser.uid != userId) {
                return Result.failure(SecurityException("Signed-in user mismatch."))
            }
            val lastSignInMs = currentUser.metadata?.lastSignInTimestamp ?: 0L
            if (lastSignInMs > 0L && (System.currentTimeMillis() - lastSignInMs) > 270_000L) {
                return Result.failure(
                    IllegalStateException("Please confirm your Google sign-in before deleting your account.")
                )
            }

            ActiveWorkoutService.stop(context)
            val cloudResult = firestoreSync.deleteAllUserCloudData()
            if (cloudResult.isFailure) {
                return cloudResult
            }
            dao.clearAllUserData(userId)
            preferencesStore.clearAll()
            currentUser.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (BuildConfig.DEBUG) {
                Log.w(TAG, "Account deletion encountered an issue: ${e::class.simpleName}")
            }
            Result.failure(e)
        }
    }

    fun computePersonalRecords(workouts: List<WorkoutLog>): List<ExercisePrSummary> {
        val map = mutableMapOf<String, ExercisePrSummary>()
        for (workout in workouts) {
            for (set in workout.sets) {
                if (!set.completed || set.warmup || set.weightKg <= 0.0 || set.reps <= 0) continue
                val key = set.exerciseName.trim().lowercase()
                val est1Rm = FitnessCalculators.calculateEpley1Rm(set.weightKg, set.reps)
                val existing = map[key]
                if (existing == null || est1Rm > existing.bestEstimated1RmKg) {
                    map[key] = ExercisePrSummary(
                        exerciseName = set.exerciseName,
                        muscleGroup = set.muscleGroup,
                        maxWeightKg = maxOf(existing?.maxWeightKg ?: 0.0, set.weightKg),
                        bestEstimated1RmKg = est1Rm,
                        bestRepsAtMax = set.reps,
                        achievedDateKey = workout.dateKey
                    )
                } else if (set.weightKg > existing.maxWeightKg) {
                    map[key] = existing.copy(maxWeightKg = set.weightKg)
                }
            }
        }
        return map.values.sortedByDescending { it.bestEstimated1RmKg }
    }

    private fun scheduleBackgroundSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "pulsetrack_immediate_sync",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    private fun WorkoutWithSets.toDomain(): WorkoutLog = WorkoutLog(
        id = workout.id,
        userId = workout.userId,
        type = WorkoutType.fromRaw(workout.workoutType),
        title = workout.title,
        dateKey = workout.dateKey,
        startedAtMs = workout.startedAtMs,
        durationMinutes = workout.durationMinutes,
        caloriesBurned = workout.caloriesBurned,
        distanceKm = workout.distanceKm,
        avgHeartRate = workout.avgHeartRate,
        totalVolumeKg = workout.totalVolumeKg,
        cardioActivity = workout.cardioActivity,
        notes = workout.notes,
        source = WorkoutSource.fromRaw(workout.source),
        prCount = workout.prCount,
        sets = sets.sortedBy { it.setIndex }.map {
            ExerciseSetItem(
                id = it.id,
                exerciseName = it.exerciseName,
                muscleGroup = MuscleGroup.fromRaw(it.muscleGroup),
                setIndex = it.setIndex,
                weightKg = it.weightKg,
                reps = it.reps,
                completed = it.completed,
                warmup = it.warmup,
                pr = it.pr
            )
        }
    )

    private fun DailyMetricEntity.toDomain(): DailyMetric = DailyMetric(
        dateKey = dateKey,
        steps = totalSteps,
        manualAdjustmentSteps = manualAdjustmentSteps,
        activeMinutes = activeMinutes,
        caloriesBurned = caloriesBurned,
        stepGoal = stepGoal
    )

    companion object {
        private const val TAG = "FitnessRepository"
    }
}
