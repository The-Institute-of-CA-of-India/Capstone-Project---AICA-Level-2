package com.example.data.healthconnect

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.metadata.Device
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.units.Length
import com.example.data.local.WorkoutEntity
import com.example.domain.model.CardioActivity
import com.example.domain.model.WorkoutSource
import com.example.domain.model.WorkoutType
import com.example.domain.util.FitnessCalculators
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

enum class HealthConnectAvailability {
    AVAILABLE,
    UPDATE_REQUIRED,
    UNAVAILABLE
}

data class HealthConnectStatus(
    val availability: HealthConnectAvailability,
    val grantedPermissions: Set<String> = emptySet(),
    val allRequiredGranted: Boolean = false
)

class HealthConnectManager(private val context: Context) {

    val requiredPermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getWritePermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class)
    )

    fun checkAvailability(): HealthConnectAvailability {
        return when (HealthConnectClient.getSdkStatus(context)) {
            HealthConnectClient.SDK_AVAILABLE -> HealthConnectAvailability.AVAILABLE
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> HealthConnectAvailability.UPDATE_REQUIRED
            else -> HealthConnectAvailability.UNAVAILABLE
        }
    }

    private fun getClientOrNull(): HealthConnectClient? {
        return if (checkAvailability() == HealthConnectAvailability.AVAILABLE) {
            HealthConnectClient.getOrCreate(context)
        } else {
            null
        }
    }

    suspend fun getStatus(): HealthConnectStatus {
        val availability = checkAvailability()
        if (availability != HealthConnectAvailability.AVAILABLE) {
            return HealthConnectStatus(availability = availability)
        }
        return try {
            val client = HealthConnectClient.getOrCreate(context)
            val granted = client.permissionController.getGrantedPermissions()
            HealthConnectStatus(
                availability = availability,
                grantedPermissions = granted,
                allRequiredGranted = granted.containsAll(requiredPermissions)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Unable to query Health Connect permissions: ${e.message}")
            HealthConnectStatus(availability = availability)
        }
    }

    fun buildInstallProviderIntent(): Intent {
        val uriString = "market://details?id=com.google.android.apps.healthdata&url=healthconnect%3A%2F%2Fonboarding"
        return Intent(Intent.ACTION_VIEW).apply {
            setPackage("com.android.vending")
            data = Uri.parse(uriString)
            putExtra("overlay", true)
            putExtra("callerId", context.packageName)
        }
    }

    suspend fun readDailySteps(date: LocalDate = LocalDate.now()): Int {
        val client = getClientOrNull() ?: return 0
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.contains(HealthPermission.getReadPermission(StepsRecord::class))) {
            return 0
        }
        return try {
            val zone = ZoneId.systemDefault()
            val start = date.atStartOfDay(zone).toInstant()
            val end = date.plusDays(1).atStartOfDay(zone).toInstant()
            val response = client.aggregate(
                AggregateRequest(
                    metrics = setOf(StepsRecord.COUNT_TOTAL),
                    timeRangeFilter = TimeRangeFilter.between(start, end)
                )
            )
            (response[StepsRecord.COUNT_TOTAL] ?: 0L).toInt().coerceIn(0, 250_000)
        } catch (e: Exception) {
            Log.w(TAG, "Error reading Health Connect steps: ${e.message}")
            0
        }
    }

    suspend fun readExternalWorkouts(userId: String, daysBack: Int = 30): List<WorkoutEntity> {
        val client = getClientOrNull() ?: return emptyList()
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.contains(HealthPermission.getReadPermission(ExerciseSessionRecord::class))) {
            return emptyList()
        }
        return try {
            val end = Instant.now()
            val start = end.minus(Duration.ofDays(daysBack.toLong()))
            val response = client.readRecords(
                ReadRecordsRequest(
                    recordType = ExerciseSessionRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(start, end)
                )
            )
            val canReadCalories = granted.contains(HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class))
            val canReadDistance = granted.contains(HealthPermission.getReadPermission(DistanceRecord::class))

            response.records
                .filter { record ->
                    // Deduplicate records originally written by PulseTrack
                    record.metadata.dataOrigin.packageName != context.packageName &&
                        !(record.metadata.clientRecordId?.startsWith(CLIENT_RECORD_PREFIX) ?: false)
                }
                .map { session ->
                    val durationMin = Duration.between(session.startTime, session.endTime)
                        .toMinutes()
                        .toInt()
                        .coerceIn(1, 1440)

                    var calories = 0
                    if (canReadCalories) {
                        val calAgg = client.aggregate(
                            AggregateRequest(
                                metrics = setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL),
                                timeRangeFilter = TimeRangeFilter.between(session.startTime, session.endTime)
                            )
                        )
                        calories = (calAgg[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0)
                            .toInt()
                            .coerceIn(0, 15000)
                    }

                    var distanceKm = 0.0
                    if (canReadDistance) {
                        val distAgg = client.aggregate(
                            AggregateRequest(
                                metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
                                timeRangeFilter = TimeRangeFilter.between(session.startTime, session.endTime)
                            )
                        )
                        distanceKm = (distAgg[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0)
                            .coerceIn(0.0, 1000.0)
                    }

                    val isStrength = session.exerciseType in STRENGTH_EXERCISE_TYPES
                    val workoutType = if (isStrength) WorkoutType.STRENGTH else WorkoutType.CARDIO
                    val defaultTitle = mapExerciseTypeLabel(session.exerciseType)
                    val safeUserPrefix = userId.replace(Regex("[^a-zA-Z0-9_\\-]"), "").take(12).ifBlank { "u" }
                    val safeSessionId = session.metadata.id.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    val safeId = "hc_${safeUserPrefix}_$safeSessionId".take(128)
                    val safeTitle = session.title?.trim()?.take(100)?.takeIf { it.isNotBlank() } ?: defaultTitle
                    val safeNotes = session.notes?.trim()?.take(500).orEmpty()

                    WorkoutEntity(
                        id = safeId,
                        userId = userId,
                        workoutType = workoutType.name,
                        title = safeTitle,
                        dateKey = FitnessCalculators.dateKeyFromMillis(session.startTime.toEpochMilli()),
                        startedAtMs = session.startTime.toEpochMilli(),
                        durationMinutes = durationMin,
                        caloriesBurned = calories,
                        distanceKm = distanceKm,
                        avgHeartRate = 0,
                        totalVolumeKg = 0.0,
                        cardioActivity = if (workoutType == WorkoutType.CARDIO) defaultTitle else "",
                        notes = safeNotes,
                        source = WorkoutSource.HEALTH_CONNECT.name,
                        prCount = 0,
                        syncStatus = "PENDING",
                        updatedAtMs = System.currentTimeMillis()
                    )
                }
        } catch (e: Exception) {
            Log.w(TAG, "Error reading Health Connect workouts: ${e.message}")
            emptyList()
        }
    }

    suspend fun writeWorkout(workout: WorkoutEntity): Boolean {
        val client = getClientOrNull() ?: return false
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.contains(HealthPermission.getWritePermission(ExerciseSessionRecord::class))) {
            return false
        }
        return try {
            val start = Instant.ofEpochMilli(workout.startedAtMs)
            val end = start.plus(Duration.ofMinutes(workout.durationMinutes.toLong().coerceAtLeast(1L)))
            val zoneOffset = ZoneOffset.systemDefault().rules.getOffset(start)
            val clientRecordId = "$CLIENT_RECORD_PREFIX${workout.id}"
            val metadata = Metadata.activelyRecorded(
                clientRecordId = clientRecordId,
                device = Device(type = Device.TYPE_PHONE)
            )

            val records = mutableListOf<androidx.health.connect.client.records.Record>()
            val exerciseType = if (workout.workoutType == WorkoutType.STRENGTH.name) {
                ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING
            } else {
                when (CardioActivity.fromRaw(workout.cardioActivity)) {
                    CardioActivity.RUN -> ExerciseSessionRecord.EXERCISE_TYPE_RUNNING
                    CardioActivity.CYCLE -> ExerciseSessionRecord.EXERCISE_TYPE_BIKING
                    CardioActivity.WALK -> ExerciseSessionRecord.EXERCISE_TYPE_WALKING
                    CardioActivity.HIIT -> ExerciseSessionRecord.EXERCISE_TYPE_HIGH_INTENSITY_INTERVAL_TRAINING
                    CardioActivity.SWIM -> ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL
                    CardioActivity.ROW -> ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE
                    CardioActivity.CLIMB -> ExerciseSessionRecord.EXERCISE_TYPE_STAIR_CLIMBING
                    CardioActivity.ELLIPTICAL -> ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL
                }
            }

            records.add(
                ExerciseSessionRecord(
                    startTime = start,
                    startZoneOffset = zoneOffset,
                    endTime = end,
                    endZoneOffset = zoneOffset,
                    exerciseType = exerciseType,
                    title = workout.title,
                    notes = workout.notes.ifBlank { null },
                    metadata = metadata
                )
            )

            if (workout.caloriesBurned > 0 &&
                granted.contains(HealthPermission.getWritePermission(TotalCaloriesBurnedRecord::class))
            ) {
                records.add(
                    TotalCaloriesBurnedRecord(
                        startTime = start,
                        startZoneOffset = zoneOffset,
                        endTime = end,
                        endZoneOffset = zoneOffset,
                        energy = Energy.kilocalories(workout.caloriesBurned.toDouble()),
                        metadata = Metadata.activelyRecorded(
                            clientRecordId = "${clientRecordId}_cal",
                            device = Device(type = Device.TYPE_PHONE)
                        )
                    )
                )
            }

            if (workout.distanceKm > 0.0 &&
                granted.contains(HealthPermission.getWritePermission(DistanceRecord::class))
            ) {
                records.add(
                    DistanceRecord(
                        startTime = start,
                        startZoneOffset = zoneOffset,
                        endTime = end,
                        endZoneOffset = zoneOffset,
                        distance = Length.kilometers(workout.distanceKm),
                        metadata = Metadata.activelyRecorded(
                            clientRecordId = "${clientRecordId}_dist",
                            device = Device(type = Device.TYPE_PHONE)
                        )
                    )
                )
            }

            client.insertRecords(records)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Error writing workout to Health Connect: ${e.message}")
            false
        }
    }

    private fun mapExerciseTypeLabel(exerciseType: Int): String = when (exerciseType) {
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "Run"
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Cycle"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Walk"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL,
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "Swim"
        ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE -> "Row"
        ExerciseSessionRecord.EXERCISE_TYPE_STAIR_CLIMBING -> "Climb"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Elliptical"
        ExerciseSessionRecord.EXERCISE_TYPE_HIGH_INTENSITY_INTERVAL_TRAINING -> "HIIT"
        ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING,
        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "Strength Training"
        else -> "Workout"
    }

    companion object {
        private const val TAG = "HealthConnectMgr"
        private const val CLIENT_RECORD_PREFIX = "pulsetrack_workout_"
        private val STRENGTH_EXERCISE_TYPES = setOf(
            ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING,
            ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
            ExerciseSessionRecord.EXERCISE_TYPE_CALISTHENICS
        )
    }
}
