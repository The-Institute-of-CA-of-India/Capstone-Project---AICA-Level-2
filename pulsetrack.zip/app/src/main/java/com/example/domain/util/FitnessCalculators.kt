package com.example.domain.util

import com.example.domain.model.CardioActivity
import com.example.domain.model.ExerciseSetItem
import com.example.domain.model.UnitSystem
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

data class StepDeltaResult(
    val deltaSteps: Int,
    val newBootStepsBaseline: Long,
    val dateRolledOver: Boolean
)

object FitnessCalculators {
    private const val KG_TO_LBS = 2.20462
    private const val KM_TO_MILES = 0.621371
    private val DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    fun todayDateKey(zoneId: ZoneId = ZoneId.systemDefault()): String =
        LocalDate.now(zoneId).format(DATE_FORMATTER)

    fun dateKeyFromMillis(epochMillis: Long, zoneId: ZoneId = ZoneId.systemDefault()): String =
        Instant.ofEpochMilli(epochMillis).atZone(zoneId).toLocalDate().format(DATE_FORMATTER)

    fun dateKeysBack(days: Int, fromDate: LocalDate = LocalDate.now()): List<String> {
        return (days - 1 downTo 0).map { offset ->
            fromDate.minusDays(offset.toLong()).format(DATE_FORMATTER)
        }
    }

    /**
     * Epley 1RM formula: weight * (1 + reps / 30). For 1 rep returns weight directly.
     */
    fun calculateEpley1Rm(weightKg: Double, reps: Int): Double {
        if (weightKg <= 0.0 || reps <= 0) return 0.0
        if (reps == 1) return weightKg
        return weightKg * (1.0 + reps / 30.0)
    }

    fun calculateWorkingTonnageKg(sets: List<ExerciseSetItem>): Double {
        return sets.filter { it.completed && !it.warmup }
            .sumOf { it.weightKg.coerceAtLeast(0.0) * it.reps.coerceAtLeast(0) }
    }

    fun kgToDisplay(weightKg: Double, unitSystem: UnitSystem): Double =
        when (unitSystem) {
            UnitSystem.METRIC -> weightKg
            UnitSystem.IMPERIAL -> weightKg * KG_TO_LBS
        }

    fun displayToKg(displayWeight: Double, unitSystem: UnitSystem): Double =
        when (unitSystem) {
            UnitSystem.METRIC -> displayWeight
            UnitSystem.IMPERIAL -> displayWeight / KG_TO_LBS
        }

    fun kmToDisplay(distanceKm: Double, unitSystem: UnitSystem): Double =
        when (unitSystem) {
            UnitSystem.METRIC -> distanceKm
            UnitSystem.IMPERIAL -> distanceKm * KM_TO_MILES
        }

    fun displayToKm(displayDistance: Double, unitSystem: UnitSystem): Double =
        when (unitSystem) {
            UnitSystem.METRIC -> displayDistance
            UnitSystem.IMPERIAL -> displayDistance / KM_TO_MILES
        }

    fun formatWeight(weightKg: Double, unitSystem: UnitSystem): String {
        val value = kgToDisplay(weightKg, unitSystem)
        return if (value % 1.0 < 0.05 || value % 1.0 > 0.95) {
            "${value.roundToInt()} ${unitSystem.weightLabel}"
        } else {
            String.format(Locale.US, "%.1f %s", value, unitSystem.weightLabel)
        }
    }

    fun formatDistance(distanceKm: Double, unitSystem: UnitSystem): String {
        val value = kmToDisplay(distanceKm, unitSystem)
        return String.format(Locale.US, "%.2f %s", value, unitSystem.distanceLabel)
    }

    fun formatPace(durationMinutes: Int, distanceKm: Double, unitSystem: UnitSystem): String {
        val dist = kmToDisplay(distanceKm, unitSystem)
        if (durationMinutes <= 0 || dist <= 0.01) return "--:-- /${unitSystem.distanceLabel}"
        val secPerUnit = ((durationMinutes * 60.0) / dist).roundToInt()
        val mins = secPerUnit / 60
        val secs = secPerUnit % 60
        return String.format(Locale.US, "%d:%02d /%s", mins, secs, unitSystem.distanceLabel)
    }

    fun formatTimerSeconds(totalSeconds: Long): String {
        val clamped = totalSeconds.coerceAtLeast(0L)
        val hours = clamped / 3600
        val minutes = (clamped % 3600) / 60
        val seconds = clamped % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun estimateCardioCalories(
        activity: CardioActivity,
        durationMinutes: Int,
        bodyWeightKg: Double = 75.0,
        customMet: Double? = null
    ): Int {
        if (durationMinutes <= 0) return 0
        val met = (customMet ?: activity.met).coerceIn(1.0, 20.0)
        val kcalPerMin = (met * 3.5 * bodyWeightKg) / 200.0
        return (kcalPerMin * durationMinutes).roundToInt().coerceIn(5, 15000)
    }

    fun estimateStrengthCalories(durationMinutes: Int, completedWorkingSets: Int): Int {
        if (durationMinutes <= 0 && completedWorkingSets <= 0) return 0
        val base = (5.0 * 3.5 * 75.0) / 200.0 * durationMinutes.coerceAtLeast(1)
        val setBonus = completedWorkingSets * 3.5
        return (base + setBonus).roundToInt().coerceIn(10, 15000)
    }

    /**
     * Safely computes daily step deltas from Android cumulative TYPE_STEP_COUNTER,
     * handling first read, device reboot counter resets, and midnight date rollovers.
     */
    fun calculateStepSensorDelta(
        currentBootSteps: Long,
        lastBootSteps: Long,
        lastDateKey: String,
        todayDateKey: String
    ): StepDeltaResult {
        val sanitizedCurrent = currentBootSteps.coerceAtLeast(0L)
        val rolledOver = lastDateKey.isNotEmpty() && lastDateKey != todayDateKey
        if (lastBootSteps < 0L) {
            return StepDeltaResult(
                deltaSteps = 0,
                newBootStepsBaseline = sanitizedCurrent,
                dateRolledOver = rolledOver
            )
        }
        val rawDelta = if (sanitizedCurrent < lastBootSteps) {
            // Device rebooted and TYPE_STEP_COUNTER reset to 0
            sanitizedCurrent
        } else {
            sanitizedCurrent - lastBootSteps
        }
        val clampedDelta = rawDelta.coerceIn(0L, 100_000L).toInt()
        return StepDeltaResult(
            deltaSteps = clampedDelta,
            newBootStepsBaseline = sanitizedCurrent,
            dateRolledOver = rolledOver
        )
    }

    private val DATE_KEY_REGEX = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
    private val ENTITY_ID_REGEX = Regex("^[a-zA-Z0-9_\\-]{1,128}$")
    private val CSV_FORMULA_PREFIXES = setOf('=', '+', '-', '@', '\t', '\r')

    fun sanitizeDateKey(raw: String?): String {
        val candidate = raw?.trim().orEmpty()
        return if (DATE_KEY_REGEX.matches(candidate)) candidate else todayDateKey()
    }

    fun isValidEntityId(raw: String?): Boolean {
        val candidate = raw?.trim().orEmpty()
        return ENTITY_ID_REGEX.matches(candidate)
    }

    /**
     * Neutralizes spreadsheet formula injection (=, +, -, @, tab, CR) and strips
     * line breaks before RFC-4180 quote-escaping for safe CSV export.
     */
    fun sanitizeCsvCell(raw: String): String {
        val singleLine = raw
            .replace("\r\n", " ")
            .replace('\r', ' ')
            .replace('\n', ' ')
        val trimmedLeading = singleLine.trimStart { it == ' ' || it == '\t' }
        val neutralized = if (
            singleLine.isNotEmpty() &&
            (singleLine[0] in CSV_FORMULA_PREFIXES ||
                (trimmedLeading.isNotEmpty() && trimmedLeading[0] in CSV_FORMULA_PREFIXES))
        ) {
            "'$singleLine"
        } else {
            singleLine
        }
        val escaped = neutralized.replace("\"", "\"\"")
        return "\"$escaped\""
    }
}
