package com.example.domain.model

enum class UnitSystem(val weightLabel: String, val distanceLabel: String) {
    METRIC("kg", "km"),
    IMPERIAL("lbs", "mi");

    companion object {
        fun fromRaw(raw: String?): UnitSystem =
            entries.firstOrNull { it.name == raw } ?: METRIC
    }
}

enum class WorkoutType(val label: String) {
    STRENGTH("Strength"),
    CARDIO("Cardio");

    companion object {
        fun fromRaw(raw: String?): WorkoutType =
            entries.firstOrNull { it.name == raw } ?: STRENGTH
    }
}

enum class WorkoutSource(val label: String) {
    PULSETRACK("PulseTrack"),
    HEALTH_CONNECT("Health Connect");

    companion object {
        fun fromRaw(raw: String?): WorkoutSource =
            entries.firstOrNull { it.name == raw } ?: PULSETRACK
    }
}

enum class MuscleGroup(val label: String) {
    CHEST("Chest"),
    BACK("Back"),
    LEGS("Legs"),
    SHOULDERS("Shoulders"),
    ARMS("Arms"),
    CORE("Core"),
    FULL_BODY("Full Body");

    companion object {
        fun fromRaw(raw: String?): MuscleGroup =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) || it.label.equals(raw, ignoreCase = true) }
                ?: FULL_BODY
    }
}

enum class CardioActivity(val label: String, val met: Double) {
    RUN("Run", 9.8),
    CYCLE("Cycle", 7.5),
    WALK("Walk", 4.3),
    HIIT("HIIT", 9.5),
    SWIM("Swim", 8.3),
    ROW("Row", 8.5),
    CLIMB("Climb", 9.0),
    ELLIPTICAL("Elliptical", 6.0);

    companion object {
        fun fromRaw(raw: String?): CardioActivity {
            if (raw.isNullOrBlank()) return RUN
            entries.firstOrNull {
                it.name.equals(raw, ignoreCase = true) || it.label.equals(raw, ignoreCase = true)
            }?.let { return it }

            ExerciseCatalog.defaultCardioExercises.firstOrNull {
                it.name.equals(raw, ignoreCase = true)
            }?.let { return it.cardioActivity }

            val lower = raw.lowercase()
            return when {
                "cycl" in lower || "bik" in lower || "spin" in lower -> CYCLE
                "walk" in lower || "hik" in lower || "ruck" in lower -> WALK
                "swim" in lower || "aqua" in lower -> SWIM
                "row" in lower || "skierg" in lower || "ergometer" in lower -> ROW
                "stair" in lower || "climb" in lower || "ladder" in lower -> CLIMB
                "elliptical" in lower || "arc" in lower -> ELLIPTICAL
                "hiit" in lower || "jump rope" in lower || "skip" in lower || "tabata" in lower ||
                    "box" in lower || "emom" in lower || "plyo" in lower -> HIIT
                else -> RUN
            }
        }
    }
}

data class ExerciseCatalogItem(
    val name: String,
    val muscleGroup: MuscleGroup = MuscleGroup.FULL_BODY,
    val workoutType: WorkoutType = WorkoutType.STRENGTH,
    val cardioActivity: CardioActivity = CardioActivity.RUN,
    val met: Double = 5.0,
    val isCustom: Boolean = false
)

data class ExerciseSetItem(
    val id: String,
    val exerciseName: String,
    val muscleGroup: MuscleGroup,
    val setIndex: Int,
    val weightKg: Double,
    val reps: Int,
    val completed: Boolean = true,
    val warmup: Boolean = false,
    val pr: Boolean = false
)

data class WorkoutLog(
    val id: String,
    val userId: String,
    val type: WorkoutType,
    val title: String,
    val dateKey: String,
    val startedAtMs: Long,
    val durationMinutes: Int,
    val caloriesBurned: Int,
    val distanceKm: Double = 0.0,
    val avgHeartRate: Int = 0,
    val totalVolumeKg: Double = 0.0,
    val cardioActivity: String = "",
    val notes: String = "",
    val source: WorkoutSource = WorkoutSource.PULSETRACK,
    val prCount: Int = 0,
    val sets: List<ExerciseSetItem> = emptyList()
)

data class DailyMetric(
    val dateKey: String,
    val steps: Int,
    val manualAdjustmentSteps: Int,
    val activeMinutes: Int,
    val caloriesBurned: Int,
    val stepGoal: Int
)

data class UserProfileSettings(
    val userId: String = "",
    val displayName: String = "Athlete",
    val email: String = "",
    val unitSystem: UnitSystem = UnitSystem.METRIC,
    val dailyStepGoal: Int = 10000,
    val weeklyWorkoutGoal: Int = 4,
    val useDynamicColor: Boolean = false,
    val hcSyncSteps: Boolean = true,
    val hcSyncWorkouts: Boolean = true,
    val hcSyncCalories: Boolean = true,
    val onboardingCompleted: Boolean = false
)

data class WorkoutTemplate(
    val id: String,
    val title: String,
    val subtitle: String,
    val type: WorkoutType,
    val cardioActivity: CardioActivity = CardioActivity.RUN,
    val cardioExerciseName: String = "Outdoor Road Run",
    val defaultDistanceKm: Double = 5.0,
    val defaultDurationMin: Int = 30,
    val exercises: List<TemplateExercise> = emptyList()
)

data class TemplateExercise(
    val exerciseName: String,
    val muscleGroup: MuscleGroup,
    val defaultSets: Int,
    val defaultWeightKg: Double,
    val defaultReps: Int
)

data class ExercisePrSummary(
    val exerciseName: String,
    val muscleGroup: MuscleGroup,
    val maxWeightKg: Double,
    val bestEstimated1RmKg: Double,
    val bestRepsAtMax: Int,
    val achievedDateKey: String
)

object ExerciseCatalog {
    // 80 Strength Exercises across 7 muscle groups
    val defaultStrengthExercises: List<ExerciseCatalogItem> = listOf(
        // Chest (12)
        ExerciseCatalogItem("Barbell Bench Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Incline Barbell Bench Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Decline Barbell Bench Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Flat Dumbbell Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Incline Dumbbell Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Decline Dumbbell Press", MuscleGroup.CHEST),
        ExerciseCatalogItem("Dumbbell Chest Fly", MuscleGroup.CHEST),
        ExerciseCatalogItem("Cable Chest Fly", MuscleGroup.CHEST),
        ExerciseCatalogItem("Pec Deck Machine Fly", MuscleGroup.CHEST),
        ExerciseCatalogItem("Weighted Dips", MuscleGroup.CHEST),
        ExerciseCatalogItem("Push-Ups", MuscleGroup.CHEST),
        ExerciseCatalogItem("Decline Push-Ups", MuscleGroup.CHEST),
        // Back (12)
        ExerciseCatalogItem("Deadlift", MuscleGroup.BACK),
        ExerciseCatalogItem("Sumo Deadlift", MuscleGroup.BACK),
        ExerciseCatalogItem("Pull-Ups", MuscleGroup.BACK),
        ExerciseCatalogItem("Chin-Ups", MuscleGroup.BACK),
        ExerciseCatalogItem("Barbell Bent-Over Row", MuscleGroup.BACK),
        ExerciseCatalogItem("Pendlay Row", MuscleGroup.BACK),
        ExerciseCatalogItem("T-Bar Row", MuscleGroup.BACK),
        ExerciseCatalogItem("Lat Pulldown", MuscleGroup.BACK),
        ExerciseCatalogItem("Close-Grip Lat Pulldown", MuscleGroup.BACK),
        ExerciseCatalogItem("Seated Cable Row", MuscleGroup.BACK),
        ExerciseCatalogItem("Single-Arm Dumbbell Row", MuscleGroup.BACK),
        ExerciseCatalogItem("Chest-Supported Machine Row", MuscleGroup.BACK),
        // Legs (14)
        ExerciseCatalogItem("Barbell Back Squat", MuscleGroup.LEGS),
        ExerciseCatalogItem("Barbell Front Squat", MuscleGroup.LEGS),
        ExerciseCatalogItem("Goblet Squat", MuscleGroup.LEGS),
        ExerciseCatalogItem("Hack Squat Machine", MuscleGroup.LEGS),
        ExerciseCatalogItem("Bulgarian Split Squat", MuscleGroup.LEGS),
        ExerciseCatalogItem("Walking Dumbbell Lunge", MuscleGroup.LEGS),
        ExerciseCatalogItem("Leg Press", MuscleGroup.LEGS),
        ExerciseCatalogItem("Romanian Deadlift", MuscleGroup.LEGS),
        ExerciseCatalogItem("Stiff-Legged Deadlift", MuscleGroup.LEGS),
        ExerciseCatalogItem("Leg Extension", MuscleGroup.LEGS),
        ExerciseCatalogItem("Seated Leg Curl", MuscleGroup.LEGS),
        ExerciseCatalogItem("Lying Leg Curl", MuscleGroup.LEGS),
        ExerciseCatalogItem("Hip Thrust", MuscleGroup.LEGS),
        ExerciseCatalogItem("Standing Calf Raise", MuscleGroup.LEGS),
        // Shoulders (11)
        ExerciseCatalogItem("Overhead Barbell Press", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Seated Dumbbell Shoulder Press", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Arnold Press", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Machine Shoulder Press", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Dumbbell Lateral Raise", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Cable Lateral Raise", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Front Dumbbell Raise", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Rear Delt Machine Fly", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Bent-Over Reverse Fly", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Face Pull", MuscleGroup.SHOULDERS),
        ExerciseCatalogItem("Barbell Upright Row", MuscleGroup.SHOULDERS),
        // Arms (12)
        ExerciseCatalogItem("Barbell Bicep Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("EZ-Bar Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Alternating Dumbbell Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Hammer Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Incline Dumbbell Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Preacher Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Cable Bicep Curl", MuscleGroup.ARMS),
        ExerciseCatalogItem("Tricep Rope Pushdown", MuscleGroup.ARMS),
        ExerciseCatalogItem("Tricep Straight-Bar Pushdown", MuscleGroup.ARMS),
        ExerciseCatalogItem("Overhead Dumbbell Tricep Extension", MuscleGroup.ARMS),
        ExerciseCatalogItem("Skull Crushers", MuscleGroup.ARMS),
        ExerciseCatalogItem("Close-Grip Bench Press", MuscleGroup.ARMS),
        // Core (10)
        ExerciseCatalogItem("Hanging Leg Raise", MuscleGroup.CORE),
        ExerciseCatalogItem("Hanging Knee Raise", MuscleGroup.CORE),
        ExerciseCatalogItem("Cable Crunch", MuscleGroup.CORE),
        ExerciseCatalogItem("Ab Wheel Rollout", MuscleGroup.CORE),
        ExerciseCatalogItem("Weighted Plank", MuscleGroup.CORE),
        ExerciseCatalogItem("Side Plank", MuscleGroup.CORE),
        ExerciseCatalogItem("Russian Twist", MuscleGroup.CORE),
        ExerciseCatalogItem("Bicycle Crunch", MuscleGroup.CORE),
        ExerciseCatalogItem("Decline Sit-Up", MuscleGroup.CORE),
        ExerciseCatalogItem("Pallof Press", MuscleGroup.CORE),
        // Full Body (9)
        ExerciseCatalogItem("Kettlebell Swing", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Clean & Press", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Power Clean", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Barbell Thruster", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Turkish Get-Up", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Farmer's Walk", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Burpees", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Sled Push", MuscleGroup.FULL_BODY),
        ExerciseCatalogItem("Battle Ropes", MuscleGroup.FULL_BODY)
    )

    // 28 Cardio Training Exercises across 8 cardio modalities
    val defaultCardioExercises: List<ExerciseCatalogItem> = listOf(
        // Run (6)
        ExerciseCatalogItem("Outdoor Road Run", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 9.8),
        ExerciseCatalogItem("Treadmill Run", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 9.0),
        ExerciseCatalogItem("Trail Running", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 10.5),
        ExerciseCatalogItem("Track Sprint Intervals", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 12.0),
        ExerciseCatalogItem("Tempo Run", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 11.0),
        ExerciseCatalogItem("Recovery Jog", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.RUN, 7.5),
        // Cycle (4)
        ExerciseCatalogItem("Outdoor Road Cycling", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.CYCLE, 8.0),
        ExerciseCatalogItem("Stationary Spin Bike", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.CYCLE, 7.5),
        ExerciseCatalogItem("Air / Assault Bike", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.CYCLE, 10.5),
        ExerciseCatalogItem("Mountain Biking", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.CYCLE, 8.5),
        // Walk (4)
        ExerciseCatalogItem("Brisk Outdoor Walk", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.WALK, 4.3),
        ExerciseCatalogItem("Incline Treadmill Walk", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.WALK, 6.0),
        ExerciseCatalogItem("Rucking / Weighted Walk", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.WALK, 6.5),
        ExerciseCatalogItem("Outdoor Hiking", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.WALK, 6.0),
        // Row (2)
        ExerciseCatalogItem("Rowing Machine (Ergometer)", MuscleGroup.BACK, WorkoutType.CARDIO, CardioActivity.ROW, 8.5),
        ExerciseCatalogItem("SkiErg Intervals", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.ROW, 8.8),
        // Climb (2)
        ExerciseCatalogItem("StairMaster / StepMill", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.CLIMB, 9.0),
        ExerciseCatalogItem("VersaClimber / Jacob's Ladder", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.CLIMB, 10.0),
        // Elliptical (2)
        ExerciseCatalogItem("Elliptical Trainer", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.ELLIPTICAL, 5.5),
        ExerciseCatalogItem("Arc Trainer", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.ELLIPTICAL, 7.0),
        // Swim (3)
        ExerciseCatalogItem("Lap Swimming (Freestyle)", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.SWIM, 8.3),
        ExerciseCatalogItem("Open Water Swim", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.SWIM, 9.0),
        ExerciseCatalogItem("Aqua Jogging", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.SWIM, 6.0),
        // HIIT & Conditioning (5)
        ExerciseCatalogItem("Jump Rope / Skipping", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.HIIT, 11.0),
        ExerciseCatalogItem("Tabata Sprint Circuit", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.HIIT, 11.5),
        ExerciseCatalogItem("Box Jumps & Plyometrics", MuscleGroup.LEGS, WorkoutType.CARDIO, CardioActivity.HIIT, 9.5),
        ExerciseCatalogItem("Boxing Heavy Bag Conditioning", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.HIIT, 8.8),
        ExerciseCatalogItem("Kettlebell EMOM Conditioning", MuscleGroup.FULL_BODY, WorkoutType.CARDIO, CardioActivity.HIIT, 9.2)
    )

    // 108 total built-in Strength + Cardio exercises
    val defaultExercises: List<ExerciseCatalogItem> = defaultStrengthExercises + defaultCardioExercises

    val starterTemplates: List<WorkoutTemplate> = listOf(
        WorkoutTemplate(
            id = "tpl_push",
            title = "Push Day",
            subtitle = "Chest · Shoulders · Triceps",
            type = WorkoutType.STRENGTH,
            exercises = listOf(
                TemplateExercise("Barbell Bench Press", MuscleGroup.CHEST, 3, 60.0, 8),
                TemplateExercise("Overhead Barbell Press", MuscleGroup.SHOULDERS, 3, 40.0, 8),
                TemplateExercise("Incline Dumbbell Press", MuscleGroup.CHEST, 3, 22.5, 10),
                TemplateExercise("Dumbbell Lateral Raise", MuscleGroup.SHOULDERS, 3, 10.0, 12),
                TemplateExercise("Tricep Rope Pushdown", MuscleGroup.ARMS, 3, 20.0, 12)
            )
        ),
        WorkoutTemplate(
            id = "tpl_pull",
            title = "Pull Day",
            subtitle = "Back · Rear Delts · Biceps",
            type = WorkoutType.STRENGTH,
            exercises = listOf(
                TemplateExercise("Barbell Bent-Over Row", MuscleGroup.BACK, 3, 60.0, 8),
                TemplateExercise("Lat Pulldown", MuscleGroup.BACK, 3, 55.0, 10),
                TemplateExercise("Seated Cable Row", MuscleGroup.BACK, 3, 50.0, 10),
                TemplateExercise("Face Pull", MuscleGroup.SHOULDERS, 3, 18.0, 15),
                TemplateExercise("Barbell Bicep Curl", MuscleGroup.ARMS, 3, 30.0, 10)
            )
        ),
        WorkoutTemplate(
            id = "tpl_legs",
            title = "Leg Day",
            subtitle = "Quads · Hamstrings · Calves",
            type = WorkoutType.STRENGTH,
            exercises = listOf(
                TemplateExercise("Barbell Back Squat", MuscleGroup.LEGS, 3, 80.0, 6),
                TemplateExercise("Romanian Deadlift", MuscleGroup.LEGS, 3, 70.0, 8),
                TemplateExercise("Leg Press", MuscleGroup.LEGS, 3, 140.0, 10),
                TemplateExercise("Seated Leg Curl", MuscleGroup.LEGS, 3, 40.0, 12),
                TemplateExercise("Standing Calf Raise", MuscleGroup.LEGS, 3, 60.0, 15)
            )
        ),
        WorkoutTemplate(
            id = "tpl_5k",
            title = "5K Run",
            subtitle = "Endurance · Steady Pace",
            type = WorkoutType.CARDIO,
            cardioActivity = CardioActivity.RUN,
            cardioExerciseName = "Outdoor Road Run",
            defaultDistanceKm = 5.0,
            defaultDurationMin = 28
        )
    )
}
