package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

class ActiveWorkoutService : Service() {

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Active Workout"
        val subtitle = intent?.getStringExtra(EXTRA_SUBTITLE) ?: "Tracking duration & rest intervals"

        if (intent?.action == ACTION_STOP || pendingStop) {
            if (isStartForegroundRequested && !hasCalledStartForeground && hasHealthForegroundPermission(this)) {
                try {
                    promoteToForeground(title, subtitle)
                } catch (e: Exception) {
                    Log.w(TAG, "Unable to promote before stopping workout service: ${e.message}")
                }
            }
            stopForegroundAndSelf()
            return START_NOT_STICKY
        }

        if (!hasHealthForegroundPermission(this)) {
            Log.i(TAG, "Skipping foreground workout service: ACTIVITY_RECOGNITION permission not granted")
            resetFlags()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            promoteToForeground(title, subtitle)
            if (pendingStop) {
                stopForegroundAndSelf()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Foreground workout notification unavailable: ${e.message}")
            resetFlags()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        resetFlags()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun promoteToForeground(title: String, subtitle: String) {
        val notification = buildNotification(title, subtitle)
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, foregroundType)
        hasCalledStartForeground = true
    }

    private fun stopForegroundAndSelf() {
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        resetFlags()
        stopSelf()
    }

    private fun ensureChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.workout_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.workout_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(title: String, subtitle: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_workout_notification)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()
    }

    companion object {
        private const val TAG = "ActiveWorkoutService"
        private const val CHANNEL_ID = "pulsetrack_active_workout"
        private const val NOTIFICATION_ID = 4012
        const val ACTION_START = "com.example.action.START_WORKOUT_SERVICE"
        const val ACTION_STOP = "com.example.action.STOP_WORKOUT_SERVICE"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_SUBTITLE = "extra_subtitle"

        @Volatile
        private var isStartForegroundRequested = false

        @Volatile
        private var hasCalledStartForeground = false

        @Volatile
        private var pendingStop = false

        private fun resetFlags() {
            isStartForegroundRequested = false
            hasCalledStartForeground = false
            pendingStop = false
        }

        fun hasHealthForegroundPermission(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACTIVITY_RECOGNITION
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }

        fun start(context: Context, title: String, subtitle: String) {
            if (!hasHealthForegroundPermission(context)) {
                Log.d(TAG, "ACTIVITY_RECOGNITION not granted; running workout timer in-app")
                return
            }
            val intent = Intent(context, ActiveWorkoutService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_SUBTITLE, subtitle)
            }
            pendingStop = false
            isStartForegroundRequested = true
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                resetFlags()
                Log.w(TAG, "Could not start workout foreground service: ${e.message}")
            }
        }

        fun stop(context: Context) {
            if (!isStartForegroundRequested && !hasCalledStartForeground) {
                return
            }
            pendingStop = true
            if (hasCalledStartForeground) {
                try {
                    context.stopService(Intent(context, ActiveWorkoutService::class.java))
                } catch (_: Exception) {
                }
            }
            // If startForegroundService() is still in flight, onStartCommand() observes
            // pendingStop, promotes to foreground first to satisfy Android's contract,
            // and immediately stops itself cleanly.
        }
    }
}
