# Preserve line numbers for crash debugging
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Keep @Keep annotated Firestore DTOs and their members
-keep @androidx.annotation.Keep class * { *; }
-keepclassmembers class * {
    @com.google.firebase.firestore.DocumentId <fields>;
    @com.google.firebase.firestore.ServerTimestamp <fields>;
    @com.google.firebase.firestore.PropertyName <fields>;
}

# Health Connect & Play Services Credential Manager
-keep class androidx.health.connect.client.records.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
