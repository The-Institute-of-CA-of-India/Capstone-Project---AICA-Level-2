# Valuation Assignment Tool – Desktop version (PyQt5)

## 1. Installation (Windows, one time)

| Step | What to do |
|---|---|
| 1 | Install **Python 3.11 or 3.12 (64-bit)** from https://www.python.org/downloads/windows/. On the first installer screen, **tick "Add python.exe to PATH"**. |
| 2 | Unzip `ValuationTool.zip` to a folder, for example `D:\ValuationTool`. Use a path you can write to, not `C:\Program Files`. |
| 3 | Double-click **`INSTALL_Requirements.bat`**. It sets up a private Python environment (`.venv`), installs every library, and then checks them. |
| 4 | Double-click **`RUN_ValuationTool.bat`** each time you want to use the tool. |

`RUN_ValuationTool.bat` runs the installer automatically on first use, or if a library is missing.
Step 3 is therefore optional.

### Libraries installed (requirements.txt)
| Library | Used for |
|---|---|
| PyQt5 | Desktop window (GUI) |
| pandas, numpy | Calculations; reading CSV / Excel |
| openpyxl | .xlsx files (FBIL yield file, index history) |
| xlrd | old .xls files (Damodaran `betaemerg.xls`) |
| python-docx, lxml | Word reports |
| reportlab | PDF evidence sheets |

Manual alternative: `python -m pip install -r requirements.txt`

### Batch files
| File | Purpose |
|---|---|
| `INSTALL_Requirements.bat` | Installs or repairs all libraries and checks them |
| `RUN_ValuationTool.bat` | Starts the tool with no console window |
| `RUN_ValuationTool_Debug.bat` | Starts the tool with a console window. Use it if the tool doesn't open, so you can see the error. |
| `DOWNLOAD_Offline_Packages.bat` | For office PCs **without internet**. Run it on a PC with internet; it creates a `wheels` folder. Copy that folder into the tool folder on the office PC. The installer then works offline. |
| `BUILD_EXE.bat` | Optional. Builds `dist\ValuationTool\ValuationTool.exe`. Copy that folder to staff PCs, which then need **no Python and no libraries**. |
| `RUN_Web_Version_optional.bat` | Optional browser version (needs Streamlit). It isn't needed for the desktop tool. |

To check the libraries at any time, run `.venv\Scripts\python check_setup.py`.

### Troubleshooting
* **"Python is not installed"**: reinstall Python with "Add python.exe to PATH" ticked.
* **Install fails behind an office proxy**: open Command Prompt and run
  `set HTTPS_PROXY=http://user:password@proxyserver:port`. Then run `INSTALL_Requirements.bat` from the same window.
* **Tool does not open**: run `RUN_ValuationTool_Debug.bat` and look at `error_log.txt` in the tool folder.
* **"DLL load failed" for PyQt5**: install the *Microsoft Visual C++ Redistributable (x64)* from Microsoft and run the installer again.

## 2. Workflow (left-hand menu)
1. **Settings** (one time): enter the firm name, valuer name, **IBBI registration number** and RVO, and check the default market parameters.
2. **Dashboard**: create an assignment. This creates 10 folders and builds the document checklist from the purpose and security type.
3. **Engagement details**: enter the CIN, dates, basis/premise of value, number of shares, and **Amounts in** (INR / thousands / lakhs / crores).
   Per-share values are always converted to INR.
4. **Document checklist**: tick each item as it arrives. Use **Attach file(s)** to copy the file into the correct folder automatically.
   This page also has a **Pending documents letter** button.
5. **Market data & cost of capital**:
   * Risk-free rate options:
     * **Auto-fetch**: from the internet.
     * **Upload FBIL / CCIL / RBI yield file**: recommended for signed reports.
     * **Manual + proof**.

     Each option saves the source file plus an evidence PDF (URL, time, SHA-256 hash) in `05_Market_Data_Proofs`.
   * **Market return**: calculated from a Nifty 50 TRI / Sensex history file, or entered as a direct ERP.
   * The page then calculates beta re-levering, Ke and WACC.
6. **Industry analysis**: the industry is auto-suggested from the nature of business and the text is auto-written. Staff edit it as needed.
   You can load Damodaran's beta file to use a current published beta.
7. **Valuation**: tabs for DCF (FCFF/FCFE with sensitivity), NAV, Rule 11UA, comparable multiples, SEBI VWAP and debt instruments.
   On the **Conclusion** tab, set the weights and DLOC/DLOM.
8. **Report**: choose either
   * the **built-in IBBI Rule 8 report**, which includes a compliance matrix; or
   * **your own Word template** with `{{PLACEHOLDERS}}`. The placeholder list is shown on the page, and a sample template can be saved from there.
9. **Audit log & folders**: shows the full audit trail and lets you open any file.

Client folders are stored in `Clients\` inside the tool folder. To use a shared or backed-up drive instead, set the environment variable `VAL_CLIENTS_DIR`,
for example `D:\Valuations\Clients`.

## 3. Customising
* Industry library: `data\industries.json`.
* Extra checklist items for every job: create `data\custom_checklist.json` in this form:
  `[["C01","Description","04_Legal_and_Secretarial",true]]`.
* Defaults for Rf fallback, Rm, ERP, tax rate and growth: Settings page.

## 4. Professional responsibility
The tool supports the valuer's work but does not replace the valuer's judgement. Before signing and generating the UDIN, the Registered Valuer must:
* review all assumptions, the indicative betas and the standard wording; and
* verify the current text of Rule 8, the ICAI Valuation Standards, Rule 11UA, the FEMA pricing guidelines and SEBI ICDR.

## 5. Developers
* `core\`: calculation, storage and report engine. It has no UI code.
* `gui\`: PyQt5 pages.
* `gui_app.py`: main window.
* Tests: `python tests\test_core.py`.
