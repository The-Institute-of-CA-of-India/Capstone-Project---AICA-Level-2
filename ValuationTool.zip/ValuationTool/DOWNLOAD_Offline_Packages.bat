@echo off
rem Run on a PC WITH internet (same Windows 64-bit and same Python version as the
rem office PC). Creates a "wheels" folder; copy the whole tool folder including
rem "wheels" to the office PC and run INSTALL_Requirements.bat there - it will
rem install offline.
cd /d "%~dp0"
set "PY=py -3"
py -3 --version >nul 2>&1 || set "PY=python"
%PY% -m pip download -r requirements.txt -d wheels
if errorlevel 1 ( echo Download failed. & pause & exit /b 1 )
echo.
echo Done. Packages saved in the "wheels" folder.
pause
