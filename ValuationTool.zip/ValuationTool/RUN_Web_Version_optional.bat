@echo off
rem OPTIONAL browser version (Streamlit). The desktop version does not need this.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call "%~dp0INSTALL_Requirements.bat" /silent
".venv\Scripts\python.exe" -m pip install -r requirements_web.txt -q
".venv\Scripts\python.exe" -m streamlit run web_app.py
pause
