@echo off
setlocal
cd /d "%~dp0"
title Valuation Tool
rem First run (or libraries missing) -> install automatically
if not exist ".venv\Scripts\python.exe" (
    call "%~dp0INSTALL_Requirements.bat" /silent || exit /b 1
)
".venv\Scripts\python.exe" check_setup.py --quiet >nul 2>&1
if errorlevel 1 (
    echo Some libraries are missing - installing them now ...
    call "%~dp0INSTALL_Requirements.bat" /silent || exit /b 1
)
rem pythonw = no black console window behind the application
start "" ".venv\Scripts\pythonw.exe" "%~dp0gui_app.py"
exit /b 0
