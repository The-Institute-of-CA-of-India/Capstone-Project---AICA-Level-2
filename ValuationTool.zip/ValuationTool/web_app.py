"""Valuation Assignment Tool - Streamlit front end.

Run:  streamlit run app.py
"""
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from core import checklist as ck
from core import industry as ind
from core import market_data as mkt
from core import report as rpt
from core import storage as sto
from core import valuation as val
from core.config import FOLDERS, TEMPLATE_DIR, load_settings, save_settings

st.set_page_config(page_title="Valuation Assignment Tool", page_icon="📊", layout="wide")
S = load_settings()

# ----------------------------------------------------------------------------- helpers
def current():
    aid = st.session_state.get("aid")
    if not aid:
        return None
    try:
        return sto.load_assignment(aid)
    except FileNotFoundError:
        st.session_state.pop("aid", None)
        return None


def save(a, msg=None):
    sto.save_assignment(a)
    if msg:
        sto.log(a["assignment_id"], "UPDATE", msg, st.session_state.get("user", ""))


def need_assignment():
    a = current()
    if not a:
        st.info("Select or create an assignment on the **Dashboard** first.")
        st.stop()
    return a


# ----------------------------------------------------------------------------- sidebar
st.sidebar.title("📊 Valuation Tool")
st.session_state["user"] = st.sidebar.text_input("Your name (for audit trail)", st.session_state.get("user", ""))
PAGES = ["Dashboard", "1. Engagement details", "2. Document checklist", "3. Market data & cost of capital",
         "4. Industry analysis", "5. Valuation", "6. Report", "Audit log", "Settings"]
page = st.sidebar.radio("Go to", PAGES)
a_side = current()
if a_side:
    st.sidebar.success(f"Assignment: **{a_side['client_name']}**\n\n`{a_side['assignment_id']}`")

# ============================================================================= DASHBOARD
if page == "Dashboard":
    st.title("Dashboard")
    with st.expander("➕ Create new assignment", expanded=not sto.list_assignments()):
        with st.form("new"):
            c1, c2 = st.columns(2)
            client = c1.text_input("Client / Company name *")
            purpose = c2.selectbox("Purpose of valuation *", list(ck.PURPOSES), format_func=lambda k: ck.PURPOSES[k])
            sec = c1.selectbox("Security / asset being valued *", ck.SECURITY_TYPES)
            vdate = c2.date_input("Valuation date *", value=date.today())
            nob = st.text_area("Nature of business (used for automatic industry analysis) *",
                               placeholder="e.g. Manufacturer of auto components for two-wheeler OEMs")
            if st.form_submit_button("Create assignment & folders", type="primary"):
                if not client or not nob:
                    st.error("Client name and nature of business are required.")
                else:
                    a = sto.create_assignment(client, {"purpose": purpose, "security_type": sec,
                                                       "valuation_date": str(vdate), "nature_of_business": nob,
                                                       "currency_unit": "INR"})
                    a["checklist"] = ck.build_checklist(purpose, sec)
                    sug = ind.match_industry(nob)
                    a["details"]["industry"] = sug[0] if sug else ""
                    save(a)
                    st.session_state["aid"] = a["assignment_id"]
                    st.success(f"Created {a['assignment_id']} with folders: {', '.join(FOLDERS)}")
                    st.rerun()

    rows = []
    for a in sto.list_assignments():
        cs = ck.checklist_status(a.get("checklist", []))
        rows.append({"Assignment ID": a["assignment_id"], "Client": a["client_name"],
                     "Purpose": a["details"].get("purpose"), "Valuation date": a["details"].get("valuation_date"),
                     "Mandatory docs": f"{cs['mandatory_received']}/{cs['mandatory']}",
                     "RFR proof": "✅" if a.get("market_data", {}).get("rfr", {}).get("evidence_pdf") else "❌",
                     "Value/share": round(a.get("valuation", {}).get("conclusion", {}).get("final_value_per_share", 0) or 0, 2),
                     "Status": a.get("status")})
    if rows:
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True, hide_index=True)
        pick = st.selectbox("Open assignment", df["Assignment ID"])
        c1, c2 = st.columns(2)
        if c1.button("Open", type="primary"):
            st.session_state["aid"] = pick
            st.rerun()
        if c2.button("Create ZIP archive of assignment folder"):
            z = sto.zip_assignment(pick)
            st.download_button("Download ZIP", z.read_bytes(), file_name=z.name)
    else:
        st.info("No assignments yet.")

# ============================================================================= ENGAGEMENT
elif page == "1. Engagement details":
    a = need_assignment()
    d = a["details"]
    st.title("Engagement details")
    with st.form("eng"):
        c1, c2, c3 = st.columns(3)
        d["cin"] = c1.text_input("CIN", d.get("cin", ""))
        d["pan"] = c2.text_input("PAN", d.get("pan", ""))
        d["currency_unit"] = c3.selectbox("Amounts in", ["INR", "INR lakhs", "INR crores", "INR thousands"],
                                          index=["INR", "INR lakhs", "INR crores", "INR thousands"].index(d.get("currency_unit", "INR")))
        d["registered_office"] = st.text_input("Registered office", d.get("registered_office", ""))
        d["nature_of_business"] = st.text_area("Nature of business", d.get("nature_of_business", ""))
        d["background"] = st.text_area("Background / history of the company (Rule 8(a))", d.get("background", ""))
        c1, c2 = st.columns(2)
        pk = list(ck.PURPOSES)
        d["purpose"] = c1.selectbox("Purpose", pk, index=pk.index(d.get("purpose", pk[0])), format_func=lambda k: ck.PURPOSES[k])
        d["security_type"] = c2.selectbox("Security", ck.SECURITY_TYPES, index=ck.SECURITY_TYPES.index(d.get("security_type", ck.SECURITY_TYPES[0])))
        d["appointing_authority"] = c1.text_input("Appointing authority (e.g. Board of Directors)", d.get("appointing_authority", "Board of Directors"))
        bases = ["Fair Value", "Fair Market Value", "Participant-specific value", "Liquidation Value", "Fair Value and Liquidation Value"]
        d["basis_of_value"] = c2.selectbox("Basis of value (ICAI VS 102)", bases, index=bases.index(d.get("basis_of_value", "Fair Value")))
        prem = ["Going Concern", "Orderly Liquidation", "Forced Liquidation", "As-is-where-is"]
        d["premise_of_value"] = c1.selectbox("Premise of value", prem, index=prem.index(d.get("premise_of_value", "Going Concern")))
        d["shares_outstanding"] = c2.number_input("Number of shares / units outstanding", value=float(d.get("shares_outstanding", 100000)), step=1.0)
        d["face_value"] = c1.number_input("Face value per share", value=float(d.get("face_value", 10)))
        c1, c2, c3 = st.columns(3)
        d["appointment_date"] = str(c1.date_input("Date of appointment", value=pd.to_datetime(d.get("appointment_date", str(date.today()))).date()))
        d["valuation_date"] = str(c2.date_input("Valuation date", value=pd.to_datetime(d.get("valuation_date", str(date.today()))).date()))
        d["report_date"] = str(c3.date_input("Report date", value=pd.to_datetime(d.get("report_date", str(date.today()))).date()))
        d["other_experts"] = st.text_input("Other experts involved (Rule 8(c))", d.get("other_experts", ""))
        d["conflict_declaration"] = st.text_area("Disclosure of interest / conflict (blank = standard independence wording)", d.get("conflict_declaration", ""))
        d["inspections"] = st.text_area("Inspections / investigations undertaken (blank = standard wording)", d.get("inspections", ""))
        d["approach_rationale"] = st.text_area("Rationale for approaches adopted / rejected", d.get("approach_rationale", ""))
        d["restrictions"] = st.text_area("Restrictions on use (blank = standard wording)", d.get("restrictions", ""))
        regen = st.checkbox("Re-build document checklist for changed purpose / security (keeps ticked items)")
        if st.form_submit_button("Save", type="primary"):
            if regen:
                old = {c["id"]: c for c in a.get("checklist", [])}
                new = ck.build_checklist(d["purpose"], d["security_type"])
                a["checklist"] = [old.get(c["id"], c) for c in new]
            save(a, "Engagement details updated")
            st.success("Saved.")

# ============================================================================= CHECKLIST
elif page == "2. Document checklist":
    a = need_assignment()
    st.title("Document checklist")
    st.caption("Tick each item on receipt and upload the file - it is saved automatically to the correct folder.")
    cl = a["checklist"]
    stat = ck.checklist_status(cl)
    c1, c2, c3 = st.columns(3)
    c1.metric("Items received", f"{stat['received']}/{stat['total']}")
    c2.metric("Mandatory received", f"{stat['mandatory_received']}/{stat['mandatory']}")
    c3.metric("Ready for report", "Yes ✅" if stat["ready"] else "No ❌")
    st.progress(stat["mandatory_received"] / max(stat["mandatory"], 1))

    for folder in FOLDERS:
        items = [c for c in cl if c["folder"] == folder]
        if not items:
            continue
        with st.expander(f"📁 {folder}  ({sum(c['received'] for c in items)}/{len(items)})"):
            for c in items:
                cols = st.columns([0.6, 5, 1, 3])
                rec = cols[0].checkbox("✔", value=c["received"], key=f"r_{c['id']}", label_visibility="collapsed")
                cols[1].markdown(f"**{c['id']}** {c['text']} {'🔴 *mandatory*' if c['mandatory'] else ''}"
                                 + (f"<br>📎 {', '.join(c['files'])}" if c["files"] else ""), unsafe_allow_html=True)
                na = cols[2].checkbox("N/A", value=c.get("na", False), key=f"na_{c['id']}")
                up = cols[3].file_uploader("Upload", key=f"u_{c['id']}", accept_multiple_files=True, label_visibility="collapsed")
                rem = st.text_input("Remarks", c.get("remarks", ""), key=f"rm_{c['id']}", label_visibility="collapsed",
                                    placeholder=f"Remarks for {c['id']}")
                changed = (rec != c["received"]) or (na != c.get("na", False)) or (rem != c.get("remarks", ""))
                if up:
                    for f in up:
                        if f.name not in [Path(x).name.split("__", 1)[-1] for x in c["files"]]:
                            p = sto.save_upload(a["assignment_id"], c["folder"], f.name, f.getvalue(), prefix=c["id"])
                            c["files"].append(p.name)
                            rec, changed = True, True
                if changed:
                    c["received"], c["na"], c["remarks"] = rec, na, rem
                    save(a, f"Checklist {c['id']} received={rec} na={na}")

    st.subheader("Add an extra item")
    with st.form("extra"):
        t = st.text_input("Description")
        f = st.selectbox("Folder", FOLDERS)
        m = st.checkbox("Mandatory")
        if st.form_submit_button("Add") and t:
            cl.append({"id": f"X{len(cl)+1:02d}", "text": t, "folder": f, "mandatory": m,
                       "received": False, "files": [], "remarks": "", "na": False})
            save(a, f"Extra checklist item: {t}")
            st.rerun()

    pend = stat["pending_mandatory"]
    if pend:
        st.subheader("Pending mandatory documents - request letter to client")
        letter = (f"Dear Sir/Madam,\n\nRe: Valuation of {a['details'].get('security_type')} of {a['client_name']} "
                  f"as at {a['details'].get('valuation_date')}\n\nTo proceed with the valuation, kindly provide the following:\n\n"
                  + "\n".join(f"{i+1}. {c['text']}" for i, c in enumerate(pend))
                  + f"\n\nRegards,\n{S['valuer_name']}\n{S['firm_name']}")
        st.text_area("Copy / download", letter, height=250)
        st.download_button("Download request letter (.txt)", letter, file_name="Pending_documents_request.txt")
    st.download_button("Export checklist to CSV", pd.DataFrame(cl).to_csv(index=False), file_name="checklist.csv")

# ============================================================================= MARKET DATA
elif page == "3. Market data & cost of capital":
    a = need_assignment()
    md = a.setdefault("market_data", {})
    st.title("Market data & cost of capital")

    st.header("A. Risk-free rate (10-year G-Sec)")
    if md.get("rfr"):
        r = md["rfr"]
        st.success(f"**Rf = {r['rate']:.2f}%** | Source: {r['source']} | As on: {r.get('as_on')} | Method: {r.get('method')}"
                   + (f" | Evidence: `{r.get('evidence_pdf')}`" if r.get("evidence_pdf") else " | ⚠ No evidence file"))
        ev = sto.assignment_dir(a["assignment_id"]) / "05_Market_Data_Proofs" / (r.get("evidence_pdf") or "_none_")
        if ev.exists():
            st.download_button("Download evidence PDF", ev.read_bytes(), file_name=ev.name)
    t1, t2, t3, t4 = st.tabs(["🌐 Auto-fetch (internet)", "📄 Upload FBIL / CCIL / RBI file", "✍ Manual + proof", "⚙ Fallback setting"])
    with t1:
        st.write("Fetches the current 10-year benchmark yield from the configured websites and saves the web page "
                 "plus an evidence PDF (URL, time, SHA-256) to *05_Market_Data_Proofs*.")
        st.caption("For a valuation date in the past, use the FBIL file upload tab (FBIL archives are date-wise).")
        if st.button("Fetch risk-free rate now", type="primary"):
            try:
                md["rfr"] = mkt.fetch_risk_free_rate(a["assignment_id"])
                save(a, f"RFR auto-fetched {md['rfr']['rate']}")
                st.rerun()
            except Exception as e:
                st.error(str(e))
    with t2:
        st.markdown("Download the **FBIL G-Sec Par Yield / Prices file** for the valuation date from "
                    "fbil.org.in (G-Sec valuation archives) - or CCIL / NSE ZCYC / RBI DBIE - and upload it here. "
                    "The tool reads the yield at the tenor you choose and stores the file as proof.")
        f = st.file_uploader("Yield file (.xlsx / .xls / .csv)", type=["xlsx", "xls", "csv"])
        c1, c2, c3 = st.columns(3)
        src = c1.text_input("Source name", "FBIL G-Sec Par Yield")
        ason = c2.date_input("Data as on", value=pd.to_datetime(a["details"]["valuation_date"]).date())
        ten = c3.number_input("Tenor (years)", value=10.0)
        if f and st.button("Read file"):
            try:
                md["rfr"] = mkt.record_rfr_from_file(a["assignment_id"], f.getvalue(), f.name, src, str(ason), ten)
                save(a, f"RFR from file {md['rfr']['rate']}")
                st.rerun()
            except Exception as e:
                st.error(str(e))
    with t3:
        c1, c2, c3 = st.columns(3)
        rate = c1.number_input("Rate % p.a.", value=7.0, step=0.01, format="%.4f")
        src = c2.text_input("Source", "RBI Weekly Statistical Supplement / FBIL")
        ason = c3.date_input("As on", value=pd.to_datetime(a["details"]["valuation_date"]).date(), key="m_ason")
        pf = st.file_uploader("Proof (PDF / screenshot / Excel) - mandatory", key="m_proof")
        if st.button("Record manual rate"):
            if not pf:
                st.error("Proof file is mandatory for manual entry.")
            else:
                md["rfr"] = mkt.record_rfr_manual(a["assignment_id"], rate, src, str(ason), pf.getvalue(), pf.name)
                save(a, f"RFR manual {rate}")
                st.rerun()
    with t4:
        fb = mkt.fallback_rfr()
        st.warning(f"Fallback from Settings: {fb['rate']}% as on {fb['as_on']} ({fb['source']}). "
                   "Use only for drafts - no evidence file is created.")
        if st.button("Use fallback (draft only)"):
            md["rfr"] = fb
            save(a, "RFR fallback used")
            st.rerun()

    st.header("B. Expected market return / Equity risk premium")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Option 1 - compute from index history** (e.g. Nifty 50 TRI CSV from niftyindices.com / BSE Sensex)")
        fi = st.file_uploader("Index history file (Date + Close/TRI)", type=["csv", "xlsx", "xls"], key="idx")
        iname = st.text_input("Index name", "Nifty 50 TRI")
        yrs = st.number_input("Look-back years", 5, 30, 15)
        if fi and st.button("Compute CAGR"):
            try:
                res = mkt.market_return_from_index(a["assignment_id"], fi.getvalue(), fi.name, iname, int(yrs),
                                                   a["details"]["valuation_date"])
                md["market_return"] = res["market_return"]
                md["market_return_source"] = f"CAGR of {iname} {res['start']} to {res['end']} ({res['years']} yrs); evidence {res['evidence_pdf']}"
                save(a, f"Market return {res['market_return']}")
                st.rerun()
            except Exception as e:
                st.error(str(e))
    with c2:
        st.markdown("**Option 2 - firm policy / manual**")
        md["market_return"] = st.number_input("Expected market return Rm %", value=float(md.get("market_return", S["market_return_default"])), step=0.1)
        md["market_return_source"] = st.text_input("Rm source", md.get("market_return_source", S["market_return_source"]))
    rf = md.get("rfr", {}).get("rate", 0.0)
    erp_mode = st.radio("ERP basis", ["Rm - Rf (from above)", "Direct ERP (e.g. Damodaran India ERP)"], horizontal=True)
    if erp_mode.startswith("Rm"):
        md["erp"] = round(md["market_return"] - rf, 4)
        md["erp_source"] = f"Rm {md['market_return']:.2f}% less Rf {rf:.2f}%"
        st.info(f"ERP = {md['erp']:.2f}%")
    else:
        md["erp"] = st.number_input("ERP %", value=float(S["equity_risk_premium"]), step=0.1)
        md["erp_source"] = st.text_input("ERP source", S["equity_risk_premium_source"])

    st.header("C. Beta, cost of equity and WACC")
    ia = a.get("industry", {})
    c1, c2, c3, c4 = st.columns(4)
    md["beta_unlevered"] = c1.number_input("Unlevered beta", value=float(md.get("beta_unlevered", ia.get("beta_unlevered", 1.0))), step=0.01)
    md["beta_source"] = md.get("beta_source") or ia.get("beta_source", "Industry library")
    md["de_ratio"] = c2.number_input("Target D/E", value=float(md.get("de_ratio", 0.25)), step=0.05)
    md["tax_rate"] = c3.number_input("Tax rate %", value=float(md.get("tax_rate", S["default_tax_rate"])), step=0.01)
    md["beta_levered"] = round(mkt.relever_beta(md["beta_unlevered"], md["de_ratio"], md["tax_rate"]), 4)
    c4.metric("Re-levered beta", f"{md['beta_levered']:.2f}")
    md["beta_source"] = st.text_input("Beta source", md["beta_source"])
    c1, c2 = st.columns(2)
    md["size_premium"] = c1.number_input("Size premium %", value=float(md.get("size_premium", 0.0)), step=0.25)
    md["csrp"] = c2.number_input("Company-specific risk premium %", value=float(md.get("csrp", 0.0)), step=0.25)
    md["csrp_reason"] = st.text_input("Reason for CSRP (projection risk, concentration, key-person ...)", md.get("csrp_reason", ""))
    ke = mkt.cost_of_equity(rf, md["beta_levered"], md["erp"], md["size_premium"], md["csrp"])
    md["ke"] = ke["ke"]
    c1, c2, c3 = st.columns(3)
    md["kd"] = c1.number_input("Pre-tax cost of debt %", value=float(md.get("kd", 9.5)), step=0.1)
    md["kd_source"] = c2.text_input("Kd source", md.get("kd_source", "Weighted average borrowing rate / MCLR + spread"))
    md["debt_weight"] = c3.number_input("Debt / (D+E) %", value=float(md.get("debt_weight", round(md["de_ratio"] / (1 + md["de_ratio"]) * 100, 2))))
    w = mkt.wacc(md["ke"], md["kd"], md["tax_rate"], md["debt_weight"])
    md["wacc"] = w["wacc"]
    c1, c2 = st.columns(2)
    c1.metric("Cost of equity (Ke)", f"{md['ke']:.2f}%", help=ke["formula"])
    c2.metric("WACC", f"{md['wacc']:.2f}%")
    if st.button("Save cost of capital", type="primary"):
        save(a, f"Cost of capital Ke={md['ke']} WACC={md['wacc']}")
        st.success("Saved.")

# ============================================================================= INDUSTRY
elif page == "4. Industry analysis":
    a = need_assignment()
    st.title("Industry analysis")
    lib = ind.load_library()
    nob = a["details"].get("nature_of_business", "")
    sug = ind.match_industry(nob)
    st.write(f"**Nature of business:** {nob}")
    st.write("Suggested industries: " + (", ".join(sug[:3]) if sug else "no keyword match - pick manually"))
    names = list(lib)
    default = a["details"].get("industry") or (sug[0] if sug else names[0])
    chosen = st.selectbox("Industry", names, index=names.index(default) if default in names else 0)
    st.markdown("**Optional:** upload Damodaran industry beta file (e.g. *betaemerg.xls*) to use current published beta.")
    bf = st.file_uploader("Damodaran beta file", type=["xls", "xlsx", "csv"])
    beta_override, beta_src = None, ""
    if bf:
        try:
            bdf = ind.load_damodaran_betas(bf.getvalue(), bf.name)
            row = st.selectbox("Pick matching Damodaran industry", bdf["Industry"].tolist())
            beta_override = float(bdf.loc[bdf["Industry"] == row, "Unlevered beta"].iloc[0])
            beta_src = f"Damodaran dataset '{bf.name}' - {row}"
            st.info(f"Unlevered beta: {beta_override:.2f}")
        except Exception as e:
            st.error(str(e))
    if st.button("Generate industry analysis", type="primary"):
        if bf and beta_override:
            sto.save_upload(a["assignment_id"], "05_Market_Data_Proofs", bf.name, bf.getvalue(), prefix="Beta")
        a["details"]["industry"] = chosen
        a["industry"] = ind.build_analysis(chosen, nob, a["client_name"], beta_override, beta_src)
        a.setdefault("market_data", {})["beta_unlevered"] = a["industry"]["beta_unlevered"]
        a["market_data"]["beta_source"] = a["industry"]["beta_source"]
        save(a, f"Industry analysis generated: {chosen}")
        st.rerun()
    if a.get("industry"):
        st.subheader("Review & edit (edits flow into the report)")
        secs = a["industry"]["sections"]
        with st.form("ind_edit"):
            for k, v in secs.items():
                if isinstance(v, list):
                    secs[k] = [x for x in st.text_area(k, "\n".join(v), height=130).split("\n") if x.strip()]
                else:
                    secs[k] = st.text_area(k, v, height=130)
            if st.form_submit_button("Save edits"):
                save(a, "Industry analysis edited")
                st.success("Saved.")
        if st.button("Save as Word document to 06_Industry_Analysis"):
            n = ind.save_analysis_docx(a["assignment_id"], a["industry"])
            st.success(f"Saved {n}")

# ============================================================================= VALUATION
elif page == "5. Valuation":
    a = need_assignment()
    v = a.setdefault("valuation", {})
    md = a.get("market_data", {})
    d = a["details"]
    shares = float(d.get("shares_outstanding", 1) or 1)
    st.title("Valuation")
    st.caption(f"Amounts in {d.get('currency_unit', 'INR')} | Shares: {shares:,.0f}")
    tabs = st.tabs(["DCF", "Net Asset Value", "Rule 11UA NAV", "Comparable multiples", "Listed price (VWAP)", "Debt instrument", "✅ Conclusion"])

    with tabs[0]:
        mode = st.radio("Method", ["FCFF", "FCFE"], horizontal=True)
        default_rate = md.get("wacc" if mode == "FCFF" else "ke", 12.0)
        c1, c2, c3, c4 = st.columns(4)
        rate = c1.number_input("Discount rate %", value=float(default_rate), step=0.1, key="dr")
        g = c2.number_input("Terminal growth %", value=float(S["default_terminal_growth"]), step=0.25)
        mid = c3.checkbox("Mid-year convention", True)
        stub = c4.number_input("First-year fraction (stub)", 0.01, 1.0, 1.0, 0.01)
        c1, c2 = st.columns(2)
        nd = c1.number_input("Net debt (debt - cash)", value=0.0) if mode == "FCFF" else 0.0
        noa = c2.number_input("Non-operating / surplus assets", value=0.0)
        base = v.get("dcf_inputs") or [{"label": f"FY{27 + i}", "ebitda": 100.0 * 1.1 ** i, "dep": 10.0, "interest": 5.0,
                                        "tax_rate": float(S["default_tax_rate"]), "capex": 15.0, "delta_nwc": 5.0,
                                        "net_borrowing": 0.0} for i in range(5)]
        st.markdown("**Projections** (edit cells; add rows for more years)")
        edf = st.data_editor(pd.DataFrame(base), num_rows="dynamic", use_container_width=True, key="dcf_ed")
        if st.button("Compute DCF", type="primary"):
            try:
                yrs = edf.fillna(0).to_dict("records")
                r = val.dcf(yrs, rate, g, mode=mode, mid_year=mid, net_debt=nd, non_operating_assets=noa,
                            shares=shares, first_period_fraction=stub, unit_mult=val.unit_mult(d.get("currency_unit")))
                v["dcf"], v["dcf_inputs"] = r, yrs
                v["dcf_sensitivity"] = val.dcf_sensitivity(yrs, rate, g, mode=mode, mid_year=mid, net_debt=nd,
                                                           non_operating_assets=noa, shares=shares, first_period_fraction=stub,
                                                           unit_mult=val.unit_mult(d.get("currency_unit")))
                save(a, f"DCF {mode} value/share {r['value_per_share']:.2f}")
            except Exception as e:
                st.error(str(e))
        if "dcf" in v:
            r = v["dcf"]
            st.dataframe(pd.DataFrame(r["rows"]), use_container_width=True, hide_index=True)
            c1, c2, c3 = st.columns(3)
            c1.metric("Equity value", f"{r['equity_value']:,.2f}")
            c2.metric("Value per share", f"{r['value_per_share']:,.2f}")
            c3.metric("TV % of value", f"{r['tv_share_pct']:.1f}%")
            if r["tv_share_pct"] > 75:
                st.warning("Terminal value exceeds 75% of total - review explicit period / growth assumptions.")
            st.markdown("**Sensitivity (value per share)**")
            st.dataframe(pd.DataFrame(v["dcf_sensitivity"]).T, use_container_width=True)

    with tabs[1]:
        st.markdown("Enter book values and, where applicable, fair values (adjusted NAV).")
        av = pd.DataFrame(v.get("nav", {}).get("assets") or [{"item": "Property, plant & equipment", "book": 0.0, "fair": 0.0},
                                                             {"item": "Investments", "book": 0.0, "fair": 0.0},
                                                             {"item": "Current assets", "book": 0.0, "fair": 0.0}])
        lv = pd.DataFrame(v.get("nav", {}).get("liabilities") or [{"item": "Borrowings", "book": 0.0, "fair": 0.0},
                                                                  {"item": "Current liabilities & provisions", "book": 0.0, "fair": 0.0}])
        ea = st.data_editor(av, num_rows="dynamic", key="nav_a", use_container_width=True)
        el = st.data_editor(lv, num_rows="dynamic", key="nav_l", use_container_width=True)
        if st.button("Compute NAV"):
            v["nav"] = val.nav(ea.fillna(0).to_dict("records"), el.fillna(0).to_dict("records"), shares, val.unit_mult(d.get("currency_unit")))
            save(a, f"NAV {v['nav']['value_per_share']:.2f}")
        if "nav" in v:
            st.metric("Adjusted NAV per share", f"{v['nav']['value_per_share']:,.2f}")

    with tabs[2]:
        st.caption("Rule 11UA(1)(c)(a): FMV = (A - L) x PV / PE. See help text in core/valuation.py for components.")
        c1, c2, c3, c4 = st.columns(4)
        A = c1.number_input("A - adjusted assets", value=0.0)
        L = c2.number_input("L - specified liabilities", value=0.0)
        PE = c3.number_input("PE - paid-up equity capital", value=float(shares * float(d.get("face_value", 10))))
        PV = c4.number_input("PV - paid-up value per share", value=float(d.get("face_value", 10)))
        if st.button("Compute Rule 11UA"):
            v["rule11ua"] = val.rule_11ua_nav(A, L, PE, PV)
            save(a, "Rule 11UA computed")
        if "rule11ua" in v:
            st.metric("FMV per share", f"{v['rule11ua']['value_per_share']:,.2f}")

    with tabs[3]:
        c1, c2, c3 = st.columns(3)
        mt = c1.selectbox("Multiple", ["EV/EBITDA", "EV/Revenue", "P/E", "P/BV"])
        stat = c2.selectbox("Statistic", ["median", "mean"])
        disc = c3.number_input("Discount to peers %", value=0.0)
        c1, c2 = st.columns(2)
        metric = c1.number_input(f"Subject company metric ({mt.split('/')[1]})", value=0.0)
        nd2 = c2.number_input("Net debt (for EV multiples)", value=0.0, key="nd2")
        peers = st.data_editor(pd.DataFrame(v.get("market", {}).get("peers") or [{"name": "Peer 1", "multiple": 0.0}]),
                               num_rows="dynamic", key="peers", use_container_width=True)
        pproof = st.file_uploader("Peer data proof (screener / Capitaline / ProwessIQ export)", key="pp")
        if st.button("Compute market approach"):
            try:
                v["market"] = val.market_multiple(peers.dropna().to_dict("records"), metric, mt, nd2, shares, stat, disc, val.unit_mult(d.get("currency_unit")))
                if pproof:
                    sto.save_upload(a["assignment_id"], "05_Market_Data_Proofs", pproof.name, pproof.getvalue(), prefix="Peers")
                save(a, "Market approach computed")
            except Exception as e:
                st.error(str(e))
        if "market" in v:
            st.metric("Value per share", f"{v['market']['value_per_share']:,.2f}")

    with tabs[4]:
        st.caption("Upload NSE/BSE price-volume history (Date, Volume/No. of shares, Turnover or Close).")
        pf = st.file_uploader("Price file", type=["csv", "xlsx", "xls"], key="vw")
        rd = st.date_input("Relevant date", value=pd.to_datetime(d["valuation_date"]).date())
        if pf and st.button("Compute VWAP"):
            try:
                v["vwap"] = mkt.vwap_pricing(pf.getvalue(), pf.name, str(rd))
                sto.save_upload(a["assignment_id"], "05_Market_Data_Proofs", pf.name, pf.getvalue(), prefix="PriceData")
                save(a, "VWAP computed")
            except Exception as e:
                st.error(str(e))
        if "vwap" in v:
            st.json(v["vwap"])

    with tabs[5]:
        c1, c2, c3 = st.columns(3)
        fv = c1.number_input("Face value", value=100.0)
        cp = c2.number_input("Coupon %", value=8.0)
        ytm = c3.number_input("Years to maturity", value=3.0)
        c1, c2, c3 = st.columns(3)
        fq = c1.selectbox("Payments per year", [1, 2, 4, 12])
        spread = c2.number_input("Credit spread over Rf %", value=2.0)
        prem = c3.number_input("Redemption premium %", value=0.0)
        y = md.get("rfr", {}).get("rate", 7.0) + spread
        st.write(f"Discount yield = Rf {md.get('rfr', {}).get('rate', 7.0):.2f}% + spread {spread:.2f}% = **{y:.2f}%**")
        if st.button("Value instrument"):
            v["debt"] = val.debt_instrument(fv, cp, ytm, fq, y, prem)
            save(a, "Debt instrument valued")
        if "debt" in v:
            st.metric("Value per unit", f"{v['debt']['value_per_unit']:,.2f}")

    with tabs[6]:
        avail = {}
        if "dcf" in v: avail[f"DCF ({v['dcf']['mode']})"] = v["dcf"]["value_per_share"]
        if "nav" in v: avail["Net Asset Value"] = v["nav"]["value_per_share"]
        if "rule11ua" in v: avail["Rule 11UA NAV"] = v["rule11ua"]["value_per_share"]
        if "market" in v: avail[f"Comparable companies ({v['market']['multiple_type']})"] = v["market"]["value_per_share"]
        if "vwap" in v: avail["Market price (VWAP)"] = v["vwap"]["floor_price"]
        if "debt" in v: avail["PV of contractual cash flows"] = v["debt"]["value_per_unit"]
        if not avail:
            st.info("Compute at least one method first.")
        else:
            prev = v.get("conclusion", {}).get("weights", {})
            weights = {}
            for m, x in avail.items():
                c1, c2 = st.columns([3, 1])
                c1.write(f"**{m}**: {x:,.2f}")
                weights[m] = c2.number_input("Weight %", 0.0, 100.0, float(prev.get(m, 100.0 / len(avail))), key=f"w_{m}")
            c1, c2 = st.columns(2)
            dloc = c1.number_input("DLOC %", value=float(v.get("conclusion", {}).get("dloc_pct", 0.0)))
            dlom = c2.number_input("DLOM %", value=float(v.get("conclusion", {}).get("dlom_pct", 0.0)))
            if st.button("Conclude value", type="primary"):
                try:
                    v["conclusion"] = val.conclude(avail, weights, dlom, dloc)
                    save(a, f"Concluded {v['conclusion']['final_value_per_share']:.2f}")
                except Exception as e:
                    st.error(str(e))
            if "conclusion" in v:
                st.success(f"Fair value per share: **{v['conclusion']['final_value_per_share']:,.2f}**")

# ============================================================================= REPORT
elif page == "6. Report":
    a = need_assignment()
    st.title("Report generation")
    stat = ck.checklist_status(a["checklist"])
    issues = []
    if not stat["ready"]:
        issues.append(f"{len(stat['pending_mandatory'])} mandatory document(s) pending")
    if not a.get("market_data", {}).get("rfr", {}).get("evidence_pdf"):
        issues.append("Risk-free rate has no evidence file")
    if not a.get("industry"):
        issues.append("Industry analysis not generated")
    if not a.get("valuation", {}).get("conclusion"):
        issues.append("Valuation conclusion not computed")
    if S["ibbi_registration_no"].startswith("IBBI/RV/xx"):
        issues.append("Valuer IBBI registration number not set (Settings)")
    for i in issues:
        st.warning(i)
    draft = st.checkbox("Generate as DRAFT despite open issues", value=bool(issues))
    can = not issues or draft

    st.header("Option 1 - Built-in IBBI Rule 8 format")
    if st.button("Generate built-in report", type="primary", disabled=not can):
        p = rpt.generate_builtin(a)
        st.download_button("Download report (.docx)", Path(p).read_bytes(), file_name=Path(p).name)

    st.header("Option 2 - Your own format (upload .docx template)")
    hp = rpt.placeholder_help()
    with st.expander("Placeholders you can use in your template"):
        st.markdown("**Text placeholders** (anywhere, incl. tables, headers, footers):")
        st.code("  ".join("{{" + x + "}}" for x in hp["simple"]))
        st.markdown("**Block placeholders** (put alone on their own line - inserts tables / sections):")
        st.code("\n".join("{{" + x + "}}" for x in hp["blocks"]))
    sample = TEMPLATE_DIR / "Sample_Custom_Template.docx"
    if sample.exists():
        st.download_button("Download sample template", sample.read_bytes(), file_name=sample.name)
    tf = st.file_uploader("Upload your report template (.docx)", type=["docx"])
    if tf and st.button("Generate from my template", disabled=not can):
        tp = sto.save_upload(a["assignment_id"], "09_Final_Report", tf.name, tf.getvalue(), prefix="Template")
        p, unknown = rpt.fill_template(str(tp), a)
        if unknown:
            st.warning("Unknown placeholders left unchanged: " + ", ".join(unknown))
        st.download_button("Download report (.docx)", Path(p).read_bytes(), file_name=Path(p).name)

    st.caption("Reports are saved in 09_Final_Report. Review, sign, and generate UDIN before issue.")

# ============================================================================= AUDIT
elif page == "Audit log":
    a = need_assignment()
    st.title("Audit trail")
    st.dataframe(pd.DataFrame(sto.read_log(a["assignment_id"])), use_container_width=True, hide_index=True)
    root = sto.assignment_dir(a["assignment_id"])
    st.subheader("Folder contents")
    for f in FOLDERS:
        files = [p.name for p in (root / f).glob("*")]
        st.write(f"📁 **{f}** - {len(files)} file(s)")
        for x in files:
            st.write(f"   • {x}")
    if a.get("status") != "Closed" and st.button("Mark assignment as Closed"):
        a["status"] = "Closed"
        save(a, "Assignment closed")
        st.rerun()

# ============================================================================= SETTINGS
elif page == "Settings":
    st.title("Settings")
    with st.form("settings"):
        st.subheader("Valuer / firm")
        for k in ["firm_name", "valuer_name", "ibbi_registration_no", "rvo_name", "membership_no", "valuer_address", "valuer_email"]:
            S[k] = st.text_input(k.replace("_", " ").title(), S.get(k, ""))
        st.subheader("Default market parameters (verify periodically)")
        c1, c2, c3 = st.columns(3)
        S["fallback_risk_free_rate"] = c1.number_input("Fallback Rf %", value=float(S["fallback_risk_free_rate"]))
        S["fallback_risk_free_rate_date"] = c2.text_input("Fallback Rf date", S["fallback_risk_free_rate_date"])
        S["default_tax_rate"] = c3.number_input("Default tax rate %", value=float(S["default_tax_rate"]))
        S["fallback_risk_free_rate_source"] = st.text_input("Fallback Rf source", S["fallback_risk_free_rate_source"])
        c1, c2, c3 = st.columns(3)
        S["market_return_default"] = c1.number_input("Default Rm %", value=float(S["market_return_default"]))
        S["equity_risk_premium"] = c2.number_input("Default ERP %", value=float(S["equity_risk_premium"]))
        S["default_terminal_growth"] = c3.number_input("Default terminal growth %", value=float(S["default_terminal_growth"]))
        S["market_return_source"] = st.text_input("Rm source text", S["market_return_source"])
        S["equity_risk_premium_source"] = st.text_input("ERP source text", S["equity_risk_premium_source"])
        S["macro_overview"] = st.text_area("Macro-economic overview paragraph (used in every report)", S.get("macro_overview", ind.MACRO_DEFAULT), height=150)
        if st.form_submit_button("Save settings", type="primary"):
            save_settings(S)
            st.success("Saved.")
    st.subheader("Risk-free rate web sources (advanced)")
    st.caption("If a website changes its layout, edit the regex here. The first capture group must be the yield.")
    src_df = st.data_editor(pd.DataFrame(S["rfr_sources"]), num_rows="dynamic", use_container_width=True)
    if st.button("Save sources"):
        S["rfr_sources"] = src_df.dropna().to_dict("records")
        save_settings(S)
        st.success("Saved.")
