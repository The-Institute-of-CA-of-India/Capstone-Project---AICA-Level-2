@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Valuation Tool - Install required libraries
echo ==================================================================
echo   VALUATION ASSIGNMENT TOOL - one-time installation
echo ==================================================================
echo.

rem ---- 1. Locate Python (py launcher first, then python.exe) ----------
set "PY="
py -3 --version >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    python --version >nul 2>&1
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ERROR] Python is not installed or not on PATH.
    echo.
    echo  1. Install Python 3.11 or 3.12 ^(64-bit^) from https://www.python.org/downloads/windows/
    echo  2. On the first installer screen TICK "Add python.exe to PATH".
    echo  3. Run this file again.
    echo.
    start "" "https://www.python.org/downloads/windows/"
    pause
    exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)"
if errorlevel 1 (
    echo [ERROR] Python 3.9 or newer is required. Found:
    %PY% --version
    pause
    exit /b 1
)
echo Using:
%PY% --version
echo.

rem ---- 2. Create a private virtual environment (.venv) ------------------
if not exist ".venv\Scripts\python.exe" (
    echo Creating private Python environment in .venv ...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
)
set "VPY=.venv\Scripts\python.exe"

rem ---- 3. Install libraries ---------------------------------------------
echo Upgrading pip ...
"%VPY%" -m pip install --upgrade pip --disable-pip-version-check -q

if exist "wheels\*.whl" (
    echo Installing libraries from the local "wheels" folder ^(offline mode^) ...
    "%VPY%" -m pip install --no-index --find-links=wheels -r requirements.txt
) else (
    echo Installing libraries from the internet ^(PyQt5, pandas, openpyxl, xlrd, python-docx, reportlab^) ...
    "%VPY%" -m pip install -r requirements.txt --disable-pip-version-check
)
if errorlevel 1 (
    echo.
    echo [ERROR] Library installation failed.
    echo  - Check the internet connection / office proxy.
    echo  - Behind a proxy:  set HTTPS_PROXY=http://user:pass@proxy:port   then run this file again.
    echo  - Without internet: on another PC run DOWNLOAD_Offline_Packages.bat and copy the "wheels" folder here.
    pause
    exit /b 1
)

rem ---- 4. Verify --------------------------------------------------------
echo.
"%VPY%" check_setup.py
if errorlevel 1 (
    pause
    exit /b 1
)
echo.
echo ==================================================================
echo   Installation complete. Start the tool with RUN_ValuationTool.bat
echo ==================================================================
if /i not "%~1"=="/silent" pause
exit /b 0
