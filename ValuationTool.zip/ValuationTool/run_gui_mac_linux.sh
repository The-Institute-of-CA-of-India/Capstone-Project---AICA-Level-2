#!/usr/bin/env bash
# Mac / Linux launcher for the desktop (PyQt5) version
cd "$(dirname "$0")"
[ -x .venv/bin/python ] || python3 -m venv .venv
.venv/bin/python -m pip install -q --upgrade pip
.venv/bin/python -m pip install -q -r requirements.txt
.venv/bin/python check_setup.py --quiet || exit 1
.venv/bin/python gui_app.py
