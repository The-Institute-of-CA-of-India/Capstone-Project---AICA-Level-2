"""Checks that every library needed by the Valuation Tool is installed.
Usage: python check_setup.py  (exit code 0 = all OK)"""
import importlib
import sys

LIBS = [("PyQt5.QtWidgets", "PyQt5", "Desktop window (GUI)"),
        ("numpy", "numpy", "Calculations"),
        ("pandas", "pandas", "Reading CSV / Excel files"),
        ("openpyxl", "openpyxl", "Excel .xlsx files"),
        ("xlrd", "xlrd", "Old Excel .xls files (Damodaran)"),
        ("docx", "python-docx", "Word reports"),
        ("reportlab", "reportlab", "PDF evidence sheets"),
        ("lxml", "lxml", "Word XML engine")]


def main():
    quiet = "--quiet" in sys.argv
    missing = []
    if not quiet:
        print(f"Python {sys.version.split()[0]} at {sys.executable}\n")
    if sys.version_info < (3, 9):
        print("ERROR: Python 3.9 or newer is required (3.11 / 3.12 recommended).")
        return 1
    for mod, pip_name, use in LIBS:
        try:
            m = importlib.import_module(mod)
            ver = getattr(m, "__version__", "")
            if mod.startswith("PyQt5"):
                from PyQt5.QtCore import PYQT_VERSION_STR
                ver = PYQT_VERSION_STR
            if not quiet:
                print(f"  [OK]      {pip_name:<12} {ver:<10} {use}")
        except Exception as e:
            missing.append(pip_name)
            print(f"  [MISSING] {pip_name:<12} {'':<10} {use}  ({e.__class__.__name__}: {e})")
    if missing:
        print("\nMissing: " + " ".join(missing))
        print("Fix: run INSTALL_Requirements.bat   or   python -m pip install " + " ".join(missing))
        return 1
    if not quiet:
        print("\nAll required libraries are installed. You can run the tool.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
