"""Valuation page: DCF, NAV, Rule 11UA, multiples, VWAP, debt, conclusion."""
from pathlib import Path

from PyQt5.QtWidgets import (
    QCheckBox, QFormLayout, QGroupBox, QLabel, QTableWidget, QTabWidget, QVBoxLayout, QWidget, QHeaderView,
)

from core import market_data as mkt
from core import storage as sto
from core import valuation as val
from core.config import load_settings
from .base import Page
from .common import (RecordTable, button, combo, date_edit, dspin, error, fill_readonly, fmt, hbox, info, iso,
                     pick_file)

DCF_COLS = [("label", "Year", "text"), ("ebitda", "EBITDA", "num"), ("dep", "Depreciation", "num"),
            ("interest", "Interest (FCFE)", "num"), ("tax_rate", "Tax rate %", "num"), ("capex", "Capex", "num"),
            ("delta_nwc", "Increase in NWC", "num"), ("net_borrowing", "Net borrowing (FCFE)", "num")]
NAV_COLS = [("item", "Item", "text"), ("book", "Book value", "num"), ("fair", "Fair value", "num")]
PEER_COLS = [("name", "Comparable company", "text"), ("multiple", "Multiple (x)", "num")]


def _tab():
    w = QWidget()
    v = QVBoxLayout(w)
    return w, v


class ValuationPage(Page):
    title = "5. Valuation"

    def build(self):
        self.hdr = QLabel(); self.hdr.setObjectName("banner")
        self.lay.addWidget(self.hdr)
        self.tabs = QTabWidget()
        self.lay.addWidget(self.tabs)
        self._build_dcf(); self._build_nav(); self._build_11ua(); self._build_market()
        self._build_vwap(); self._build_debt(); self._build_conclusion()
        self.tabs.currentChanged.connect(lambda i: self.refresh_conclusion() if i == 6 else None)

    # ------------------------------------------------------------------ DCF
    def _build_dcf(self):
        w, v = _tab()
        f = QFormLayout()
        self.mode = combo(["FCFF (discount at WACC)", "FCFE (discount at Ke)"], data=["FCFF", "FCFE"])
        self.rate = dspin(12, 2, 0.01, 100, 0.1, " %")
        self.g = dspin(5, 2, -10, 20, 0.25, " %")
        self.mid = QCheckBox("Mid-year discounting"); self.mid.setChecked(True)
        self.stub = dspin(1, 2, 0.01, 1, 0.01)
        self.nd = dspin(0, 2)
        self.noa = dspin(0, 2)
        f.addRow("Method", self.mode)
        f.addRow("Discount rate", hbox(self.rate, button("Use WACC / Ke from market page", self._use_rate)))
        f.addRow("Terminal growth", self.g)
        f.addRow("", self.mid)
        f.addRow("First-year fraction (stub period)", self.stub)
        f.addRow("Net debt (debt - cash) [FCFF]", self.nd)
        f.addRow("Non-operating / surplus assets", self.noa)
        v.addLayout(f)
        v.addWidget(QLabel("<b>Projections</b> - edit cells directly"))
        self.dcf_t = RecordTable(DCF_COLS)
        self.dcf_t.setMinimumHeight(200)
        v.addWidget(self.dcf_t)
        v.addWidget(hbox(button("Add year", lambda: self.dcf_t.add_row({"label": f"Y{self.dcf_t.rowCount() + 1}",
                                                                          "tax_rate": load_settings()["default_tax_rate"]})),
                         button("Remove selected", self.dcf_t.remove_selected),
                         button("Compute DCF", self.compute_dcf, primary=True)))
        self.dcf_res = QLabel(); self.dcf_res.setWordWrap(True)
        v.addWidget(self.dcf_res)
        self.dcf_rows = QTableWidget(); self.dcf_rows.setMinimumHeight(170)
        self.dcf_rows.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        v.addWidget(self.dcf_rows)
        v.addWidget(QLabel("<b>Sensitivity</b> - value per share (rows: discount rate, columns: terminal growth)"))
        self.sens = QTableWidget(); self.sens.setMinimumHeight(170)
        self.sens.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        v.addWidget(self.sens)
        self.tabs.addTab(w, "DCF")

    def _use_rate(self):
        md = self.app.current().get("market_data", {})
        key = "wacc" if self.mode.currentData() == "FCFF" else "ke"
        if not md.get(key):
            error(self, f"{key.upper()} not saved on the Market data page yet.")
            return
        self.rate.setValue(float(md[key]))

    def compute_dcf(self):
        a = self.app.current()
        try:
            yrs = self.dcf_t.records()
            if not yrs:
                raise ValueError("Enter at least one projection year.")
            kw = dict(mode=self.mode.currentData(), mid_year=self.mid.isChecked(),
                      net_debt=self.nd.value() if self.mode.currentData() == "FCFF" else 0.0,
                      non_operating_assets=self.noa.value(), shares=self._shares(a), unit_mult=self._mult(a),
                      first_period_fraction=self.stub.value())
            r = val.dcf(yrs, self.rate.value(), self.g.value(), **kw)
            v = a.setdefault("valuation", {})
            v["dcf"], v["dcf_inputs"] = r, yrs
            v["dcf_sensitivity"] = val.dcf_sensitivity(yrs, self.rate.value(), self.g.value(), **kw)
            v["dcf_params"] = {"nd": self.nd.value(), "noa": self.noa.value(), "stub": self.stub.value()}
            self.app.save(a, f"DCF {r['mode']} value/share {r['value_per_share']:.2f}")
            self.show_dcf(v)
        except Exception as e:
            error(self, e)

    def show_dcf(self, v):
        r = v.get("dcf")
        if not r:
            self.dcf_res.setText(""); fill_readonly(self.dcf_rows, [], []); fill_readonly(self.sens, [], [])
            return
        warn = " &nbsp; <span style='color:#b00'>Terminal value > 75% of total - review assumptions.</span>" \
            if r["tv_share_pct"] > 75 else ""
        self.dcf_res.setText(
            f"Sum of PV {fmt(r['sum_pv'])} + PV of TV {fmt(r['pv_tv'])} = <b>{fmt(r['enterprise_or_equity_value'])}</b>; "
            f"equity value <b>{fmt(r['equity_value'])}</b>; <b>value per share {fmt(r['value_per_share'])}</b>; "
            f"TV share {r['tv_share_pct']:.1f}%{warn}")
        fill_readonly(self.dcf_rows, ["Year", "EBITDA", "EBIT", "Tax", "Free cash flow", "Period", "DF", "PV"],
                      [[x["label"], fmt(x["ebitda"]), fmt(x["ebit"]), fmt(x["tax"]), fmt(x["cash_flow"]),
                        x["period"], f"{x['df']:.4f}", fmt(x["pv"])] for x in r["rows"]])
        g = v.get("dcf_sensitivity", {})
        if g:
            cols = list(next(iter(g.values())).keys())
            fill_readonly(self.sens, ["Discount rate \\ growth"] + cols,
                          [[k] + [fmt(x) for x in row.values()] for k, row in g.items()])

    # ------------------------------------------------------------------ NAV
    def _build_nav(self):
        w, v = _tab()
        v.addWidget(QLabel("<b>Assets</b> (enter book value and fair value; fair = book if not revalued)"))
        self.nav_a = RecordTable(NAV_COLS); self.nav_a.setMinimumHeight(160)
        v.addWidget(self.nav_a)
        v.addWidget(hbox(button("Add asset", lambda: self.nav_a.add_row()), button("Remove selected", self.nav_a.remove_selected)))
        v.addWidget(QLabel("<b>Liabilities</b>"))
        self.nav_l = RecordTable(NAV_COLS); self.nav_l.setMinimumHeight(140)
        v.addWidget(self.nav_l)
        v.addWidget(hbox(button("Add liability", lambda: self.nav_l.add_row()), button("Remove selected", self.nav_l.remove_selected),
                         button("Compute NAV", self.compute_nav, primary=True)))
        self.nav_res = QLabel()
        v.addWidget(self.nav_res)
        v.addStretch(1)
        self.tabs.addTab(w, "Net Asset Value")

    def compute_nav(self):
        a = self.app.current()
        try:
            r = val.nav(self.nav_a.records(), self.nav_l.records(), self._shares(a), self._mult(a))
            a.setdefault("valuation", {})["nav"] = r
            self.app.save(a, f"NAV {r['value_per_share']:.2f}")
            self.show_nav(r)
        except Exception as e:
            error(self, e)

    def show_nav(self, r):
        self.nav_res.setText(f"Book NAV {fmt(r['book_nav'])} ({fmt(r['book_nav_per_share'])}/share) &nbsp;|&nbsp; "
                             f"<b>Adjusted NAV {fmt(r['adjusted_nav'])} = {fmt(r['value_per_share'])} per share</b>" if r else "")

    # ------------------------------------------------------------------ Rule 11UA
    def _build_11ua(self):
        w, v = _tab()
        note = QLabel("Rule 11UA(1)(c)(a), Income-tax Rules: FMV per unquoted equity share = (A - L) x PV / PE.<br>"
                      "A = book value of assets less income-tax paid (net of refund) and unamortised deferred expenditure; "
                      "L = liabilities excluding paid-up equity, reserves &amp; surplus, tax provision in excess of tax payable, "
                      "unascertained provisions, undeclared proposed dividend and contingent liabilities. "
                      "Verify against the Rule as amended on the valuation date.")
        note.setWordWrap(True)
        v.addWidget(note)
        f = QFormLayout()
        self.ua_A, self.ua_L, self.ua_PE, self.ua_PV = dspin(0), dspin(0), dspin(1000000, 2, 0.01), dspin(10, 2, 0.01)
        f.addRow("A - adjusted assets", self.ua_A); f.addRow("L - specified liabilities", self.ua_L)
        f.addRow("PE - total paid-up equity capital (same unit as A and L)", self.ua_PE); f.addRow("PV - paid-up value per share", self.ua_PV)
        f.addRow("", button("Compute Rule 11UA FMV", self.compute_11ua, primary=True))
        v.addLayout(f)
        self.ua_res = QLabel(); v.addWidget(self.ua_res)
        v.addStretch(1)
        self.tabs.addTab(w, "Rule 11UA NAV")

    def compute_11ua(self):
        a = self.app.current()
        r = val.rule_11ua_nav(self.ua_A.value(), self.ua_L.value(), self.ua_PE.value(), self.ua_PV.value())
        a.setdefault("valuation", {})["rule11ua"] = r
        self.app.save(a, "Rule 11UA computed")
        self.ua_res.setText(f"<b>FMV per share = {fmt(r['value_per_share'])}</b>")

    # ------------------------------------------------------------------ Market multiples
    def _build_market(self):
        w, v = _tab()
        f = QFormLayout()
        self.mt = combo(["EV/EBITDA", "EV/Revenue", "P/E", "P/BV"])
        self.stat = combo(["median", "mean"])
        self.disc = dspin(0, 2, -100, 100, 1, " %")
        self.metric = dspin(0)
        self.nd2 = dspin(0)
        f.addRow("Multiple", self.mt); f.addRow("Statistic", self.stat)
        f.addRow("Discount to peers (size / liquidity)", self.disc)
        f.addRow("Subject company metric (EBITDA / Revenue / PAT / Book value)", self.metric)
        f.addRow("Net debt (EV multiples only)", self.nd2)
        v.addLayout(f)
        self.peers = RecordTable(PEER_COLS); self.peers.setMinimumHeight(170)
        v.addWidget(self.peers)
        v.addWidget(hbox(button("Add peer", lambda: self.peers.add_row()), button("Remove selected", self.peers.remove_selected),
                         button("Attach peer data proof...", self.peer_proof),
                         button("Compute market approach", self.compute_market, primary=True)))
        self.mk_res = QLabel(); v.addWidget(self.mk_res)
        v.addStretch(1)
        self.tabs.addTab(w, "Comparable multiples")

    def peer_proof(self):
        p = pick_file(self, "Peer data proof (Capitaline / Prowess / screener export)")
        if p:
            a = self.app.current()
            sto.save_upload(a["assignment_id"], "05_Market_Data_Proofs", Path(p).name, Path(p).read_bytes(), prefix="Peers")
            info(self, "Proof saved to 05_Market_Data_Proofs.")

    def compute_market(self):
        a = self.app.current()
        try:
            r = val.market_multiple(self.peers.records(), self.metric.value(), self.mt.currentText(), self.nd2.value(),
                                    self._shares(a), self.stat.currentText(), self.disc.value(), self._mult(a))
            a.setdefault("valuation", {})["market"] = r
            self.app.save(a, "Market approach computed")
            self.show_market(r)
        except Exception as e:
            error(self, e)

    def show_market(self, r):
        self.mk_res.setText(f"Peer {r['statistic']} {r['peer_multiple']:.2f}x (range {r['min']:.2f}x-{r['max']:.2f}x), applied "
                            f"{r['applied_multiple']:.2f}x &nbsp;|&nbsp; equity {fmt(r['equity_value'])} &nbsp;|&nbsp; "
                            f"<b>value per share {fmt(r['value_per_share'])}</b>" if r else "")

    # ------------------------------------------------------------------ VWAP
    def _build_vwap(self):
        w, v = _tab()
        note = QLabel("Listed shares (SEBI ICDR preferential issue): upload NSE / BSE price-volume history with Date, "
                      "Volume / No. of shares and Turnover (or Close). The tool computes the 90 and 10 trading-day VWAP "
                      "before the relevant date and takes the higher.")
        note.setWordWrap(True); v.addWidget(note)
        self.rd = date_edit()
        v.addWidget(hbox("Relevant date", self.rd, button("Select price file and compute VWAP", self.compute_vwap, primary=True)))
        self.vw_res = QLabel(); self.vw_res.setWordWrap(True); v.addWidget(self.vw_res)
        v.addStretch(1)
        self.tabs.addTab(w, "Listed price (VWAP)")

    def compute_vwap(self):
        p = pick_file(self, "Price-volume file", "Data (*.csv *.xlsx *.xls)")
        if not p:
            return
        a = self.app.current()
        try:
            r = mkt.vwap_pricing(Path(p).read_bytes(), Path(p).name, iso(self.rd))
            sto.save_upload(a["assignment_id"], "05_Market_Data_Proofs", Path(p).name, Path(p).read_bytes(), prefix="PriceData")
            a.setdefault("valuation", {})["vwap"] = r
            self.app.save(a, "VWAP computed")
            self.show_vwap(r)
        except Exception as e:
            error(self, e)

    def show_vwap(self, r):
        self.vw_res.setText(f"90-day VWAP {fmt(r['vwap_90'])} ({r['days_90']} days) &nbsp;|&nbsp; 10-day VWAP {fmt(r['vwap_10'])} "
                            f"({r['days_10']} days) &nbsp;|&nbsp; <b>Floor price {fmt(r['floor_price'])}</b><br>{r['basis']}" if r else "")

    # ------------------------------------------------------------------ Debt
    def _build_debt(self):
        w, v = _tab()
        f = QFormLayout()
        self.fv, self.cp, self.ytm = dspin(100, 2, 0.01), dspin(8, 4, 0, 50, 0.25, " %"), dspin(3, 2, 0.1, 50, 0.5, " yrs")
        self.fq = combo(["1", "2", "4", "12"], "2")
        self.spread, self.prem = dspin(2, 2, -5, 30, 0.25, " %"), dspin(0, 2, 0, 100, 1, " %")
        self.debt_y = QLabel()
        for lab, x in [("Face value", self.fv), ("Coupon rate", self.cp), ("Years to maturity", self.ytm),
                       ("Payments per year", self.fq), ("Credit spread over Rf", self.spread),
                       ("Redemption premium", self.prem), ("Discount yield", self.debt_y)]:
            f.addRow(lab, x)
        f.addRow("", button("Value instrument", self.compute_debt, primary=True))
        v.addLayout(f)
        self.debt_res = QLabel(); v.addWidget(self.debt_res)
        v.addStretch(1)
        self.spread.valueChanged.connect(self._yield_lbl)
        self.tabs.addTab(w, "Debt instrument")

    def _yield_lbl(self, *_):
        a = self.app.current()
        rf = float(a.get("market_data", {}).get("rfr", {}).get("rate", 7.0)) if a else 7.0
        self.debt_y.setText(f"Rf {rf:.2f}% + spread {self.spread.value():.2f}% = <b>{rf + self.spread.value():.2f}%</b>")
        return rf + self.spread.value()

    def compute_debt(self):
        a = self.app.current()
        r = val.debt_instrument(self.fv.value(), self.cp.value(), self.ytm.value(), int(self.fq.currentText()),
                                self._yield_lbl(), self.prem.value())
        a.setdefault("valuation", {})["debt"] = r
        self.app.save(a, "Debt instrument valued")
        self.debt_res.setText(f"<b>Value per unit = {fmt(r['value_per_unit'])}</b>")

    # ------------------------------------------------------------------ Conclusion
    def _build_conclusion(self):
        w, v = _tab()
        v.addWidget(QLabel("Assign weights (must total 100%) to the methods computed, then apply discounts."))
        self.wbox = QGroupBox("Methods and weights")
        self.wform = QFormLayout(self.wbox)
        v.addWidget(self.wbox)
        f = QFormLayout()
        self.dloc, self.dlom = dspin(0, 2, 0, 90, 1, " %"), dspin(0, 2, 0, 90, 1, " %")
        f.addRow("Discount for lack of control (DLOC)", self.dloc)
        f.addRow("Discount for lack of marketability (DLOM)", self.dlom)
        f.addRow("", button("Conclude value", self.conclude, primary=True))
        v.addLayout(f)
        self.c_res = QLabel(); self.c_res.setObjectName("ok"); v.addWidget(self.c_res)
        v.addStretch(1)
        self.weights = {}
        self.tabs.addTab(w, "Conclusion")

    def _available(self, v):
        m = {}
        if "dcf" in v: m[f"DCF ({v['dcf']['mode']})"] = v["dcf"]["value_per_share"]
        if "nav" in v: m["Net Asset Value"] = v["nav"]["value_per_share"]
        if "rule11ua" in v: m["Rule 11UA NAV"] = v["rule11ua"]["value_per_share"]
        if "market" in v: m[f"Comparable companies ({v['market']['multiple_type']})"] = v["market"]["value_per_share"]
        if "vwap" in v: m["Market price (VWAP)"] = v["vwap"]["floor_price"]
        if "debt" in v: m["PV of contractual cash flows"] = v["debt"]["value_per_unit"]
        return m

    def refresh_conclusion(self):
        a = self.app.current()
        if not a:
            return
        v = a.get("valuation", {})
        while self.wform.rowCount():
            self.wform.removeRow(0)
        self.weights = {}
        avail = self._available(v)
        prev = v.get("conclusion", {}).get("weights", {})
        if not avail:
            self.wform.addRow(QLabel("Compute at least one method first."))
        for m, x in avail.items():
            sp = dspin(prev.get(m, round(100.0 / len(avail), 2)), 2, 0, 100, 5, " %")
            self.weights[m] = sp
            self.wform.addRow(f"{m}: {fmt(x)}", sp)
        c = v.get("conclusion", {})
        self.dloc.setValue(float(c.get("dloc_pct", 0))); self.dlom.setValue(float(c.get("dlom_pct", 0)))
        self.c_res.setText(f"Fair value per share: <b>{fmt(c['final_value_per_share'])}</b>" if c else "")

    def conclude(self):
        a = self.app.current()
        v = a.get("valuation", {})
        avail = self._available(v)
        if not avail:
            error(self, "Compute at least one method first.")
            return
        try:
            c = val.conclude(avail, {m: s.value() for m, s in self.weights.items()}, self.dlom.value(), self.dloc.value())
            v["conclusion"] = c
            self.app.save(a, f"Concluded {c['final_value_per_share']:.2f}")
            self.c_res.setText(f"Weighted {fmt(c['weighted_value'])} &nbsp;->&nbsp; <b>Fair value per share: "
                               f"{fmt(c['final_value_per_share'])}</b>")
        except Exception as e:
            error(self, e)

    # ------------------------------------------------------------------ load
    @staticmethod
    def _mult(a):
        return val.unit_mult(a["details"].get("currency_unit", "INR"))

    @staticmethod
    def _shares(a):
        return float(a["details"].get("shares_outstanding") or 1) or 1.0

    def load(self, a):
        d, v, md = a["details"], a.get("valuation", {}), a.get("market_data", {})
        s = load_settings()
        self.hdr.setText(f"Amounts in <b>{d.get('currency_unit', 'INR')}</b> &nbsp;|&nbsp; Shares outstanding: "
                         f"<b>{self._shares(a):,.0f}</b> &nbsp;|&nbsp; Value per share is always in INR &nbsp;|&nbsp; Ke {md.get('ke', 0):.2f}% &nbsp;|&nbsp; "
                         f"WACC {md.get('wacc', 0):.2f}%  (change shares on Engagement page)")
        if "dcf" in v:
            self.mode.setCurrentIndex(max(0, self.mode.findData(v["dcf"]["mode"])))
            self.rate.setValue(v["dcf"]["discount_rate"]); self.g.setValue(v["dcf"]["terminal_growth"])
            self.mid.setChecked(v["dcf"]["mid_year"])
        else:
            self.rate.setValue(float(md.get("wacc", 12) or 12)); self.g.setValue(float(s["default_terminal_growth"]))
        p = v.get("dcf_params", {})
        self.nd.setValue(p.get("nd", 0)); self.noa.setValue(p.get("noa", 0)); self.stub.setValue(p.get("stub", 1))
        self.dcf_t.set_records(v.get("dcf_inputs") or [
            {"label": f"FY{27 + i}", "ebitda": 0.0, "dep": 0.0, "interest": 0.0, "tax_rate": float(s["default_tax_rate"]),
             "capex": 0.0, "delta_nwc": 0.0, "net_borrowing": 0.0} for i in range(5)])
        self.show_dcf(v)
        nav = v.get("nav", {})
        self.nav_a.set_records(nav.get("assets") or [{"item": "Property, plant & equipment"}, {"item": "Investments"},
                                                     {"item": "Current assets incl. cash"}])
        self.nav_l.set_records(nav.get("liabilities") or [{"item": "Borrowings"}, {"item": "Current liabilities & provisions"}])
        self.show_nav(nav)
        ua = v.get("rule11ua")
        if ua:
            self.ua_A.setValue(ua["A"]); self.ua_L.setValue(ua["L"]); self.ua_PE.setValue(ua["PE"]); self.ua_PV.setValue(ua["PV"])
            self.ua_res.setText(f"<b>FMV per share = {fmt(ua['value_per_share'])}</b>")
        else:
            fv = float(d.get("face_value", 10) or 10)
            self.ua_PV.setValue(fv); self.ua_PE.setValue(fv * self._shares(a) / self._mult(a)); self.ua_res.setText("")
        mk = v.get("market")
        self.peers.set_records(mk["peers"] if mk else [{"name": "Peer 1"}, {"name": "Peer 2"}, {"name": "Peer 3"}])
        if mk:
            self.mt.setCurrentText(mk["multiple_type"]); self.stat.setCurrentText(mk["statistic"])
            self.disc.setValue(mk["discount_pct"]); self.metric.setValue(mk["subject_metric"]); self.nd2.setValue(mk["net_debt"])
        self.show_market(mk)
        self.rd.setDate(date_edit(d.get("valuation_date", "")).date())
        self.show_vwap(v.get("vwap"))
        self._yield_lbl()
        self.debt_res.setText(f"<b>Value per unit = {fmt(v['debt']['value_per_unit'])}</b>" if "debt" in v else "")
        self.refresh_conclusion()
