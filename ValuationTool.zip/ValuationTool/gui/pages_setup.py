"""Dashboard, Engagement details and Document checklist pages."""
from pathlib import Path

import pandas as pd
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QBrush, QColor
from PyQt5.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QGroupBox, QHeaderView, QInputDialog, QLabel, QLineEdit, QPlainTextEdit, QProgressBar,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from core import checklist as ck
from core import industry as ind
from core import storage as sto
from core.config import FOLDERS, load_settings
from .base import Page
from .common import (set_state, ask, button, combo, date_edit, dspin, error, fill_readonly, hbox, info, iso,
                     open_path, pick_files)


# ============================================================================ DASHBOARD
class DashboardPage(Page):
    title = "Dashboard"
    needs_assignment = False

    def build(self):
        g = QGroupBox("Create new assignment")
        f = QFormLayout(g)
        self.client = QLineEdit()
        self.purpose = combo(list(ck.PURPOSES.values()), data=list(ck.PURPOSES))
        self.security = combo(ck.SECURITY_TYPES)
        self.vdate = date_edit()
        self.nob = QPlainTextEdit()
        self.nob.setPlaceholderText("e.g. Manufacturer of auto components for two-wheeler OEMs")
        self.nob.setFixedHeight(60)
        f.addRow("Client / Company name *", self.client)
        f.addRow("Purpose of valuation *", self.purpose)
        f.addRow("Security / asset valued *", self.security)
        f.addRow("Valuation date *", self.vdate)
        f.addRow("Nature of business *", self.nob)
        f.addRow("", button("Create assignment && folders", self.create, primary=True))
        self.lay.addWidget(g)

        g2 = QGroupBox("All assignments")
        v = QVBoxLayout(g2)
        self.table = QTableWidget()
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(self.open_selected)
        self.table.setMinimumHeight(260)
        v.addWidget(self.table)
        v.addWidget(hbox(button("Open selected", self.open_selected, primary=True),
                         button("Open client folder", self.open_folder),
                         button("Create ZIP archive", self.zip_selected),
                         button("Refresh", self.refresh)))
        self.lay.addWidget(g2)
        self.lay.addStretch(1)

    def load(self, a):
        rows = []
        for x in sto.list_assignments():
            cs = ck.checklist_status(x.get("checklist", []))
            rows.append([x["assignment_id"], x["client_name"], x["details"].get("purpose", ""),
                         x["details"].get("valuation_date", ""),
                         f"{cs['mandatory_received']}/{cs['mandatory']}",
                         "Yes" if x.get("market_data", {}).get("rfr", {}).get("evidence_pdf") else "No",
                         f"{(x.get('valuation', {}).get('conclusion', {}).get('final_value_per_share') or 0):,.2f}",
                         x.get("status", "")])
        fill_readonly(self.table, ["Assignment ID", "Client", "Purpose", "Valuation date", "Mandatory docs",
                                   "Rf proof", "Value / share", "Status"], rows)

    def _selected(self):
        r = self.table.currentRow()
        if r < 0:
            error(self, "Select an assignment in the table first.")
            return None
        return self.table.item(r, 0).text()

    def create(self):
        client, nob = self.client.text().strip(), self.nob.toPlainText().strip()
        if not client or not nob:
            error(self, "Client name and nature of business are required.")
            return
        purpose, sec = self.purpose.currentData(), self.security.currentText()
        a = sto.create_assignment(client, {"purpose": purpose, "security_type": sec, "valuation_date": iso(self.vdate),
                                           "nature_of_business": nob, "currency_unit": "INR"})
        a["checklist"] = ck.build_checklist(purpose, sec)
        sug = ind.match_industry(nob)
        a["details"]["industry"] = sug[0] if sug else ""
        sto.save_assignment(a)
        self.client.clear()
        self.nob.clear()
        self.app.set_assignment(a["assignment_id"])
        info(self, f"Assignment created with {len(FOLDERS)} folders:\n{sto.assignment_dir(a['assignment_id'])}")
        self.refresh()

    def open_selected(self, *_):
        aid = self._selected()
        if aid:
            self.app.set_assignment(aid)
            self.app.go(1)

    def open_folder(self):
        aid = self._selected()
        if aid:
            open_path(sto.assignment_dir(aid))

    def zip_selected(self):
        aid = self._selected()
        if aid:
            z = sto.zip_assignment(aid)
            info(self, f"Archive created:\n{z}")
            open_path(z.parent)


# ============================================================================ ENGAGEMENT
class EngagementPage(Page):
    title = "1. Engagement details"

    def build(self):
        g = QGroupBox("Company and engagement (Rule 8 particulars)")
        f = QFormLayout(g)
        self.client = QLineEdit()
        self.cin, self.pan = QLineEdit(), QLineEdit()
        self.unit = combo(["INR", "INR thousands", "INR lakhs", "INR crores"])
        self.office = QLineEdit()
        self.nob = QPlainTextEdit(); self.nob.setFixedHeight(55)
        self.background = QPlainTextEdit(); self.background.setFixedHeight(70)
        self.purpose = combo(list(ck.PURPOSES.values()), data=list(ck.PURPOSES))
        self.security = combo(ck.SECURITY_TYPES)
        self.authority = QLineEdit()
        self.basis = combo(["Fair Value", "Fair Market Value", "Participant-specific value", "Liquidation Value",
                            "Fair Value and Liquidation Value"])
        self.premise = combo(["Going Concern", "Orderly Liquidation", "Forced Liquidation", "As-is-where-is"])
        self.shares = dspin(100000, 0, 0, step=1)
        self.face = dspin(10, 2, 0)
        self.d_app, self.d_val, self.d_rep = date_edit(), date_edit(), date_edit()
        self.experts = QLineEdit()
        self.conflict = QPlainTextEdit(); self.conflict.setFixedHeight(55)
        self.inspect = QPlainTextEdit(); self.inspect.setFixedHeight(55)
        self.rationale = QPlainTextEdit(); self.rationale.setFixedHeight(55)
        self.restrict = QPlainTextEdit(); self.restrict.setFixedHeight(55)
        for w in (self.conflict, self.inspect, self.restrict):
            w.setPlaceholderText("Leave blank to use the standard wording")
        rows = [("Client / Company name", self.client), ("CIN", self.cin), ("PAN", self.pan), ("Amounts in", self.unit),
                ("Registered office", self.office), ("Nature of business", self.nob),
                ("Background / history (Rule 8(a))", self.background), ("Purpose", self.purpose),
                ("Security valued", self.security), ("Appointing authority", self.authority),
                ("Basis of value (ICAI VS 102)", self.basis), ("Premise of value", self.premise),
                ("No. of shares / units", self.shares), ("Face value per share", self.face),
                ("Date of appointment", self.d_app), ("Valuation date", self.d_val), ("Report date", self.d_rep),
                ("Other experts (Rule 8(c))", self.experts), ("Interest / conflict disclosure", self.conflict),
                ("Inspections / investigations", self.inspect), ("Rationale for approaches", self.rationale),
                ("Restrictions on use", self.restrict)]
        for label, w in rows:
            f.addRow(label, w)
        self.regen = QCheckBox("Rebuild document checklist for changed purpose / security (keeps ticked items)")
        f.addRow("", self.regen)
        f.addRow("", button("Save engagement details", self.save, primary=True))
        self.lay.addWidget(g)
        self.lay.addStretch(1)

    def load(self, a):
        d = a["details"]
        self.client.setText(a["client_name"])
        self.cin.setText(d.get("cin", "")); self.pan.setText(d.get("pan", ""))
        self.unit.setCurrentText(d.get("currency_unit", "INR"))
        self.office.setText(d.get("registered_office", ""))
        self.nob.setPlainText(d.get("nature_of_business", ""))
        self.background.setPlainText(d.get("background", ""))
        self.purpose.setCurrentIndex(max(0, self.purpose.findData(d.get("purpose"))))
        self.security.setCurrentText(d.get("security_type", ck.SECURITY_TYPES[0]))
        self.authority.setText(d.get("appointing_authority", "Board of Directors"))
        self.basis.setCurrentText(d.get("basis_of_value", "Fair Value"))
        self.premise.setCurrentText(d.get("premise_of_value", "Going Concern"))
        self.shares.setValue(float(d.get("shares_outstanding", 100000) or 0))
        self.face.setValue(float(d.get("face_value", 10) or 0))
        for w, k in ((self.d_app, "appointment_date"), (self.d_val, "valuation_date"), (self.d_rep, "report_date")):
            w.setDate(date_edit(d.get(k, "")).date())
        self.experts.setText(d.get("other_experts", ""))
        self.conflict.setPlainText(d.get("conflict_declaration", ""))
        self.inspect.setPlainText(d.get("inspections", ""))
        self.rationale.setPlainText(d.get("approach_rationale", ""))
        self.restrict.setPlainText(d.get("restrictions", ""))
        self.regen.setChecked(False)

    def save(self):
        a = self.app.current()
        d = a["details"]
        a["client_name"] = self.client.text().strip() or a["client_name"]
        d.update({"cin": self.cin.text().strip(), "pan": self.pan.text().strip(), "currency_unit": self.unit.currentText(),
                  "registered_office": self.office.text().strip(), "nature_of_business": self.nob.toPlainText().strip(),
                  "background": self.background.toPlainText().strip(), "purpose": self.purpose.currentData(),
                  "security_type": self.security.currentText(), "appointing_authority": self.authority.text().strip(),
                  "basis_of_value": self.basis.currentText(), "premise_of_value": self.premise.currentText(),
                  "shares_outstanding": self.shares.value(), "face_value": self.face.value(),
                  "appointment_date": iso(self.d_app), "valuation_date": iso(self.d_val), "report_date": iso(self.d_rep),
                  "other_experts": self.experts.text().strip(), "conflict_declaration": self.conflict.toPlainText().strip(),
                  "inspections": self.inspect.toPlainText().strip(), "approach_rationale": self.rationale.toPlainText().strip(),
                  "restrictions": self.restrict.toPlainText().strip()})
        if self.regen.isChecked():
            old = {c["id"]: c for c in a.get("checklist", [])}
            a["checklist"] = [old.get(c["id"], c) for c in ck.build_checklist(d["purpose"], d["security_type"])]
        self.app.save(a, "Engagement details updated")
        info(self, "Engagement details saved.")


# ============================================================================ CHECKLIST
COLS = ["Received", "N/A", "Ref", "Information / document", "Mandatory", "Folder", "File(s)", "Remarks"]


class ChecklistPage(Page):
    title = "2. Document checklist"

    def build(self):
        self.summary = QLabel(); self.summary.setObjectName("banner")
        self.lay.addWidget(self.summary)
        self.bar = QProgressBar()
        self.lay.addWidget(self.bar)
        hint = QLabel("Tick <b>Received</b> as documents arrive. Select a row and click <b>Attach file(s)</b> - the file is "
                      "copied into the correct folder automatically and the item is ticked. Double-click a row to open its folder.")
        hint.setWordWrap(True)
        self.lay.addWidget(hint)
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        h = self.table.horizontalHeader()
        for i in range(len(COLS)):
            h.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setWordWrap(True)
        self.table.setMinimumHeight(420)
        self.table.itemChanged.connect(self.on_change)
        self.table.cellDoubleClicked.connect(self.open_row_folder)
        self.lay.addWidget(self.table)
        self.lay.addWidget(hbox(button("Attach file(s) to selected item", self.attach, primary=True),
                                button("Open item folder", lambda: self.open_row_folder(self.table.currentRow(), 0)),
                                button("Add extra item", self.add_item),
                                button("Pending documents letter", self.letter),
                                button("Export checklist (CSV)", self.export)))
        self._loading = False

    def load(self, a):
        self._loading = True
        cl = a["checklist"]
        self.table.setRowCount(len(cl))
        for r, c in enumerate(cl):
            for col, checked in ((0, c["received"]), (1, c.get("na", False))):
                it = QTableWidgetItem()
                it.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setCheckState(Qt.Checked if checked else Qt.Unchecked)
                self.table.setItem(r, col, it)
            for col, txt in ((2, c["id"]), (3, c["text"]), (4, "Yes" if c["mandatory"] else ""),
                             (5, c["folder"]), (6, "\n".join(c.get("files", [])))):
                it = QTableWidgetItem(txt)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if col == 4 and c["mandatory"]:
                    it.setForeground(QBrush(QColor('red')))
                self.table.setItem(r, col, it)
            self.table.setItem(r, 7, QTableWidgetItem(c.get("remarks", "")))
        self.table.resizeRowsToContents()
        self._loading = False
        self.update_summary(a)

    def update_summary(self, a):
        s = ck.checklist_status(a["checklist"])
        self.bar.setMaximum(max(s["mandatory"], 1))
        self.bar.setValue(s["mandatory_received"])
        self.summary.setText(f"Items received: <b>{s['received']}/{s['total']}</b> &nbsp;|&nbsp; Mandatory received: "
                             f"<b>{s['mandatory_received']}/{s['mandatory']}</b> &nbsp;|&nbsp; Ready for report: "
                             f"<b>{'YES' if s['ready'] else 'NO'}</b>")
        set_state(self.summary, "ok" if s["ready"] else "warn")

    def on_change(self, item):
        if self._loading:
            return
        a = self.app.current()
        c = a["checklist"][item.row()]
        col = item.column()
        if col == 0:
            c["received"] = item.checkState() == Qt.Checked
        elif col == 1:
            c["na"] = item.checkState() == Qt.Checked
        elif col == 7:
            c["remarks"] = item.text()
        else:
            return
        self.app.save(a, f"Checklist {c['id']} received={c['received']} na={c.get('na')}")
        self.update_summary(a)

    def attach(self):
        r = self.table.currentRow()
        if r < 0:
            error(self, "Select a checklist row first.")
            return
        paths = pick_files(self, "Select document(s)")
        if not paths:
            return
        a = self.app.current()
        c = a["checklist"][r]
        for p in paths:
            saved = sto.save_upload(a["assignment_id"], c["folder"], Path(p).name, Path(p).read_bytes(), prefix=c["id"])
            c["files"].append(saved.name)
        c["received"] = True
        self.app.save(a, f"Checklist {c['id']} files attached")
        self.load(a)
        self.table.selectRow(r)

    def open_row_folder(self, r, _c):
        a = self.app.current()
        if r is None or r < 0:
            return
        open_path(sto.assignment_dir(a["assignment_id"]) / a["checklist"][r]["folder"])

    def add_item(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Add checklist item")
        f = QFormLayout(dlg)
        t = QLineEdit(); fo = combo(FOLDERS); m = QCheckBox("Mandatory")
        f.addRow("Description", t); f.addRow("Folder", fo); f.addRow("", m)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept); bb.rejected.connect(dlg.reject)
        f.addRow(bb)
        if dlg.exec_() and t.text().strip():
            a = self.app.current()
            a["checklist"].append({"id": f"X{len(a['checklist']) + 1:02d}", "text": t.text().strip(),
                                   "folder": fo.currentText(), "mandatory": m.isChecked(), "received": False,
                                   "files": [], "remarks": "", "na": False})
            self.app.save(a, f"Extra checklist item: {t.text().strip()}")
            self.load(a)

    def letter(self):
        a = self.app.current()
        s = load_settings()
        pend = ck.checklist_status(a["checklist"])["pending_mandatory"]
        if not pend:
            info(self, "All mandatory documents have been received.")
            return
        text = (f"Dear Sir/Madam,\n\nRe: Valuation of {a['details'].get('security_type')} of {a['client_name']} as at "
                f"{a['details'].get('valuation_date')}\n\nTo proceed with the valuation, kindly provide the following:\n\n"
                + "\n".join(f"{i + 1}. {c['text']}" for i, c in enumerate(pend))
                + f"\n\nRegards,\n{s['valuer_name']}\n{s['firm_name']}")
        out = sto.assignment_dir(a["assignment_id"]) / "10_Correspondence" / "Pending_documents_request.txt"
        out.write_text(text, encoding="utf-8")
        sto.log(a["assignment_id"], "LETTER", out.name)
        dlg = QDialog(self); dlg.setWindowTitle("Pending documents request"); dlg.resize(650, 450)
        v = QVBoxLayout(dlg); e = QPlainTextEdit(text); v.addWidget(e)
        v.addWidget(QLabel(f"Saved to: {out}"))
        v.addWidget(hbox(button("Open file", lambda: open_path(out)), button("Close", dlg.accept)))
        dlg.exec_()

    def export(self):
        a = self.app.current()
        path, _ = QFileDialog.getSaveFileName(self, "Export checklist", f"{a['assignment_id']}_checklist.csv", "CSV (*.csv)")
        if path:
            pd.DataFrame(a["checklist"]).to_csv(path, index=False)
            info(self, f"Saved {path}")
