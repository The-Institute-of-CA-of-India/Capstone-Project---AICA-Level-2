"""Shared PyQt5 helpers and widgets."""
import os
import subprocess
import sys
from pathlib import Path

from PyQt5.QtCore import Qt, QDate, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDoubleSpinBox, QFileDialog, QHBoxLayout,
    QHeaderView, QLabel, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QWidget,
)

BIG = 1e15


def open_path(path) -> None:
    """Open a file or folder with the default Windows / macOS / Linux application."""
    path = str(path)
    if not os.path.exists(path):
        QMessageBox.warning(None, "Not found", f"Path does not exist:\n{path}")
        return
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        QMessageBox.warning(None, "Cannot open", f"Could not open:\n{path}\n\n{e}")


def set_state(label, name):
    """Change a QLabel's style class (ok / warn / banner) and re-apply the stylesheet."""
    label.setObjectName(name)
    label.style().unpolish(label)
    label.style().polish(label)


def info(parent, text, title="Information"):
    QMessageBox.information(parent, title, text)


def error(parent, text, title="Error"):
    QMessageBox.critical(parent, title, str(text))


def ask(parent, text, title="Confirm") -> bool:
    return QMessageBox.question(parent, title, text, QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes


def pick_file(parent, title, filt="All files (*.*)"):
    path, _ = QFileDialog.getOpenFileName(parent, title, "", filt)
    return path or None


def pick_files(parent, title, filt="All files (*.*)"):
    paths, _ = QFileDialog.getOpenFileNames(parent, title, "", filt)
    return paths or []


def dspin(value=0.0, dec=2, mn=-BIG, mx=BIG, step=0.1, suffix=""):
    w = QDoubleSpinBox()
    w.setDecimals(dec)
    w.setRange(mn, mx)
    w.setSingleStep(step)
    w.setValue(float(value or 0))
    w.setGroupSeparatorShown(True)
    if suffix:
        w.setSuffix(suffix)
    w.setMinimumWidth(110)
    return w


def date_edit(iso: str = ""):
    w = QDateEdit()
    w.setCalendarPopup(True)
    w.setDisplayFormat("dd-MM-yyyy")
    d = QDate.fromString(iso or "", "yyyy-MM-dd")
    w.setDate(d if d.isValid() else QDate.currentDate())
    return w


def iso(w: QDateEdit) -> str:
    return w.date().toString("yyyy-MM-dd")


def combo(items, current=None, data=None):
    """items: list of display strings; data: optional list of keys."""
    c = QComboBox()
    for i, t in enumerate(items):
        c.addItem(t, data[i] if data else t)
    if current is not None:
        idx = c.findData(current)
        if idx >= 0:
            c.setCurrentIndex(idx)
    return c


def hbox(*widgets, stretch=True):
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    for x in widgets:
        if isinstance(x, str):
            lay.addWidget(QLabel(x))
        else:
            lay.addWidget(x)
    if stretch:
        lay.addStretch(1)
    return w


def button(text, slot, primary=False, tip=""):
    b = QPushButton(text)
    b.clicked.connect(slot)
    if primary:
        b.setProperty("primary", True)
    if tip:
        b.setToolTip(tip)
    return b


def fmt(x, dec=2):
    try:
        return f"{float(x):,.{dec}f}"
    except (TypeError, ValueError):
        return "-" if x in (None, "") else str(x)


class RecordTable(QTableWidget):
    """Editable table backed by a list of dicts.
    columns: list of (key, header, kind) where kind is 'text' or 'num'."""

    def __init__(self, columns, records=None, parent=None):
        super().__init__(0, len(columns), parent)
        self.columns = columns
        self.setHorizontalHeaderLabels([c[1] for c in columns])
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setAlternatingRowColors(True)
        if records:
            self.set_records(records)

    def set_records(self, records):
        self.setRowCount(0)
        for r in records:
            self.add_row(r)

    def add_row(self, rec=None):
        rec = rec or {}
        row = self.rowCount()
        self.insertRow(row)
        for c, (key, _, kind) in enumerate(self.columns):
            v = rec.get(key, "" if kind == "text" else 0.0)
            item = QTableWidgetItem(fmt(v, 4).rstrip("0").rstrip(".") if kind == "num" and v != "" else str(v))
            if kind == "num":
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.setItem(row, c, item)

    def remove_selected(self):
        rows = sorted({i.row() for i in self.selectedIndexes()}, reverse=True)
        for r in rows:
            self.removeRow(r)

    def records(self):
        out = []
        for r in range(self.rowCount()):
            rec, empty = {}, True
            for c, (key, header, kind) in enumerate(self.columns):
                it = self.item(r, c)
                txt = (it.text() if it else "").strip()
                if txt:
                    empty = False
                if kind == "num":
                    try:
                        rec[key] = float(txt.replace(",", "")) if txt else 0.0
                    except ValueError:
                        raise ValueError(f"Row {r + 1}, column '{header}': '{txt}' is not a number")
                else:
                    rec[key] = txt
            if not empty:
                out.append(rec)
        return out


def readonly_table(headers, rows):
    t = QTableWidget(len(rows), len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setAlternatingRowColors(True)
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            t.setItem(i, j, QTableWidgetItem(str(v)))
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    return t


def fill_readonly(t: QTableWidget, headers, rows):
    t.clear()
    t.setColumnCount(len(headers))
    t.setRowCount(len(rows))
    t.setHorizontalHeaderLabels(headers)
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            t.setItem(i, j, QTableWidgetItem(str(v)))


class Worker(QThread):
    """Run a function in a background thread (keeps the window responsive)."""
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs

    def run(self):
        try:
            self.done.emit(self.fn(*self.args, **self.kwargs))
        except Exception as e:  # pragma: no cover
            self.failed.emit(str(e))


def read_bytes(path) -> bytes:
    return Path(path).read_bytes()


STYLE = """
QWidget { font-family: 'Segoe UI', Arial; font-size: 10pt; }
QListWidget#nav { background: #1f3a5f; color: white; border: none; font-size: 11pt; }
QListWidget#nav::item { padding: 10px 8px; }
QListWidget#nav::item:selected { background: #2f6db5; color: white; }
QLabel#title { font-size: 16pt; font-weight: 600; color: #1f3a5f; padding: 4px 0 8px 0; }
QLabel#banner { background: #e8f0fb; border: 1px solid #b7cde9; padding: 6px; border-radius: 4px; }
QLabel#ok { background: #e6f4ea; border: 1px solid #9ed2a9; padding: 6px; border-radius: 4px; }
QLabel#warn { background: #fff4e5; border: 1px solid #f0c27b; padding: 6px; border-radius: 4px; }
QPushButton { padding: 5px 12px; }
QPushButton[primary="true"] { background: #2f6db5; color: white; font-weight: 600; border-radius: 4px; padding: 6px 14px; }
QPushButton[primary="true"]:hover { background: #255a96; }
QGroupBox { font-weight: 600; border: 1px solid #c9d3df; border-radius: 6px; margin-top: 12px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #1f3a5f; }
"""
