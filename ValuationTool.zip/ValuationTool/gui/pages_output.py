"""Report, Audit log and Settings pages."""
import shutil
from pathlib import Path

from PyQt5.QtWidgets import (
    QCheckBox, QFileDialog, QFormLayout, QGroupBox, QLabel, QLineEdit, QPlainTextEdit, QTableWidget,
    QTreeWidget, QTreeWidgetItem, QVBoxLayout, QHeaderView,
)

from core import checklist as ck
from core import industry as ind
from core import report as rpt
from core import storage as sto
from core.config import CLIENTS_DIR, FOLDERS, TEMPLATE_DIR, load_settings, save_settings
from .base import Page
from .common import (set_state, RecordTable, ask, button, dspin, error, fill_readonly, hbox, info, open_path, pick_file)


# ============================================================================ REPORT
class ReportPage(Page):
    title = "6. Report"

    def build(self):
        g = QGroupBox("Pre-issue checks")
        v = QVBoxLayout(g)
        self.issues = QLabel(); self.issues.setWordWrap(True)
        v.addWidget(self.issues)
        self.draft = QCheckBox("Generate as DRAFT despite open issues")
        v.addWidget(self.draft)
        self.lay.addWidget(g)

        g = QGroupBox("Option 1 - Built-in report (Rule 8, Companies (Registered Valuers and Valuation) Rules, 2017)")
        v = QVBoxLayout(g)
        v.addWidget(QLabel("Cover, transmittal letter, 14 sections, Annexure A (documents), B (market evidence), "
                           "C (Rule 8 compliance matrix)."))
        v.addWidget(hbox(button("Generate built-in IBBI report", self.builtin, primary=True)))
        self.lay.addWidget(g)

        g = QGroupBox("Option 2 - Your own Word format (template with {{PLACEHOLDERS}})")
        v = QVBoxLayout(g)
        hp = rpt.placeholder_help()
        ph = QPlainTextEdit("TEXT placeholders (anywhere - body, tables, header, footer):\n"
                            + "  ".join("{{" + x + "}}" for x in hp["simple"])
                            + "\n\nBLOCK placeholders (alone on their own line - inserts tables / sections):\n"
                            + "\n".join("{{" + x + "}}" for x in hp["blocks"]))
        ph.setReadOnly(True); ph.setFixedHeight(170)
        v.addWidget(ph)
        v.addWidget(hbox(button("Save sample template as...", self.sample),
                         button("Select my template (.docx) and generate", self.custom, primary=True)))
        self.lay.addWidget(g)

        g = QGroupBox("Generated reports (09_Final_Report)")
        v = QVBoxLayout(g)
        self.files = QTableWidget(); self.files.setMinimumHeight(150)
        self.files.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.files.cellDoubleClicked.connect(self._open_row)
        v.addWidget(self.files)
        v.addWidget(hbox(button("Open selected", lambda: self._open_row(self.files.currentRow(), 0)),
                         button("Open report folder", self._open_folder)))
        v.addWidget(QLabel("Review, sign and generate the UDIN before issue."))
        self.lay.addWidget(g)
        self.lay.addStretch(1)

    def _issues(self, a):
        s = load_settings()
        out = []
        st = ck.checklist_status(a["checklist"])
        if not st["ready"]:
            out.append(f"{len(st['pending_mandatory'])} mandatory document(s) pending")
        if not a.get("market_data", {}).get("rfr", {}).get("evidence_pdf"):
            out.append("Risk-free rate has no evidence file")
        if not a.get("market_data", {}).get("ke"):
            out.append("Cost of capital not saved")
        if not a.get("industry"):
            out.append("Industry analysis not generated")
        if not a.get("valuation", {}).get("conclusion"):
            out.append("Valuation conclusion not computed")
        if s["ibbi_registration_no"].startswith("IBBI/RV/xx"):
            out.append("Valuer IBBI registration number not set (Settings page)")
        return out

    def load(self, a):
        iss = self._issues(a)
        if iss:
            self.issues.setText("<b>Open issues:</b><br>• " + "<br>• ".join(iss))
            set_state(self.issues, "warn")
        else:
            self.issues.setText("All checks passed - ready to generate the final report.")
            set_state(self.issues, "ok")
        self.draft.setVisible(bool(iss))
        folder = sto.assignment_dir(a["assignment_id"]) / "09_Final_Report"
        self._file_list = sorted(folder.glob("*.docx"), reverse=True) if folder.exists() else []
        fill_readonly(self.files, ["File"], [[p.name] for p in self._file_list])

    def _ok(self, a):
        if self._issues(a) and not self.draft.isChecked():
            error(self, "Resolve the open issues or tick 'Generate as DRAFT'.")
            return False
        return True

    def builtin(self):
        a = self.app.current()
        if not self._ok(a):
            return
        try:
            p = rpt.generate_builtin(a)
            self.load(a)
            if ask(self, f"Report generated:\n{p}\n\nOpen it now?"):
                open_path(p)
        except Exception as e:
            error(self, e)

    def sample(self):
        src = TEMPLATE_DIR / "Sample_Custom_Template.docx"
        path, _ = QFileDialog.getSaveFileName(self, "Save sample template", "Sample_Custom_Template.docx", "Word (*.docx)")
        if path:
            shutil.copy(src, path)
            open_path(path)

    def custom(self):
        a = self.app.current()
        if not self._ok(a):
            return
        p = pick_file(self, "Select your report template", "Word (*.docx)")
        if not p:
            return
        try:
            tp = sto.save_upload(a["assignment_id"], "09_Final_Report", Path(p).name, Path(p).read_bytes(), prefix="Template")
            out, unknown = rpt.fill_template(str(tp), a)
            self.load(a)
            msg = f"Report generated:\n{out}"
            if unknown:
                msg += "\n\nUnknown placeholders left unchanged: " + ", ".join(unknown)
            if ask(self, msg + "\n\nOpen it now?"):
                open_path(out)
        except Exception as e:
            error(self, e)

    def _open_row(self, r, _c):
        if r is not None and 0 <= r < len(self._file_list):
            open_path(self._file_list[r])

    def _open_folder(self):
        open_path(sto.assignment_dir(self.app.current()["assignment_id"]) / "09_Final_Report")


# ============================================================================ AUDIT
class AuditPage(Page):
    title = "Audit log & folders"

    def build(self):
        self.log = QTableWidget(); self.log.setMinimumHeight(260)
        self.log.horizontalHeader().setStretchLastSection(True)
        self.lay.addWidget(QLabel("<b>Audit trail</b> (every action with time and user)"))
        self.lay.addWidget(self.log)
        self.lay.addWidget(QLabel("<b>Folder contents</b> - double-click a file to open it"))
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Folder / file"]); self.tree.setMinimumHeight(260)
        self.tree.itemDoubleClicked.connect(lambda it, _c: it.data(0, 256) and open_path(it.data(0, 256)))
        self.lay.addWidget(self.tree)
        self.lay.addWidget(hbox(button("Open assignment folder", lambda: open_path(sto.assignment_dir(self.app.current()["assignment_id"]))),
                                button("Mark assignment as Closed", self.close_a)))

    def load(self, a):
        rows = sto.read_log(a["assignment_id"])
        fill_readonly(self.log, ["timestamp", "user", "action", "detail"],
                      [[r["timestamp"], r["user"], r["action"], r["detail"]] for r in reversed(rows)])
        self.log.resizeColumnsToContents()
        self.tree.clear()
        root = sto.assignment_dir(a["assignment_id"])
        for f in FOLDERS:
            files = sorted((root / f).glob("*")) if (root / f).exists() else []
            top = QTreeWidgetItem([f"{f}  ({len(files)})"])
            top.setData(0, 256, str(root / f))
            for p in files:
                c = QTreeWidgetItem([p.name]); c.setData(0, 256, str(p)); top.addChild(c)
            self.tree.addTopLevelItem(top)
        self.tree.expandAll()

    def close_a(self):
        a = self.app.current()
        if ask(self, "Mark this assignment as Closed?"):
            a["status"] = "Closed"
            self.app.save(a, "Assignment closed")
            self.refresh()


# ============================================================================ SETTINGS
FIRM_FIELDS = [("firm_name", "Firm name"), ("valuer_name", "Registered Valuer name"),
               ("ibbi_registration_no", "IBBI registration no."), ("rvo_name", "RVO name"),
               ("membership_no", "Membership no."), ("valuer_address", "Address"), ("valuer_email", "Email")]


class SettingsPage(Page):
    title = "Settings"
    needs_assignment = False

    def build(self):
        g = QGroupBox("Valuer / firm (appears in every report)")
        f = QFormLayout(g)
        self.firm = {}
        for k, lab in FIRM_FIELDS:
            self.firm[k] = QLineEdit(); f.addRow(lab, self.firm[k])
        self.lay.addWidget(g)

        g = QGroupBox("Default market parameters - verify periodically")
        f = QFormLayout(g)
        self.fb_rate = dspin(7.2, 4, 0, 30, 0.01, " %"); self.fb_date = QLineEdit(); self.fb_src = QLineEdit()
        self.rm = dspin(14, 2, 0, 50, 0.1, " %"); self.rm_src = QLineEdit()
        self.erp = dspin(7, 2, 0, 30, 0.1, " %"); self.erp_src = QLineEdit()
        self.tax = dspin(25.17, 2, 0, 60, 0.01, " %"); self.tg = dspin(5, 2, -5, 15, 0.25, " %")
        self.macro = QPlainTextEdit(); self.macro.setFixedHeight(110)
        for lab, w in [("Fallback risk-free rate", self.fb_rate), ("Fallback Rf date (yyyy-mm-dd)", self.fb_date),
                       ("Fallback Rf source", self.fb_src), ("Default market return Rm", self.rm), ("Rm source", self.rm_src),
                       ("Default ERP", self.erp), ("ERP source", self.erp_src), ("Default tax rate", self.tax),
                       ("Default terminal growth", self.tg), ("Macro-economic paragraph (all reports)", self.macro)]:
            f.addRow(lab, w)
        self.lay.addWidget(g)

        g = QGroupBox("Risk-free rate web sources (advanced) - first capture group of the regex must be the yield")
        v = QVBoxLayout(g)
        self.src = RecordTable([("name", "Name", "text"), ("url", "URL", "text"), ("regex", "Regex", "text")])
        self.src.setMinimumHeight(150)
        v.addWidget(self.src)
        v.addWidget(hbox(button("Add source", lambda: self.src.add_row()), button("Remove selected", self.src.remove_selected)))
        self.lay.addWidget(g)
        self.lay.addWidget(hbox(button("Save settings", self.save, primary=True),
                                button("Open Clients folder", lambda: (CLIENTS_DIR.mkdir(parents=True, exist_ok=True), open_path(CLIENTS_DIR))),
                                button("Open industry library (industries.json)", lambda: open_path(Path(ind.DATA_DIR) / "industries.json"))))
        self.lay.addStretch(1)

    def load(self, _a):
        s = load_settings()
        for k, w in self.firm.items():
            w.setText(s.get(k, ""))
        self.fb_rate.setValue(float(s["fallback_risk_free_rate"])); self.fb_date.setText(s["fallback_risk_free_rate_date"])
        self.fb_src.setText(s["fallback_risk_free_rate_source"])
        self.rm.setValue(float(s["market_return_default"])); self.rm_src.setText(s["market_return_source"])
        self.erp.setValue(float(s["equity_risk_premium"])); self.erp_src.setText(s["equity_risk_premium_source"])
        self.tax.setValue(float(s["default_tax_rate"])); self.tg.setValue(float(s["default_terminal_growth"]))
        self.macro.setPlainText(s.get("macro_overview") or ind.MACRO_DEFAULT)
        self.src.set_records(s["rfr_sources"])

    def save(self):
        s = load_settings()
        for k, w in self.firm.items():
            s[k] = w.text().strip()
        s.update({"fallback_risk_free_rate": self.fb_rate.value(), "fallback_risk_free_rate_date": self.fb_date.text().strip(),
                  "fallback_risk_free_rate_source": self.fb_src.text().strip(), "market_return_default": self.rm.value(),
                  "market_return_source": self.rm_src.text().strip(), "equity_risk_premium": self.erp.value(),
                  "equity_risk_premium_source": self.erp_src.text().strip(), "default_tax_rate": self.tax.value(),
                  "default_terminal_growth": self.tg.value(), "macro_overview": self.macro.toPlainText().strip(),
                  "rfr_sources": self.src.records()})
        save_settings(s)
        info(self, "Settings saved.")
