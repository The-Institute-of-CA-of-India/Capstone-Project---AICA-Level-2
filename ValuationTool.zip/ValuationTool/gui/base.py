"""Base class for every page in the main window."""
from PyQt5.QtWidgets import QFrame, QLabel, QScrollArea, QVBoxLayout, QWidget


class Page(QWidget):
    title = "Page"
    needs_assignment = True

    def __init__(self, app):
        super().__init__()
        self.app = app                      # MainWindow
        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 10, 14, 10)
        t = QLabel(self.title)
        t.setObjectName("title")
        outer.addWidget(t)
        self.placeholder = QLabel("Select or create an assignment on the Dashboard first.")
        self.placeholder.setObjectName("warn")
        outer.addWidget(self.placeholder)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        self.body = QWidget()
        self.lay = QVBoxLayout(self.body)
        self.lay.setContentsMargins(0, 0, 0, 0)
        scroll.setWidget(self.body)
        outer.addWidget(scroll)
        self.scroll = scroll
        self.build()

    # --- to override -------------------------------------------------------
    def build(self):
        pass

    def load(self, a):
        """Populate widgets from assignment dict `a` (None if not needed)."""
        pass

    # --- framework ---------------------------------------------------------
    def refresh(self):
        a = self.app.current()
        if self.needs_assignment and not a:
            self.placeholder.show()
            self.scroll.hide()
            return
        self.placeholder.hide()
        self.scroll.show()
        self.load(a)
