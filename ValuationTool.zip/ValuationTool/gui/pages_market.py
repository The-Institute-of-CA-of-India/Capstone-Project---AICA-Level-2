"""Market data & cost of capital page, and Industry analysis page."""
from pathlib import Path

from PyQt5.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QGroupBox, QLabel, QLineEdit, QPlainTextEdit,
    QSpinBox, QVBoxLayout,
)

from core import industry as ind
from core import market_data as mkt
from core import storage as sto
from core.config import load_settings
from .base import Page
from .common import (set_state, Worker, button, combo, date_edit, dspin, error, hbox, info, iso, open_path, pick_file)

PROOF = "05_Market_Data_Proofs"


class _RfrDialog(QDialog):
    """Small dialog to capture source / date / tenor (+ rate for manual)."""

    def __init__(self, parent, title, vdate, manual=False):
        super().__init__(parent)
        self.setWindowTitle(title)
        f = QFormLayout(self)
        self.rate = dspin(7.0, 4, 0, 30, 0.01, " %")
        self.src = QLineEdit("RBI / FBIL" if manual else "FBIL G-Sec Par Yield")
        self.ason = date_edit(vdate)
        self.tenor = dspin(10.0, 1, 0.5, 40, 0.5, " yrs")
        if manual:
            f.addRow("Rate (% p.a.)", self.rate)
        f.addRow("Source name", self.src)
        f.addRow("Data as on", self.ason)
        if not manual:
            f.addRow("Tenor to pick", self.tenor)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        f.addRow(bb)


class MarketPage(Page):
    title = "3. Market data & cost of capital"

    def build(self):
        # --- A. Risk-free rate
        g = QGroupBox("A. Risk-free rate (10-year Government of India security)")
        v = QVBoxLayout(g)
        self.rfr_lbl = QLabel(); self.rfr_lbl.setWordWrap(True)
        v.addWidget(self.rfr_lbl)
        v.addWidget(hbox(button("Auto-fetch from internet", self.fetch, primary=True,
                                tip="Downloads current 10Y G-Sec yield; saves web page + evidence PDF"),
                         button("Upload FBIL / CCIL / RBI yield file", self.from_file,
                                tip="Recommended for signed reports and past valuation dates"),
                         button("Manual rate + proof", self.manual),
                         button("Use fallback (draft only)", self.fallback),
                         button("Open evidence PDF", self.open_evidence),
                         button("Open proofs folder", self.open_proofs)))
        note = QLabel("Tip: for formal reports download the FBIL G-Sec par-yield / price file for the valuation date from "
                      "fbil.org.in and use 'Upload FBIL file'. Every method saves the source file and an evidence PDF "
                      "(URL, timestamp, SHA-256) to 05_Market_Data_Proofs.")
        note.setWordWrap(True); note.setStyleSheet("color:#555")
        v.addWidget(note)
        self.lay.addWidget(g)

        # --- B. Market return / ERP
        g = QGroupBox("B. Expected market return and equity risk premium")
        f = QFormLayout(g)
        self.idx_name = QLineEdit("Nifty 50 TRI")
        self.idx_years = QSpinBox(); self.idx_years.setRange(3, 40); self.idx_years.setValue(15)
        f.addRow("Index name", self.idx_name)
        f.addRow("Look-back (years)", self.idx_years)
        f.addRow("", button("Compute Rm from index history file (CSV / Excel)...", self.index_cagr))
        self.rm = dspin(14, 2, -50, 100, 0.1, " %")
        self.rm_src = QLineEdit()
        f.addRow("Expected market return Rm", self.rm)
        f.addRow("Rm source", self.rm_src)
        self.erp_mode = combo(["ERP = Rm - Rf", "Direct ERP (e.g. Damodaran India ERP)"])
        self.erp = dspin(7, 2, -20, 40, 0.1, " %")
        self.erp_src = QLineEdit()
        f.addRow("ERP basis", self.erp_mode)
        f.addRow("Equity risk premium", self.erp)
        f.addRow("ERP source", self.erp_src)
        self.lay.addWidget(g)

        # --- C. Beta / Ke / WACC
        g = QGroupBox("C. Beta, cost of equity and WACC")
        f = QFormLayout(g)
        self.bu = dspin(1.0, 2, 0, 5, 0.01)
        self.bsrc = QLineEdit()
        self.de = dspin(0.25, 2, 0, 20, 0.05)
        self.tax = dspin(25.17, 2, 0, 60, 0.01, " %")
        self.bl_lbl = QLabel()
        self.sp = dspin(0, 2, -10, 20, 0.25, " %")
        self.csrp = dspin(0, 2, -10, 30, 0.25, " %")
        self.csrp_reason = QLineEdit(); self.csrp_reason.setPlaceholderText("Projection risk, customer concentration, key person ...")
        self.kd = dspin(9.5, 2, 0, 40, 0.1, " %")
        self.kd_src = QLineEdit()
        self.wd = dspin(20, 2, 0, 100, 1, " %")
        self.res = QLabel(); self.res.setObjectName("banner")
        for lab, w in [("Unlevered beta", self.bu), ("Beta source", self.bsrc), ("Target D/E", self.de),
                       ("Tax rate", self.tax), ("Re-levered beta", self.bl_lbl), ("Size premium", self.sp),
                       ("Company-specific risk premium", self.csrp), ("Reason for CSRP", self.csrp_reason),
                       ("Pre-tax cost of debt Kd", self.kd), ("Kd source", self.kd_src), ("Debt / (D+E)", self.wd)]:
            f.addRow(lab, w)
        f.addRow("Result", self.res)
        f.addRow("", button("Save cost of capital", self.save, primary=True))
        self.lay.addWidget(g)
        self.lay.addStretch(1)
        for w in (self.rm, self.erp, self.bu, self.de, self.tax, self.sp, self.csrp, self.kd, self.wd):
            w.valueChanged.connect(self.recalc)
        self.erp_mode.currentIndexChanged.connect(self.recalc)
        self._worker = None

    # ------------------------------------------------------------------ load / calc
    def load(self, a):
        s = load_settings()
        md = a.get("market_data", {})
        ia = a.get("industry", {})
        self._a = a
        self.show_rfr(md.get("rfr"))
        self.rm.setValue(float(md.get("market_return", s["market_return_default"])))
        self.rm_src.setText(md.get("market_return_source", s["market_return_source"]))
        self.erp_mode.setCurrentIndex(1 if md.get("erp_mode") == "direct" else 0)
        self.erp.setValue(float(md.get("erp", s["equity_risk_premium"])))
        self.erp_src.setText(md.get("erp_source", s["equity_risk_premium_source"]))
        self.bu.setValue(float(md.get("beta_unlevered", ia.get("beta_unlevered", 1.0))))
        self.bsrc.setText(md.get("beta_source") or ia.get("beta_source", "Industry library (indicative)"))
        self.de.setValue(float(md.get("de_ratio", 0.25)))
        self.tax.setValue(float(md.get("tax_rate", s["default_tax_rate"])))
        self.sp.setValue(float(md.get("size_premium", 0)))
        self.csrp.setValue(float(md.get("csrp", 0)))
        self.csrp_reason.setText(md.get("csrp_reason", ""))
        self.kd.setValue(float(md.get("kd", 9.5)))
        self.kd_src.setText(md.get("kd_source", "Weighted average borrowing rate / MCLR + spread"))
        self.wd.setValue(float(md.get("debt_weight", 20)))
        self.recalc()

    def show_rfr(self, r):
        if r:
            ev = r.get("evidence_pdf") or "NO EVIDENCE FILE (draft only)"
            self.rfr_lbl.setText(f"<b>Rf = {r['rate']:.2f}%</b> &nbsp; Source: {r.get('source')} &nbsp; As on: "
                                 f"{r.get('as_on')} &nbsp; Method: {r.get('method')}<br>Evidence: {ev}")
            set_state(self.rfr_lbl, "ok" if r.get("evidence_pdf") else "warn")
        else:
            self.rfr_lbl.setText("Risk-free rate not yet recorded.")
            set_state(self.rfr_lbl, "warn")

    def rf(self):
        return float(self.app.current().get("market_data", {}).get("rfr", {}).get("rate", 0.0))

    def recalc(self, *_):
        rf = self.rf() if self.app.current() else 0.0
        direct = self.erp_mode.currentIndex() == 1
        self.erp.setEnabled(direct)
        if not direct:
            self.erp.blockSignals(True)
            self.erp.setValue(self.rm.value() - rf)
            self.erp.blockSignals(False)
            self.erp_src.setText(f"Rm {self.rm.value():.2f}% less Rf {rf:.2f}%")
        bl = mkt.relever_beta(self.bu.value(), self.de.value(), self.tax.value())
        self.bl_lbl.setText(f"<b>{bl:.4f}</b> &nbsp; (Bu x (1 + (1 - t) x D/E))")
        ke = mkt.cost_of_equity(rf, bl, self.erp.value(), self.sp.value(), self.csrp.value())["ke"]
        w = mkt.wacc(ke, self.kd.value(), self.tax.value(), self.wd.value())
        self.res.setText(f"Rf {rf:.2f}% + Beta {bl:.2f} x ERP {self.erp.value():.2f}% + premiums "
                         f"{self.sp.value() + self.csrp.value():.2f}% &nbsp;=&nbsp; <b>Ke {ke:.2f}%</b>"
                         f" &nbsp;|&nbsp; Post-tax Kd {w['kd_post_tax']:.2f}% &nbsp;|&nbsp; <b>WACC {w['wacc']:.2f}%</b>")
        return bl, ke, w

    def save(self, silent=False):
        a = self.app.current()
        md = a.setdefault("market_data", {})
        bl, ke, w = self.recalc()
        md.update({"market_return": self.rm.value(), "market_return_source": self.rm_src.text(),
                   "erp_mode": "direct" if self.erp_mode.currentIndex() == 1 else "rm-rf",
                   "erp": self.erp.value(), "erp_source": self.erp_src.text(),
                   "beta_unlevered": self.bu.value(), "beta_source": self.bsrc.text(), "de_ratio": self.de.value(),
                   "tax_rate": self.tax.value(), "beta_levered": round(bl, 4), "size_premium": self.sp.value(),
                   "csrp": self.csrp.value(), "csrp_reason": self.csrp_reason.text(), "ke": ke,
                   "kd": self.kd.value(), "kd_source": self.kd_src.text(), "debt_weight": self.wd.value(),
                   "wacc": w["wacc"]})
        self.app.save(a, f"Cost of capital saved Ke={ke} WACC={w['wacc']}")
        if not silent:
            info(self, f"Saved.\nCost of equity: {ke:.2f}%\nWACC: {w['wacc']:.2f}%")

    def _set_rfr(self, r, msg):
        a = self.app.current()
        a.setdefault("market_data", {})["rfr"] = r
        self.app.save(a, msg)
        self.show_rfr(r)
        self.recalc()

    # ------------------------------------------------------------------ actions
    def fetch(self):
        a = self.app.current()
        self.rfr_lbl.setText("Fetching from internet ... please wait")
        self.app.statusBar().showMessage("Fetching risk-free rate ...")
        self._worker = Worker(mkt.fetch_risk_free_rate, a["assignment_id"])
        # bound methods (not lambdas) so Qt delivers the result on the GUI thread
        self._worker.done.connect(self._fetch_ok)
        self._worker.failed.connect(self._fetch_fail)
        self._worker.start()

    def _fetch_ok(self, r):
        self.app.statusBar().clearMessage()
        self._set_rfr(r, f"RFR auto-fetched {r['rate']}")
        info(self, f"Risk-free rate {r['rate']:.2f}% recorded.\nEvidence: {r['evidence_pdf']}")

    def _fetch_fail(self, msg):
        self.app.statusBar().clearMessage()
        self.show_rfr(self.app.current().get("market_data", {}).get("rfr"))
        error(self, msg + "\n\nUse 'Upload FBIL / CCIL / RBI yield file' or 'Manual rate + proof' instead.")

    def from_file(self):
        p = pick_file(self, "Select FBIL / CCIL / RBI yield file", "Spreadsheets (*.xlsx *.xls *.csv)")
        if not p:
            return
        a = self.app.current()
        dlg = _RfrDialog(self, "Yield file details", a["details"].get("valuation_date", ""))
        if not dlg.exec_():
            return
        try:
            r = mkt.record_rfr_from_file(a["assignment_id"], Path(p).read_bytes(), Path(p).name, dlg.src.text(),
                                         iso(dlg.ason), dlg.tenor.value())
            self._set_rfr(r, f"RFR from file {r['rate']}")
            info(self, f"Rf = {r['rate']:.4f}% (tenor {r['tenor_used']} yrs, column '{r['yield_column']}').\nEvidence: {r['evidence_pdf']}")
        except Exception as e:
            error(self, e)

    def manual(self):
        a = self.app.current()
        dlg = _RfrDialog(self, "Manual risk-free rate", a["details"].get("valuation_date", ""), manual=True)
        if not dlg.exec_():
            return
        p = pick_file(self, "Select PROOF file (PDF / screenshot / Excel) - mandatory")
        if not p:
            error(self, "A proof file is mandatory for a manual rate.")
            return
        r = mkt.record_rfr_manual(a["assignment_id"], dlg.rate.value(), dlg.src.text(), iso(dlg.ason),
                                  Path(p).read_bytes(), Path(p).name)
        self._set_rfr(r, f"RFR manual {r['rate']}")

    def fallback(self):
        fb = mkt.fallback_rfr()
        self._set_rfr(fb, "RFR fallback used")
        info(self, f"Fallback {fb['rate']}% as on {fb['as_on']} applied.\nNo evidence file - use for DRAFTS only.")

    def open_evidence(self):
        a = self.app.current()
        ev = a.get("market_data", {}).get("rfr", {}).get("evidence_pdf")
        if not ev:
            error(self, "No evidence file recorded.")
            return
        open_path(sto.assignment_dir(a["assignment_id"]) / PROOF / ev)

    def open_proofs(self):
        open_path(sto.assignment_dir(self.app.current()["assignment_id"]) / PROOF)

    def index_cagr(self):
        p = pick_file(self, "Index history file (Date + Close / TRI)", "Data (*.csv *.xlsx *.xls)")
        if not p:
            return
        a = self.app.current()
        try:
            r = mkt.market_return_from_index(a["assignment_id"], Path(p).read_bytes(), Path(p).name,
                                             self.idx_name.text(), self.idx_years.value(), a["details"]["valuation_date"])
            self.rm.setValue(r["market_return"])
            self.rm_src.setText(f"CAGR of {self.idx_name.text()} {r['start']} to {r['end']} ({r['years']} yrs); "
                                f"evidence {r['evidence_pdf']}")
            self.save(silent=True)
            info(self, f"Market return (CAGR) = {r['market_return']:.2f}% over {r['years']} years.")
        except Exception as e:
            error(self, e)


# ============================================================================ INDUSTRY
class IndustryPage(Page):
    title = "4. Industry analysis"

    def build(self):
        g = QGroupBox("Select industry")
        f = QFormLayout(g)
        self.nob = QLabel(); self.nob.setWordWrap(True)
        self.sug = QLabel(); self.sug.setWordWrap(True)
        self.ind = QComboBox()
        self.ind.addItems(list(ind.load_library()))
        self.dam = QComboBox(); self.dam.setEnabled(False)
        self.dam_lbl = QLabel("Not loaded - indicative library beta will be used")
        f.addRow("Nature of business", self.nob)
        f.addRow("Suggested", self.sug)
        f.addRow("Industry", self.ind)
        f.addRow("", button("Load Damodaran beta file (optional)...", self.load_dam))
        f.addRow("Damodaran industry", self.dam)
        f.addRow("", self.dam_lbl)
        f.addRow("", button("Generate industry analysis", self.generate, primary=True))
        self.lay.addWidget(g)
        self.edit_box = QGroupBox("Review and edit (edits flow into the report). For list sections put one point per line.")
        self.edit_lay = QFormLayout(self.edit_box)
        self.lay.addWidget(self.edit_box)
        self.lay.addWidget(hbox(button("Save edits", self.save_edits, primary=True),
                                button("Export Word document to 06_Industry_Analysis", self.export)))
        self.lay.addStretch(1)
        self.editors = {}
        self._dam_df = None
        self._dam_file = None
        self.dam.currentIndexChanged.connect(self._dam_changed)

    def load(self, a):
        nob = a["details"].get("nature_of_business", "")
        self.nob.setText(nob)
        sug = ind.match_industry(nob)
        self.sug.setText(", ".join(sug[:3]) if sug else "No keyword match - select manually")
        cur = a["details"].get("industry") or (sug[0] if sug else "")
        if cur:
            self.ind.setCurrentText(cur)
        self.build_editors(a.get("industry", {}).get("sections", {}))

    def build_editors(self, sections):
        while self.edit_lay.rowCount():
            self.edit_lay.removeRow(0)
        self.editors = {}
        if not sections:
            self.edit_lay.addRow(QLabel("Not generated yet."))
            return
        for k, val in sections.items():
            e = QPlainTextEdit("\n".join(val) if isinstance(val, list) else val)
            e.setFixedHeight(110)
            self.editors[k] = (e, isinstance(val, list))
            self.edit_lay.addRow(QLabel(f"<b>{k}</b>"), e)

    def load_dam(self):
        p = pick_file(self, "Damodaran beta file (betaemerg.xls / betaIndia)", "Excel / CSV (*.xls *.xlsx *.csv)")
        if not p:
            return
        try:
            self._dam_df = ind.load_damodaran_betas(Path(p).read_bytes(), Path(p).name)
            self._dam_file = p
            self.dam.clear()
            self.dam.addItems(self._dam_df["Industry"].astype(str).tolist())
            self.dam.setEnabled(True)
        except Exception as e:
            error(self, e)

    def _dam_changed(self, *_):
        if self._dam_df is not None and self.dam.currentIndex() >= 0:
            b = float(self._dam_df.iloc[self.dam.currentIndex()]["Unlevered beta"])
            self.dam_lbl.setText(f"Unlevered beta: <b>{b:.2f}</b>")

    def generate(self):
        a = self.app.current()
        beta, src = None, ""
        if self._dam_df is not None and self.dam.currentIndex() >= 0:
            beta = float(self._dam_df.iloc[self.dam.currentIndex()]["Unlevered beta"])
            src = f"Damodaran dataset '{Path(self._dam_file).name}' - {self.dam.currentText()}"
            sto.save_upload(a["assignment_id"], PROOF, Path(self._dam_file).name, Path(self._dam_file).read_bytes(), prefix="Beta")
        name = self.ind.currentText()
        a["details"]["industry"] = name
        a["industry"] = ind.build_analysis(name, a["details"].get("nature_of_business", ""), a["client_name"], beta, src)
        md = a.setdefault("market_data", {})
        md["beta_unlevered"] = a["industry"]["beta_unlevered"]
        md["beta_source"] = a["industry"]["beta_source"]
        self.app.save(a, f"Industry analysis generated: {name}")
        self.build_editors(a["industry"]["sections"])
        info(self, f"Industry analysis generated for '{name}'.\nUnlevered beta {a['industry']['beta_unlevered']:.2f} "
                   f"copied to the Market data page.")

    def save_edits(self):
        a = self.app.current()
        if not a.get("industry"):
            error(self, "Generate the analysis first.")
            return
        for k, (e, is_list) in self.editors.items():
            t = e.toPlainText()
            a["industry"]["sections"][k] = [x.strip() for x in t.split("\n") if x.strip()] if is_list else t
        self.app.save(a, "Industry analysis edited")
        info(self, "Saved.")

    def export(self):
        a = self.app.current()
        if not a.get("industry"):
            error(self, "Generate the analysis first.")
            return
        self.save_edits()
        n = ind.save_analysis_docx(a["assignment_id"], a["industry"])
        open_path(sto.assignment_dir(a["assignment_id"]) / "06_Industry_Analysis" / n)
