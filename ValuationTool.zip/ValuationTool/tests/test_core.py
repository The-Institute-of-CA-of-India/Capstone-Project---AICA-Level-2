"""Run: python -m pytest tests  (or python tests/test_core.py)"""
import io, os, re, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("VAL_CLIENTS_DIR", tempfile.mkdtemp())

import numpy as np, pandas as pd
from docx import Document
from core import storage, checklist, market_data as m, valuation as v, industry, report
from core.config import load_settings


def test_end_to_end():
    a = storage.create_assignment("Demo Auto Parts Pvt Ltd", {
        "purpose": "FEMA", "security_type": "Unlisted equity shares", "valuation_date": "2026-09-30",
        "nature_of_business": "Manufacturer of auto component forgings for two wheeler OEMs",
        "shares_outstanding": 1000000, "face_value": 10, "currency_unit": "INR lakhs", "cin": "U12345MH2010PTC000000",
        "appointing_authority": "Board of Directors"})
    a["checklist"] = checklist.build_checklist("FEMA", "Unlisted equity shares")
    for c in a["checklist"][:5]:
        c["received"] = True
    st = checklist.checklist_status(a["checklist"])
    assert st["mandatory"] > 5 and not st["ready"]

    # risk-free from a FBIL-like par yield file
    df = pd.DataFrame({"Tenor (Years)": [1, 5, 9.5, 10, 15], "Par Yield (Semi-Annual)": [6.0, 6.9, 7.1, 7.2, 7.4],
                       "Par Yield (Annualized)": [6.09, 7.02, 7.23, 7.33, 7.54]})
    buf = io.BytesIO(); df.to_excel(buf, index=False)
    r = m.record_rfr_from_file(a["assignment_id"], buf.getvalue(), "FBIL_par_yield.xlsx", "FBIL", "2026-09-30")
    assert abs(r["rate"] - 7.33) < 1e-9 and r["evidence_pdf"].endswith(".pdf")
    a["market_data"]["rfr"] = r

    # market return from synthetic index (12% CAGR)
    dates = pd.date_range("2008-01-01", "2026-09-30", freq="B")
    yrs = (dates - dates[0]).days / 365.25
    idx = pd.DataFrame({"Date": dates.strftime("%d-%m-%Y"), "Close": 1000 * 1.12 ** yrs})
    mr = m.market_return_from_index(a["assignment_id"], idx.to_csv(index=False).encode(), "nifty.csv", "Nifty 50 TRI", 15, "2026-09-30")
    assert abs(mr["market_return"] - 12.0) < 0.05, mr

    bl = m.relever_beta(0.9, 0.5, 25)
    assert abs(bl - 0.9 * (1 + 0.75 * 0.5)) < 1e-12
    ke = m.cost_of_equity(7.33, bl, 12 - 7.33, 1, 2)["ke"]
    w = m.wacc(ke, 9.5, 25, 20)["wacc"]
    a["market_data"].update({"market_return": 12.0, "erp": 4.67, "beta_unlevered": 0.9, "de_ratio": 0.5, "beta_levered": bl,
                             "tax_rate": 25, "ke": ke, "kd": 9.5, "debt_weight": 20, "wacc": w})

    # industry
    sug = industry.match_industry(a["details"]["nature_of_business"])
    assert sug[0].startswith("Automobile"), sug
    a["industry"] = industry.build_analysis(sug[0], a["details"]["nature_of_business"], a["client_name"])
    industry.save_analysis_docx(a["assignment_id"], a["industry"])

    # DCF check against manual calc (end-year, no stub)
    yrs_ = [{"label": "Y1", "ebitda": 110, "dep": 10, "tax_rate": 25, "capex": 10, "delta_nwc": 0}] * 2
    r = v.dcf(yrs_, 10, 0, mid_year=False, shares=1)
    fcf = 100 * 0.75 + 10 - 10
    exp = fcf / 1.1 + fcf / 1.21 + (fcf / 0.10) / 1.21
    assert abs(r["equity_value"] - exp) < 1e-6
    assert abs(exp - fcf / 0.10) < 1e-6  # zero growth perpetuity identity

    proj = [{"label": f"FY{27+i}", "ebitda": 500 * 1.12 ** i, "dep": 50, "interest": 20, "tax_rate": 25.17,
             "capex": 70, "delta_nwc": 25, "net_borrowing": 0} for i in range(5)]
    a["valuation"]["dcf"] = v.dcf(proj, w, 5, net_debt=300, shares=1000000, unit_mult=1e5)
    a["valuation"]["dcf_sensitivity"] = v.dcf_sensitivity(proj, w, 5, net_debt=300, shares=1000000, unit_mult=1e5)
    a["valuation"]["nav"] = v.nav([{"item": "PPE", "book": 1500, "fair": 1900}, {"item": "Current assets", "book": 800}],
                                  [{"item": "Borrowings", "book": 400}, {"item": "Current liabilities", "book": 300}], 1000000, 1e5)
    a["valuation"]["market"] = v.market_multiple([{"name": "A", "multiple": 12}, {"name": "B", "multiple": 15}, {"name": "C", "multiple": 10}],
                                                 500, "EV/EBITDA", 300, 1000000, "median", 20, 1e5)
    assert abs(a["valuation"]["market"]["applied_multiple"] - 9.6) < 1e-9
    a["valuation"]["rule11ua"] = v.rule_11ua_nav(2300, 700, 100, 10)   # lakhs; PE = 10 lakh shares x Rs 10
    assert a["valuation"]["rule11ua"]["value_per_share"] == 160
    assert abs(a["valuation"]["nav"]["value_per_share"] - 200) < 1e-9
    methods = {"DCF (FCFF)": a["valuation"]["dcf"]["value_per_share"], "Net Asset Value": a["valuation"]["nav"]["value_per_share"],
               "Comparable companies (EV/EBITDA)": a["valuation"]["market"]["value_per_share"]}
    a["valuation"]["conclusion"] = v.conclude(methods, {"DCF (FCFF)": 60, "Net Asset Value": 20, "Comparable companies (EV/EBITDA)": 20}, dlom_pct=10)

    # bond: coupon = yield -> par
    b = v.debt_instrument(100, 8, 5, 2, 8)
    assert abs(b["value_per_unit"] - 100) < 1e-9

    # VWAP
    pdates = pd.bdate_range(end="2026-09-29", periods=120)
    pdf = pd.DataFrame({"Date": pdates.strftime("%d-%b-%Y"), "No. of Shares": 1000, "Close Price": np.linspace(100, 160, 120)})
    pdf["Total Turnover"] = pdf["No. of Shares"] * pdf["Close Price"]
    vw = m.vwap_pricing(pdf.to_csv(index=False).encode(), "p.csv", "2026-09-30")
    assert vw["days_90"] == 90 and vw["floor_price"] == vw["vwap_10"]

    storage.save_assignment(a)
    p = report.generate_builtin(a)
    txt = "\n".join(x.text for x in Document(p).paragraphs)
    assert "Annexure C" in txt and "Demo Auto Parts" in txt

    # custom template
    t = Document()
    t.add_paragraph("Valuation of {{CLIENT_NAME}} as on {{VALUATION_DATE}}; Rf {{RISK_FREE_RATE}} {{FOO}}")
    t.add_paragraph("{{MARKET_DATA_TABLE}}")
    t.add_paragraph("Final: {{FINAL_VALUE_PER_SHARE}}")
    tp = Path(os.environ["VAL_CLIENTS_DIR"]) / "t.docx"; t.save(tp)
    out, unknown = report.fill_template(str(tp), a)
    d2 = Document(out)
    body = "\n".join(x.text for x in d2.paragraphs)
    assert "Demo Auto Parts" in body and "7.33%" in body and unknown == ["FOO"] and len(d2.tables) == 1
    assert "{{MARKET_DATA_TABLE}}" not in body
    print("Report:", p)
    print("Value/share:", a["valuation"]["conclusion"])
    return a, p, out


def test_rfr_regexes():
    s = load_settings()["rfr_sources"]
    samples = ["India's 10 year G-Sec yield today is 7.04% as of 22 Sep, 2026",
               "India 10-year G-Sec yield is 7.21% today.", "India 10-Year G-Sec Yield 7.12% +0.00%"]
    for src, txt in zip(s, samples):
        mm = re.search(src["regex"], txt, flags=re.I)
        assert mm, src["name"]


def test_fmt():
    assert report.fmt_in(12345678.9) == "1,23,45,678.90"
    assert report.fmt_in(999) == "999.00"


if __name__ == "__main__":
    test_rfr_regexes(); test_fmt(); test_end_to_end(); print("ALL TESTS PASSED")
