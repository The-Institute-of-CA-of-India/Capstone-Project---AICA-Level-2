"""Valuation Assignment Tool - desktop GUI (PyQt5).

Run:  python gui_app.py        (or double-click RUN_ValuationTool.bat)
"""
import sys
import traceback
from datetime import datetime
from pathlib import Path

try:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (QApplication, QHBoxLayout, QLabel, QLineEdit, QListWidget, QMainWindow,
                                 QMessageBox, QSizePolicy, QStackedWidget, QToolBar, QWidget)
except ImportError:  # friendly message when libraries are missing
    print("\nPyQt5 is not installed. Run INSTALL_Requirements.bat (Windows) or:\n"
          "    pip install -r requirements.txt\n")
    input("Press Enter to exit...") if sys.stdin and sys.stdin.isatty() else None
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core import storage as sto                                # noqa: E402
from core.config import BASE_DIR, load_settings                 # noqa: E402
from gui.common import STYLE                                    # noqa: E402
from gui.pages_market import IndustryPage, MarketPage           # noqa: E402
from gui.pages_output import AuditPage, ReportPage, SettingsPage  # noqa: E402
from gui.pages_setup import ChecklistPage, DashboardPage, EngagementPage  # noqa: E402
from gui.pages_valuation import ValuationPage                   # noqa: E402

APP_NAME = "Valuation Assignment Tool"
PAGES = [DashboardPage, EngagementPage, ChecklistPage, MarketPage, IndustryPage, ValuationPage, ReportPage,
         AuditPage, SettingsPage]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.aid = None
        self.setWindowTitle(APP_NAME)
        self.resize(1320, 860)

        tb = QToolBar("Main")
        tb.setMovable(False)
        self.addToolBar(tb)
        self.cur_lbl = QLabel("  No assignment selected  ")
        self.cur_lbl.setStyleSheet("font-weight:600; color:#1f3a5f;")
        tb.addWidget(self.cur_lbl)
        spacer = QWidget(); spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)
        tb.addWidget(QLabel("User (audit trail): "))
        self.user = QLineEdit(); self.user.setFixedWidth(180)
        tb.addWidget(self.user)

        central = QWidget()
        lay = QHBoxLayout(central)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.nav = QListWidget(); self.nav.setObjectName("nav"); self.nav.setFixedWidth(250)
        self.stack = QStackedWidget()
        self.pages = []
        for cls in PAGES:
            p = cls(self)
            self.pages.append(p)
            self.stack.addWidget(p)
            self.nav.addItem(cls.title)
        self.nav.currentRowChanged.connect(self._switch)
        lay.addWidget(self.nav)
        lay.addWidget(self.stack, 1)
        self.setCentralWidget(central)
        self.statusBar().showMessage(f"Data folder: {sto.assignment_dir('').parent}")
        self.nav.setCurrentRow(0)

        if load_settings()["ibbi_registration_no"].startswith("IBBI/RV/xx"):
            self.statusBar().showMessage("First run: enter your firm and IBBI details on the Settings page.")

    # ---------------------------------------------------------------- API used by pages
    def current(self):
        if not self.aid:
            return None
        try:
            return sto.load_assignment(self.aid)
        except FileNotFoundError:
            self.aid = None
            return None

    def save(self, a, msg=None):
        sto.save_assignment(a)
        if msg:
            sto.log(a["assignment_id"], "UPDATE", msg, self.user.text().strip())
        self.cur_lbl.setText(f"  Assignment: {a['client_name']}  [{a['assignment_id']}]  ")
        self.statusBar().showMessage(f"Saved {datetime.now():%H:%M:%S} - {msg or ''}", 6000)

    def set_assignment(self, aid):
        self.aid = aid
        a = self.current()
        self.cur_lbl.setText(f"  Assignment: {a['client_name']}  [{aid}]  " if a else "  No assignment selected  ")

    def go(self, idx):
        self.nav.setCurrentRow(idx)

    def _switch(self, idx):
        self.stack.setCurrentIndex(idx)
        try:
            self.pages[idx].refresh()
        except Exception as e:  # never crash the app on a page refresh
            _show_error(type(e), e, e.__traceback__)


def _show_error(etype, value, tb):
    text = "".join(traceback.format_exception(etype, value, tb))
    try:
        with open(BASE_DIR / "error_log.txt", "a", encoding="utf-8") as f:
            f.write(f"\n==== {datetime.now()} ====\n{text}")
    except Exception:
        pass
    QMessageBox.critical(None, "Unexpected error",
                         f"{value}\n\nDetails were written to error_log.txt in the tool folder.")


def main():
    if hasattr(Qt, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    sys.excepthook = _show_error
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
