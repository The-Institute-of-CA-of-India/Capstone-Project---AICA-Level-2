@echo off
rem OPTIONAL: builds a stand-alone ValuationTool.exe so staff PCs do NOT need
rem Python or any library. Run once on your PC; then copy the folder
rem dist\ValuationTool\ to any Windows PC and double-click ValuationTool.exe.
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call "%~dp0INSTALL_Requirements.bat" /silent || exit /b 1
set "VPY=.venv\Scripts\python.exe"
echo Installing PyInstaller ...
"%VPY%" -m pip install --upgrade pyinstaller -q || ( echo PyInstaller install failed & pause & exit /b 1 )
echo Building - this takes 2-5 minutes ...
"%VPY%" -m PyInstaller --noconfirm --clean --windowed --name ValuationTool ^
  --add-data "data;data" --add-data "templates;templates" ^
  --collect-data docx --collect-data reportlab ^
  --hidden-import openpyxl --hidden-import xlrd ^
  --exclude-module streamlit --exclude-module matplotlib --exclude-module tkinter ^
  gui_app.py
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
echo.
echo ===============================================================
echo  Built: dist\ValuationTool\ValuationTool.exe
echo  Copy the whole dist\ValuationTool folder to staff PCs.
echo  Client folders will be created in dist\ValuationTool\Clients
echo  (or set the VAL_CLIENTS_DIR environment variable to a shared drive).
echo ===============================================================
pause
