"""Valuation engines (pure functions - no UI, fully testable).

Approaches per ICAI Valuation Standard 103 / IVS 105:
  Income  : DCF - FCFF (discount at WACC) and FCFE (discount at Ke)
  Asset   : Book / Adjusted NAV, Rule 11UA(1)(c)(a) NAV
  Market  : Comparable company multiples, listed price (VWAP in market_data)
  Debt    : Bond / NCD / preference share - PV of contractual cash flows
"""
from statistics import mean, median

# Amounts entered in thousands / lakhs / crores must be converted to rupees
# before dividing by the number of shares.
UNIT_MULTIPLIER = {"INR": 1.0, "INR thousands": 1e3, "INR lakhs": 1e5, "INR crores": 1e7}


def unit_mult(unit: str) -> float:
    return UNIT_MULTIPLIER.get(unit or "INR", 1.0)


def _disc_factor(rate_pct: float, period: float) -> float:
    return 1 / ((1 + rate_pct / 100) ** period)


def dcf(years: list, discount_rate: float, terminal_growth: float, mode: str = "FCFF",
        mid_year: bool = True, net_debt: float = 0.0, non_operating_assets: float = 0.0,
        shares: float = 1.0, first_period_fraction: float = 1.0, unit_mult: float = 1.0) -> dict:
    """years: list of dicts with keys
         label, ebitda, dep, interest (FCFE only), tax_rate, capex, delta_nwc, net_borrowing (FCFE only)
       FCFF = EBIT x (1-t) + Dep - Capex - dNWC
       FCFE = (EBIT - Interest) x (1-t) + Dep - Capex - dNWC + Net borrowing
       first_period_fraction: stub period (e.g. 0.5 if valuation date is mid-year)."""
    if discount_rate <= terminal_growth:
        raise ValueError("Discount rate must exceed terminal growth rate.")
    rows, pv_total, t_end = [], 0.0, 0.0
    for i, y in enumerate(years):
        frac = first_period_fraction if i == 0 else 1.0
        ebit = y["ebitda"] - y["dep"]
        interest = y.get("interest", 0.0) if mode == "FCFE" else 0.0
        tax = max(ebit - interest, 0) * y["tax_rate"] / 100
        cf = (ebit - interest - tax) + y["dep"] - y["capex"] - y["delta_nwc"]
        if mode == "FCFE":
            cf += y.get("net_borrowing", 0.0)
        cf_period = cf * frac
        period = t_end + (frac / 2 if mid_year else frac)
        t_end += frac
        df = _disc_factor(discount_rate, period)
        pv = cf_period * df
        pv_total += pv
        rows.append({"label": y["label"], "ebitda": y["ebitda"], "ebit": ebit, "tax": tax,
                     "cash_flow": cf_period, "period": round(period, 4), "df": round(df, 6), "pv": pv})
    last_cf = rows[-1]["cash_flow"] / (first_period_fraction if len(rows) == 1 else 1.0)
    tv = last_cf * (1 + terminal_growth / 100) / ((discount_rate - terminal_growth) / 100)
    tv_period = t_end - 0.5 if mid_year else t_end   # Gordon TV: same convention as final cash flow
    pv_tv = tv * _disc_factor(discount_rate, tv_period)
    ev = pv_total + pv_tv
    if mode == "FCFF":
        equity = ev - net_debt + non_operating_assets
    else:
        equity = ev + non_operating_assets
    return {"mode": mode, "rows": rows, "sum_pv": pv_total, "terminal_value": tv, "pv_tv": pv_tv,
            "tv_share_pct": pv_tv / ev * 100 if ev else 0, "enterprise_or_equity_value": ev,
            "net_debt": net_debt if mode == "FCFF" else 0.0, "non_operating_assets": non_operating_assets,
            "equity_value": equity, "shares": shares, "value_per_share": equity * unit_mult / shares,
            "unit_mult": unit_mult, "discount_rate": discount_rate, "terminal_growth": terminal_growth, "mid_year": mid_year}


def dcf_sensitivity(years, discount_rate, terminal_growth, steps=(-1, -0.5, 0, 0.5, 1), **kw) -> dict:
    grid = {}
    for dr in steps:
        row = {}
        for g in steps:
            r, gg = discount_rate + dr, terminal_growth + g
            try:
                row[f"{gg:.2f}%"] = dcf(years, r, gg, **kw)["value_per_share"]
            except ValueError:
                row[f"{gg:.2f}%"] = None
        grid[f"{r:.2f}%"] = row
    return grid


def nav(assets: list, liabilities: list, shares: float, unit_mult: float = 1.0) -> dict:
    """assets/liabilities: list of dicts {item, book, fair} (fair optional)."""
    ab = sum(a["book"] for a in assets)
    af = sum(a.get("fair", a["book"]) for a in assets)
    lb = sum(l["book"] for l in liabilities)
    lf = sum(l.get("fair", l["book"]) for l in liabilities)
    return {"book_nav": ab - lb, "adjusted_nav": af - lf, "shares": shares,
            "book_nav_per_share": (ab - lb) * unit_mult / shares, "value_per_share": (af - lf) * unit_mult / shares,
            "assets": assets, "liabilities": liabilities}


def rule_11ua_nav(A: float, L: float, PE: float, PV: float) -> dict:
    """Rule 11UA(1)(c)(a), Income-tax Rules: FMV of unquoted equity share = (A - L) x PV / PE
    A  = book value of all assets less income-tax paid (net of refund) and unamortised
         deferred expenditure not representing an asset
    L  = book value of liabilities EXCLUDING paid-up equity, reserves & surplus (other than for
         depreciation), provision for tax (excess over tax payable), unascertained provisions,
         proposed dividend not declared, contingent liabilities (other than arrears of preference dividend)
    PE = total paid-up equity capital, PV = paid-up value of the equity share
    NOTE: Rule 11UA(1)(c)(b) adds fair value adjustments for jewellery, art, shares/securities and
    immovable property - include those adjustments in A. Verify against the rule as amended."""
    fmv = (A - L) * PV / PE
    return {"A": A, "L": L, "PE": PE, "PV": PV, "value_per_share": fmv,
            "formula": "(A - L) x (PV / PE)"}


def market_multiple(peers: list, subject_metric: float, multiple_type: str, net_debt: float,
                    shares: float, statistic: str = "median", discount_pct: float = 0.0,
                    unit_mult: float = 1.0) -> dict:
    """peers: list of {name, multiple}. multiple_type: 'EV/EBITDA', 'EV/Revenue', 'P/E', 'P/BV'."""
    vals = [p["multiple"] for p in peers if p.get("multiple") not in (None, 0)]
    if not vals:
        raise ValueError("No valid peer multiples.")
    m = median(vals) if statistic == "median" else mean(vals)
    m_adj = m * (1 - discount_pct / 100)
    implied = subject_metric * m_adj
    equity = implied - net_debt if multiple_type.startswith("EV") else implied
    return {"multiple_type": multiple_type, "peers": peers, "statistic": statistic,
            "peer_multiple": m, "discount_pct": discount_pct, "applied_multiple": m_adj,
            "subject_metric": subject_metric, "implied_value": implied, "net_debt": net_debt if multiple_type.startswith("EV") else 0,
            "equity_value": equity, "shares": shares, "value_per_share": equity * unit_mult / shares,
            "min": min(vals), "max": max(vals)}


def debt_instrument(face_value: float, coupon_pct: float, years_to_maturity: float, freq: int,
                    yield_pct: float, redemption_premium_pct: float = 0.0) -> dict:
    """PV of coupons + redemption at the required yield (risk-free + credit spread)."""
    n = int(round(years_to_maturity * freq))
    c = face_value * coupon_pct / 100 / freq
    r = yield_pct / 100 / freq
    flows = []
    pv = 0.0
    for k in range(1, n + 1):
        cf = c + (face_value * (1 + redemption_premium_pct / 100) if k == n else 0)
        d = 1 / (1 + r) ** k
        pv += cf * d
        flows.append({"period": k, "cash_flow": cf, "df": d, "pv": cf * d})
    return {"value_per_unit": pv, "flows": flows, "yield_pct": yield_pct, "coupon_pct": coupon_pct,
            "face_value": face_value}


def conclude(method_values: dict, weights: dict, dlom_pct: float = 0.0, dloc_pct: float = 0.0) -> dict:
    """method_values: {method: value_per_share}; weights in % (must total 100)."""
    tw = sum(weights.get(m, 0) for m in method_values)
    if abs(tw - 100) > 0.01:
        raise ValueError(f"Weights total {tw}%, must be 100%.")
    weighted = sum(method_values[m] * weights.get(m, 0) / 100 for m in method_values)
    after = weighted * (1 - dloc_pct / 100) * (1 - dlom_pct / 100)
    return {"method_values": method_values, "weights": weights, "weighted_value": weighted,
            "dloc_pct": dloc_pct, "dlom_pct": dlom_pct, "final_value_per_share": after}
