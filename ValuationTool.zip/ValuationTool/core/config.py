"""Central configuration for the Valuation Assignment Tool.

Edit the values in data/settings.json (created on first run) rather than this
file, so firm-specific defaults survive upgrades.
"""
import json
import os
from pathlib import Path

import shutil
import sys

if getattr(sys, "frozen", False):
    # Running as a PyInstaller-built .exe: writable files live next to the .exe,
    # bundled read-only resources live in sys._MEIPASS.
    BASE_DIR = Path(sys.executable).resolve().parent
    _RES_DIR = Path(getattr(sys, "_MEIPASS", BASE_DIR))
    for _sub in ("data", "templates"):
        if not (BASE_DIR / _sub).exists() and (_RES_DIR / _sub).exists():
            shutil.copytree(_RES_DIR / _sub, BASE_DIR / _sub)
else:
    BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
TEMPLATE_DIR = BASE_DIR / "templates"
CLIENTS_DIR = Path(os.environ.get("VAL_CLIENTS_DIR", BASE_DIR / "Clients"))
SETTINGS_FILE = DATA_DIR / "settings.json"

# Standard folder structure created for every assignment
FOLDERS = [
    "01_Engagement_and_Independence",
    "02_Financial_Statements",
    "03_Projections_and_Business_Plan",
    "04_Legal_and_Secretarial",
    "05_Market_Data_Proofs",
    "06_Industry_Analysis",
    "07_Valuation_Workings",
    "08_Management_Representations",
    "09_Final_Report",
    "10_Correspondence",
]

DEFAULT_SETTINGS = {
    "firm_name": "Your Firm Name",
    "valuer_name": "Registered Valuer Name",
    "ibbi_registration_no": "IBBI/RV/xx/20xx/xxxxx",
    "rvo_name": "Registered Valuers Organisation name",
    "membership_no": "",
    "valuer_address": "",
    "valuer_email": "",
    # Fallback market parameters - ALWAYS verify and update before use.
    "fallback_risk_free_rate": 7.20,
    "fallback_risk_free_rate_date": "2026-11-23",
    "fallback_risk_free_rate_source": "10-year benchmark G-Sec closing yield as reported in financial press (Business Standard, 23-Nov-2026) - verify with FBIL/CCIL",
    "equity_risk_premium": 7.00,
    "equity_risk_premium_source": "Firm policy: long-term Indian ERP (cross-check with Damodaran country ERP for India / index CAGR study)",
    "market_return_default": 14.00,
    "market_return_source": "Firm policy: long-term Nifty 50 TRI / BSE Sensex CAGR - recompute from uploaded index file",
    "default_tax_rate": 25.17,
    "default_terminal_growth": 5.0,
    # Online sources tried in order for the risk free rate. Each has a URL and a
    # regex whose first group captures the yield. Edit if a website changes.
    "rfr_sources": [
        {
            "name": "indiamacroindicators.co.in - 10Y G-Sec",
            "url": "https://indiamacroindicators.co.in/economic-indicators/10y-g-sec-yield",
            "regex": r"10[ -]year G-Sec yield (?:today )?is\s*([0-9]+\.[0-9]+)\s*%"
        },
        {
            "name": "capera.co - India 10-year G-Sec",
            "url": "https://capera.co/data/India/yields/10-year",
            "regex": r"10-year G-Sec yield is\s*([0-9]+\.[0-9]+)\s*%"
        },
        {
            "name": "dealplexus.com - India 10Y G-Sec",
            "url": "https://www.dealplexus.com/markets/india-10-year-gsec-yield",
            "regex": r"India 10-Year G-Sec Yield(?:\s|<[^>]*>)*([0-9]+\.[0-9]+)\s*%"
        }
    ]
}


def load_settings() -> dict:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not SETTINGS_FILE.exists():
        save_settings(DEFAULT_SETTINGS)
        return dict(DEFAULT_SETTINGS)
    with open(SETTINGS_FILE, encoding="utf-8") as f:
        data = json.load(f)
    merged = dict(DEFAULT_SETTINGS)
    merged.update(data)
    return merged


def save_settings(settings: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)
