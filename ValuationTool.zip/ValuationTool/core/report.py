"""Report generation.

1. Built-in report structured on Rule 8 of the Companies (Registered Valuers and
   Valuation) Rules, 2017 (IBBI) and ICAI Valuation Standard 202 (Reporting).
   A compliance matrix mapping every Rule 8 clause to the report section is
   included as an annexure.
2. Custom template: upload your own .docx containing {{PLACEHOLDERS}}; the tool
   fills them. Block placeholders (alone on a paragraph) insert tables/sections.
"""
import re
from datetime import datetime

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor, Cm

from .checklist import PURPOSES
from .config import load_settings
from .storage import assignment_dir, log


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def fmt_in(x, dec=2):
    """Indian digit grouping: 12,34,567.89"""
    if x is None or x == "":
        return "-"
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    neg = x < 0
    s = f"{abs(x):.{dec}f}"
    whole, _, frac = s.partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        head = ",".join(re.findall(r"\d{1,2}", head[::-1]))[::-1]
        whole = head + "," + tail
    out = whole + ("." + frac if frac else "")
    return ("-" if neg else "") + out


def _d(a: dict, *keys, default="-"):
    cur = a
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur if cur not in (None, "") else default


def _table(doc, header, rows, widths=None):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Light Grid Accent 1"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        t.rows[0].cells[i].text = str(h)
        for r in t.rows[0].cells[i].paragraphs[0].runs:
            r.bold = True
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = str(v)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    return t


# --------------------------------------------------------------------------- #
# Context (simple placeholders)
# --------------------------------------------------------------------------- #
def build_context(a: dict) -> dict:
    s = load_settings()
    d = a.get("details", {})
    md = a.get("market_data", {})
    v = a.get("valuation", {})
    concl = v.get("conclusion", {})
    unit = d.get("currency_unit", "INR")
    return {
        "CLIENT_NAME": a.get("client_name", ""),
        "CIN": d.get("cin", ""), "PAN": d.get("pan", ""),
        "REGISTERED_OFFICE": d.get("registered_office", ""),
        "NATURE_OF_BUSINESS": d.get("nature_of_business", ""),
        "INDUSTRY": d.get("industry", ""),
        "PURPOSE": PURPOSES.get(d.get("purpose", ""), d.get("purpose", "")),
        "SECURITY_TYPE": d.get("security_type", ""),
        "VALUATION_DATE": d.get("valuation_date", ""),
        "APPOINTMENT_DATE": d.get("appointment_date", ""),
        "REPORT_DATE": d.get("report_date", datetime.now().strftime("%Y-%m-%d")),
        "APPOINTING_AUTHORITY": d.get("appointing_authority", ""),
        "BASIS_OF_VALUE": d.get("basis_of_value", "Fair Value"),
        "PREMISE_OF_VALUE": d.get("premise_of_value", "Going Concern"),
        "CURRENCY_UNIT": unit,
        "SHARES_OUTSTANDING": fmt_in(d.get("shares_outstanding"), 0),
        "FACE_VALUE": fmt_in(d.get("face_value")),
        "FIRM_NAME": s["firm_name"], "VALUER_NAME": s["valuer_name"],
        "IBBI_REG_NO": s["ibbi_registration_no"], "RVO_NAME": s["rvo_name"],
        "VALUER_ADDRESS": s.get("valuer_address", ""), "VALUER_EMAIL": s.get("valuer_email", ""),
        "RISK_FREE_RATE": f"{_d(md, 'rfr', 'rate', default=0):.2f}%" if md.get("rfr") else "-",
        "RFR_SOURCE": _d(md, "rfr", "source"), "RFR_AS_ON": _d(md, "rfr", "as_on"),
        "MARKET_RETURN": f"{md.get('market_return', 0):.2f}%" if md.get("market_return") else "-",
        "ERP": f"{md.get('erp', 0):.2f}%" if md.get("erp") is not None else "-",
        "BETA": f"{md.get('beta_levered', 0):.2f}" if md.get("beta_levered") else "-",
        "COST_OF_EQUITY": f"{md.get('ke', 0):.2f}%" if md.get("ke") else "-",
        "WACC": f"{md.get('wacc', 0):.2f}%" if md.get("wacc") else "-",
        "FINAL_VALUE_PER_SHARE": fmt_in(concl.get("final_value_per_share")),
        "FINAL_VALUE_TOTAL": fmt_in((concl.get("final_value_per_share") or 0) * float(d.get("shares_outstanding") or 0)),
    }


# --------------------------------------------------------------------------- #
# Block renderers (used by both built-in and custom template)
# --------------------------------------------------------------------------- #
def blk_industry(doc, a):
    ind = a.get("industry", {})
    if not ind:
        doc.add_paragraph("[Industry analysis not generated]")
        return
    for title, body in ind.get("sections", {}).items():
        doc.add_paragraph().add_run(title).bold = True
        if isinstance(body, list):
            for b in body:
                doc.add_paragraph(b, style="List Bullet")
        else:
            doc.add_paragraph(body)


def blk_market_data(doc, a):
    md = a.get("market_data", {})
    rfr = md.get("rfr", {})
    rows = [
        ["Risk-free rate (Rf)", f"{rfr.get('rate', 0):.2f}%" if rfr else "-",
         f"{rfr.get('source', '-')}; as on {rfr.get('as_on', '-')}; evidence: {rfr.get('evidence_pdf') or 'n/a'}"],
        ["Expected market return (Rm)", f"{md.get('market_return', 0):.2f}%" if md.get("market_return") else "-", md.get("market_return_source", "-")],
        ["Equity risk premium (Rm - Rf)", f"{md.get('erp', 0):.2f}%", md.get("erp_source", "-")],
        ["Unlevered beta", f"{md.get('beta_unlevered', 0):.2f}", md.get("beta_source", "-")],
        ["Target D/E", f"{md.get('de_ratio', 0):.2f}", "Industry / company target capital structure"],
        ["Re-levered beta", f"{md.get('beta_levered', 0):.2f}", "Hamada: Bu x (1 + (1 - t) x D/E)"],
        ["Size premium", f"{md.get('size_premium', 0):.2f}%", "Valuer judgement"],
        ["Company-specific risk premium", f"{md.get('csrp', 0):.2f}%", md.get("csrp_reason", "Valuer judgement")],
        ["Cost of equity (Ke)", f"{md.get('ke', 0):.2f}%", "CAPM: Rf + Beta x ERP + premiums"],
        ["Pre-tax cost of debt (Kd)", f"{md.get('kd', 0):.2f}%", md.get("kd_source", "-")],
        ["Tax rate", f"{md.get('tax_rate', 0):.2f}%", "Applicable corporate tax rate"],
        ["Debt / (Debt + Equity)", f"{md.get('debt_weight', 0):.2f}%", "Target capital structure"],
        ["WACC", f"{md.get('wacc', 0):.2f}%", "Ke x We + Kd x (1 - t) x Wd"],
    ]
    _table(doc, ["Parameter", "Value", "Source / basis"], rows, [5, 2.5, 9])


def blk_valuation(doc, a):
    v = a.get("valuation", {})
    unit = a.get("details", {}).get("currency_unit", "INR")
    if "dcf" in v:
        r = v["dcf"]
        doc.add_paragraph().add_run(f"Income Approach - Discounted Cash Flow ({r['mode']})").bold = True
        doc.add_paragraph(
            f"Discount rate {r['discount_rate']:.2f}%, terminal growth {r['terminal_growth']:.2f}%, "
            f"{'mid-year' if r['mid_year'] else 'end-of-year'} discounting convention. Amounts in {unit}.")
        rows = [[x["label"], fmt_in(x["ebitda"]), fmt_in(x["tax"]), fmt_in(x["cash_flow"]),
                 x["period"], f"{x['df']:.4f}", fmt_in(x["pv"])] for x in r["rows"]]
        _table(doc, ["Year", "EBITDA", "Tax", "Free cash flow", "Period", "DF", "PV"], rows)
        summ = [["Sum of PV of explicit cash flows", fmt_in(r["sum_pv"])],
                ["Terminal value (Gordon growth)", fmt_in(r["terminal_value"])],
                ["PV of terminal value", fmt_in(r["pv_tv"])],
                ["Terminal value as % of total", f"{r['tv_share_pct']:.1f}%"],
                ["Enterprise value" if r["mode"] == "FCFF" else "Equity value from operations", fmt_in(r["enterprise_or_equity_value"])],
                ["Less: Net debt", fmt_in(r["net_debt"])],
                ["Add: Non-operating assets", fmt_in(r["non_operating_assets"])],
                ["Equity value", fmt_in(r["equity_value"])],
                ["Number of shares", fmt_in(r["shares"], 0)],
                ["Value per share (INR)", fmt_in(r["value_per_share"])]]
        doc.add_paragraph()
        _table(doc, ["Particulars", "Amount"], summ, [10, 5])
        if v.get("dcf_sensitivity"):
            doc.add_paragraph().add_run("Sensitivity - value per share (rows: discount rate, columns: terminal growth)").italic = True
            g = v["dcf_sensitivity"]
            cols = list(next(iter(g.values())).keys())
            _table(doc, ["Discount rate"] + cols, [[k] + [fmt_in(x) for x in row.values()] for k, row in g.items()])
    if "nav" in v:
        r = v["nav"]
        doc.add_paragraph().add_run("Asset Approach - Net Asset Value").bold = True
        rows = [[x["item"], fmt_in(x["book"]), fmt_in(x.get("fair", x["book"]))] for x in r["assets"]]
        rows += [["Less: " + x["item"], fmt_in(x["book"]), fmt_in(x.get("fair", x["book"]))] for x in r["liabilities"]]
        rows += [["Net asset value", fmt_in(r["book_nav"]), fmt_in(r["adjusted_nav"])],
                 ["Value per share (INR)", fmt_in(r["book_nav_per_share"]), fmt_in(r["value_per_share"])]]
        _table(doc, ["Particulars", "Book value", "Fair / adjusted value"], rows)
    if "rule11ua" in v:
        r = v["rule11ua"]
        doc.add_paragraph().add_run("Rule 11UA(1)(c)(a) - Income-tax Rules, 1962").bold = True
        _table(doc, ["Component", "Amount"], [["A (adjusted assets)", fmt_in(r["A"])], ["L (specified liabilities)", fmt_in(r["L"])],
                                              ["PE (paid-up equity capital)", fmt_in(r["PE"])], ["PV (paid-up value per share)", fmt_in(r["PV"])],
                                              ["FMV per share = (A - L) x PV / PE", fmt_in(r["value_per_share"])]])
    if "market" in v:
        r = v["market"]
        doc.add_paragraph().add_run(f"Market Approach - Comparable Companies ({r['multiple_type']})").bold = True
        _table(doc, ["Comparable company", r["multiple_type"]], [[p["name"], f"{p['multiple']:.2f}x"] for p in r["peers"]])
        _table(doc, ["Particulars", "Amount"], [
            [f"Peer {r['statistic']} multiple (range {r['min']:.2f}x - {r['max']:.2f}x)", f"{r['peer_multiple']:.2f}x"],
            ["Discount applied (size / liquidity / growth)", f"{r['discount_pct']:.1f}%"],
            ["Multiple applied", f"{r['applied_multiple']:.2f}x"], ["Subject company metric", fmt_in(r["subject_metric"])],
            ["Implied value", fmt_in(r["implied_value"])], ["Less: Net debt", fmt_in(r["net_debt"])],
            ["Equity value", fmt_in(r["equity_value"])], ["Value per share (INR)", fmt_in(r["value_per_share"])]])
    if "vwap" in v:
        r = v["vwap"]
        doc.add_paragraph().add_run("Market Price Method - Listed shares").bold = True
        _table(doc, ["Particulars", "Value"], [[f"90 trading-day VWAP ({r['days_90']} days)", fmt_in(r["vwap_90"])],
                                               [f"10 trading-day VWAP ({r['days_10']} days)", fmt_in(r["vwap_10"])],
                                               ["Higher of the above (floor price)", fmt_in(r["floor_price"])],
                                               ["Basis", r["basis"]]])
    if "debt" in v:
        r = v["debt"]
        doc.add_paragraph().add_run("Valuation of debt instrument - PV of contractual cash flows").bold = True
        doc.add_paragraph(f"Face value {fmt_in(r['face_value'])}, coupon {r['coupon_pct']:.2f}%, discount yield {r['yield_pct']:.2f}%: "
                          f"value per unit {fmt_in(r['value_per_unit'])}.")


def blk_conclusion(doc, a):
    c = a.get("valuation", {}).get("conclusion", {})
    if not c:
        doc.add_paragraph("[Conclusion not computed]")
        return
    rows = [[m, fmt_in(val), f"{c['weights'].get(m, 0):.0f}%", fmt_in(val * c['weights'].get(m, 0) / 100)]
            for m, val in c["method_values"].items()]
    rows.append(["Weighted value per share", "", "100%", fmt_in(c["weighted_value"])])
    running = c["weighted_value"]
    if c["dloc_pct"]:
        cut = running * c["dloc_pct"] / 100; running -= cut
        rows.append([f"Less: Discount for lack of control ({c['dloc_pct']}%)", "", "", "(" + fmt_in(cut) + ")"])
    if c["dlom_pct"]:
        cut = running * c["dlom_pct"] / 100; running -= cut
        rows.append([f"Less: Discount for lack of marketability ({c['dlom_pct']}%)", "", "", "(" + fmt_in(cut) + ")"])
    rows.append(["Fair value per share", "", "", fmt_in(c["final_value_per_share"])])
    _table(doc, ["Method", "Value per share", "Weight", "Weighted value"], rows)


def blk_checklist(doc, a):
    rows = [[c["id"], c["text"], "N/A" if c.get("na") else ("Received" if c["received"] else "Pending"),
             ", ".join(c.get("files", [])) or "-"] for c in a.get("checklist", [])]
    _table(doc, ["Ref", "Information / document", "Status", "File(s)"], rows, [1.5, 9, 2, 4.5])


def blk_sources(doc, a):
    items = [f"{c['text']}" for c in a.get("checklist", []) if c["received"]]
    md = a.get("market_data", {})
    if md.get("rfr"):
        items.append(f"Risk-free rate: {md['rfr'].get('source')} (as on {md['rfr'].get('as_on')})")
    if md.get("market_return_source"):
        items.append(f"Market return: {md['market_return_source']}")
    items.append("Industry information: published industry reports, regulator publications and the valuer's database")
    items += a.get("details", {}).get("other_sources", [])
    for i in items:
        doc.add_paragraph(i, style="List Bullet")


def blk_evidence(doc, a):
    folder = assignment_dir(a["assignment_id"]) / "05_Market_Data_Proofs"
    files = sorted(p.name for p in folder.glob("*")) if folder.exists() else []
    for f in files:
        doc.add_paragraph(f, style="List Bullet")
    if not files:
        doc.add_paragraph("No evidence files recorded.")


BLOCKS = {
    "INDUSTRY_ANALYSIS": blk_industry, "MARKET_DATA_TABLE": blk_market_data,
    "VALUATION_WORKINGS": blk_valuation, "CONCLUSION_TABLE": blk_conclusion,
    "DOCUMENT_CHECKLIST": blk_checklist, "SOURCES_OF_INFORMATION": blk_sources,
    "EVIDENCE_LIST": blk_evidence,
}


# --------------------------------------------------------------------------- #
# Built-in IBBI Rule 8 report
# --------------------------------------------------------------------------- #
RULE8 = [
    ("(a)", "Background information of the asset being valued", "Section 2"),
    ("(b)", "Purpose of valuation and appointing authority", "Section 3"),
    ("(c)", "Identity of the registered valuer and any other experts involved in the valuation", "Section 4"),
    ("(d)", "Disclosure of registered valuer interest or conflict, if any", "Section 4"),
    ("(e)", "Date of appointment, valuation date and date of report", "Section 5"),
    ("(f)", "Inspections and/or investigations undertaken", "Section 6"),
    ("(g)", "Nature and sources of the information used or relied upon", "Section 7 and Annexure A"),
    ("(h)", "Procedures adopted in carrying out the valuation and valuation standards followed", "Sections 8-11"),
    ("(i)", "Restrictions on use of the report, if any", "Section 13"),
    ("(j)", "Major factors that were taken into account during the valuation", "Section 12"),
    ("(k)", "Conclusion", "Section 1 and Section 11"),
    ("(l)", "Caveats, limitations and disclaimers to the extent they explain or elucidate the limitations faced by the valuer", "Section 14"),
]


def generate_builtin(a: dict) -> str:
    ctx = build_context(a)
    d = a.get("details", {})
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name, st.font.size = "Calibri", Pt(11)
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.2)
        s.footer.paragraphs[0].text = f"{ctx['FIRM_NAME']} | Strictly private & confidential | Valuation of {ctx['CLIENT_NAME']}"

    # Cover
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("VALUATION REPORT"); r.bold = True; r.font.size = Pt(26); r.font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)
    for line in [f"{ctx['SECURITY_TYPE']} of", ctx["CLIENT_NAME"], f"CIN: {ctx['CIN']}", "",
                 f"Purpose: {ctx['PURPOSE']}", f"Valuation date: {ctx['VALUATION_DATE']}",
                 f"Report date: {ctx['REPORT_DATE']}", "", "Prepared by", ctx["VALUER_NAME"],
                 f"Registered Valuer (Securities or Financial Assets)", f"IBBI Registration No.: {ctx['IBBI_REG_NO']}",
                 ctx["RVO_NAME"], ctx["FIRM_NAME"]]:
        q = doc.add_paragraph(line); q.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_page_break()

    # Transmittal
    doc.add_paragraph(f"Date: {ctx['REPORT_DATE']}")
    doc.add_paragraph(f"To,\n{ctx['APPOINTING_AUTHORITY']}\n{ctx['CLIENT_NAME']}\n{ctx['REGISTERED_OFFICE']}")
    doc.add_paragraph(f"Sub: Valuation of {ctx['SECURITY_TYPE']} of {ctx['CLIENT_NAME']} as at {ctx['VALUATION_DATE']}")
    doc.add_paragraph(
        f"We have been appointed to determine the {ctx['BASIS_OF_VALUE'].lower()} of the {ctx['SECURITY_TYPE'].lower()} of "
        f"{ctx['CLIENT_NAME']} (the 'Company') as at {ctx['VALUATION_DATE']} for the purpose of {ctx['PURPOSE']}. "
        f"Based on our analysis and subject to the caveats in this report, the {ctx['BASIS_OF_VALUE'].lower()} per "
        f"share is INR {ctx['FINAL_VALUE_PER_SHARE']}.")
    doc.add_paragraph(f"For {ctx['FIRM_NAME']}\n\n\n{ctx['VALUER_NAME']}\nRegistered Valuer - {ctx['IBBI_REG_NO']}")
    doc.add_page_break()

    H = lambda t: doc.add_heading(t, 1)
    H("1. Executive summary and conclusion of value")
    blk_conclusion(doc, a)
    doc.add_paragraph(f"Basis of value: {ctx['BASIS_OF_VALUE']}. Premise of value: {ctx['PREMISE_OF_VALUE']}. "
                      f"Amounts in {ctx['CURRENCY_UNIT']} unless stated otherwise; per-share values are in INR.")

    H("2. Background information of the asset being valued")
    _table(doc, ["Particulars", "Details"], [
        ["Name of company", ctx["CLIENT_NAME"]], ["CIN / PAN", f"{ctx['CIN']} / {ctx['PAN']}"],
        ["Registered office", ctx["REGISTERED_OFFICE"]], ["Nature of business", ctx["NATURE_OF_BUSINESS"]],
        ["Industry", ctx["INDUSTRY"]], ["Security valued", ctx["SECURITY_TYPE"]],
        ["Number of shares / units", ctx["SHARES_OUTSTANDING"]], ["Face value", ctx["FACE_VALUE"]]], [5, 11])
    if d.get("background"):
        doc.add_paragraph(d["background"])

    H("3. Purpose of valuation and appointing authority")
    doc.add_paragraph(f"The valuation is required for: {ctx['PURPOSE']}. We have been appointed by "
                      f"{ctx['APPOINTING_AUTHORITY']} of the Company.")

    H("4. Identity of the valuer and other experts; disclosure of interest")
    doc.add_paragraph(f"{ctx['VALUER_NAME']}, Registered Valuer (Securities or Financial Assets), IBBI Registration "
                      f"No. {ctx['IBBI_REG_NO']}, member of {ctx['RVO_NAME']}.")
    doc.add_paragraph("Other experts involved: " + (d.get("other_experts") or "None."))
    doc.add_paragraph(d.get("conflict_declaration") or
                      "The valuer is independent of the Company and the parties to the transaction, has no present or "
                      "prospective interest in the Company or the security being valued, and the fee is not contingent "
                      "on the value concluded.")

    H("5. Date of appointment, valuation date and date of report")
    _table(doc, ["Particulars", "Date"], [["Date of appointment", ctx["APPOINTMENT_DATE"]],
                                         ["Valuation date", ctx["VALUATION_DATE"]], ["Date of report", ctx["REPORT_DATE"]]], [8, 8])

    H("6. Inspections and/or investigations undertaken")
    doc.add_paragraph(d.get("inspections") or
                      "We held discussions with the management, reviewed the documents listed in Annexure A, analysed "
                      "historical financial statements and projections, and carried out such other procedures as considered "
                      "necessary. No physical inspection of assets was carried out unless specifically stated.")

    H("7. Nature and sources of information used or relied upon")
    blk_sources(doc, a)

    H("8. Valuation standards, basis and premise of value")
    doc.add_paragraph(d.get("standards_followed") or
                      "The valuation has been carried out in accordance with the ICAI Valuation Standards 2018 "
                      "(including VS 101 Definitions, VS 102 Valuation Bases, VS 103 Valuation Approaches and Methods, "
                      "VS 201 Scope of Work, VS 202 Reporting and Documentation) as applicable to registered valuers, "
                      "and Rule 8 of the Companies (Registered Valuers and Valuation) Rules, 2017.")
    doc.add_paragraph(f"Basis of value: {ctx['BASIS_OF_VALUE']}. Premise of value: {ctx['PREMISE_OF_VALUE']}.")

    H("9. Industry and economic analysis")
    blk_industry(doc, a)

    H("10. Market data and cost of capital")
    blk_market_data(doc, a)
    doc.add_paragraph("Evidence for each market input is retained in the working papers (Annexure B).")

    H("11. Valuation approaches, methodology and workings")
    doc.add_paragraph(d.get("approach_rationale") or
                      "The income, market and asset approaches were considered. The approaches adopted, and the reasons "
                      "for rejecting others, are explained below.")
    blk_valuation(doc, a)
    doc.add_paragraph().add_run("Conclusion of value").bold = True
    blk_conclusion(doc, a)

    H("12. Major factors taken into account")
    for f in d.get("major_factors") or [
        "Historical financial performance and quality of earnings",
        "Management projections and the reasonableness of key assumptions",
        "Industry outlook and competitive position", "Capital structure and cost of capital",
        "Terms and rights attached to the security", "Liquidity / marketability and control characteristics"]:
        doc.add_paragraph(f, style="List Bullet")

    H("13. Restrictions on use of the report")
    doc.add_paragraph(d.get("restrictions") or
                      f"This report has been prepared solely for the purpose stated in Section 3 and for submission to the "
                      f"relevant authority. It should not be used, circulated, quoted or relied upon for any other purpose "
                      f"without our prior written consent.")

    H("14. Caveats, limitations and disclaimers")
    for c in d.get("caveats") or [
        "The valuation is based on information provided by the management; we have not audited or independently verified it.",
        "Projections are management's responsibility; actual results may differ materially.",
        "Valuation is not an exact science and involves judgement; the value is specific to the valuation date and purpose.",
        "We have no obligation to update this report for events after the date of the report.",
        "Our liability is limited as per the engagement letter.",
        "This report does not constitute a fairness opinion, investment advice or a recommendation to transact."]:
        doc.add_paragraph(c, style="List Bullet")

    doc.add_paragraph(f"\n\nFor {ctx['FIRM_NAME']}\n\n\n{ctx['VALUER_NAME']}\nRegistered Valuer (S&FA) - {ctx['IBBI_REG_NO']}\n"
                      f"Place: ________   Date: {ctx['REPORT_DATE']}\nUDIN / UVIN: ____________")

    doc.add_page_break()
    H("Annexure A - Information and documents received")
    blk_checklist(doc, a)
    H("Annexure B - Market data evidence on file")
    blk_evidence(doc, a)
    H("Annexure C - Compliance matrix: Rule 8, Companies (Registered Valuers and Valuation) Rules, 2017")
    _table(doc, ["Clause", "Requirement", "Where covered"], [list(x) for x in RULE8], [1.5, 11, 3.5])

    return _save(doc, a, "Valuation_Report_IBBI")


def _save(doc, a, stem):
    folder = assignment_dir(a["assignment_id"]) / "09_Final_Report"
    folder.mkdir(parents=True, exist_ok=True)
    name = f"{stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    doc.save(folder / name)
    log(a["assignment_id"], "REPORT", name)
    return str(folder / name)


# --------------------------------------------------------------------------- #
# Custom template filling
# --------------------------------------------------------------------------- #
PH = re.compile(r"\{\{\s*([A-Z0-9_]+)\s*\}\}")


def _iter_paragraphs(container):
    for p in container.paragraphs:
        yield p
    for t in getattr(container, "tables", []):
        for row in t.rows:
            for cell in row.cells:
                yield from _iter_paragraphs(cell)


def _replace_in_paragraph(p, ctx):
    full = "".join(r.text for r in p.runs)
    if "{{" not in full:
        return
    new = PH.sub(lambda m: str(ctx.get(m.group(1), m.group(0))), full)
    if new != full and p.runs:
        p.runs[0].text = new
        for r in p.runs[1:]:
            r.text = ""


def fill_template(template_path: str, a: dict) -> tuple:
    """Returns (output_path, list_of_unknown_placeholders)."""
    doc = Document(template_path)
    ctx = build_context(a)
    unknown = set()

    # 1. Block placeholders: paragraph whose whole text is {{BLOCK}}
    for p in list(doc.paragraphs):
        m = PH.fullmatch(p.text.strip())
        if m and m.group(1) in BLOCKS:
            body = doc.element.body
            existing = set(id(e) for e in body)
            BLOCKS[m.group(1)](doc, a)          # appends at end of document
            new_elems = [e for e in body if id(e) not in existing and not e.tag.endswith("sectPr")]
            for e in new_elems:
                p._p.addprevious(e)
            p._p.getparent().remove(p._p)

    # 2. Simple placeholders everywhere (body, tables, headers, footers)
    containers = [doc] + [s.header for s in doc.sections] + [s.footer for s in doc.sections]
    for c in containers:
        for p in _iter_paragraphs(c):
            for m in PH.finditer("".join(r.text for r in p.runs)):
                if m.group(1) not in ctx:
                    unknown.add(m.group(1))
            _replace_in_paragraph(p, ctx)
    return _save(doc, a, "Valuation_Report_CustomTemplate"), sorted(unknown)


def placeholder_help() -> dict:
    return {"simple": sorted(build_context({"details": {}, "market_data": {}, "valuation": {}}).keys()),
            "blocks": sorted(BLOCKS.keys())}
