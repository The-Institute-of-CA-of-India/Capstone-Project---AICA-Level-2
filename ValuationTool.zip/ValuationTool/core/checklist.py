"""Requirement checklists, generated from Purpose of valuation and Type of security.

Each item: id, text, folder (where the file is saved), mandatory flag.
Firms can add items in data/custom_checklist.json (same structure as COMMON).
"""
import json

from .config import DATA_DIR

PURPOSES = {
    "COMPANIES_ACT_62": "Further issue of shares / Preferential allotment - Sec 62(1)(c) & 42, Companies Act 2013",
    "COMPANIES_ACT_230": "Merger / Demerger / Scheme of Arrangement - Sec 230-232, Companies Act 2013",
    "COMPANIES_ACT_OTHER": "Other Companies Act valuation (Sec 54, 66, 192, 236, 281, 305, 325)",
    "INCOME_TAX_11UA": "Income-tax Act - Rule 11UA / Sec 56(2)(x) / 50CA (FMV of unquoted shares)",
    "FEMA": "FEMA / RBI - Issue or transfer of shares to/from non-residents (pricing guidelines)",
    "SEBI_ICDR": "SEBI ICDR / SAST - Preferential issue of listed company",
    "IBC": "Insolvency & Bankruptcy Code - Fair value and Liquidation value (CIRP Reg. 27/35)",
    "IND_AS": "Financial reporting - Ind AS 113 / 109 / 102 (ESOP) / PPA",
    "ESOP": "ESOP / Sweat equity valuation",
    "TRANSACTION": "Transaction / Fund raise / Internal decision / Litigation support",
}

SECURITY_TYPES = [
    "Unlisted equity shares",
    "Listed equity shares",
    "Compulsorily Convertible Preference Shares (CCPS)",
    "Optionally / Non-convertible Preference Shares",
    "Compulsorily / Optionally Convertible Debentures",
    "Non-convertible debentures / Bonds",
    "Employee stock options / Warrants",
    "Business / Undertaking (enterprise value)",
    "Financial assets / Portfolio (loans, receivables, investments)",
]

COMMON = [
    ("ENG01", "Signed engagement letter / appointment letter (with scope, purpose, valuation date)", "01_Engagement_and_Independence", True),
    ("ENG02", "Board resolution / authority appointing the Registered Valuer", "01_Engagement_and_Independence", True),
    ("ENG03", "Independence and conflict-of-interest declaration by valuer", "01_Engagement_and_Independence", True),
    ("ENG04", "KYC of client - PAN, CIN, Certificate of Incorporation", "04_Legal_and_Secretarial", True),
    ("FIN01", "Audited financial statements - last 3 years (with notes and auditor's report)", "02_Financial_Statements", True),
    ("FIN02", "Provisional / limited-review financial statements as at (or nearest to) valuation date", "02_Financial_Statements", True),
    ("FIN03", "Trial balance / schedules as at valuation date", "02_Financial_Statements", False),
    ("FIN04", "Income-tax returns and tax audit reports - last 3 years", "02_Financial_Statements", False),
    ("FIN05", "Details of contingent liabilities, pending litigations and commitments", "02_Financial_Statements", True),
    ("FIN06", "Details of investments, loans given / taken, related party balances", "02_Financial_Statements", True),
    ("LEG01", "Memorandum and Articles of Association", "04_Legal_and_Secretarial", True),
    ("LEG02", "Shareholding pattern as on valuation date (pre and proposed post issue)", "04_Legal_and_Secretarial", True),
    ("LEG03", "Terms of the security being valued (term sheet / SHA / SSA)", "04_Legal_and_Secretarial", True),
    ("LEG04", "Details of previous fund raises / share transfers in last 2 years with prices", "04_Legal_and_Secretarial", False),
    ("MR01", "Management representation letter (signed)", "08_Management_Representations", True),
    ("MKT01", "Risk-free rate proof (auto-generated / FBIL / RBI download)", "05_Market_Data_Proofs", True),
    ("MKT02", "Beta / comparable companies data proof", "05_Market_Data_Proofs", False),
]

BY_PURPOSE = {
    "COMPANIES_ACT_62": [
        ("P62A", "Draft special resolution / explanatory statement for issue", "04_Legal_and_Secretarial", False),
    ],
    "COMPANIES_ACT_230": [
        ("P230A", "Draft scheme of arrangement and appointed date", "04_Legal_and_Secretarial", True),
        ("P230B", "Financials of all transferor / transferee companies", "02_Financial_Statements", True),
        ("P230C", "Share entitlement ratio basis and fairness opinion requirement (if listed)", "07_Valuation_Workings", True),
    ],
    "INCOME_TAX_11UA": [
        ("P11A", "Balance sheet as on valuation date (for NAV under Rule 11UA(1)(c)(a))", "02_Financial_Statements", True),
        ("P11B", "Fair value of jewellery, artistic work, immovable property (stamp duty value), shares held", "02_Financial_Statements", True),
        ("P11C", "Projections approved by management (if DCF method chosen)", "03_Projections_and_Business_Plan", False),
    ],
    "FEMA": [
        ("PFA", "Details of non-resident investor / transferee and FDI sector cap / route", "04_Legal_and_Secretarial", True),
        ("PFB", "Projections approved by management (DCF as internationally accepted pricing methodology)", "03_Projections_and_Business_Plan", True),
    ],
    "SEBI_ICDR": [
        ("PSA", "Stock exchange price-volume data (90 / 10 trading days) up to relevant date", "05_Market_Data_Proofs", True),
        ("PSB", "Relevant date computation and in-principle approval workings", "07_Valuation_Workings", True),
        ("PSC", "Articles provision on preferential pricing (if any)", "04_Legal_and_Secretarial", False),
    ],
    "IBC": [
        ("PIA", "Appointment letter from Resolution Professional / Liquidator", "01_Engagement_and_Independence", True),
        ("PIB", "Information memorandum / list of assets and liabilities as on insolvency commencement date", "02_Financial_Statements", True),
        ("PIC", "Fixed asset register, physical verification and site inspection photographs", "07_Valuation_Workings", True),
        ("PID", "Asset-wise details: receivables ageing, inventory, investments, securities", "02_Financial_Statements", True),
    ],
    "IND_AS": [
        ("PIN1", "Accounting policy and measurement date as per Ind AS", "07_Valuation_Workings", True),
        ("PIN2", "Auditor's queries / requirements (if any)", "10_Correspondence", False),
    ],
    "ESOP": [
        ("PES1", "ESOP scheme document, grant letters, vesting schedule", "04_Legal_and_Secretarial", True),
        ("PES2", "Historic volatility data / comparable volatility", "05_Market_Data_Proofs", True),
    ],
    "TRANSACTION": [
        ("PTR1", "Term sheet / LOI of the transaction", "04_Legal_and_Secretarial", False),
    ],
}

BY_SECURITY = {
    "Listed equity shares": [
        ("SL1", "Share price history (NSE/BSE bhavcopy or price CSV) for required look-back", "05_Market_Data_Proofs", True),
    ],
    "Compulsorily Convertible Preference Shares (CCPS)": [
        ("SC1", "Conversion terms, coupon, anti-dilution and liquidation preference", "04_Legal_and_Secretarial", True),
    ],
    "Compulsorily / Optionally Convertible Debentures": [
        ("SD1", "Debenture trust deed / terms incl. coupon, conversion & redemption", "04_Legal_and_Secretarial", True),
        ("SD2", "Credit rating of issuer / instrument (if any)", "05_Market_Data_Proofs", False),
    ],
    "Non-convertible debentures / Bonds": [
        ("SN1", "Information memorandum / trust deed / cash-flow schedule", "04_Legal_and_Secretarial", True),
        ("SN2", "Credit rating and comparable corporate bond yields / spread (FBIL/FIMMDA)", "05_Market_Data_Proofs", True),
    ],
    "Optionally / Non-convertible Preference Shares": [
        ("SP1", "Terms: dividend rate, redemption date & premium", "04_Legal_and_Secretarial", True),
    ],
    "Employee stock options / Warrants": [
        ("SE1", "Option terms: exercise price, vesting, expected life", "04_Legal_and_Secretarial", True),
    ],
    "Business / Undertaking (enterprise value)": [
        ("SB1", "Projections for 5 years with key assumptions approved by management", "03_Projections_and_Business_Plan", True),
        ("SB2", "Business plan / capex plan / working capital assumptions", "03_Projections_and_Business_Plan", False),
    ],
    "Unlisted equity shares": [
        ("SU1", "Projections for 5 years with key assumptions (if Income approach used)", "03_Projections_and_Business_Plan", False),
    ],
    "Financial assets / Portfolio (loans, receivables, investments)": [
        ("SF1", "Loan-wise / asset-wise data tape with contractual cash flows", "02_Financial_Statements", True),
        ("SF2", "Ageing, DPD status, collateral and recovery history", "02_Financial_Statements", True),
    ],
}


def _custom_items() -> list:
    f = DATA_DIR / "custom_checklist.json"
    if f.exists():
        with open(f, encoding="utf-8") as fh:
            return [tuple(x) for x in json.load(fh)]
    return []


def build_checklist(purpose: str, security_type: str) -> list:
    items = list(COMMON) + BY_PURPOSE.get(purpose, []) + BY_SECURITY.get(security_type, []) + _custom_items()
    seen, out = set(), []
    for iid, text, folder, mandatory in items:
        if iid in seen:
            continue
        seen.add(iid)
        out.append({"id": iid, "text": text, "folder": folder, "mandatory": mandatory,
                    "received": False, "files": [], "remarks": "", "na": False})
    return out


def checklist_status(checklist: list) -> dict:
    mand = [c for c in checklist if c["mandatory"] and not c.get("na")]
    done = [c for c in mand if c["received"]]
    pending = [c for c in mand if not c["received"]]
    return {
        "total": len(checklist),
        "received": sum(1 for c in checklist if c["received"]),
        "mandatory": len(mand),
        "mandatory_received": len(done),
        "pending_mandatory": pending,
        "ready": len(pending) == 0,
    }
