"""Market data: risk-free rate (auto-fetch with proof), market return from index
history, cost of equity (CAPM / build-up), WACC, and listed-share VWAP pricing.

Every fetched / uploaded number produces a PROOF in 05_Market_Data_Proofs:
  * raw source file (HTML / CSV / XLSX) exactly as received
  * a PDF "Market Data Evidence Sheet" with URL, timestamp, SHA-256 hash and
    the extracted value - attach this to the working papers.
"""
import hashlib
import io
import re
import ssl
import urllib.request
from datetime import datetime, date
from pathlib import Path

import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.lib import colors

from .config import load_settings
from .storage import assignment_dir, log

PROOF_FOLDER = "05_Market_Data_Proofs"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


# --------------------------------------------------------------------------- #
# Proof generation
# --------------------------------------------------------------------------- #
def _evidence_pdf(path: Path, title: str, rows: list, excerpt: str = "") -> None:
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm)
    story = [Paragraph("Market Data Evidence Sheet", styles["Title"]),
             Paragraph(title, styles["Heading2"]), Spacer(1, 8)]
    t = Table([[Paragraph(f"<b>{k}</b>", styles["Normal"]), Paragraph(str(v), styles["Normal"])]
               for k, v in rows], colWidths=[5 * cm, 11 * cm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                           ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(t)
    if excerpt:
        story += [Spacer(1, 12), Paragraph("<b>Extract from source</b>", styles["Normal"]),
                  Paragraph(excerpt.replace("<", "&lt;").replace(">", "&gt;"), styles["Code"])]
    story += [Spacer(1, 18), Paragraph(
        "The raw source file saved alongside this sheet is the primary evidence. "
        "Its SHA-256 hash above can be recomputed to demonstrate it has not been altered. "
        "Prepared by: ____________ Reviewed by (Registered Valuer): ____________", styles["Italic"])]
    doc.build(story)


def _save_proof(assignment_id: str, stem: str, raw: bytes, ext: str, title: str,
                rows: list, excerpt: str = "") -> dict:
    folder = assignment_dir(assignment_id) / PROOF_FOLDER
    folder.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    raw_path = folder / f"{stem}_{ts}{ext}"
    raw_path.write_bytes(raw)
    sha = hashlib.sha256(raw).hexdigest()
    pdf_path = folder / f"{stem}_{ts}_EVIDENCE.pdf"
    _evidence_pdf(pdf_path, title, rows + [("Raw file saved as", raw_path.name), ("SHA-256", sha)], excerpt)
    log(assignment_id, "PROOF", f"{pdf_path.name}")
    return {"raw_file": raw_path.name, "evidence_pdf": pdf_path.name, "sha256": sha}


# --------------------------------------------------------------------------- #
# Risk-free rate
# --------------------------------------------------------------------------- #
def _http_get(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html,*/*"})
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def _strip_html(html: str) -> str:
    text = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text)


def fetch_risk_free_rate(assignment_id: str) -> dict:
    """Try each configured source; first success wins. Returns dict with rate,
    source, timestamp and proof file names. Raises RuntimeError if all fail."""
    settings = load_settings()
    errors = []
    for src in settings["rfr_sources"]:
        try:
            raw = _http_get(src["url"])
            html = raw.decode("utf-8", errors="ignore")
            text = _strip_html(html)
            m = re.search(src["regex"], text, flags=re.I)
            hay = text
            if not m:
                m = re.search(src["regex"], html, flags=re.I)
                hay = html
            if not m:
                errors.append(f"{src['name']}: pattern not found")
                continue
            rate = float(m.group(1))
            if not 3.0 < rate < 15.0:
                errors.append(f"{src['name']}: implausible value {rate}")
                continue
            s, e = max(0, m.start() - 200), m.end() + 200
            excerpt = hay[s:e]
            fetched = datetime.now().isoformat(timespec="seconds")
            proof = _save_proof(assignment_id, "RiskFreeRate_web", raw, ".html",
                                "Risk-free rate: 10-year Government of India benchmark yield",
                                [("Value extracted", f"{rate:.2f}% p.a."), ("Source", src["name"]),
                                 ("URL", src["url"]), ("Fetched on", fetched),
                                 ("Method", "Automated HTTP fetch and pattern extraction")], excerpt)
            return {"rate": rate, "source": src["name"], "url": src["url"], "as_on": fetched[:10],
                    "fetched_on": fetched, "method": "auto-web", **proof}
        except Exception as ex:  # network / parse errors - try next source
            errors.append(f"{src['name']}: {ex}")
    raise RuntimeError("All online sources failed:\n" + "\n".join(errors))


def parse_yield_file(content: bytes, filename: str, tenor: float = 10.0) -> dict:
    """Parse a yield-curve file downloaded from FBIL (Par Yield / G-Sec prices),
    CCIL or NSE ZCYC. Looks for a 'tenor/maturity' column and a 'yield/ytm' column
    and returns the yield at the tenor closest to the target."""
    name = filename.lower()
    if name.endswith((".xlsx", ".xls")):
        sheets = pd.read_excel(io.BytesIO(content), sheet_name=None, header=None)
    else:
        sheets = {"csv": pd.read_csv(io.BytesIO(content), header=None)}
    for sname, raw in sheets.items():
        raw = raw.dropna(how="all").dropna(axis=1, how="all")
        for hdr_row in range(min(15, len(raw))):
            header = [str(x).strip().lower() for x in raw.iloc[hdr_row].tolist()]
            t_col = next((i for i, h in enumerate(header) if any(k in h for k in ("tenor", "maturity (yrs", "years", "term"))), None)
            y_cols = [i for i, h in enumerate(header) if any(k in h for k in ("yield", "ytm", "rate"))]
            if t_col is None or not y_cols:
                continue
            # prefer annualised column when available
            y_col = next((i for i in y_cols if "annual" in header[i] and "semi" not in header[i]), y_cols[0])
            body = raw.iloc[hdr_row + 1:, [t_col, y_col]].copy()
            body.columns = ["tenor", "yld"]
            body["tenor"] = pd.to_numeric(body["tenor"].astype(str).str.extract(r"([0-9.]+)")[0], errors="coerce")
            body["yld"] = pd.to_numeric(body["yld"], errors="coerce")
            body = body.dropna()
            if body.empty:
                continue
            if body["yld"].max() < 1:  # given as decimals
                body["yld"] *= 100
            row = body.iloc[(body["tenor"] - tenor).abs().argsort().iloc[0]]
            return {"rate": round(float(row["yld"]), 4), "tenor_used": float(row["tenor"]),
                    "sheet": sname, "yield_column": header[y_col]}
    raise ValueError("Could not locate tenor and yield columns in the file. Enter rate manually.")


def record_rfr_from_file(assignment_id: str, content: bytes, filename: str,
                         source_name: str, as_on: str, tenor: float = 10.0) -> dict:
    parsed = parse_yield_file(content, filename, tenor)
    ext = Path(filename).suffix or ".dat"
    proof = _save_proof(assignment_id, "RiskFreeRate_file", content, ext,
                        f"Risk-free rate from uploaded yield file ({source_name})",
                        [("Value extracted", f"{parsed['rate']:.4f}% p.a."),
                         ("Tenor used", f"{parsed['tenor_used']} years"),
                         ("Column used", parsed["yield_column"]), ("Sheet", parsed["sheet"]),
                         ("Source", source_name), ("Data as on", as_on), ("Original file", filename),
                         ("Recorded on", datetime.now().isoformat(timespec="seconds"))])
    return {"rate": parsed["rate"], "source": source_name, "url": "", "as_on": as_on,
            "method": "uploaded-file", **parsed, **proof}


def record_rfr_manual(assignment_id: str, rate: float, source_name: str, as_on: str,
                      proof_content: bytes, proof_filename: str) -> dict:
    ext = Path(proof_filename).suffix or ".dat"
    proof = _save_proof(assignment_id, "RiskFreeRate_manual", proof_content, ext,
                        "Risk-free rate - manual entry supported by attached proof",
                        [("Value entered", f"{rate:.4f}% p.a."), ("Source", source_name),
                         ("Data as on", as_on), ("Proof file", proof_filename),
                         ("Recorded on", datetime.now().isoformat(timespec="seconds"))])
    return {"rate": rate, "source": source_name, "url": "", "as_on": as_on, "method": "manual", **proof}


def fallback_rfr() -> dict:
    s = load_settings()
    return {"rate": s["fallback_risk_free_rate"], "source": s["fallback_risk_free_rate_source"],
            "as_on": s["fallback_risk_free_rate_date"], "method": "fallback-setting",
            "evidence_pdf": "", "raw_file": ""}


# --------------------------------------------------------------------------- #
# Market return from index history (e.g. Nifty 50 TRI CSV from niftyindices.com)
# --------------------------------------------------------------------------- #
def market_return_from_index(assignment_id: str, content: bytes, filename: str,
                             index_name: str, years: int = 15, end_date: str = "") -> dict:
    df = pd.read_excel(io.BytesIO(content)) if filename.lower().endswith((".xlsx", ".xls")) \
        else pd.read_csv(io.BytesIO(content))
    cols = {c.lower().strip(): c for c in df.columns}
    dcol = next((cols[c] for c in cols if "date" in c), None)
    ccol = next((cols[c] for c in cols if c in ("close", "total returns index", "tri", "closing index value", "price", "adj close")), None) \
        or next((cols[c] for c in cols if "close" in c or "index value" in c or "tri" in c), None)
    if dcol is None or ccol is None:
        raise ValueError("Need a Date column and a Close / TRI column.")
    df = df[[dcol, ccol]].copy()
    df.columns = ["d", "c"]
    df["d"] = pd.to_datetime(df["d"], errors="coerce", dayfirst=True)
    df["c"] = pd.to_numeric(df["c"].astype(str).str.replace(",", ""), errors="coerce")
    df = df.dropna().sort_values("d")
    end = pd.Timestamp(end_date) if end_date else df["d"].iloc[-1]
    df = df[df["d"] <= end]
    start_target = end - pd.DateOffset(years=years)
    start_row = df.iloc[(df["d"] - start_target).abs().argsort().iloc[0]]
    end_row = df.iloc[-1]
    n = (end_row["d"] - start_row["d"]).days / 365.25
    if n < 1:
        raise ValueError("Index history is shorter than one year.")
    cagr = ((end_row["c"] / start_row["c"]) ** (1 / n) - 1) * 100
    proof = _save_proof(assignment_id, "MarketReturn_index", content, Path(filename).suffix or ".csv",
                        f"Expected market return - CAGR of {index_name}",
                        [("Index", index_name), ("Start", f"{start_row['d'].date()} : {start_row['c']:,.2f}"),
                         ("End", f"{end_row['d'].date()} : {end_row['c']:,.2f}"),
                         ("Period (years)", f"{n:.2f}"), ("CAGR", f"{cagr:.2f}% p.a."),
                         ("Formula", "(End / Start)^(1/years) - 1")])
    return {"market_return": round(cagr, 2), "index": index_name, "years": round(n, 2),
            "start": str(start_row["d"].date()), "end": str(end_row["d"].date()), **proof}


# --------------------------------------------------------------------------- #
# Cost of capital
# --------------------------------------------------------------------------- #
def relever_beta(unlevered: float, de_ratio: float, tax_rate_pct: float) -> float:
    """Hamada: Bl = Bu x (1 + (1 - t) x D/E)"""
    return unlevered * (1 + (1 - tax_rate_pct / 100) * de_ratio)


def cost_of_equity(rf: float, beta: float, erp: float, size_premium: float = 0.0,
                   company_specific: float = 0.0) -> dict:
    ke = rf + beta * erp + size_premium + company_specific
    return {"rf": rf, "beta": beta, "erp": erp, "size_premium": size_premium,
            "csrp": company_specific, "ke": round(ke, 4),
            "formula": "Ke = Rf + Beta x (Rm - Rf) + Size premium + Company-specific risk premium"}


def wacc(ke: float, kd_pre_tax: float, tax_rate_pct: float, debt_weight_pct: float) -> dict:
    wd = debt_weight_pct / 100
    kd_post = kd_pre_tax * (1 - tax_rate_pct / 100)
    w = ke * (1 - wd) + kd_post * wd
    return {"ke": ke, "kd_pre_tax": kd_pre_tax, "kd_post_tax": round(kd_post, 4),
            "we": round(1 - wd, 4), "wd": wd, "wacc": round(w, 4)}


# --------------------------------------------------------------------------- #
# Listed shares - SEBI ICDR Reg. 164(1): higher of 90 & 10 trading-day VWAP
# --------------------------------------------------------------------------- #
def vwap_pricing(content: bytes, filename: str, relevant_date: str) -> dict:
    df = pd.read_excel(io.BytesIO(content)) if filename.lower().endswith((".xlsx", ".xls")) \
        else pd.read_csv(io.BytesIO(content))
    df.columns = [str(c).strip().lower() for c in df.columns]
    dcol = next(c for c in df.columns if "date" in c)
    vcol = next(c for c in df.columns if "volume" in c or "no. of shares" in c or "qty" in c or "quantity" in c)
    tcol = next((c for c in df.columns if "turnover" in c or "value" in c), None)
    pcol = next((c for c in df.columns if c in ("close", "close price", "vwap", "average price", "wap")), None)
    df[dcol] = pd.to_datetime(df[dcol], errors="coerce", dayfirst=True)
    df = df[df[dcol] < pd.Timestamp(relevant_date)].sort_values(dcol)
    num = lambda s: pd.to_numeric(s.astype(str).str.replace(",", ""), errors="coerce")
    df[vcol] = num(df[vcol])
    if tcol:
        df[tcol] = num(df[tcol])
    else:
        df["turnover_calc"] = num(df[pcol]) * df[vcol]
        tcol = "turnover_calc"

    def _vwap(n):
        sub = df.tail(n)
        return float(sub[tcol].sum() / sub[vcol].sum()), len(sub)

    v90, n90 = _vwap(90)
    v10, n10 = _vwap(10)
    return {"vwap_90": round(v90, 2), "days_90": n90, "vwap_10": round(v10, 2), "days_10": n10,
            "floor_price": round(max(v90, v10), 2), "relevant_date": relevant_date,
            "basis": "SEBI ICDR Reg. 164(1): higher of 90 and 10 trading-day VWAP preceding relevant date "
                     "(verify current regulation and AoA requirements)"}
