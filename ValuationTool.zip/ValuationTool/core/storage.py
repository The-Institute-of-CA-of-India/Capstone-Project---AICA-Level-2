"""Assignment storage: one folder per assignment, state kept in assignment.json,
every action recorded in audit_log.csv (useful for IBBI / RVO inspection)."""
import csv
import json
import re
import shutil
from datetime import datetime
from pathlib import Path

from .config import CLIENTS_DIR, FOLDERS


def _slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_")[:50] or "Client"


def assignment_dir(assignment_id: str) -> Path:
    return CLIENTS_DIR / assignment_id


def create_assignment(client_name: str, details: dict) -> dict:
    CLIENTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    assignment_id = f"{_slug(client_name)}_{stamp}"
    root = assignment_dir(assignment_id)
    for folder in FOLDERS:
        (root / folder).mkdir(parents=True, exist_ok=True)
    data = {
        "assignment_id": assignment_id,
        "client_name": client_name,
        "created_on": datetime.now().isoformat(timespec="seconds"),
        "status": "Open",
        "details": details,
        "checklist": {},
        "market_data": {},
        "industry": {},
        "valuation": {},
        "report": {},
    }
    save_assignment(data)
    log(assignment_id, "CREATE", f"Assignment created for {client_name}")
    return data


def list_assignments() -> list:
    if not CLIENTS_DIR.exists():
        return []
    out = []
    for p in sorted(CLIENTS_DIR.iterdir(), reverse=True):
        f = p / "assignment.json"
        if f.exists():
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
            out.append(d)
    return out


def load_assignment(assignment_id: str) -> dict:
    with open(assignment_dir(assignment_id) / "assignment.json", encoding="utf-8") as f:
        return json.load(f)


def save_assignment(data: dict) -> None:
    root = assignment_dir(data["assignment_id"])
    root.mkdir(parents=True, exist_ok=True)
    data["last_saved"] = datetime.now().isoformat(timespec="seconds")
    with open(root / "assignment.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


def save_upload(assignment_id: str, folder: str, filename: str, content: bytes,
                prefix: str = "") -> Path:
    """Save an uploaded file into the assignment's sub-folder; never overwrite."""
    target_dir = assignment_dir(assignment_id) / folder
    target_dir.mkdir(parents=True, exist_ok=True)
    name = (prefix + "__" if prefix else "") + Path(filename).name
    target = target_dir / name
    i = 1
    while target.exists():
        target = target_dir / f"{Path(name).stem}_v{i}{Path(name).suffix}"
        i += 1
    target.write_bytes(content)
    log(assignment_id, "UPLOAD", f"{folder}/{target.name}")
    return target


def log(assignment_id: str, action: str, detail: str, user: str = "") -> None:
    f = assignment_dir(assignment_id) / "audit_log.csv"
    new = not f.exists()
    with open(f, "a", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        if new:
            w.writerow(["timestamp", "user", "action", "detail"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), user, action, detail])


def read_log(assignment_id: str) -> list:
    f = assignment_dir(assignment_id) / "audit_log.csv"
    if not f.exists():
        return []
    with open(f, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def zip_assignment(assignment_id: str) -> Path:
    root = assignment_dir(assignment_id)
    archive = shutil.make_archive(str(root.parent / f"{assignment_id}_archive"), "zip", root)
    return Path(archive)
