"""Industry analysis: auto-generated from the nature of business.

* data/industries.json  - built-in Indian industry library (editable)
* Optional: upload Damodaran 'betaemerg.xls' / 'betaIndia' file to override
  indicative betas with current published industry betas (saved as proof).
"""
import io
import json
from datetime import datetime

import pandas as pd
from docx import Document
from docx.shared import Pt

from .config import DATA_DIR, load_settings
from .storage import assignment_dir, log

MACRO_DEFAULT = (
    "India is among the fastest-growing major economies, supported by public capital expenditure, "
    "a large domestic consumption base, digital public infrastructure and manufacturing incentives. "
    "Monetary policy is set by the Reserve Bank of India's Monetary Policy Committee under a flexible "
    "inflation-targeting framework. Key macro risks include global growth slowdown, commodity and crude "
    "oil price volatility, currency movements and geopolitical developments. "
    "[Update this paragraph with the latest RBI Monetary Policy Statement, MoSPI GDP release and Union Budget "
    "highlights as at the valuation date - Settings > macro_overview]"
)


def load_library() -> dict:
    with open(DATA_DIR / "industries.json", encoding="utf-8") as f:
        return json.load(f)


def match_industry(nature_of_business: str) -> list:
    """Return industries ranked by keyword hits in the description."""
    text = (nature_of_business or "").lower()
    scores = []
    for name, d in load_library().items():
        score = sum(len(k) for k in d["keywords"] if k in text)
        if score:
            scores.append((score, name))
    return [n for _, n in sorted(scores, reverse=True)]


def load_damodaran_betas(content: bytes, filename: str) -> pd.DataFrame:
    """Read Damodaran industry beta sheet; returns Industry / Unlevered beta table."""
    xl = pd.read_excel(io.BytesIO(content), sheet_name=None, header=None) \
        if filename.lower().endswith((".xls", ".xlsx")) else {"csv": pd.read_csv(io.BytesIO(content), header=None)}
    for _, raw in xl.items():
        for r in range(min(20, len(raw))):
            hdr = [str(x).strip().lower() for x in raw.iloc[r].tolist()]
            if any("industry" in h for h in hdr) and any("unlevered beta" in h for h in hdr):
                ic = next(i for i, h in enumerate(hdr) if "industry" in h)
                bc = next(i for i, h in enumerate(hdr) if h.startswith("unlevered beta") and "cash" not in h)
                df = raw.iloc[r + 1:, [ic, bc]].dropna()
                df.columns = ["Industry", "Unlevered beta"]
                df["Unlevered beta"] = pd.to_numeric(df["Unlevered beta"], errors="coerce")
                return df.dropna()
    raise ValueError("Could not find 'Industry Name' and 'Unlevered beta' columns.")


def build_analysis(industry_name: str, nature_of_business: str, client_name: str,
                   beta_override: float = None, beta_source: str = "") -> dict:
    lib = load_library()
    d = lib[industry_name]
    settings = load_settings()
    beta = beta_override if beta_override else d["indicative_unlevered_beta"]
    src = beta_source or ("Indicative value from tool library - replace with current Damodaran "
                          "Emerging Markets / India industry beta or comparable-company regression beta")
    sections = {
        "Macro-economic overview (India)": settings.get("macro_overview") or MACRO_DEFAULT,
        "Industry overview": d["overview"],
        "Key growth drivers": d["drivers"],
        "Key risks and challenges": d["risks"],
        "Regulatory environment": "Principal regulators / authorities: " + ", ".join(d["regulators"]) + ".",
        "Key performance indicators tracked": d["kpis"],
        "Position of the subject company": (
            f"{client_name} is engaged in: {nature_of_business}. Its performance has been analysed against "
            f"the industry KPIs above. [Staff to add: market share, competitive position, key customers / "
            f"suppliers, and how the company compares with peers on the KPIs.]"),
        "Implications for valuation": [
            f"Preferred approaches for this industry: {'; '.join(d['preferred_approaches'])}.",
            f"Unlevered (asset) beta adopted for the industry: {beta:.2f} ({src}).",
            "Industry risks above have been considered in the projections and, where not captured in cash flows, "
            "in the company-specific risk premium.",
        ],
    }
    return {"industry": industry_name, "beta_unlevered": beta, "beta_source": src,
            "preferred_approaches": d["preferred_approaches"], "sections": sections,
            "generated_on": datetime.now().isoformat(timespec="seconds")}


def save_analysis_docx(assignment_id: str, analysis: dict) -> str:
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)
    doc.add_heading(f"Industry Analysis - {analysis['industry']}", 0)
    for title, body in analysis["sections"].items():
        doc.add_heading(title, 2)
        if isinstance(body, list):
            for b in body:
                doc.add_paragraph(b, style="List Bullet")
        else:
            doc.add_paragraph(body)
    folder = assignment_dir(assignment_id) / "06_Industry_Analysis"
    folder.mkdir(parents=True, exist_ok=True)
    name = f"Industry_Analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    doc.save(folder / name)
    log(assignment_id, "INDUSTRY", name)
    return name
