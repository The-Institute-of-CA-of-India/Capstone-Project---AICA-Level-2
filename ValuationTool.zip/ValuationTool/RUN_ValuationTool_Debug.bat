@echo off
rem Same as RUN_ValuationTool.bat but keeps a console window open so any
rem error message is visible. Use this if the tool does not open.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call "%~dp0INSTALL_Requirements.bat"
".venv\Scripts\python.exe" check_setup.py
".venv\Scripts\python.exe" gui_app.py
echo.
echo Exit code %errorlevel%. If there was an error, see error_log.txt in this folder.
pause
