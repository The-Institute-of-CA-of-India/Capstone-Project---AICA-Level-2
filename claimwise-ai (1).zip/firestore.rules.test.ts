/**
 * ClaimWise AI — Firestore Security Rules Adversarial Test Specification
 * Covers the Dirty Dozen payloads against firestore.rules invariants.
 */

export const DIRTY_DOZEN_TESTS = [
  {
    name: '1. Unauthenticated write to expenseClaims is denied',
    auth: null,
    path: '/expenseClaims/claim_1',
    op: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '2. Unverified email write to expenseClaims is denied',
    auth: { uid: 'u1', email_verified: false },
    path: '/expenseClaims/claim_1',
    op: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '3. Oversized ID poisoning (>128 chars) is denied',
    auth: { uid: 'u1', email_verified: true },
    path: `/users/${'a'.repeat(200)}`,
    op: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '4. Shadow field injection (isSuperAdmin) on users is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/users/user_1',
    op: 'create',
    payload: { isSuperAdmin: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '5. Identity spoofing (mismatched ownerUid) is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/claim_1',
    op: 'create',
    payload: { ownerUid: 'victim_uid' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '6. Negative totalAmount on expenseClaims is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/claim_1',
    op: 'create',
    payload: { totalAmount: -500 },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '7. Invalid status enum on expenseClaims is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/claim_1',
    op: 'create',
    payload: { status: 'AutoPaid' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '8. Orphaned expense line without parent claim is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/nonexistent/lines/line_1',
    op: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '9. Modifying terminal Paid claim as non-admin is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/paid_claim',
    op: 'update',
    payload: { status: 'Draft' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '10. Mutating immutable claimNo on update is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/expenseClaims/claim_1',
    op: 'update',
    payload: { claimNo: 'EXP-2026-9999' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '11. Mutating immutable auditTrail document is denied',
    auth: { uid: 'u1', email_verified: true },
    path: '/auditTrail/audit_1',
    op: 'update',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '12. Listing another tenant expenseClaims is denied',
    auth: { uid: 'u2', email_verified: true },
    path: '/expenseClaims',
    op: 'list',
    expected: 'PERMISSION_DENIED',
  },
];
