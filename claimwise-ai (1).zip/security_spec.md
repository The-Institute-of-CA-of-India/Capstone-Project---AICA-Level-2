# ClaimWise AI — Firestore Security Specification

## 1. Data Invariants
1. Every document ID must pass `isValidId(id)` (`^[a-zA-Z0-9_-]+$`, `<= 128` chars).
2. Every write requires an authenticated, email-verified Firebase user (`request.auth != null && request.auth.token.email_verified == true`).
3. Every record carries `ownerUid` matching the authenticated tenant/presenter UID (`request.auth.uid`) or verified admin (`akshay.burde@gmail.com` / admin doc), preventing cross-tenant read/write scraping.
4. `expenseClaims/{claimId}/lines/{lineId}` and `expenseClaims/{claimId}/approvalLogs/{logId}` enforce the Master Gate pattern by verifying the parent claim exists via `get()` and checking `ownerUid == request.auth.uid` or `isAdmin()`.
5. `Paid` and `Rejected` claims are terminal states locked against non-admin updates.
6. `auditTrail` and `approvalLogs` are append-only (`allow update, delete: if false` for non-admins).
7. `allow list` queries strictly enforce `resource.data.ownerUid == request.auth.uid || isAdmin()` so no client can list another user's private workspace records.

## 2. Dirty Dozen Adversarial Payloads
1. Unauthenticated read/write on `/expenseClaims/claim-1`.
2. Unverified email (`email_verified: false`) attempting create on `/expenseClaims/claim-1`.
3. Oversized 1.5KB document ID poisoning on `/users/{id}`.
4. Shadow field injection (`isSuperAdmin: true`) on `/users/{userId}` create.
5. Identity spoofing (`ownerUid: "other-uid"`) on `/expenseClaims/{claimId}`.
6. Negative `totalAmount` (`-500`) on `/expenseClaims/{claimId}`.
7. Invalid status enum (`status: "AutoPaid"`) on `/expenseClaims/{claimId}`.
8. Orphaned expense line write where parent `/expenseClaims/{claimId}` does not exist.
9. Updating a terminal `Paid` claim back to `Draft` as a standard user.
10. Modifying immutable `claimNo` or `ownerUid` during claim update.
11. Mutating an immutable `auditTrail` document after creation.
12. Querying `/expenseClaims` owned by another `ownerUid` via list.
