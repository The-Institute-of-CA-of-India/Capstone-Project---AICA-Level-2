# ClaimWise AI — 12-Minute Capstone PowerPoint Presentation Plan

This plan delivers a polished, 11-slide widescreen PowerPoint presentation (`.pptx`) tailored for a strict 12-minute capstone defense (including a dedicated 2-minute live demo slot), covering every AI, deterministic rule engine, security, persistence, and PWA technical solution built into ClaimWise AI.

---

### User Review & Critical Decisions

> [!IMPORTANT] All key scope, format, and pacing decisions were confirmed during interactive clarification and are locked in below.

-   **Confirmed Decision 1 (Delivery Format)**: Generate a standalone, downloadable `.pptx` PowerPoint file directly (no in-app slide viewer), paired with a direct one-click download link inside the application so the deck can be retrieved immediately from the browser.
-   **Confirmed Decision 2 (Slide Budget & Live Demo)**: Structure the deck into **11 cohesive slides** paced to **12:00 minutes total**, allocating **10:00 minutes** across 10 narrative/technical slides and a dedicated **2:00-minute live demo slot** (Slide 9).
-   **Confirmed Decision 3 (Speaker Notes & Timing)**: Embed explicit **per-slide time budgets** on every slide header alongside complete **PowerPoint Speaker Notes** containing talking points, transition cues, and live demo choreography.

---

### 1. Overview & Core Concept

-   **What It Does**: Produces a ready-to-present, 16:9 executive and technical PowerPoint deck explaining the business problem, end-to-end architecture, AI document processing, deterministic compliance rules, fraud/anomaly detection, analytics & conversational copilot, security/PWA engineering, and measurable operational ROI of ClaimWise AI.
-   **Target Audience / Persona**: Capstone evaluation panel, finance/enterprise stakeholders, and technical reviewers assessing both product impact and engineering rigor within a tight 12-minute window.
-   **Key Value**: Eliminates generic bullet-heavy slides by pairing ClaimWise AI's exact visual identity with structured architecture diagrams, native comparison tables, grounded system figures (`60` claims, `60` policy rules, `20` users, `6` Indian offices), and synchronized speaker timing cues.

---

### 2. User Experience & Visual Design

-   **Deck Visual Language & Theme Consistency**:
    -   *Aesthetic Direction*: Crisp executive SaaS & enterprise financial governance deck matching the live ClaimWise AI application—clean layouts, generous whitespace, hairline borders, and zero cluttered clip-art.
    -   *Color Palette*:
        -   **Canvas (`60%`)**: Warm Stone (`#F2EFE7`) on content slides; Steel Cobalt (`#3368A0`) cover/closing anchor slides for strong opening and closing bookends.
        -   **Structural Surfaces (`30%`)**: Crisp White (`#FFFFFF`) elevated panels with subtle Slate hairline outlines (`#CBD5E1`) and Sage Mist (`#C8DFDB`) callout highlights.
        -   **Accents & Semantics (`10%`)**: Steel Cobalt (`#3368A0`), Slate Azure (`#66A3BF`), and strictly semantic state hues—Emerald (`#16A34A`) for verified/pass, Amber (`#D97706`) for review warnings, and Crimson (`#DC2626`) for policy exceptions and risk alerts.
    -   *Typography & Hierarchy*: Clean sans-serif display/body hierarchy (`Plus Jakarta Sans` / `Segoe UI` fallback for universal PowerPoint compatibility) paired with monospace tabular figures (`JetBrains Mono` / `Consolas`) for INR values, compliance scores, and slide timing indicators.
-   **Consistent Slide Chrome & Pacing**:
    -   Every content slide features a consistent top header zone (section category label + clear action-oriented headline + top-right time-budget badge, e.g., `01:15 · Cumulative 04:00`), a structured multi-column or diagram body, and a quiet footer carrying the capstone attribution (`ClaimWise AI – AICA Level 2 Capstone Project | Developed by CA Akshay Burde (#168212)`) and slide index (`1 / 11` through `11 / 11`).
-   **Visual Variety Across the 11 Slides**:
    -   Alternates purposefully between a bold full-bleed cover, split KPI/problem layouts, 3-tier system architecture block diagrams, 6-stage pipeline flows, rule-matrix/scoring callouts, side-by-side comparison tables, and a timed live-demo runbook card so no two consecutive slides feel repetitive.

---

### 3. Key Product Decisions & Trade-Offs

-   **Decision 1: Programmatic Native `.pptx` Generation (`pptxgenjs`)**
    -   *Chosen Approach*: Generate the PowerPoint file programmatically using `pptxgenjs` so every text box, native table, shape, connector, color token, and Speaker Note is editable directly in Microsoft PowerPoint and Google Slides.
    -   *Why*: Native PowerPoint objects remain crisp at any zoom level and allow the presenter to tweak wording or timing right before presenting, unlike flattened image-based slides.
    -   *Alternatives Considered*: Building an HTML/React slide viewer or exporting screenshots to PDF—rejected per the user's choice for a real `.pptx` file only.
-   **Decision 2: Strict 12-Minute Time Allocation (11 Slides = 10 Min Talk + 2 Min Demo)**
    -   *Chosen Approach*: Assign explicit per-slide durations (`0:45` to `1:15` on narrative/technical slides plus `2:00` on the Live Demo slide) totaling exactly `12:00`, with a crisp presenter script in each slide's Notes pane.
    -   *Why*: Technical capstone presentations routinely run over time during deep dives; embedding concrete time checkpoints and concise slide copy keeps delivery sharp and leaves room for live product proof.
-   **Decision 3: Direct Browser Download Integration**
    -   *Chosen Approach*: Place the compiled `.pptx` in the app's static public assets directory and expose a subtle `"Download Capstone Deck (.pptx)"` button on the app's existing `How AI Works` page.
    -   *Why*: Ensures effortless one-click retrieval from the running web workspace without cluttering the login screen or creating an unwanted in-app slide viewer.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

-   **Presentation Generation & Delivery Flow**:

```
┌───────────────────────────────────────────────────────────────────────────┐
│                   ClaimWise AI Codebase (Ground Truth)                    │
│  Gemini API Routes · Policy Engine · Risk Engine · Firestore Rules · PWA  │
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                Programmatic PPTX Builder (pptxgenjs Engine)               │
│  11 Widescreen 16:9 Slides · Native Tables & Diagrams · Theme Tokens      │
│  Per-Slide Time Budgets (Total 12:00) · Embedded Speaker Notes Script     │
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│             Static Public Asset (.pptx) & Direct App Download             │
│  Served directly by Vite/Express + 1-Click Download in "How AI Works"     │
└───────────────────────────────────────────────────────────────────────────┘
```

-   **11-Slide Technical Blueprint & 12-Minute Pacing Schedule**:

    | Slide | Title & Focus | Time | Key Technical Solutions Covered |
    | :--- | :--- | :--- | :--- |
    | **01** | **Title & Capstone Overview** | `0:45` | ClaimWise AI identity, Nova Foods India Pvt Ltd context (`60` claims, `60` policy rules, `20` users, `6` cities), AICA Level 2 attribution |
    | **02** | **Problem Statement & Enterprise Context** | `1:00` | Manual receipt entry (5–8 min), Indian GST/GSTIN ITC leakage, Grade G1–G5 & Tier-1/2 policy complexity, duplicate/split-bill leakage, slow Finance turnaround |
    | **03** | **Full-Stack Architecture & Tech Stack** | `1:00` | React 19 + TypeScript + Tailwind CSS v4 + Vite 8 PWA; Express server proxy (`/api/*`); Dual persistence (`localStorage` demo + optional Firebase Auth/Firestore real-time sync) |
    | **04** | **AI Solution 1: Multimodal Receipt IDP** | `1:15` | `@google/genai` server route (`/api/ai/extract-receipt`), structured JSON `responseSchema`, `gemini-3.1-flash-lite` primary + `gemini-4-hydrogen` fallback, 9 extracted fields, High/Med/Low confidence, 15-char GSTIN & 28% GST slab guard, AI-vs-user override audit log |
    | **05** | **AI Solution 2: Deterministic Policy Engine** | `1:15` | Zero-hallucination separation (`expense_policies` lookup by category × grade × city tier), 5 checks (caps, receipt, weekend/2026 Indian holiday calendar, trip dates, pre-approval), mandatory exception justification, 0–100 Compliance Score, AI Pre-Submission Check |
    | **06** | **AI Solution 3: Duplicate, Anomaly & Review Agent** | `1:00` | Cross-claim & intra-claim duplicate matching (exact invoice + fuzzy amount/date/merchant), 4 anomaly heuristics (round numbers, 6-month baseline spike, just-below-limit frequency, split bills), Low/Med/High Risk Indicators, Human-in-the-Loop AI Review Agent |
    | **07** | **AI Solution 4: Analytics & ClaimWise Assistant** | `1:00` | Finance KPI & 7-chart dashboard with Excel/CSV export + Gemini Executive Insights; floating role-aware ClaimWise Assistant grounded in policy rules & live ledger with mandatory source citations |
    | **08** | **Security, Reliability & Desktop PWA** | `1:00` | API key isolation via Express proxy, SHA-256 response caching & 429/503 resilient model fallback, Firebase Eight-Pillar `firestore.rules` (RBAC + payload validation), client-side image compression, installable offline-capable Desktop PWA (`vite-plugin-pwa`) |
    | **09** | **Live Product Demo Walkthrough** | `2:00` | Timed 3-act demo script: (1) Employee receipt IDP + policy exception justification → (2) Manager risk review & approval → (3) Finance AI Review Agent, Analytics & Assistant Q&A |
    | **10** | **Traditional vs. ClaimWise AI Impact** | `1:00` | Side-by-side operational benchmark table across 7 dimensions (entry speed, GST accuracy, policy compliance, fraud prevention, Finance SLA, Q&A, auditability) |
    | **11** | **Engineering Takeaways & Q&A** | `1:00` | Core architectural principles (Deterministic Rules + Generative AI, Human-in-the-Loop governance, Graceful Degradation) + Q&A readiness |

-   **Verification Plan**:
    -   Run the generator script to produce the `.pptx` file, verify structural integrity (all 11 slides, native tables, shapes, and embedded speaker notes present), and verify TypeScript compilation and linting for the download trigger in the app.
