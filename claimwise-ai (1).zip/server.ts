import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'application/pdf',
]);

const EXPENSE_CATEGORIES = [
  'Airfare',
  'Train/Bus',
  'Local Conveyance',
  'Fuel/Mileage',
  'Hotel Accommodation',
  'Meals',
  'Client Entertainment',
  'Telephone/Internet',
  'Training & Conference',
  'Miscellaneous',
];

const PAYMENT_MODES = [
  'Corporate Card',
  'Personal UPI',
  'Personal Card',
  'Cash',
  'NetBanking',
];

const extractionCache = new Map<string, Record<string, unknown>>();

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in server environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function parseDataUrl(dataUrl: string, fallbackMime?: string): { mimeType: string; base64: string } {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return {
      mimeType: match[1].toLowerCase(),
      base64: match[2],
    };
  }
  return {
    mimeType: (fallbackMime || 'image/jpeg').toLowerCase(),
    base64: dataUrl,
  };
}

function validateGstinAndGst(totalAmount: number, gstAmount: number, gstin: string): string[] {
  const warnings: string[] = [];
  const trimmedGstin = (gstin || '').trim().toUpperCase();

  if (trimmedGstin.length > 0) {
    if (trimmedGstin.length !== 15) {
      warnings.push(`GSTIN must be 15 characters (found ${trimmedGstin.length}).`);
    } else if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(trimmedGstin)) {
      warnings.push('GSTIN format does not match standard Indian 15-character GSTIN pattern.');
    }
  }

  if (gstAmount < 0) {
    warnings.push('GST amount cannot be negative.');
  } else if (totalAmount > 0 && gstAmount >= totalAmount) {
    warnings.push('GST amount is equal to or exceeds the total invoice amount.');
  } else if (totalAmount > 0 && gstAmount > 0) {
    const base = totalAmount - gstAmount;
    const effectiveRate = base > 0 ? (gstAmount / base) * 100 : 100;
    if (effectiveRate > 29.5) {
      warnings.push(
        `GST (${effectiveRate.toFixed(1)}% of base) exceeds standard Indian max GST slab (28%).`
      );
    }
  } else if (trimmedGstin.length === 15 && gstAmount === 0 && totalAmount > 0) {
    warnings.push('Valid GSTIN detected on invoice, but extracted GST amount is 0. Please verify.');
  }

  return warnings;
}

function isQuotaOrRateLimitError(err: unknown): boolean {
  const status = (err as { status?: number } | null)?.status;
  if (status === 429) return true;
  const msg = err instanceof Error ? err.message : String(err);
  return msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('Quota exceeded');
}

function isTransientUnavailableError(err: unknown): boolean {
  const status = (err as { status?: number } | null)?.status;
  if (status === 503 || status === 504) return true;
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('overloaded')
  );
}

function formatReadableApiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  const errStatus = (err as { status?: number } | null)?.status;
  if (isQuotaOrRateLimitError(err)) {
    return {
      status: 429,
      message:
        'Gemini API free-tier daily quota exceeded. Select a billing-enabled API key in Settings > Secrets to increase quota; deterministic policy checks and manual entry remain active.',
    };
  }
  if (isTransientUnavailableError(err)) {
    return {
      status: 503,
      message:
        'Gemini AI receipt extraction is temporarily experiencing high demand. Please retry in a few seconds or enter the receipt fields manually below.',
    };
  }
  if (
    errStatus === 403 ||
    raw.includes('PERMISSION_DENIED') ||
    raw.includes('API_KEY_INVALID') ||
    raw.includes('403')
  ) {
    return {
      status: 403,
      message:
        'Gemini API key permission denied or invalid. Please check GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (raw.trim().startsWith('{') || raw.length > 180) {
    return {
      status: 500,
      message: 'Unable to extract receipt via Gemini AI right now. Please retry or enter fields manually.',
    };
  }
  return {
    status: 500,
    message: raw,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'ClaimWise AI' });
  });

  app.post('/api/ai/extract-receipt', async (req, res) => {
    try {
      const { dataUrl, mimeType: rawMime, fileName } = req.body as {
        dataUrl?: string;
        mimeType?: string;
        fileName?: string;
      };

      if (!dataUrl || typeof dataUrl !== 'string') {
        res.status(400).json({ error: 'Receipt file data is required.' });
        return;
      }

      const parsed = parseDataUrl(dataUrl, rawMime);
      const normalizedMime = parsed.mimeType === 'image/jpg' ? 'image/jpeg' : parsed.mimeType;

      if (!ALLOWED_MIME_TYPES.has(normalizedMime)) {
        res.status(400).json({ error: `Unsupported receipt MIME type: ${normalizedMime}` });
        return;
      }

      if (parsed.base64.length > 10 * 1024 * 1024) {
        res.status(400).json({ error: 'Receipt file exceeds 7MB limit.' });
        return;
      }

      const cacheKey = crypto
        .createHash('sha256')
        .update(`${normalizedMime}:${parsed.base64}`)
        .digest('hex');

      const cached = extractionCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      const prompt = `You are an enterprise finance Intelligent Document Processing (IDP) engine for Nova Foods India Pvt Ltd.
Inspect the attached receipt/tax invoice (${fileName || 'receipt'}) carefully and extract structured expense data.

Rules:
- Extract merchant name cleanly (e.g., "Orchid Elite Hotels", "IndiGo Airlines", "Uber India Systems").
- Extract invoice date in YYYY-MM-DD format. If year/date is ambiguous, use your best reading and mark date confidence "Low".
- Extract invoice or bill number (or PNR/booking ref if airline ticket).
- Extract totalAmount (grand total paid) as a number, and gstAmount (sum of CGST + SGST + IGST, or 0 if not shown) as a number.
- Extract vendor 15-character Indian GSTIN if visible (e.g., 36AAAAO1234A1ZM). Leave "" if absent.
- Extract currency code (default "INR" for Indian rupees / ₹ / Rs).
- Infer paymentMode from the receipt if shown ("Corporate Card", "Personal UPI", "Personal Card", "Cash", "NetBanking"), defaulting to "Corporate Card" with "Low" confidence if not printed.
- Classify into exactly ONE of these categories: ${EXPENSE_CATEGORIES.join(', ')}.
- Provide categoryReason as a concise one-line explanation starting with "Classified as <Category> – ...".
- For EVERY field (merchant, date, invoiceNo, totalAmount, gstAmount, gstin, currency, paymentMode, category), assign a confidence score: "High", "Medium", or "Low". Use "Low" if a field is missing, blurry, inferred, or uncertain.`;

      const schemaConfig = {
        type: Type.OBJECT,
        properties: {
          merchant: { type: Type.STRING },
          date: { type: Type.STRING },
          invoiceNo: { type: Type.STRING },
          totalAmount: { type: Type.NUMBER },
          gstAmount: { type: Type.NUMBER },
          gstin: { type: Type.STRING },
          currency: { type: Type.STRING },
          paymentMode: { type: Type.STRING },
          suggestedCategory: { type: Type.STRING },
          categoryReason: { type: Type.STRING },
          fieldConfidence: {
            type: Type.OBJECT,
            properties: {
              merchant: { type: Type.STRING },
              date: { type: Type.STRING },
              invoiceNo: { type: Type.STRING },
              totalAmount: { type: Type.STRING },
              gstAmount: { type: Type.STRING },
              gstin: { type: Type.STRING },
              currency: { type: Type.STRING },
              paymentMode: { type: Type.STRING },
              category: { type: Type.STRING },
            },
            required: [
              'merchant',
              'date',
              'invoiceNo',
              'totalAmount',
              'gstAmount',
              'gstin',
              'currency',
              'paymentMode',
              'category',
            ],
          },
        },
        required: [
          'merchant',
          'date',
          'invoiceNo',
          'totalAmount',
          'gstAmount',
          'gstin',
          'currency',
          'paymentMode',
          'suggestedCategory',
          'categoryReason',
          'fieldConfidence',
        ],
      };

      const callModel = (model: string, thinkingLevel: ThinkingLevel) =>
        ai.models.generateContent({
          model,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: normalizedMime,
                  data: parsed.base64,
                },
              },
              { text: prompt },
            ],
          },
          config: {
            thinkingConfig: { thinkingLevel },
            responseMimeType: 'application/json',
            responseSchema: schemaConfig,
          },
        });

      let response;
      try {
        response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
      } catch (primaryErr) {
        if (isTransientUnavailableError(primaryErr)) {
          await new Promise((r) => setTimeout(r, 900));
          try {
            response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
          } catch (retryErr) {
            if (isQuotaOrRateLimitError(retryErr) || isTransientUnavailableError(retryErr)) {
              response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
            } else {
              throw retryErr;
            }
          }
        } else if (isQuotaOrRateLimitError(primaryErr)) {
          response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
        } else {
          throw primaryErr;
        }
      }

      const rawText = (response.text || '{}')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '');
      const extracted = JSON.parse(rawText);

      const safeCategory = EXPENSE_CATEGORIES.includes(extracted.suggestedCategory)
        ? extracted.suggestedCategory
        : 'Miscellaneous';

      const safePaymentMode = PAYMENT_MODES.includes(extracted.paymentMode)
        ? extracted.paymentMode
        : 'Corporate Card';

      const normalizeConf = (v: unknown): 'High' | 'Medium' | 'Low' => {
        if (v === 'High' || v === 'Medium' || v === 'Low') return v;
        return 'Medium';
      };

      const totalAmount = Number(extracted.totalAmount) || 0;
      const gstAmount = Number(extracted.gstAmount) || 0;
      const gstin = String(extracted.gstin || '').trim().toUpperCase();
      const currency = String(extracted.currency || 'INR').trim().toUpperCase() || 'INR';
      const dateStr = /^\d{4}-\d{2}-\d{2}$/.test(String(extracted.date || ''))
        ? String(extracted.date)
        : new Date().toISOString().slice(0, 10);

      const fieldConfidence = {
        merchant: extracted.merchant ? normalizeConf(extracted.fieldConfidence?.merchant) : 'Low',
        date: /^\d{4}-\d{2}-\d{2}$/.test(String(extracted.date || ''))
          ? normalizeConf(extracted.fieldConfidence?.date)
          : 'Low',
        invoiceNo: extracted.invoiceNo ? normalizeConf(extracted.fieldConfidence?.invoiceNo) : 'Low',
        totalAmount: totalAmount > 0 ? normalizeConf(extracted.fieldConfidence?.totalAmount) : 'Low',
        gstAmount: normalizeConf(extracted.fieldConfidence?.gstAmount),
        gstin: gstin ? normalizeConf(extracted.fieldConfidence?.gstin) : 'Low',
        currency: normalizeConf(extracted.fieldConfidence?.currency),
        paymentMode: normalizeConf(extracted.fieldConfidence?.paymentMode),
        category: normalizeConf(extracted.fieldConfidence?.category),
      };

      const validationWarnings = validateGstinAndGst(totalAmount, gstAmount, gstin);

      const resultPayload = {
        merchant: String(extracted.merchant || '').trim(),
        date: dateStr,
        invoiceNo: String(extracted.invoiceNo || '').trim(),
        totalAmount,
        gstAmount,
        gstin,
        currency,
        paymentMode: safePaymentMode,
        suggestedCategory: safeCategory,
        categoryReason:
          String(extracted.categoryReason || '').trim() ||
          `Classified as ${safeCategory} based on receipt merchant and line items.`,
        fieldConfidence,
        validationWarnings,
      };

      extractionCache.set(cacheKey, resultPayload);
      res.json(resultPayload);
    } catch (err) {
      console.error('Receipt extraction failed:', err);
      const formatted = formatReadableApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/ai/compliance-check', async (req, res) => {
    try {
      const {
        claimHeader,
        lines,
        deterministicSummary,
      } = req.body as {
        claimHeader?: {
          claimNo?: string;
          employeeName?: string;
          grade?: string;
          department?: string;
          destination?: string;
          cityTier?: string;
          tripFromDate?: string;
          tripToDate?: string;
          purpose?: string;
          totalAmount?: number;
          totalGstAmount?: number;
        };
        lines?: {
          lineNumber: number;
          date: string;
          category: string;
          merchant: string;
          amount: number;
          gstAmount: number;
          gstin: string;
          hasReceipt: boolean;
          preApprovalRef?: string;
          justification: string;
          permissibleLimit: number;
          excessAmount: number;
          hasException: boolean;
          issues: {
            code: string;
            severity: string;
            title: string;
            summary: string;
            suggestedFix: string;
          }[];
        }[];
        deterministicSummary?: {
          complianceScore: number;
          exceptionCount: number;
          warningCount: number;
          duplicateClaimNo?: string;
        };
      };

      if (!claimHeader || !Array.isArray(lines) || !deterministicSummary) {
        res.status(400).json({ error: 'Claim header, lines, and deterministic policy summary are required.' });
        return;
      }

      const cacheInput = JSON.stringify({ claimHeader, lines, deterministicSummary });
      const cacheKey = crypto.createHash('sha256').update(`compliance:${cacheInput}`).digest('hex');
      const cached = extractionCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      const prompt = `You are the ClaimWise AI Policy Compliance Advisor for Nova Foods India Pvt Ltd.
Review the expense claim and its DETERMINISTIC policy evaluation results below.

STRICT RULES:
1. ALL monetary limits, permissible caps, excess amounts, and compliance scores come strictly from the corporate expense_policies table and are already computed below.
2. NEVER invent, change, or guess any rupee limits, grade allowances, or policy rules. Cite ONLY the exact numbers provided in the input.
3. For each line with an exception or warning, provide a crisp 1-2 sentence recommendation explaining why it was flagged and what the employee should do (e.g., "Hotel Accommodation limit for Grade G3 in Tier 1 city exceeded. Provide justification or request exception approval.").
4. List prioritized suggested fixes for all issues found across the claim.
5. Keep currency formatted as Indian Rupees (₹) using Indian comma grouping (e.g., ₹8,500).

CLAIM CONTEXT:
${JSON.stringify({ claimHeader, deterministicSummary, lines }, null, 2)}`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          executiveSummary: { type: Type.STRING },
          gstAssessment: { type: Type.STRING },
          lineRecommendations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                lineNumber: { type: Type.INTEGER },
                recommendation: { type: Type.STRING },
              },
              required: ['lineNumber', 'recommendation'],
            },
          },
          prioritizedFixes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                lineNumber: { type: Type.INTEGER },
                issueTitle: { type: Type.STRING },
                severity: { type: Type.STRING },
                suggestedFix: { type: Type.STRING },
              },
              required: ['lineNumber', 'issueTitle', 'severity', 'suggestedFix'],
            },
          },
        },
        required: ['executiveSummary', 'gstAssessment', 'lineRecommendations', 'prioritizedFixes'],
      };

      const callComplianceModel = (model: string, thinkingLevel: ThinkingLevel) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel },
            responseMimeType: 'application/json',
            responseSchema,
          },
        });

      let response;
      try {
        response = await callComplianceModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
      } catch (primaryErr) {
        if (isTransientUnavailableError(primaryErr)) {
          await new Promise((r) => setTimeout(r, 900));
          try {
            response = await callComplianceModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
          } catch (retryErr) {
            if (isQuotaOrRateLimitError(retryErr) || isTransientUnavailableError(retryErr)) {
              response = await callComplianceModel('gemini-4-hydrogen', ThinkingLevel.LOW);
            } else {
              throw retryErr;
            }
          }
        } else if (isQuotaOrRateLimitError(primaryErr)) {
          response = await callComplianceModel('gemini-4-hydrogen', ThinkingLevel.LOW);
        } else {
          throw primaryErr;
        }
      }

      const rawText = (response.text || '{}')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '');
      const parsed = JSON.parse(rawText);

      const payload = {
        complianceScore: Number(deterministicSummary.complianceScore ?? 100),
        executiveSummary: String(parsed.executiveSummary || '').trim(),
        gstAssessment: String(parsed.gstAssessment || '').trim(),
        lineRecommendations: Array.isArray(parsed.lineRecommendations)
          ? parsed.lineRecommendations.map((lr: { lineNumber?: unknown; recommendation?: unknown }) => ({
              lineNumber: Number(lr.lineNumber) || 1,
              recommendation: String(lr.recommendation || '').trim(),
            }))
          : [],
        prioritizedFixes: Array.isArray(parsed.prioritizedFixes)
          ? parsed.prioritizedFixes.map(
              (pf: {
                lineNumber?: unknown;
                issueTitle?: unknown;
                severity?: unknown;
                suggestedFix?: unknown;
              }) => ({
                lineNumber: Number(pf.lineNumber) || 1,
                issueTitle: String(pf.issueTitle || 'Policy Review').trim(),
                severity: pf.severity === 'warning' ? 'warning' : 'exception',
                suggestedFix: String(pf.suggestedFix || '').trim(),
              })
            )
          : [],
      };

      extractionCache.set(cacheKey, payload);
      res.json(payload);
    } catch (err) {
      console.error('Compliance check failed:', err);
      const formatted = formatReadableApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/ai/finance-review-agent', async (req, res) => {
    try {
      const {
        claimHeader,
        lines,
        policyCompliance,
        riskAnalysis,
      } = req.body as {
        claimHeader?: Record<string, unknown>;
        lines?: Record<string, unknown>[];
        policyCompliance?: Record<string, unknown>;
        riskAnalysis?: Record<string, unknown>;
      };

      if (!claimHeader || !Array.isArray(lines) || !policyCompliance || !riskAnalysis) {
        res.status(400).json({
          error: 'Claim header, lines, policy compliance summary, and risk analysis are required.',
        });
        return;
      }

      const cacheInput = JSON.stringify({ claimHeader, lines, policyCompliance, riskAnalysis });
      const cacheKey = crypto.createHash('sha256').update(`finance-agent:${cacheInput}`).digest('hex');
      const cached = extractionCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      const prompt = `You are the ClaimWise AI Finance Review Agent assisting the Finance Controller at Nova Foods India Pvt Ltd.
Perform an end-to-end advisory audit across ALL FOUR dimensions below and draft a recommendation. The human Finance Controller ALWAYS retains the final Verify / Send Back decision.

STRICT RULES:
1. Never invent, alter, or guess policy caps or amounts—use ONLY the deterministic facts provided below.
2. Output recommendation strictly as ONE of:
   - "Approve": All lines compliant, Low risk, no unresolved duplicates or missing receipts/GSTIN issues.
   - "Approve with exception": Minor/justified policy limit or weekend/date exception (or low/medium behavioral note) where receipts & employee justification support exception sign-off.
   - "Send back": Confirmed/likely duplicate claim, split-bill policy evasion, missing mandatory receipt, unverified high-severity anomaly without justification, or GST discrepancy requiring employee correction.
3. Evaluate every pillar clearly in plain English using Indian Rupee formatting (₹1,25,000):
   - pillars.extractionReview: OCR confidence scores, any manual user overrides of AI-extracted fields, receipt presence, and GST/GSTIN consistency.
   - pillars.policyReview: Compliance score, grade/city-tier cap checks, weekend/trip-date/pre-approval checks, and strength of employee justifications.
   - pillars.duplicateAndAnomalyReview: Cross-claim or intra-claim duplicates, round numbers, 6-month category average spikes, near-cap frequency, and split bills.
4. Provide suggestedFinanceComment: a crisp 1-2 sentence remark suitable for the Finance audit log.

EVIDENCE PAYLOAD:
${JSON.stringify({ claimHeader, policyCompliance, riskAnalysis, lines }, null, 2)}`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          recommendation: { type: Type.STRING },
          confidence: { type: Type.STRING },
          executiveReasoning: { type: Type.STRING },
          pillars: {
            type: Type.OBJECT,
            properties: {
              extractionReview: { type: Type.STRING },
              policyReview: { type: Type.STRING },
              duplicateAndAnomalyReview: { type: Type.STRING },
            },
            required: ['extractionReview', 'policyReview', 'duplicateAndAnomalyReview'],
          },
          suggestedFinanceComment: { type: Type.STRING },
        },
        required: [
          'recommendation',
          'confidence',
          'executiveReasoning',
          'pillars',
          'suggestedFinanceComment',
        ],
      };

      const callAgentModel = (model: string, thinkingLevel: ThinkingLevel) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel },
            responseMimeType: 'application/json',
            responseSchema,
          },
        });

      let response;
      try {
        response = await callAgentModel('gemini-3.1-flash-lite', ThinkingLevel.LOW);
      } catch (primaryErr) {
        if (isTransientUnavailableError(primaryErr)) {
          await new Promise((r) => setTimeout(r, 900));
          try {
            response = await callAgentModel('gemini-3.1-flash-lite', ThinkingLevel.LOW);
          } catch (retryErr) {
            if (isQuotaOrRateLimitError(retryErr) || isTransientUnavailableError(retryErr)) {
              response = await callAgentModel('gemini-4-hydrogen', ThinkingLevel.LOW);
            } else {
              throw retryErr;
            }
          }
        } else if (isQuotaOrRateLimitError(primaryErr)) {
          response = await callAgentModel('gemini-4-hydrogen', ThinkingLevel.LOW);
        } else {
          throw primaryErr;
        }
      }

      const rawText = (response.text || '{}')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '');
      const parsed = JSON.parse(rawText);

      const allowedRecs = new Set(['Approve', 'Approve with exception', 'Send back']);
      const safeRecommendation = allowedRecs.has(String(parsed.recommendation))
        ? String(parsed.recommendation)
        : Array.isArray((riskAnalysis as { duplicates?: unknown[] }).duplicates) &&
            (riskAnalysis as { duplicates: unknown[] }).duplicates.length > 0
          ? 'Send back'
          : (policyCompliance as { hasExceptions?: boolean }).hasExceptions
            ? 'Approve with exception'
            : 'Approve';

      const confRaw = String(parsed.confidence || 'Medium');
      const safeConfidence =
        confRaw === 'High' || confRaw === 'Medium' || confRaw === 'Low' ? confRaw : 'Medium';

      const payload = {
        recommendation: safeRecommendation,
        confidence: safeConfidence,
        executiveReasoning: String(parsed.executiveReasoning || '').trim(),
        pillars: {
          extractionReview: String(parsed.pillars?.extractionReview || '').trim(),
          policyReview: String(parsed.pillars?.policyReview || '').trim(),
          duplicateAndAnomalyReview: String(parsed.pillars?.duplicateAndAnomalyReview || '').trim(),
        },
        suggestedFinanceComment: String(parsed.suggestedFinanceComment || '').trim(),
        humanDecisionNote:
          'Advisory draft only — final verification or send-back authority stays with the Finance Controller.',
      };

      extractionCache.set(cacheKey, payload);
      res.json(payload);
    } catch (err) {
      console.error('Finance AI review agent failed:', err);
      const formatted = formatReadableApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/ai/analytics-insights', async (req, res) => {
    try {
      const { filtersSummary, analyticsSnapshot } = req.body as {
        filtersSummary?: Record<string, unknown>;
        analyticsSnapshot?: Record<string, unknown>;
      };

      if (!analyticsSnapshot) {
        res.status(400).json({ error: 'Analytics snapshot is required.' });
        return;
      }

      const cacheInput = JSON.stringify({ filtersSummary, analyticsSnapshot });
      const cacheKey = crypto.createHash('sha256').update(`analytics:${cacheInput}`).digest('hex');
      const cached = extractionCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      const prompt = `You are the ClaimWise AI CFO & Finance Analytics Copilot for Nova Foods India Pvt Ltd.
Generate a concise, high-signal executive management summary for the selected period and filters below.

STRICT RULES:
1. Cite ONLY exact numbers, percentages, departments, categories, and claim figures present in the snapshot below. Never fabricate figures.
2. Format all Rupee amounts using Indian numbering (e.g., ₹1,25,000).
3. Produce:
   - executiveHeadline: 1 sharp executive sentence summarizing spend velocity, pending liability, and compliance posture.
   - keyTrends: 3 short bullet points covering spend trajectory, category/department drivers, and budget utilization.
   - topExceptionsAndRisks: 3 short bullet points covering policy exception rate, top exception causes, duplicate flags, and ageing (>15 / >30 days) bottlenecks.
   - recommendedActions: 3 concrete next actions for Finance Controller / Management.

SELECTED FILTERS:
${JSON.stringify(filtersSummary || {}, null, 2)}

DETERMINISTIC ANALYTICS SNAPSHOT:
${JSON.stringify(analyticsSnapshot, null, 2)}`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          executiveHeadline: { type: Type.STRING },
          keyTrends: { type: Type.ARRAY, items: { type: Type.STRING } },
          topExceptionsAndRisks: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendedActions: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: [
          'executiveHeadline',
          'keyTrends',
          'topExceptionsAndRisks',
          'recommendedActions',
        ],
      };

      const callModel = (model: string, thinkingLevel: ThinkingLevel) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel },
            responseMimeType: 'application/json',
            responseSchema,
          },
        });

      let response;
      try {
        response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
      } catch (primaryErr) {
        if (isTransientUnavailableError(primaryErr)) {
          await new Promise((r) => setTimeout(r, 900));
          try {
            response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.MINIMAL);
          } catch (retryErr) {
            if (isQuotaOrRateLimitError(retryErr) || isTransientUnavailableError(retryErr)) {
              response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
            } else {
              throw retryErr;
            }
          }
        } else if (isQuotaOrRateLimitError(primaryErr)) {
          response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
        } else {
          throw primaryErr;
        }
      }

      const rawText = (response.text || '{}')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '');
      const parsed = JSON.parse(rawText);

      const toStringArray = (val: unknown): string[] =>
        Array.isArray(val) ? val.map((x) => String(x || '').trim()).filter(Boolean) : [];

      const payload = {
        executiveHeadline: String(parsed.executiveHeadline || '').trim(),
        keyTrends: toStringArray(parsed.keyTrends),
        topExceptionsAndRisks: toStringArray(parsed.topExceptionsAndRisks),
        recommendedActions: toStringArray(parsed.recommendedActions),
      };

      extractionCache.set(cacheKey, payload);
      res.json(payload);
    } catch (err) {
      console.error('AI Analytics Insights failed:', err);
      const formatted = formatReadableApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/ai/assistant', async (req, res) => {
    try {
      const { question, history, groundedContext } = req.body as {
        question?: string;
        history?: { role: string; content: string }[];
        groundedContext?: Record<string, unknown>;
      };

      if (!question || !question.trim() || !groundedContext) {
        res.status(400).json({ error: 'Question and grounded context are required.' });
        return;
      }

      const recentHistory = Array.isArray(history) ? history.slice(-4) : [];
      const cacheInput = JSON.stringify({
        q: question.trim().toLowerCase(),
        role: (groundedContext.userContext as { role?: string } | undefined)?.role,
        grade: (groundedContext.userContext as { grade?: string } | undefined)?.grade,
        recentHistory,
        dataScope: groundedContext.dataScope,
      });
      const cacheKey = crypto.createHash('sha256').update(`assistant:${cacheInput}`).digest('hex');
      const cached = extractionCache.get(cacheKey);
      if (cached) {
        res.json(cached);
        return;
      }

      const ai = getGeminiClient();

      const prompt = `You are "ClaimWise Assistant", the enterprise AI finance & policy copilot for Nova Foods India Pvt Ltd.
Answer the user's question accurately using ONLY the grounded policy rules, city-tier table, corporate holidays, and dataset summary provided below.

STRICT RULES:
1. If the user asks about their personal limits (e.g. "What is my hotel limit in Mumbai?"), resolve their grade from userContext.grade, resolve the city tier from cityTierMapping (e.g. Mumbai = Tier 1, Pune = Tier 2), look up the EXACT row in policyRules, and state the exact INR limit, receipt requirement, and pre-approval requirement.
2. If a Finance/Admin user asks a data question (e.g. "Top 3 reasons for policy violations this month" or "Summarise travel spend by department"), answer strictly from dataSummary using exact INR figures (₹), counts, percentages, and claim numbers.
3. If the answer cannot be determined from the provided policyRules or dataSummary (or if an Employee asks about another employee's private claims), state clearly what is outside their role scope or missing.
4. ALWAYS include at least 1 concrete item in "sources" citing the exact policy rule ID / category / grade / city tier OR the exact dataset scope / metric backing your answer.
   - type MUST be one of: "Policy Rule", "Dataset", or "Compliance Engine".
   - label: short title (e.g. "Policy Rule pol-23 · Hotel Accommodation (G2, Tier 1)" or "Finance Analytics · Nov 2026 Exceptions").
   - detail: exact supporting fact (e.g. "Limit ₹5,625/day · Receipt Required: Yes · Pre-Approval: No").

CONVERSATION HISTORY:
${JSON.stringify(recentHistory, null, 2)}

GROUNDED CONTEXT:
${JSON.stringify(groundedContext, null, 2)}

USER QUESTION:
${question.trim()}`;

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          answer: { type: Type.STRING },
          sources: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING },
                label: { type: Type.STRING },
                detail: { type: Type.STRING },
              },
              required: ['type', 'label', 'detail'],
            },
          },
        },
        required: ['answer', 'sources'],
      };

      const callModel = (model: string, thinkingLevel: ThinkingLevel) =>
        ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel },
            responseMimeType: 'application/json',
            responseSchema,
          },
        });

      let response;
      try {
        response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.LOW);
      } catch (primaryErr) {
        if (isTransientUnavailableError(primaryErr)) {
          await new Promise((r) => setTimeout(r, 900));
          try {
            response = await callModel('gemini-3.1-flash-lite', ThinkingLevel.LOW);
          } catch (retryErr) {
            if (isQuotaOrRateLimitError(retryErr) || isTransientUnavailableError(retryErr)) {
              response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
            } else {
              throw retryErr;
            }
          }
        } else if (isQuotaOrRateLimitError(primaryErr)) {
          response = await callModel('gemini-4-hydrogen', ThinkingLevel.LOW);
        } else {
          throw primaryErr;
        }
      }

      const rawText = (response.text || '{}')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '');
      const parsed = JSON.parse(rawText);

      const allowedTypes = new Set(['Policy Rule', 'Dataset', 'Compliance Engine']);
      const rawSources = Array.isArray(parsed.sources) ? parsed.sources : [];
      const sources = rawSources
        .map((s: { type?: unknown; label?: unknown; detail?: unknown }) => ({
          type: allowedTypes.has(String(s.type)) ? String(s.type) : 'Dataset',
          label: String(s.label || 'Grounded Source').trim(),
          detail: String(s.detail || '').trim(),
        }))
        .filter((s: { label: string; detail: string }) => s.label || s.detail);

      if (sources.length === 0) {
        sources.push({
          type: 'Dataset',
          label: String(groundedContext.dataScope || 'Nova Foods Policy & Claims Store'),
          detail: 'Derived from corporate expense_policies and live claims ledger.',
        });
      }

      const payload = {
        answer: String(parsed.answer || '').trim(),
        sources,
      };

      extractionCache.set(cacheKey, payload);
      res.json(payload);
    } catch (err) {
      console.error('ClaimWise Assistant failed:', err);
      const formatted = formatReadableApiError(err);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.get('/ClaimWise_AI_Capstone_Presentation.pptx', (_req, res) => {
    const publicPptx = path.resolve(__dirname, 'public', 'ClaimWise_AI_Capstone_Presentation.pptx');
    const distPptx = path.resolve(__dirname, 'dist', 'ClaimWise_AI_Capstone_Presentation.pptx');
    const filePath = fs.existsSync(publicPptx) ? publicPptx : distPptx;
    if (!fs.existsSync(filePath)) {
      res.status(404).send('Presentation file not found.');
      return;
    }
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation'
    );
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="ClaimWise_AI_Capstone_Presentation.pptx"'
    );
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(filePath);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, ws: false },
      appType: 'spa',
    });

    // Vite 8 injects /@vite/client and unconditionally calls transport.connect() even when hmr/ws are false.
    // Intercept /@vite/client in dev middleware mode so CSS/style helpers stay intact without opening a failing WebSocket.
    app.use('/@vite/client', (req, res, next) => {
      req.headers['accept-encoding'] = 'identity';
      const chunks: Buffer[] = [];
      const origWrite = res.write.bind(res);
      const origEnd = res.end.bind(res);

      res.write = ((chunk: unknown, ...args: unknown[]) => {
        if (chunk) {
          chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)));
        }
        return true;
      }) as typeof res.write;

      res.end = ((chunk?: unknown, ...args: unknown[]) => {
        if (chunk) {
          chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)));
        }
        let body = Buffer.concat(chunks).toString('utf8');
        if (body.includes('transport.connect(createHMRHandler(handleMessage))')) {
          body = body
            .replace('ws.send(JSON.stringify(data));', 'ws?.send(JSON.stringify(data));')
            .replace(
              'transport.connect(createHMRHandler(handleMessage));',
              '/* HMR WebSocket disabled */'
            );
          res.removeHeader('Content-Length');
          res.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));
        }
        res.write = origWrite;
        res.end = origEnd;
        return origEnd(body, ...(args as []));
      }) as typeof res.end;

      next();
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ClaimWise AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
