import {
  CostCentre,
  Department,
  ExpenseClaim,
  ExpensePolicy,
  INDIAN_CITIES,
  UserProfile,
} from '../types/claimwise';
import {
  computeFinanceAnalytics,
  DEFAULT_ANALYTICS_FILTERS,
} from './analyticsEngine';
import { formatDateDDMMMYYYY, formatINR } from './formatters';
import { INDIAN_CORPORATE_HOLIDAYS_2026 } from './policyEngine';
import { analyzeClaimRisk } from './riskEngine';

export interface AssistantGroundedPayload {
  userContext: {
    name: string;
    employeeCode: string;
    role: string;
    grade: string;
    department: string;
    costCentre: string;
    location: string;
  };
  cityTierMapping: { city: string; tier: string }[];
  policyRules: {
    policyId: string;
    category: string;
    grade: string;
    cityTier: string;
    limitPerDay: number;
    limitPerUnit: number;
    requiresReceipt: boolean;
    requiresPreApproval: boolean;
    gstEligible: boolean;
    notes: string;
  }[];
  corporateHolidays2026: { date: string; name: string }[];
  dataScope: string;
  dataSummary: Record<string, unknown>;
}

export function buildAssistantGroundedPayload(params: {
  currentUser: UserProfile;
  claims: ExpenseClaim[];
  policies: ExpensePolicy[];
  departments: Department[];
  costCentres: CostCentre[];
  referenceDate?: string;
}): AssistantGroundedPayload {
  const {
    currentUser,
    claims,
    policies,
    departments,
    costCentres,
    referenceDate = new Date().toISOString().slice(0, 10),
  } = params;

  const isFinanceOrAdmin =
    currentUser.role === 'finance' || currentUser.role === 'admin';
  const isManager = currentUser.role === 'manager';

  // Policy rules: include all for Finance/Admin/Manager, or user's grade first + full reference for Employee
  const orderedPolicies = [...policies].sort((a, b) => {
    const aOwn = a.grade === currentUser.grade ? 0 : 1;
    const bOwn = b.grade === currentUser.grade ? 0 : 1;
    if (aOwn !== bOwn) return aOwn - bOwn;
    return a.category.localeCompare(b.category);
  });

  const policyRules = orderedPolicies.map((p) => ({
    policyId: p.id,
    category: p.category,
    grade: p.grade,
    cityTier: p.cityTier,
    limitPerDay: p.limitPerDay,
    limitPerUnit: p.limitPerUnit,
    requiresReceipt: p.requiresReceipt,
    requiresPreApproval: p.requiresPreApproval,
    gstEligible: p.gstEligible,
    notes: p.notes,
  }));

  let dataScope = 'Personal Employee Claims & Policy Rules';
  let dataSummary: Record<string, unknown> = {};

  if (isFinanceOrAdmin) {
    dataScope = 'Full Organization Finance & Compliance Dataset (Nova Foods India Pvt Ltd)';
    const ytdAnalytics = computeFinanceAnalytics(
      claims,
      departments,
      costCentres,
      policies,
      DEFAULT_ANALYTICS_FILTERS,
      referenceDate
    );

    const monthStart = `${referenceDate.slice(0, 7)}-01`;
    const mtdAnalytics = computeFinanceAnalytics(
      claims,
      departments,
      costCentres,
      policies,
      {
        ...DEFAULT_ANALYTICS_FILTERS,
        dateFrom: monthStart,
        dateTo: referenceDate.slice(0, 7) + '-31',
      },
      referenceDate
    );

    const riskyClaims = claims
      .map((c) => ({
        claimNo: c.claimNo,
        employeeName: c.employeeName,
        department: c.department,
        status: c.status,
        amount: formatINR(c.totalAmount),
        risk: analyzeClaimRisk(c, claims, policies),
      }))
      .filter((x) => x.risk.riskLevel === 'High' || x.risk.duplicates.length > 0)
      .slice(0, 12)
      .map((x) => ({
        claimNo: x.claimNo,
        employeeName: x.employeeName,
        department: x.department,
        status: x.status,
        amount: x.amount,
        riskLevel: x.risk.riskLevel,
        riskScore: x.risk.riskScore,
        reasons: x.risk.plainEnglishReasons.slice(0, 2),
      }));

    dataSummary = {
      referenceDate: formatDateDDMMMYYYY(referenceDate),
      totalClaimsInSystem: claims.length,
      ytdKpis: {
        totalSpendYtd: formatINR(ytdAnalytics.kpis.totalSpendYtd),
        totalSpendMtd: formatINR(ytdAnalytics.kpis.totalSpendMtd),
        mtdMonth: ytdAnalytics.kpis.mtdMonthLabel,
        pendingLiability: formatINR(ytdAnalytics.kpis.pendingLiability),
        pendingClaimCount: ytdAnalytics.kpis.pendingCount,
        avgApprovalTurnaroundDays: ytdAnalytics.kpis.avgApprovalTurnaroundDays,
        policyExceptionRatePct: ytdAnalytics.kpis.policyExceptionRatePct,
        exceptionClaimCount: ytdAnalytics.kpis.exceptionClaimCount,
        duplicateFlaggedCount: ytdAnalytics.kpis.duplicateFlaggedCount,
        highRiskCount: ytdAnalytics.kpis.highRiskCount,
      },
      currentMonthBreakdown: {
        monthLabel: mtdAnalytics.kpis.mtdMonthLabel,
        totalSpend: formatINR(mtdAnalytics.kpis.totalSpendYtd),
        claimCount: mtdAnalytics.filteredClaims.length,
        exceptionRatePct: mtdAnalytics.kpis.policyExceptionRatePct,
        topExceptionReasonsThisMonth: mtdAnalytics.exceptionBreakdown.slice(0, 5).map((e) => ({
          reason: e.label,
          occurrences: e.count,
          sharePct: e.sharePct,
          impactAmount: formatINR(e.impactAmount),
        })),
      },
      overallTopExceptionReasons: ytdAnalytics.exceptionBreakdown.map((e) => ({
        reason: e.label,
        occurrences: e.count,
        sharePct: e.sharePct,
        impactAmount: formatINR(e.impactAmount),
      })),
      spendByDepartment: ytdAnalytics.spendByDepartment.map((d) => ({
        department: d.department,
        actualSpend: formatINR(d.amount),
        annualBudget: formatINR(d.budget),
        utilizationPct: d.utilizationPct,
        claimCount: d.claimCount,
      })),
      spendByCostCentre: ytdAnalytics.spendByCostCentre.map((cc) => ({
        costCentre: cc.costCentre,
        name: cc.name,
        department: cc.department,
        spend: formatINR(cc.amount),
        claimCount: cc.claimCount,
      })),
      spendByCategory: ytdAnalytics.spendByCategory.map((cat) => ({
        category: cat.category,
        spend: formatINR(cat.amount),
        sharePct: cat.sharePct,
        lineCount: cat.lineCount,
      })),
      monthlySpendTrend: ytdAnalytics.monthlyTrend.map((m) => ({
        month: m.label,
        totalSpend: formatINR(m.totalSpend),
        paidSpend: formatINR(m.paidSpend),
        claimCount: m.claimCount,
      })),
      topClaimants: ytdAnalytics.topClaimants.slice(0, 5).map((tc) => ({
        employeeName: tc.employeeName,
        department: tc.department,
        grade: tc.grade,
        totalSpend: formatINR(tc.totalSpend),
        claimCount: tc.claimCount,
      })),
      pendingAgeing: ytdAnalytics.pendingAgeing.map((b) => ({
        bucket: b.bucket,
        claimCount: b.count,
        liability: formatINR(b.amount),
      })),
      highRiskAndDuplicateClaims: riskyClaims,
    };
  } else if (isManager) {
    dataScope = `Direct Reportees & Personal Claims (${currentUser.department})`;
    const teamClaims = claims.filter(
      (c) => c.managerId === currentUser.id || c.employeeId === currentUser.id
    );
    const pendingApproval = teamClaims.filter((c) => c.status === 'Submitted');
    dataSummary = {
      teamClaimCount: teamClaims.length,
      pendingManagerApprovalCount: pendingApproval.length,
      pendingClaims: pendingApproval.slice(0, 10).map((c) => ({
        claimNo: c.claimNo,
        employeeName: c.employeeName,
        destination: c.destination,
        amount: formatINR(c.totalAmount),
        hasPolicyViolation: c.hasPolicyViolation,
        isDuplicateFlagged: c.isDuplicateFlagged,
      })),
    };
  } else {
    const ownClaims = claims.filter((c) => c.employeeId === currentUser.id);
    dataSummary = {
      yourClaimCount: ownClaims.length,
      totalClaimedYtd: formatINR(
        ownClaims
          .filter((c) => c.status !== 'Draft' && c.status !== 'Rejected')
          .reduce((s, c) => s + c.totalAmount, 0)
      ),
      pendingCount: ownClaims.filter((c) =>
        ['Submitted', 'Manager Approved', 'Sent Back'].includes(c.status)
      ).length,
      recentClaims: ownClaims.slice(0, 6).map((c) => ({
        claimNo: c.claimNo,
        destination: c.destination,
        tripDates: `${formatDateDDMMMYYYY(c.tripFromDate)} to ${formatDateDDMMMYYYY(c.tripToDate)}`,
        amount: formatINR(c.totalAmount),
        status: c.status,
        hasPolicyViolation: c.hasPolicyViolation,
      })),
    };
  }

  return {
    userContext: {
      name: currentUser.name,
      employeeCode: currentUser.employeeCode,
      role: currentUser.role,
      grade: currentUser.grade,
      department: currentUser.department,
      costCentre: currentUser.costCentre,
      location: currentUser.location,
    },
    cityTierMapping: INDIAN_CITIES.map((c) => ({ city: c.name, tier: c.tier })),
    policyRules,
    corporateHolidays2026: Object.entries(INDIAN_CORPORATE_HOLIDAYS_2026).map(([date, name]) => ({
      date: formatDateDDMMMYYYY(date),
      name,
    })),
    dataScope,
    dataSummary,
  };
}
