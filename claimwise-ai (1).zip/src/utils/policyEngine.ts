import {
  CityTier,
  ClaimComplianceIssueItem,
  ClaimComplianceSummary,
  ExpenseClaim,
  ExpenseLine,
  ExpensePolicy,
  Grade,
  LineComplianceEvaluation,
  PolicyCheckIssue,
  PolicyFlag,
} from '../types/claimwise';
import {
  detectDuplicateClaim,
  formatDateDDMMMYYYY,
  formatINR,
  validateGstAndGstin,
} from './formatters';

export const INDIAN_CORPORATE_HOLIDAYS_2026: Record<string, string> = {
  '2026-01-26': 'Republic Day',
  '2026-03-04': 'Holi',
  '2026-03-21': 'Id-ul-Fitr',
  '2026-04-03': 'Good Friday',
  '2026-05-01': 'Maharashtra Day / Labour Day',
  '2026-08-15': 'Independence Day',
  '2026-09-14': 'Ganesh Chaturthi',
  '2026-10-02': 'Gandhi Jayanti',
  '2026-10-20': 'Dussehra',
  '2026-11-08': 'Diwali (Lakshmi Pujan)',
  '2026-12-25': 'Christmas Day',
};

const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function checkWeekendOrHoliday(dateStr: string): {
  isWeekendOrHoliday: boolean;
  isWeekend: boolean;
  isHoliday: boolean;
  label: string;
} {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return { isWeekendOrHoliday: false, isWeekend: false, isHoliday: false, label: '' };
  }
  const [y, m, d] = dateStr.split('-').map(Number);
  const utcDay = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  const isWeekend = utcDay === 0 || utcDay === 6;
  const holidayName = INDIAN_CORPORATE_HOLIDAYS_2026[dateStr];
  const isHoliday = Boolean(holidayName);

  if (isHoliday && isWeekend) {
    return {
      isWeekendOrHoliday: true,
      isWeekend: true,
      isHoliday: true,
      label: `${holidayName} (${WEEKDAY_NAMES[utcDay]})`,
    };
  }
  if (isHoliday) {
    return {
      isWeekendOrHoliday: true,
      isWeekend: false,
      isHoliday: true,
      label: `Corporate Holiday (${holidayName})`,
    };
  }
  if (isWeekend) {
    return {
      isWeekendOrHoliday: true,
      isWeekend: true,
      isHoliday: false,
      label: `Weekend (${WEEKDAY_NAMES[utcDay]})`,
    };
  }
  return { isWeekendOrHoliday: false, isWeekend: false, isHoliday: false, label: '' };
}

export function findMatchingPolicy(
  category: string,
  grade: Grade,
  cityTier: CityTier,
  policies: ExpensePolicy[]
): ExpensePolicy | undefined {
  return (
    policies.find(
      (p) => p.category === category && p.grade === grade && p.cityTier === cityTier
    ) ||
    policies.find(
      (p) => p.category === category && p.grade === grade && p.cityTier === 'All'
    )
  );
}

export function evaluateLineCompliance(
  line: Pick<
    ExpenseLine,
    | 'date'
    | 'category'
    | 'merchant'
    | 'amount'
    | 'gstAmount'
    | 'gstin'
    | 'receiptName'
    | 'receiptUrl'
    | 'preApprovalRef'
    | 'justification'
  >,
  grade: Grade,
  cityTier: CityTier,
  tripFromDate: string,
  tripToDate: string,
  policies: ExpensePolicy[]
): LineComplianceEvaluation {
  const matchedPolicy = findMatchingPolicy(line.category, grade, cityTier, policies);
  const permissibleLimit = matchedPolicy
    ? matchedPolicy.limitPerUnit > 0
      ? matchedPolicy.limitPerUnit
      : matchedPolicy.limitPerDay
    : 0;
  const requiresReceipt = matchedPolicy ? matchedPolicy.requiresReceipt : true;
  const requiresPreApproval = matchedPolicy ? matchedPolicy.requiresPreApproval : false;
  const claimedAmount = Number(line.amount || 0);
  const excessAmount =
    permissibleLimit > 0 && claimedAmount > permissibleLimit
      ? Math.round((claimedAmount - permissibleLimit) * 100) / 100
      : 0;

  const issues: PolicyCheckIssue[] = [];

  // 1. Limit by category / grade / city tier (deterministic from expense_policies)
  if (permissibleLimit > 0 && claimedAmount > permissibleLimit) {
    const tierNote =
      matchedPolicy?.cityTier === 'All' ? `${cityTier} (All Tiers)` : `${cityTier} city`;
    issues.push({
      code: 'LIMIT_EXCEEDED',
      severity: 'exception',
      title: 'Policy Limit Exceeded',
      summary: `${line.category} limit for Grade ${grade} in ${tierNote} exceeded.`,
      suggestedFix: `Provide business justification for the ${formatINR(excessAmount)} excess or reduce claimed amount to ${formatINR(permissibleLimit)} (excess will route to Finance Controller for exception approval).`,
    });
  }

  // 2. Missing receipt
  if (requiresReceipt && !line.receiptName?.trim() && !line.receiptUrl?.trim()) {
    issues.push({
      code: 'MISSING_RECEIPT',
      severity: 'exception',
      title: 'Missing Mandatory Receipt',
      summary: `Supporting tax invoice or receipt is mandatory for ${line.category} under Nova Foods policy.`,
      suggestedFix: 'Upload a PDF, JPG, or PNG receipt, or enter a justification for a lost/unavailable voucher.',
    });
  }

  // 3. Weekend / Holiday expense
  if (line.date) {
    const wh = checkWeekendOrHoliday(line.date);
    if (wh.isWeekendOrHoliday) {
      issues.push({
        code: 'WEEKEND_HOLIDAY',
        severity: 'exception',
        title: wh.isHoliday ? 'Corporate Holiday Expense' : 'Weekend Expense',
        summary: `Expense dated ${formatDateDDMMMYYYY(line.date)} falls on a ${wh.label}.`,
        suggestedFix: `Verify the invoice date or explain the business necessity for ${wh.label} spend in the justification field.`,
      });
    }
  }

  // 4. Expense outside trip dates
  if (
    /^\d{4}-\d{2}-\d{2}$/.test(line.date || '') &&
    /^\d{4}-\d{2}-\d{2}$/.test(tripFromDate || '') &&
    /^\d{4}-\d{2}-\d{2}$/.test(tripToDate || '') &&
    (line.date < tripFromDate || line.date > tripToDate)
  ) {
    issues.push({
      code: 'OUTSIDE_TRIP_DATES',
      severity: 'exception',
      title: 'Outside Trip Dates',
      summary: `Expense date (${formatDateDDMMMYYYY(line.date)}) falls outside trip window (${formatDateDDMMMYYYY(tripFromDate)} to ${formatDateDDMMMYYYY(tripToDate)}).`,
      suggestedFix: `Update the trip start/end dates or invoice date if erroneous, or justify advance/post-trip booking.`,
    });
  }

  // 5. Missing pre-approval
  if (requiresPreApproval && !line.preApprovalRef?.trim()) {
    issues.push({
      code: 'MISSING_PRE_APPROVAL',
      severity: 'exception',
      title: 'Missing Pre-Approval',
      summary: `${line.category} requires prior manager/finance pre-approval for Grade ${grade}.`,
      suggestedFix: `Enter your Pre-Approval Reference ID (e.g., PA-2026-0142) or document emergency approval justification.`,
    });
  }

  // 6. GST / GSTIN consistency check
  const gstCheck = validateGstAndGstin(claimedAmount, line.gstAmount || 0, line.gstin || '');
  if (!gstCheck.gstinValid || !gstCheck.gstConsistent) {
    issues.push({
      code: 'GST_WARNING',
      severity: 'warning',
      title: 'GST / GSTIN Verification Needed',
      summary: gstCheck.warnings.join(' · '),
      suggestedFix: 'Verify the 15-character vendor GSTIN and GST tax breakup against the invoice.',
    });
  }

  const exceptions = issues.filter((i) => i.severity === 'exception');
  const warnings = issues.filter((i) => i.severity === 'warning');
  const hasException = exceptions.length > 0;
  const flag: PolicyFlag = hasException
    ? 'Violation'
    : warnings.length > 0
      ? 'Warning'
      : 'Compliant';

  const reason = issues.map((i) => i.summary).join(' · ');

  let aiRecommendation = '';
  if (hasException) {
    const primary = exceptions[0];
    if (primary.code === 'LIMIT_EXCEEDED') {
      aiRecommendation = `${line.category} limit for Grade ${grade} in ${cityTier} city exceeded. Provide justification or request exception approval.`;
    } else {
      aiRecommendation = `${primary.summary} ${primary.suggestedFix}`;
    }
    if (exceptions.length > 1) {
      aiRecommendation += ` (+${exceptions.length - 1} additional policy check${exceptions.length > 2 ? 's' : ''} flagged)`;
    }
  } else if (warnings.length > 0) {
    aiRecommendation = warnings[0].suggestedFix;
  }

  return {
    flag,
    hasException,
    claimedAmount,
    permissibleLimit,
    excessAmount,
    requiresReceipt,
    requiresPreApproval,
    matchedPolicyId: matchedPolicy?.id,
    matchedPolicyNotes: matchedPolicy?.notes,
    issues,
    exceptionCodes: issues.map((i) => i.code),
    reason,
    aiRecommendation,
  };
}

export function evaluateClaimCompliance(
  claimInput: {
    tripFromDate: string;
    tripToDate: string;
    employeeId?: string;
    lines: Pick<
      ExpenseLine,
      | 'date'
      | 'category'
      | 'merchant'
      | 'amount'
      | 'gstAmount'
      | 'gstin'
      | 'invoiceNo'
      | 'receiptName'
      | 'receiptUrl'
      | 'preApprovalRef'
      | 'justification'
    >[];
  },
  grade: Grade,
  cityTier: CityTier,
  policies: ExpensePolicy[],
  existingClaims: ExpenseClaim[],
  excludeClaimId?: string
): ClaimComplianceSummary {
  const lineEvaluations = claimInput.lines.map((line) =>
    evaluateLineCompliance(
      line,
      grade,
      cityTier,
      claimInput.tripFromDate,
      claimInput.tripToDate,
      policies
    )
  );

  const dupResult = detectDuplicateClaim(
    claimInput.lines,
    existingClaims,
    excludeClaimId,
    claimInput.employeeId
  );
  if (dupResult.isDuplicate && lineEvaluations.length > 0) {
    const first = lineEvaluations[0];
    const dupIssue: PolicyCheckIssue = {
      code: 'DUPLICATE_CLAIM',
      severity: 'exception',
      title: 'Potential Duplicate Claim',
      summary: `Line details match existing claim ${dupResult.matchedClaimNo}.`,
      suggestedFix: `Verify invoice number and date; remove duplicate entry or justify if split billing.`,
    };
    first.issues = [dupIssue, ...first.issues];
    first.hasException = true;
    first.flag = 'Violation';
    first.exceptionCodes = Array.from(new Set(['DUPLICATE_CLAIM', ...first.exceptionCodes]));
    first.reason = first.issues.map((i) => i.summary).join(' · ');
    first.aiRecommendation = `${dupIssue.summary} ${dupIssue.suggestedFix}`;
  }

  const issues: ClaimComplianceIssueItem[] = [];
  const missingJustificationLines: number[] = [];
  let deduction = 0;

  lineEvaluations.forEach((ev, idx) => {
    const line = claimInput.lines[idx];
    const lineNum = idx + 1;

    if (ev.hasException && !line.justification?.trim()) {
      missingJustificationLines.push(lineNum);
    }

    for (const iss of ev.issues) {
      issues.push({
        lineNumber: lineNum,
        merchant: line.merchant || `Line #${lineNum}`,
        category: line.category,
        code: iss.code,
        severity: iss.severity,
        title: iss.title,
        summary: iss.summary,
        suggestedFix: iss.suggestedFix,
      });

      if (iss.code === 'LIMIT_EXCEEDED') {
        const overRatio = ev.permissibleLimit > 0 ? ev.excessAmount / ev.permissibleLimit : 0.25;
        deduction += overRatio > 0.5 ? 25 : 18;
      } else if (iss.code === 'MISSING_RECEIPT') {
        deduction += 20;
      } else if (iss.code === 'MISSING_PRE_APPROVAL') {
        deduction += 15;
      } else if (iss.code === 'OUTSIDE_TRIP_DATES') {
        deduction += 12;
      } else if (iss.code === 'WEEKEND_HOLIDAY') {
        deduction += 8;
      } else if (iss.code === 'DUPLICATE_CLAIM') {
        deduction += 35;
      } else if (iss.code === 'GST_WARNING') {
        deduction += 5;
      }
    }
  });

  const exceptionCount = issues.filter((i) => i.severity === 'exception').length;
  const warningCount = issues.filter((i) => i.severity === 'warning').length;
  const complianceScore = Math.max(0, Math.min(100, 100 - deduction));

  return {
    complianceScore,
    hasExceptions: exceptionCount > 0,
    exceptionCount,
    warningCount,
    lineEvaluations,
    issues,
    duplicateClaimNo: dupResult.matchedClaimNo,
    missingJustificationLines,
  };
}
