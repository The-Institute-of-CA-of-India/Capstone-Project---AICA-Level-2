import {
  CostCentre,
  Department,
  EXPENSE_CATEGORIES,
  ExpenseClaim,
  ExpensePolicy,
} from '../types/claimwise';
import { evaluateClaimCompliance } from './policyEngine';
import { analyzeClaimRisk } from './riskEngine';

export interface AnalyticsFilters {
  dateFrom: string;
  dateTo: string;
  department: string;
  costCentre: string;
  category: string;
  status: string;
}

export const DEFAULT_ANALYTICS_FILTERS: AnalyticsFilters = {
  dateFrom: '2026-06-01',
  dateTo: '2026-11-30',
  department: 'ALL',
  costCentre: 'ALL',
  category: 'ALL',
  status: 'ALL',
};

const SHORT_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatMonthLabel(ym: string): string {
  const [y, m] = ym.split('-');
  const idx = Number(m) - 1;
  if (!y || idx < 0 || idx > 11) return ym;
  return `${SHORT_MONTHS[idx]} ${y}`;
}

function getClaimPrimaryDate(c: ExpenseClaim): string {
  return (c.submittedDate || c.tripToDate || c.tripFromDate || c.createdAt || '').slice(0, 10);
}

function getScopedClaimAmount(c: ExpenseClaim, categoryFilter: string): number {
  if (categoryFilter === 'ALL') return Number(c.totalAmount || 0);
  return c.lines
    .filter((l) => l.category === categoryFilter)
    .reduce((s, l) => s + Number(l.amount || 0), 0);
}

function getScopedClaimGst(c: ExpenseClaim, categoryFilter: string): number {
  if (categoryFilter === 'ALL') return Number(c.totalGstAmount || 0);
  return c.lines
    .filter((l) => l.category === categoryFilter)
    .reduce((s, l) => s + Number(l.gstAmount || 0), 0);
}

function daysBetween(fromIso: string, toIso: string): number {
  if (!/^\d{4}-\d{2}-\d{2}/.test(fromIso) || !/^\d{4}-\d{2}-\d{2}/.test(toIso)) return 0;
  const [y1, m1, d1] = fromIso.slice(0, 10).split('-').map(Number);
  const [y2, m2, d2] = toIso.slice(0, 10).split('-').map(Number);
  const diff = (Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / (1000 * 60 * 60 * 24);
  return Math.max(0, Math.round(diff));
}

export interface FinanceAnalyticsResult {
  filteredClaims: ExpenseClaim[];
  activeSpendClaims: ExpenseClaim[];
  kpis: {
    totalSpendYtd: number;
    totalSpendMtd: number;
    mtdMonthLabel: string;
    totalGstEligible: number;
    pendingLiability: number;
    pendingCount: number;
    avgApprovalTurnaroundDays: number;
    turnaroundSampleSize: number;
    policyExceptionRatePct: number;
    exceptionClaimCount: number;
    duplicateFlaggedCount: number;
    duplicateFlaggedAmount: number;
    highRiskCount: number;
  };
  monthlyTrend: {
    monthKey: string;
    label: string;
    totalSpend: number;
    paidSpend: number;
    claimCount: number;
    exceptionCount: number;
  }[];
  spendByCategory: {
    category: string;
    amount: number;
    gstAmount: number;
    lineCount: number;
    sharePct: number;
  }[];
  spendByDepartment: {
    department: string;
    code: string;
    amount: number;
    claimCount: number;
    budget: number;
    utilizationPct: number;
  }[];
  spendByCostCentre: {
    costCentre: string;
    name: string;
    department: string;
    amount: number;
    claimCount: number;
  }[];
  budgetVsActual: {
    department: string;
    code: string;
    budget: number;
    actual: number;
    variance: number;
    utilizationPct: number;
  }[];
  topClaimants: {
    employeeId: string;
    employeeName: string;
    employeeCode: string;
    department: string;
    grade: string;
    claimCount: number;
    totalSpend: number;
    exceptionCount: number;
  }[];
  exceptionBreakdown: {
    code: string;
    label: string;
    count: number;
    impactAmount: number;
    sharePct: number;
  }[];
  pendingAgeing: {
    bucket: '0-7 days' | '8-15 days' | '16-30 days' | '>30 days';
    count: number;
    amount: number;
    claims: { claimNo: string; employeeName: string; daysPending: number; amount: number; status: string }[];
  }[];
}

const EXCEPTION_LABELS: Record<string, string> = {
  LIMIT_EXCEEDED: 'Policy Limit Exceeded',
  MISSING_RECEIPT: 'Missing Mandatory Receipt',
  WEEKEND_HOLIDAY: 'Weekend / Corporate Holiday',
  OUTSIDE_TRIP_DATES: 'Outside Trip Dates',
  MISSING_PRE_APPROVAL: 'Missing Pre-Approval',
  DUPLICATE_CLAIM: 'Duplicate Invoice / Match',
  GST_WARNING: 'GST / GSTIN Discrepancy',
};

export function computeFinanceAnalytics(
  claims: ExpenseClaim[],
  departments: Department[],
  costCentres: CostCentre[],
  policies: ExpensePolicy[],
  filters: AnalyticsFilters,
  referenceDate = new Date().toISOString().slice(0, 10)
): FinanceAnalyticsResult {
  const filteredClaims = claims.filter((c) => {
    const primaryDate = getClaimPrimaryDate(c);
    if (filters.dateFrom && primaryDate && primaryDate < filters.dateFrom) return false;
    if (filters.dateTo && primaryDate && primaryDate > filters.dateTo) return false;
    if (filters.department !== 'ALL' && c.department !== filters.department) return false;
    if (filters.costCentre !== 'ALL' && c.costCentre !== filters.costCentre) return false;
    if (filters.status !== 'ALL' && c.status !== filters.status) return false;
    if (
      filters.category !== 'ALL' &&
      !c.lines.some((l) => l.category === filters.category)
    ) {
      return false;
    }
    return true;
  });

  const activeSpendClaims =
    filters.status === 'ALL'
      ? filteredClaims.filter((c) => c.status !== 'Draft' && c.status !== 'Rejected')
      : filteredClaims;

  const totalSpendYtd = activeSpendClaims.reduce(
    (s, c) => s + getScopedClaimAmount(c, filters.category),
    0
  );
  const totalGstEligible = activeSpendClaims.reduce(
    (s, c) => s + getScopedClaimGst(c, filters.category),
    0
  );

  // Determine MTD month key (latest month in filtered claims or reference month)
  const refMonthKey = referenceDate.slice(0, 7);
  const monthKeysInSet = Array.from(
    new Set(activeSpendClaims.map((c) => getClaimPrimaryDate(c).slice(0, 7)).filter(Boolean))
  ).sort();
  const mtdKey = monthKeysInSet.includes(refMonthKey)
    ? refMonthKey
    : monthKeysInSet[monthKeysInSet.length - 1] || refMonthKey;

  const totalSpendMtd = activeSpendClaims
    .filter((c) => getClaimPrimaryDate(c).slice(0, 7) === mtdKey)
    .reduce((s, c) => s + getScopedClaimAmount(c, filters.category), 0);

  const pendingStatuses = new Set(['Submitted', 'Manager Approved', 'Sent Back', 'Finance Verified']);
  const pendingClaims = filteredClaims.filter((c) => pendingStatuses.has(c.status));
  const pendingLiability = pendingClaims.reduce(
    (s, c) => s + getScopedClaimAmount(c, filters.category),
    0
  );

  // Turnaround time (Submitted -> Finance Verified / Paid / Manager Approved)
  let turnaroundSumDays = 0;
  let turnaroundSampleSize = 0;
  for (const c of filteredClaims) {
    const subLog = c.approvalHistory.find((a) => a.action === 'Submitted');
    const finLog =
      c.approvalHistory.find((a) => a.action === 'Finance Verified') ||
      c.approvalHistory.find((a) => a.action === 'Paid') ||
      c.approvalHistory.find((a) => a.action === 'Manager Approved');
    if (subLog && finLog) {
      const tSub = new Date(subLog.timestamp).getTime();
      const tFin = new Date(finLog.timestamp).getTime();
      if (Number.isFinite(tSub) && Number.isFinite(tFin) && tFin >= tSub) {
        const diffDays = Math.max(0.25, (tFin - tSub) / (1000 * 60 * 60 * 24));
        turnaroundSumDays += diffDays;
        turnaroundSampleSize++;
      }
    }
  }
  const avgApprovalTurnaroundDays =
    turnaroundSampleSize > 0
      ? Math.round((turnaroundSumDays / turnaroundSampleSize) * 10) / 10
      : 0;

  // Risk & Policy evaluation across filtered claims
  const nonDraftFiltered = filteredClaims.filter((c) => c.status !== 'Draft');
  let exceptionClaimCount = 0;
  let duplicateFlaggedCount = 0;
  let duplicateFlaggedAmount = 0;
  let highRiskCount = 0;

  const exceptionMap = new Map<string, { count: number; impactAmount: number }>();

  for (const c of filteredClaims) {
    const comp = evaluateClaimCompliance(
      {
        tripFromDate: c.tripFromDate,
        tripToDate: c.tripToDate,
        employeeId: c.employeeId,
        lines: c.lines,
      },
      c.grade,
      c.cityTier,
      policies,
      claims,
      c.id
    );
    const risk = analyzeClaimRisk(c, claims, policies);
    const isDup = c.isDuplicateFlagged || risk.duplicates.length > 0;
    const hasExc = c.hasPolicyViolation || comp.hasExceptions;

    if (c.status !== 'Draft' && hasExc) exceptionClaimCount++;
    if (isDup) {
      duplicateFlaggedCount++;
      duplicateFlaggedAmount += getScopedClaimAmount(c, filters.category);
    }
    if (risk.riskLevel === 'High') highRiskCount++;

    for (let idx = 0; idx < c.lines.length; idx++) {
      const line = c.lines[idx];
      if (filters.category !== 'ALL' && line.category !== filters.category) continue;
      const lineEv = comp.lineEvaluations[idx];
      if (!lineEv) continue;
      for (const iss of lineEv.issues) {
        const cur = exceptionMap.get(iss.code) || { count: 0, impactAmount: 0 };
        cur.count += 1;
        cur.impactAmount +=
          iss.code === 'LIMIT_EXCEEDED' && lineEv.excessAmount > 0
            ? lineEv.excessAmount
            : Number(line.amount || 0);
        exceptionMap.set(iss.code, cur);
      }
    }
  }

  const policyExceptionRatePct =
    nonDraftFiltered.length > 0
      ? Math.round((exceptionClaimCount / nonDraftFiltered.length) * 1000) / 10
      : 0;

  // 1. Monthly trend
  const monthMap = new Map<
    string,
    { totalSpend: number; paidSpend: number; claimCount: number; exceptionCount: number }
  >();
  for (const c of activeSpendClaims) {
    const mk = getClaimPrimaryDate(c).slice(0, 7);
    if (!mk) continue;
    const cur = monthMap.get(mk) || {
      totalSpend: 0,
      paidSpend: 0,
      claimCount: 0,
      exceptionCount: 0,
    };
    const amt = getScopedClaimAmount(c, filters.category);
    cur.totalSpend += amt;
    if (c.status === 'Paid') cur.paidSpend += amt;
    cur.claimCount += 1;
    if (c.hasPolicyViolation) cur.exceptionCount += 1;
    monthMap.set(mk, cur);
  }
  const monthlyTrend = Array.from(monthMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([monthKey, val]) => ({
      monthKey,
      label: formatMonthLabel(monthKey),
      ...val,
    }));

  // 2. Spend by category
  const catStats = new Map<string, { amount: number; gstAmount: number; lineCount: number }>();
  for (const cat of EXPENSE_CATEGORIES) {
    catStats.set(cat, { amount: 0, gstAmount: 0, lineCount: 0 });
  }
  for (const c of activeSpendClaims) {
    for (const l of c.lines) {
      if (filters.category !== 'ALL' && l.category !== filters.category) continue;
      const cur = catStats.get(l.category) || { amount: 0, gstAmount: 0, lineCount: 0 };
      cur.amount += Number(l.amount || 0);
      cur.gstAmount += Number(l.gstAmount || 0);
      cur.lineCount += 1;
      catStats.set(l.category, cur);
    }
  }
  const spendByCategory = Array.from(catStats.entries())
    .map(([category, v]) => ({
      category,
      ...v,
      sharePct: totalSpendYtd > 0 ? Math.round((v.amount / totalSpendYtd) * 1000) / 10 : 0,
    }))
    .filter((x) => filters.category === 'ALL' || x.category === filters.category)
    .sort((a, b) => b.amount - a.amount);

  // 3. Spend by Department & Budget vs Actual
  const spendByDepartment = departments
    .filter((d) => filters.department === 'ALL' || d.name === filters.department)
    .map((d) => {
      const deptClaims = activeSpendClaims.filter((c) => c.department === d.name);
      const amount = deptClaims.reduce(
        (s, c) => s + getScopedClaimAmount(c, filters.category),
        0
      );
      const utilizationPct =
        d.annualBudgetInr > 0 ? Math.round((amount / d.annualBudgetInr) * 1000) / 10 : 0;
      return {
        department: d.name,
        code: d.code,
        amount,
        claimCount: deptClaims.length,
        budget: d.annualBudgetInr,
        utilizationPct,
      };
    })
    .sort((a, b) => b.amount - a.amount);

  const budgetVsActual = spendByDepartment.map((d) => ({
    department: d.department,
    code: d.code,
    budget: d.budget,
    actual: d.amount,
    variance: d.budget - d.amount,
    utilizationPct: d.utilizationPct,
  }));

  // 4. Spend by Cost Centre
  const spendByCostCentre = costCentres
    .filter((cc) => filters.costCentre === 'ALL' || cc.code === filters.costCentre)
    .filter((cc) => filters.department === 'ALL' || cc.department === filters.department)
    .map((cc) => {
      const ccClaims = activeSpendClaims.filter((c) => c.costCentre === cc.code);
      const amount = ccClaims.reduce(
        (s, c) => s + getScopedClaimAmount(c, filters.category),
        0
      );
      return {
        costCentre: cc.code,
        name: cc.name,
        department: cc.department,
        amount,
        claimCount: ccClaims.length,
      };
    })
    .sort((a, b) => b.amount - a.amount);

  // 5. Top 10 Claimants
  const claimantMap = new Map<
    string,
    {
      employeeId: string;
      employeeName: string;
      employeeCode: string;
      department: string;
      grade: string;
      claimCount: number;
      totalSpend: number;
      exceptionCount: number;
    }
  >();
  for (const c of activeSpendClaims) {
    const cur = claimantMap.get(c.employeeId) || {
      employeeId: c.employeeId,
      employeeName: c.employeeName,
      employeeCode: c.employeeCode,
      department: c.department,
      grade: c.grade,
      claimCount: 0,
      totalSpend: 0,
      exceptionCount: 0,
    };
    cur.claimCount += 1;
    cur.totalSpend += getScopedClaimAmount(c, filters.category);
    if (c.hasPolicyViolation) cur.exceptionCount += 1;
    claimantMap.set(c.employeeId, cur);
  }
  const topClaimants = Array.from(claimantMap.values())
    .sort((a, b) => b.totalSpend - a.totalSpend)
    .slice(0, 10);

  // 6. Exception Reasons Breakdown
  const totalExceptionOccurrences = Array.from(exceptionMap.values()).reduce(
    (s, x) => s + x.count,
    0
  );
  const exceptionBreakdown = Array.from(exceptionMap.entries())
    .map(([code, v]) => ({
      code,
      label: EXCEPTION_LABELS[code] || code,
      count: v.count,
      impactAmount: v.impactAmount,
      sharePct:
        totalExceptionOccurrences > 0
          ? Math.round((v.count / totalExceptionOccurrences) * 1000) / 10
          : 0,
    }))
    .sort((a, b) => b.count - a.count);

  // 7. Pending Claims Ageing (0-7, 8-15, 16-30, >30 days)
  const buckets: FinanceAnalyticsResult['pendingAgeing'] = [
    { bucket: '0-7 days', count: 0, amount: 0, claims: [] },
    { bucket: '8-15 days', count: 0, amount: 0, claims: [] },
    { bucket: '16-30 days', count: 0, amount: 0, claims: [] },
    { bucket: '>30 days', count: 0, amount: 0, claims: [] },
  ];

  for (const c of pendingClaims) {
    const refStart = getClaimPrimaryDate(c) || referenceDate;
    const ageDays = daysBetween(refStart, referenceDate);
    const amt = getScopedClaimAmount(c, filters.category);
    const bIdx = ageDays <= 7 ? 0 : ageDays <= 15 ? 1 : ageDays <= 30 ? 2 : 3;
    buckets[bIdx].count += 1;
    buckets[bIdx].amount += amt;
    buckets[bIdx].claims.push({
      claimNo: c.claimNo,
      employeeName: c.employeeName,
      daysPending: ageDays,
      amount: amt,
      status: c.status,
    });
  }

  return {
    filteredClaims,
    activeSpendClaims,
    kpis: {
      totalSpendYtd,
      totalSpendMtd,
      mtdMonthLabel: formatMonthLabel(mtdKey),
      totalGstEligible,
      pendingLiability,
      pendingCount: pendingClaims.length,
      avgApprovalTurnaroundDays,
      turnaroundSampleSize,
      policyExceptionRatePct,
      exceptionClaimCount,
      duplicateFlaggedCount,
      duplicateFlaggedAmount,
      highRiskCount,
    },
    monthlyTrend,
    spendByCategory,
    spendByDepartment,
    spendByCostCentre,
    budgetVsActual,
    topClaimants,
    exceptionBreakdown,
    pendingAgeing: buckets,
  };
}
