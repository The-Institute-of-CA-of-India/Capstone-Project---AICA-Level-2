import {
  AnomalyFinding,
  ClaimRiskAnalysis,
  DuplicateFinding,
  ExpenseClaim,
  ExpensePolicy,
  RiskLevel,
} from '../types/claimwise';
import {
  daysBetweenIsoDates,
  formatDateDDMMMYYYY,
  formatINR,
  isSimilarExpenseAmount,
  merchantsMatch,
  normalizeMerchantName,
} from './formatters';
import { evaluateClaimCompliance, findMatchingPolicy } from './policyEngine';

function getReferenceDateMs(claim: ExpenseClaim): number {
  const iso = claim.tripToDate || claim.tripFromDate || claim.submittedDate || claim.createdAt;
  if (iso && /^\d{4}-\d{2}-\d{2}/.test(iso)) {
    const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
    return Date.UTC(y, m - 1, d);
  }
  return Date.now();
}

export function findDuplicateFindings(
  claim: ExpenseClaim,
  allClaims: ExpenseClaim[]
): DuplicateFinding[] {
  const findings: DuplicateFinding[] = [];
  const seenKeys = new Set<string>();

  // 1. Cross-claim duplicates (same employee + similar amount + close date + same merchant or invoiceNo, OR identical invoiceNo)
  for (let lIdx = 0; lIdx < claim.lines.length; lIdx++) {
    const line = claim.lines[lIdx];
    const lineNum = lIdx + 1;

    for (const other of allClaims) {
      if (other.id === claim.id) continue;
      if (other.status === 'Rejected') continue;

      for (let oIdx = 0; oIdx < other.lines.length; oIdx++) {
        const oLine = other.lines[oIdx];
        const sameEmployee = other.employeeId === claim.employeeId;
        const invCand = (line.invoiceNo || '').trim().toLowerCase();
        const invOther = (oLine.invoiceNo || '').trim().toLowerCase();
        const sameInvoice = invCand.length >= 4 && invCand === invOther;
        const dayDiff = daysBetweenIsoDates(line.date, oLine.date);
        const closeDate = dayDiff <= 3;
        const similarAmount = isSimilarExpenseAmount(line.amount, oLine.amount);
        const sameMerchant = merchantsMatch(line.merchant, oLine.merchant);

        const isExactInvoiceDup = sameInvoice;
        const isFuzzyEmployeeDup = sameEmployee && closeDate && similarAmount && sameMerchant;

        if (!isExactInvoiceDup && !isFuzzyEmployeeDup) continue;

        const key = `${lineNum}->${other.id}#${oIdx + 1}`;
        if (seenKeys.has(key)) continue;
        seenKeys.add(key);

        const matchType = isExactInvoiceDup ? 'EXACT_INVOICE' : 'FUZZY_SAME_EMPLOYEE';
        const similarityScore = isExactInvoiceDup
          ? sameEmployee && similarAmount
            ? 99
            : 95
          : dayDiff === 0 && Math.abs(line.amount - oLine.amount) < 1
            ? 94
            : 86;

        const reason = isExactInvoiceDup
          ? `Line #${lineNum} (${line.merchant}, ${formatINR(line.amount)} on ${formatDateDDMMMYYYY(line.date)}) shares invoice no. ${line.invoiceNo} with ${other.claimNo} (${other.employeeName}, ${formatINR(oLine.amount)} on ${formatDateDDMMMYYYY(oLine.date)}).`
          : `Line #${lineNum} (${line.merchant}, ${formatINR(line.amount)} on ${formatDateDDMMMYYYY(line.date)}) closely matches ${claim.employeeName}'s ${other.claimNo} (${oLine.merchant}, ${formatINR(oLine.amount)} on ${formatDateDDMMMYYYY(oLine.date)}, ${dayDiff === 0 ? 'same day' : `${dayDiff} day(s) apart`}).`;

        findings.push({
          lineNumber: lineNum,
          merchant: line.merchant,
          invoiceNo: line.invoiceNo,
          amount: line.amount,
          date: line.date,
          matchedClaimId: other.id,
          matchedClaimNo: other.claimNo,
          matchedLineNumber: oIdx + 1,
          matchedAmount: oLine.amount,
          matchedDate: oLine.date,
          matchedInvoiceNo: oLine.invoiceNo,
          matchType,
          similarityScore,
          reason,
        });
      }
    }
  }

  // 2. Intra-claim duplicate lines (duplicate receipt/charge within the same claim)
  for (let i = 0; i < claim.lines.length; i++) {
    for (let j = i + 1; j < claim.lines.length; j++) {
      const a = claim.lines[i];
      const b = claim.lines[j];
      const invA = (a.invoiceNo || '').trim().toLowerCase();
      const invB = (b.invoiceNo || '').trim().toLowerCase();
      const sameInvoice = invA.length >= 4 && invA === invB;
      const sameMerchant = merchantsMatch(a.merchant, b.merchant);
      const exactSameAmountAndDate =
        a.date === b.date && Math.abs(Number(a.amount) - Number(b.amount)) <= 1;

      if (sameInvoice || (sameMerchant && exactSameAmountAndDate)) {
        findings.push({
          lineNumber: j + 1,
          merchant: b.merchant,
          invoiceNo: b.invoiceNo,
          amount: b.amount,
          date: b.date,
          matchedClaimId: claim.id,
          matchedClaimNo: claim.claimNo,
          matchedLineNumber: i + 1,
          matchedAmount: a.amount,
          matchedDate: a.date,
          matchedInvoiceNo: a.invoiceNo,
          matchType: 'INTRA_CLAIM',
          similarityScore: sameInvoice ? 98 : 92,
          reason: `Line #${j + 1} (${b.merchant}, ${formatINR(b.amount)}) duplicates Line #${i + 1} inside this same claim (${claim.claimNo}).`,
        });
      }
    }
  }

  return findings;
}

export function analyzeClaimRisk(
  claim: ExpenseClaim,
  allClaims: ExpenseClaim[],
  policies: ExpensePolicy[]
): ClaimRiskAnalysis {
  const duplicates = findDuplicateFindings(claim, allClaims);
  const anomalies: AnomalyFinding[] = [];

  const compliance = evaluateClaimCompliance(
    {
      tripFromDate: claim.tripFromDate,
      tripToDate: claim.tripToDate,
      employeeId: claim.employeeId,
      lines: claim.lines,
    },
    claim.grade,
    claim.cityTier,
    policies,
    allClaims,
    claim.id
  );

  // Build employee's 6-month historical baselines (excluding Draft, Rejected, and current claim)
  const refMs = getReferenceDateMs(claim);
  const sixMonthsMs = 185 * 24 * 60 * 60 * 1000;

  const employeeHistoryClaims = allClaims.filter((c) => {
    if (c.employeeId !== claim.employeeId) return false;
    if (c.status === 'Draft' || c.status === 'Rejected') return false;
    if (c.id === claim.id) return false;
    const cMs = getReferenceDateMs(c);
    return Math.abs(refMs - cMs) <= sixMonthsMs;
  });

  const catTotals: Record<string, { sum: number; count: number }> = {};
  for (const hc of employeeHistoryClaims) {
    for (const hl of hc.lines) {
      if (!catTotals[hl.category]) {
        catTotals[hl.category] = { sum: 0, count: 0 };
      }
      catTotals[hl.category].sum += Number(hl.amount || 0);
      catTotals[hl.category].count += 1;
    }
  }

  const categorySixMonthAverages: Record<string, { avg: number; sampleCount: number }> = {};
  for (const [cat, stats] of Object.entries(catTotals)) {
    categorySixMonthAverages[cat] = {
      avg: Math.round(stats.sum / Math.max(1, stats.count)),
      sampleCount: stats.count,
    };
  }

  // Track threshold-hugging categories & split-bill groups
  const thresholdFlaggedCats = new Set<string>();
  const splitKeysSeen = new Set<string>();

  for (let idx = 0; idx < claim.lines.length; idx++) {
    const line = claim.lines[idx];
    const lineNum = idx + 1;
    const amount = Number(line.amount || 0);
    const gstAmount = Number(line.gstAmount || 0);
    const matchedPolicy = findMatchingPolicy(line.category, claim.grade, claim.cityTier, policies);
    const permissibleLimit = matchedPolicy
      ? matchedPolicy.limitPerUnit > 0
        ? matchedPolicy.limitPerUnit
        : matchedPolicy.limitPerDay
      : 0;

    // 1. Anomaly: Round-number amount
    const isExactThousand = amount >= 1000 && amount % 1000 === 0;
    const isSuspiciousFiveHundred =
      amount >= 1500 &&
      amount % 500 === 0 &&
      gstAmount === 0 &&
      Boolean(matchedPolicy?.gstEligible);

    if (isExactThousand || isSuspiciousFiveHundred) {
      const highSeverity = isExactThousand && amount >= 3000 && gstAmount === 0;
      anomalies.push({
        code: 'ROUND_NUMBER',
        severity: highSeverity ? 'high' : 'medium',
        lineNumber: lineNum,
        category: line.category,
        title: 'Round-Number Amount',
        reason: `Line #${lineNum} (${line.category} – ${line.merchant}) is an exact round figure of ${formatINR(amount)}${
          gstAmount === 0 && matchedPolicy?.gstEligible
            ? ' with ₹0 GST recorded, which often indicates an un-itemized or estimated voucher'
            : ''
        }.`,
        metrics: `${formatINR(amount)} · GST ${formatINR(gstAmount)}`,
      });
    }

    // 2. Anomaly: Unusually high amount vs employee's 6-month category average
    const hist = categorySixMonthAverages[line.category];
    if (hist && hist.sampleCount >= 2 && hist.avg > 0) {
      const ratio = amount / hist.avg;
      if (ratio >= 1.55 && amount - hist.avg >= 500) {
        anomalies.push({
          code: 'HIGH_VS_AVG',
          severity: ratio >= 2.1 ? 'high' : 'medium',
          lineNumber: lineNum,
          category: line.category,
          title: 'Unusually High vs 6-Month Average',
          reason: `Line #${lineNum} ${line.category} expense (${formatINR(amount)}) is ${ratio.toFixed(1)}× higher than ${claim.employeeName}'s 6-month ${line.category} average of ${formatINR(hist.avg)} across ${hist.sampleCount} prior claims.`,
          metrics: `${formatINR(amount)} vs ${formatINR(hist.avg)} avg (${hist.sampleCount} prior)`,
        });
      }
    }

    // 3. Anomaly: Frequent claims just below policy limit (88% - 100% of cap)
    if (
      permissibleLimit > 0 &&
      amount >= permissibleLimit * 0.88 &&
      amount <= permissibleLimit &&
      !thresholdFlaggedCats.has(line.category)
    ) {
      const nearCapHistory: { claimNo: string; amount: number }[] = [];
      for (const hc of employeeHistoryClaims) {
        const hcPolicy = findMatchingPolicy(line.category, hc.grade, hc.cityTier, policies);
        const hcCap = hcPolicy
          ? hcPolicy.limitPerUnit > 0
            ? hcPolicy.limitPerUnit
            : hcPolicy.limitPerDay
          : permissibleLimit;
        for (const hl of hc.lines) {
          if (
            hl.category === line.category &&
            hcCap > 0 &&
            hl.amount >= hcCap * 0.88 &&
            hl.amount <= hcCap
          ) {
            nearCapHistory.push({ claimNo: hc.claimNo, amount: hl.amount });
          }
        }
      }
      // Also count other near-cap lines in current claim for the same category
      const currentNearCapCount = claim.lines.filter(
        (cl) =>
          cl.category === line.category &&
          cl.amount >= permissibleLimit * 0.88 &&
          cl.amount <= permissibleLimit
      ).length;

      const totalNearCap = nearCapHistory.length + currentNearCapCount;
      if (totalNearCap >= 3) {
        thresholdFlaggedCats.add(line.category);
        const pct = Math.round((amount / permissibleLimit) * 100);
        anomalies.push({
          code: 'THRESHOLD_HUGGING',
          severity: totalNearCap >= 4 ? 'high' : 'medium',
          lineNumber: lineNum,
          category: line.category,
          title: 'Frequent Claims Just Below Policy Limit',
          reason: `${claim.employeeName} has ${totalNearCap} ${line.category} expenses within 88%–100% of the ${formatINR(permissibleLimit)} policy cap over the past 6 months (including Line #${lineNum} at ${formatINR(amount)} = ${pct}% of cap).`,
          metrics: `${totalNearCap} near-cap claims (${pct}% of ${formatINR(permissibleLimit)})`,
        });
      }
    }

    // 4a. Anomaly: Split bills within this same claim (2+ charges same merchant/category within ±1 day)
    for (let j = idx + 1; j < claim.lines.length; j++) {
      const sibling = claim.lines[j];
      const sibAmt = Number(sibling.amount || 0);
      const closeDay = daysBetweenIsoDates(line.date, sibling.date) <= 1;
      const sameMerch = merchantsMatch(line.merchant, sibling.merchant);
      const sameCat = line.category === sibling.category;

      if (closeDay && sameMerch && sameCat) {
        const combined = amount + sibAmt;
        const splitKey = `intra:${normalizeMerchantName(line.merchant)}:${line.category}:${[line.date, sibling.date].sort().join('|')}`;
        if (
          !splitKeysSeen.has(splitKey) &&
          (permissibleLimit === 0 ||
            (amount <= permissibleLimit && sibAmt <= permissibleLimit && combined > permissibleLimit))
        ) {
          splitKeysSeen.add(splitKey);
          anomalies.push({
            code: 'SPLIT_BILL',
            severity: 'high',
            lineNumber: lineNum,
            category: line.category,
            title: 'Potential Split Bill (Same Claim)',
            reason: `Lines #${lineNum} and #${j + 1} split two ${line.merchant} (${line.category}) charges within ${daysBetweenIsoDates(line.date, sibling.date) === 0 ? 'the same day' : '1 day'} (${formatINR(amount)} + ${formatINR(sibAmt)} = ${formatINR(combined)})${
              permissibleLimit > 0
                ? `, exceeding the single-event policy limit of ${formatINR(permissibleLimit)}`
                : ''
            }.`,
            metrics: `${formatINR(amount)} + ${formatINR(sibAmt)} = ${formatINR(combined)}`,
          });
        }
      }
    }

    // 4b. Anomaly: Cross-claim split bills (same employee + same merchant + same category + ±1 day across another claim)
    for (const other of employeeHistoryClaims) {
      if (other.id === claim.id) continue;
      for (const oLine of other.lines) {
        const oAmt = Number(oLine.amount || 0);
        const dayDiff = daysBetweenIsoDates(line.date, oLine.date);
        const sameMerch = merchantsMatch(line.merchant, oLine.merchant);
        const sameCat = line.category === oLine.category;
        if (dayDiff <= 1 && sameMerch && sameCat) {
          const combined = amount + oAmt;
          // Avoid double-reporting if it's already an exact/fuzzy duplicate (same amount)
          const isIdenticalDup = isSimilarExpenseAmount(amount, oAmt) && dayDiff <= 3;
          const splitKey = `cross:${other.id}:${normalizeMerchantName(line.merchant)}:${line.category}`;
          if (
            !isIdenticalDup &&
            !splitKeysSeen.has(splitKey) &&
            (permissibleLimit === 0 ||
              (amount <= permissibleLimit && oAmt <= permissibleLimit && combined > permissibleLimit))
          ) {
            splitKeysSeen.add(splitKey);
            anomalies.push({
              code: 'SPLIT_BILL',
              severity: 'high',
              lineNumber: lineNum,
              category: line.category,
              title: 'Potential Split Bill Across Claims',
              reason: `Line #${lineNum} (${line.merchant}, ${formatINR(amount)}) and ${other.claimNo} (${formatINR(oAmt)} on ${formatDateDDMMMYYYY(oLine.date)}) split ${line.category} spend at the same merchant across consecutive claims (${formatINR(combined)} combined${
                permissibleLimit > 0 ? ` vs ${formatINR(permissibleLimit)} cap` : ''
              }).`,
              metrics: `${formatINR(combined)} combined across ${claim.claimNo} & ${other.claimNo}`,
            });
          }
        }
      }
    }
  }

  // Calculate composite risk score (0-100)
  let riskScore = 0;
  riskScore += duplicates.length * 45;
  for (const a of anomalies) {
    if (a.code === 'SPLIT_BILL') riskScore += 35;
    else if (a.code === 'HIGH_VS_AVG') riskScore += 25;
    else if (a.code === 'THRESHOLD_HUGGING') riskScore += 25;
    else if (a.code === 'ROUND_NUMBER') riskScore += a.severity === 'high' ? 25 : 15;
  }
  riskScore += Math.min(40, compliance.exceptionCount * 18);
  riskScore += Math.min(10, compliance.warningCount * 5);
  riskScore = Math.max(0, Math.min(100, riskScore));

  let riskLevel: RiskLevel = 'Low';
  if (
    duplicates.length > 0 ||
    anomalies.some((a) => a.severity === 'high') ||
    riskScore >= 50
  ) {
    riskLevel = 'High';
  } else if (
    anomalies.length > 0 ||
    compliance.exceptionCount > 0 ||
    riskScore >= 20
  ) {
    riskLevel = 'Medium';
  }

  const plainEnglishReasons: string[] = [];
  for (const d of duplicates) {
    plainEnglishReasons.push(d.reason);
  }
  for (const a of anomalies) {
    plainEnglishReasons.push(a.reason);
  }
  for (const iss of compliance.issues) {
    if (iss.severity === 'exception' && iss.code !== 'DUPLICATE_CLAIM') {
      plainEnglishReasons.push(`Line #${iss.lineNumber} (${iss.title}): ${iss.summary}`);
    }
  }
  if (plainEnglishReasons.length === 0) {
    plainEnglishReasons.push(
      'No duplicate submissions, behavioral spend anomalies, or policy exceptions detected for this claim.'
    );
  }

  return {
    riskLevel,
    riskScore,
    duplicates,
    anomalies,
    plainEnglishReasons: Array.from(new Set(plainEnglishReasons)),
    categorySixMonthAverages,
    policyExceptionCount: compliance.exceptionCount,
  };
}
