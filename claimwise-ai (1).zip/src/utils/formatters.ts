import {
  CityTier,
  ExpenseClaim,
  ExpenseLine,
  ExpensePolicy,
  Grade,
  INDIAN_CITIES,
  PolicyFlag,
} from '../types/claimwise';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatINR(amount: number): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(Math.round(safe));
}

export function formatINRWithDecimals(amount: number): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safe);
}

/**
 * Formats YYYY-MM-DD or ISO timestamp to DD-MMM-YYYY (e.g. 24-Nov-2026)
 */
export function formatDateDDMMMYYYY(input?: string | null): string {
  if (!input) return '—';
  const datePart = input.slice(0, 10);
  const parts = datePart.split('-');
  if (parts.length !== 3) return input;
  const year = Number(parts[0]);
  const monthIdx = Number(parts[1]) - 1;
  const day = Number(parts[2]);
  if (!year || monthIdx < 0 || monthIdx > 11 || !day) return input;
  const dd = String(day).padStart(2, '0');
  return `${dd}-${MONTHS[monthIdx]}-${year}`;
}

export function formatDateTimeDDMMMYYYY(iso?: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return formatDateDDMMMYYYY(iso);
  const dd = String(d.getDate()).padStart(2, '0');
  const mmm = MONTHS[d.getMonth()];
  const yyyy = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  return `${dd}-${mmm}-${yyyy}, ${hh}:${min}`;
}

export function getCityTier(city: string): CityTier {
  const match = INDIAN_CITIES.find((c) => c.name.toLowerCase() === city.trim().toLowerCase());
  return match ? match.tier : 'Tier 2';
}

export function getTripDays(from: string, to: string): number {
  const start = new Date(from);
  const end = new Date(to);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 1;
  const diff = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  return Math.max(1, diff);
}

export interface GstValidationResult {
  gstinValid: boolean;
  gstConsistent: boolean;
  warnings: string[];
}

export function validateGstAndGstin(
  totalAmount: number,
  gstAmount: number,
  gstin: string
): GstValidationResult {
  const warnings: string[] = [];
  const cleanGstin = (gstin || '').trim().toUpperCase();
  let gstinValid = true;
  let gstConsistent = true;

  if (cleanGstin.length > 0) {
    if (cleanGstin.length !== 15) {
      gstinValid = false;
      warnings.push(`GSTIN must be 15 characters (currently ${cleanGstin.length}).`);
    } else if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(cleanGstin)) {
      gstinValid = false;
      warnings.push('GSTIN does not match valid Indian 15-character GSTIN format.');
    }
  }

  if (gstAmount < 0) {
    gstConsistent = false;
    warnings.push('GST amount cannot be negative.');
  } else if (totalAmount > 0 && gstAmount >= totalAmount) {
    gstConsistent = false;
    warnings.push('GST amount cannot equal or exceed Total Amount.');
  } else if (totalAmount > 0 && gstAmount > 0) {
    const base = totalAmount - gstAmount;
    const rate = base > 0 ? (gstAmount / base) * 100 : 100;
    if (rate > 29.5) {
      gstConsistent = false;
      warnings.push(
        `GST (${rate.toFixed(1)}% of base) exceeds max Indian 28% GST slab.`
      );
    }
  } else if (cleanGstin.length === 15 && gstinValid && totalAmount > 0 && gstAmount === 0) {
    gstConsistent = false;
    warnings.push('15-char GSTIN entered but GST amount is ₹0.');
  }

  return { gstinValid, gstConsistent, warnings };
}

export function computeAiOverrides(
  suggested: {
    merchant: string;
    date: string;
    invoiceNo: string;
    amount: number;
    gstAmount: number;
    gstin: string;
    currency: string;
    paymentMode: string;
    category: string;
  } | undefined,
  current: {
    merchant: string;
    date: string;
    invoiceNo: string;
    amount: number;
    gstAmount: number;
    gstin: string;
    currency?: string;
    paymentMode: string;
    category: string;
  }
): { field: string; aiValue: string; userValue: string }[] {
  if (!suggested) return [];
  const pairs: { field: string; aiVal: string; curVal: string }[] = [
    { field: 'Merchant', aiVal: suggested.merchant, curVal: current.merchant },
    { field: 'Invoice Date', aiVal: suggested.date, curVal: current.date },
    { field: 'Invoice No.', aiVal: suggested.invoiceNo, curVal: current.invoiceNo },
    { field: 'Total Amount', aiVal: String(suggested.amount), curVal: String(current.amount) },
    { field: 'GST Amount', aiVal: String(suggested.gstAmount), curVal: String(current.gstAmount) },
    { field: 'GSTIN', aiVal: suggested.gstin, curVal: current.gstin },
    { field: 'Currency', aiVal: suggested.currency || 'INR', curVal: current.currency || 'INR' },
    { field: 'Payment Mode', aiVal: suggested.paymentMode, curVal: current.paymentMode },
    { field: 'Category', aiVal: suggested.category, curVal: current.category },
  ];

  return pairs
    .filter((p) => p.aiVal.trim() !== p.curVal.trim())
    .map((p) => ({ field: p.field, aiValue: p.aiVal || '—', userValue: p.curVal || '—' }));
}

export function evaluateLinePolicy(
  line: Pick<ExpenseLine, 'category' | 'amount' | 'gstAmount' | 'gstin' | 'receiptName' | 'receiptUrl'>,
  grade: Grade,
  cityTier: CityTier,
  policies: ExpensePolicy[]
): { flag: PolicyFlag; reason: string } {
  const matching =
    policies.find(
      (p) => p.category === line.category && p.grade === grade && p.cityTier === cityTier
    ) ||
    policies.find(
      (p) => p.category === line.category && p.grade === grade && p.cityTier === 'All'
    );

  const reasons: string[] = [];
  let flag: PolicyFlag = 'Compliant';

  const gstCheck = validateGstAndGstin(line.amount, line.gstAmount || 0, line.gstin || '');
  if (!gstCheck.gstinValid || !gstCheck.gstConsistent) {
    flag = 'Warning';
    reasons.push(...gstCheck.warnings);
  }

  if (matching) {
    if (matching.requiresReceipt && !line.receiptName && !line.receiptUrl) {
      flag = 'Violation';
      reasons.push(`Receipt mandatory for ${line.category}`);
    }

    const cap = matching.limitPerUnit > 0 ? matching.limitPerUnit : matching.limitPerDay;
    if (cap > 0 && line.amount > cap) {
      const overPct = ((line.amount - cap) / cap) * 100;
      if (overPct > 15) {
        flag = 'Violation';
        reasons.push(`Exceeds ${grade} ${cityTier} cap of ${formatINR(cap)}`);
      } else {
        if (flag !== 'Violation') flag = 'Warning';
        reasons.push(`Slightly above ${grade} ${cityTier} guideline (${formatINR(cap)})`);
      }
    }

    if (matching.requiresPreApproval && line.amount > 0 && flag === 'Compliant') {
      flag = 'Warning';
      reasons.push('Pre-approval verification required by Finance');
    }
  }

  return {
    flag,
    reason: reasons.join(' · '),
  };
}

export function normalizeMerchantName(name: string): string {
  return (name || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\b(pvt|ltd|private|limited|india|systems|services|corp|inc)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function merchantsMatch(a: string, b: string): boolean {
  const na = normalizeMerchantName(a);
  const nb = normalizeMerchantName(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  if (na.length >= 5 && nb.length >= 5 && (na.includes(nb) || nb.includes(na))) return true;
  const tokA = new Set(na.split(' ').filter((t) => t.length >= 3));
  const tokB = new Set(nb.split(' ').filter((t) => t.length >= 3));
  if (tokA.size === 0 || tokB.size === 0) return false;
  let overlap = 0;
  for (const t of tokA) {
    if (tokB.has(t)) overlap++;
  }
  const minSize = Math.min(tokA.size, tokB.size);
  return overlap / minSize >= 0.65;
}

export function daysBetweenIsoDates(d1: string, d2: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d1 || '') || !/^\d{4}-\d{2}-\d{2}$/.test(d2 || '')) {
    return 999;
  }
  const [y1, m1, day1] = d1.split('-').map(Number);
  const [y2, m2, day2] = d2.split('-').map(Number);
  const t1 = Date.UTC(y1, m1 - 1, day1);
  const t2 = Date.UTC(y2, m2 - 1, day2);
  return Math.abs(Math.round((t1 - t2) / (1000 * 60 * 60 * 24)));
}

export function isSimilarExpenseAmount(a: number, b: number): boolean {
  const va = Number(a || 0);
  const vb = Number(b || 0);
  if (va <= 0 || vb <= 0) return false;
  const tolerance = Math.max(50, Math.max(va, vb) * 0.05);
  return Math.abs(va - vb) <= tolerance;
}

export function detectDuplicateClaim(
  candidateLines: Pick<ExpenseLine, 'invoiceNo' | 'merchant' | 'amount' | 'date'>[],
  existingClaims: ExpenseClaim[],
  excludeClaimId?: string,
  employeeId?: string
): { isDuplicate: boolean; matchedClaimNo: string } {
  for (const existing of existingClaims) {
    if (excludeClaimId && existing.id === excludeClaimId) continue;
    if (existing.status === 'Rejected') continue;
    for (const exLine of existing.lines) {
      for (const cand of candidateLines) {
        const sameInvoice =
          cand.invoiceNo.trim().length >= 4 &&
          exLine.invoiceNo.trim().toLowerCase() === cand.invoiceNo.trim().toLowerCase();
        const sameEmployee = !employeeId || existing.employeeId === employeeId;
        const closeDate = daysBetweenIsoDates(cand.date, exLine.date) <= 3;
        const similarAmount = isSimilarExpenseAmount(cand.amount, exLine.amount);
        const sameMerchant = merchantsMatch(cand.merchant, exLine.merchant);

        const fuzzyDuplicate = sameEmployee && closeDate && similarAmount && sameMerchant;
        const sameEmployeeInvoiceDup =
          sameEmployee && sameInvoice && (closeDate || similarAmount);

        if (sameInvoice || sameEmployeeInvoiceDup || fuzzyDuplicate) {
          return { isDuplicate: true, matchedClaimNo: existing.claimNo };
        }
      }
    }
  }
  return { isDuplicate: false, matchedClaimNo: '' };
}

export function generateClaimNo(existingClaims: ExpenseClaim[]): string {
  let maxSeq = 0;
  for (const c of existingClaims) {
    const m = c.claimNo.match(/^EXP-2026-(\d{4})$/);
    if (m) {
      const seq = Number(m[1]);
      if (seq > maxSeq) maxSeq = seq;
    }
  }
  return `EXP-2026-${String(maxSeq + 1).padStart(4, '0')}`;
}
