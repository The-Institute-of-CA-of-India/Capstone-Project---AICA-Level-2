import React from 'react';
import { Download, FileText, X } from 'lucide-react';
import { ExpenseLine } from '../types/claimwise';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';

interface ReceiptPreviewModalProps {
  line: ExpenseLine | null;
  onClose: () => void;
}

export const ReceiptPreviewModal: React.FC<ReceiptPreviewModalProps> = ({ line, onClose }) => {
  if (!line) return null;
  const isPdf =
    line.receiptMimeType?.includes('pdf') || line.receiptName?.toLowerCase().endsWith('.pdf');

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Receipt Preview · {line.merchant}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {formatDateDDMMMYYYY(line.date)} · Invoice {line.invoiceNo || '—'} ·{' '}
              <span className="font-mono-num font-medium text-slate-700">
                {formatINR(line.amount)}
              </span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            {line.receiptUrl && (
              <a
                href={line.receiptUrl}
                download={line.receiptName || 'receipt'}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Download
              </a>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
              aria-label="Close receipt preview"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 bg-slate-100 p-6 overflow-auto flex items-center justify-center min-h-[380px]">
          {!line.receiptUrl ? (
            <div className="text-center max-w-sm bg-white rounded-xl border border-slate-200 p-8">
              <FileText className="w-10 h-10 text-slate-400 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-900">No Receipt Attached</p>
              <p className="text-xs text-slate-500 mt-1">
                This expense line was recorded without an attached tax invoice or receipt document.
              </p>
            </div>
          ) : isPdf ? (
            <iframe
              src={line.receiptUrl}
              title={line.receiptName || 'Receipt PDF'}
              className="w-full h-[520px] rounded-lg border border-slate-200 bg-white"
            />
          ) : (
            <img
              src={line.receiptUrl}
              alt={line.receiptName || `Receipt from ${line.merchant}`}
              referrerPolicy="no-referrer"
              className="max-h-[65vh] w-auto rounded-lg border border-slate-200 shadow-sm object-contain bg-white"
            />
          )}
        </div>

        <div className="px-6 py-3 border-t border-slate-200 bg-white flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <span>File: {line.receiptName || 'None'}</span>
          <span>
            GSTIN: <span className="font-mono-num text-slate-700">{line.gstin || 'Not provided'}</span> · GST:{' '}
            <span className="font-mono-num text-slate-700">{formatINR(line.gstAmount)}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
