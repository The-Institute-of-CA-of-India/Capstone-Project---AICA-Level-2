import React, { useMemo } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  Clock,
  Edit3,
  FilePlus2,
  IndianRupee,
  Sparkles,
  Wallet,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';
import { StatusBadge } from './StatusBadge';

export const DashboardView: React.FC = () => {
  const { currentUser, claims, navigate } = useApp();

  const myClaims = useMemo(() => {
    if (!currentUser) return [];
    return claims.filter((c) => c.employeeId === currentUser.id);
  }, [claims, currentUser]);

  // If user is manager/finance/admin and has few personal claims, show relevant workspace summary too
  const displayClaims = myClaims.length > 0 ? myClaims : claims.slice(0, 8);
  const scopeLabel = myClaims.length > 0 ? 'Your Claims' : 'Organization Claims Overview';

  const metrics = useMemo(() => {
    const source = myClaims.length > 0 ? myClaims : claims;
    const nonDraft = source.filter((c) => c.status !== 'Draft' && c.status !== 'Rejected');
    const totalClaimed = nonDraft.reduce((s, c) => s + c.totalAmount, 0);
    const pending = source
      .filter((c) => ['Submitted', 'Manager Approved', 'Sent Back'].includes(c.status))
      .reduce((s, c) => s + c.totalAmount, 0);
    const approved = source
      .filter((c) => c.status === 'Finance Verified')
      .reduce((s, c) => s + c.totalAmount, 0);
    const paid = source
      .filter((c) => c.status === 'Paid')
      .reduce((s, c) => s + c.totalAmount, 0);

    return {
      totalClaimed,
      totalCount: nonDraft.length,
      pending,
      pendingCount: source.filter((c) => ['Submitted', 'Manager Approved', 'Sent Back'].includes(c.status)).length,
      approved,
      approvedCount: source.filter((c) => c.status === 'Finance Verified').length,
      paid,
      paidCount: source.filter((c) => c.status === 'Paid').length,
    };
  }, [myClaims, claims]);

  if (!currentUser) return null;

  return (
    <div className="space-y-6">
      {/* Welcome & Primary CTA */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Welcome back, {currentUser.name.split(' ')[0]}
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            {currentUser.department} · Cost Centre <span className="font-mono-num">{currentUser.costCentre}</span> · Grade {currentUser.grade} · {currentUser.location}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {currentUser.role === 'manager' && (
            <button
              type="button"
              onClick={() => navigate('manager-inbox')}
              className="px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              Open Approvals Inbox
            </button>
          )}
          {currentUser.role === 'finance' && (
            <button
              type="button"
              onClick={() => navigate('finance-queue')}
              className="px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              Open Finance Queue
            </button>
          )}
          <button
            type="button"
            onClick={() => navigate('new-claim', { editClaimId: null })}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#3368A0] text-white text-sm font-medium hover:bg-[#295584] transition-colors cursor-pointer whitespace-nowrap shadow-xs"
          >
            <FilePlus2 className="w-4 h-4" />
            New Claim
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Total Claimed YTD</span>
            <IndianRupee className="w-4 h-4 text-[#3368A0]" />
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900 font-mono-num">
            {formatINR(metrics.totalClaimed)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{metrics.totalCount} active claims (FY 2026-27)</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Pending Approval</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900 font-mono-num">
            {formatINR(metrics.pending)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{metrics.pendingCount} awaiting manager or finance</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Approved (Ready for Pay)</span>
            <BadgeCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900 font-mono-num">
            {formatINR(metrics.approved)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{metrics.approvedCount} finance-verified claims</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Reimbursed / Paid</span>
            <Wallet className="w-4 h-4 text-teal-700" />
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900 font-mono-num">
            {formatINR(metrics.paid)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{metrics.paidCount} settled via NEFT</p>
        </div>
      </div>

      {/* Live AI Intelligent Document Processing Banner */}
      <div className="rounded-xl border border-[#66A3BF]/45 bg-gradient-to-r from-[#C8DFDB]/30 via-white to-[#C8DFDB]/20 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#3368A0]/10 text-[#3368A0] flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-semibold text-slate-900">
                AI Intelligent Document Processing Active
              </span>
              <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-700 whitespace-nowrap">
                Gemini AI Enabled
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              Upload any PDF, JPG, or PNG receipt on New Claim to auto-extract Merchant, Date, Invoice No., GSTIN, Total, GST, Currency, Payment Mode, and Category with field-level confidence scores.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => navigate('how-ai-works')}
            className="px-3.5 py-2 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
          >
            How AI Works
          </button>
          <button
            type="button"
            onClick={() => navigate('new-claim', { editClaimId: null })}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#3368A0]/30 bg-white text-[#3368A0] text-xs font-medium hover:bg-[#3368A0]/5 transition-colors whitespace-nowrap cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Upload &amp; Extract Receipt
          </button>
        </div>
      </div>

      {/* Recent Claims Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Recent Claims · {scopeLabel}</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Click any claim row to inspect receipts, approval progress, and audit logs.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('my-claims')}
            className="inline-flex items-center gap-1 text-xs font-medium text-[#3368A0] hover:underline cursor-pointer whitespace-nowrap"
          >
            View all claims
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Claim No.</th>
                <th className="py-3 px-4">Purpose &amp; Destination</th>
                <th className="py-3 px-4">Trip Dates</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {displayClaims.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-xs text-slate-500">
                    No expense claims available yet. Click <strong>New Claim</strong> to upload your first receipt.
                  </td>
                </tr>
              ) : (
                displayClaims.slice(0, 8).map((c) => {
                const canEdit =
                  c.employeeId === currentUser.id &&
                  (c.status === 'Draft' || c.status === 'Sent Back');
                return (
                  <tr
                    key={c.id}
                    onClick={() => navigate('claim-detail', { claimId: c.id })}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4 font-mono-num font-medium text-[#3368A0] whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span>{c.claimNo}</span>
                        {(c.hasPolicyViolation || c.isDuplicateFlagged) && (
                          <AlertTriangle
                            className="w-3.5 h-3.5 text-rose-600"
                            aria-label="Policy or duplicate flag"
                          />
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      <div className="font-medium text-slate-900 truncate">{c.purpose}</div>
                      <div className="text-xs text-slate-500">
                        {c.destination} ({c.cityTier}) · {c.lineCount} item(s)
                      </div>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600 font-mono-num whitespace-nowrap">
                      {formatDateDDMMMYYYY(c.tripFromDate)} → {formatDateDDMMMYYYY(c.tripToDate)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900 whitespace-nowrap">
                      {formatINR(c.totalAmount)}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusBadge status={c.status} />
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      {canEdit ? (
                        <button
                          type="button"
                          onClick={() => navigate('new-claim', { editClaimId: c.id })}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          Edit
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => navigate('claim-detail', { claimId: c.id })}
                          className="text-xs font-medium text-[#3368A0] hover:underline cursor-pointer"
                        >
                          View
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
