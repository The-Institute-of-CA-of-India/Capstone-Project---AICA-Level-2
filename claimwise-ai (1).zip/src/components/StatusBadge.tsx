import React from 'react';
import {
  AlertCircle,
  AlertTriangle,
  BadgeCheck,
  CheckCircle2,
  Clock,
  FileEdit,
  RotateCcw,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { ClaimStatus, PolicyFlag, RiskLevel, UserRole } from '../types/claimwise';

export const StatusBadge: React.FC<{ status: ClaimStatus }> = ({ status }) => {
  const styles: Record<ClaimStatus, { cls: string; icon: React.ReactNode; label: string }> = {
    Draft: {
      cls: 'bg-slate-100 text-slate-700 border-slate-200',
      icon: <FileEdit className="w-3.5 h-3.5 shrink-0" />,
      label: 'Draft',
    },
    Submitted: {
      cls: 'bg-blue-50 text-blue-700 border-blue-200',
      icon: <Send className="w-3.5 h-3.5 shrink-0" />,
      label: 'Submitted',
    },
    'Manager Approved': {
      cls: 'bg-amber-50 text-amber-800 border-amber-200',
      icon: <Clock className="w-3.5 h-3.5 shrink-0" />,
      label: 'Under Review (Mgr Approved)',
    },
    'Sent Back': {
      cls: 'bg-amber-50 text-amber-900 border-amber-300',
      icon: <RotateCcw className="w-3.5 h-3.5 shrink-0" />,
      label: 'Sent Back',
    },
    'Finance Verified': {
      cls: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      icon: <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />,
      label: 'Approved (Fin Verified)',
    },
    Rejected: {
      cls: 'bg-rose-50 text-rose-700 border-rose-200',
      icon: <XCircle className="w-3.5 h-3.5 shrink-0" />,
      label: 'Rejected',
    },
    Paid: {
      cls: 'bg-teal-50 text-teal-800 border-teal-200',
      icon: <BadgeCheck className="w-3.5 h-3.5 shrink-0" />,
      label: 'Paid',
    },
  };

  const cfg = styles[status] || styles.Draft;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-medium whitespace-nowrap shrink-0 ${cfg.cls}`}
    >
      {cfg.icon}
      <span>{cfg.label}</span>
    </span>
  );
};

export const PolicyFlagBadge: React.FC<{ flag: PolicyFlag; reason?: string }> = ({ flag, reason }) => {
  if (flag === 'Compliant') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        Compliant
      </span>
    );
  }
  if (flag === 'Warning') {
    return (
      <span
        title={reason}
        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-xs font-medium text-amber-800 whitespace-nowrap"
      >
        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
        Review
      </span>
    );
  }
  return (
    <span
      title={reason}
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700 whitespace-nowrap"
    >
      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
      Violation
    </span>
  );
};

export const PolicyExceptionTag: React.FC<{ title?: string; compact?: boolean }> = ({
  title,
  compact = false,
}) => (
  <span
    title={title}
    className={`inline-flex items-center gap-1 rounded-md bg-red-50 border border-red-300 font-semibold text-red-700 whitespace-nowrap shrink-0 ${
      compact ? 'px-1.5 py-0.5 text-[11px]' : 'px-2 py-0.5 text-xs'
    }`}
  >
    <AlertTriangle className={compact ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />
    Policy Exception
  </span>
);

export const RiskLevelBadge: React.FC<{ level: RiskLevel; compact?: boolean }> = ({
  level,
  compact = false,
}) => {
  const cfg: Record<RiskLevel, { cls: string; icon: React.ReactNode }> = {
    Low: {
      cls: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      icon: <ShieldCheck className={compact ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />,
    },
    Medium: {
      cls: 'bg-amber-50 text-amber-800 border-amber-300',
      icon: <AlertTriangle className={compact ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />,
    },
    High: {
      cls: 'bg-rose-50 text-rose-800 border-rose-300',
      icon: <ShieldAlert className={compact ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />,
    },
  };
  const item = cfg[level];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md border font-semibold whitespace-nowrap shrink-0 ${item.cls} ${
        compact ? 'px-1.5 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs'
      }`}
    >
      {item.icon}
      <span>{level} Risk</span>
    </span>
  );
};

export const RoleBadge: React.FC<{ role: UserRole }> = ({ role }) => {
  const map: Record<UserRole, { label: string; cls: string }> = {
    employee: { label: 'Employee', cls: 'bg-[#C8DFDB]/60 text-slate-800 border-[#66A3BF]/40' },
    manager: { label: 'Manager', cls: 'bg-blue-50 text-[#3368A0] border-blue-200' },
    finance: { label: 'Finance Controller', cls: 'bg-teal-50 text-teal-800 border-teal-200' },
    admin: { label: 'System Admin', cls: 'bg-slate-100 text-slate-800 border-slate-300' },
  };
  const item = map[role];
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md border text-xs font-medium whitespace-nowrap shrink-0 ${item.cls}`}>
      {item.label}
    </span>
  );
};

export const AiPlaceholderBanner: React.FC<{
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}> = ({ title, description, actionLabel, onAction }) => {
  return (
    <div className="rounded-xl border border-[#66A3BF]/40 bg-gradient-to-r from-[#C8DFDB]/30 via-white to-[#C8DFDB]/20 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-[#3368A0]/10 text-[#3368A0] flex items-center justify-center shrink-0">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-slate-900">{title}</span>
            <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-[#3368A0]/10 text-[#3368A0] whitespace-nowrap">
              AI Copilot
            </span>
          </div>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">{description}</p>
        </div>
      </div>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#3368A0]/30 bg-white text-[#3368A0] text-xs font-medium hover:bg-[#3368A0]/5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          {actionLabel}
        </button>
      )}
    </div>
  );
};
