import React from 'react';
import {
  ArrowRight,
  Bot,
  CheckCircle2,
  FilePlus2,
  FileSearch,
  Landmark,
  MessageSquareText,
  Scale,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  UserCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const PIPELINE_STEPS = [
  {
    step: '01',
    title: 'Upload Receipt',
    subtitle: 'PDF, JPG, or PNG invoice',
    icon: <UploadCloud className="w-5 h-5" />,
    detail:
      'Employee drags & drops a receipt or loads a sample GST invoice. Images are automatically resized client-side for fast, reliable processing.',
    badge: 'Employee Input',
  },
  {
    step: '02',
    title: 'AI Extracts',
    subtitle: 'Gemini Intelligent Document Processing',
    icon: <FileSearch className="w-5 h-5" />,
    detail:
      'Extracts Merchant, Invoice Date, Invoice No., Total Amount, GST Amount, 15-char GSTIN, Currency, and Payment Mode with High/Medium/Low confidence.',
    badge: 'Gemini IDP',
  },
  {
    step: '03',
    title: 'AI Validates',
    subtitle: 'Tax, format & override audit',
    icon: <Scale className="w-5 h-5" />,
    detail:
      'Validates Indian GSTIN structure (15 chars), flags GST-to-total ratio anomalies (>28%), highlights Low-confidence fields in amber, and logs every human edit.',
    badge: 'GST & Audit Guard',
  },
  {
    step: '04',
    title: 'AI Checks Policy',
    subtitle: 'Deterministic rules + Risk engine',
    icon: <ShieldAlert className="w-5 h-5" />,
    detail:
      'Evaluates Grade (G1–G5) & City Tier caps strictly from expense_policies, missing receipts, weekend/holiday dates, trip dates, pre-approvals, duplicates & anomalies.',
    badge: 'Zero-Hallucination Rules',
  },
  {
    step: '05',
    title: 'AI Recommends',
    subtitle: 'Copilot guidance & Compliance Score',
    icon: <Bot className="w-5 h-5" />,
    detail:
      'Generates a 0–100 Compliance Score, Pre-Submission fix list, Finance AI Review Agent verdict (Approve / Approve with exception / Send back), and Executive Insights.',
    badge: 'Explainable AI',
  },
  {
    step: '06',
    title: 'Human Approves',
    subtitle: 'Human-in-the-loop accountability',
    icon: <UserCheck className="w-5 h-5" />,
    detail:
      'Reporting Manager approves/rejects and Finance Controller verifies GST & Policy Exception tags before triggering corporate NEFT reimbursement settlement.',
    badge: 'Final Decision',
  },
];

const COMPARISON_ROWS = [
  {
    dimension: 'Receipt Data Entry',
    traditional: 'Manual typing of merchant, date, invoice no., amount, and GST from PDFs/photos (5–8 mins/claim).',
    aiPowered: 'Gemini IDP auto-fills all 9 fields in seconds with High/Medium/Low per-field confidence badges.',
  },
  {
    dimension: 'GST & GSTIN Verification',
    traditional: 'Sampled manually weeks later by Finance; invalid GSTINs cause ITC input credit leakage.',
    aiPowered: 'Real-time 15-character GSTIN regex validation and automatic 28% GST slab consistency checks at entry.',
  },
  {
    dimension: 'Policy Limit Enforcement',
    traditional: 'Employees guess Grade G1–G5 & Tier-1/2 city limits from static PDF manuals; high send-back rate.',
    aiPowered: 'Deterministic checks against expense_policies calculate exact excess INR and mandate justification before submit.',
  },
  {
    dimension: 'Duplicate & Anomaly Detection',
    traditional: 'Rarely caught unless identical invoice numbers happen to be remembered by an auditor.',
    aiPowered: 'Cross-claim exact + fuzzy duplicate matching, 6-month baseline spike checks, round-number & split-bill alerts.',
  },
  {
    dimension: 'Finance Review & Turnaround',
    traditional: '5–10 days manual line-by-line review of every claim regardless of risk profile.',
    aiPowered: 'AI Review Agent synthesizes OCR, policy, and risk pillars into a draft recommendation; human decides in <2 days.',
  },
  {
    dimension: 'Policy & Spend Q&A',
    traditional: 'Emailing HR/Finance for hotel caps or waiting for monthly Excel pivots.',
    aiPowered: 'ClaimWise Assistant answers employee policy limits & Finance spend queries in real time with grounded sources.',
  },
  {
    dimension: 'Auditability & Governance',
    traditional: 'Opaque email approvals with no record of manual edits vs original invoice values.',
    aiPowered: 'Immutable audit trail logs every AI-suggested vs user-overridden field, workflow transition, and Finance remark.',
  },
];

export const HowAiWorksView: React.FC = () => {
  const { currentUser, navigate } = useApp();

  if (!currentUser) return null;

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6 lg:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-3xl space-y-2.5">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-[#C8DFDB]/60 border border-[#66A3BF]/40 text-xs font-semibold text-[#3368A0]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Architecture &amp; Responsible AI Design</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              About ClaimWise AI · How AI Works
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>Nova Foods India Pvt Ltd</strong> combines{' '}
              <strong>deterministic corporate policy &amp; tax math</strong> with{' '}
              <strong>Gemini AI extraction and reasoning</strong>. AI never invents limits or silently approves payouts — every rupee cap comes from{' '}
              <span className="font-mono-num text-slate-800">expense_policies</span>, and every approval remains strictly{' '}
              <strong>Human-in-the-Loop</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => navigate('new-claim', { editClaimId: null })}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
            >
              <FilePlus2 className="w-4 h-4" />
              Try Receipt IDP on New Claim
            </button>
            {(currentUser.role === 'finance' || currentUser.role === 'admin') && (
              <button
                type="button"
                onClick={() => navigate('finance-analytics')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Landmark className="w-4 h-4 text-[#3368A0]" />
                Open Finance Analytics
              </button>
            )}
          </div>
        </div>
      </section>

      {/* End-to-End 6-Stage AI Pipeline */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              End-to-End Expense &amp; Compliance Pipeline
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Upload Receipt → AI Extracts → AI Validates → AI Checks Policy → AI Recommends → Human Approves
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md">
            <ShieldCheck className="w-3.5 h-3.5" />
            Human-in-the-Loop Enforced
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {PIPELINE_STEPS.map((item, idx) => (
            <div
              key={item.step}
              className="relative rounded-xl border border-slate-200 bg-slate-50/60 p-4 flex flex-col justify-between gap-3"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-[#3368A0] text-white flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <div className="text-[11px] font-mono-num font-bold text-[#3368A0]">
                        STEP {item.step}
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900">{item.title}</h4>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-white border border-slate-200 text-[10px] font-semibold text-slate-600 whitespace-nowrap">
                    {item.badge}
                  </span>
                </div>
                <div className="text-xs font-medium text-slate-700">{item.subtitle}</div>
                <p className="text-xs text-slate-600 leading-relaxed">{item.detail}</p>
              </div>

              {idx < PIPELINE_STEPS.length - 1 && (
                <div className="pt-2 border-t border-slate-200/70 flex items-center justify-end text-[11px] font-medium text-[#3368A0]">
                  <span>Next: {PIPELINE_STEPS[idx + 1].title}</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Traditional vs AI-Powered Comparison Table */}
      <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Traditional Expense Processing vs ClaimWise AI
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Measurable operational impact across Employee experience, GST compliance, and Finance control
            </p>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-medium text-[#3368A0]">
            <Sparkles className="w-3.5 h-3.5" />
            Nova Foods Finance Ops Benchmark
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-5 w-48">Capability Area</th>
                <th className="py-3 px-5">Traditional Manual Process</th>
                <th className="py-3 px-5 bg-[#C8DFDB]/20 text-[#3368A0]">
                  ClaimWise AI (AI-Powered + Human-in-the-Loop)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {COMPARISON_ROWS.map((row) => (
                <tr key={row.dimension} className="hover:bg-slate-50/60 align-top">
                  <td className="py-3.5 px-5 font-semibold text-slate-900 whitespace-nowrap">
                    {row.dimension}
                  </td>
                  <td className="py-3.5 px-5 text-slate-600 leading-relaxed">{row.traditional}</td>
                  <td className="py-3.5 px-5 bg-[#C8DFDB]/10 text-slate-800 leading-relaxed">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{row.aiPowered}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Embedded AI Copilot Callout */}
      <section className="rounded-2xl border border-[#66A3BF]/50 bg-gradient-to-r from-[#C8DFDB]/30 via-white to-[#C8DFDB]/20 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#3368A0] text-white flex items-center justify-center shrink-0">
            <MessageSquareText className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">
              Need instant policy limits or live spend summaries?
            </h4>
            <p className="text-xs text-slate-600 mt-0.5">
              Click the floating <strong>ClaimWise Assistant</strong> button in the bottom-right corner on any screen to ask questions backed by live policy rules and Finance claim records.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => navigate('dashboard')}
          className="px-4 py-2 rounded-lg border border-[#3368A0]/30 bg-white text-xs font-medium text-[#3368A0] hover:bg-[#3368A0]/5 cursor-pointer whitespace-nowrap shrink-0"
        >
          Back to Dashboard
        </button>
      </section>
    </div>
  );
};
