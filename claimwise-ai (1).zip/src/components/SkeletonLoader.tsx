import React from 'react';

export const AiSummarySkeleton: React.FC<{ label?: string }> = ({
  label = 'Synthesizing AI analysis...',
}) => (
  <div className="rounded-xl border border-[#66A3BF]/40 bg-slate-50/70 p-4 space-y-3 animate-pulse">
    <div className="flex items-center justify-between">
      <div className="h-3.5 w-48 rounded bg-[#3368A0]/20" />
      <span className="text-[11px] font-medium text-[#3368A0]">{label}</span>
    </div>
    <div className="space-y-2">
      <div className="h-3 w-full rounded bg-slate-200" />
      <div className="h-3 w-5/6 rounded bg-slate-200" />
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
      <div className="h-16 rounded-lg bg-white border border-slate-200/80" />
      <div className="h-16 rounded-lg bg-white border border-slate-200/80" />
      <div className="h-16 rounded-lg bg-white border border-slate-200/80" />
    </div>
  </div>
);

export const DashboardSyncSkeleton: React.FC = () => (
  <div className="space-y-6 animate-pulse">
    <div className="bg-white rounded-2xl border border-slate-200 p-6 flex items-center justify-between">
      <div className="space-y-2">
        <div className="h-5 w-56 rounded bg-slate-200" />
        <div className="h-3.5 w-80 rounded bg-slate-100" />
      </div>
      <div className="h-9 w-32 rounded-lg bg-[#3368A0]/20" />
    </div>

    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
          <div className="h-3 w-28 rounded bg-slate-200" />
          <div className="h-7 w-36 rounded bg-slate-200" />
          <div className="h-3 w-40 rounded bg-slate-100" />
        </div>
      ))}
    </div>

    <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
      <div className="h-4 w-44 rounded bg-slate-200" />
      {[0, 1, 2, 3, 4].map((row) => (
        <div key={row} className="h-11 rounded-lg bg-slate-100" />
      ))}
    </div>
  </div>
);
