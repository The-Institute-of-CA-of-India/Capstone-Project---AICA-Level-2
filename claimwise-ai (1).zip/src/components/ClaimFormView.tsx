import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Eye,
  FileText,
  Loader2,
  Plus,
  RefreshCw,
  Save,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Trash2,
  UploadCloud,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SAMPLE_RECEIPT_FLIGHT, SAMPLE_RECEIPT_HOTEL } from '../data/seedData';
import { extractReceiptWithAI, runAiComplianceCheck } from '../services/aiPlaceholders';
import {
  AiFieldConfidences,
  AiPreSubmissionCheckResult,
  AiSuggestedSnapshot,
  ConfidenceLevel,
  EXPENSE_CATEGORIES,
  ExpenseLine,
  INDIAN_CITIES,
  PaymentMode,
} from '../types/claimwise';
import {
  computeAiOverrides,
  formatINR,
  getCityTier,
  validateGstAndGstin,
} from '../utils/formatters';
import { evaluateClaimCompliance } from '../utils/policyEngine';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { AiSummarySkeleton } from './SkeletonLoader';
import { PolicyExceptionTag, PolicyFlagBadge } from './StatusBadge';

interface DraftLine {
  tempId: string;
  date: string;
  category: string;
  merchant: string;
  amount: number;
  gstAmount: number;
  gstin: string;
  currency: string;
  invoiceNo: string;
  paymentMode: PaymentMode;
  receiptName: string;
  receiptMimeType: string;
  receiptUrl: string;
  preApprovalRef: string;
  aiConfidenceScore: number;
  aiExtracted: boolean;
  aiCategoryReason: string;
  aiFieldConfidence?: AiFieldConfidences;
  aiSuggestedValues?: AiSuggestedSnapshot;
  aiPolicyRecommendation?: string;
  justification: string;
}

const PAYMENT_MODES: PaymentMode[] = [
  'Corporate Card',
  'Personal UPI',
  'Personal Card',
  'NetBanking',
  'Cash',
];

const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'SGD', 'AED'];

function createEmptyLine(defaultDate: string): DraftLine {
  return {
    tempId: `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    date: defaultDate,
    category: 'Hotel Accommodation',
    merchant: '',
    amount: 0,
    gstAmount: 0,
    gstin: '',
    currency: 'INR',
    invoiceNo: '',
    paymentMode: 'Corporate Card',
    receiptName: '',
    receiptMimeType: '',
    receiptUrl: '',
    preApprovalRef: '',
    aiConfidenceScore: 0,
    aiExtracted: false,
    aiCategoryReason: '',
    aiPolicyRecommendation: '',
    justification: '',
  };
}

async function readAndOptimizeReceiptFile(file: File): Promise<{
  dataUrl: string;
  mimeType: string;
  name: string;
}> {
  if (file.type.startsWith('image/')) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const maxDim = 1200;
          const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
          const canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve({
              dataUrl: String(reader.result),
              mimeType: file.type,
              name: file.name,
            });
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve({
            dataUrl: canvas.toDataURL('image/jpeg', 0.8),
            mimeType: 'image/jpeg',
            name: file.name,
          });
        };
        img.onerror = () => reject(new Error('Could not decode image receipt.'));
        img.src = String(reader.result);
      };
      reader.onerror = () => reject(new Error('Failed to read file.'));
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      resolve({
        dataUrl: String(reader.result),
        mimeType: file.type || 'application/pdf',
        name: file.name,
      });
    reader.onerror = () => reject(new Error('Failed to read PDF file.'));
    reader.readAsDataURL(file);
  });
}

async function fetchImageUrlAsDataUrl(url: string): Promise<{ dataUrl: string; mimeType: string }> {
  const resp = await fetch(url);
  const blob = await resp.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      resolve({
        dataUrl: String(reader.result),
        mimeType: blob.type || 'image/jpeg',
      });
    reader.onerror = () => reject(new Error('Failed to load sample receipt.'));
    reader.readAsDataURL(blob);
  });
}

function computeOverallScore(conf: AiFieldConfidences): number {
  const vals = Object.values(conf);
  const total = vals.reduce((acc, c) => acc + (c === 'High' ? 96 : c === 'Medium' ? 78 : 52), 0);
  return Math.round(total / vals.length);
}

const FieldConfidenceTag: React.FC<{
  level?: ConfidenceLevel;
  overridden?: boolean;
}> = ({ level, overridden }) => {
  if (!level && !overridden) return null;
  if (overridden) {
    return (
      <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
        Edited
      </span>
    );
  }
  if (level === 'Low') {
    return (
      <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
        Low · Review
      </span>
    );
  }
  if (level === 'Medium') {
    return (
      <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-blue-50 text-[#3368A0] border border-blue-200">
        Medium
      </span>
    );
  }
  return (
    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
      High
    </span>
  );
};

export const ClaimFormView: React.FC = () => {
  const { currentUser, claims, policies, editingClaimId, navigate, saveClaim } = useApp();
  const today = new Date().toISOString().slice(0, 10);

  const editingClaim = useMemo(
    () => (editingClaimId ? claims.find((c) => c.id === editingClaimId) : undefined),
    [claims, editingClaimId]
  );

  const [purpose, setPurpose] = useState('');
  const [destination, setDestination] = useState('Mumbai');
  const [tripFromDate, setTripFromDate] = useState(today);
  const [tripToDate, setTripToDate] = useState(today);
  const [lines, setLines] = useState<DraftLine[]>([createEmptyLine(today)]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);
  const [extractingLines, setExtractingLines] = useState<Record<string, boolean>>({});
  const [aiErrorByLine, setAiErrorByLine] = useState<Record<string, string>>({});
  const [previewLine, setPreviewLine] = useState<ExpenseLine | null>(null);
  const [checkingCompliance, setCheckingCompliance] = useState(false);
  const [preCheckResult, setPreCheckResult] = useState<AiPreSubmissionCheckResult | null>(null);
  const [preCheckError, setPreCheckError] = useState('');

  useEffect(() => {
    if (editingClaim) {
      setPurpose(editingClaim.purpose);
      setDestination(editingClaim.destination);
      setTripFromDate(editingClaim.tripFromDate);
      setTripToDate(editingClaim.tripToDate);
      setLines(
        editingClaim.lines.map((l) => ({
          tempId: l.id,
          date: l.date,
          category: l.category,
          merchant: l.merchant,
          amount: l.amount,
          gstAmount: l.gstAmount,
          gstin: l.gstin,
          currency: l.currency || 'INR',
          invoiceNo: l.invoiceNo,
          paymentMode: l.paymentMode,
          receiptName: l.receiptName,
          receiptMimeType: l.receiptMimeType,
          receiptUrl: l.receiptUrl,
          preApprovalRef: l.preApprovalRef || '',
          aiConfidenceScore: l.aiConfidenceScore,
          aiExtracted: Boolean(l.aiExtracted),
          aiCategoryReason: l.aiCategoryReason || '',
          aiFieldConfidence: l.aiFieldConfidence,
          aiSuggestedValues: l.aiSuggestedValues,
          aiPolicyRecommendation: l.aiPolicyRecommendation || '',
          justification: l.justification,
        }))
      );
    } else {
      setPurpose('');
      setDestination('Mumbai');
      setTripFromDate(today);
      setTripToDate(today);
      setLines([createEmptyLine(today)]);
    }
    setError('');
    setExtractingLines({});
    setAiErrorByLine({});
    setPreCheckResult(null);
    setPreCheckError('');
  }, [editingClaim, today]);

  if (!currentUser) return null;

  const cityTier = getCityTier(destination);

  const complianceSummary = evaluateClaimCompliance(
    {
      tripFromDate,
      tripToDate,
      lines,
    },
    currentUser.grade,
    cityTier,
    policies,
    claims,
    editingClaim?.id
  );

  const lineEvaluations = complianceSummary.lineEvaluations;
  const dupResult = {
    isDuplicate: Boolean(complianceSummary.duplicateClaimNo),
    matchedClaimNo: complianceSummary.duplicateClaimNo,
  };

  const totalAmount = lines.reduce((s, l) => s + Number(l.amount || 0), 0);
  const totalGst = lines.reduce((s, l) => s + Number(l.gstAmount || 0), 0);

  const updateLineByTempId = (tempId: string, patch: Partial<DraftLine>) => {
    setLines((prev) => prev.map((l) => (l.tempId === tempId ? { ...l, ...patch } : l)));
  };

  const runAiExtraction = async (
    tempId: string,
    dataUrl: string,
    mimeType: string,
    fileName: string
  ) => {
    setExtractingLines((prev) => ({ ...prev, [tempId]: true }));
    setAiErrorByLine((prev) => {
      const next = { ...prev };
      delete next[tempId];
      return next;
    });

    try {
      const res = await extractReceiptWithAI(dataUrl, mimeType, fileName);
      const snapshot: AiSuggestedSnapshot = {
        merchant: res.merchant,
        date: res.date,
        invoiceNo: res.invoiceNo,
        amount: res.totalAmount,
        gstAmount: res.gstAmount,
        gstin: res.gstin,
        currency: res.currency || 'INR',
        paymentMode: res.paymentMode,
        category: res.suggestedCategory,
      };

      updateLineByTempId(tempId, {
        merchant: res.merchant,
        date: res.date,
        invoiceNo: res.invoiceNo,
        amount: res.totalAmount,
        gstAmount: res.gstAmount,
        gstin: res.gstin,
        currency: res.currency || 'INR',
        paymentMode: res.paymentMode,
        category: res.suggestedCategory,
        aiExtracted: true,
        aiCategoryReason: res.categoryReason,
        aiFieldConfidence: res.fieldConfidence,
        aiSuggestedValues: snapshot,
        aiConfidenceScore: computeOverallScore(res.fieldConfidence),
      });
    } catch (err) {
      setAiErrorByLine((prev) => ({
        ...prev,
        [tempId]:
          err instanceof Error
            ? err.message
            : 'AI receipt extraction failed. Please enter fields manually.',
      }));
    } finally {
      setExtractingLines((prev) => ({ ...prev, [tempId]: false }));
    }
  };

  const handleFileForLine = async (idx: number, file: File | undefined) => {
    if (!file) return;
    const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    if (
      !validTypes.includes(file.type) &&
      !/\.(pdf|jpg|jpeg|png|webp)$/i.test(file.name)
    ) {
      setError('Only PDF, JPG, PNG, and WEBP receipt files are supported.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError('Receipt file must be under 5 MB.');
      return;
    }
    const target = lines[idx];
    if (!target) return;

    try {
      setError('');
      const optimized = await readAndOptimizeReceiptFile(file);
      updateLineByTempId(target.tempId, {
        receiptName: optimized.name,
        receiptMimeType: optimized.mimeType,
        receiptUrl: optimized.dataUrl,
      });
      await runAiExtraction(target.tempId, optimized.dataUrl, optimized.mimeType, optimized.name);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process receipt.');
    }
  };

  const handleLoadSampleReceipt = async (idx: number, sampleType: 'hotel' | 'flight') => {
    const target = lines[idx];
    if (!target) return;
    const url = sampleType === 'hotel' ? SAMPLE_RECEIPT_HOTEL : SAMPLE_RECEIPT_FLIGHT;
    const name = sampleType === 'hotel' ? 'orchid_hotel_tax_invoice.jpg' : 'indigo_eticket_tax_invoice.jpg';

    try {
      setError('');
      const { dataUrl, mimeType } = await fetchImageUrlAsDataUrl(url);
      updateLineByTempId(target.tempId, {
        receiptName: name,
        receiptMimeType: mimeType,
        receiptUrl: dataUrl,
      });
      await runAiExtraction(target.tempId, dataUrl, mimeType, name);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load sample receipt.');
    }
  };

  const handleRunPreSubmissionCheck = async () => {
    setPreCheckError('');
    setCheckingCompliance(true);
    try {
      const result = await runAiComplianceCheck({
        claimHeader: {
          claimNo: editingClaim?.claimNo,
          employeeName: currentUser.name,
          grade: currentUser.grade,
          department: currentUser.department,
          destination,
          cityTier,
          tripFromDate,
          tripToDate,
          purpose: purpose || 'Business Trip Expense Claim',
          totalAmount,
          totalGstAmount: totalGst,
        },
        lines: lines.map((l, idx) => ({
          lineNumber: idx + 1,
          date: l.date,
          category: l.category,
          merchant: l.merchant || `Line #${idx + 1}`,
          amount: Number(l.amount || 0),
          gstAmount: Number(l.gstAmount || 0),
          gstin: l.gstin || '',
          hasReceipt: Boolean(l.receiptName || l.receiptUrl),
          preApprovalRef: l.preApprovalRef || '',
          justification: l.justification || '',
        })),
        summary: complianceSummary,
      });

      setPreCheckResult(result);

      if (result.lineRecommendations.length > 0) {
        setLines((prev) =>
          prev.map((l, idx) => {
            const match = result.lineRecommendations.find((r) => r.lineNumber === idx + 1);
            return match?.recommendation
              ? { ...l, aiPolicyRecommendation: match.recommendation }
              : l;
          })
        );
      }
    } catch (err) {
      setPreCheckError(
        err instanceof Error
          ? err.message
          : 'AI explanation temporarily unavailable. Deterministic policy checks above remain active.'
      );
      setPreCheckResult({
        complianceScore: complianceSummary.complianceScore,
        executiveSummary:
          complianceSummary.hasExceptions
            ? `Deterministic policy engine flagged ${complianceSummary.exceptionCount} policy exception(s) against Nova Foods expense_policies.`
            : 'All deterministic checks against Nova Foods expense_policies passed.',
        gstAssessment:
          totalGst > 0
            ? `Total GST of ${formatINR(totalGst)} recorded across claim lines.`
            : 'No GST amount recorded on current line items.',
        lineRecommendations: lineEvaluations.map((ev, idx) => ({
          lineNumber: idx + 1,
          recommendation: ev.aiRecommendation,
        })),
        prioritizedFixes: complianceSummary.issues.map((iss) => ({
          lineNumber: iss.lineNumber,
          issueTitle: iss.title,
          severity: iss.severity,
          suggestedFix: iss.suggestedFix,
        })),
      });
    } finally {
      setCheckingCompliance(false);
    }
  };

  const validateBeforeSave = (submitImmediately: boolean): string | null => {
    if (purpose.trim().length < 3) return 'Please enter a trip or expense purpose (min 3 characters).';
    if (!tripFromDate || !tripToDate) return 'Please select trip start and end dates.';
    if (tripToDate < tripFromDate) return 'Trip To date cannot be earlier than From date.';
    if (lines.length === 0) return 'Add at least one expense line item.';

    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (!l.merchant.trim()) return `Line ${i + 1}: Merchant name is required.`;
      if (!l.amount || l.amount <= 0) return `Line ${i + 1}: Amount must be greater than 0.`;
      const gstCheck = validateGstAndGstin(l.amount, l.gstAmount, l.gstin);
      if (!gstCheck.gstinValid && submitImmediately) {
        return `Line ${i + 1}: ${gstCheck.warnings[0]}`;
      }
      if (submitImmediately) {
        const pol = lineEvaluations[i];
        if (pol.hasException && !l.justification.trim()) {
          const issueTitles = pol.issues
            .filter((x) => x.severity === 'exception')
            .map((x) => x.title)
            .join(', ');
          return `Line ${i + 1} has a Policy Exception (${issueTitles}). A justification is mandatory to submit.`;
        }
      }
    }
    return null;
  };

  const handleSave = async (submitImmediately: boolean) => {
    const errMsg = validateBeforeSave(submitImmediately);
    if (errMsg) {
      setError(errMsg);
      return;
    }
    setError('');
    setSaving(true);
    try {
      const saved = await saveClaim(
        {
          id: editingClaim?.id,
          purpose,
          destination,
          tripFromDate,
          tripToDate,
          aiComplianceSummary: preCheckResult?.executiveSummary,
          lines: lines.map(({ tempId: _tempId, ...rest }) => rest),
        },
        submitImmediately
      );
      navigate('claim-detail', { claimId: saved.id, editClaimId: null });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save claim.');
    } finally {
      setSaving(false);
    }
  };

  const isFieldOverridden = (line: DraftLine, field: keyof AiSuggestedSnapshot, val: string | number) => {
    if (!line.aiExtracted || !line.aiSuggestedValues) return false;
    return String(line.aiSuggestedValues[field] ?? '').trim() !== String(val ?? '').trim();
  };

  const getInputHighlightClass = (
    line: DraftLine,
    confKey: keyof AiFieldConfidences,
    suggestedKey: keyof AiSuggestedSnapshot,
    currentVal: string | number
  ) => {
    const isLow =
      line.aiExtracted &&
      line.aiFieldConfidence?.[confKey] === 'Low' &&
      !isFieldOverridden(line, suggestedKey, currentVal);
    return isLow
      ? 'border-amber-400 bg-amber-50/60 focus:ring-amber-300 focus:border-amber-500'
      : 'border-slate-300 bg-white focus:ring-[#3368A0]/25 focus:border-[#3368A0]';
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate('my-claims', { editClaimId: null })}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to My Claims
        </button>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={checkingCompliance}
            onClick={handleRunPreSubmissionCheck}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#66A3BF] bg-[#C8DFDB]/35 text-xs font-semibold text-[#3368A0] hover:bg-[#C8DFDB]/60 cursor-pointer disabled:opacity-50"
          >
            {checkingCompliance ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            {checkingCompliance ? 'Checking Policy...' : 'AI Pre-Submission Check'}
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={() => handleSave(false)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            Save as Draft
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={() => handleSave(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            {saving ? 'Submitting...' : 'Submit Claim'}
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {dupResult.isDuplicate && (
        <div className="rounded-xl border border-rose-300 bg-rose-50 px-4 py-3 text-xs text-rose-800 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>
            Duplicate Alert: One or more lines match invoice/merchant details in{' '}
            <strong className="font-mono-num">{dupResult.matchedClaimNo}</strong>. Finance will flag this claim on submission.
          </span>
        </div>
      )}

      {/* Claim-Level Compliance Score & AI Pre-Submission Check Panel */}
      <section className="bg-white rounded-2xl border border-[#66A3BF]/50 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                complianceSummary.complianceScore >= 85
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : complianceSummary.complianceScore >= 60
                    ? 'bg-amber-50 text-amber-800 border border-amber-200'
                    : 'bg-red-50 text-red-700 border border-red-200'
              }`}
            >
              {complianceSummary.hasExceptions ? (
                <ShieldAlert className="w-5 h-5" />
              ) : (
                <ShieldCheck className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  Policy Compliance Engine (Deterministic Rules + AI Advisor)
                </h3>
                {complianceSummary.hasExceptions ? (
                  <PolicyExceptionTag compact />
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-[11px] font-medium text-emerald-700">
                    <CheckCircle2 className="w-3 h-3" />
                    Compliant
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Checks Grade <strong>{currentUser.grade}</strong> &amp;{' '}
                <strong>{cityTier}</strong> caps from{' '}
                <span className="font-mono-num">expense_policies</span>, mandatory receipts,
                weekend/holiday dates, trip date window, and pre-approvals.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <div className="text-right">
              <div className="text-[11px] font-medium text-slate-500">Compliance Score</div>
              <div className="flex items-baseline gap-1 justify-end">
                <span
                  className={`text-2xl font-bold font-mono-num ${
                    complianceSummary.complianceScore >= 85
                      ? 'text-emerald-700'
                      : complianceSummary.complianceScore >= 60
                        ? 'text-amber-700'
                        : 'text-red-700'
                  }`}
                >
                  {complianceSummary.complianceScore}
                </span>
                <span className="text-xs text-slate-400 font-mono-num">/ 100</span>
              </div>
            </div>
            <button
              type="button"
              disabled={checkingCompliance}
              onClick={handleRunPreSubmissionCheck}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer disabled:opacity-50"
            >
              {checkingCompliance ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              {checkingCompliance ? 'Reviewing Claim...' : 'Run AI Pre-Submission Check'}
            </button>
          </div>
        </div>

        {preCheckError && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900 flex items-center justify-between gap-2">
            <span>{preCheckError}</span>
            <button
              type="button"
              onClick={() => setPreCheckError('')}
              className="text-[11px] font-medium underline cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {checkingCompliance && (
          <AiSummarySkeleton label="Checking policy caps, GSTIN & trip dates with Gemini AI..." />
        )}

        {!checkingCompliance && preCheckResult && (
          <div className="rounded-xl border border-[#66A3BF]/50 bg-[#C8DFDB]/20 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#3368A0]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Pre-Submission Review · Score {preCheckResult.complianceScore}/100</span>
              </div>
              <span className="text-[11px] text-slate-500">
                Limits verified against Nova Foods expense_policies
              </span>
            </div>
            <p className="text-xs text-slate-800 leading-relaxed">
              {preCheckResult.executiveSummary}
            </p>
            {preCheckResult.gstAssessment && (
              <p className="text-[11px] text-slate-600">{preCheckResult.gstAssessment}</p>
            )}

            {preCheckResult.prioritizedFixes.length === 0 ? (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>No policy exceptions or warnings detected. Claim is ready for submission.</span>
              </div>
            ) : (
              <div className="space-y-2 pt-1">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-600">
                  Issues Found &amp; Suggested Fixes ({preCheckResult.prioritizedFixes.length})
                </div>
                {preCheckResult.prioritizedFixes.map((fix, fIdx) => (
                  <div
                    key={`${fix.lineNumber}-${fIdx}`}
                    className={`rounded-lg border px-3 py-2 text-xs flex flex-col sm:flex-row sm:items-start justify-between gap-2 ${
                      fix.severity === 'exception'
                        ? 'bg-red-50/70 border-red-200 text-red-900'
                        : 'bg-amber-50/70 border-amber-200 text-amber-900'
                    }`}
                  >
                    <div>
                      <span className="font-semibold">
                        Line #{fix.lineNumber} · {fix.issueTitle}:
                      </span>{' '}
                      <span>{fix.suggestedFix}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Claim Header Form */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              {editingClaim ? `Edit Claim · ${editingClaim.claimNo}` : 'Trip & Claim Header'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {currentUser.name} ({currentUser.employeeCode}) · {currentUser.department} · Cost Centre{' '}
              <span className="font-mono-num">{currentUser.costCentre}</span> · Grade {currentUser.grade}
            </p>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-500">Total Claim Value</div>
            <div className="text-xl font-bold text-slate-900 font-mono-num">
              {formatINR(totalAmount)}
            </div>
            <div className="text-[11px] text-slate-500 font-mono-num">
              Includes {formatINR(totalGst)} GST
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-5">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Business Purpose *
            </label>
            <input
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="e.g., Baramati dairy plant audit & distributor review"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25 focus:border-[#3368A0]"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Destination City ({cityTier}) *
            </label>
            <select
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25"
            >
              {INDIAN_CITIES.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name} ({c.tier})
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">Trip From *</label>
            <input
              type="date"
              value={tripFromDate}
              onChange={(e) => setTripFromDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 font-mono-num focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">Trip To *</label>
            <input
              type="date"
              value={tripToDate}
              onChange={(e) => setTripToDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 font-mono-num focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25"
            />
          </div>
        </div>
      </section>

      {/* Expense Lines */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Expense Line Items ({lines.length})
            </h3>
            <p className="text-xs text-slate-500">
              Upload any PDF, JPG, or PNG receipt — AI automatically extracts invoice fields, GSTIN, currency, and category with confidence scores.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setLines((prev) => [...prev, createEmptyLine(tripFromDate || today)])}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Expense Line
          </button>
        </div>

        {lines.map((line, idx) => {
          const pol = lineEvaluations[idx];
          const gstCheck = validateGstAndGstin(line.amount, line.gstAmount, line.gstin);
          const isExtracting = Boolean(extractingLines[line.tempId]);
          const aiErr = aiErrorByLine[line.tempId];
          const overrides = line.aiExtracted
            ? computeAiOverrides(line.aiSuggestedValues, line)
            : [];
          const hasLowConfidence =
            line.aiExtracted &&
            line.aiFieldConfidence &&
            Object.values(line.aiFieldConfidence).some((v) => v === 'Low');

          return (
            <div
              key={line.tempId}
              className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4"
            >
              {/* Line Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-xs font-semibold text-slate-800">
                    Line #{idx + 1}
                  </span>

                  {line.aiExtracted && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#C8DFDB]/60 border border-[#66A3BF]/50 text-[11px] font-semibold text-[#3368A0]">
                      <Sparkles className="w-3 h-3" />
                      AI extracted
                    </span>
                  )}

                  {isExtracting && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-[11px] font-medium text-[#3368A0]">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Extracting receipt fields with Gemini AI...
                    </span>
                  )}

                  <PolicyFlagBadge flag={pol.flag} reason={pol.reason} />
                  {pol.reason && (
                    <span className="text-xs text-slate-500">{pol.reason}</span>
                  )}
                </div>

                {lines.length > 1 && (
                  <button
                    type="button"
                    onClick={() => setLines((prev) => prev.filter((_, i) => i !== idx))}
                    className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove
                  </button>
                )}
              </div>

              {pol.hasException && (
                <div className="rounded-xl border border-red-300 bg-red-50/80 p-3.5 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-red-800">
                      <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                      <span>
                        ⚠️ Policy Exception
                        {pol.excessAmount > 0 && (
                          <>
                            {' '}
                            – Claimed{' '}
                            <span className="font-mono-num">{formatINR(pol.claimedAmount)}</span> |
                            Permissible{' '}
                            <span className="font-mono-num">{formatINR(pol.permissibleLimit)}</span>{' '}
                            | Excess{' '}
                            <span className="font-mono-num">{formatINR(pol.excessAmount)}</span>
                          </>
                        )}
                      </span>
                    </div>
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-white border border-red-200 text-red-700">
                      Routes to Finance Controller
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {pol.issues
                      .filter((i) => i.severity === 'exception')
                      .map((iss) => (
                        <span
                          key={iss.code}
                          title={iss.summary}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white border border-red-200 text-[11px] font-medium text-red-700"
                        >
                          <AlertCircle className="w-3 h-3 shrink-0" />
                          {iss.title}: {iss.summary}
                        </span>
                      ))}
                  </div>

                  <div className="flex items-start gap-1.5 text-xs text-slate-800 bg-white/80 rounded-lg border border-red-200/70 px-3 py-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#3368A0] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-[#3368A0]">AI Recommendation: </span>
                      <span>{line.aiPolicyRecommendation || pol.aiRecommendation}</span>
                      {!line.justification.trim() && (
                        <span className="block text-[11px] font-semibold text-red-700 mt-1">
                          Justification below is mandatory to submit this claim.
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {aiErr && (
                <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{aiErr}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setAiErrorByLine((prev) => {
                        const next = { ...prev };
                        delete next[line.tempId];
                        return next;
                      })
                    }
                    className="shrink-0 text-[11px] font-medium text-rose-700 hover:underline cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              )}

              {hasLowConfidence && (
                <div className="rounded-lg border border-amber-300 bg-amber-50/70 px-3 py-2 text-xs text-amber-900 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-700" />
                  <span>
                    Fields highlighted in amber have <strong>Low</strong> AI confidence. Please review or override before submitting.
                  </span>
                </div>
              )}

              {gstCheck.warnings.length > 0 && (
                <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-700" />
                  <div>
                    <span className="font-semibold">GST / GSTIN Validation Alert: </span>
                    {gstCheck.warnings.join(' · ')}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                {/* Fields */}
                <div className="lg:col-span-8 space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Invoice Date *
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.date}
                          overridden={isFieldOverridden(line, 'date', line.date)}
                        />
                      </div>
                      <input
                        type="date"
                        value={line.date}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, { date: e.target.value })
                        }
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'date',
                          'date',
                          line.date
                        )}`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Category *
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.category}
                          overridden={isFieldOverridden(line, 'category', line.category)}
                        />
                      </div>
                      <select
                        value={line.category}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, { category: e.target.value })
                        }
                        className={`w-full rounded-lg border px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'category',
                          'category',
                          line.category
                        )}`}
                      >
                        {EXPENSE_CATEGORIES.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Merchant / Vendor *
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.merchant}
                          overridden={isFieldOverridden(line, 'merchant', line.merchant)}
                        />
                      </div>
                      <input
                        type="text"
                        value={line.merchant}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, { merchant: e.target.value })
                        }
                        placeholder="e.g., IndiGo Airlines"
                        className={`w-full rounded-lg border px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'merchant',
                          'merchant',
                          line.merchant
                        )}`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Total Amount *
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.totalAmount}
                          overridden={isFieldOverridden(line, 'amount', line.amount)}
                        />
                      </div>
                      <input
                        type="number"
                        min={0}
                        step="0.01"
                        value={line.amount || ''}
                        onChange={(e) => {
                          const val = Number(e.target.value) || 0;
                          updateLineByTempId(line.tempId, { amount: val });
                        }}
                        placeholder="0"
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'totalAmount',
                          'amount',
                          line.amount
                        )}`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          GST Amount
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.gstAmount}
                          overridden={isFieldOverridden(line, 'gstAmount', line.gstAmount)}
                        />
                      </div>
                      <input
                        type="number"
                        min={0}
                        step="0.01"
                        value={line.gstAmount || ''}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, {
                            gstAmount: Number(e.target.value) || 0,
                          })
                        }
                        placeholder="0"
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'gstAmount',
                          'gstAmount',
                          line.gstAmount
                        )}`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Currency
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.currency}
                          overridden={isFieldOverridden(line, 'currency', line.currency)}
                        />
                      </div>
                      <select
                        value={line.currency}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, { currency: e.target.value })
                        }
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'currency',
                          'currency',
                          line.currency
                        )}`}
                      >
                        {CURRENCIES.map((cur) => (
                          <option key={cur} value={cur}>
                            {cur}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Invoice No.
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.invoiceNo}
                          overridden={isFieldOverridden(line, 'invoiceNo', line.invoiceNo)}
                        />
                      </div>
                      <input
                        type="text"
                        value={line.invoiceNo}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, { invoiceNo: e.target.value })
                        }
                        placeholder="INV-2026-..."
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'invoiceNo',
                          'invoiceNo',
                          line.invoiceNo
                        )}`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Vendor GSTIN (15 chars)
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.gstin}
                          overridden={isFieldOverridden(line, 'gstin', line.gstin)}
                        />
                      </div>
                      <input
                        type="text"
                        maxLength={15}
                        value={line.gstin}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, {
                            gstin: e.target.value.toUpperCase(),
                          })
                        }
                        placeholder="27AAACI1681G1Z2"
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 uppercase focus:outline-none focus:ring-2 ${
                          !gstCheck.gstinValid
                            ? 'border-rose-400 bg-rose-50/40 focus:ring-rose-300'
                            : getInputHighlightClass(line, 'gstin', 'gstin', line.gstin)
                        }`}
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Payment Mode
                        </label>
                        <FieldConfidenceTag
                          level={line.aiFieldConfidence?.paymentMode}
                          overridden={isFieldOverridden(line, 'paymentMode', line.paymentMode)}
                        />
                      </div>
                      <select
                        value={line.paymentMode}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, {
                            paymentMode: e.target.value as PaymentMode,
                          })
                        }
                        className={`w-full rounded-lg border px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 ${getInputHighlightClass(
                          line,
                          'paymentMode',
                          'paymentMode',
                          line.paymentMode
                        )}`}
                      >
                        {PAYMENT_MODES.map((pm) => (
                          <option key={pm} value={pm}>
                            {pm}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <label className="text-xs font-medium text-slate-600">
                          Pre-Approval Ref{' '}
                          {pol.requiresPreApproval && <span className="text-red-600">*</span>}
                        </label>
                        {pol.requiresPreApproval && !line.preApprovalRef.trim() && (
                          <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-red-50 text-red-700 border border-red-200">
                            Required
                          </span>
                        )}
                      </div>
                      <input
                        type="text"
                        value={line.preApprovalRef}
                        onChange={(e) =>
                          updateLineByTempId(line.tempId, {
                            preApprovalRef: e.target.value.toUpperCase(),
                          })
                        }
                        placeholder={pol.requiresPreApproval ? 'PA-2026-0142' : 'Optional (if pre-approved)'}
                        className={`w-full rounded-lg border px-3 py-2 text-xs font-mono-num text-slate-900 focus:outline-none focus:ring-2 ${
                          pol.requiresPreApproval && !line.preApprovalRef.trim()
                            ? 'border-red-300 bg-red-50/40 focus:ring-red-200'
                            : 'border-slate-300 bg-white focus:ring-[#3368A0]/25'
                        }`}
                      />
                    </div>
                  </div>

                  {/* AI Category Reason */}
                  {line.aiExtracted && line.aiCategoryReason && (
                    <div className="rounded-lg bg-[#C8DFDB]/25 border border-[#66A3BF]/40 px-3 py-2 text-xs text-slate-800 flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-[#3368A0] shrink-0" />
                      <span>{line.aiCategoryReason}</span>
                    </div>
                  )}

                  {/* Justification */}
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <label className="block text-xs font-medium text-slate-600">
                        Business Justification / Exception Remarks{' '}
                        {pol.hasException && (
                          <span className="text-red-600 font-semibold">
                            * (Mandatory due to Policy Exception)
                          </span>
                        )}
                      </label>
                    </div>
                    <input
                      type="text"
                      value={line.justification}
                      onChange={(e) =>
                        updateLineByTempId(line.tempId, { justification: e.target.value })
                      }
                      placeholder={
                        pol.hasException
                          ? 'Required: Explain business reason for policy exception...'
                          : 'Purpose of expense or additional remarks...'
                      }
                      className={`w-full rounded-lg border px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 ${
                        pol.hasException && !line.justification.trim()
                          ? 'border-red-300 bg-red-50/40 focus:ring-red-200'
                          : 'border-slate-300 bg-white focus:ring-[#3368A0]/25'
                      }`}
                    />
                  </div>

                  {/* Live Audit Log Preview of AI-Suggested vs User-Final */}
                  {line.aiExtracted && (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[11px] text-slate-600 flex flex-wrap items-center justify-between gap-2">
                      {overrides.length === 0 ? (
                        <span className="inline-flex items-center gap-1.5 text-emerald-700 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Audit Log: All final values match AI-extracted suggestions.
                        </span>
                      ) : (
                        <div>
                          <span className="font-semibold text-slate-800">
                            Audit Log ({overrides.length} user override{overrides.length > 1 ? 's' : ''}):{' '}
                          </span>
                          {overrides.map((ov, ovIdx) => (
                            <span key={ov.field} className="mr-2">
                              {ovIdx > 0 && '· '}
                              <strong>{ov.field}</strong>: AI{' '}
                              <span className="line-through text-slate-400">{ov.aiValue}</span> →{' '}
                              <span className="text-[#3368A0] font-medium">{ov.userValue}</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Receipt Drag & Drop Zone */}
                <div className="lg:col-span-4 flex flex-col justify-between gap-2.5">
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragOverIdx(idx);
                    }}
                    onDragLeave={() => setDragOverIdx(null)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragOverIdx(null);
                      handleFileForLine(idx, e.dataTransfer.files?.[0]);
                    }}
                    className={`rounded-xl border border-dashed p-4 flex flex-col items-center justify-center text-center transition-colors min-h-[180px] ${
                      dragOverIdx === idx
                        ? 'border-[#3368A0] bg-[#C8DFDB]/30'
                        : 'border-slate-300 bg-slate-50/70'
                    }`}
                  >
                    {line.receiptUrl ? (
                      <div className="w-full space-y-2.5">
                        <div className="flex items-center gap-2.5 bg-white border border-slate-200 rounded-lg p-2 text-left">
                          {line.receiptMimeType.startsWith('image/') ? (
                            <img
                              src={line.receiptUrl}
                              alt={line.receiptName}
                              referrerPolicy="no-referrer"
                              className="w-10 h-10 rounded object-cover border border-slate-200 shrink-0"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded bg-blue-50 text-[#3368A0] flex items-center justify-center shrink-0">
                              <FileText className="w-5 h-5" />
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium text-slate-900 truncate">
                              {line.receiptName}
                            </p>
                            <p className="text-[11px] text-emerald-700">
                              {isExtracting
                                ? 'Analyzing with AI...'
                                : line.aiExtracted
                                  ? `AI extracted (${line.aiConfidenceScore}% avg)`
                                  : 'Attached & ready'}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              setPreviewLine({
                                id: line.tempId,
                                claimId: editingClaim?.id || 'draft',
                                ...line,
                                policyFlag: pol.flag,
                                policyFlagReason: pol.reason,
                                ownerUid: currentUser.ownerUid,
                              })
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Preview
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              updateLineByTempId(line.tempId, {
                                receiptName: '',
                                receiptMimeType: '',
                                receiptUrl: '',
                              })
                            }
                            className="px-2.5 py-1 rounded-md border border-slate-200 bg-white text-xs font-medium text-rose-600 hover:bg-rose-50 cursor-pointer"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <UploadCloud className="w-6 h-6 text-[#3368A0] mb-2" />
                        <p className="text-xs font-medium text-slate-700">
                          Drop receipt (PDF, JPG, PNG) to auto-fill with AI
                        </p>
                        <label className="mt-2 inline-flex items-center px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer">
                          Browse File
                          <input
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
                            className="hidden"
                            onChange={(e) => handleFileForLine(idx, e.target.files?.[0])}
                          />
                        </label>
                        <div className="mt-3 pt-2.5 border-t border-slate-200/80 w-full flex items-center justify-center gap-2 text-[11px]">
                          <button
                            type="button"
                            onClick={() => handleLoadSampleReceipt(idx, 'hotel')}
                            className="text-[#3368A0] hover:underline cursor-pointer"
                          >
                            Test Hotel Invoice
                          </button>
                          <span className="text-slate-300">·</span>
                          <button
                            type="button"
                            onClick={() => handleLoadSampleReceipt(idx, 'flight')}
                            className="text-[#3368A0] hover:underline cursor-pointer"
                          >
                            Test Flight Ticket
                          </button>
                        </div>
                      </>
                    )}
                  </div>

                  {line.receiptUrl && (
                    <button
                      type="button"
                      disabled={isExtracting}
                      onClick={() =>
                        runAiExtraction(
                          line.tempId,
                          line.receiptUrl,
                          line.receiptMimeType,
                          line.receiptName
                        )
                      }
                      className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-[#66A3BF]/60 bg-[#C8DFDB]/25 text-[#3368A0] text-xs font-medium hover:bg-[#C8DFDB]/45 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      {isExtracting ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <RefreshCw className="w-3.5 h-3.5" />
                      )}
                      {isExtracting ? 'Extracting...' : 'Re-run AI Extraction'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </section>

      <ReceiptPreviewModal line={previewLine} onClose={() => setPreviewLine(null)} />
    </div>
  );
};
