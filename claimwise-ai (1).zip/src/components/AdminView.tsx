import React, { useMemo, useState } from 'react';
import {
  Check,
  Edit3,
  Plus,
  RotateCcw,
  Search,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  DEPARTMENTS_LIST,
  EXPENSE_CATEGORIES,
  ExpensePolicy,
  Grade,
  PolicyCityTier,
  UserProfile,
  UserRole,
} from '../types/claimwise';
import { formatDateTimeDDMMMYYYY, formatINR } from '../utils/formatters';
import { ConfirmDialog } from './ConfirmDialog';
import { RoleBadge } from './StatusBadge';

export const AdminView: React.FC = () => {
  const {
    users,
    policies,
    departments,
    costCentres,
    auditTrail,
    updatePolicy,
    addPolicy,
    updateUser,
    addUser,
    addDepartment,
    addCostCentre,
    resetDemoWorkspace,
    showToast,
  } = useApp();

  const [tab, setTab] = useState<'policies' | 'users' | 'org' | 'audit'>('policies');
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const [policyCatFilter, setPolicyCatFilter] = useState<string>('All');
  const [editingPolicyId, setEditingPolicyId] = useState<string | null>(null);
  const [policyDraft, setPolicyDraft] = useState<ExpensePolicy | null>(null);

  const [userSearch, setUserSearch] = useState('');
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userDraft, setUserDraft] = useState<UserProfile | null>(null);
  const [showAddUser, setShowAddUser] = useState(false);

  const [newUser, setNewUser] = useState({
    name: '',
    employeeCode: `NF-${1021 + users.length}`,
    email: '',
    role: 'employee' as UserRole,
    department: 'Sales',
    costCentre: 'CC-MUM-101',
    grade: 'G2' as Grade,
    managerId: 'u-mgr-1',
    location: 'Mumbai',
    isActive: true,
  });

  const [showAddPolicy, setShowAddPolicy] = useState(false);
  const [newPolicy, setNewPolicy] = useState({
    category: 'Airfare',
    grade: 'G2' as Grade,
    limitPerDay: 0,
    limitPerUnit: 9000,
    cityTier: 'All' as PolicyCityTier,
    requiresReceipt: true,
    requiresPreApproval: false,
    gstEligible: true,
    notes: '',
  });

  const [newDept, setNewDept] = useState({ code: '', name: '', headName: '', annualBudgetInr: 1500000 });
  const [newCC, setNewCC] = useState({ code: '', name: '', department: 'Sales', location: 'Mumbai' });

  const filteredPolicies = useMemo(
    () =>
      policies.filter(
        (p) => policyCatFilter === 'All' || p.category === policyCatFilter
      ),
    [policies, policyCatFilter]
  );

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        u.name.toLowerCase().includes(q) ||
        u.employeeCode.toLowerCase().includes(q) ||
        u.department.toLowerCase().includes(q) ||
        u.location.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q)
    );
  }, [users, userSearch]);

  const managersList = useMemo(
    () => users.filter((u) => u.role === 'manager' || u.role === 'finance'),
    [users]
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#3368A0]" />
            <h2 className="text-lg font-semibold text-slate-900">
              Admin Console · Nova Foods India Pvt Ltd
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Configure expense policy caps (G1–G5), manage 20+ employees &amp; roles, departments, cost centres, and review audit logs.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-slate-100 p-1 rounded-lg overflow-x-auto">
            {(
              [
                { id: 'policies', label: 'Policy Rules' },
                { id: 'users', label: `Users (${users.length})` },
                { id: 'org', label: 'Depts & Cost Centres' },
                { id: 'audit', label: 'Audit Trail' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer whitespace-nowrap ${
                  tab === t.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setConfirmResetOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-rose-200 bg-rose-50/70 text-xs font-medium text-rose-700 hover:bg-rose-100 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Demo Data
          </button>
        </div>
      </div>

      {/* TAB 1: Editable Expense Policy Rules Table */}
      {tab === 'policies' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-600">Filter Category:</span>
              <select
                value={policyCatFilter}
                onChange={(e) => setPolicyCatFilter(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs text-slate-800"
              >
                <option value="All">All 10 Categories</option>
                {EXPENSE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => setShowAddPolicy((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Policy Rule
            </button>
          </div>

          {showAddPolicy && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 grid grid-cols-1 sm:grid-cols-4 gap-3">
              <select
                value={newPolicy.category}
                onChange={(e) => setNewPolicy({ ...newPolicy, category: e.target.value })}
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                {EXPENSE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <select
                value={newPolicy.grade}
                onChange={(e) => setNewPolicy({ ...newPolicy, grade: e.target.value as Grade })}
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                {(['G1', 'G2', 'G3', 'G4', 'G5'] as Grade[]).map((g) => (
                  <option key={g} value={g}>
                    Grade {g}
                  </option>
                ))}
              </select>
              <select
                value={newPolicy.cityTier}
                onChange={(e) =>
                  setNewPolicy({ ...newPolicy, cityTier: e.target.value as PolicyCityTier })
                }
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                <option value="All">All Cities</option>
                <option value="Tier 1">Tier 1</option>
                <option value="Tier 2">Tier 2</option>
              </select>
              <input
                type="number"
                value={newPolicy.limitPerUnit}
                onChange={(e) =>
                  setNewPolicy({
                    ...newPolicy,
                    limitPerUnit: Number(e.target.value) || 0,
                    limitPerDay: Number(e.target.value) || 0,
                  })
                }
                placeholder="Limit ₹"
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono-num"
              />
              <input
                type="text"
                value={newPolicy.notes}
                onChange={(e) => setNewPolicy({ ...newPolicy, notes: e.target.value })}
                placeholder="Policy rule notes..."
                className="sm:col-span-2 rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <label className="inline-flex items-center gap-2 text-xs text-slate-700">
                <input
                  type="checkbox"
                  checked={newPolicy.requiresReceipt}
                  onChange={(e) =>
                    setNewPolicy({ ...newPolicy, requiresReceipt: e.target.checked })
                  }
                />
                Receipt Mandatory
              </label>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddPolicy(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (newPolicy.limitPerUnit <= 0 && newPolicy.limitPerDay <= 0) {
                      showToast('Enter a positive rupee cap for the policy rule.', 'error');
                      return;
                    }
                    await addPolicy(newPolicy);
                    setShowAddPolicy(false);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium cursor-pointer"
                >
                  Save Rule
                </button>
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Grade</th>
                    <th className="py-3 px-4">City Tier</th>
                    <th className="py-3 px-4 text-right">Limit / Day (₹)</th>
                    <th className="py-3 px-4 text-right">Limit / Unit (₹)</th>
                    <th className="py-3 px-4 text-center">Receipt Req.</th>
                    <th className="py-3 px-4 text-center">Pre-Approval</th>
                    <th className="py-3 px-4">Notes</th>
                    <th className="py-3 px-4 text-right">Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPolicies.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-10 text-center text-xs text-slate-500">
                        No policy rules match the selected category filter.{' '}
                        <button
                          type="button"
                          onClick={() => setPolicyCatFilter('All')}
                          className="text-[#3368A0] font-medium hover:underline cursor-pointer"
                        >
                          Show all categories
                        </button>
                      </td>
                    </tr>
                  ) : (
                    filteredPolicies.map((p) => {
                    const isEditing = editingPolicyId === p.id && policyDraft;
                    return (
                      <tr key={p.id} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-4 font-semibold text-slate-900 whitespace-nowrap">
                          {p.category}
                        </td>
                        <td className="py-2.5 px-4 font-mono-num">{p.grade}</td>
                        <td className="py-2.5 px-4 whitespace-nowrap">
                          {isEditing ? (
                            <select
                              value={policyDraft.cityTier}
                              onChange={(e) =>
                                setPolicyDraft({
                                  ...policyDraft,
                                  cityTier: e.target.value as PolicyCityTier,
                                })
                              }
                              className="rounded border border-slate-300 px-2 py-1 text-xs bg-white"
                            >
                              <option value="All">All</option>
                              <option value="Tier 1">Tier 1</option>
                              <option value="Tier 2">Tier 2</option>
                            </select>
                          ) : (
                            p.cityTier
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono-num">
                          {isEditing ? (
                            <input
                              type="number"
                              value={policyDraft.limitPerDay}
                              onChange={(e) =>
                                setPolicyDraft({
                                  ...policyDraft,
                                  limitPerDay: Number(e.target.value) || 0,
                                })
                              }
                              className="w-24 rounded border border-slate-300 px-2 py-1 text-right text-xs"
                            />
                          ) : p.limitPerDay > 0 ? (
                            formatINR(p.limitPerDay)
                          ) : (
                            '—'
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono-num font-semibold text-slate-900">
                          {isEditing ? (
                            <input
                              type="number"
                              value={policyDraft.limitPerUnit}
                              onChange={(e) =>
                                setPolicyDraft({
                                  ...policyDraft,
                                  limitPerUnit: Number(e.target.value) || 0,
                                })
                              }
                              className="w-24 rounded border border-slate-300 px-2 py-1 text-right text-xs"
                            />
                          ) : (
                            formatINR(p.limitPerUnit)
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          {isEditing ? (
                            <input
                              type="checkbox"
                              checked={policyDraft.requiresReceipt}
                              onChange={(e) =>
                                setPolicyDraft({
                                  ...policyDraft,
                                  requiresReceipt: e.target.checked,
                                })
                              }
                            />
                          ) : p.requiresReceipt ? (
                            'Yes'
                          ) : (
                            'No'
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          {isEditing ? (
                            <input
                              type="checkbox"
                              checked={policyDraft.requiresPreApproval}
                              onChange={(e) =>
                                setPolicyDraft({
                                  ...policyDraft,
                                  requiresPreApproval: e.target.checked,
                                })
                              }
                            />
                          ) : p.requiresPreApproval ? (
                            'Yes'
                          ) : (
                            'No'
                          )}
                        </td>
                        <td className="py-2.5 px-4 max-w-xs text-slate-600">
                          {isEditing ? (
                            <input
                              type="text"
                              value={policyDraft.notes}
                              onChange={(e) =>
                                setPolicyDraft({ ...policyDraft, notes: e.target.value })
                              }
                              className="w-full rounded border border-slate-300 px-2 py-1 text-xs"
                            />
                          ) : (
                            <span className="truncate block">{p.notes}</span>
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-right whitespace-nowrap">
                          {isEditing ? (
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={async () => {
                                  await updatePolicy(policyDraft);
                                  setEditingPolicyId(null);
                                  setPolicyDraft(null);
                                }}
                                className="p-1.5 rounded bg-emerald-600 text-white cursor-pointer"
                                title="Save"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingPolicyId(null);
                                  setPolicyDraft(null);
                                }}
                                className="p-1.5 rounded bg-slate-200 text-slate-700 cursor-pointer"
                                title="Cancel"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingPolicyId(p.id);
                                setPolicyDraft({ ...p });
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" />
                              Edit
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Users & Roles Directory */}
      {tab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative max-w-md w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search employees by name, code, department, city..."
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 bg-white text-xs text-slate-900"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowAddUser((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer self-start"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Employee
            </button>
          </div>

          {showAddUser && (
            <div className="bg-white rounded-2xl border border-slate-200 p-5 grid grid-cols-1 sm:grid-cols-4 gap-3">
              <input
                type="text"
                value={newUser.name}
                onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                placeholder="Full Name *"
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <input
                type="text"
                value={newUser.employeeCode}
                onChange={(e) => setNewUser({ ...newUser, employeeCode: e.target.value })}
                placeholder="Emp Code (NF-1021)"
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono-num"
              />
              <input
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                placeholder="Email (@novafoods.in) *"
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <select
                value={newUser.role}
                onChange={(e) => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                <option value="employee">Employee</option>
                <option value="manager">Manager</option>
                <option value="finance">Finance Controller</option>
                <option value="admin">Admin</option>
              </select>
              <select
                value={newUser.department}
                onChange={(e) => setNewUser({ ...newUser, department: e.target.value })}
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                {DEPARTMENTS_LIST.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
              <select
                value={newUser.grade}
                onChange={(e) => setNewUser({ ...newUser, grade: e.target.value as Grade })}
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs bg-white"
              >
                {(['G1', 'G2', 'G3', 'G4', 'G5'] as Grade[]).map((g) => (
                  <option key={g} value={g}>
                    Grade {g}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={newUser.location}
                onChange={(e) => setNewUser({ ...newUser, location: e.target.value })}
                placeholder="Location (Mumbai, Pune...)"
                className="rounded-lg border border-slate-300 px-3 py-2 text-xs"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddUser(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (!newUser.name.trim() || !newUser.email.trim()) {
                      showToast('Full Name and Email are required to create a user.', 'error');
                      return;
                    }
                    await addUser(newUser);
                    setShowAddUser(false);
                    setNewUser({
                      ...newUser,
                      name: '',
                      email: '',
                      employeeCode: `NF-${1022 + users.length}`,
                    });
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium cursor-pointer"
                >
                  Create User
                </button>
              </div>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-3 px-4">Code</th>
                    <th className="py-3 px-4">Name &amp; Email</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Cost Centre</th>
                    <th className="py-3 px-4">Grade</th>
                    <th className="py-3 px-4">Manager</th>
                    <th className="py-3 px-4">Location</th>
                    <th className="py-3 px-4 text-right">Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-10 text-center text-xs text-slate-500">
                        No employees match &ldquo;{userSearch}&rdquo;.{' '}
                        <button
                          type="button"
                          onClick={() => setUserSearch('')}
                          className="text-[#3368A0] font-medium hover:underline cursor-pointer"
                        >
                          Clear search
                        </button>
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => {
                    const isEditing = editingUserId === u.id && userDraft;
                    const mgr = users.find((m) => m.id === u.managerId);
                    return (
                      <tr key={u.id} className="hover:bg-slate-50/60">
                        <td className="py-2.5 px-4 font-mono-num font-medium text-slate-700 whitespace-nowrap">
                          {u.employeeCode}
                        </td>
                        <td className="py-2.5 px-4">
                          <div className="font-semibold text-slate-900">{u.name}</div>
                          <div className="text-[11px] text-slate-500">{u.email}</div>
                        </td>
                        <td className="py-2.5 px-4 whitespace-nowrap">
                          {isEditing ? (
                            <select
                              value={userDraft.role}
                              onChange={(e) =>
                                setUserDraft({ ...userDraft, role: e.target.value as UserRole })
                              }
                              className="rounded border border-slate-300 px-2 py-1 text-xs bg-white"
                            >
                              <option value="employee">employee</option>
                              <option value="manager">manager</option>
                              <option value="finance">finance</option>
                              <option value="admin">admin</option>
                            </select>
                          ) : (
                            <RoleBadge role={u.role} />
                          )}
                        </td>
                        <td className="py-2.5 px-4 whitespace-nowrap">
                          {isEditing ? (
                            <select
                              value={userDraft.department}
                              onChange={(e) =>
                                setUserDraft({ ...userDraft, department: e.target.value })
                              }
                              className="rounded border border-slate-300 px-2 py-1 text-xs bg-white"
                            >
                              {DEPARTMENTS_LIST.map((d) => (
                                <option key={d} value={d}>
                                  {d}
                                </option>
                              ))}
                            </select>
                          ) : (
                            u.department
                          )}
                        </td>
                        <td className="py-2.5 px-4 font-mono-num whitespace-nowrap">
                          {u.costCentre}
                        </td>
                        <td className="py-2.5 px-4 font-mono-num">
                          {isEditing ? (
                            <select
                              value={userDraft.grade}
                              onChange={(e) =>
                                setUserDraft({ ...userDraft, grade: e.target.value as Grade })
                              }
                              className="rounded border border-slate-300 px-2 py-1 text-xs bg-white"
                            >
                              {(['G1', 'G2', 'G3', 'G4', 'G5'] as Grade[]).map((g) => (
                                <option key={g} value={g}>
                                  {g}
                                </option>
                              ))}
                            </select>
                          ) : (
                            u.grade
                          )}
                        </td>
                        <td className="py-2.5 px-4 whitespace-nowrap text-slate-600">
                          {isEditing ? (
                            <select
                              value={userDraft.managerId}
                              onChange={(e) =>
                                setUserDraft({ ...userDraft, managerId: e.target.value })
                              }
                              className="rounded border border-slate-300 px-2 py-1 text-xs bg-white"
                            >
                              <option value="">None</option>
                              {managersList.map((m) => (
                                <option key={m.id} value={m.id}>
                                  {m.name}
                                </option>
                              ))}
                            </select>
                          ) : (
                            mgr?.name || '—'
                          )}
                        </td>
                        <td className="py-2.5 px-4 whitespace-nowrap">{u.location}</td>
                        <td className="py-2.5 px-4 text-right whitespace-nowrap">
                          {isEditing ? (
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={async () => {
                                  await updateUser(userDraft);
                                  setEditingUserId(null);
                                  setUserDraft(null);
                                }}
                                className="p-1.5 rounded bg-emerald-600 text-white cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingUserId(null);
                                  setUserDraft(null);
                                }}
                                className="p-1.5 rounded bg-slate-200 text-slate-700 cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingUserId(u.id);
                                setUserDraft({ ...u });
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" />
                              Edit
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Departments & Cost Centres */}
      {tab === 'org' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900">
              Departments ({departments.length})
            </h3>
            <div className="divide-y divide-slate-100 text-xs">
              {departments.map((d) => (
                <div key={d.id} className="py-3 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-slate-900">
                      {d.name} <span className="font-mono-num text-slate-400">({d.code})</span>
                    </div>
                    <div className="text-slate-500">Head: {d.headName}</div>
                  </div>
                  <div className="font-mono-num font-semibold text-slate-900">
                    {formatINR(d.annualBudgetInr)} / yr
                  </div>
                </div>
              ))}
            </div>
            <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
              <input
                type="text"
                value={newDept.code}
                onChange={(e) => setNewDept({ ...newDept, code: e.target.value.toUpperCase() })}
                placeholder="Code (e.g. RND)"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={newDept.name}
                onChange={(e) => setNewDept({ ...newDept, name: e.target.value })}
                placeholder="Department Name"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={newDept.headName}
                onChange={(e) => setNewDept({ ...newDept, headName: e.target.value })}
                placeholder="Department Head"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
              />
              <button
                type="button"
                onClick={async () => {
                  if (!newDept.code.trim() || !newDept.name.trim()) {
                    showToast('Department Code and Name are required.', 'error');
                    return;
                  }
                  await addDepartment({
                    ...newDept,
                    code: newDept.code.trim(),
                    name: newDept.name.trim(),
                    headName: newDept.headName.trim() || 'TBD',
                  });
                  setNewDept({ code: '', name: '', headName: '', annualBudgetInr: 1500000 });
                }}
                className="rounded-lg bg-[#3368A0] text-white text-xs font-medium py-1.5 cursor-pointer"
              >
                Add Department
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900">
              Cost Centres ({costCentres.length})
            </h3>
            <div className="divide-y divide-slate-100 text-xs">
              {costCentres.map((cc) => (
                <div key={cc.id} className="py-3 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-slate-900">{cc.name}</div>
                    <div className="text-slate-500">
                      {cc.department} · {cc.location}
                    </div>
                  </div>
                  <span className="font-mono-num px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                    {cc.code}
                  </span>
                </div>
              ))}
            </div>
            <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
              <input
                type="text"
                value={newCC.code}
                onChange={(e) => setNewCC({ ...newCC, code: e.target.value.toUpperCase() })}
                placeholder="Code (CC-PUN-501)"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs font-mono-num"
              />
              <input
                type="text"
                value={newCC.name}
                onChange={(e) => setNewCC({ ...newCC, name: e.target.value })}
                placeholder="Cost Centre Name"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={newCC.location}
                onChange={(e) => setNewCC({ ...newCC, location: e.target.value })}
                placeholder="City"
                className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs"
              />
              <button
                type="button"
                onClick={async () => {
                  if (!newCC.code.trim() || !newCC.name.trim()) {
                    showToast('Cost Centre Code and Name are required.', 'error');
                    return;
                  }
                  await addCostCentre({
                    ...newCC,
                    code: newCC.code.trim(),
                    name: newCC.name.trim(),
                    location: newCC.location.trim() || 'Mumbai',
                  });
                  setNewCC({ code: '', name: '', department: 'Sales', location: 'Mumbai' });
                }}
                className="rounded-lg bg-[#3368A0] text-white text-xs font-medium py-1.5 cursor-pointer"
              >
                Add Cost Centre
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Audit Trail */}
      {tab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">
              System Audit Trail ({auditTrail.length} events)
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Entity</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditTrail.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                      No audit events recorded yet. Actions on claims, users, and policies appear here automatically.
                    </td>
                  </tr>
                ) : (
                  auditTrail.slice(0, 50).map((a) => (
                    <tr key={a.id} className="hover:bg-slate-50/60">
                      <td className="py-2.5 px-4 font-mono-num text-slate-500 whitespace-nowrap">
                        {formatDateTimeDDMMMYYYY(a.timestamp)}
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                        {a.claimNo || a.entityType}
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-slate-900 whitespace-nowrap">
                        {a.action}
                      </td>
                      <td className="py-2.5 px-4 whitespace-nowrap">
                        {a.actorName} <span className="text-slate-400">({a.actorRole})</span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">{a.details}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={confirmResetOpen}
        title="Reset Demo Data?"
        message="This will restore all 60 claims, 20 employees, 60 policy rules, departments, cost centres, and notifications back to the initial Nova Foods India demo state. Any unsaved or newly created demo edits will be cleared."
        confirmLabel="Yes, Reset Demo Data"
        variant="danger"
        onCancel={() => setConfirmResetOpen(false)}
        onConfirm={async () => {
          await resetDemoWorkspace();
          setConfirmResetOpen(false);
        }}
      />
    </div>
  );
};
