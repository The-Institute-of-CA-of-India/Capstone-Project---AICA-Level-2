import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  BadgeCheck,
  CheckCircle2,
  Landmark,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getFinanceInsightsPlaceholder } from '../services/aiPlaceholders';
import { EXPENSE_CATEGORIES, ExpenseClaim } from '../types/claimwise';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';
import { analyzeClaimRisk } from '../utils/riskEngine';
import { ActionCommentModal } from './ActionCommentModal';
import { PolicyExceptionTag, RiskLevelBadge, StatusBadge } from './StatusBadge';

export const FinanceQueueView: React.FC = () => {
  const {
    currentUser,
    claims,
    policies,
    departments,
    navigate,
    financeVerifyClaim,
    financeSendBackClaim,
    financeMarkAsPaid,
  } = useApp();

  const [tab, setTab] = useState<'verify' | 'payout' | 'analytics'>('verify');
  const [onlyFlagged, setOnlyFlagged] = useState(false);
  const [selectedPayIds, setSelectedPayIds] = useState<string[]>([]);
  const [sendBackTarget, setSendBackTarget] = useState<ExpenseClaim | null>(null);
  const [bulkPayModalOpen, setBulkPayModalOpen] = useState(false);

  const riskByClaimId = useMemo(() => {
    const map = new Map<string, ReturnType<typeof analyzeClaimRisk>>();
    for (const c of claims) {
      if (c.status === 'Manager Approved' || c.status === 'Finance Verified') {
        map.set(c.id, analyzeClaimRisk(c, claims, policies));
      }
    }
    return map;
  }, [claims, policies]);

  const pendingVerification = useMemo(() => {
    const base = claims.filter((c) => c.status === 'Manager Approved');
    if (onlyFlagged) {
      return base.filter((c) => {
        const r = riskByClaimId.get(c.id);
        return (
          c.hasPolicyViolation ||
          c.isDuplicateFlagged ||
          (r && (r.riskLevel !== 'Low' || r.duplicates.length > 0 || r.anomalies.length > 0))
        );
      });
    }
    return base;
  }, [claims, onlyFlagged, riskByClaimId]);

  const readyForPayout = useMemo(
    () => claims.filter((c) => c.status === 'Finance Verified'),
    [claims]
  );

  const analytics = useMemo(() => {
    const valid = claims.filter((c) => c.status !== 'Draft' && c.status !== 'Rejected');
    const totalSpend = valid.reduce((s, c) => s + c.totalAmount, 0);
    const totalGst = valid.reduce((s, c) => s + c.totalGstAmount, 0);
    const paidTotal = claims
      .filter((c) => c.status === 'Paid')
      .reduce((s, c) => s + c.totalAmount, 0);
    const duplicateClaims = claims.filter((c) => c.isDuplicateFlagged);
    const violationClaims = claims.filter((c) => c.hasPolicyViolation);

    const byCategory = EXPENSE_CATEGORIES.map((cat) => {
      const amount = valid.reduce(
        (s, c) =>
          s +
          c.lines
            .filter((l) => l.category === cat)
            .reduce((ls, l) => ls + l.amount, 0),
        0
      );
      return { category: cat, amount };
    }).sort((a, b) => b.amount - a.amount);

    const maxCat = Math.max(1, ...byCategory.map((x) => x.amount));

    const byDept = departments.map((d) => {
      const spend = valid
        .filter((c) => c.department === d.name)
        .reduce((s, c) => s + c.totalAmount, 0);
      return {
        name: d.name,
        code: d.code,
        budget: d.annualBudgetInr,
        spend,
        pct: Math.round((spend / Math.max(1, d.annualBudgetInr)) * 100),
      };
    });

    return {
      totalSpend,
      totalGst,
      paidTotal,
      duplicateClaims,
      violationClaims,
      byCategory,
      maxCat,
      byDept,
    };
  }, [claims, departments]);

  const aiInsights = useMemo(() => getFinanceInsightsPlaceholder(claims), [claims]);

  if (!currentUser) return null;

  const payoutSelectedTotal = readyForPayout
    .filter((c) => selectedPayIds.includes(c.id))
    .reduce((s, c) => s + c.totalAmount, 0);

  return (
    <div className="space-y-5">
      {/* Header & Tabs */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-[#3368A0]" />
            <h2 className="text-lg font-semibold text-slate-900">
              Finance Verification &amp; Payout Queue
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Audit GST invoices, resolve policy exceptions &amp; duplicate flags, and settle verified claims via NEFT.
          </p>
        </div>

        <div className="flex items-center bg-slate-100 p-1 rounded-lg self-start lg:self-auto overflow-x-auto">
          <button
            type="button"
            onClick={() => setTab('verify')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer whitespace-nowrap ${
              tab === 'verify' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Pending Verification ({pendingVerification.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('payout')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer whitespace-nowrap ${
              tab === 'payout' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Ready for Payout ({readyForPayout.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('analytics')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer whitespace-nowrap ${
              tab === 'analytics' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Analytics &amp; Exceptions
          </button>
        </div>
      </div>

      {/* Tab 1: Pending Verification */}
      {tab === 'verify' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>
                <strong>{analytics.duplicateClaims.length}</strong> duplicate-flagged claim(s) and{' '}
                <strong>{analytics.violationClaims.length}</strong> policy exception claim(s) in system.
              </span>
            </div>
            <button
              type="button"
              onClick={() => setOnlyFlagged((v) => !v)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
                onlyFlagged
                  ? 'bg-rose-50 border-rose-300 text-rose-800'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {onlyFlagged ? 'Showing Flagged / High-Medium Risk' : 'Filter Flagged / Risk'}
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {pendingVerification.length === 0 ? (
              <div className="p-12 text-center">
                <p className="text-sm font-semibold text-slate-900">Verification queue is clear</p>
                <p className="text-xs text-slate-500 mt-1">
                  No manager-approved claims currently await Finance verification.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-4">Claim No.</th>
                      <th className="py-3 px-4">Employee &amp; Dept</th>
                      <th className="py-3 px-4">City &amp; Dates</th>
                      <th className="py-3 px-4 text-right">Amount / GST</th>
                      <th className="py-3 px-4">Compliance Flags</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {pendingVerification.map((c) => {
                      const risk = riskByClaimId.get(c.id);
                      const hasDup = c.isDuplicateFlagged || Boolean(risk && risk.duplicates.length > 0);
                      const dupRef =
                        c.duplicateRefClaimNo || risk?.duplicates[0]?.matchedClaimNo || '';
                      return (
                        <tr
                          key={c.id}
                          onClick={() => navigate('claim-detail', { claimId: c.id })}
                          className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                        >
                          <td className="py-3 px-4 font-mono-num font-medium text-[#3368A0] whitespace-nowrap">
                            {c.claimNo}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <div className="font-medium text-slate-900">{c.employeeName}</div>
                            <div className="text-xs text-slate-500">
                              {c.department} · {c.costCentre} · {c.grade}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600 whitespace-nowrap">
                            <div className="font-medium text-slate-800">
                              {c.destination} ({c.cityTier})
                            </div>
                            <div className="font-mono-num">
                              {formatDateDDMMMYYYY(c.tripFromDate)}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono-num whitespace-nowrap">
                            <div className="font-semibold text-slate-900">
                              {formatINR(c.totalAmount)}
                            </div>
                            <div className="text-xs text-slate-500">
                              GST {formatINR(c.totalGstAmount)}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex flex-wrap items-center gap-1.5">
                              {risk && <RiskLevelBadge level={risk.riskLevel} compact />}
                              {hasDup && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 border border-rose-300 text-[11px] font-semibold text-rose-800 whitespace-nowrap">
                                  <AlertTriangle className="w-3 h-3" />
                                  Duplicate ({dupRef})
                                </span>
                              )}
                              {risk && risk.anomalies.length > 0 && (
                                <span
                                  title={risk.anomalies.map((a) => a.reason).join(' | ')}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 border border-amber-300 text-[11px] font-semibold text-amber-800 whitespace-nowrap"
                                >
                                  {risk.anomalies.length} Anomal{risk.anomalies.length === 1 ? 'y' : 'ies'}
                                </span>
                              )}
                              {c.hasPolicyViolation && (
                                <PolicyExceptionTag
                                  compact
                                  title={c.lines
                                    .filter((l) => l.policyFlag === 'Violation')
                                    .map((l) => l.policyFlagReason)
                                    .filter(Boolean)
                                    .join(' | ')}
                                />
                              )}
                              {!hasDup && !c.hasPolicyViolation && (!risk || risk.anomalies.length === 0) && (
                                <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 whitespace-nowrap">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Compliant
                                </span>
                              )}
                            </div>
                          </td>
                          <td
                            className="py-3 px-4 text-right whitespace-nowrap"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => navigate('claim-detail', { claimId: c.id })}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-[#3368A0]/30 bg-[#3368A0]/5 text-xs font-medium text-[#3368A0] hover:bg-[#3368A0]/10 cursor-pointer"
                              >
                                <Sparkles className="w-3.5 h-3.5" />
                                AI Audit
                              </button>
                              <button
                                type="button"
                                onClick={() => financeVerifyClaim(c.id)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 cursor-pointer"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Verify
                              </button>
                              <button
                                type="button"
                                onClick={() => setSendBackTarget(c)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-amber-300 bg-amber-50 text-amber-800 text-xs font-medium hover:bg-amber-100 cursor-pointer"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                Send Back
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Ready for Payout */}
      {tab === 'payout' && (
        <div className="space-y-4">
          {selectedPayIds.length > 0 && (
            <div className="rounded-xl border border-teal-300 bg-teal-50 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs font-medium text-teal-900">
                Selected <strong className="font-mono-num">{selectedPayIds.length}</strong> verified claim(s) for NEFT payout:{' '}
                <strong className="font-mono-num">{formatINR(payoutSelectedTotal)}</strong>
              </span>
              <button
                type="button"
                onClick={() => setBulkPayModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-teal-700 text-white text-xs font-medium hover:bg-teal-800 cursor-pointer"
              >
                <BadgeCheck className="w-3.5 h-3.5" />
                Process NEFT Batch ({selectedPayIds.length})
              </button>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {readyForPayout.length === 0 ? (
              <div className="p-12 text-center">
                <p className="text-sm font-semibold text-slate-900">No pending payouts</p>
                <p className="text-xs text-slate-500 mt-1">
                  Verify claims in the Verification tab to queue them for reimbursement.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-4 w-10">
                        <input
                          type="checkbox"
                          checked={
                            readyForPayout.length > 0 &&
                            selectedPayIds.length === readyForPayout.length
                          }
                          onChange={() =>
                            setSelectedPayIds(
                              selectedPayIds.length === readyForPayout.length
                                ? []
                                : readyForPayout.map((c) => c.id)
                            )
                          }
                          className="rounded border-slate-300 accent-teal-700 cursor-pointer"
                        />
                      </th>
                      <th className="py-3 px-4">Claim No.</th>
                      <th className="py-3 px-4">Employee</th>
                      <th className="py-3 px-4">Cost Centre</th>
                      <th className="py-3 px-4 text-right">Net Payable (₹)</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {readyForPayout.map((c) => (
                      <tr
                        key={c.id}
                        onClick={() => navigate('claim-detail', { claimId: c.id })}
                        className="hover:bg-slate-50/80 cursor-pointer"
                      >
                        <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={selectedPayIds.includes(c.id)}
                            onChange={() =>
                              setSelectedPayIds((prev) =>
                                prev.includes(c.id)
                                  ? prev.filter((x) => x !== c.id)
                                  : [...prev, c.id]
                              )
                            }
                            className="rounded border-slate-300 accent-teal-700 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-4 font-mono-num font-medium text-[#3368A0] whitespace-nowrap">
                          {c.claimNo}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-medium text-slate-900">{c.employeeName}</div>
                          <div className="text-xs text-slate-500">{c.employeeCode}</div>
                        </td>
                        <td className="py-3 px-4 font-mono-num text-xs text-slate-700 whitespace-nowrap">
                          {c.costCentre}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900 whitespace-nowrap">
                          {formatINR(c.totalAmount)}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <StatusBadge status={c.status} />
                            {c.hasPolicyViolation && <PolicyExceptionTag compact />}
                          </div>
                        </td>
                        <td
                          className="py-3 px-4 text-right whitespace-nowrap"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() => financeMarkAsPaid([c.id])}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-teal-700 text-white text-xs font-medium hover:bg-teal-800 cursor-pointer"
                          >
                            <BadgeCheck className="w-3.5 h-3.5" />
                            Mark Paid
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Analytics & Exceptions */}
      {tab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-xs font-medium text-slate-500">Total Active Claim Spend</div>
              <div className="mt-2 text-2xl font-bold text-slate-900 font-mono-num">
                {formatINR(analytics.totalSpend)}
              </div>
              <p className="text-xs text-slate-500 mt-1">Across last 6 months</p>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-xs font-medium text-slate-500">Eligible GST Input Credit</div>
              <div className="mt-2 text-2xl font-bold text-slate-900 font-mono-num">
                {formatINR(analytics.totalGst)}
              </div>
              <p className="text-xs text-slate-500 mt-1">Tax invoices with GSTIN</p>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-xs font-medium text-slate-500">Settled &amp; Paid Out</div>
              <div className="mt-2 text-2xl font-bold text-teal-700 font-mono-num">
                {formatINR(analytics.paidTotal)}
              </div>
              <p className="text-xs text-slate-500 mt-1">Reimbursed via NEFT</p>
            </div>
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-xs font-medium text-slate-500">Flagged Exceptions</div>
              <div className="mt-2 text-2xl font-bold text-rose-700 font-mono-num">
                {analytics.violationClaims.length} / {analytics.duplicateClaims.length} dup
              </div>
              <p className="text-xs text-slate-500 mt-1">Policy breaches &amp; duplicates</p>
            </div>
          </div>

          {/* Finance Analytics Shortcut */}
          <div className="bg-white rounded-2xl border border-[#66A3BF]/50 p-6">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#3368A0]" />
                <h3 className="text-sm font-semibold text-slate-900">
                  Executive Spend &amp; Compliance Analytics Ready
                </h3>
              </div>
              <button
                type="button"
                onClick={() => navigate('finance-analytics')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Open Full Finance Analytics
              </button>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-600 list-disc pl-5">
              {aiInsights.bulletFindings.map((b, i) => (
                <li key={i}>{b}</li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <h3 className="text-sm font-semibold text-slate-900 mb-4">
                Spend by Expense Category (INR)
              </h3>
              <div className="space-y-3">
                {analytics.byCategory.map((item) => (
                  <div key={item.category}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-700 font-medium">{item.category}</span>
                      <span className="font-mono-num font-semibold text-slate-900">
                        {formatINR(item.amount)}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#3368A0]"
                        style={{ width: `${Math.max(4, Math.round((item.amount / analytics.maxCat) * 100))}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 mb-3">
                  Department Budget Utilization
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500">
                        <th className="py-2">Department</th>
                        <th className="py-2 text-right">6M Spend</th>
                        <th className="py-2 text-right">Annual Budget</th>
                        <th className="py-2 text-right">Util.</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {analytics.byDept.map((d) => (
                        <tr key={d.code}>
                          <td className="py-2.5 font-medium text-slate-900">{d.name}</td>
                          <td className="py-2.5 text-right font-mono-num">{formatINR(d.spend)}</td>
                          <td className="py-2.5 text-right font-mono-num text-slate-500">
                            {formatINR(d.budget)}
                          </td>
                          <td className="py-2.5 text-right font-mono-num font-medium text-[#3368A0]">
                            {d.pct}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <h4 className="text-xs font-semibold text-rose-700 mb-2">
                  Detected Duplicate Claims ({analytics.duplicateClaims.length})
                </h4>
                {analytics.duplicateClaims.length === 0 ? (
                  <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 text-xs text-emerald-800">
                    No duplicate invoice collisions detected across active claims.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {analytics.duplicateClaims.map((dc) => (
                      <button
                        key={dc.id}
                        type="button"
                        onClick={() => navigate('claim-detail', { claimId: dc.id })}
                        className="w-full text-left p-3 rounded-xl border border-rose-200 bg-rose-50/70 hover:bg-rose-50 flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <div className="text-xs">
                          <span className="font-mono-num font-semibold text-rose-800">
                            {dc.claimNo}
                          </span>{' '}
                          <span className="text-slate-700">by {dc.employeeName}</span>
                          <div className="text-[11px] text-rose-700 mt-0.5">
                            Matches {dc.duplicateRefClaimNo}
                          </div>
                        </div>
                        <span className="font-mono-num text-xs font-semibold text-slate-900">
                          {formatINR(dc.totalAmount)}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <ActionCommentModal
        open={Boolean(sendBackTarget)}
        title={`Send Back ${sendBackTarget?.claimNo || ''}`}
        subtitle="Explain the missing invoice/GSTIN or policy correction needed. Comment is mandatory."
        confirmLabel="Send Back to Employee"
        confirmVariant="amber"
        requireComment={true}
        placeholder="e.g., Please upload itemized hotel GST invoice with Nova Foods GSTIN."
        onCancel={() => setSendBackTarget(null)}
        onConfirm={async (comment) => {
          if (sendBackTarget) {
            await financeSendBackClaim(sendBackTarget.id, comment);
          }
          setSendBackTarget(null);
        }}
      />

      <ActionCommentModal
        open={bulkPayModalOpen}
        title={`Process NEFT Payout (${selectedPayIds.length} Claims)`}
        subtitle={`Total settlement amount: ${formatINR(payoutSelectedTotal)}`}
        confirmLabel="Confirm Payout & Mark Paid"
        confirmVariant="teal"
        requireComment={false}
        defaultComment={`HDFC Corporate NEFT Batch #NF-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`}
        onCancel={() => setBulkPayModalOpen(false)}
        onConfirm={async (ref) => {
          await financeMarkAsPaid(selectedPayIds, ref);
          setSelectedPayIds([]);
          setBulkPayModalOpen(false);
        }}
      />
    </div>
  );
};
