import React, { useState } from 'react';
import { Download, ExternalLink, Laptop, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'primary' | 'subtle' }> = ({
  variant = 'subtle',
}) => {
  const { isInstallable, isInstalled, isIOS, isEmbeddedIframe, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  // Suppress when already running as an installed standalone desktop/mobile app
  if (isInstalled) {
    return null;
  }

  // Native Chromium Desktop / Android install flow when beforeinstallprompt is available
  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] transition-colors shadow-xs cursor-pointer whitespace-nowrap"
      >
        <Download className="w-3.5 h-3.5" />
        <span>Install Desktop App</span>
      </button>
    );
  }

  const standaloneUrl = typeof window !== 'undefined' ? window.location.href : '/';

  return (
    <>
      <button
        type="button"
        onClick={() => setShowGuide(true)}
        className={
          variant === 'primary'
            ? 'inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] transition-colors shadow-xs cursor-pointer whitespace-nowrap'
            : 'inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap'
        }
      >
        <Laptop className="w-3.5 h-3.5 text-[#3368A0]" />
        <span>{isIOS ? 'Add to Home Screen' : 'Add to Desktop'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-[1px] p-4"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-white border border-slate-200 shadow-xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="pwa-install-guide-title"
          >
            <div className="px-6 py-4 border-b border-slate-100 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#3368A0]/10 text-[#3368A0] flex items-center justify-center shrink-0">
                  <Laptop className="w-4 h-4" />
                </div>
                <div>
                  <h3 id="pwa-install-guide-title" className="text-sm font-semibold text-slate-900">
                    Install ClaimWise AI on Your Device
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Launch in its own standalone desktop window with offline asset caching.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100 cursor-pointer"
                aria-label="Close install guide"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-700">
              {isEmbeddedIframe && (
                <div className="rounded-xl border border-[#66A3BF]/50 bg-[#C8DFDB]/25 p-3.5 space-y-2.5">
                  <p className="font-semibold text-slate-900">
                    Step 1: Open in a standalone browser tab
                  </p>
                  <p className="text-slate-600 leading-relaxed">
                    Browsers block one-click app installation inside embedded preview frames. Open ClaimWise AI in its own tab first, then click <strong>Install Desktop App</strong> or the browser address-bar install icon.
                  </p>
                  <a
                    href={standaloneUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Open Standalone Tab
                  </a>
                </div>
              )}

              {isIOS ? (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-2">
                  <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                    <Share className="w-3.5 h-3.5 text-[#3368A0]" />
                    <span>iPhone / iPad (Safari)</span>
                  </div>
                  <ol className="list-decimal pl-4 space-y-1 text-slate-600">
                    <li>
                      Tap the <strong>Share</strong> button in Safari&apos;s toolbar.
                    </li>
                    <li>
                      Scroll down and tap <strong>Add to Home Screen</strong>.
                    </li>
                  </ol>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-1.5">
                    <div className="font-semibold text-slate-900">
                      Windows / macOS / Linux (Chrome or Edge)
                    </div>
                    <ol className="list-decimal pl-4 space-y-1 text-slate-600">
                      <li>
                        Open ClaimWise AI in a standalone tab (not an embedded frame).
                      </li>
                      <li>
                        Click the <strong>Install app</strong> icon in the right side of the address bar, or open menu{' '}
                        <strong>⋮ → Cast, save, and share → Install page as app…</strong> (Chrome) /{' '}
                        <strong>Apps → Install this site as an app</strong> (Edge).
                      </li>
                      <li>
                        Confirm <strong>Install</strong> to create a Desktop shortcut / Start Menu / Dock app.
                      </li>
                    </ol>
                  </div>

                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-1">
                    <div className="font-semibold text-slate-900">macOS Safari</div>
                    <p className="text-slate-600">
                      Open in Safari and choose <strong>File → Add to Dock…</strong> from the macOS menu bar.
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
