import React, { useState } from 'react';
import {
  ArrowRight,
  Landmark,
  ShieldCheck,
  Sparkles,
  UserCheck,
  Users,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types/claimwise';
import { formatDateDDMMMYYYY } from '../utils/formatters';
import { PWAInstallButton } from './PWAInstallButton';

interface DemoCardSpec {
  role: UserRole;
  roleLabel: string;
  person: string;
  initials: string;
  meta: string;
  scope: string;
  avatar: string;
  icon: React.ReactNode;
}

const DEMO_CARDS: DemoCardSpec[] = [
  {
    role: 'employee',
    roleLabel: 'Employee',
    person: 'Aarav Deshmukh',
    initials: 'AD',
    meta: 'NF-1004 · Sales · Grade G2 · Pune',
    scope: 'Upload receipts for AI extraction, check policy limits, and submit expense claims.',
    avatar: '/src/assets/images/avatar_employee_aarav_1795531789233.jpg',
    icon: <UserCheck className="w-4 h-4" />,
  },
  {
    role: 'manager',
    roleLabel: 'Manager',
    person: 'Priya Nair',
    initials: 'PN',
    meta: 'NF-1002 · Regional Sales Manager · Grade G4 · Mumbai',
    scope: 'Review direct reportee claims, inspect risk indicators, and bulk approve or reject.',
    avatar: '/src/assets/images/avatar_manager_priya_1795531789238.jpg',
    icon: <Users className="w-4 h-4" />,
  },
  {
    role: 'finance',
    roleLabel: 'Finance Controller',
    person: 'Vikramaditya Rao',
    initials: 'VR',
    meta: 'NF-1001 · Finance Controller · Grade G5 · Mumbai',
    scope: 'Verify GST & policy exceptions, run AI claim reviews, inspect analytics, and mark Paid.',
    avatar: '/src/assets/images/avatar_finance_vikram_1795531789425.jpg',
    icon: <Landmark className="w-4 h-4" />,
  },
  {
    role: 'admin',
    roleLabel: 'HR & Systems Admin',
    person: 'Sneha Kulkarni',
    initials: 'SK',
    meta: 'NF-1003 · HR & Systems Admin · Grade G4 · Pune',
    scope: 'Manage employees, departments, cost centres, editable policy rules, and demo resets.',
    avatar: '/src/assets/images/avatar_admin_sneha_1795531789983.jpg',
    icon: <ShieldCheck className="w-4 h-4" />,
  },
];

export const LoginScreen: React.FC = () => {
  const { loginAsDemoRole, claims, policies, users, departments } = useApp();
  const [brokenAvatars, setBrokenAvatars] = useState<Record<string, boolean>>({});

  const now = new Date();
  const todayLocalIso = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;
  const todayFormatted = formatDateDDMMMYYYY(todayLocalIso);

  const managerPendingCount = claims.filter(
    (c) => c.status === 'Submitted' && c.managerId === 'u-mgr-1'
  ).length;
  const financeQueueCount = claims.filter(
    (c) => c.status === 'Manager Approved' || c.status === 'Finance Verified'
  ).length;
  const employeeDraftOrOpenCount = claims.filter(
    (c) => c.employeeId === 'u-emp-1'
  ).length;

  const getRoleFooterHint = (role: UserRole): string => {
    switch (role) {
      case 'employee':
        return `${employeeDraftOrOpenCount} claims in workspace`;
      case 'manager':
        return `${managerPendingCount} pending approval`;
      case 'finance':
        return `${financeQueueCount} awaiting payout`;
      case 'admin':
        return `${policies.length} rules · ${users.length} users`;
    }
  };

  return (
    <div className="min-h-screen bg-[#F2EFE7] text-slate-900 flex flex-col justify-between px-6 py-6 lg:px-10 lg:py-8">
      {/* Top Bar */}
      <header className="max-w-6xl w-full mx-auto flex items-center justify-between gap-8">
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-[#3368A0] text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            ClaimWise AI
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <PWAInstallButton />
        </div>
      </header>

      {/* Main Split Workspace Entry */}
      <main className="max-w-6xl w-full mx-auto my-8 lg:my-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
        {/* Left Editorial Column directly on warm canvas */}
        <section className="lg:col-span-5 space-y-6">
          <div className="space-y-4">
            <p className="text-xs font-semibold text-[#3368A0] tracking-wide">
              Nova Foods India Pvt Ltd · Enterprise Expense Platform
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight leading-[1.12] text-balance">
              From Receipt to Reimbursement, Powered by AI.
            </h1>
            <p className="text-sm sm:text-[15px] text-slate-600 leading-relaxed max-w-prose">
              Intelligent GST receipt extraction, deterministic policy checks, duplicate &amp;
              anomaly detection, and multi-stage approvals across {departments.length} corporate
              departments.
            </p>
          </div>

          {/* Grounded Workspace Figures */}
          <div className="grid grid-cols-3 gap-4 py-4 border-y border-slate-300/70">
            <div>
              <div className="text-2xl font-bold text-slate-900 font-mono-num">
                {claims.length}
              </div>
              <div className="text-xs text-slate-600 mt-0.5">Loaded Claims</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900 font-mono-num">
                {policies.length}
              </div>
              <div className="text-xs text-slate-600 mt-0.5">Policy Rules</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900 font-mono-num">
                {users.length}
              </div>
              <div className="text-xs text-slate-600 mt-0.5">Employees</div>
            </div>
          </div>

          {/* Plain typographic context */}
          <div className="space-y-2 text-xs text-slate-600">
            <p>
              <span className="font-semibold text-slate-800">Approval Flow:</span> Draft →
              Submitted → Manager → Finance → Paid
            </p>
            <p>
              <span className="font-semibold text-slate-800">Locations:</span> Mumbai · Pune ·
              Baramati · Delhi · Bengaluru · Chennai
            </p>
          </div>
        </section>

        {/* Right Role Selector Grid (Single-Elevation Cards, No Nested Boxes) */}
        <section className="lg:col-span-7">
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-slate-900">Select a Workspace Role</h2>
            <p className="text-xs text-slate-600 mt-0.5">
              One-click persona access to explore ClaimWise AI end-to-end.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DEMO_CARDS.map((card) => (
              <button
                key={card.role}
                type="button"
                onClick={() => loginAsDemoRole(card.role)}
                className="group text-left bg-white rounded-xl border border-slate-200 p-5 hover:border-[#3368A0] hover:bg-[#C8DFDB]/15 hover:shadow-sm transition-all duration-150 cursor-pointer flex flex-col justify-between gap-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3368A0]"
              >
                <div className="flex items-start gap-3.5">
                  {brokenAvatars[card.role] ? (
                    <div className="w-11 h-11 rounded-full bg-[#3368A0] text-white text-xs font-semibold flex items-center justify-center shrink-0">
                      {card.initials}
                    </div>
                  ) : (
                    <img
                      src={card.avatar}
                      alt={card.person}
                      referrerPolicy="no-referrer"
                      onError={() =>
                        setBrokenAvatars((prev) => ({ ...prev, [card.role]: true }))
                      }
                      className="w-11 h-11 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                  )}
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-slate-900 group-hover:text-[#3368A0] transition-colors">
                      {card.icon}
                      <span className="truncate">{card.roleLabel}</span>
                    </div>
                    <p className="text-xs font-medium text-slate-800 mt-0.5 truncate">
                      {card.person}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5 truncate">{card.meta}</p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">{card.scope}</p>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                  <span className="text-[11px] font-medium text-slate-500 font-mono-num">
                    {getRoleFooterHint(card.role)}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#3368A0] whitespace-nowrap shrink-0">
                    <span>Launch</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </section>
      </main>

      {/* Capstone Attribution Footer */}
      <footer className="max-w-6xl w-full mx-auto pt-5 border-t border-slate-300/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-600">
        <span className="font-medium text-slate-800">
          ClaimWise AI – AICA Level 2 Capstone Project | Developed by CA Akshay Burde (#168212)
        </span>
        <span className="font-mono-num whitespace-nowrap">
          Nova Foods India Pvt Ltd · {todayFormatted} · INR (₹)
        </span>
      </footer>
    </div>
  );
};
