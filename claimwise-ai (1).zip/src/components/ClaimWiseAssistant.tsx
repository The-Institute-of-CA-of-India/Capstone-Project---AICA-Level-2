import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen,
  Database,
  Loader2,
  MessageSquareText,
  Send,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { askClaimWiseAssistant } from '../services/aiPlaceholders';
import { AssistantMessage } from '../types/claimwise';
import { buildAssistantGroundedPayload } from '../utils/assistantContext';

const STARTER_PROMPTS_BY_ROLE: Record<string, string[]> = {
  employee: [
    'What is my hotel limit in Mumbai?',
    'Do I need pre-approval for Client Entertainment?',
    'What is my meal allowance in Pune vs Delhi?',
  ],
  manager: [
    'What is the hotel limit for Grade G2 in Mumbai?',
    'How many team claims are pending my approval?',
    'Which categories require mandatory pre-approval?',
  ],
  finance: [
    'Top 3 reasons for policy violations this month',
    'Summarise travel spend by department',
    'Which claims are flagged as duplicates or high risk?',
    'What is the hotel limit for Grade G3 in Mumbai?',
  ],
  admin: [
    'Top 3 reasons for policy violations this month',
    'Summarise travel spend by department',
    'What is the hotel limit for Grade G3 in Mumbai?',
  ],
};

export const ClaimWiseAssistant: React.FC = () => {
  const { currentUser, claims, policies, departments, costCentres } = useApp();

  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<AssistantMessage[]>([]);

  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages, open, loading]);

  // Reset greeting cleanly when user/role changes
  useEffect(() => {
    if (!currentUser) {
      setMessages([]);
      return;
    }
    const isFinanceOrAdmin = currentUser.role === 'finance' || currentUser.role === 'admin';
    setMessages([
      {
        id: `welcome-${currentUser.id}`,
        role: 'assistant',
        content: isFinanceOrAdmin
          ? `Hello ${currentUser.name.split(' ')[0]}. Ask me about Nova Foods policy limits or live finance analytics (spend by department, top policy violations, duplicate exposure, or pending ageing).`
          : `Hello ${currentUser.name.split(' ')[0]} (Grade ${currentUser.grade}). Ask me about your travel & expense limits, receipt requirements, pre-approvals, or your own claims.`,
        sources: [
          {
            type: isFinanceOrAdmin ? 'Dataset' : 'Policy Rule',
            label: isFinanceOrAdmin
              ? `Finance Ledger & ${policies.length} Policy Rules`
              : `Nova Foods Grade ${currentUser.grade} Policy Table`,
            detail: isFinanceOrAdmin
              ? `${claims.length} claims and ${departments.length} departments loaded`
              : `City-tier limits & guidelines grounded for ${currentUser.department}`,
          },
        ],
        timestamp: new Date().toISOString(),
      },
    ]);
  }, [currentUser?.id, currentUser?.role, currentUser?.grade, claims.length, policies.length, departments.length]);

  const groundedContext = useMemo(() => {
    if (!currentUser) return null;
    return buildAssistantGroundedPayload({
      currentUser,
      claims,
      policies,
      departments,
      costCentres,
      referenceDate: '2026-11-24',
    });
  }, [currentUser, claims, policies, departments, costCentres]);

  if (!currentUser || !groundedContext) return null;

  const starterPrompts =
    STARTER_PROMPTS_BY_ROLE[currentUser.role] || STARTER_PROMPTS_BY_ROLE.employee;

  const sendQuestion = async (rawQuestion: string) => {
    const q = rawQuestion.trim();
    if (!q || loading) return;

    const userMsg: AssistantMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: q,
      timestamp: new Date().toISOString(),
    };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setLoading(true);

    try {
      const res = await askClaimWiseAssistant({
        question: q,
        history: nextHistory
          .filter((m) => !m.error)
          .slice(-6)
          .map((m) => ({ role: m.role, content: m.content })),
        groundedContext,
      });

      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: 'assistant',
          content: res.answer,
          sources: res.sources,
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: '',
          error:
            err instanceof Error
              ? err.message
              : 'Unable to reach ClaimWise Assistant right now.',
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open ClaimWise Assistant"
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-[#3368A0] text-white shadow-lg hover:bg-[#295584] transition-all cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#C8DFDB]" />
          <span className="text-xs font-semibold">ClaimWise Assistant</span>
          <MessageSquareText className="w-4 h-4 opacity-90" />
        </button>
      )}

      {/* Floating Chat Panel */}
      {open && (
        <div className="fixed bottom-5 right-5 z-50 w-[390px] sm:w-[430px] max-w-[calc(100vw-2rem)] h-[560px] max-h-[82vh] bg-white rounded-2xl border border-slate-200 shadow-2xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="px-4 py-3.5 bg-[#3368A0] text-white flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-[#C8DFDB]" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-semibold truncate">ClaimWise Assistant</div>
                <div className="text-[11px] text-white/80 truncate">
                  {currentUser.role === 'finance' || currentUser.role === 'admin'
                    ? 'Finance Data & Policy Copilot · Source-Grounded'
                    : `Policy & Claims Copilot · Grade ${currentUser.grade}`}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close ClaimWise Assistant"
              className="p-1.5 rounded-lg text-white/80 hover:bg-white/15 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Starter Prompts */}
          <div className="px-3.5 py-2.5 border-b border-slate-100 bg-[#F2EFE7]/60 flex items-center gap-1.5 overflow-x-auto shrink-0">
            {starterPrompts.map((prompt) => (
              <button
                key={prompt}
                type="button"
                disabled={loading}
                onClick={() => sendQuestion(prompt)}
                className="px-2.5 py-1 rounded-md border border-[#66A3BF]/50 bg-white text-[11px] font-medium text-[#3368A0] hover:bg-[#C8DFDB]/30 whitespace-nowrap cursor-pointer shrink-0 disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages */}
          <div ref={listRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[90%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-[#3368A0] text-white'
                      : m.error
                        ? 'bg-amber-50 border border-amber-200 text-amber-900'
                        : 'bg-white border border-slate-200 text-slate-800 shadow-2xs'
                  }`}
                >
                  {m.error ? (
                    <span>{m.error}</span>
                  ) : (
                    <div className="whitespace-pre-wrap">{m.content}</div>
                  )}

                  {/* Mandatory Source Attribution */}
                  {m.role === 'assistant' && m.sources && m.sources.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-slate-100 space-y-1.5">
                      <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                        Sources Grounded
                      </div>
                      {m.sources.map((src, sIdx) => (
                        <div
                          key={sIdx}
                          className="rounded-lg bg-slate-50 border border-slate-200 px-2.5 py-1.5 text-[11px]"
                        >
                          <div className="flex items-center gap-1.5 font-semibold text-[#3368A0]">
                            {src.type === 'Policy Rule' ? (
                              <BookOpen className="w-3 h-3 shrink-0" />
                            ) : src.type === 'Compliance Engine' ? (
                              <ShieldCheck className="w-3 h-3 shrink-0" />
                            ) : (
                              <Database className="w-3 h-3 shrink-0" />
                            )}
                            <span>{src.label}</span>
                          </div>
                          {src.detail && (
                            <div className="text-slate-600 mt-0.5">{src.detail}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex items-start">
                <div className="rounded-xl bg-white border border-slate-200 px-3.5 py-2.5 text-xs text-slate-600 inline-flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-[#3368A0]" />
                  Checking policy table &amp; live claims data...
                </div>
              </div>
            )}
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendQuestion(input);
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                currentUser.role === 'finance' || currentUser.role === 'admin'
                  ? 'Ask about spend, violations, or policy limits...'
                  : 'Ask about your hotel, meal, travel, or pre-approval rules...'
              }
              className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3368A0]/30 focus:border-[#3368A0]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="Send question"
              className="p-2 rounded-lg bg-[#3368A0] text-white hover:bg-[#295584] cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
