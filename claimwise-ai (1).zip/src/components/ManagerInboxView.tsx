import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  Users,
  XCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ExpenseClaim } from '../types/claimwise';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';
import { analyzeClaimRisk } from '../utils/riskEngine';
import { ActionCommentModal } from './ActionCommentModal';
import { PolicyExceptionTag, RiskLevelBadge, StatusBadge } from './StatusBadge';

export const ManagerInboxView: React.FC = () => {
  const {
    currentUser,
    claims,
    policies,
    navigate,
    managerApproveClaims,
    managerRejectClaim,
  } = useApp();

  const [tab, setTab] = useState<'pending' | 'history'>('pending');
  const [showAllTeams, setShowAllTeams] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [rejectTarget, setRejectTarget] = useState<ExpenseClaim | null>(null);
  const [bulkModalOpen, setBulkModalOpen] = useState(false);

  const reporteeClaims = useMemo(() => {
    if (!currentUser) return [];
    return claims.filter((c) => {
      if (!showAllTeams && currentUser.role !== 'admin') {
        return c.managerId === currentUser.id;
      }
      return true;
    });
  }, [claims, currentUser, showAllTeams]);

  const pendingClaims = useMemo(
    () => reporteeClaims.filter((c) => c.status === 'Submitted'),
    [reporteeClaims]
  );

  const historyClaims = useMemo(
    () =>
      reporteeClaims.filter((c) =>
        ['Manager Approved', 'Finance Verified', 'Paid', 'Rejected', 'Sent Back'].includes(
          c.status
        )
      ),
    [reporteeClaims]
  );

  const activeList = tab === 'pending' ? pendingClaims : historyClaims;

  const riskByClaimId = useMemo(() => {
    const map = new Map<string, ReturnType<typeof analyzeClaimRisk>>();
    for (const c of activeList) {
      map.set(c.id, analyzeClaimRisk(c, claims, policies));
    }
    return map;
  }, [activeList, claims, policies]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleAllPending = () => {
    if (selectedIds.length === pendingClaims.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(pendingClaims.map((c) => c.id));
    }
  };

  if (!currentUser) return null;

  const selectedTotal = pendingClaims
    .filter((c) => selectedIds.includes(c.id))
    .reduce((s, c) => s + c.totalAmount, 0);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#3368A0]" />
            <h2 className="text-lg font-semibold text-slate-900">Manager Approvals Inbox</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {pendingClaims.length} claim(s) awaiting your approval · Bulk approve compliant claims or reject with mandatory feedback.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {currentUser.role !== 'admin' && (
            <button
              type="button"
              onClick={() => {
                setShowAllTeams((v) => !v);
                setSelectedIds([]);
              }}
              className={`px-3 py-2 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                showAllTeams
                  ? 'bg-[#C8DFDB]/60 border-[#66A3BF] text-slate-900'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {showAllTeams ? 'Showing All Teams' : 'Direct Reportees Only'}
            </button>
          )}

          <div className="flex items-center bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setTab('pending')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                tab === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Pending ({pendingClaims.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('history')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                tab === 'history' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Team History ({historyClaims.length})
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Action Bar */}
      {tab === 'pending' && selectedIds.length > 0 && (
        <div className="rounded-xl border border-[#3368A0]/30 bg-[#C8DFDB]/30 px-5 py-3 flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs font-medium text-slate-900">
            Selected <strong className="font-mono-num">{selectedIds.length}</strong> claim(s) totaling{' '}
            <strong className="font-mono-num">{formatINR(selectedTotal)}</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 cursor-pointer"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => setBulkModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Bulk Approve ({selectedIds.length})
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        {activeList.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-slate-900">
              {tab === 'pending' ? 'All caught up!' : 'No reviewed claims yet'}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {tab === 'pending'
                ? 'There are no pending claims from your direct reportees.'
                : 'Approved and rejected claims will appear here.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  {tab === 'pending' && (
                    <th className="py-3 px-4 w-10">
                      <input
                        type="checkbox"
                        checked={
                          pendingClaims.length > 0 &&
                          selectedIds.length === pendingClaims.length
                        }
                        onChange={toggleAllPending}
                        aria-label="Select all pending claims"
                        className="rounded border-slate-300 accent-[#3368A0] cursor-pointer"
                      />
                    </th>
                  )}
                  <th className="py-3 px-4">Claim No.</th>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Purpose &amp; Destination</th>
                  <th className="py-3 px-4">Submitted</th>
                  <th className="py-3 px-4 text-right">Amount (₹)</th>
                  <th className="py-3 px-4">Status / Flags</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {activeList.map((c) => {
                  const risk = riskByClaimId.get(c.id);
                  const hasDup = c.isDuplicateFlagged || Boolean(risk && risk.duplicates.length > 0);
                  const dupRef =
                    c.duplicateRefClaimNo || risk?.duplicates[0]?.matchedClaimNo || '';
                  return (
                    <tr
                      key={c.id}
                      onClick={() => navigate('claim-detail', { claimId: c.id })}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                    >
                      {tab === 'pending' && (
                        <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={selectedIds.includes(c.id)}
                            onChange={() => toggleSelect(c.id)}
                            aria-label={`Select ${c.claimNo}`}
                            className="rounded border-slate-300 accent-[#3368A0] cursor-pointer"
                          />
                        </td>
                      )}
                      <td className="py-3 px-4 font-mono-num font-medium text-[#3368A0] whitespace-nowrap">
                        {c.claimNo}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-medium text-slate-900">{c.employeeName}</div>
                        <div className="text-xs text-slate-500">
                          {c.employeeCode} · {c.grade} · {c.department}
                        </div>
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-slate-900 truncate">{c.purpose}</div>
                        <div className="text-xs text-slate-500">
                          {c.destination} ({c.cityTier}) · {c.lineCount} lines
                        </div>
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600 font-mono-num whitespace-nowrap">
                        {formatDateDDMMMYYYY(c.submittedDate)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900 whitespace-nowrap">
                        {formatINR(c.totalAmount)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <StatusBadge status={c.status} />
                          {risk && risk.riskLevel !== 'Low' && (
                            <RiskLevelBadge level={risk.riskLevel} compact />
                          )}
                          {c.hasPolicyViolation && <PolicyExceptionTag compact />}
                          {hasDup && (
                            <span
                              title={`Duplicate of ${dupRef}`}
                              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-50 border border-rose-200 text-[11px] font-semibold text-rose-700 whitespace-nowrap"
                            >
                              <AlertTriangle className="w-3 h-3" />
                              Duplicate
                            </span>
                          )}
                          {risk && risk.anomalies.length > 0 && (
                            <span
                              title={risk.anomalies.map((a) => a.reason).join(' | ')}
                              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200 text-[11px] font-semibold text-amber-800 whitespace-nowrap"
                            >
                              {risk.anomalies.length} Anomal{risk.anomalies.length === 1 ? 'y' : 'ies'}
                            </span>
                          )}
                        </div>
                      </td>
                    <td
                      className="py-3 px-4 text-right whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => navigate('claim-detail', { claimId: c.id })}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View
                        </button>
                        {c.status === 'Submitted' && (
                          <>
                            <button
                              type="button"
                              onClick={() => managerApproveClaims([c.id])}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={() => setRejectTarget(c)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-rose-200 bg-rose-50 text-rose-700 text-xs font-medium hover:bg-rose-100 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Reject
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ActionCommentModal
        open={bulkModalOpen}
        title={`Bulk Approve ${selectedIds.length} Claim(s)`}
        subtitle={`Total value ${formatINR(selectedTotal)} will be forwarded to Finance Verification.`}
        confirmLabel={`Approve ${selectedIds.length} Claim(s)`}
        confirmVariant="primary"
        requireComment={false}
        defaultComment="Bulk approved by reporting manager."
        onCancel={() => setBulkModalOpen(false)}
        onConfirm={async (comment) => {
          await managerApproveClaims(selectedIds, comment);
          setSelectedIds([]);
          setBulkModalOpen(false);
        }}
      />

      <ActionCommentModal
        open={Boolean(rejectTarget)}
        title={`Reject ${rejectTarget?.claimNo || ''}`}
        subtitle={`Employee: ${rejectTarget?.employeeName || ''} · Mandatory comment required.`}
        confirmLabel="Confirm Rejection"
        confirmVariant="danger"
        requireComment={true}
        placeholder="State the reason for rejection..."
        onCancel={() => setRejectTarget(null)}
        onConfirm={async (comment) => {
          if (rejectTarget) {
            await managerRejectClaim(rejectTarget.id, comment);
            setSelectedIds((prev) => prev.filter((id) => id !== rejectTarget.id));
          }
          setRejectTarget(null);
        }}
      />
    </div>
  );
};
