import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  BadgeCheck,
  Bot,
  Check,
  CheckCircle2,
  CopyCheck,
  Edit3,
  Eye,
  Loader2,
  RotateCcw,
  Send,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  XCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  getPolicyExplanationPlaceholder,
  runAiComplianceCheck,
  runAiFinanceReviewAgent,
} from '../services/aiPlaceholders';
import {
  AiFinanceReviewResult,
  AiPreSubmissionCheckResult,
  ExpenseLine,
} from '../types/claimwise';
import {
  formatDateDDMMMYYYY,
  formatDateTimeDDMMMYYYY,
  formatINR,
  getTripDays,
} from '../utils/formatters';
import { evaluateClaimCompliance } from '../utils/policyEngine';
import { analyzeClaimRisk } from '../utils/riskEngine';
import { ActionCommentModal } from './ActionCommentModal';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { AiSummarySkeleton } from './SkeletonLoader';
import {
  PolicyExceptionTag,
  PolicyFlagBadge,
  RiskLevelBadge,
  RoleBadge,
  StatusBadge,
} from './StatusBadge';

const TRACKER_STEPS = [
  { key: 'Draft', label: 'Draft' },
  { key: 'Submitted', label: 'Submitted' },
  { key: 'Manager Approved', label: 'Manager Approved' },
  { key: 'Finance Verified', label: 'Finance Verified' },
  { key: 'Paid', label: 'Paid' },
];

export const ClaimDetailView: React.FC = () => {
  const {
    currentUser,
    claims,
    policies,
    auditTrail,
    selectedClaimId,
    navigate,
    saveClaim,
    managerApproveClaims,
    managerRejectClaim,
    financeVerifyClaim,
    financeSendBackClaim,
    financeMarkAsPaid,
    recordAiReviewAudit,
  } = useApp();

  const [previewLine, setPreviewLine] = useState<ExpenseLine | null>(null);
  const [modalAction, setModalAction] = useState<
    null | 'mgr-approve' | 'mgr-reject' | 'fin-verify' | 'fin-sendback' | 'fin-paid'
  >(null);
  const [submitError, setSubmitError] = useState('');
  const [aiReviewLoading, setAiReviewLoading] = useState(false);
  const [aiReviewResult, setAiReviewResult] = useState<AiPreSubmissionCheckResult | null>(null);
  const [aiReviewError, setAiReviewError] = useState('');
  const [agentLoading, setAgentLoading] = useState(false);
  const [agentResult, setAgentResult] = useState<AiFinanceReviewResult | null>(null);
  const [agentError, setAgentError] = useState('');

  const claim = useMemo(
    () => claims.find((c) => c.id === selectedClaimId) || claims[0],
    [claims, selectedClaimId]
  );

  const claimAudit = useMemo(
    () => (claim ? auditTrail.filter((a) => a.entityId === claim.id || a.claimNo === claim.claimNo) : []),
    [auditTrail, claim]
  );

  const liveCompliance = useMemo(() => {
    if (!claim) return null;
    return evaluateClaimCompliance(
      {
        tripFromDate: claim.tripFromDate,
        tripToDate: claim.tripToDate,
        employeeId: claim.employeeId,
        lines: claim.lines,
      },
      claim.grade,
      claim.cityTier,
      policies,
      claims,
      claim.id
    );
  }, [claim, policies, claims]);

  const riskAnalysis = useMemo(() => {
    if (!claim) return null;
    return analyzeClaimRisk(claim, claims, policies);
  }, [claim, claims, policies]);

  useEffect(() => {
    setAiReviewResult(null);
    setAiReviewError('');
    setAgentResult(null);
    setAgentError('');
    setSubmitError('');
  }, [claim?.id]);

  if (!currentUser || !claim) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center">
        <p className="text-sm font-semibold text-slate-900">Claim not found</p>
        <button
          type="button"
          onClick={() => navigate('my-claims')}
          className="mt-4 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium cursor-pointer"
        >
          Back to Claims
        </button>
      </div>
    );
  }

  const aiExplain = getPolicyExplanationPlaceholder(claim);
  const tripDays = getTripDays(claim.tripFromDate, claim.tripToDate);

  const currentStepIndex = (() => {
    if (claim.status === 'Draft' || claim.status === 'Sent Back') return 0;
    if (claim.status === 'Submitted') return 1;
    if (claim.status === 'Manager Approved' || claim.status === 'Rejected') return 2;
    if (claim.status === 'Finance Verified') return 3;
    if (claim.status === 'Paid') return 4;
    return 0;
  })();

  const canEmployeeEdit =
    (claim.employeeId === currentUser.id || currentUser.role === 'admin') &&
    (claim.status === 'Draft' || claim.status === 'Sent Back');

  const canManagerAct =
    (currentUser.role === 'manager' || currentUser.role === 'admin') &&
    claim.status === 'Submitted';

  const canFinanceVerify =
    (currentUser.role === 'finance' || currentUser.role === 'admin') &&
    claim.status === 'Manager Approved';

  const canFinancePay =
    (currentUser.role === 'finance' || currentUser.role === 'admin') &&
    claim.status === 'Finance Verified';

  const canViewRiskPanel =
    currentUser.role === 'manager' ||
    currentUser.role === 'finance' ||
    currentUser.role === 'admin';

  const canUseFinanceAgent =
    currentUser.role === 'finance' || currentUser.role === 'admin';

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() =>
            navigate(
              currentUser.role === 'manager'
                ? 'manager-inbox'
                : currentUser.role === 'finance'
                  ? 'finance-queue'
                  : 'my-claims'
            )
          }
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to List
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {canEmployeeEdit && (
            <>
              <button
                type="button"
                onClick={() => navigate('new-claim', { editClaimId: claim.id })}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                Edit Claim
              </button>
              <button
                type="button"
                onClick={async () => {
                  setSubmitError('');
                  try {
                    await saveClaim(
                      {
                        id: claim.id,
                        purpose: claim.purpose,
                        destination: claim.destination,
                        tripFromDate: claim.tripFromDate,
                        tripToDate: claim.tripToDate,
                        aiComplianceSummary: claim.aiComplianceSummary,
                        lines: claim.lines.map((l) => ({
                          date: l.date,
                          category: l.category,
                          merchant: l.merchant,
                          amount: l.amount,
                          gstAmount: l.gstAmount,
                          gstin: l.gstin,
                          currency: l.currency,
                          invoiceNo: l.invoiceNo,
                          paymentMode: l.paymentMode,
                          receiptName: l.receiptName,
                          receiptMimeType: l.receiptMimeType,
                          receiptUrl: l.receiptUrl,
                          preApprovalRef: l.preApprovalRef,
                          aiConfidenceScore: l.aiConfidenceScore,
                          aiExtracted: l.aiExtracted,
                          aiCategoryReason: l.aiCategoryReason,
                          aiFieldConfidence: l.aiFieldConfidence,
                          aiSuggestedValues: l.aiSuggestedValues,
                          aiPolicyRecommendation: l.aiPolicyRecommendation,
                          justification: l.justification,
                        })),
                      },
                      true
                    );
                  } catch (err) {
                    setSubmitError(err instanceof Error ? err.message : 'Unable to submit claim.');
                  }
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                Submit Claim
              </button>
            </>
          )}

          {canManagerAct && (
            <>
              <button
                type="button"
                onClick={() => setModalAction('mgr-reject')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-rose-300 bg-rose-50 text-xs font-medium text-rose-700 hover:bg-rose-100 cursor-pointer"
              >
                <XCircle className="w-3.5 h-3.5" />
                Reject
              </button>
              <button
                type="button"
                onClick={() => setModalAction('mgr-approve')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Approve Claim
              </button>
            </>
          )}

          {canFinanceVerify && (
            <>
              <button
                type="button"
                onClick={() => setModalAction('fin-sendback')}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-amber-300 bg-amber-50 text-xs font-medium text-amber-800 hover:bg-amber-100 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Send Back
              </button>
              <button
                type="button"
                onClick={() => setModalAction('fin-verify')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Verify Claim
              </button>
            </>
          )}

          {canFinancePay && (
            <button
              type="button"
              onClick={() => setModalAction('fin-paid')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-teal-700 text-white text-xs font-medium hover:bg-teal-800 cursor-pointer"
            >
              <BadgeCheck className="w-3.5 h-3.5" />
              Mark as Paid
            </button>
          )}
        </div>
      </div>

      {submitError && (
        <div className="rounded-xl border border-rose-300 bg-rose-50 px-5 py-3 text-xs text-rose-800 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{submitError}</span>
        </div>
      )}

      {/* Visual Progress Tracker */}
      <section className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-lg font-bold font-mono-num text-[#3368A0]">{claim.claimNo}</span>
            <StatusBadge status={claim.status} />
            {(claim.hasPolicyViolation || liveCompliance?.hasExceptions) && (
              <PolicyExceptionTag />
            )}
          </div>
          <span className="text-xs text-slate-500 font-mono-num">
            Last updated: {formatDateTimeDDMMMYYYY(claim.updatedAt)}
          </span>
        </div>

        <div className="grid grid-cols-5 gap-2">
          {TRACKER_STEPS.map((step, idx) => {
            const isRejectedHere = claim.status === 'Rejected' && idx === 2;
            const isSentBack = claim.status === 'Sent Back' && idx === 0;
            const completed =
              claim.status !== 'Rejected' &&
              claim.status !== 'Sent Back' &&
              idx <= currentStepIndex;

            return (
              <div key={step.key} className="flex flex-col items-center text-center">
                <div className="w-full flex items-center">
                  <div
                    className={`h-1 flex-1 ${
                      idx === 0
                        ? 'bg-transparent'
                        : completed
                          ? 'bg-[#3368A0]'
                          : 'bg-slate-200'
                    }`}
                  />
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold border shrink-0 ${
                      isRejectedHere
                        ? 'bg-rose-600 border-rose-600 text-white'
                        : isSentBack
                          ? 'bg-amber-500 border-amber-500 text-white'
                          : completed
                            ? 'bg-[#3368A0] border-[#3368A0] text-white'
                            : 'bg-white border-slate-300 text-slate-400'
                    }`}
                  >
                    {isRejectedHere ? (
                      <XCircle className="w-4 h-4" />
                    ) : completed ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      idx + 1
                    )}
                  </div>
                  <div
                    className={`h-1 flex-1 ${
                      idx === TRACKER_STEPS.length - 1
                        ? 'bg-transparent'
                        : idx < currentStepIndex && claim.status !== 'Rejected'
                          ? 'bg-[#3368A0]'
                          : 'bg-slate-200'
                    }`}
                  />
                </div>
                <span className="text-[11px] font-medium text-slate-700 mt-2">
                  {isRejectedHere ? 'Rejected' : isSentBack ? 'Sent Back' : step.label}
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Duplicate or Violation Callout */}
      {(claim.isDuplicateFlagged || (riskAnalysis && riskAnalysis.duplicates.length > 0)) && (
        <div className="rounded-xl border border-rose-300 bg-rose-50 px-5 py-3.5 flex items-start gap-3 text-xs text-rose-800">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Potential Duplicate Detected</p>
            <p className="mt-0.5">
              {riskAnalysis && riskAnalysis.duplicates.length > 0 ? (
                riskAnalysis.duplicates[0].reason
              ) : (
                <>
                  This claim shares matching invoice or merchant/date/amount details with{' '}
                  <strong className="font-mono-num">{claim.duplicateRefClaimNo}</strong>. Finance verification is required before payout.
                </>
              )}
            </p>
          </div>
        </div>
      )}

      {/* Claim Summary & AI Explanation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-semibold text-slate-900">Claim Overview</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-slate-500">Employee</span>
              <p className="font-semibold text-slate-900 mt-0.5">{claim.employeeName}</p>
              <p className="text-slate-500 font-mono-num">{claim.employeeCode} · {claim.grade}</p>
            </div>
            <div>
              <span className="text-slate-500">Department &amp; Cost Centre</span>
              <p className="font-semibold text-slate-900 mt-0.5">{claim.department}</p>
              <p className="text-slate-500 font-mono-num">{claim.costCentre}</p>
            </div>
            <div>
              <span className="text-slate-500">Destination</span>
              <p className="font-semibold text-slate-900 mt-0.5">{claim.destination}</p>
              <p className="text-slate-500">{claim.cityTier}</p>
            </div>
            <div>
              <span className="text-slate-500">Trip Dates</span>
              <p className="font-semibold text-slate-900 font-mono-num mt-0.5">
                {formatDateDDMMMYYYY(claim.tripFromDate)}
              </p>
              <p className="text-slate-500 font-mono-num">
                to {formatDateDDMMMYYYY(claim.tripToDate)} ({tripDays}d)
              </p>
            </div>
            <div>
              <span className="text-slate-500">Total Claimed</span>
              <p className="text-base font-bold text-slate-900 font-mono-num mt-0.5">
                {formatINR(claim.totalAmount)}
              </p>
              <p className="text-slate-500 font-mono-num">GST: {formatINR(claim.totalGstAmount)}</p>
            </div>
            <div>
              <span className="text-slate-500">Submitted Date</span>
              <p className="font-semibold text-slate-900 font-mono-num mt-0.5">
                {claim.submittedDate ? formatDateDDMMMYYYY(claim.submittedDate) : 'Draft'}
              </p>
            </div>
          </div>
          <div className="pt-3 border-t border-slate-100">
            <span className="text-xs text-slate-500">Business Purpose</span>
            <p className="text-sm text-slate-900 mt-0.5">{claim.purpose}</p>
          </div>
        </section>

        <section className="lg:col-span-5 bg-white rounded-2xl border border-[#66A3BF]/50 p-6 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#3368A0]" />
                <h3 className="text-sm font-semibold text-slate-900">AI Policy Compliance Engine</h3>
              </div>
              <span
                className={`text-xs font-bold font-mono-num px-2.5 py-0.5 rounded-md border ${
                  (liveCompliance?.complianceScore ?? claim.complianceScore ?? 100) >= 85
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                    : (liveCompliance?.complianceScore ?? claim.complianceScore ?? 100) >= 60
                      ? 'bg-amber-50 border-amber-200 text-amber-800'
                      : 'bg-red-50 border-red-300 text-red-700'
                }`}
              >
                Score: {liveCompliance?.complianceScore ?? claim.complianceScore ?? 100}/100
              </span>
            </div>

            {aiReviewLoading ? (
              <AiSummarySkeleton label="Analyzing claim compliance & GST rules..." />
            ) : aiReviewResult ? (
              <div className="space-y-2.5">
                <p className="text-xs text-slate-700 leading-relaxed">
                  {aiReviewResult.executiveSummary}
                </p>
                {aiReviewResult.gstAssessment && (
                  <p className="text-[11px] text-slate-500">{aiReviewResult.gstAssessment}</p>
                )}
                {aiReviewResult.prioritizedFixes.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    {aiReviewResult.prioritizedFixes.slice(0, 4).map((fix, idx) => (
                      <div
                        key={idx}
                        className="rounded-lg bg-slate-50 border border-slate-200 px-2.5 py-1.5 text-[11px] text-slate-700"
                      >
                        <strong className="text-slate-900">
                          L{fix.lineNumber} · {fix.issueTitle}:
                        </strong>{' '}
                        {fix.suggestedFix}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {claim.aiComplianceSummary || aiExplain.summary}
                </p>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {aiExplain.gstEligibilityNote}
                </p>
              </>
            )}

            {aiReviewError && (
              <p className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5">
                {aiReviewError}
              </p>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] text-slate-500">
              Limits grounded in Nova Foods expense_policies
            </span>
            <button
              type="button"
              disabled={aiReviewLoading || !liveCompliance}
              onClick={async () => {
                if (!liveCompliance) return;
                setAiReviewError('');
                setAiReviewLoading(true);
                try {
                  const res = await runAiComplianceCheck({
                    claimHeader: {
                      claimNo: claim.claimNo,
                      employeeName: claim.employeeName,
                      grade: claim.grade,
                      department: claim.department,
                      destination: claim.destination,
                      cityTier: claim.cityTier,
                      tripFromDate: claim.tripFromDate,
                      tripToDate: claim.tripToDate,
                      purpose: claim.purpose,
                      totalAmount: claim.totalAmount,
                      totalGstAmount: claim.totalGstAmount,
                    },
                    lines: claim.lines.map((l, idx) => ({
                      lineNumber: idx + 1,
                      date: l.date,
                      category: l.category,
                      merchant: l.merchant,
                      amount: l.amount,
                      gstAmount: l.gstAmount,
                      gstin: l.gstin,
                      hasReceipt: Boolean(l.receiptName || l.receiptUrl),
                      preApprovalRef: l.preApprovalRef,
                      justification: l.justification,
                    })),
                    summary: liveCompliance,
                  });
                  setAiReviewResult(res);
                } catch (err) {
                  setAiReviewError(
                    err instanceof Error ? err.message : 'Unable to fetch AI review right now.'
                  );
                } finally {
                  setAiReviewLoading(false);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer disabled:opacity-50"
            >
              {aiReviewLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              {aiReviewLoading ? 'Analyzing...' : 'Run AI Compliance Review'}
            </button>
          </div>
        </section>
      </div>

      {/* Risk Indicators Panel (Manager, Finance & Admin) */}
      {canViewRiskPanel && riskAnalysis && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#3368A0]/10 text-[#3368A0] flex items-center justify-center shrink-0">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-slate-900">Risk Indicators</h3>
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#C8DFDB]/60 text-[10px] font-semibold text-[#3368A0]">
                    <Sparkles className="w-2.5 h-2.5" />
                    Duplicate &amp; Anomaly Detection
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Cross-claim duplicate checks, 6-month employee category baselines, near-cap frequency, round numbers, and split bills
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <span className="text-xs font-mono-num text-slate-500">
                Risk Score: <strong className="text-slate-900">{riskAnalysis.riskScore}/100</strong>
              </span>
              <RiskLevelBadge level={riskAnalysis.riskLevel} />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="rounded-xl border border-slate-200 bg-slate-50/70 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-600">
                <CopyCheck className="w-4 h-4 text-[#3368A0]" />
                <span>Duplicate Matches</span>
              </div>
              <span
                className={`font-mono-num font-bold ${
                  riskAnalysis.duplicates.length > 0 ? 'text-rose-700' : 'text-emerald-700'
                }`}
              >
                {riskAnalysis.duplicates.length}
              </span>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50/70 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-600">
                <TrendingUp className="w-4 h-4 text-[#3368A0]" />
                <span>Spend Anomalies</span>
              </div>
              <span
                className={`font-mono-num font-bold ${
                  riskAnalysis.anomalies.length > 0 ? 'text-amber-700' : 'text-emerald-700'
                }`}
              >
                {riskAnalysis.anomalies.length}
              </span>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50/70 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-600">
                <AlertTriangle className="w-4 h-4 text-[#3368A0]" />
                <span>Policy Exceptions</span>
              </div>
              <span
                className={`font-mono-num font-bold ${
                  riskAnalysis.policyExceptionCount > 0 ? 'text-rose-700' : 'text-emerald-700'
                }`}
              >
                {riskAnalysis.policyExceptionCount}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            {riskAnalysis.duplicates.map((dup, idx) => (
              <div
                key={`dup-${idx}`}
                className="rounded-xl border border-rose-200 bg-rose-50/70 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-0.5">
                  <div className="font-semibold text-rose-800">
                    Potential Duplicate ({dup.matchType === 'EXACT_INVOICE' ? 'Invoice Match' : dup.matchType === 'INTRA_CLAIM' ? 'Same-Claim Line' : 'Same Employee · Merchant · Close Date'}) · {dup.similarityScore}% similarity
                  </div>
                  <p className="text-slate-700">{dup.reason}</p>
                </div>
                {dup.matchedClaimId !== claim.id && (
                  <button
                    type="button"
                    onClick={() => navigate('claim-detail', { claimId: dup.matchedClaimId })}
                    className="px-2.5 py-1 rounded-md border border-rose-300 bg-white text-[11px] font-semibold text-rose-700 hover:bg-rose-50 cursor-pointer whitespace-nowrap"
                  >
                    Inspect {dup.matchedClaimNo}
                  </button>
                )}
              </div>
            ))}

            {riskAnalysis.anomalies.map((anom, idx) => (
              <div
                key={`anom-${idx}`}
                className={`rounded-xl border px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-xs ${
                  anom.severity === 'high'
                    ? 'border-amber-300 bg-amber-50/80'
                    : 'border-slate-200 bg-slate-50'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="font-semibold text-slate-900">
                    {anom.title}
                    {anom.lineNumber ? ` · Line #${anom.lineNumber}` : ''}
                  </div>
                  <p className="text-slate-700">{anom.reason}</p>
                </div>
                {anom.metrics && (
                  <span className="font-mono-num text-[11px] font-medium px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 whitespace-nowrap">
                    {anom.metrics}
                  </span>
                )}
              </div>
            ))}

            {riskAnalysis.duplicates.length === 0 && riskAnalysis.anomalies.length === 0 && (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 px-4 py-3 text-xs text-emerald-900">
                {riskAnalysis.plainEnglishReasons[0]}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Finance AI Review Agent (Human-in-the-Loop) */}
      {canUseFinanceAgent && riskAnalysis && liveCompliance && (
        <section className="bg-white rounded-2xl border border-[#3368A0]/35 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#3368A0] text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-sm font-semibold text-slate-900">AI Review Agent</h3>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#C8DFDB]/70 text-[11px] font-semibold text-[#3368A0]">
                    <Sparkles className="w-3 h-3" />
                    Finance Copilot
                  </span>
                  <span className="px-2 py-0.5 rounded border border-slate-200 bg-slate-50 text-[11px] font-medium text-slate-600">
                    Human-in-the-Loop
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Reviews OCR extraction, policy compliance, duplicates, and spend anomalies end-to-end to draft a Finance recommendation.
                </p>
              </div>
            </div>

            <button
              type="button"
              disabled={agentLoading}
              onClick={async () => {
                setAgentError('');
                setAgentLoading(true);
                try {
                  const res = await runAiFinanceReviewAgent({
                    claim,
                    compliance: liveCompliance,
                    riskAnalysis,
                  });
                  setAgentResult(res);
                  await recordAiReviewAudit(claim.id, res.recommendation, res.executiveReasoning);
                } catch (err) {
                  setAgentError(
                    err instanceof Error ? err.message : 'Unable to run AI Review Agent right now.'
                  );
                } finally {
                  setAgentLoading(false);
                }
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer disabled:opacity-50"
            >
              {agentLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              {agentLoading ? 'Reviewing Claim...' : agentResult ? 'Re-run AI Review Agent' : 'AI Review Agent'}
            </button>
          </div>

          {agentError && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              {agentError}
            </div>
          )}

          {agentLoading && (
            <AiSummarySkeleton label="Auditing extraction, policy rules, duplicates & anomalies..." />
          )}

          {!agentLoading && agentResult && (
            <div className="space-y-4 pt-2 border-t border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-xs font-medium text-slate-500">Draft Recommendation:</span>
                  <span
                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md border text-xs font-bold ${
                      agentResult.recommendation === 'Approve'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                        : agentResult.recommendation === 'Approve with exception'
                          ? 'bg-amber-50 border-amber-300 text-amber-900'
                          : 'bg-rose-50 border-rose-300 text-rose-800'
                    }`}
                  >
                    {agentResult.recommendation}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">
                    AI Confidence: <strong className="text-slate-800">{agentResult.confidence}</strong>
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 italic">
                  {agentResult.humanDecisionNote}
                </span>
              </div>

              <p className="text-xs text-slate-800 leading-relaxed bg-[#F2EFE7]/70 border border-slate-200 rounded-xl px-4 py-3">
                {agentResult.executiveReasoning}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div className="rounded-xl border border-slate-200 p-3.5 space-y-1">
                  <div className="font-semibold text-[#3368A0]">1. Extraction &amp; GST Audit</div>
                  <p className="text-slate-600 leading-relaxed">
                    {agentResult.pillars.extractionReview}
                  </p>
                </div>
                <div className="rounded-xl border border-slate-200 p-3.5 space-y-1">
                  <div className="font-semibold text-[#3368A0]">2. Policy Compliance Rules</div>
                  <p className="text-slate-600 leading-relaxed">
                    {agentResult.pillars.policyReview}
                  </p>
                </div>
                <div className="rounded-xl border border-slate-200 p-3.5 space-y-1">
                  <div className="font-semibold text-[#3368A0]">3. Duplicates &amp; Anomalies</div>
                  <p className="text-slate-600 leading-relaxed">
                    {agentResult.pillars.duplicateAndAnomalyReview}
                  </p>
                </div>
              </div>

              {agentResult.suggestedFinanceComment && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-semibold text-slate-800">Drafted Finance Remark: </span>
                    <span className="text-slate-700">{agentResult.suggestedFinanceComment}</span>
                  </div>
                  {canFinanceVerify && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setModalAction('fin-sendback')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-amber-900 text-xs font-medium hover:bg-amber-100 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Send Back (Human Decision)
                      </button>
                      <button
                        type="button"
                        onClick={() => setModalAction('fin-verify')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-medium hover:bg-emerald-800 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Verify Claim (Human Decision)
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </section>
      )}

      {/* Expense Lines Table */}
      <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">
            Itemized Expense Lines ({claim.lines.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Category &amp; Merchant</th>
                <th className="py-3 px-4">Invoice / GSTIN</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
                <th className="py-3 px-4">Policy Check</th>
                <th className="py-3 px-4 text-right">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {claim.lines.map((l, idx) => {
                const lineEval = liveCompliance?.lineEvaluations[idx];
                const aiLineRec =
                  aiReviewResult?.lineRecommendations.find((r) => r.lineNumber === idx + 1)
                    ?.recommendation ||
                  l.aiPolicyRecommendation ||
                  lineEval?.aiRecommendation;

                return (
                  <tr key={l.id} className="hover:bg-slate-50/60 align-top">
                    <td className="py-3 px-4 font-mono-num text-slate-700 whitespace-nowrap">
                      {formatDateDDMMMYYYY(l.date)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-slate-900">{l.category}</span>
                        {l.aiExtracted && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#C8DFDB]/60 text-[10px] font-semibold text-[#3368A0]">
                            <Sparkles className="w-2.5 h-2.5" />
                            AI extracted
                          </span>
                        )}
                      </div>
                      <div className="text-slate-600">{l.merchant}</div>
                      {l.aiCategoryReason && (
                        <div className="text-[11px] text-[#3368A0] mt-0.5">{l.aiCategoryReason}</div>
                      )}
                      {l.justification && (
                        <div className="text-[11px] text-slate-600 mt-1">
                          <span className="font-medium text-slate-700">Justification:</span>{' '}
                          {l.justification}
                        </div>
                      )}
                      {(lineEval?.hasException || l.policyFlag === 'Violation') && (
                        <div className="mt-2 rounded-lg border border-red-200 bg-red-50/70 px-2.5 py-2 space-y-1 max-w-md">
                          <div className="text-[11px] font-semibold text-red-800">
                            ⚠️ Policy Exception
                            {lineEval && lineEval.excessAmount > 0 && (
                              <span className="font-mono-num">
                                {' '}
                                – Claimed {formatINR(lineEval.claimedAmount)} | Permissible{' '}
                                {formatINR(lineEval.permissibleLimit)} | Excess{' '}
                                {formatINR(lineEval.excessAmount)}
                              </span>
                            )}
                          </div>
                          {aiLineRec && (
                            <div className="text-[11px] text-slate-700">
                              <span className="font-semibold text-[#3368A0]">AI Recommendation: </span>
                              {aiLineRec}
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono-num text-slate-600 whitespace-nowrap">
                      <div>{l.invoiceNo || '—'}</div>
                      <div className="text-[11px] text-slate-400">{l.gstin || 'No GSTIN'}</div>
                      {l.preApprovalRef && (
                        <div className="text-[11px] text-emerald-700">PA: {l.preApprovalRef}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">{l.paymentMode}</td>
                    <td className="py-3 px-4 text-right font-mono-num whitespace-nowrap">
                      <div className="font-semibold text-slate-900">
                        {l.currency && l.currency !== 'INR' ? `${l.currency} ${l.amount}` : formatINR(l.amount)}
                      </div>
                      <div className="text-[11px] text-slate-500">GST {formatINR(l.gstAmount)}</div>
                    </td>
                    <td className="py-3 px-4">
                      {lineEval?.hasException ? (
                        <PolicyExceptionTag compact title={lineEval.reason} />
                      ) : (
                        <PolicyFlagBadge
                          flag={lineEval?.flag || l.policyFlag}
                          reason={lineEval?.reason || l.policyFlagReason}
                        />
                      )}
                      {(lineEval?.reason || l.policyFlagReason) && (
                        <div className="text-[11px] text-slate-500 mt-1 max-w-[220px]">
                          {lineEval?.reason || l.policyFlagReason}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      {l.receiptUrl ? (
                        <button
                          type="button"
                          onClick={() => setPreviewLine(l)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-200 bg-white text-xs font-medium text-[#3368A0] hover:bg-slate-50 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View
                        </button>
                      ) : (
                        <span className="text-rose-600 font-medium">Missing</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* AI Extraction vs User Final Audit Comparison */}
      {claim.lines.some((l) => l.aiExtracted) && (
        <section className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-[#3368A0]" />
            <h3 className="text-sm font-semibold text-slate-900">
              AI Extraction vs User Final Audit Log
            </h3>
          </div>
          <div className="space-y-3">
            {claim.lines.map((l, idx) => {
              if (!l.aiExtracted) return null;
              const overrides = l.aiUserOverrides || [];
              return (
                <div
                  key={l.id}
                  className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 text-xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900">
                      Line #{idx + 1} · {l.merchant} ({l.category})
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Avg AI Confidence: {l.aiConfidenceScore}% ·{' '}
                      {overrides.length === 0
                        ? 'Accepted without overrides'
                        : `${overrides.length} field(s) overridden by user`}
                    </span>
                  </div>
                  {overrides.length > 0 && (
                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {overrides.map((ov) => (
                        <div
                          key={ov.field}
                          className="bg-white border border-amber-200 rounded-lg px-2.5 py-1.5"
                        >
                          <div className="text-[11px] font-semibold text-slate-700">{ov.field}</div>
                          <div className="text-[11px] text-slate-500">
                            AI: <span className="line-through">{ov.aiValue}</span> → Final:{' '}
                            <span className="font-semibold text-[#3368A0]">{ov.userValue}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Approval History & Audit Trail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Approval History &amp; Comments</h3>
          <div className="space-y-4">
            {claim.approvalHistory.map((log) => (
              <div key={log.id} className="flex items-start gap-3 pb-3 border-b border-slate-100 last:border-0 last:pb-0">
                <div className="w-2 h-2 rounded-full bg-[#3368A0] mt-2 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-900">{log.action}</span>
                      <RoleBadge role={log.byRole} />
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono-num">
                      {formatDateTimeDDMMMYYYY(log.timestamp)}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    By <span className="font-medium text-slate-800">{log.byName}</span> · {log.comments}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">Audit Trail</h3>
          {claimAudit.length === 0 ? (
            <p className="text-xs text-slate-500">
              All state mutations on {claim.claimNo} are logged here automatically.
            </p>
          ) : (
            <div className="space-y-3">
              {claimAudit.map((aud) => (
                <div key={aud.id} className="text-xs pb-3 border-b border-slate-100 last:border-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-800">{aud.action}</span>
                    <span className="font-mono-num text-[11px] text-slate-400">
                      {formatDateTimeDDMMMYYYY(aud.timestamp)}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-0.5">{aud.details}</p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <ReceiptPreviewModal line={previewLine} onClose={() => setPreviewLine(null)} />

      <ActionCommentModal
        open={modalAction === 'mgr-approve'}
        title={`Approve ${claim.claimNo}`}
        subtitle={`Route ${formatINR(claim.totalAmount)} claim by ${claim.employeeName} to Finance Verification.`}
        confirmLabel="Approve Claim"
        confirmVariant="primary"
        requireComment={false}
        defaultComment="Verified trip details and approved for Finance check."
        onCancel={() => setModalAction(null)}
        onConfirm={async (comment) => {
          await managerApproveClaims([claim.id], comment);
          setModalAction(null);
        }}
      />

      <ActionCommentModal
        open={modalAction === 'mgr-reject'}
        title={`Reject ${claim.claimNo}`}
        subtitle="Rejection closes the claim and notifies the employee. A reason is mandatory."
        confirmLabel="Reject Claim"
        confirmVariant="danger"
        requireComment={true}
        placeholder="Explain why this claim is rejected..."
        onCancel={() => setModalAction(null)}
        onConfirm={async (comment) => {
          await managerRejectClaim(claim.id, comment);
          setModalAction(null);
        }}
      />

      <ActionCommentModal
        open={modalAction === 'fin-verify'}
        title={`Verify ${claim.claimNo}`}
        subtitle="Confirm GST invoice validity and policy compliance to queue for payout."
        confirmLabel="Verify for Payout"
        confirmVariant="primary"
        requireComment={false}
        defaultComment={
          agentResult && agentResult.recommendation !== 'Send back' && agentResult.suggestedFinanceComment
            ? agentResult.suggestedFinanceComment
            : 'GSTIN & tax invoices verified by Finance Controller.'
        }
        onCancel={() => setModalAction(null)}
        onConfirm={async (comment) => {
          await financeVerifyClaim(claim.id, comment);
          setModalAction(null);
        }}
      />

      <ActionCommentModal
        open={modalAction === 'fin-sendback'}
        title={`Send Back ${claim.claimNo}`}
        subtitle="Returns claim to employee for edits or missing receipt upload. Comment is mandatory."
        confirmLabel="Send Back to Employee"
        confirmVariant="amber"
        requireComment={true}
        defaultComment={
          agentResult && agentResult.recommendation === 'Send back'
            ? agentResult.suggestedFinanceComment
            : ''
        }
        placeholder="Specify required correction (e.g., attach GST tax invoice)..."
        onCancel={() => setModalAction(null)}
        onConfirm={async (comment) => {
          await financeSendBackClaim(claim.id, comment);
          setModalAction(null);
        }}
      />

      <ActionCommentModal
        open={modalAction === 'fin-paid'}
        title={`Mark ${claim.claimNo} as Paid`}
        subtitle={`Confirm reimbursement settlement of ${formatINR(claim.totalAmount)} to ${claim.employeeName}.`}
        confirmLabel="Mark as Paid"
        confirmVariant="teal"
        requireComment={false}
        defaultComment={`Settled via HDFC NEFT UTR NF26${Date.now().toString().slice(-6)}`}
        onCancel={() => setModalAction(null)}
        onConfirm={async (comment) => {
          await financeMarkAsPaid([claim.id], comment);
          setModalAction(null);
        }}
      />
    </div>
  );
};
