import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface ActionCommentModalProps {
  open: boolean;
  title: string;
  subtitle: string;
  confirmLabel: string;
  confirmVariant?: 'primary' | 'danger' | 'amber' | 'teal';
  requireComment: boolean;
  defaultComment?: string;
  placeholder?: string;
  onCancel: () => void;
  onConfirm: (comment: string) => Promise<void> | void;
}

export const ActionCommentModal: React.FC<ActionCommentModalProps> = ({
  open,
  title,
  subtitle,
  confirmLabel,
  confirmVariant = 'primary',
  requireComment,
  defaultComment = '',
  placeholder = 'Enter remarks or reference details...',
  onCancel,
  onConfirm,
}) => {
  const [comment, setComment] = useState(defaultComment);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setComment(defaultComment);
      setError('');
    }
  }, [open, defaultComment]);

  if (!open) return null;

  const btnClasses = {
    primary: 'bg-[#3368A0] hover:bg-[#295584] text-white',
    danger: 'bg-rose-600 hover:bg-rose-700 text-white',
    amber: 'bg-amber-600 hover:bg-amber-700 text-white',
    teal: 'bg-teal-700 hover:bg-teal-800 text-white',
  }[confirmVariant];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (requireComment && !comment.trim()) {
      setError('A comment is mandatory for this action.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await onConfirm(comment.trim() || defaultComment);
      setComment('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-2xl border border-slate-200 max-w-md w-full shadow-xl overflow-hidden"
      >
        <div className="flex items-start justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900">{title}</h3>
            <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6">
          <label className="block text-xs font-medium text-slate-700 mb-2">
            Comments {requireComment ? <span className="text-rose-600">* (Mandatory)</span> : '(Optional)'}
          </label>
          <textarea
            rows={3}
            value={comment}
            onChange={(e) => {
              setComment(e.target.value);
              if (error) setError('');
            }}
            placeholder={placeholder}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3368A0]/30 focus:border-[#3368A0]"
          />
          {error && <p className="text-xs text-rose-600 mt-1.5">{error}</p>}
        </div>

        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer disabled:opacity-50 ${btnClasses}`}
          >
            {submitting ? 'Processing...' : confirmLabel}
          </button>
        </div>
      </form>
    </div>
  );
};
