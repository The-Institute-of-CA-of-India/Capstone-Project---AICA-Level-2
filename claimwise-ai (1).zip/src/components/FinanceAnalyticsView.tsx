import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  Calendar,
  Clock,
  CopyCheck,
  Download,
  Filter,
  IndianRupee,
  Loader2,
  PieChart,
  RotateCcw,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { runAiAnalyticsInsights } from '../services/aiPlaceholders';
import {
  AiAnalyticsInsightsResult,
  ClaimStatus,
  EXPENSE_CATEGORIES,
} from '../types/claimwise';
import {
  AnalyticsFilters,
  computeFinanceAnalytics,
  DEFAULT_ANALYTICS_FILTERS,
} from '../utils/analyticsEngine';
import { exportRowsToCsv } from '../utils/csvExport';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';
import { AiSummarySkeleton } from './SkeletonLoader';
import { PolicyExceptionTag, StatusBadge } from './StatusBadge';

const ALL_STATUSES: ClaimStatus[] = [
  'Draft',
  'Submitted',
  'Manager Approved',
  'Finance Verified',
  'Paid',
  'Sent Back',
  'Rejected',
];

export const FinanceAnalyticsView: React.FC = () => {
  const { currentUser, claims, departments, costCentres, policies, navigate } = useApp();

  const [filters, setFilters] = useState<AnalyticsFilters>(DEFAULT_ANALYTICS_FILTERS);
  const [orgChartMode, setOrgChartMode] = useState<'department' | 'costCentre'>('department');
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [insightsResult, setInsightsResult] = useState<AiAnalyticsInsightsResult | null>(null);
  const [insightsError, setInsightsError] = useState('');

  const referenceDate = '2026-11-24';

  const analytics = useMemo(
    () =>
      computeFinanceAnalytics(
        claims,
        departments,
        costCentres,
        policies,
        filters,
        referenceDate
      ),
    [claims, departments, costCentres, policies, filters]
  );

  const availableCostCentres = useMemo(() => {
    if (filters.department === 'ALL') return costCentres;
    return costCentres.filter((cc) => cc.department === filters.department);
  }, [costCentres, filters.department]);

  if (!currentUser || (currentUser.role !== 'finance' && currentUser.role !== 'admin')) {
    return null;
  }

  const maxMonthlySpend = Math.max(1, ...analytics.monthlyTrend.map((m) => m.totalSpend));
  const maxCategorySpend = Math.max(1, ...analytics.spendByCategory.map((c) => c.amount));
  const maxOrgSpend = Math.max(
    1,
    ...(orgChartMode === 'department'
      ? analytics.spendByDepartment.map((d) => d.amount)
      : analytics.spendByCostCentre.map((cc) => cc.amount))
  );
  const maxExceptionCount = Math.max(1, ...analytics.exceptionBreakdown.map((e) => e.count));
  const maxAgeingAmount = Math.max(1, ...analytics.pendingAgeing.map((b) => b.amount));

  const applyFilters = (next: Partial<AnalyticsFilters>) => {
    setFilters((prev) => ({ ...prev, ...next }));
    setInsightsResult(null);
    setInsightsError('');
  };

  const handleGenerateInsights = async () => {
    setInsightsError('');
    setInsightsLoading(true);
    try {
      const res = await runAiAnalyticsInsights({
        filtersSummary: {
          dateFrom: filters.dateFrom || 'Start',
          dateTo: filters.dateTo || 'End',
          department: filters.department,
          costCentre: filters.costCentre,
          category: filters.category,
          status: filters.status,
          matchingClaimsCount: analytics.filteredClaims.length,
        },
        analyticsSnapshot: {
          kpis: {
            totalSpendYtd: formatINR(analytics.kpis.totalSpendYtd),
            totalSpendMtd: formatINR(analytics.kpis.totalSpendMtd),
            mtdMonthLabel: analytics.kpis.mtdMonthLabel,
            totalGstEligible: formatINR(analytics.kpis.totalGstEligible),
            pendingLiability: formatINR(analytics.kpis.pendingLiability),
            pendingCount: analytics.kpis.pendingCount,
            avgApprovalTurnaroundDays: analytics.kpis.avgApprovalTurnaroundDays,
            policyExceptionRatePct: analytics.kpis.policyExceptionRatePct,
            exceptionClaimCount: analytics.kpis.exceptionClaimCount,
            duplicateFlaggedCount: analytics.kpis.duplicateFlaggedCount,
            duplicateFlaggedAmount: formatINR(analytics.kpis.duplicateFlaggedAmount),
            highRiskCount: analytics.kpis.highRiskCount,
          },
          monthlyTrend: analytics.monthlyTrend.map((m) => ({
            month: m.label,
            totalSpend: formatINR(m.totalSpend),
            paidSpend: formatINR(m.paidSpend),
            claims: m.claimCount,
          })),
          topCategories: analytics.spendByCategory.slice(0, 5).map((c) => ({
            category: c.category,
            spend: formatINR(c.amount),
            sharePct: c.sharePct,
          })),
          budgetVsActual: analytics.budgetVsActual.map((b) => ({
            department: b.department,
            actual: formatINR(b.actual),
            budget: formatINR(b.budget),
            utilizationPct: b.utilizationPct,
          })),
          topExceptions: analytics.exceptionBreakdown.slice(0, 5).map((e) => ({
            reason: e.label,
            count: e.count,
            impact: formatINR(e.impactAmount),
          })),
          pendingAgeing: analytics.pendingAgeing.map((a) => ({
            bucket: a.bucket,
            count: a.count,
            liability: formatINR(a.amount),
          })),
        },
      });
      setInsightsResult(res);
    } catch (err) {
      setInsightsError(
        err instanceof Error ? err.message : 'Unable to generate AI Analytics Insights right now.'
      );
    } finally {
      setInsightsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header & Quick Presets */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#3368A0]" />
            <h2 className="text-lg font-semibold text-slate-900">
              Finance Analytics &amp; Spend Intelligence
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Executive expense telemetry across {analytics.filteredClaims.length} matching claims · Nova Foods India Pvt Ltd
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => applyFilters({ dateFrom: '2026-06-01', dateTo: '2026-11-30' })}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
              filters.dateFrom === '2026-06-01' && filters.dateTo === '2026-11-30'
                ? 'bg-[#3368A0] text-white border-[#3368A0]'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            All FY 2026
          </button>
          <button
            type="button"
            onClick={() => applyFilters({ dateFrom: '2026-11-01', dateTo: '2026-11-30' })}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
              filters.dateFrom === '2026-11-01'
                ? 'bg-[#3368A0] text-white border-[#3368A0]'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Nov 2026 (MTD)
          </button>
          <button
            type="button"
            onClick={() => applyFilters({ dateFrom: '2026-09-01', dateTo: '2026-11-30' })}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
              filters.dateFrom === '2026-09-01'
                ? 'bg-[#3368A0] text-white border-[#3368A0]'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Last 3 Months
          </button>
          <button
            type="button"
            onClick={() => {
              setFilters(DEFAULT_ANALYTICS_FILTERS);
              setInsightsResult(null);
              setInsightsError('');
            }}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <section className="bg-white rounded-2xl border border-slate-200 p-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 mb-3">
          <Filter className="w-3.5 h-3.5 text-[#3368A0]" />
          <span>Slice &amp; Filter Analytics</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">From Date</label>
            <input
              type="date"
              value={filters.dateFrom}
              onChange={(e) => applyFilters({ dateFrom: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 font-mono-num"
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">To Date</label>
            <input
              type="date"
              value={filters.dateTo}
              onChange={(e) => applyFilters({ dateTo: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 font-mono-num"
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Department</label>
            <select
              value={filters.department}
              onChange={(e) =>
                applyFilters({ department: e.target.value, costCentre: 'ALL' })
              }
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 bg-white"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.name}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Cost Centre</label>
            <select
              value={filters.costCentre}
              onChange={(e) => applyFilters({ costCentre: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 bg-white"
            >
              <option value="ALL">All Cost Centres</option>
              {availableCostCentres.map((cc) => (
                <option key={cc.id} value={cc.code}>
                  {cc.code} · {cc.location}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Category</label>
            <select
              value={filters.category}
              onChange={(e) => applyFilters({ category: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 bg-white"
            >
              <option value="ALL">All Categories</option>
              {EXPENSE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Claim Status</label>
            <select
              value={filters.status}
              onChange={(e) => applyFilters({ status: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 text-xs text-slate-900 bg-white"
            >
              <option value="ALL">All Statuses</option>
              {ALL_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* KPI Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Total Spend (YTD / MTD)</span>
            <IndianRupee className="w-4 h-4 text-[#3368A0]" />
          </div>
          <div className="mt-2.5 text-xl font-bold text-slate-900 font-mono-num">
            {formatINR(analytics.kpis.totalSpendYtd)}
          </div>
          <p className="text-xs text-slate-500 mt-1 font-mono-num">
            MTD ({analytics.kpis.mtdMonthLabel}):{' '}
            <strong className="text-slate-800">{formatINR(analytics.kpis.totalSpendMtd)}</strong>
          </p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Pending Liability</span>
            <Calendar className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2.5 text-xl font-bold text-slate-900 font-mono-num">
            {formatINR(analytics.kpis.pendingLiability)}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {analytics.kpis.pendingCount} unpaid active claim(s)
          </p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Avg Approval Turnaround</span>
            <Clock className="w-4 h-4 text-[#66A3BF]" />
          </div>
          <div className="mt-2.5 text-xl font-bold text-slate-900 font-mono-num">
            {analytics.kpis.avgApprovalTurnaroundDays.toFixed(1)} days
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Across {analytics.kpis.turnaroundSampleSize} approved claim(s)
          </p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Policy Exception Rate</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2.5 text-xl font-bold text-rose-700 font-mono-num">
            {analytics.kpis.policyExceptionRatePct.toFixed(1)}%
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {analytics.kpis.exceptionClaimCount} claim(s) with violations
          </p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Flagged Duplicates</span>
            <CopyCheck className="w-4 h-4 text-rose-700" />
          </div>
          <div className="mt-2.5 text-xl font-bold text-slate-900 font-mono-num">
            {analytics.kpis.duplicateFlaggedCount}
          </div>
          <p className="text-xs text-slate-500 mt-1 font-mono-num">
            Exposure: {formatINR(analytics.kpis.duplicateFlaggedAmount)}
          </p>
        </div>
      </section>

      {/* AI Insights Panel */}
      <section className="bg-white rounded-2xl border border-[#66A3BF]/55 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#3368A0]/10 text-[#3368A0] flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                ✨ AI Insights · Executive Management Summary
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Summarizes trends, top policy exceptions, duplicate/anomaly risks, and Finance actions for the currently filtered dataset.
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={insightsLoading}
            onClick={handleGenerateInsights}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer disabled:opacity-50"
          >
            {insightsLoading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            {insightsLoading
              ? 'Generating Summary...'
              : insightsResult
                ? 'Refresh AI Insights'
                : 'Generate AI Insights'}
          </button>
        </div>

        {insightsError && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
            {insightsError}
          </div>
        )}

        {insightsLoading ? (
          <AiSummarySkeleton label="Synthesizing management trends & risk actions..." />
        ) : insightsResult ? (
          <div className="space-y-4 pt-2 border-t border-slate-100">
            <div className="rounded-xl bg-[#F2EFE7]/75 border border-slate-200 px-4 py-3 text-xs font-medium text-slate-900">
              {insightsResult.executiveHeadline}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="rounded-xl border border-slate-200 p-4 space-y-2">
                <div className="font-semibold text-[#3368A0]">Key Spend &amp; Budget Trends</div>
                <ul className="space-y-1.5 text-slate-700 list-disc pl-4">
                  {insightsResult.keyTrends.map((t, i) => (
                    <li key={i}>{t}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-rose-200 bg-rose-50/30 p-4 space-y-2">
                <div className="font-semibold text-rose-800">Top Exceptions &amp; Risks</div>
                <ul className="space-y-1.5 text-slate-700 list-disc pl-4">
                  {insightsResult.topExceptionsAndRisks.map((t, i) => (
                    <li key={i}>{t}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/30 p-4 space-y-2">
                <div className="font-semibold text-emerald-800">Recommended Actions</div>
                <ul className="space-y-1.5 text-slate-700 list-disc pl-4">
                  {insightsResult.recommendedActions.map((t, i) => (
                    <li key={i}>{t}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-xl bg-slate-50 border border-slate-200 px-4 py-3 text-xs text-slate-600">
            Click <strong>Generate AI Insights</strong> above to synthesize an executive briefing across{' '}
            <strong className="font-mono-num">{formatINR(analytics.kpis.totalSpendYtd)}</strong> of spend,{' '}
            <strong className="font-mono-num">{analytics.kpis.policyExceptionRatePct.toFixed(1)}%</strong> exception rate, and{' '}
            <strong className="font-mono-num">{analytics.kpis.pendingCount}</strong> pending claims.
          </div>
        )}
      </section>

      {/* Row 1 Charts: Monthly Spend Trend & Spend by Category */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Spend Trend */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#3368A0]" />
                <h3 className="text-sm font-semibold text-slate-900">Monthly Spend Trend</h3>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Total claimed spend vs settled (Paid) spend per month
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                exportRowsToCsv(
                  'claimwise_monthly_spend_trend.csv',
                  ['Month', 'Total Spend (INR)', 'Paid Spend (INR)', 'Claim Count', 'Exception Claims'],
                  analytics.monthlyTrend.map((m) => [
                    m.label,
                    m.totalSpend,
                    m.paidSpend,
                    m.claimCount,
                    m.exceptionCount,
                  ])
                )
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              Export CSV
            </button>
          </div>

          {analytics.monthlyTrend.length === 0 ? (
            <p className="text-xs text-slate-500 py-8 text-center">No data for selected filters.</p>
          ) : (
            <div className="space-y-4">
              <div className="h-52 flex items-end gap-3 pt-6 pb-2 border-b border-slate-200">
                {analytics.monthlyTrend.map((m) => {
                  const totalH = Math.max(8, Math.round((m.totalSpend / maxMonthlySpend) * 100));
                  const paidH = Math.max(4, Math.round((m.paidSpend / maxMonthlySpend) * 100));
                  return (
                    <div
                      key={m.monthKey}
                      className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group"
                    >
                      <span className="text-[10px] font-mono-num font-semibold text-slate-700">
                        {formatINR(m.totalSpend)}
                      </span>
                      <div className="w-full max-w-[44px] flex items-end justify-center gap-1 h-36">
                        <div
                          title={`Total: ${formatINR(m.totalSpend)} (${m.claimCount} claims)`}
                          className="w-1/2 rounded-t-md bg-[#3368A0] transition-all"
                          style={{ height: `${totalH}%` }}
                        />
                        <div
                          title={`Paid: ${formatINR(m.paidSpend)}`}
                          className="w-1/2 rounded-t-md bg-[#66A3BF] transition-all"
                          style={{ height: `${paidH}%` }}
                        />
                      </div>
                      <span className="text-[11px] font-medium text-slate-600 whitespace-nowrap">
                        {m.label.split(' ')[0]}
                      </span>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center gap-4 text-[11px] text-slate-600">
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-xs bg-[#3368A0]" />
                  Total Active Spend
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-xs bg-[#66A3BF]" />
                  Settled / Paid
                </span>
              </div>
            </div>
          )}
        </section>

        {/* Spend by Category */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <PieChart className="w-4 h-4 text-[#3368A0]" />
                <h3 className="text-sm font-semibold text-slate-900">Spend by Category</h3>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                INR spend &amp; % share across corporate expense heads
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                exportRowsToCsv(
                  'claimwise_spend_by_category.csv',
                  ['Category', 'Spend (INR)', 'GST (INR)', 'Line Items', 'Share (%)'],
                  analytics.spendByCategory.map((c) => [
                    c.category,
                    c.amount,
                    c.gstAmount,
                    c.lineCount,
                    c.sharePct,
                  ])
                )
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              Export CSV
            </button>
          </div>

          <div className="space-y-2.5">
            {analytics.spendByCategory.map((cat) => (
              <div key={cat.category} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-800">{cat.category}</span>
                  <span className="font-mono-num text-slate-700">
                    <strong className="text-slate-900">{formatINR(cat.amount)}</strong>{' '}
                    <span className="text-slate-400">({cat.sharePct}%)</span>
                  </span>
                </div>
                <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#3368A0]"
                    style={{
                      width: `${cat.amount > 0 ? Math.max(3, Math.round((cat.amount / maxCategorySpend) * 100)) : 0}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Row 2 Charts: Spend by Dept / Cost Centre & Budget vs Actual */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Spend by Department / Cost Centre */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Spend by {orgChartMode === 'department' ? 'Department' : 'Cost Centre'}
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Toggle between functional departments and regional cost centres
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-[11px]">
                <button
                  type="button"
                  onClick={() => setOrgChartMode('department')}
                  className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                    orgChartMode === 'department'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  Department
                </button>
                <button
                  type="button"
                  onClick={() => setOrgChartMode('costCentre')}
                  className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                    orgChartMode === 'costCentre'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  Cost Centre
                </button>
              </div>
              <button
                type="button"
                onClick={() =>
                  orgChartMode === 'department'
                    ? exportRowsToCsv(
                        'claimwise_spend_by_department.csv',
                        ['Department', 'Code', 'Spend (INR)', 'Claims', 'Annual Budget (INR)', 'Utilization (%)'],
                        analytics.spendByDepartment.map((d) => [
                          d.department,
                          d.code,
                          d.amount,
                          d.claimCount,
                          d.budget,
                          d.utilizationPct,
                        ])
                      )
                    : exportRowsToCsv(
                        'claimwise_spend_by_cost_centre.csv',
                        ['Cost Centre', 'Name', 'Department', 'Spend (INR)', 'Claims'],
                        analytics.spendByCostCentre.map((cc) => [
                          cc.costCentre,
                          cc.name,
                          cc.department,
                          cc.amount,
                          cc.claimCount,
                        ])
                      )
                }
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <Download className="w-3 h-3" />
                CSV
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {orgChartMode === 'department'
              ? analytics.spendByDepartment.map((d) => (
                  <div key={d.code} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-800">
                        {d.department}{' '}
                        <span className="text-[11px] text-slate-400 font-mono-num">
                          ({d.claimCount} claims)
                        </span>
                      </span>
                      <span className="font-mono-num font-semibold text-slate-900">
                        {formatINR(d.amount)}
                      </span>
                    </div>
                    <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#66A3BF]"
                        style={{
                          width: `${d.amount > 0 ? Math.max(4, Math.round((d.amount / maxOrgSpend) * 100)) : 0}%`,
                        }}
                      />
                    </div>
                  </div>
                ))
              : analytics.spendByCostCentre.map((cc) => (
                  <div key={cc.costCentre} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-800">
                        <span className="font-mono-num text-[#3368A0]">{cc.costCentre}</span> ·{' '}
                        {cc.name}
                      </span>
                      <span className="font-mono-num font-semibold text-slate-900">
                        {formatINR(cc.amount)}
                      </span>
                    </div>
                    <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#3368A0]"
                        style={{
                          width: `${cc.amount > 0 ? Math.max(4, Math.round((cc.amount / maxOrgSpend) * 100)) : 0}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
          </div>
        </section>

        {/* Budget vs Actual by Department */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Budget vs Actual by Department
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Annual department travel &amp; expense budgets compared against actual spend
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                exportRowsToCsv(
                  'claimwise_budget_vs_actual.csv',
                  ['Department', 'Annual Budget (INR)', 'Actual Spend (INR)', 'Remaining (INR)', 'Utilization (%)'],
                  analytics.budgetVsActual.map((b) => [
                    b.department,
                    b.budget,
                    b.actual,
                    b.variance,
                    b.utilizationPct,
                  ])
                )
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              Export CSV
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2">Department</th>
                  <th className="py-2 text-right">Annual Budget</th>
                  <th className="py-2 text-right">Actual Spend</th>
                  <th className="py-2 text-right">Variance</th>
                  <th className="py-2 w-28 text-right">Util.</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {analytics.budgetVsActual.map((b) => (
                  <tr key={b.code}>
                    <td className="py-2.5 font-medium text-slate-900">{b.department}</td>
                    <td className="py-2.5 text-right font-mono-num text-slate-500">
                      {formatINR(b.budget)}
                    </td>
                    <td className="py-2.5 text-right font-mono-num font-semibold text-slate-900">
                      {formatINR(b.actual)}
                    </td>
                    <td className="py-2.5 text-right font-mono-num text-emerald-700">
                      {formatINR(b.variance)}
                    </td>
                    <td className="py-2.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-14 h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              b.utilizationPct >= 90
                                ? 'bg-rose-600'
                                : b.utilizationPct >= 75
                                  ? 'bg-amber-500'
                                  : 'bg-[#3368A0]'
                            }`}
                            style={{ width: `${Math.min(100, Math.max(3, b.utilizationPct))}%` }}
                          />
                        </div>
                        <span className="font-mono-num font-semibold text-[#3368A0]">
                          {b.utilizationPct}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {/* Row 3 Charts: Exception Reasons Breakdown & Ageing of Pending Claims */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Exception Reasons Breakdown */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Exception Reasons Breakdown
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Frequency and rupee exposure across deterministic policy rules
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                exportRowsToCsv(
                  'claimwise_exception_breakdown.csv',
                  ['Code', 'Exception Reason', 'Occurrences', 'Share (%)', 'Exposure (INR)'],
                  analytics.exceptionBreakdown.map((e) => [
                    e.code,
                    e.label,
                    e.count,
                    e.sharePct,
                    e.impactAmount,
                  ])
                )
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              Export CSV
            </button>
          </div>

          {analytics.exceptionBreakdown.length === 0 ? (
            <div className="py-8 text-center text-xs text-emerald-700">
              No policy exceptions found for the selected filters.
            </div>
          ) : (
            <div className="space-y-3">
              {analytics.exceptionBreakdown.map((e) => (
                <div key={e.code} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800">
                      {e.label}{' '}
                      <span className="text-[11px] text-slate-400">({e.sharePct}%)</span>
                    </span>
                    <span className="font-mono-num text-slate-700">
                      <strong className="text-rose-700">{e.count}x</strong> · {formatINR(e.impactAmount)}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-rose-600"
                      style={{
                        width: `${Math.max(5, Math.round((e.count / maxExceptionCount) * 100))}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Ageing of Pending Claims */}
        <section className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Ageing of Pending Claims
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Unpaid claims bucketed as of {formatDateDDMMMYYYY(referenceDate)} (0–7, 8–15, 16–30, &gt;30 days)
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                exportRowsToCsv(
                  'claimwise_pending_ageing.csv',
                  ['Ageing Bucket', 'Claim Count', 'Pending Liability (INR)'],
                  analytics.pendingAgeing.map((b) => [b.bucket, b.count, b.amount])
                )
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-[11px] font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Download className="w-3 h-3" />
              Export CSV
            </button>
          </div>

          <div className="grid grid-cols-4 gap-3 pt-2">
            {analytics.pendingAgeing.map((b, idx) => {
              const barH = b.amount > 0 ? Math.max(12, Math.round((b.amount / maxAgeingAmount) * 100)) : 4;
              const barColor =
                idx === 3
                  ? 'bg-rose-600'
                  : idx === 2
                    ? 'bg-amber-500'
                    : idx === 1
                      ? 'bg-[#66A3BF]'
                      : 'bg-[#3368A0]';
              return (
                <div
                  key={b.bucket}
                  className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 flex flex-col justify-between"
                >
                  <div className="h-24 flex items-end justify-center pb-2">
                    <div
                      className={`w-9 rounded-t-md ${barColor}`}
                      style={{ height: `${barH}%` }}
                    />
                  </div>
                  <div className="text-center space-y-0.5 border-t border-slate-200 pt-2">
                    <div className="text-[11px] font-semibold text-slate-700">{b.bucket}</div>
                    <div className="text-xs font-bold font-mono-num text-slate-900">
                      {formatINR(b.amount)}
                    </div>
                    <div className="text-[11px] text-slate-500">{b.count} claim(s)</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Top 10 Claimants Table */}
      <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Top 10 Claimants</h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Highest spend employees in selected window with exception counts
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              exportRowsToCsv(
                'claimwise_top_10_claimants.csv',
                ['Rank', 'Employee Code', 'Employee Name', 'Department', 'Grade', 'Claims', 'Total Spend (INR)', 'Exception Claims'],
                analytics.topClaimants.map((tc, idx) => [
                  idx + 1,
                  tc.employeeCode,
                  tc.employeeName,
                  tc.department,
                  tc.grade,
                  tc.claimCount,
                  tc.totalSpend,
                  tc.exceptionCount,
                ])
              )
            }
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Grade</th>
                <th className="py-3 px-4 text-right">Claims</th>
                <th className="py-3 px-4 text-right">Exceptions</th>
                <th className="py-3 px-4 text-right">Total Spend (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {analytics.topClaimants.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-xs text-slate-500">
                    No claimants match the active date, department, category, or status filters.
                  </td>
                </tr>
              ) : (
                analytics.topClaimants.map((tc, idx) => (
                  <tr key={tc.employeeId} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono-num text-slate-400">{idx + 1}</td>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {tc.employeeName}{' '}
                      <span className="text-[11px] text-slate-400 font-mono-num">
                        ({tc.employeeCode})
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{tc.department}</td>
                    <td className="py-3 px-4 font-mono-num text-slate-700">{tc.grade}</td>
                    <td className="py-3 px-4 text-right font-mono-num">{tc.claimCount}</td>
                    <td className="py-3 px-4 text-right font-mono-num">
                      {tc.exceptionCount > 0 ? (
                        <span className="text-rose-700 font-semibold">{tc.exceptionCount}</span>
                      ) : (
                        <span className="text-slate-400">0</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900">
                      {formatINR(tc.totalSpend)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Filtered Claims Export Table */}
      <section className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Filtered Claims Ledger ({analytics.filteredClaims.length})
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Click any row to inspect line-item receipts, policy exceptions, and AI review details
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              exportRowsToCsv(
                'claimwise_filtered_claims_ledger.csv',
                [
                  'Claim No',
                  'Employee',
                  'Employee Code',
                  'Grade',
                  'Department',
                  'Cost Centre',
                  'Destination',
                  'City Tier',
                  'Trip From',
                  'Trip To',
                  'Submitted Date',
                  'Total Amount (INR)',
                  'GST Amount (INR)',
                  'Status',
                  'Policy Exception',
                  'Duplicate Flagged',
                ],
                analytics.filteredClaims.map((c) => [
                  c.claimNo,
                  c.employeeName,
                  c.employeeCode,
                  c.grade,
                  c.department,
                  c.costCentre,
                  c.destination,
                  c.cityTier,
                  c.tripFromDate,
                  c.tripToDate,
                  c.submittedDate,
                  c.totalAmount,
                  c.totalGstAmount,
                  c.status,
                  c.hasPolicyViolation ? 'Yes' : 'No',
                  c.isDuplicateFlagged ? `Yes (${c.duplicateRefClaimNo})` : 'No',
                ])
              )
            }
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export Filtered Claims CSV
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Claim No.</th>
                <th className="py-3 px-4">Employee &amp; Dept</th>
                <th className="py-3 px-4">Destination &amp; Date</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
                <th className="py-3 px-4">Status &amp; Flags</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {analytics.filteredClaims.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                    No claims match the selected filters.{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setFilters(DEFAULT_ANALYTICS_FILTERS);
                        setInsightsResult(null);
                        setInsightsError('');
                      }}
                      className="text-[#3368A0] font-medium hover:underline cursor-pointer"
                    >
                      Reset analytics filters
                    </button>
                  </td>
                </tr>
              ) : (
                analytics.filteredClaims.slice(0, 15).map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => navigate('claim-detail', { claimId: c.id })}
                    className="hover:bg-slate-50/80 cursor-pointer"
                  >
                    <td className="py-3 px-4 font-mono-num font-semibold text-[#3368A0] whitespace-nowrap">
                      {c.claimNo}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-medium text-slate-900">{c.employeeName}</div>
                      <div className="text-[11px] text-slate-500">
                        {c.department} · {c.costCentre} · {c.grade}
                      </div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="text-slate-800">
                        {c.destination} ({c.cityTier})
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        {formatDateDDMMMYYYY(c.tripFromDate)}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900 whitespace-nowrap">
                      {formatINR(c.totalAmount)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <StatusBadge status={c.status} />
                        {c.hasPolicyViolation && <PolicyExceptionTag compact />}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
          {analytics.filteredClaims.length > 15 && (
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 text-[11px] text-slate-500">
              Showing top 15 of {analytics.filteredClaims.length} matching claims — click{' '}
              <strong>Export Filtered Claims CSV</strong> to download all rows.
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
