import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Edit3,
  FilePlus2,
  Search,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ClaimStatus, EXPENSE_CATEGORIES, ExpenseClaim } from '../types/claimwise';
import { formatDateDDMMMYYYY, formatINR } from '../utils/formatters';
import { ConfirmDialog } from './ConfirmDialog';
import { StatusBadge } from './StatusBadge';

const STATUS_FILTERS: ('All' | ClaimStatus)[] = [
  'All',
  'Draft',
  'Submitted',
  'Manager Approved',
  'Sent Back',
  'Finance Verified',
  'Rejected',
  'Paid',
];

export const MyClaimsView: React.FC = () => {
  const { currentUser, claims, navigate, deleteDraftClaim } = useApp();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | ClaimStatus>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [scopeAllOrg, setScopeAllOrg] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ExpenseClaim | null>(null);

  const filtered = useMemo(() => {
    if (!currentUser) return [];
    return claims.filter((c) => {
      if (!scopeAllOrg && currentUser.role === 'employee' && c.employeeId !== currentUser.id) {
        return false;
      }
      if (!scopeAllOrg && currentUser.role !== 'employee' && c.employeeId !== currentUser.id) {
        // Default "My Claims" shows own claims unless toggled to All Claims
        return false;
      }
      if (statusFilter !== 'All' && c.status !== statusFilter) return false;
      if (categoryFilter !== 'All' && !c.lines.some((l) => l.category === categoryFilter)) {
        return false;
      }
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const hit =
          c.claimNo.toLowerCase().includes(q) ||
          c.purpose.toLowerCase().includes(q) ||
          c.destination.toLowerCase().includes(q) ||
          c.employeeName.toLowerCase().includes(q) ||
          c.lines.some((l) => l.merchant.toLowerCase().includes(q));
        if (!hit) return false;
      }
      return true;
    });
  }, [claims, currentUser, statusFilter, categoryFilter, search, scopeAllOrg]);

  if (!currentUser) return null;

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              {scopeAllOrg ? 'All Organization Claims' : 'My Expense Claims'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {filtered.length} claim(s) matching current filters · Draft and Sent Back claims can be edited.
            </p>
          </div>
          <div className="flex items-center gap-2.5">
            {currentUser.role !== 'employee' && (
              <button
                type="button"
                onClick={() => setScopeAllOrg((v) => !v)}
                className={`px-3 py-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  scopeAllOrg
                    ? 'bg-[#C8DFDB]/60 border-[#66A3BF] text-slate-900'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                {scopeAllOrg ? 'Showing All Org Claims' : 'Show All Org Claims'}
              </button>
            )}
            <button
              type="button"
              onClick={() => navigate('new-claim', { editClaimId: null })}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] transition-colors cursor-pointer whitespace-nowrap"
            >
              <FilePlus2 className="w-4 h-4" />
              New Claim
            </button>
          </div>
        </div>

        {/* Search & Category */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by Claim No (EXP-2026-...), purpose, city, or merchant..."
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25 focus:border-[#3368A0]"
            />
          </div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-[#3368A0]/25"
          >
            <option value="All">All Categories</option>
            {EXPENSE_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {STATUS_FILTERS.map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                statusFilter === st
                  ? 'bg-[#3368A0] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Claims Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-slate-900">No expense claims found</p>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Try adjusting your status filter or create a new claim.
            </p>
            <div className="flex items-center justify-center gap-2.5">
              {(search || statusFilter !== 'All' || categoryFilter !== 'All') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearch('');
                    setStatusFilter('All');
                    setCategoryFilter('All');
                  }}
                  className="px-4 py-2 rounded-lg border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Clear Filters
                </button>
              )}
              <button
                type="button"
                onClick={() => navigate('new-claim', { editClaimId: null })}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] cursor-pointer"
              >
                <FilePlus2 className="w-4 h-4" />
                Create New Claim
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Claim No.</th>
                  {scopeAllOrg && <th className="py-3 px-4">Employee</th>}
                  <th className="py-3 px-4">Purpose &amp; City</th>
                  <th className="py-3 px-4">Submitted</th>
                  <th className="py-3 px-4 text-right">Amount (₹)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((c) => {
                  const canEdit =
                    (c.employeeId === currentUser.id || currentUser.role === 'admin') &&
                    (c.status === 'Draft' || c.status === 'Sent Back');
                  const canDelete =
                    (c.employeeId === currentUser.id || currentUser.role === 'admin') &&
                    c.status === 'Draft';

                  return (
                    <tr
                      key={c.id}
                      onClick={() => navigate('claim-detail', { claimId: c.id })}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4 font-mono-num font-medium text-[#3368A0] whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{c.claimNo}</span>
                          {(c.hasPolicyViolation || c.isDuplicateFlagged) && (
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          )}
                        </div>
                      </td>
                      {scopeAllOrg && (
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-medium text-slate-900">{c.employeeName}</div>
                          <div className="text-xs text-slate-500">
                            {c.department} · {c.grade}
                          </div>
                        </td>
                      )}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-slate-900 truncate">{c.purpose}</div>
                        <div className="text-xs text-slate-500">
                          {c.destination} ({c.cityTier}) · {formatDateDDMMMYYYY(c.tripFromDate)}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600 font-mono-num whitespace-nowrap">
                        {c.submittedDate ? formatDateDDMMMYYYY(c.submittedDate) : 'Not submitted'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-num font-semibold text-slate-900 whitespace-nowrap">
                        {formatINR(c.totalAmount)}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <StatusBadge status={c.status} />
                      </td>
                      <td
                        className="py-3 px-4 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="inline-flex items-center gap-1.5">
                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => navigate('new-claim', { editClaimId: c.id })}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" />
                              Edit
                            </button>
                          )}
                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(c)}
                              className="p-1.5 rounded-md border border-slate-200 text-rose-600 hover:bg-rose-50 cursor-pointer"
                              aria-label="Delete draft"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {!canEdit && (
                            <button
                              type="button"
                              onClick={() => navigate('claim-detail', { claimId: c.id })}
                              className="text-xs font-medium text-[#3368A0] hover:underline cursor-pointer"
                            >
                              Details
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        title={`Delete Draft ${deleteTarget?.claimNo || ''}?`}
        message={`Are you sure you want to permanently delete this draft claim (${deleteTarget?.purpose || 'Expense Draft'})? This action cannot be undone.`}
        confirmLabel="Delete Draft"
        variant="danger"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) {
            await deleteDraftClaim(deleteTarget.id);
          }
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};
