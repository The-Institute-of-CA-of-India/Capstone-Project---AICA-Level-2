import React, { useState } from 'react';
import {
  BarChart3,
  Bell,
  BookOpen,
  CheckCheck,
  Cloud,
  FilePlus2,
  FileText,
  Landmark,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  Sparkles,
  Users,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AppScreen, UserRole } from '../types/claimwise';
import { formatDateTimeDDMMMYYYY } from '../utils/formatters';
import { ClaimWiseAssistant } from './ClaimWiseAssistant';
import { PWAInstallButton } from './PWAInstallButton';
import { DashboardSyncSkeleton } from './SkeletonLoader';
import { RoleBadge } from './StatusBadge';

const SCREEN_TITLES: Record<AppScreen, string> = {
  dashboard: 'Dashboard',
  'new-claim': 'New / Edit Expense Claim',
  'my-claims': 'My Claims',
  'claim-detail': 'Claim Details',
  'manager-inbox': 'Manager Approvals Inbox',
  'finance-queue': 'Finance Verification Queue',
  'finance-analytics': 'Finance Analytics Dashboard',
  admin: 'Admin · Users & Policy Rules',
  'how-ai-works': 'About · How AI Works',
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    currentUser,
    firebaseUser,
    cloudSyncMode,
    signInWithGoogleCloud,
    disconnectGoogleCloud,
    activeScreen,
    navigate,
    loginAsDemoRole,
    logout,
    notifications,
    unreadCount,
    markNotificationRead,
    markAllNotificationsRead,
    claims,
    toast,
    clearToast,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  if (!currentUser) return null;

  const managerPendingCount = claims.filter(
    (c) =>
      c.status === 'Submitted' &&
      (currentUser.role === 'admin' || c.managerId === currentUser.id)
  ).length;

  const financePendingCount = claims.filter(
    (c) => c.status === 'Manager Approved' || c.status === 'Finance Verified'
  ).length;

  const navItems: {
    id: AppScreen;
    label: string;
    icon: React.ReactNode;
    roles: UserRole[];
    badge?: number;
  }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
      roles: ['employee', 'manager', 'finance', 'admin'],
    },
    {
      id: 'new-claim',
      label: 'New Claim',
      icon: <FilePlus2 className="w-4 h-4" />,
      roles: ['employee', 'manager', 'finance', 'admin'],
    },
    {
      id: 'my-claims',
      label: 'My Claims',
      icon: <FileText className="w-4 h-4" />,
      roles: ['employee', 'manager', 'finance', 'admin'],
    },
    {
      id: 'manager-inbox',
      label: 'Manager Approvals',
      icon: <Users className="w-4 h-4" />,
      roles: ['manager', 'admin'],
      badge: managerPendingCount,
    },
    {
      id: 'finance-queue',
      label: 'Finance Queue',
      icon: <Landmark className="w-4 h-4" />,
      roles: ['finance', 'admin'],
      badge: financePendingCount,
    },
    {
      id: 'finance-analytics',
      label: 'Finance Analytics',
      icon: <BarChart3 className="w-4 h-4" />,
      roles: ['finance', 'admin'],
    },
    {
      id: 'admin',
      label: 'Admin Console',
      icon: <Settings className="w-4 h-4" />,
      roles: ['admin'],
    },
    {
      id: 'how-ai-works',
      label: 'How AI Works',
      icon: <BookOpen className="w-4 h-4" />,
      roles: ['employee', 'manager', 'finance', 'admin'],
    },
  ];

  const allowedNav = navItems.filter((item) => item.roles.includes(currentUser.role));

  const SidebarContent = (
    <div className="h-full overflow-y-auto flex flex-col justify-between bg-white border-r border-slate-200">
      <div>
        {/* Brand */}
        <div className="px-5 py-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[#3368A0] text-white flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-base font-bold tracking-tight text-slate-900 truncate">
                ClaimWise AI
              </div>
              <div className="text-[11px] text-slate-500 truncate">Nova Foods India</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="p-3 space-y-1">
          {allowedNav.map((item) => {
            const active =
              activeScreen === item.id ||
              (activeScreen === 'claim-detail' && item.id === 'my-claims');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  navigate(item.id, item.id === 'new-claim' ? { editClaimId: null } : undefined);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#3368A0] text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  {item.icon}
                  <span>{item.label}</span>
                </span>
                {typeof item.badge === 'number' && item.badge > 0 && (
                  <span
                    className={`text-xs font-mono-num px-1.5 py-0.5 rounded ${
                      active ? 'bg-white/20 text-white' : 'bg-[#C8DFDB] text-slate-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Quick Demo Switcher + Cloud Status */}
      <div className="p-4 border-t border-slate-100 space-y-3">
        <div>
          <div className="text-[11px] font-medium text-slate-500 mb-2">Quick Demo Role Switch</div>
          <div className="grid grid-cols-2 gap-1.5">
            {(['employee', 'manager', 'finance', 'admin'] as UserRole[]).map((role) => (
              <button
                key={role}
                type="button"
                onClick={() => {
                  loginAsDemoRole(role);
                  setMobileMenuOpen(false);
                }}
                className={`px-2 py-1.5 rounded-md text-xs font-medium capitalize border transition-colors cursor-pointer ${
                  currentUser.role === role
                    ? 'bg-[#C8DFDB]/70 border-[#66A3BF] text-slate-900'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-2.5 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-slate-700">
              <Cloud className="w-3.5 h-3.5 text-[#3368A0]" />
              Google Cloud Sync
            </span>
            <span
              className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                cloudSyncMode === 'cloud'
                  ? 'bg-[#C8DFDB] text-slate-900'
                  : cloudSyncMode === 'syncing'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-200/80 text-slate-600'
              }`}
            >
              {cloudSyncMode === 'cloud'
                ? 'Synced'
                : cloudSyncMode === 'syncing'
                  ? 'Syncing…'
                  : 'Local'}
            </span>
          </div>

          {firebaseUser ? (
            <div className="space-y-1.5">
              <p className="text-[11px] text-slate-600 truncate" title={firebaseUser.email || ''}>
                {firebaseUser.email}
              </p>
              <button
                type="button"
                onClick={disconnectGoogleCloud}
                className="w-full px-2.5 py-1.5 rounded-md border border-slate-200 bg-white text-[11px] font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Disconnect Cloud Sync
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={signInWithGoogleCloud}
              className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#3368A0] text-white text-xs font-medium hover:bg-[#295584] transition-colors cursor-pointer"
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>Sign in with Google</span>
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-600 hover:bg-rose-50 hover:text-rose-700 transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Back to Login Screen</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F2EFE7] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        {SidebarContent}
      </aside>

      {/* Mobile/Tablet Sidebar Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] h-full z-10">{SidebarContent}</aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 cursor-pointer"
              aria-label="Open navigation menu"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="min-w-0">
              <div className="text-xs text-slate-500 hidden sm:block">
                Nova Foods India Pvt Ltd / <span className="text-slate-700">{SCREEN_TITLES[activeScreen]}</span>
              </div>
              <h1 className="text-base sm:text-lg font-semibold text-slate-900 truncate">
                {SCREEN_TITLES[activeScreen]}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden sm:block">
              <PWAInstallButton />
            </div>

            {/* Notifications Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotifOpen((o) => !o)}
                className="relative p-2 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#3368A0] text-white text-[10px] font-semibold flex items-center justify-center font-mono-num">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl border border-slate-200 shadow-lg z-50 overflow-hidden">
                    <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-900">
                        Workflow Notifications
                      </span>
                      {unreadCount > 0 && (
                        <button
                          type="button"
                          onClick={markAllNotificationsRead}
                          className="inline-flex items-center gap-1 text-xs text-[#3368A0] hover:underline cursor-pointer"
                        >
                          <CheckCheck className="w-3.5 h-3.5" />
                          Mark all read
                        </button>
                      )}
                    </div>
                    <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                      {notifications.length === 0 ? (
                        <div className="p-6 text-center text-xs text-slate-500">
                          No notifications for your role yet.
                        </div>
                      ) : (
                        notifications.slice(0, 8).map((n) => (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => {
                              markNotificationRead(n.id);
                              setNotifOpen(false);
                              if (n.claimId) {
                                navigate('claim-detail', { claimId: n.claimId });
                              }
                            }}
                            className={`w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors cursor-pointer ${
                              n.read ? 'bg-white' : 'bg-[#C8DFDB]/20'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-semibold text-slate-900 truncate">
                                {n.title}
                              </span>
                              <span className="text-[10px] text-slate-400 whitespace-nowrap">
                                {formatDateTimeDDMMMYYYY(n.timestamp)}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 mt-1 line-clamp-2">{n.message}</p>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* User Profile & Role Badge */}
            <div className="flex items-center gap-2.5 pl-2 border-l border-slate-200">
              {currentUser.avatarUrl ? (
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-[#3368A0] text-white text-xs font-semibold flex items-center justify-center shrink-0">
                  {currentUser.name
                    .split(' ')
                    .map((p) => p[0])
                    .slice(0, 2)
                    .join('')}
                </div>
              )}
              <div className="hidden sm:block text-left">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-900 whitespace-nowrap">
                    {currentUser.name}
                  </span>
                  <RoleBadge role={currentUser.role} />
                </div>
                <div className="text-[11px] text-slate-500">
                  {currentUser.employeeCode} · {currentUser.department} · {currentUser.grade}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1360px] w-full mx-auto">
          {cloudSyncMode === 'syncing' ? <DashboardSyncSkeleton /> : children}
        </main>

        {/* Capstone Footer */}
        <footer className="border-t border-slate-200/80 bg-white/75 px-4 sm:px-6 lg:px-8 py-3.5 text-xs text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span className="font-medium text-slate-700">
            ClaimWise AI – AICA Level 2 Capstone Project | Developed by CA Akshay Burde (#168212)
          </span>
          <button
            type="button"
            onClick={() => navigate('how-ai-works')}
            className="text-left sm:text-right text-[#3368A0] hover:underline font-medium cursor-pointer"
          >
            About · How AI Works
          </button>
        </footer>

        {/* Toast Notification */}
        {toast && (
          <div
            className={`fixed bottom-20 right-5 z-50 max-w-sm px-4 py-3 rounded-xl shadow-lg flex items-center justify-between gap-3 text-xs font-medium border ${
              toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-700'
                : toast.type === 'success'
                  ? 'bg-slate-900 text-white border-slate-700'
                  : 'bg-[#3368A0] text-white border-[#295584]'
            }`}
          >
            <span>{toast.message}</span>
            <button
              type="button"
              onClick={clearToast}
              className="text-white/75 hover:text-white cursor-pointer"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* ClaimWise Assistant (All Roles) */}
        <ClaimWiseAssistant />
      </div>
    </div>
  );
};
