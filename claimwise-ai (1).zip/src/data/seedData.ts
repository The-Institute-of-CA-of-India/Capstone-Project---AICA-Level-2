import {
  ApprovalLog,
  AuditEntry,
  ClaimStatus,
  CostCentre,
  Department,
  EXPENSE_CATEGORIES,
  ExpenseClaim,
  ExpenseLine,
  ExpensePolicy,
  Grade,
  INDIAN_CITIES,
  PaymentMode,
  UserProfile,
} from '../types/claimwise';
import { checkWeekendOrHoliday, evaluateClaimCompliance, findMatchingPolicy } from '../utils/policyEngine';

export const DEMO_OWNER_UID = 'demo_workspace';

export const SAMPLE_RECEIPT_HOTEL = '/src/assets/images/receipt_hotel_sample_1795531790951.jpg';
export const SAMPLE_RECEIPT_FLIGHT = '/src/assets/images/receipt_flight_sample_1795531792072.jpg';

export function buildSeedDepartments(ownerUid = DEMO_OWNER_UID): Department[] {
  return [
    { id: 'dept-sales', code: 'SLS', name: 'Sales', headName: 'Priya Nair', annualBudgetInr: 4800000, ownerUid },
    { id: 'dept-scm', code: 'SCM', name: 'Supply Chain', headName: 'Rajeshwari Iyer', annualBudgetInr: 3600000, ownerUid },
    { id: 'dept-mfg', code: 'MFG', name: 'Manufacturing', headName: 'Sandeep Joshi', annualBudgetInr: 4200000, ownerUid },
    { id: 'dept-fin', code: 'FIN', name: 'Finance', headName: 'Vikramaditya Rao', annualBudgetInr: 1800000, ownerUid },
    { id: 'dept-hr', code: 'HRD', name: 'HR', headName: 'Ananya Chatterjee', annualBudgetInr: 1400000, ownerUid },
  ];
}

export function buildSeedCostCentres(ownerUid = DEMO_OWNER_UID): CostCentre[] {
  return [
    { id: 'cc-mum-sls', code: 'CC-MUM-101', name: 'Mumbai Western Region Sales', department: 'Sales', location: 'Mumbai', ownerUid },
    { id: 'cc-del-sls', code: 'CC-DEL-102', name: 'Delhi North Territory Sales', department: 'Sales', location: 'Delhi', ownerUid },
    { id: 'cc-blr-scm', code: 'CC-BLR-201', name: 'Bengaluru Cold-Chain Logistics', department: 'Supply Chain', location: 'Bengaluru', ownerUid },
    { id: 'cc-pun-mfg', code: 'CC-PUN-301', name: 'Pune Packaging & QA Plant', department: 'Manufacturing', location: 'Pune', ownerUid },
    { id: 'cc-bmt-mfg', code: 'CC-BMT-302', name: 'Baramati Dairy & Snacks Unit', department: 'Manufacturing', location: 'Baramati', ownerUid },
    { id: 'cc-chn-fin', code: 'CC-CHN-401', name: 'Chennai Shared Finance & HR', department: 'Finance', location: 'Chennai', ownerUid },
  ];
}

export function buildSeedUsers(ownerUid = DEMO_OWNER_UID): UserProfile[] {
  return [
    // 5 Managers (including Demo Manager Priya Nair)
    {
      id: 'u-mgr-1',
      name: 'Priya Nair',
      employeeCode: 'NF-1002',
      email: 'priya.nair@novafoods.in',
      role: 'manager',
      department: 'Sales',
      costCentre: 'CC-MUM-101',
      grade: 'G4',
      managerId: 'u-fin-1',
      location: 'Mumbai',
      avatarUrl: '/src/assets/images/avatar_manager_priya_1795531789238.jpg',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-mgr-2',
      name: 'Rajeshwari Iyer',
      employeeCode: 'NF-1005',
      email: 'rajeshwari.iyer@novafoods.in',
      role: 'manager',
      department: 'Supply Chain',
      costCentre: 'CC-BLR-201',
      grade: 'G4',
      managerId: 'u-fin-1',
      location: 'Bengaluru',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-mgr-3',
      name: 'Sandeep Joshi',
      employeeCode: 'NF-1006',
      email: 'sandeep.joshi@novafoods.in',
      role: 'manager',
      department: 'Manufacturing',
      costCentre: 'CC-BMT-302',
      grade: 'G5',
      managerId: 'u-fin-1',
      location: 'Baramati',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-mgr-4',
      name: 'Ananya Chatterjee',
      employeeCode: 'NF-1007',
      email: 'ananya.chatterjee@novafoods.in',
      role: 'manager',
      department: 'HR',
      costCentre: 'CC-CHN-401',
      grade: 'G4',
      managerId: 'u-fin-1',
      location: 'Chennai',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-mgr-5',
      name: 'Harishankar Menon',
      employeeCode: 'NF-1008',
      email: 'harishankar.menon@novafoods.in',
      role: 'manager',
      department: 'Sales',
      costCentre: 'CC-DEL-102',
      grade: 'G4',
      managerId: 'u-fin-1',
      location: 'Delhi',
      isActive: true,
      ownerUid,
    },
    // Demo Finance Controller
    {
      id: 'u-fin-1',
      name: 'Vikramaditya Rao',
      employeeCode: 'NF-1001',
      email: 'vikramaditya.rao@novafoods.in',
      role: 'finance',
      department: 'Finance',
      costCentre: 'CC-MUM-101',
      grade: 'G5',
      managerId: '',
      location: 'Mumbai',
      avatarUrl: '/src/assets/images/avatar_finance_vikram_1795531789425.jpg',
      isActive: true,
      ownerUid,
    },
    // Demo Admin
    {
      id: 'u-adm-1',
      name: 'Sneha Kulkarni',
      employeeCode: 'NF-1003',
      email: 'sneha.kulkarni@novafoods.in',
      role: 'admin',
      department: 'HR',
      costCentre: 'CC-PUN-301',
      grade: 'G4',
      managerId: 'u-mgr-4',
      location: 'Pune',
      avatarUrl: '/src/assets/images/avatar_admin_sneha_1795531789983.jpg',
      isActive: true,
      ownerUid,
    },
    // Demo Employee (reports to Priya Nair u-mgr-1)
    {
      id: 'u-emp-1',
      name: 'Aarav Deshmukh',
      employeeCode: 'NF-1004',
      email: 'aarav.deshmukh@novafoods.in',
      role: 'employee',
      department: 'Sales',
      costCentre: 'CC-MUM-101',
      grade: 'G2',
      managerId: 'u-mgr-1',
      location: 'Pune',
      avatarUrl: '/src/assets/images/avatar_employee_aarav_1795531789233.jpg',
      isActive: true,
      ownerUid,
    },
    // 12 More Employees across Sales, Supply Chain, Manufacturing, Finance, HR
    {
      id: 'u-emp-2',
      name: 'Meera Patil',
      employeeCode: 'NF-1009',
      email: 'meera.patil@novafoods.in',
      role: 'employee',
      department: 'Sales',
      costCentre: 'CC-MUM-101',
      grade: 'G3',
      managerId: 'u-mgr-1',
      location: 'Mumbai',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-3',
      name: 'Rohan Malhotra',
      employeeCode: 'NF-1010',
      email: 'rohan.malhotra@novafoods.in',
      role: 'employee',
      department: 'Sales',
      costCentre: 'CC-DEL-102',
      grade: 'G2',
      managerId: 'u-mgr-1',
      location: 'Delhi',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-4',
      name: 'Kavya Subramanian',
      employeeCode: 'NF-1011',
      email: 'kavya.subramanian@novafoods.in',
      role: 'employee',
      department: 'Supply Chain',
      costCentre: 'CC-BLR-201',
      grade: 'G3',
      managerId: 'u-mgr-2',
      location: 'Bengaluru',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-5',
      name: 'Siddharth Verma',
      employeeCode: 'NF-1012',
      email: 'siddharth.verma@novafoods.in',
      role: 'employee',
      department: 'Supply Chain',
      costCentre: 'CC-BLR-201',
      grade: 'G2',
      managerId: 'u-mgr-2',
      location: 'Chennai',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-6',
      name: 'Nandini Gokhale',
      employeeCode: 'NF-1013',
      email: 'nandini.gokhale@novafoods.in',
      role: 'employee',
      department: 'Manufacturing',
      costCentre: 'CC-BMT-302',
      grade: 'G2',
      managerId: 'u-mgr-3',
      location: 'Baramati',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-7',
      name: 'Prashant Bhosale',
      employeeCode: 'NF-1014',
      email: 'prashant.bhosale@novafoods.in',
      role: 'employee',
      department: 'Manufacturing',
      costCentre: 'CC-PUN-301',
      grade: 'G3',
      managerId: 'u-mgr-3',
      location: 'Pune',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-8',
      name: 'Divya Krishnan',
      employeeCode: 'NF-1015',
      email: 'divya.krishnan@novafoods.in',
      role: 'employee',
      department: 'Finance',
      costCentre: 'CC-CHN-401',
      grade: 'G3',
      managerId: 'u-fin-1',
      location: 'Chennai',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-9',
      name: 'Aditya Sharma',
      employeeCode: 'NF-1016',
      email: 'aditya.sharma@novafoods.in',
      role: 'employee',
      department: 'Sales',
      costCentre: 'CC-DEL-102',
      grade: 'G1',
      managerId: 'u-mgr-5',
      location: 'Delhi',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-10',
      name: 'Pooja Sawant',
      employeeCode: 'NF-1017',
      email: 'pooja.sawant@novafoods.in',
      role: 'employee',
      department: 'Manufacturing',
      costCentre: 'CC-BMT-302',
      grade: 'G1',
      managerId: 'u-mgr-3',
      location: 'Baramati',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-11',
      name: 'Karanvir Gill',
      employeeCode: 'NF-1018',
      email: 'karanvir.gill@novafoods.in',
      role: 'employee',
      department: 'Supply Chain',
      costCentre: 'CC-BLR-201',
      grade: 'G2',
      managerId: 'u-mgr-2',
      location: 'Bengaluru',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-12',
      name: 'Shruti Hegde',
      employeeCode: 'NF-1019',
      email: 'shruti.hegde@novafoods.in',
      role: 'employee',
      department: 'HR',
      costCentre: 'CC-CHN-401',
      grade: 'G2',
      managerId: 'u-mgr-4',
      location: 'Mumbai',
      isActive: true,
      ownerUid,
    },
    {
      id: 'u-emp-13',
      name: 'Tanmay Kulkarni',
      employeeCode: 'NF-1020',
      email: 'tanmay.kulkarni@novafoods.in',
      role: 'employee',
      department: 'Sales',
      costCentre: 'CC-MUM-101',
      grade: 'G2',
      managerId: 'u-mgr-1',
      location: 'Pune',
      isActive: true,
      ownerUid,
    },
  ];
}

export function buildSeedPolicies(ownerUid = DEMO_OWNER_UID): ExpensePolicy[] {
  const grades: Grade[] = ['G1', 'G2', 'G3', 'G4', 'G5'];
  const baseCaps: Record<string, { day: number; unit: number; receipt: boolean; preApproval: boolean; gst: boolean; notes: string }> = {
    Airfare: { day: 0, unit: 8500, receipt: true, preApproval: false, gst: true, notes: 'Economy class domestic sectors; GSTIN invoice mandatory' },
    'Train/Bus': { day: 0, unit: 3200, receipt: true, preApproval: false, gst: true, notes: 'AC 2-Tier / Chair Car or Volvo Intercity' },
    'Local Conveyance': { day: 1200, unit: 1200, receipt: true, preApproval: false, gst: true, notes: 'App cabs (Uber/Ola) or auto-rickshaw within city limits' },
    'Fuel/Mileage': { day: 1500, unit: 1500, receipt: true, preApproval: false, gst: false, notes: '₹12/km car or ₹5/km two-wheeler for field visits' },
    'Hotel Accommodation': { day: 4500, unit: 4500, receipt: true, preApproval: false, gst: true, notes: 'Standard business hotel room + breakfast' },
    Meals: { day: 1100, unit: 900, receipt: true, preApproval: false, gst: true, notes: 'Daily meal allowance during outstation travel' },
    'Client Entertainment': { day: 3500, unit: 3500, receipt: true, preApproval: true, gst: true, notes: 'Requires manager pre-approval & attendee list' },
    'Telephone/Internet': { day: 0, unit: 1500, receipt: true, preApproval: false, gst: true, notes: 'Monthly field mobile & data reimbursement cap' },
    'Training & Conference': { day: 0, unit: 12000, receipt: true, preApproval: true, gst: true, notes: 'External FMCG/supply-chain workshops' },
    Miscellaneous: { day: 1000, unit: 1000, receipt: true, preApproval: false, gst: false, notes: 'Courier, toll, stationery, sample shipping' },
  };

  const policies: ExpensePolicy[] = [];
  let idx = 1;

  for (const cat of EXPENSE_CATEGORIES) {
    const base = baseCaps[cat];
    for (const grade of grades) {
      const mult = grade === 'G1' ? 0.8 : grade === 'G2' ? 1 : grade === 'G3' ? 1.25 : grade === 'G4' ? 1.55 : 2.0;
      if (cat === 'Hotel Accommodation' || cat === 'Meals') {
        policies.push({
          id: `pol-${idx++}`,
          category: cat,
          grade,
          limitPerDay: Math.round(base.day * mult * 1.25),
          limitPerUnit: Math.round(base.unit * mult * 1.25),
          cityTier: 'Tier 1',
          requiresReceipt: base.receipt,
          requiresPreApproval: base.preApproval,
          gstEligible: base.gst,
          notes: `${base.notes} (Tier 1 Metro: Mumbai, Delhi, Bengaluru, Chennai)`,
          ownerUid,
        });
        policies.push({
          id: `pol-${idx++}`,
          category: cat,
          grade,
          limitPerDay: Math.round(base.day * mult),
          limitPerUnit: Math.round(base.unit * mult),
          cityTier: 'Tier 2',
          requiresReceipt: base.receipt,
          requiresPreApproval: base.preApproval,
          gstEligible: base.gst,
          notes: `${base.notes} (Tier 2: Pune, Baramati)`,
          ownerUid,
        });
      } else {
        policies.push({
          id: `pol-${idx++}`,
          category: cat,
          grade,
          limitPerDay: Math.round(base.day * mult),
          limitPerUnit: Math.round(base.unit * mult),
          cityTier: 'All',
          requiresReceipt: base.receipt,
          requiresPreApproval: base.preApproval,
          gstEligible: base.gst,
          notes: base.notes,
          ownerUid,
        });
      }
    }
  }
  return policies;
}

const MERCHANTS_BY_CATEGORY: Record<string, { name: string; gstin: string }[]> = {
  Airfare: [
    { name: 'IndiGo Airlines', gstin: '07AAACI1681G1Z2' },
    { name: 'Air India Domestic', gstin: '27AAACA8293L1Z9' },
    { name: 'Akasa Air', gstin: '27AAKCS4312D1Z4' },
  ],
  'Train/Bus': [
    { name: 'IRCTC Vande Bharat Express', gstin: '07AAACI0001A1Z1' },
    { name: 'MSRTC Shivneri Volvo', gstin: '27AAACM9123B1Z7' },
  ],
  'Local Conveyance': [
    { name: 'Uber India Systems', gstin: '27AAACU4521K1Z8' },
    { name: 'Ola Cabs Business', gstin: '29AAACO6712M1Z3' },
  ],
  'Fuel/Mileage': [
    { name: 'IndianOil Corp Station', gstin: '27AAACI1681E1Z0' },
    { name: 'HPCL Highway Fuel', gstin: '27AAACH8812N1Z6' },
  ],
  'Hotel Accommodation': [
    { name: 'Orchid Elite Hotels', gstin: '36AAAAO1234A1ZM' },
    { name: 'Lemon Tree Premier', gstin: '27AAACL2311H1Z5' },
    { name: 'Ginger Hotels Business', gstin: '29AAACG9981B1Z2' },
  ],
  Meals: [
    { name: 'Zomato Corporate Dining', gstin: '07AAACZ3421L1Z8' },
    { name: 'Vaishali Restaurant Pune', gstin: '27AABCV1192D1Z4' },
    { name: 'MTR Bengaluru Express', gstin: '29AABCM7721E1Z1' },
  ],
  'Client Entertainment': [
    { name: 'Mainland China Hospitality', gstin: '27AAACM3312F1Z9' },
    { name: 'Taj Vivanta Business Lounge', gstin: '27AAACT5541G1Z2' },
  ],
  'Telephone/Internet': [
    { name: 'Bharti Airtel Postpaid', gstin: '07AAACB2894G1Z7' },
    { name: 'JioFiber Enterprise', gstin: '27AAACJ8831M1Z5' },
  ],
  'Training & Conference': [
    { name: 'CII FMCG Supply Summit', gstin: '07AAACC4412N1Z3' },
    { name: 'NIFTEM Food Quality Forum', gstin: '06AAACN2219B1Z8' },
  ],
  Miscellaneous: [
    { name: 'BlueDart Express Courier', gstin: '27AAACB0441F1Z1' },
    { name: 'FASTag Highway Toll', gstin: '' },
  ],
};

const PURPOSES = [
  'Retail distributor quarterly audit & shelf-space review',
  'Baramati dairy plant cold-chain cold storage inspection',
  'Modern trade key account JBP meeting',
  'Pune packaging line FSSAI quality audit travel',
  'Regional distributor onboarding & scheme rollout',
  'Supply chain vendor negotiation & warehouse visit',
  'National FMCG Logistics & Cold-Chain Conference',
  'New snack SKU regional launch sampling drive',
  'Annual statutory GST & plant inventory reconciliation',
  'Campus hiring & plant safety training workshop',
];

const PAYMENT_MODES: PaymentMode[] = [
  'Corporate Card',
  'Personal UPI',
  'Personal Card',
  'NetBanking',
  'Cash',
];

export function buildSeedData(ownerUid = DEMO_OWNER_UID): {
  departments: Department[];
  costCentres: CostCentre[];
  users: UserProfile[];
  policies: ExpensePolicy[];
  claims: ExpenseClaim[];
  auditTrail: AuditEntry[];
} {
  const departments = buildSeedDepartments(ownerUid);
  const costCentres = buildSeedCostCentres(ownerUid);
  const users = buildSeedUsers(ownerUid);
  const policies = buildSeedPolicies(ownerUid);

  const employees = users.filter((u) => u.role === 'employee' || u.role === 'manager');

  const statusCycle: ClaimStatus[] = [
    'Paid',
    'Paid',
    'Paid',
    'Finance Verified',
    'Manager Approved',
    'Submitted',
    'Submitted',
    'Sent Back',
    'Rejected',
    'Draft',
  ];

  // Build 60 claims across Jun 2026 - Nov 2026
  const claims: ExpenseClaim[] = [];
  const auditTrail: AuditEntry[] = [];

  for (let i = 1; i <= 60; i++) {
    const claimId = `claim-${String(i).padStart(3, '0')}`;
    const claimNo = `EXP-2026-${String(i).padStart(4, '0')}`;

    // Make sure Aarav Deshmukh (u-emp-1) gets ~10 claims across all statuses
    let emp: UserProfile;
    if (i <= 10) {
      emp = users.find((u) => u.id === 'u-emp-1')!;
    } else if (i <= 20) {
      // Priya Nair's other reportees (u-emp-2, u-emp-3, u-emp-13) so Manager Inbox has rich items
      const priyaReportees = ['u-emp-2', 'u-emp-3', 'u-emp-13'];
      emp = users.find((u) => u.id === priyaReportees[i % priyaReportees.length])!;
    } else {
      emp = employees[(i * 7) % employees.length];
    }

    const cityObj = INDIAN_CITIES[(i * 3) % INDIAN_CITIES.length];
    // Month spread: Jun (06) to Nov (11) 2026, increasing recency for higher claim numbers
    const monthNum = 6 + Math.min(5, Math.floor((i - 1) / 10));
    let dayStart = 2 + ((i * 3) % 22);
    const mm = String(monthNum).padStart(2, '0');
    // Shift non-weekend-test claims off weekends/holidays so compliant claims stay compliant
    if (i !== 14 && i !== 27) {
      let guard = 0;
      while (
        checkWeekendOrHoliday(`2026-${mm}-${String(dayStart).padStart(2, '0')}`).isWeekendOrHoliday &&
        guard < 4
      ) {
        dayStart = (dayStart % 25) + 1;
        guard++;
      }
    }
    const dayEnd = Math.min(28, dayStart + (i % 3));
    const tripFromDate =
      i === 55 ? '2026-11-02' : `2026-${mm}-${String(dayStart).padStart(2, '0')}`;
    const tripToDate =
      i === 55 ? '2026-11-04' : `2026-${mm}-${String(dayEnd).padStart(2, '0')}`;

    let status: ClaimStatus = statusCycle[(i - 1) % statusCycle.length];
    // Guarantee key presentation scenarios on specific claims:
    if (i === 1) status = 'Paid';
    if (i === 2) status = 'Finance Verified';
    if (i === 3) status = 'Manager Approved';
    if (i === 4) status = 'Submitted';
    if (i === 5) status = 'Sent Back';
    if (i === 6) status = 'Draft';
    if (i === 7) status = 'Rejected';
    if (i >= 11 && i <= 15) status = 'Submitted'; // Direct reportees for Priya's Manager Inbox!
    if (i === 3 || i === 33 || i === 49 || i === 54 || i === 58) status = 'Manager Approved'; // Finance Queue showcase (exceptions, duplicates, split bills, round numbers)

    const lineCount = i === 58 ? 3 : (i % 3) + 2; // 2 to 4 lines per claim
    const lines: ExpenseLine[] = [];

    for (let l = 0; l < lineCount; l++) {
      let cat = EXPENSE_CATEGORIES[(i * 3 + l * 2) % EXPENSE_CATEGORIES.length];
      // Force deterministic demo categories on showcase claims
      if ((i === 11 || i === 14) && l === 0) cat = 'Hotel Accommodation';
      if (i === 58 && (l === 0 || l === 1)) cat = 'Meals';
      if (i === 58 && l === 2) cat = 'Hotel Accommodation';
      if ((i === 1 || i === 2 || i === 3 || i === 8) && l === 1) cat = 'Local Conveyance';

      const merchantList = MERCHANTS_BY_CATEGORY[cat] || MERCHANTS_BY_CATEGORY.Miscellaneous;
      const merchantObj = merchantList[(i + l) % merchantList.length];

      const matchedPol = findMatchingPolicy(cat, emp.grade, cityObj.tier, policies);
      const polCap = matchedPol ? (matchedPol.limitPerUnit > 0 ? matchedPol.limitPerUnit : matchedPol.limitPerDay) : 2000;
      const pctFactor = 0.66 + (((i * 13 + l * 7) % 19) / 100); // 66%..84% of permissible cap
      let baseAmount = Math.max(250, Math.round(polCap * pctFactor));
      if (baseAmount % 500 === 0) baseAmount += 45; // Avoid accidental round numbers on compliant baselines

      // Inject intentional policy exceptions on specific claims (cap exceeded, weekend, outside trip dates, missing pre-approval)
      let policyFlag: ExpenseLine['policyFlag'] = 'Compliant';
      let policyFlagReason = '';
      if ((i === 12 || i === 24 || i === 33 || i === 44 || i === 52) && l === 0) {
        baseAmount = i === 33 ? 7000 : Math.round(polCap * 1.42);
        policyFlag = 'Violation';
        policyFlagReason = `Exceeds ${emp.grade} ${cityObj.tier} cap of ${polCap} for ${cat}`;
      }

      let invoiceNo = `INV-${2026}${mm}-${String(i * 10 + l).padStart(4, '0')}`;
      let merchantName = merchantObj.name;
      let lineDate = tripFromDate;

      // Threshold-hugging showcase for Aarav Deshmukh (u-emp-1) on Local Conveyance (cap ₹1,200): 94%-96% of cap
      if ((i === 1 || i === 2 || i === 3 || i === 8) && l === 1) {
        baseAmount = Math.round(polCap * (0.93 + (i % 3) * 0.02));
      }

      // Fuzzy Same-Employee Duplicate showcase: Claim 14 duplicates Claim 11 (same employee u-emp-13, same merchant, similar amount, ±1 day, different invoiceNo)
      if (i === 11 && l === 0) {
        merchantName = 'Lemon Tree Premier';
        baseAmount = 3420;
        lineDate = '2026-07-07';
        invoiceNo = 'INV-202607-0110';
      }
      if (i === 14 && l === 0) {
        merchantName = 'Lemon Tree Premier';
        baseAmount = 3460;
        lineDate = '2026-07-08';
        invoiceNo = 'INV-202607-9914';
      }

      // Split-Bill + Round-Number ₹0 GST showcase on Claim 58 (Manager Approved in Finance Queue)
      if (i === 58 && l === 0) {
        merchantName = 'Vaishali Restaurant Pune';
        baseAmount = 850;
        invoiceNo = 'INV-202611-5801';
      }
      if (i === 58 && l === 1) {
        merchantName = 'Vaishali Restaurant Pune';
        baseAmount = 750;
        invoiceNo = 'INV-202611-5802';
      }
      if (i === 58 && l === 2) {
        merchantName = 'Orchid Elite Hotels';
        baseAmount = 5000;
        invoiceNo = 'INV-202611-5803';
      }

      // Intentional outside-trip-date exception on claim 15 line 1
      if (i === 15 && l === 1) {
        const preDay = Math.max(1, dayStart - 3);
        lineDate = `2026-${mm}-${String(preDay).padStart(2, '0')}`;
      }

      const requiresPreApprovalCat =
        cat === 'Client Entertainment' || cat === 'Training & Conference';
      // Attach preApprovalRef on compliant claims; omit on claim 13 / 35 for intentional missing pre-approval exception
      const preApprovalRef =
        requiresPreApprovalCat && i !== 13 && i !== 35
          ? `PA-2026-${String(100 + i).padStart(4, '0')}`
          : '';

      // Explicit Duplicate #1: Claim 49 duplicates Claim 41 line 0
      if (i === 49 && l === 0) {
        invoiceNo = 'INV-202610-0410';
        merchantName = 'Orchid Elite Hotels';
        baseAmount = 5420;
        lineDate = '2026-10-05';
        policyFlag = 'Violation';
        policyFlagReason = 'Potential duplicate invoice detected (matches EXP-2026-0041)';
      }
      if (i === 41 && l === 0) {
        invoiceNo = 'INV-202610-0410';
        merchantName = 'Orchid Elite Hotels';
        baseAmount = 5420;
        lineDate = '2026-10-05';
      }

      // Explicit Duplicate #2: Claim 54 duplicates Claim 36 line 0
      if (i === 54 && l === 0) {
        invoiceNo = 'INV-202609-0360';
        merchantName = 'IndiGo Airlines';
        baseAmount = 7080;
        lineDate = '2026-09-12';
        policyFlag = 'Violation';
        policyFlagReason = 'Potential duplicate ticket PNR/invoice (matches EXP-2026-0036)';
      }
      if (i === 36 && l === 0) {
        invoiceNo = 'INV-202609-0360';
        merchantName = 'IndiGo Airlines';
        baseAmount = 7080;
        lineDate = '2026-09-12';
      }

      const gstRate =
        i === 58 && l === 2
          ? 0
          : merchantObj.gstin
            ? cat === 'Hotel Accommodation' || cat === 'Airfare'
              ? 0.12
              : 0.05
            : 0;
      const gstAmount = Math.round(baseAmount * gstRate);

      let receiptUrl = '';
      let receiptName = `receipt_${claimNo}_${l + 1}.jpg`;
      let receiptMimeType = 'image/jpeg';

      if (cat === 'Hotel Accommodation' || i === 49 || i === 41) {
        receiptUrl = SAMPLE_RECEIPT_HOTEL;
        receiptName = `hotel_tax_invoice_${invoiceNo}.jpg`;
      } else if (cat === 'Airfare' || i === 54 || i === 36) {
        receiptUrl = SAMPLE_RECEIPT_FLIGHT;
        receiptName = `indigo_gst_eticket_${invoiceNo}.jpg`;
      } else if (i % 7 === 0 && l === 1 && i !== 14) {
        // One missing receipt policy violation example
        receiptName = '';
        receiptUrl = '';
        receiptMimeType = '';
        policyFlag = 'Violation';
        policyFlagReason = `Receipt mandatory for ${cat}`;
      } else {
        receiptUrl = l % 2 === 0 ? SAMPLE_RECEIPT_HOTEL : SAMPLE_RECEIPT_FLIGHT;
      }

      lines.push({
        id: `${claimId}-line-${l + 1}`,
        claimId,
        date: lineDate,
        category: cat,
        merchant: merchantName,
        amount: baseAmount,
        gstAmount,
        gstin: merchantObj.gstin,
        invoiceNo,
        paymentMode: PAYMENT_MODES[(i + l) % PAYMENT_MODES.length],
        receiptName,
        receiptMimeType,
        receiptUrl,
        preApprovalRef,
        aiConfidenceScore: receiptUrl ? 92 + ((i + l) % 7) : 0,
        policyFlag,
        policyFlagReason,
        justification:
          policyFlag === 'Violation'
            ? 'Urgent plant/customer escalation travel; surge pricing applied.'
            : 'Official Nova Foods field & operations business travel.',
        ownerUid,
      });
    }

    // Evaluate deterministically against expense_policies so seed claims match the Policy Compliance Engine
    const evalSummary = evaluateClaimCompliance(
      { tripFromDate, tripToDate, employeeId: emp.id, lines },
      emp.grade,
      cityObj.tier,
      policies,
      claims,
      claimId
    );
    const finalizedLines: ExpenseLine[] = lines.map((line, lIdx) => {
      const ev = evalSummary.lineEvaluations[lIdx];
      return {
        ...line,
        policyFlag: ev.flag,
        policyFlagReason: ev.reason.slice(0, 390),
        policyPermissibleLimit: ev.permissibleLimit,
        policyExcessAmount: ev.excessAmount,
        policyExceptionCodes: ev.exceptionCodes,
        aiPolicyRecommendation: ev.aiRecommendation.slice(0, 390),
        justification: ev.hasException
          ? 'Urgent plant/customer escalation travel; exception approval requested.'
          : line.justification,
      };
    });

    const totalAmount = finalizedLines.reduce((sum, x) => sum + x.amount, 0);
    const totalGstAmount = finalizedLines.reduce((sum, x) => sum + x.gstAmount, 0);
    const hasPolicyViolation = evalSummary.hasExceptions;
    const isDuplicateFlagged = i === 49 || i === 54 || Boolean(evalSummary.duplicateClaimNo);
    const duplicateRefClaimNo =
      i === 49 ? 'EXP-2026-0041' : i === 54 ? 'EXP-2026-0036' : evalSummary.duplicateClaimNo;

    const manager = users.find((u) => u.id === emp.managerId) || users[0];
    const submittedDate = status === 'Draft' ? '' : tripToDate;

    const shiftTimestamp = (baseIsoDate: string, addDays: number, hh: string): string => {
      const [y, m, d] = baseIsoDate.split('-').map(Number);
      const dt = new Date(Date.UTC(y, m - 1, d + addDays));
      return `${dt.toISOString().slice(0, 10)}T${hh}:00.000Z`;
    };

    const approvalHistory: ApprovalLog[] = [
      {
        id: `${claimId}-log-1`,
        claimId,
        claimNo,
        action: 'Created',
        byUserId: emp.id,
        byName: emp.name,
        byRole: emp.role,
        comments: 'Claim initiated with itemized bills.',
        timestamp: `${tripFromDate}T10:15:00.000Z`,
        ownerUid,
      },
    ];

    if (status !== 'Draft') {
      approvalHistory.push({
        id: `${claimId}-log-2`,
        claimId,
        claimNo,
        action: 'Submitted',
        byUserId: emp.id,
        byName: emp.name,
        byRole: emp.role,
        comments: 'Submitted for reporting manager review.',
        timestamp: `${tripToDate}T11:30:00.000Z`,
        ownerUid,
      });
    }

    if (['Manager Approved', 'Finance Verified', 'Paid'].includes(status)) {
      approvalHistory.push({
        id: `${claimId}-log-3`,
        claimId,
        claimNo,
        action: 'Manager Approved',
        byUserId: manager.id,
        byName: manager.name,
        byRole: 'manager',
        comments: 'Verified visit schedule and approved for Finance check.',
        timestamp: shiftTimestamp(tripToDate, 1, '15:20'),
        ownerUid,
      });
    } else if (status === 'Rejected') {
      approvalHistory.push({
        id: `${claimId}-log-3`,
        claimId,
        claimNo,
        action: 'Rejected',
        byUserId: manager.id,
        byName: manager.name,
        byRole: 'manager',
        comments: 'Outstation stay not pre-authorized for this territory visit.',
        timestamp: shiftTimestamp(tripToDate, 1, '18:20'),
        ownerUid,
      });
    } else if (status === 'Sent Back') {
      approvalHistory.push({
        id: `${claimId}-log-3`,
        claimId,
        claimNo,
        action: 'Manager Approved',
        byUserId: manager.id,
        byName: manager.name,
        byRole: 'manager',
        comments: 'Approved pending GST invoice confirmation.',
        timestamp: shiftTimestamp(tripToDate, 1, '14:10'),
        ownerUid,
      });
      approvalHistory.push({
        id: `${claimId}-log-4`,
        claimId,
        claimNo,
        action: 'Sent Back',
        byUserId: 'u-fin-1',
        byName: 'Vikramaditya Rao',
        byRole: 'finance',
        comments: 'Please attach itemized tax invoice with Nova Foods GSTIN.',
        timestamp: shiftTimestamp(tripToDate, 2, '17:05'),
        ownerUid,
      });
    }

    if (['Finance Verified', 'Paid'].includes(status)) {
      approvalHistory.push({
        id: `${claimId}-log-4`,
        claimId,
        claimNo,
        action: 'Finance Verified',
        byUserId: 'u-fin-1',
        byName: 'Vikramaditya Rao',
        byRole: 'finance',
        comments: 'GST credit verified and queued for NEFT payout batch.',
        timestamp: shiftTimestamp(tripToDate, 2 + (i % 2), '16:30'),
        ownerUid,
      });
    }

    if (status === 'Paid') {
      approvalHistory.push({
        id: `${claimId}-log-5`,
        claimId,
        claimNo,
        action: 'Paid',
        byUserId: 'u-fin-1',
        byName: 'Vikramaditya Rao',
        byRole: 'finance',
        comments: `Settled via HDFC NEFT UTR NF26${String(i).padStart(6, '0')}.`,
        timestamp: shiftTimestamp(tripToDate, 3 + (i % 2), '19:00'),
        ownerUid,
      });
    }

    claims.push({
      id: claimId,
      claimNo,
      employeeId: emp.id,
      employeeName: emp.name,
      employeeCode: emp.employeeCode,
      department: emp.department,
      costCentre: emp.costCentre,
      grade: emp.grade,
      managerId: emp.managerId || 'u-mgr-1',
      purpose: PURPOSES[(i - 1) % PURPOSES.length],
      destination: cityObj.name,
      cityTier: cityObj.tier,
      tripFromDate,
      tripToDate,
      totalAmount,
      totalGstAmount,
      lineCount: finalizedLines.length,
      status,
      submittedDate,
      hasPolicyViolation,
      isDuplicateFlagged,
      duplicateRefClaimNo,
      complianceScore: evalSummary.complianceScore,
      ownerUid,
      createdAt: `${tripFromDate}T10:15:00.000Z`,
      updatedAt: `${tripToDate}T21:00:00.000Z`,
      lines: finalizedLines,
      approvalHistory,
    });

    if (i >= 48) {
      const latest = approvalHistory[approvalHistory.length - 1];
      auditTrail.push({
        id: `audit-seed-${i}`,
        entityType: 'Claim',
        entityId: claimId,
        claimNo,
        action: latest.action,
        actorId: latest.byUserId,
        actorName: latest.byName,
        actorRole: latest.byRole,
        details: `${claimNo} (${emp.name}) transitioned to ${status} · ${latest.comments}`,
        timestamp: latest.timestamp,
        ownerUid,
      });
    }
  }

  return {
    departments,
    costCentres,
    users,
    policies,
    claims: claims.reverse(), // Latest claims first
    auditTrail: auditTrail.reverse(),
  };
}
