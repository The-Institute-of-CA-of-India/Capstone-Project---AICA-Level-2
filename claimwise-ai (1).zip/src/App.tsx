/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AdminView } from './components/AdminView';
import { ClaimDetailView } from './components/ClaimDetailView';
import { ClaimFormView } from './components/ClaimFormView';
import { DashboardView } from './components/DashboardView';
import { ErrorBoundary } from './components/ErrorBoundary';
import { FinanceAnalyticsView } from './components/FinanceAnalyticsView';
import { FinanceQueueView } from './components/FinanceQueueView';
import { HowAiWorksView } from './components/HowAiWorksView';
import { Layout } from './components/Layout';
import { LoginScreen } from './components/LoginScreen';
import { ManagerInboxView } from './components/ManagerInboxView';
import { MyClaimsView } from './components/MyClaimsView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { AppProvider, useApp } from './context/AppContext';

const MainRouter: React.FC = () => {
  const { currentUser, activeScreen } = useApp();

  if (!currentUser) {
    return <LoginScreen />;
  }

  return (
    <Layout>
      {activeScreen === 'dashboard' && <DashboardView />}
      {activeScreen === 'new-claim' && <ClaimFormView />}
      {activeScreen === 'my-claims' && <MyClaimsView />}
      {activeScreen === 'claim-detail' && <ClaimDetailView />}
      {activeScreen === 'manager-inbox' &&
        (currentUser.role === 'manager' || currentUser.role === 'admin' ? (
          <ManagerInboxView />
        ) : (
          <DashboardView />
        ))}
      {activeScreen === 'finance-queue' &&
        (currentUser.role === 'finance' || currentUser.role === 'admin' ? (
          <FinanceQueueView />
        ) : (
          <DashboardView />
        ))}
      {activeScreen === 'finance-analytics' &&
        (currentUser.role === 'finance' || currentUser.role === 'admin' ? (
          <FinanceAnalyticsView />
        ) : (
          <DashboardView />
        ))}
      {activeScreen === 'admin' &&
        (currentUser.role === 'admin' ? <AdminView /> : <DashboardView />)}
      {activeScreen === 'how-ai-works' && <HowAiWorksView />}
    </Layout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <MainRouter />
        <OfflineIndicator />
      </AppProvider>
    </ErrorBoundary>
  );
}
