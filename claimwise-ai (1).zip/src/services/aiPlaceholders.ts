/**
 * ClaimWise AI — Gemini AI Services
 *
 * Receipt OCR & Intelligent Document Processing calls server-side `/api/ai/extract-receipt`
 * powered by `@google/genai` (`gemini-4-hydrogen`).
 * Policy explanations and Finance insights remain lightweight placeholders for the next phase.
 */

import {
  AiAnalyticsInsightsResult,
  AiAssistantResponse,
  AiFieldConfidences,
  AiFinanceReviewResult,
  AiPreSubmissionCheckResult,
  ClaimComplianceSummary,
  ClaimRiskAnalysis,
  ExpenseCategory,
  ExpenseClaim,
  ExpenseLine,
  PaymentMode,
} from '../types/claimwise';
import { AssistantGroundedPayload } from '../utils/assistantContext';

export interface AiReceiptExtractionResult {
  merchant: string;
  date: string;
  invoiceNo: string;
  totalAmount: number;
  gstAmount: number;
  gstin: string;
  currency: string;
  paymentMode: PaymentMode;
  suggestedCategory: ExpenseCategory;
  categoryReason: string;
  fieldConfidence: AiFieldConfidences;
  validationWarnings: string[];
}

export interface AiPolicyExplanationResult {
  summary: string;
  recommendation: string;
  gstEligibilityNote: string;
  status: 'placeholder';
}

export interface AiFinanceInsightsResult {
  headline: string;
  bulletFindings: string[];
  anomalyCount: number;
  status: 'placeholder';
}

/**
 * Calls server-side Gemini AI Intelligent Document Processing endpoint to extract
 * structured receipt fields, category suggestion + reason, and per-field confidence scores.
 */
export async function extractReceiptWithAI(
  dataUrl: string,
  mimeType: string,
  fileName: string
): Promise<AiReceiptExtractionResult> {
  const response = await fetch('/api/ai/extract-receipt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ dataUrl, mimeType, fileName }),
  });

  const text = await response.text();
  let payload: Record<string, unknown> = {};
  try {
    payload = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    payload = { error: text || `AI receipt extraction failed (${response.status}).` };
  }
  if (!response.ok) {
    throw new Error(
      typeof payload.error === 'string' && payload.error.trim()
        ? payload.error
        : `AI receipt extraction failed (${response.status}).`
    );
  }
  return payload as unknown as AiReceiptExtractionResult;
}

export async function runAiComplianceCheck(params: {
  claimHeader: {
    claimNo?: string;
    employeeName: string;
    grade: string;
    department: string;
    destination: string;
    cityTier: string;
    tripFromDate: string;
    tripToDate: string;
    purpose: string;
    totalAmount: number;
    totalGstAmount: number;
  };
  lines: {
    lineNumber: number;
    date: string;
    category: string;
    merchant: string;
    amount: number;
    gstAmount: number;
    gstin: string;
    hasReceipt: boolean;
    preApprovalRef?: string;
    justification: string;
  }[];
  summary: ClaimComplianceSummary;
}): Promise<AiPreSubmissionCheckResult> {
  const response = await fetch('/api/ai/compliance-check', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      claimHeader: params.claimHeader,
      lines: params.lines.map((l, idx) => {
        const ev = params.summary.lineEvaluations[idx];
        return {
          ...l,
          permissibleLimit: ev?.permissibleLimit ?? 0,
          excessAmount: ev?.excessAmount ?? 0,
          hasException: ev?.hasException ?? false,
          issues: ev?.issues ?? [],
        };
      }),
      deterministicSummary: {
        complianceScore: params.summary.complianceScore,
        exceptionCount: params.summary.exceptionCount,
        warningCount: params.summary.warningCount,
        duplicateClaimNo: params.summary.duplicateClaimNo,
      },
    }),
  });

  const text = await response.text();
  let payload: Record<string, unknown> = {};
  try {
    payload = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    payload = { error: text || `AI compliance check failed (${response.status}).` };
  }
  if (!response.ok) {
    throw new Error(
      typeof payload.error === 'string' && payload.error.trim()
        ? payload.error
        : `AI compliance check failed (${response.status}).`
    );
  }
  return payload as unknown as AiPreSubmissionCheckResult;
}

export async function runAiFinanceReviewAgent(params: {
  claim: ExpenseClaim;
  compliance: ClaimComplianceSummary;
  riskAnalysis: ClaimRiskAnalysis;
}): Promise<AiFinanceReviewResult> {
  const { claim, compliance, riskAnalysis } = params;
  const response = await fetch('/api/ai/finance-review-agent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      claimHeader: {
        claimNo: claim.claimNo,
        employeeName: claim.employeeName,
        employeeCode: claim.employeeCode,
        grade: claim.grade,
        department: claim.department,
        costCentre: claim.costCentre,
        destination: claim.destination,
        cityTier: claim.cityTier,
        tripFromDate: claim.tripFromDate,
        tripToDate: claim.tripToDate,
        purpose: claim.purpose,
        totalAmount: claim.totalAmount,
        totalGstAmount: claim.totalGstAmount,
        status: claim.status,
      },
      lines: claim.lines.map((l, idx) => {
        const ev = compliance.lineEvaluations[idx];
        return {
          lineNumber: idx + 1,
          date: l.date,
          category: l.category,
          merchant: l.merchant,
          amount: l.amount,
          gstAmount: l.gstAmount,
          gstin: l.gstin,
          invoiceNo: l.invoiceNo,
          hasReceipt: Boolean(l.receiptName || l.receiptUrl),
          preApprovalRef: l.preApprovalRef || '',
          justification: l.justification,
          aiExtracted: Boolean(l.aiExtracted),
          aiConfidenceScore: l.aiConfidenceScore,
          userOverrideCount: l.aiUserOverrides?.length || 0,
          permissibleLimit: ev?.permissibleLimit ?? 0,
          excessAmount: ev?.excessAmount ?? 0,
          hasException: ev?.hasException ?? false,
          policyIssues: ev?.issues.map((i) => `${i.title}: ${i.summary}`) ?? [],
        };
      }),
      policyCompliance: {
        complianceScore: compliance.complianceScore,
        hasExceptions: compliance.hasExceptions,
        exceptionCount: compliance.exceptionCount,
        warningCount: compliance.warningCount,
        duplicateClaimNo: compliance.duplicateClaimNo,
      },
      riskAnalysis: {
        riskLevel: riskAnalysis.riskLevel,
        riskScore: riskAnalysis.riskScore,
        duplicates: riskAnalysis.duplicates.map((d) => ({
          lineNumber: d.lineNumber,
          matchedClaimNo: d.matchedClaimNo,
          matchType: d.matchType,
          similarityScore: d.similarityScore,
          reason: d.reason,
        })),
        anomalies: riskAnalysis.anomalies.map((a) => ({
          code: a.code,
          severity: a.severity,
          lineNumber: a.lineNumber,
          category: a.category,
          title: a.title,
          reason: a.reason,
          metrics: a.metrics,
        })),
        plainEnglishReasons: riskAnalysis.plainEnglishReasons,
      },
    }),
  });

  const text = await response.text();
  let payload: Record<string, unknown> = {};
  try {
    payload = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    payload = { error: text || `AI Review Agent failed (${response.status}).` };
  }
  if (!response.ok) {
    throw new Error(
      typeof payload.error === 'string' && payload.error.trim()
        ? payload.error
        : `AI Review Agent failed (${response.status}).`
    );
  }
  return payload as unknown as AiFinanceReviewResult;
}

export async function runAiAnalyticsInsights(params: {
  filtersSummary: Record<string, unknown>;
  analyticsSnapshot: Record<string, unknown>;
}): Promise<AiAnalyticsInsightsResult> {
  const response = await fetch('/api/ai/analytics-insights', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const text = await response.text();
  let payload: Record<string, unknown> = {};
  try {
    payload = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    payload = { error: text || `AI Insights failed (${response.status}).` };
  }
  if (!response.ok) {
    throw new Error(
      typeof payload.error === 'string' && payload.error.trim()
        ? payload.error
        : `AI Insights failed (${response.status}).`
    );
  }
  return payload as unknown as AiAnalyticsInsightsResult;
}

export async function askClaimWiseAssistant(params: {
  question: string;
  history: { role: 'user' | 'assistant'; content: string }[];
  groundedContext: AssistantGroundedPayload;
}): Promise<AiAssistantResponse> {
  const response = await fetch('/api/ai/assistant', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const text = await response.text();
  let payload: Record<string, unknown> = {};
  try {
    payload = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    payload = { error: text || `ClaimWise Assistant failed (${response.status}).` };
  }
  if (!response.ok) {
    throw new Error(
      typeof payload.error === 'string' && payload.error.trim()
        ? payload.error
        : `ClaimWise Assistant failed (${response.status}).`
    );
  }
  return payload as unknown as AiAssistantResponse;
}

export function getPolicyExplanationPlaceholder(claim: ExpenseClaim): AiPolicyExplanationResult {
  const flaggedLines = claim.lines.filter((l) => l.policyFlag !== 'Compliant');
  return {
    summary: claim.isDuplicateFlagged
      ? `Duplicate pattern detected referencing ${claim.duplicateRefClaimNo}. Gemini Audit comparison flags overlapping invoice metadata.`
      : flaggedLines.length > 0
        ? `${flaggedLines.length} expense line(s) require compliance review under Nova Foods ${claim.grade} ${claim.cityTier} guidelines.`
        : `All ${claim.lines.length} expense line(s) align with Nova Foods ${claim.grade} ${claim.cityTier} policy thresholds.`,
    recommendation:
      flaggedLines.length > 0
        ? 'Click "Run AI Compliance Review" above for a line-by-line Gemini explanation and suggested fixes grounded in corporate expense_policies.'
        : 'All deterministic policy checks passed. Ready for approval or settlement.',
    gstEligibilityNote:
      claim.totalGstAmount > 0
        ? 'GST input tax credit eligibility is computed from attached tax invoices.'
        : 'No GST amount recorded; verify if vendor is GST-registered.',
    status: 'placeholder',
  };
}

export function getFinanceInsightsPlaceholder(claims: ExpenseClaim[]): AiFinanceInsightsResult {
  const violations = claims.filter((c) => c.hasPolicyViolation).length;
  const duplicates = claims.filter((c) => c.isDuplicateFlagged).length;
  return {
    headline: 'AI Spend & Compliance Intelligence',
    bulletFindings: [
      `${violations} claims currently carry grade/tier policy flags across tracked submissions.`,
      `${duplicates} potential duplicate invoice claims flagged for Finance pre-payout verification.`,
      'Open Finance Analytics for interactive KPI charts, CSV exports, and Gemini executive summaries, or query ClaimWise Assistant anytime.',
    ],
    anomalyCount: violations + duplicates,
    status: 'placeholder',
  };
}

export function getLineAiConfidenceLabel(line: ExpenseLine): string {
  if (line.aiExtracted) return '✨ AI extracted';
  if (!line.aiConfidenceScore) return 'Manual Entry';
  return `OCR Verified (${line.aiConfidenceScore}%)`;
}
