import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
  testFirestoreConnection,
} from '../firebase';
import { buildSeedData, DEMO_OWNER_UID } from '../data/seedData';
import {
  AppNotification,
  AppScreen,
  ApprovalLog,
  AuditEntry,
  CityTier,
  ClaimStatus,
  CostCentre,
  Department,
  ExpenseClaim,
  ExpenseLine,
  ExpensePolicy,
  UserProfile,
  UserRole,
} from '../types/claimwise';
import {
  computeAiOverrides,
  formatINR,
  generateClaimNo,
  getCityTier,
} from '../utils/formatters';
import { evaluateClaimCompliance } from '../utils/policyEngine';

const LOCAL_STORAGE_KEY = 'claimwise_nova_foods_v3';

const DEMO_USER_IDS: Record<UserRole, string> = {
  employee: 'u-emp-1', // Aarav Deshmukh
  manager: 'u-mgr-1',  // Priya Nair
  finance: 'u-fin-1',  // Vikramaditya Rao
  admin: 'u-adm-1',    // Sneha Kulkarni
};

interface PersistedState {
  departments: Department[];
  costCentres: CostCentre[];
  users: UserProfile[];
  policies: ExpensePolicy[];
  claims: ExpenseClaim[];
  auditTrail: AuditEntry[];
  notifications: AppNotification[];
}

export interface ClaimDraftInput {
  id?: string;
  purpose: string;
  destination: string;
  tripFromDate: string;
  tripToDate: string;
  aiComplianceSummary?: string;
  lines: Omit<ExpenseLine, 'id' | 'claimId' | 'policyFlag' | 'policyFlagReason' | 'ownerUid'>[];
}

interface AppContextValue {
  currentUser: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  authReady: boolean;
  cloudSyncMode: 'local' | 'syncing' | 'cloud';
  cloudError: string | null;
  activeScreen: AppScreen;
  selectedClaimId: string | null;
  editingClaimId: string | null;
  departments: Department[];
  costCentres: CostCentre[];
  users: UserProfile[];
  policies: ExpensePolicy[];
  claims: ExpenseClaim[];
  auditTrail: AuditEntry[];
  notifications: AppNotification[];
  unreadCount: number;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  clearToast: () => void;
  navigate: (screen: AppScreen, options?: { claimId?: string | null; editClaimId?: string | null }) => void;
  loginAsDemoRole: (role: UserRole) => void;
  signInWithGoogleCloud: () => Promise<void>;
  disconnectGoogleCloud: () => Promise<void>;
  logout: () => Promise<void>;
  resetDemoWorkspace: () => Promise<void>;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  saveClaim: (input: ClaimDraftInput, submitImmediately: boolean) => Promise<ExpenseClaim>;
  deleteDraftClaim: (claimId: string) => Promise<void>;
  managerApproveClaims: (claimIds: string[], comment?: string) => Promise<void>;
  managerRejectClaim: (claimId: string, comment: string) => Promise<void>;
  financeVerifyClaim: (claimId: string, comment?: string) => Promise<void>;
  financeSendBackClaim: (claimId: string, comment: string) => Promise<void>;
  financeMarkAsPaid: (claimIds: string[], paymentRef?: string) => Promise<void>;
  recordAiReviewAudit: (claimId: string, recommendation: string, reasoning: string) => Promise<void>;
  updatePolicy: (policy: ExpensePolicy) => Promise<void>;
  addPolicy: (policy: Omit<ExpensePolicy, 'id' | 'ownerUid'>) => Promise<void>;
  updateUser: (user: UserProfile) => Promise<void>;
  addUser: (user: Omit<UserProfile, 'id' | 'ownerUid'>) => Promise<void>;
  addDepartment: (dept: Omit<Department, 'id' | 'ownerUid'>) => Promise<void>;
  addCostCentre: (cc: Omit<CostCentre, 'id' | 'ownerUid'>) => Promise<void>;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

function buildInitialNotifications(claims: ExpenseClaim[]): AppNotification[] {
  const notifs: AppNotification[] = [];
  const submitted = claims.filter((c) => c.status === 'Submitted').slice(0, 3);
  for (const c of submitted) {
    notifs.push({
      id: `notif-sub-${c.id}`,
      title: `Approval Required · ${c.claimNo}`,
      message: `${c.employeeName} submitted ${formatINR(c.totalAmount)} for ${c.destination}.`,
      claimId: c.id,
      claimNo: c.claimNo,
      timestamp: c.updatedAt,
      read: false,
      targetRoles: ['manager', 'admin'],
    });
  }
  const flagged = claims.filter((c) => c.isDuplicateFlagged).slice(0, 2);
  for (const c of flagged) {
    notifs.push({
      id: `notif-dup-${c.id}`,
      title: `Duplicate Flag · ${c.claimNo}`,
      message: `Matches ${c.duplicateRefClaimNo} (${c.employeeName}). Review before payout.`,
      claimId: c.id,
      claimNo: c.claimNo,
      timestamp: c.updatedAt,
      read: false,
      targetRoles: ['finance', 'admin'],
    });
  }
  const sentBack = claims.filter((c) => c.status === 'Sent Back').slice(0, 3);
  for (const c of sentBack) {
    notifs.push({
      id: `notif-sb-${c.id}`,
      title: `Action Needed · ${c.claimNo}`,
      message: `Finance sent back ${c.claimNo} (${formatINR(c.totalAmount)}) for tax invoice clarification.`,
      claimId: c.id,
      claimNo: c.claimNo,
      timestamp: c.updatedAt,
      read: false,
      targetRoles: ['employee', 'admin'],
      targetUserId: c.employeeId,
    });
  }
  const settled = claims.filter((c) => c.status === 'Paid').slice(0, 2);
  for (const c of settled) {
    notifs.push({
      id: `notif-paid-${c.id}`,
      title: `Reimbursement Paid · ${c.claimNo}`,
      message: `${formatINR(c.totalAmount)} settled via HDFC NEFT for ${c.destination}.`,
      claimId: c.id,
      claimNo: c.claimNo,
      timestamp: c.updatedAt,
      read: true,
      targetRoles: ['employee', 'admin'],
      targetUserId: c.employeeId,
    });
  }
  return notifs;
}

function loadLocalSeed(): PersistedState {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PersistedState;
      if (parsed && Array.isArray(parsed.claims) && parsed.claims.length > 0 && Array.isArray(parsed.users)) {
        return parsed;
      }
    }
  } catch {
    // Ignore storage read errors
  }
  const seed = buildSeedData(DEMO_OWNER_UID);
  return {
    ...seed,
    notifications: buildInitialNotifications(seed.claims),
  };
}

function sanitizeForFirestore<T extends object>(obj: T): T {
  const clean: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) clean[k] = v;
  }
  return clean as T;
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initial = useMemo(() => loadLocalSeed(), []);
  const [departments, setDepartments] = useState<Department[]>(initial.departments);
  const [costCentres, setCostCentres] = useState<CostCentre[]>(initial.costCentres);
  const [users, setUsers] = useState<UserProfile[]>(initial.users);
  const [policies, setPolicies] = useState<ExpensePolicy[]>(initial.policies);
  const [claims, setClaims] = useState<ExpenseClaim[]>(initial.claims);
  const [auditTrail, setAuditTrail] = useState<AuditEntry[]>(initial.auditTrail);
  const [notifications, setNotifications] = useState<AppNotification[]>(initial.notifications);

  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    try {
      return localStorage.getItem('claimwise_active_user_id');
    } catch {
      return null;
    }
  });
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [cloudSyncMode, setCloudSyncMode] = useState<'local' | 'syncing' | 'cloud'>('local');
  const [cloudError, setCloudError] = useState<string | null>(null);

  const [activeScreen, setActiveScreen] = useState<AppScreen>('dashboard');
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  const [editingClaimId, setEditingClaimId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const currentUser = useMemo(
    () => users.find((u) => u.id === currentUserId) || null,
    [users, currentUserId]
  );

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4000);
    return () => clearTimeout(t);
  }, [toast]);

  // Persist local state whenever running locally
  useEffect(() => {
    try {
      const payload: PersistedState = {
        departments,
        costCentres,
        users,
        policies,
        claims,
        auditTrail,
        notifications,
      };
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore quota errors on large receipt previews
    }
  }, [departments, costCentres, users, policies, claims, auditTrail, notifications]);

  useEffect(() => {
    try {
      if (currentUserId) {
        localStorage.setItem('claimwise_active_user_id', currentUserId);
      } else {
        localStorage.removeItem('claimwise_active_user_id');
      }
    } catch {
      // Ignore
    }
  }, [currentUserId]);

  // Seed Firestore workspace on first Google login
  const seedFirestoreIfEmpty = async (uid: string) => {
    const existingUsers = await getDocs(collection(db, 'users')).catch((e) =>
      handleFirestoreError(e, OperationType.LIST, 'users')
    );
    if (!existingUsers.empty) return;

    const seed = buildSeedData(uid);
    const ops: { ref: ReturnType<typeof doc>; data: Record<string, unknown> }[] = [];

    for (const d of seed.departments) {
      ops.push({ ref: doc(db, 'departments', d.id), data: sanitizeForFirestore({ ...d, ownerUid: uid }) });
    }
    for (const cc of seed.costCentres) {
      ops.push({ ref: doc(db, 'costCentres', cc.id), data: sanitizeForFirestore({ ...cc, ownerUid: uid }) });
    }
    for (const u of seed.users) {
      ops.push({ ref: doc(db, 'users', u.id), data: sanitizeForFirestore({ ...u, ownerUid: uid }) });
    }
    for (const p of seed.policies) {
      ops.push({ ref: doc(db, 'expensePolicies', p.id), data: sanitizeForFirestore({ ...p, ownerUid: uid }) });
    }
    for (const c of seed.claims) {
      const { lines, approvalHistory, ...claimHeader } = c;
      ops.push({ ref: doc(db, 'expenseClaims', c.id), data: sanitizeForFirestore({ ...claimHeader, ownerUid: uid }) });
      for (const l of lines) {
        ops.push({
          ref: doc(db, 'expenseClaims', c.id, 'lines', l.id),
          data: sanitizeForFirestore({ ...l, ownerUid: uid }),
        });
      }
      for (const a of approvalHistory) {
        ops.push({
          ref: doc(db, 'expenseClaims', c.id, 'approvalLogs', a.id),
          data: sanitizeForFirestore({ ...a, ownerUid: uid }),
        });
      }
    }
    for (const aud of seed.auditTrail) {
      ops.push({ ref: doc(db, 'auditTrail', aud.id), data: sanitizeForFirestore({ ...aud, ownerUid: uid }) });
    }

    // Commit in batches of 400
    for (let i = 0; i < ops.length; i += 400) {
      const batch = writeBatch(db);
      for (const op of ops.slice(i, i + 400)) {
        batch.set(op.ref, op.data);
      }
      await batch.commit().catch((e) => handleFirestoreError(e, OperationType.WRITE, 'seedBatch'));
    }
  };

  // Monitor Firebase Auth state & connect Firestore listeners when signed in
  useEffect(() => {
    testFirestoreConnection();
    const unsubAuth = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      setAuthReady(true);

      if (!fbUser || !fbUser.emailVerified) {
        setCloudSyncMode('local');
        return;
      }

      setCloudSyncMode('syncing');
      setCloudError(null);
      try {
        await seedFirestoreIfEmpty(fbUser.uid);
        setCloudSyncMode('cloud');
      } catch (err) {
        setCloudError(err instanceof Error ? err.message : 'Failed to sync with Firestore');
        setCloudSyncMode('local');
      }
    });
    return () => unsubAuth();
  }, []);

  // Real-time Firestore subscriptions when cloudSyncMode === 'cloud'
  useEffect(() => {
    if (cloudSyncMode !== 'cloud' || !firebaseUser) return;

    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        if (!snap.empty) {
          setUsers(snap.docs.map((d) => d.data() as UserProfile));
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );

    const unsubDepts = onSnapshot(
      collection(db, 'departments'),
      (snap) => {
        if (!snap.empty) setDepartments(snap.docs.map((d) => d.data() as Department));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'departments')
    );

    const unsubCC = onSnapshot(
      collection(db, 'costCentres'),
      (snap) => {
        if (!snap.empty) setCostCentres(snap.docs.map((d) => d.data() as CostCentre));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'costCentres')
    );

    const unsubPolicies = onSnapshot(
      collection(db, 'expensePolicies'),
      (snap) => {
        if (!snap.empty) setPolicies(snap.docs.map((d) => d.data() as ExpensePolicy));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'expensePolicies')
    );

    const unsubAudit = onSnapshot(
      collection(db, 'auditTrail'),
      (snap) => {
        if (!snap.empty) {
          const list = snap.docs.map((d) => d.data() as AuditEntry);
          list.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
          setAuditTrail(list);
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'auditTrail')
    );

    const unsubClaims = onSnapshot(
      collection(db, 'expenseClaims'),
      async (snap) => {
        if (snap.empty) return;
        const loadedClaims: ExpenseClaim[] = await Promise.all(
          snap.docs.map(async (claimDoc) => {
            const header = claimDoc.data() as Omit<ExpenseClaim, 'lines' | 'approvalHistory'>;
            const [linesSnap, logsSnap] = await Promise.all([
              getDocs(collection(db, 'expenseClaims', claimDoc.id, 'lines')).catch((e) =>
                handleFirestoreError(e, OperationType.LIST, `expenseClaims/${claimDoc.id}/lines`)
              ),
              getDocs(collection(db, 'expenseClaims', claimDoc.id, 'approvalLogs')).catch((e) =>
                handleFirestoreError(e, OperationType.LIST, `expenseClaims/${claimDoc.id}/approvalLogs`)
              ),
            ]);
            const lines = linesSnap.docs.map((l) => l.data() as ExpenseLine);
            const approvalHistory = logsSnap.docs
              .map((a) => a.data() as ApprovalLog)
              .sort((a, b) => a.timestamp.localeCompare(b.timestamp));
            return { ...header, lines, approvalHistory };
          })
        );
        loadedClaims.sort((a, b) => b.claimNo.localeCompare(a.claimNo));
        setClaims(loadedClaims);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'expenseClaims')
    );

    return () => {
      unsubUsers();
      unsubDepts();
      unsubCC();
      unsubPolicies();
      unsubAudit();
      unsubClaims();
    };
  }, [cloudSyncMode, firebaseUser]);

  const activeOwnerUid = firebaseUser?.uid || DEMO_OWNER_UID;

  const navigate = (
    screen: AppScreen,
    options?: { claimId?: string | null; editClaimId?: string | null }
  ) => {
    setActiveScreen(screen);
    if (options && 'claimId' in options) setSelectedClaimId(options.claimId ?? null);
    if (options && 'editClaimId' in options) setEditingClaimId(options.editClaimId ?? null);
  };

  const loginAsDemoRole = (role: UserRole) => {
    const uid = DEMO_USER_IDS[role];
    setCurrentUserId(uid);
    if (role === 'manager') setActiveScreen('manager-inbox');
    else if (role === 'finance') setActiveScreen('finance-queue');
    else if (role === 'admin') setActiveScreen('admin');
    else setActiveScreen('dashboard');
    setSelectedClaimId(null);
    setEditingClaimId(null);
    const matched = users.find((u) => u.id === uid);
    if (matched) {
      showToast(`Signed in as ${matched.name} (${role.toUpperCase()})`, 'info');
    }
  };

  const signInWithGoogleCloud = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (!currentUserId) {
        setCurrentUserId(DEMO_USER_IDS.admin);
        setActiveScreen('dashboard');
      }
      showToast(`Cloud sync connected for ${result.user.email}`, 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Google Sign-In cancelled or blocked', 'error');
    }
  };

  const disconnectGoogleCloud = async () => {
    if (firebaseUser) {
      await firebaseSignOut(auth).catch(() => undefined);
      showToast('Google Cloud Sync disconnected. Using local browser workspace.', 'info');
    }
  };

  const logout = async () => {
    setCurrentUserId(null);
    setSelectedClaimId(null);
    setEditingClaimId(null);
    setActiveScreen('dashboard');
    if (firebaseUser) {
      await firebaseSignOut(auth).catch(() => undefined);
    }
  };

  const resetDemoWorkspace = async () => {
    const seed = buildSeedData(activeOwnerUid);
    setDepartments(seed.departments);
    setCostCentres(seed.costCentres);
    setUsers(seed.users);
    setPolicies(seed.policies);
    setClaims(seed.claims);
    setAuditTrail(seed.auditTrail);
    setNotifications(buildInitialNotifications(seed.claims));
    setSelectedClaimId(null);
    setEditingClaimId(null);
    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
    showToast('Demo workspace reset to initial 60 claims, 20 employees, and 60 policy rules.', 'info');
  };

  const appendAudit = async (entry: Omit<AuditEntry, 'id' | 'timestamp' | 'ownerUid'>) => {
    const full: AuditEntry = {
      ...entry,
      id: `aud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      ownerUid: activeOwnerUid,
    };
    setAuditTrail((prev) => [full, ...prev]);
    if (cloudSyncMode === 'cloud') {
      await setDoc(doc(db, 'auditTrail', full.id), sanitizeForFirestore(full)).catch((e) =>
        handleFirestoreError(e, OperationType.CREATE, `auditTrail/${full.id}`)
      );
    }
  };

  const pushNotification = (notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const item: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
      read: false,
    };
    setNotifications((prev) => [item, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const saveClaim = async (input: ClaimDraftInput, submitImmediately: boolean): Promise<ExpenseClaim> => {
    if (!currentUser) throw new Error('User must be signed in.');
    const nowIso = new Date().toISOString();
    const todayDate = nowIso.slice(0, 10);
    const cityTier: CityTier = getCityTier(input.destination);
    const existingClaim = input.id ? claims.find((c) => c.id === input.id) : undefined;

    if (existingClaim && existingClaim.status !== 'Draft' && existingClaim.status !== 'Sent Back') {
      throw new Error('Only Draft or Sent Back claims can be edited.');
    }

    const claimId = existingClaim ? existingClaim.id : `claim-${Date.now()}`;
    const claimNo = existingClaim ? existingClaim.claimNo : generateClaimNo(claims);
    const effectiveGrade = existingClaim?.grade || currentUser.grade;

    const compliance = evaluateClaimCompliance(
      {
        tripFromDate: input.tripFromDate,
        tripToDate: input.tripToDate,
        employeeId: existingClaim?.employeeId || currentUser.id,
        lines: input.lines,
      },
      effectiveGrade,
      cityTier,
      policies,
      claims,
      claimId
    );

    if (submitImmediately && compliance.missingJustificationLines.length > 0) {
      throw new Error(
        `Mandatory justification required before submitting line(s) with policy exceptions: Line #${compliance.missingJustificationLines.join(', #')}.`
      );
    }

    const evaluatedLines: ExpenseLine[] = input.lines.map((l, idx) => {
      const evalRes = compliance.lineEvaluations[idx];
      const overrides = l.aiExtracted
        ? computeAiOverrides(l.aiSuggestedValues, {
            merchant: l.merchant,
            date: l.date,
            invoiceNo: l.invoiceNo,
            amount: l.amount,
            gstAmount: l.gstAmount,
            gstin: l.gstin,
            currency: l.currency || 'INR',
            paymentMode: l.paymentMode,
            category: l.category,
          })
        : [];
      return {
        ...l,
        id: `${claimId}-line-${idx + 1}-${Date.now().toString().slice(-4)}`,
        claimId,
        aiUserOverrides: overrides,
        policyFlag: evalRes.flag,
        policyFlagReason: evalRes.reason.slice(0, 390),
        policyPermissibleLimit: evalRes.permissibleLimit,
        policyExcessAmount: evalRes.excessAmount,
        policyExceptionCodes: evalRes.exceptionCodes,
        aiPolicyRecommendation: (l.aiPolicyRecommendation || evalRes.aiRecommendation).slice(0, 390),
        ownerUid: activeOwnerUid,
      };
    });

    const totalAmount = evaluatedLines.reduce((s, l) => s + Number(l.amount || 0), 0);
    const totalGstAmount = evaluatedLines.reduce((s, l) => s + Number(l.gstAmount || 0), 0);
    const hasPolicyViolation = compliance.hasExceptions;
    const newStatus: ClaimStatus = submitImmediately ? 'Submitted' : 'Draft';

    const newLog: ApprovalLog = {
      id: `${claimId}-log-${Date.now()}`,
      claimId,
      claimNo,
      action: submitImmediately ? 'Submitted' : existingClaim ? 'Updated Draft' : 'Created',
      byUserId: currentUser.id,
      byName: currentUser.name,
      byRole: currentUser.role,
      comments: submitImmediately
        ? hasPolicyViolation
          ? `Submitted with ${compliance.exceptionCount} policy exception(s) (Compliance Score: ${compliance.complianceScore}/100).`
          : `Submitted for manager approval (Compliance Score: ${compliance.complianceScore}/100).`
        : 'Saved as draft.',
      timestamp: nowIso,
      ownerUid: activeOwnerUid,
    };

    const claimObj: ExpenseClaim = {
      id: claimId,
      claimNo,
      employeeId: existingClaim?.employeeId || currentUser.id,
      employeeName: existingClaim?.employeeName || currentUser.name,
      employeeCode: existingClaim?.employeeCode || currentUser.employeeCode,
      department: existingClaim?.department || currentUser.department,
      costCentre: existingClaim?.costCentre || currentUser.costCentre,
      grade: effectiveGrade,
      managerId: existingClaim?.managerId || currentUser.managerId || 'u-mgr-1',
      purpose: input.purpose.trim(),
      destination: input.destination,
      cityTier,
      tripFromDate: input.tripFromDate,
      tripToDate: input.tripToDate,
      totalAmount,
      totalGstAmount,
      lineCount: evaluatedLines.length,
      status: newStatus,
      submittedDate: submitImmediately ? todayDate : existingClaim?.submittedDate || '',
      hasPolicyViolation,
      isDuplicateFlagged: Boolean(compliance.duplicateClaimNo),
      duplicateRefClaimNo: compliance.duplicateClaimNo,
      complianceScore: compliance.complianceScore,
      aiComplianceSummary: input.aiComplianceSummary?.slice(0, 590),
      ownerUid: existingClaim?.ownerUid || activeOwnerUid,
      createdAt: existingClaim?.createdAt || nowIso,
      updatedAt: nowIso,
      lines: evaluatedLines,
      approvalHistory: [...(existingClaim?.approvalHistory || []), newLog],
    };

    setClaims((prev) => {
      const exists = prev.some((c) => c.id === claimId);
      if (exists) return prev.map((c) => (c.id === claimId ? claimObj : c));
      return [claimObj, ...prev];
    });

    if (cloudSyncMode === 'cloud') {
      const { lines, approvalHistory, ...header } = claimObj;
      await setDoc(doc(db, 'expenseClaims', claimId), sanitizeForFirestore(header)).catch((e) =>
        handleFirestoreError(e, OperationType.WRITE, `expenseClaims/${claimId}`)
      );
      if (existingClaim) {
        for (const oldLine of existingClaim.lines) {
          await deleteDoc(doc(db, 'expenseClaims', claimId, 'lines', oldLine.id)).catch(() => undefined);
        }
      }
      for (const l of lines) {
        await setDoc(doc(db, 'expenseClaims', claimId, 'lines', l.id), sanitizeForFirestore(l)).catch((e) =>
          handleFirestoreError(e, OperationType.WRITE, `expenseClaims/${claimId}/lines/${l.id}`)
        );
      }
      await setDoc(
        doc(db, 'expenseClaims', claimId, 'approvalLogs', newLog.id),
        sanitizeForFirestore(newLog)
      ).catch((e) => handleFirestoreError(e, OperationType.CREATE, `expenseClaims/${claimId}/approvalLogs/${newLog.id}`));
    }

    await appendAudit({
      entityType: 'Claim',
      entityId: claimId,
      claimNo,
      action: submitImmediately ? 'Claim Submitted' : 'Draft Saved',
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      details: `${claimNo} for ${formatINR(totalAmount)} (${input.destination}) ${submitImmediately ? 'submitted for approval' : 'saved as draft'}.`,
    });

    const aiLines = evaluatedLines.filter((l) => l.aiExtracted);
    if (aiLines.length > 0) {
      const overrideSummary = aiLines
        .flatMap((l, idx) =>
          (l.aiUserOverrides || []).map(
            (ov) => `L${idx + 1} ${ov.field}: AI "${ov.aiValue}" → User "${ov.userValue}"`
          )
        )
        .join('; ');
      await appendAudit({
        entityType: 'ExpenseLine',
        entityId: claimId,
        claimNo,
        action: 'AI Extraction Audit',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        details: overrideSummary
          ? `${aiLines.length} line(s) AI-extracted with user overrides: ${overrideSummary}`.slice(0, 490)
          : `${aiLines.length} line(s) AI-extracted and accepted without user overrides.`,
      });
    }

    if (submitImmediately) {
      pushNotification({
        title: `New Submission · ${claimNo}`,
        message: `${currentUser.name} submitted ${formatINR(totalAmount)} (${input.destination}).`,
        claimId,
        claimNo,
        targetRoles: ['manager', 'admin'],
      });
      pushNotification({
        title: `Claim Submitted · ${claimNo}`,
        message: `Your claim for ${formatINR(totalAmount)} (${input.destination}) is pending manager review.`,
        claimId,
        claimNo,
        targetRoles: ['employee'],
        targetUserId: claimObj.employeeId,
      });
    }

    showToast(
      submitImmediately ? `${claimNo} submitted for manager approval.` : `${claimNo} saved as draft.`,
      'success'
    );
    return claimObj;
  };

  const deleteDraftClaim = async (claimId: string) => {
    if (!currentUser) return;
    const target = claims.find((c) => c.id === claimId);
    if (!target || target.status !== 'Draft') {
      showToast('Only Draft claims can be deleted.', 'error');
      return;
    }
    setClaims((prev) => prev.filter((c) => c.id !== claimId));
    if (cloudSyncMode === 'cloud') {
      await deleteDoc(doc(db, 'expenseClaims', claimId)).catch((e) =>
        handleFirestoreError(e, OperationType.DELETE, `expenseClaims/${claimId}`)
      );
    }
    await appendAudit({
      entityType: 'Claim',
      entityId: claimId,
      claimNo: target.claimNo,
      action: 'Draft Deleted',
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      details: `Deleted draft claim ${target.claimNo}.`,
    });
    showToast(`Draft ${target.claimNo} deleted.`, 'info');
  };

  const transitionClaim = async (
    claimId: string,
    newStatus: ClaimStatus,
    actionLabel: string,
    comment: string
  ) => {
    if (!currentUser) return;
    const target = claims.find((c) => c.id === claimId);
    if (!target) return;

    const nowIso = new Date().toISOString();
    const log: ApprovalLog = {
      id: `${claimId}-log-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      claimId,
      claimNo: target.claimNo,
      action: actionLabel,
      byUserId: currentUser.id,
      byName: currentUser.name,
      byRole: currentUser.role,
      comments: comment,
      timestamp: nowIso,
      ownerUid: target.ownerUid,
    };

    const updated: ExpenseClaim = {
      ...target,
      status: newStatus,
      updatedAt: nowIso,
      approvalHistory: [...target.approvalHistory, log],
    };

    setClaims((prev) => prev.map((c) => (c.id === claimId ? updated : c)));

    if (cloudSyncMode === 'cloud') {
      await updateDoc(doc(db, 'expenseClaims', claimId), {
        status: newStatus,
        updatedAt: nowIso,
      }).catch((e) => handleFirestoreError(e, OperationType.UPDATE, `expenseClaims/${claimId}`));
      await setDoc(
        doc(db, 'expenseClaims', claimId, 'approvalLogs', log.id),
        sanitizeForFirestore(log)
      ).catch((e) => handleFirestoreError(e, OperationType.CREATE, `expenseClaims/${claimId}/approvalLogs/${log.id}`));
    }

    await appendAudit({
      entityType: 'Claim',
      entityId: claimId,
      claimNo: target.claimNo,
      action: actionLabel,
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      details: `${target.claimNo} marked ${newStatus} · ${comment}`,
    });
  };

  const managerApproveClaims = async (claimIds: string[], comment = 'Approved by reporting manager.') => {
    for (const id of claimIds) {
      await transitionClaim(id, 'Manager Approved', 'Manager Approved', comment);
    }
    const approvedClaims = claims.filter((c) => claimIds.includes(c.id));
    const exceptionClaims = approvedClaims.filter((c) => c.hasPolicyViolation || c.isDuplicateFlagged);
    pushNotification({
      title:
        exceptionClaims.length > 0
          ? `Policy Exception Routed (${exceptionClaims.length} of ${claimIds.length})`
          : `${claimIds.length} Claim(s) Ready for Finance`,
      message:
        exceptionClaims.length > 0
          ? `${currentUser?.name} approved ${claimIds.length} claim(s); ${exceptionClaims.map((e) => e.claimNo).join(', ')} carry Policy Exception tags for Finance review.`
          : `${currentUser?.name} approved ${claimIds.length} claim(s) for Finance verification.`,
      claimId: (exceptionClaims[0] || approvedClaims[0])?.id || claimIds[0],
      claimNo: (exceptionClaims[0] || approvedClaims[0])?.claimNo,
      targetRoles: ['finance', 'admin'],
    });
    for (const c of approvedClaims) {
      pushNotification({
        title: `Manager Approved · ${c.claimNo}`,
        message: `${currentUser?.name || 'Manager'} approved ${c.claimNo} (${formatINR(c.totalAmount)}) and routed it to Finance.`,
        claimId: c.id,
        claimNo: c.claimNo,
        targetRoles: ['employee'],
        targetUserId: c.employeeId,
      });
    }
    showToast(`${claimIds.length} claim(s) approved and routed to Finance.`, 'success');
  };

  const managerRejectClaim = async (claimId: string, comment: string) => {
    if (!comment.trim()) throw new Error('Rejection comment is mandatory.');
    const target = claims.find((c) => c.id === claimId);
    await transitionClaim(claimId, 'Rejected', 'Rejected', comment.trim());
    if (target) {
      pushNotification({
        title: `Claim Rejected · ${target.claimNo}`,
        message: `${currentUser?.name} rejected ${target.claimNo}: ${comment.trim()}`,
        claimId,
        claimNo: target.claimNo,
        targetRoles: ['employee', 'admin'],
        targetUserId: target.employeeId,
      });
    }
    showToast('Claim rejected with comment.', 'info');
  };

  const financeVerifyClaim = async (claimId: string, comment = 'GST & policy verified by Finance Controller.') => {
    const target = claims.find((c) => c.id === claimId);
    await transitionClaim(claimId, 'Finance Verified', 'Finance Verified', comment);
    if (target) {
      pushNotification({
        title: `Finance Verified · ${target.claimNo}`,
        message: `${target.claimNo} (${formatINR(target.totalAmount)}) cleared Finance audit and is queued for NEFT payout.`,
        claimId,
        claimNo: target.claimNo,
        targetRoles: ['employee', 'admin'],
        targetUserId: target.employeeId,
      });
    }
    showToast('Claim verified and queued for payout.', 'success');
  };

  const financeSendBackClaim = async (claimId: string, comment: string) => {
    if (!comment.trim()) throw new Error('Send-back comment is mandatory.');
    const target = claims.find((c) => c.id === claimId);
    await transitionClaim(claimId, 'Sent Back', 'Sent Back', comment.trim());
    if (target) {
      pushNotification({
        title: `Claim Sent Back · ${target.claimNo}`,
        message: `Finance requested revision: ${comment.trim()}`,
        claimId,
        claimNo: target.claimNo,
        targetRoles: ['employee', 'admin'],
        targetUserId: target.employeeId,
      });
    }
    showToast('Claim sent back to employee for edits.', 'info');
  };

  const financeMarkAsPaid = async (claimIds: string[], paymentRef = 'HDFC NEFT Batch Settlement') => {
    for (const id of claimIds) {
      await transitionClaim(id, 'Paid', 'Paid', paymentRef);
    }
    const paidClaims = claims.filter((c) => claimIds.includes(c.id));
    for (const c of paidClaims) {
      pushNotification({
        title: `Reimbursement Paid · ${c.claimNo}`,
        message: `${formatINR(c.totalAmount)} settled via ${paymentRef}.`,
        claimId: c.id,
        claimNo: c.claimNo,
        targetRoles: ['employee', 'admin'],
        targetUserId: c.employeeId,
      });
    }
    showToast(`${claimIds.length} claim(s) marked as Paid.`, 'success');
  };

  const recordAiReviewAudit = async (claimId: string, recommendation: string, reasoning: string) => {
    if (!currentUser) return;
    const target = claims.find((c) => c.id === claimId);
    if (!target) return;
    await appendAudit({
      entityType: 'Claim',
      entityId: claimId,
      claimNo: target.claimNo,
      action: 'AI Review Agent Consulted',
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      details: `Draft recommendation: ${recommendation} — ${reasoning}`.slice(0, 480),
    });
  };

  const updatePolicy = async (policy: ExpensePolicy) => {
    setPolicies((prev) => prev.map((p) => (p.id === policy.id ? policy : p)));
    if (cloudSyncMode === 'cloud') {
      const { limitPerDay, limitPerUnit, cityTier, requiresReceipt, requiresPreApproval, gstEligible, notes } = policy;
      await updateDoc(doc(db, 'expensePolicies', policy.id), {
        limitPerDay,
        limitPerUnit,
        cityTier,
        requiresReceipt,
        requiresPreApproval,
        gstEligible,
        notes,
      }).catch((e) => handleFirestoreError(e, OperationType.UPDATE, `expensePolicies/${policy.id}`));
    }
    if (currentUser) {
      await appendAudit({
        entityType: 'Policy',
        entityId: policy.id,
        action: 'Policy Rule Updated',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        details: `${policy.category} (${policy.grade}, ${policy.cityTier}) cap updated to ${formatINR(policy.limitPerUnit || policy.limitPerDay)}.`,
      });
    }
    showToast('Expense policy rule updated.', 'success');
  };

  const addPolicy = async (policyInput: Omit<ExpensePolicy, 'id' | 'ownerUid'>) => {
    const policy: ExpensePolicy = {
      ...policyInput,
      id: `pol-${Date.now()}`,
      ownerUid: activeOwnerUid,
    };
    setPolicies((prev) => [policy, ...prev]);
    if (cloudSyncMode === 'cloud') {
      await setDoc(doc(db, 'expensePolicies', policy.id), sanitizeForFirestore(policy)).catch((e) =>
        handleFirestoreError(e, OperationType.CREATE, `expensePolicies/${policy.id}`)
      );
    }
    if (currentUser) {
      await appendAudit({
        entityType: 'Policy',
        entityId: policy.id,
        action: 'Policy Rule Added',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        details: `Created rule for ${policy.category} (${policy.grade}, ${policy.cityTier}).`,
      });
    }
    showToast('New policy rule created.', 'success');
  };

  const updateUser = async (user: UserProfile) => {
    setUsers((prev) => prev.map((u) => (u.id === user.id ? user : u)));
    if (cloudSyncMode === 'cloud') {
      const { name, role, department, costCentre, grade, managerId, location, avatarUrl, isActive } = user;
      await updateDoc(
        doc(db, 'users', user.id),
        sanitizeForFirestore({ name, role, department, costCentre, grade, managerId, location, avatarUrl, isActive })
      ).catch((e) => handleFirestoreError(e, OperationType.UPDATE, `users/${user.id}`));
    }
    if (currentUser) {
      await appendAudit({
        entityType: 'User',
        entityId: user.id,
        action: 'User Profile Updated',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        details: `Updated ${user.name} (${user.employeeCode}) · Role: ${user.role}, Grade: ${user.grade}.`,
      });
    }
    showToast(`Updated ${user.name}'s profile.`, 'success');
  };

  const addUser = async (userInput: Omit<UserProfile, 'id' | 'ownerUid'>) => {
    const newUser: UserProfile = {
      ...userInput,
      id: `u-custom-${Date.now()}`,
      ownerUid: activeOwnerUid,
    };
    setUsers((prev) => [newUser, ...prev]);
    if (cloudSyncMode === 'cloud') {
      await setDoc(doc(db, 'users', newUser.id), sanitizeForFirestore(newUser)).catch((e) =>
        handleFirestoreError(e, OperationType.CREATE, `users/${newUser.id}`)
      );
    }
    if (currentUser) {
      await appendAudit({
        entityType: 'User',
        entityId: newUser.id,
        action: 'User Created',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        details: `Added ${newUser.name} (${newUser.employeeCode}) as ${newUser.role} in ${newUser.department}.`,
      });
    }
    showToast(`Added ${newUser.name} to directory.`, 'success');
  };

  const addDepartment = async (deptInput: Omit<Department, 'id' | 'ownerUid'>) => {
    const dept: Department = {
      ...deptInput,
      id: `dept-${Date.now()}`,
      ownerUid: activeOwnerUid,
    };
    setDepartments((prev) => [...prev, dept]);
    if (cloudSyncMode === 'cloud') {
      await setDoc(doc(db, 'departments', dept.id), sanitizeForFirestore(dept)).catch((e) =>
        handleFirestoreError(e, OperationType.CREATE, `departments/${dept.id}`)
      );
    }
    showToast(`Department ${dept.name} added.`, 'success');
  };

  const addCostCentre = async (ccInput: Omit<CostCentre, 'id' | 'ownerUid'>) => {
    const cc: CostCentre = {
      ...ccInput,
      id: `cc-${Date.now()}`,
      ownerUid: activeOwnerUid,
    };
    setCostCentres((prev) => [...prev, cc]);
    if (cloudSyncMode === 'cloud') {
      await setDoc(doc(db, 'costCentres', cc.id), sanitizeForFirestore(cc)).catch((e) =>
        handleFirestoreError(e, OperationType.CREATE, `costCentres/${cc.id}`)
      );
    }
    showToast(`Cost centre ${cc.code} added.`, 'success');
  };

  const visibleNotifications = useMemo(() => {
    if (!currentUser) return [];
    return notifications.filter((n) => {
      if (!n.targetRoles.includes(currentUser.role)) return false;
      if (currentUser.role === 'employee' && n.targetUserId) {
        return n.targetUserId === currentUser.id;
      }
      return true;
    });
  }, [notifications, currentUser]);

  const unreadCount = useMemo(
    () => visibleNotifications.filter((n) => !n.read).length,
    [visibleNotifications]
  );

  return (
    <AppContext.Provider
      value={{
        currentUser,
        firebaseUser,
        authReady,
        cloudSyncMode,
        cloudError,
        activeScreen,
        selectedClaimId,
        editingClaimId,
        departments,
        costCentres,
        users,
        policies,
        claims,
        auditTrail,
        notifications: visibleNotifications,
        unreadCount,
        toast,
        showToast,
        clearToast: () => setToast(null),
        navigate,
        loginAsDemoRole,
        signInWithGoogleCloud,
        disconnectGoogleCloud,
        logout,
        resetDemoWorkspace,
        markNotificationRead,
        markAllNotificationsRead,
        saveClaim,
        deleteDraftClaim,
        managerApproveClaims,
        managerRejectClaim,
        financeVerifyClaim,
        financeSendBackClaim,
        financeMarkAsPaid,
        recordAiReviewAudit,
        updatePolicy,
        addPolicy,
        updateUser,
        addUser,
        addDepartment,
        addCostCentre,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
