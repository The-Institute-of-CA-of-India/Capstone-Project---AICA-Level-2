export type UserRole = 'employee' | 'manager' | 'finance' | 'admin';

export type Grade = 'G1' | 'G2' | 'G3' | 'G4' | 'G5';

export type CityTier = 'Tier 1' | 'Tier 2';

export type PolicyCityTier = 'Tier 1' | 'Tier 2' | 'All';

export type ClaimStatus =
  | 'Draft'
  | 'Submitted'
  | 'Manager Approved'
  | 'Rejected'
  | 'Sent Back'
  | 'Finance Verified'
  | 'Paid';

export type PolicyFlag = 'Compliant' | 'Warning' | 'Violation';

export type PolicyExceptionCode =
  | 'LIMIT_EXCEEDED'
  | 'MISSING_RECEIPT'
  | 'WEEKEND_HOLIDAY'
  | 'OUTSIDE_TRIP_DATES'
  | 'MISSING_PRE_APPROVAL'
  | 'GST_WARNING'
  | 'DUPLICATE_CLAIM';

export interface PolicyCheckIssue {
  code: PolicyExceptionCode;
  severity: 'exception' | 'warning';
  title: string;
  summary: string;
  suggestedFix: string;
}

export interface LineComplianceEvaluation {
  flag: PolicyFlag;
  hasException: boolean;
  claimedAmount: number;
  permissibleLimit: number;
  excessAmount: number;
  requiresReceipt: boolean;
  requiresPreApproval: boolean;
  matchedPolicyId?: string;
  matchedPolicyNotes?: string;
  issues: PolicyCheckIssue[];
  exceptionCodes: string[];
  reason: string;
  aiRecommendation: string;
}

export interface ClaimComplianceIssueItem {
  lineNumber: number;
  merchant: string;
  category: string;
  code: PolicyExceptionCode;
  severity: 'exception' | 'warning';
  title: string;
  summary: string;
  suggestedFix: string;
}

export interface ClaimComplianceSummary {
  complianceScore: number; // 0-100
  hasExceptions: boolean;
  exceptionCount: number;
  warningCount: number;
  lineEvaluations: LineComplianceEvaluation[];
  issues: ClaimComplianceIssueItem[];
  duplicateClaimNo: string;
  missingJustificationLines: number[];
}

export interface AiPreSubmissionCheckResult {
  complianceScore: number;
  executiveSummary: string;
  gstAssessment: string;
  lineRecommendations: {
    lineNumber: number;
    recommendation: string;
  }[];
  prioritizedFixes: {
    lineNumber: number;
    issueTitle: string;
    severity: 'exception' | 'warning';
    suggestedFix: string;
  }[];
}

export type RiskLevel = 'Low' | 'Medium' | 'High';

export type DuplicateMatchType = 'EXACT_INVOICE' | 'FUZZY_SAME_EMPLOYEE' | 'INTRA_CLAIM';

export interface DuplicateFinding {
  lineNumber: number;
  merchant: string;
  invoiceNo: string;
  amount: number;
  date: string;
  matchedClaimId: string;
  matchedClaimNo: string;
  matchedLineNumber: number;
  matchedAmount: number;
  matchedDate: string;
  matchedInvoiceNo: string;
  matchType: DuplicateMatchType;
  similarityScore: number;
  reason: string;
}

export type AnomalyCode =
  | 'ROUND_NUMBER'
  | 'HIGH_VS_AVG'
  | 'THRESHOLD_HUGGING'
  | 'SPLIT_BILL';

export interface AnomalyFinding {
  code: AnomalyCode;
  severity: 'medium' | 'high';
  lineNumber?: number;
  category: string;
  title: string;
  reason: string;
  metrics?: string;
}

export interface ClaimRiskAnalysis {
  riskLevel: RiskLevel;
  riskScore: number; // 0-100
  duplicates: DuplicateFinding[];
  anomalies: AnomalyFinding[];
  plainEnglishReasons: string[];
  categorySixMonthAverages: Record<string, { avg: number; sampleCount: number }>;
  policyExceptionCount: number;
}

export type FinanceAiRecommendation =
  | 'Approve'
  | 'Approve with exception'
  | 'Send back';

export interface AiFinanceReviewResult {
  recommendation: FinanceAiRecommendation;
  confidence: ConfidenceLevel;
  executiveReasoning: string;
  pillars: {
    extractionReview: string;
    policyReview: string;
    duplicateAndAnomalyReview: string;
  };
  suggestedFinanceComment: string;
  humanDecisionNote: string;
}

export type ConfidenceLevel = 'High' | 'Medium' | 'Low';

export interface AiFieldConfidences {
  merchant: ConfidenceLevel;
  date: ConfidenceLevel;
  invoiceNo: ConfidenceLevel;
  totalAmount: ConfidenceLevel;
  gstAmount: ConfidenceLevel;
  gstin: ConfidenceLevel;
  currency: ConfidenceLevel;
  paymentMode: ConfidenceLevel;
  category: ConfidenceLevel;
}

export interface AiSuggestedSnapshot {
  merchant: string;
  date: string;
  invoiceNo: string;
  amount: number;
  gstAmount: number;
  gstin: string;
  currency: string;
  paymentMode: PaymentMode;
  category: string;
}

export interface AiFieldOverride {
  field: string;
  aiValue: string;
  userValue: string;
}

export type PaymentMode =
  | 'Corporate Card'
  | 'Personal UPI'
  | 'Personal Card'
  | 'Cash'
  | 'NetBanking';

export const EXPENSE_CATEGORIES = [
  'Airfare',
  'Train/Bus',
  'Local Conveyance',
  'Fuel/Mileage',
  'Hotel Accommodation',
  'Meals',
  'Client Entertainment',
  'Telephone/Internet',
  'Training & Conference',
  'Miscellaneous',
] as const;

export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export const INDIAN_CITIES: { name: string; tier: CityTier }[] = [
  { name: 'Mumbai', tier: 'Tier 1' },
  { name: 'Delhi', tier: 'Tier 1' },
  { name: 'Bengaluru', tier: 'Tier 1' },
  { name: 'Chennai', tier: 'Tier 1' },
  { name: 'Pune', tier: 'Tier 2' },
  { name: 'Baramati', tier: 'Tier 2' },
];

export const DEPARTMENTS_LIST = [
  'Sales',
  'Supply Chain',
  'Manufacturing',
  'Finance',
  'HR',
] as const;

export interface UserProfile {
  id: string;
  name: string;
  employeeCode: string;
  email: string;
  role: UserRole;
  department: string;
  costCentre: string;
  grade: Grade;
  managerId: string;
  location: string;
  avatarUrl?: string;
  isActive: boolean;
  ownerUid: string;
}

export interface Department {
  id: string;
  code: string;
  name: string;
  headName: string;
  annualBudgetInr: number;
  ownerUid: string;
}

export interface CostCentre {
  id: string;
  code: string;
  name: string;
  department: string;
  location: string;
  ownerUid: string;
}

export interface ExpensePolicy {
  id: string;
  category: string;
  grade: Grade;
  limitPerDay: number;
  limitPerUnit: number;
  cityTier: PolicyCityTier;
  requiresReceipt: boolean;
  requiresPreApproval: boolean;
  gstEligible: boolean;
  notes: string;
  ownerUid: string;
}

export interface ExpenseLine {
  id: string;
  claimId: string;
  date: string; // YYYY-MM-DD
  category: ExpenseCategory | string;
  merchant: string;
  amount: number;
  gstAmount: number;
  gstin: string;
  currency?: string;
  invoiceNo: string;
  paymentMode: PaymentMode;
  receiptName: string;
  receiptMimeType: string;
  receiptUrl: string;
  preApprovalRef?: string;
  aiConfidenceScore: number; // 0-100
  aiExtracted?: boolean;
  aiCategoryReason?: string;
  aiFieldConfidence?: AiFieldConfidences;
  aiSuggestedValues?: AiSuggestedSnapshot;
  aiUserOverrides?: AiFieldOverride[];
  policyFlag: PolicyFlag;
  policyFlagReason: string;
  policyPermissibleLimit?: number;
  policyExcessAmount?: number;
  policyExceptionCodes?: string[];
  aiPolicyRecommendation?: string;
  justification: string;
  ownerUid: string;
}

export interface ApprovalLog {
  id: string;
  claimId: string;
  claimNo: string;
  action: string;
  byUserId: string;
  byName: string;
  byRole: UserRole;
  comments: string;
  timestamp: string;
  ownerUid: string;
}

export interface ExpenseClaim {
  id: string;
  claimNo: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  costCentre: string;
  grade: Grade;
  managerId: string;
  purpose: string;
  destination: string;
  cityTier: CityTier;
  tripFromDate: string; // YYYY-MM-DD
  tripToDate: string; // YYYY-MM-DD
  totalAmount: number;
  totalGstAmount: number;
  lineCount: number;
  status: ClaimStatus;
  submittedDate: string;
  hasPolicyViolation: boolean;
  isDuplicateFlagged: boolean;
  duplicateRefClaimNo: string;
  complianceScore?: number;
  aiComplianceSummary?: string;
  ownerUid: string;
  createdAt: string;
  updatedAt: string;
  lines: ExpenseLine[];
  approvalHistory: ApprovalLog[];
}

export interface AuditEntry {
  id: string;
  entityType: 'Claim' | 'ExpenseLine' | 'Policy' | 'User' | 'Department' | 'CostCentre';
  entityId: string;
  claimNo?: string;
  action: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  details: string;
  timestamp: string;
  ownerUid: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  claimId?: string;
  claimNo?: string;
  timestamp: string;
  read: boolean;
  targetRoles: UserRole[];
  targetUserId?: string;
}

export interface AiAnalyticsInsightsResult {
  executiveHeadline: string;
  keyTrends: string[];
  topExceptionsAndRisks: string[];
  recommendedActions: string[];
}

export interface AssistantSource {
  type: 'Policy Rule' | 'Dataset' | 'Compliance Engine';
  label: string;
  detail: string;
}

export interface AiAssistantResponse {
  answer: string;
  sources: AssistantSource[];
}

export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: AssistantSource[];
  error?: string;
  timestamp: string;
}

export type AppScreen =
  | 'dashboard'
  | 'new-claim'
  | 'my-claims'
  | 'claim-detail'
  | 'manager-inbox'
  | 'finance-queue'
  | 'finance-analytics'
  | 'admin'
  | 'how-ai-works';
