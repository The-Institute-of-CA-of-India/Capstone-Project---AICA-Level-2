import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';
import PptxGenJS from 'pptxgenjs';

const COLORS = {
  canvas: 'F2EFE7',
  white: 'FFFFFF',
  cobalt: '3368A0',
  cobaltDark: '244B75',
  azure: '66A3BF',
  sage: 'C8DFDB',
  sageLight: 'E8F2F0',
  slate900: '0F172A',
  slate700: '334155',
  slate600: '475569',
  slate500: '64748B',
  border: 'CBD5E1',
  borderSoft: 'E2E8F0',
  green: '16A34A',
  greenBg: 'DCFCE7',
  amber: 'D97706',
  amberBg: 'FEF3C7',
  red: 'DC2626',
  redBg: 'FEE2E2',
};

const FONT_UI = 'Segoe UI';
const FONT_MONO = 'Consolas';
const ATTRIBUTION = 'ClaimWise AI – AICA Level 2 Capstone Project | Developed by CA Akshay Burde (#168212)';
const TOTAL_SLIDES = 11;

interface ChromeOpts {
  category: string;
  title: string;
  duration: string;
  cumulative: string;
  slideNum: number;
}

function addSlideChrome(pptx: PptxGenJS, slide: PptxGenJS.Slide, opts: ChromeOpts) {
  slide.background = { color: COLORS.canvas };

  // Category kicker
  slide.addText(opts.category, {
    x: 0.6,
    y: 0.3,
    w: 8.6,
    h: 0.25,
    fontFace: FONT_UI,
    fontSize: 10,
    bold: true,
    color: COLORS.cobalt,
    margin: 0,
  });

  // Slide Title
  slide.addText(opts.title, {
    x: 0.6,
    y: 0.56,
    w: 9.2,
    h: 0.52,
    fontFace: FONT_UI,
    fontSize: 22,
    bold: true,
    color: COLORS.slate900,
    margin: 0,
  });

  // Top-right Time-Budget Pill
  slide.addShape(pptx.ShapeType.roundRect, {
    x: 9.95,
    y: 0.38,
    w: 2.78,
    h: 0.58,
    fill: { color: COLORS.sageLight },
    line: { color: COLORS.azure, width: 1 },
    rectRadius: 0.08,
  });
  slide.addText(`TIME ${opts.duration}  |  CUM ${opts.cumulative}`, {
    x: 10.0,
    y: 0.43,
    w: 2.68,
    h: 0.24,
    fontFace: FONT_MONO,
    fontSize: 9.5,
    bold: true,
    color: COLORS.cobaltDark,
    align: 'center',
    margin: 0,
  });
  slide.addText('12:00 MAX BUDGET', {
    x: 10.0,
    y: 0.69,
    w: 2.68,
    h: 0.2,
    fontFace: FONT_MONO,
    fontSize: 8,
    color: COLORS.slate600,
    align: 'center',
    margin: 0,
  });

  // Header divider
  slide.addShape(pptx.ShapeType.line, {
    x: 0.6,
    y: 1.18,
    w: 12.13,
    h: 0,
    line: { color: COLORS.border, width: 1 },
  });

  // Footer divider
  slide.addShape(pptx.ShapeType.line, {
    x: 0.6,
    y: 6.96,
    w: 12.13,
    h: 0,
    line: { color: COLORS.border, width: 1 },
  });

  // Footer left
  slide.addText(ATTRIBUTION, {
    x: 0.6,
    y: 7.05,
    w: 10.2,
    h: 0.26,
    fontFace: FONT_UI,
    fontSize: 9,
    color: COLORS.slate600,
    margin: 0,
  });

  // Footer right slide number
  slide.addText(`Slide ${opts.slideNum} / ${TOTAL_SLIDES}`, {
    x: 11.1,
    y: 7.05,
    w: 1.63,
    h: 0.26,
    fontFace: FONT_MONO,
    fontSize: 9.5,
    bold: true,
    color: COLORS.cobalt,
    align: 'right',
    margin: 0,
  });
}

function addCard(
  pptx: PptxGenJS,
  slide: PptxGenJS.Slide,
  opts: {
    x: number;
    y: number;
    w: number;
    h: number;
    fill?: string;
    borderColor?: string;
    topBarColor?: string;
  }
) {
  slide.addShape(pptx.ShapeType.roundRect, {
    x: opts.x,
    y: opts.y,
    w: opts.w,
    h: opts.h,
    fill: { color: opts.fill ?? COLORS.white },
    line: { color: opts.borderColor ?? COLORS.border, width: 1 },
    rectRadius: 0.08,
  });

  if (opts.topBarColor) {
    slide.addShape(pptx.ShapeType.rect, {
      x: opts.x + 0.08,
      y: opts.y + 0.01,
      w: opts.w - 0.16,
      h: 0.06,
      fill: { color: opts.topBarColor },
      line: { color: opts.topBarColor, width: 0.5 },
    });
  }
}

async function generatePresentation() {
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_WIDE'; // 13.333" x 7.5"
  pptx.author = 'CA Akshay Burde (#168212)';
  pptx.company = 'Nova Foods India Pvt Ltd';
  pptx.subject = 'ClaimWise AI — AICA Level 2 Capstone Project';
  pptx.title = 'ClaimWise AI: From Receipt to Reimbursement, Powered by AI';

  // =========================================================================
  // SLIDE 1: TITLE & CAPSTONE OVERVIEW (00:45 | Cum 00:45)
  // =========================================================================
  {
    const s = pptx.addSlide();
    s.background = { color: COLORS.cobalt };

    // Subtle right geometric panel
    s.addShape(pptx.ShapeType.rect, {
      x: 9.25,
      y: 0,
      w: 4.083,
      h: 7.5,
      fill: { color: COLORS.cobaltDark },
      line: { color: COLORS.cobaltDark, width: 0.5 },
    });

    // Top bar badge & timing
    s.addShape(pptx.ShapeType.roundRect, {
      x: 0.75,
      y: 0.55,
      w: 4.55,
      h: 0.42,
      fill: { color: COLORS.cobaltDark },
      line: { color: COLORS.azure, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('AICA LEVEL 2 CAPSTONE PROJECT  ·  NOVA FOODS INDIA PVT LTD', {
      x: 0.85,
      y: 0.62,
      w: 4.35,
      h: 0.28,
      fontFace: FONT_UI,
      fontSize: 9.5,
      bold: true,
      color: COLORS.sage,
      margin: 0,
    });

    s.addShape(pptx.ShapeType.roundRect, {
      x: 9.65,
      y: 0.55,
      w: 3.05,
      h: 0.42,
      fill: { color: COLORS.cobalt },
      line: { color: COLORS.azure, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('TIME 00:45  |  12:00 DECK (11 SLIDES)', {
      x: 9.72,
      y: 0.63,
      w: 2.91,
      h: 0.26,
      fontFace: FONT_MONO,
      fontSize: 9,
      bold: true,
      color: COLORS.white,
      align: 'center',
      margin: 0,
    });

    // Hero Brand & Headline
    s.addText('ClaimWise AI', {
      x: 0.75,
      y: 1.45,
      w: 8.1,
      h: 0.85,
      fontFace: FONT_UI,
      fontSize: 44,
      bold: true,
      color: COLORS.white,
      margin: 0,
    });
    s.addText('From Receipt to Reimbursement,\nPowered by AI.', {
      x: 0.75,
      y: 2.38,
      w: 8.1,
      h: 1.25,
      fontFace: FONT_UI,
      fontSize: 26,
      bold: true,
      color: COLORS.sage,
      margin: 0,
    });
    s.addText(
      'An enterprise employee expense & GST compliance platform pairing deterministic Indian tax/policy rules with Gemini multimodal extraction, anomaly risk intelligence, and Human-in-the-Loop governance.',
      {
        x: 0.75,
        y: 3.78,
        w: 7.9,
        h: 1.1,
        fontFace: FONT_UI,
        fontSize: 13.5,
        color: 'E2E8F0',
        lineSpacingMultiple: 1.25,
        margin: 0,
      }
    );

    // Right column: 4 Grounded Workspace Stats
    const coverStats = [
      { num: '60', label: 'Multi-City INR Claims', sub: 'Draft to Paid lifecycle' },
      { num: '60', label: 'Deterministic Policy Rules', sub: 'Category × Grade G1–G5 × Tier' },
      { num: '5', label: 'Server-Side Gemini APIs', sub: 'IDP, Policy, Agent, Insights, Chat' },
      { num: '20', label: 'Users Across 6 Cities', sub: '4 RBAC Roles · 5 Departments' },
    ];
    coverStats.forEach((st, idx) => {
      const cy = 1.45 + idx * 1.25;
      s.addShape(pptx.ShapeType.roundRect, {
        x: 9.65,
        y: cy,
        w: 3.05,
        h: 1.05,
        fill: { color: COLORS.cobalt },
        line: { color: COLORS.azure, width: 1 },
        rectRadius: 0.08,
      });
      s.addText(st.num, {
        x: 9.85,
        y: cy + 0.14,
        w: 0.8,
        h: 0.5,
        fontFace: FONT_MONO,
        fontSize: 26,
        bold: true,
        color: COLORS.sage,
        margin: 0,
      });
      s.addText(st.label, {
        x: 10.65,
        y: cy + 0.18,
        w: 1.95,
        h: 0.34,
        fontFace: FONT_UI,
        fontSize: 11.5,
        bold: true,
        color: COLORS.white,
        margin: 0,
      });
      s.addText(st.sub, {
        x: 10.65,
        y: cy + 0.54,
        w: 1.95,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 9.5,
        color: 'CBD5E1',
        margin: 0,
      });
    });

    // Bottom attribution bar
    s.addShape(pptx.ShapeType.line, {
      x: 0.75,
      y: 6.55,
      w: 11.95,
      h: 0,
      line: { color: COLORS.azure, width: 1 },
    });
    s.addText(ATTRIBUTION, {
      x: 0.75,
      y: 6.72,
      w: 9.5,
      h: 0.32,
      fontFace: FONT_UI,
      fontSize: 11,
      bold: true,
      color: COLORS.white,
      margin: 0,
    });
    s.addText('Slide 1 / 11', {
      x: 11.2,
      y: 6.72,
      w: 1.5,
      h: 0.32,
      fontFace: FONT_MONO,
      fontSize: 10,
      bold: true,
      color: COLORS.sage,
      align: 'right',
      margin: 0,
    });

    s.addNotes(
      [
        'TIME TARGET: 00:45 (Cumulative 00:45 / 12:00)',
        '',
        'OPENING TALKING POINTS:',
        '- Hello everyone, I am CA Akshay Burde (#168212). Today I am presenting ClaimWise AI, my AICA Level 2 Capstone Project built for Nova Foods India Pvt Ltd.',
        '- ClaimWise AI transforms corporate expense reimbursements from receipt capture all the way to NEFT payout.',
        '- As a Chartered Accountant, my core design thesis was clear: let Generative AI handle messy receipts, explanations, and synthesis—while deterministic business rules handle every rupee limit and tax check, with humans keeping final approval authority.',
        '- In the next 12 minutes, I will cover the business problem, our full-stack technical architecture, four AI & rule-engine solutions, security & PWA engineering, and a live 2-minute application walkthrough.',
        '',
        'TRANSITION: Let us look at the operational problem ClaimWise AI solves.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 2: PROBLEM STATEMENT & ENTERPRISE CONTEXT (01:00 | Cum 01:45)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '01 · BUSINESS PROBLEM & CONTEXT',
      title: 'Why Traditional Expense Workflows Fail Indian Enterprises',
      duration: '01:00',
      cumulative: '01:45',
      slideNum: 2,
    });

    const problems = [
      {
        num: '01',
        title: 'Slow Manual Receipt Entry',
        metric: '5–8 mins / claim',
        color: COLORS.cobalt,
        body: 'Employees manually key in merchant names, dates, invoice numbers, and tax splits from photos or PDFs—leading to frequent typos and abandoned drafts.',
      },
      {
        num: '02',
        title: 'GSTIN & Input Tax Credit Leakage',
        metric: '28% max GST slab risk',
        color: COLORS.red,
        body: 'Finance teams only sample invoices weeks later. Invalid 15-character Indian GSTINs or mismatched GST amounts directly cause ITC credit disallowances.',
      },
      {
        num: '03',
        title: 'Opaque Grade & City-Tier Policies',
        metric: 'Grades G1–G5 · Tier 1/2',
        color: COLORS.amber,
        body: 'Employees guess hotel, meal, and travel caps buried inside static HR PDFs—triggering avoidable policy breaches and 30%+ claim send-backs.',
      },
      {
        num: '04',
        title: 'Missed Duplicates & 5–10 Day SLA',
        metric: 'Split bills & weekend claims',
        color: COLORS.cobaltDark,
        body: 'Cross-claim fuzzy duplicates, split bills below approval caps, and baseline spend spikes go unnoticed during manual line-by-line Finance review.',
      },
    ];

    problems.forEach((p, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.6 + col * 6.2;
      const y = 1.42 + row * 2.22;
      addCard(pptx, s, { x, y, w: 5.93, h: 2.02, topBarColor: p.color });

      s.addText(p.num, {
        x: x + 0.24,
        y: y + 0.22,
        w: 0.55,
        h: 0.4,
        fontFace: FONT_MONO,
        fontSize: 16,
        bold: true,
        color: p.color,
        margin: 0,
      });
      s.addText(p.title, {
        x: x + 0.8,
        y: y + 0.22,
        w: 3.3,
        h: 0.36,
        fontFace: FONT_UI,
        fontSize: 14,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addText(p.metric, {
        x: x + 4.05,
        y: y + 0.24,
        w: 1.65,
        h: 0.3,
        fontFace: FONT_MONO,
        fontSize: 9.5,
        bold: true,
        color: p.color,
        align: 'right',
        margin: 0,
      });
      s.addText(p.body, {
        x: x + 0.24,
        y: y + 0.72,
        w: 5.45,
        h: 1.1,
        fontFace: FONT_UI,
        fontSize: 11.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.25,
        margin: 0,
      });
    });

    // Bottom Context Strip
    addCard(pptx, s, {
      x: 0.6,
      y: 5.92,
      w: 12.13,
      h: 0.84,
      fill: COLORS.sageLight,
      borderColor: COLORS.azure,
    });
    s.addText('NOVA FOODS INDIA PVT LTD · ENTERPRISE SCOPE', {
      x: 0.85,
      y: 6.03,
      w: 11.6,
      h: 0.24,
      fontFace: FONT_UI,
      fontSize: 9.5,
      bold: true,
      color: COLORS.cobaltDark,
      margin: 0,
    });
    s.addText(
      '5 Departments (Sales, Supply Chain, Manufacturing, Finance, HR)  ·  6 Cost Centres (Mumbai, Pune, Baramati, Delhi, Bengaluru, Chennai)  ·  5-Stage Workflow: Draft → Submitted → Manager → Finance → Paid',
      {
        x: 0.85,
        y: 6.3,
        w: 11.6,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 11,
        color: COLORS.slate900,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:00 (Cumulative 01:45 / 12:00)',
        '',
        'KEY POINTS:',
        '- Nova Foods India operates across 6 cities and 5 departments with 5 employee grades (G1 to G5).',
        '- Four pain points drive high reimbursement cost and friction:',
        '  1. Manual entry takes 5–8 minutes per claim.',
        '  2. Invalid 15-character GSTINs or wrong GST amounts leak Input Tax Credit.',
        '  3. Employees cannot easily navigate Grade x City-Tier caps inside static PDFs.',
        '  4. Finance takes 5–10 days manually checking claims yet still misses cross-claim duplicates and split bills.',
        '',
        'TRANSITION: Next, here is the full-stack technical architecture we engineered to solve all four.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 3: FULL-STACK ARCHITECTURE & TECH STACK (01:00 | Cum 02:45)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '02 · SYSTEM ARCHITECTURE & STACK',
      title: 'Full-Stack Architecture: Client PWA, Server AI Proxy & Dual Persistence',
      duration: '01:00',
      cumulative: '02:45',
      slideNum: 3,
    });

    const tiers = [
      {
        x: 0.6,
        header: 'TIER 1 · CLIENT SPA & DESKTOP PWA',
        accent: COLORS.cobalt,
        stack: 'React 19 · TypeScript · Tailwind CSS v4 · Vite 8',
        bullets: [
          '4 RBAC Portals: Employee, Manager, Finance Controller, Admin',
          'Deterministic TypeScript Engines: policyEngine.ts, riskEngine.ts, analyticsEngine.ts',
          'Client-side receipt compression & CSV/Excel export',
          'Installable Desktop PWA via vite-plugin-pwa + Workbox offline caching',
        ],
      },
      {
        x: 4.82,
        header: 'TIER 2 · EXPRESS AI PROXY (/api/*)',
        accent: COLORS.cobaltDark,
        stack: 'Node.js · Express · @google/genai SDK',
        bullets: [
          'Server-side GEMINI_API_KEY isolation (never exposed in browser bundle)',
          '5 Typed JSON Endpoints: extract-receipt, compliance-check, finance-review-agent, analytics-insights, assistant',
          'Resilient Model Routing: gemini-3.1-flash-lite → automatic gemini-4-hydrogen fallback',
          'SHA-256 request caching (extractionCache) + HTTP 429/503 backoff',
        ],
      },
      {
        x: 9.04,
        header: 'TIER 3 · DUAL PERSISTENCE LAYER',
        accent: COLORS.green,
        stack: 'Browser localStorage + Optional Firebase Firestore',
        bullets: [
          'Zero-Friction Demo Mode: Immediate browser persistence with 60 seeded claims & 60 rules',
          'Optional Google Cloud Sync via Firebase Auth (signInWithPopup) moved cleanly to sidebar',
          'Real-time Firestore onSnapshot listeners across 6 collections + subcollections',
          'Eight-Pillar firestore.rules enforcing verified auth & strict payload schemas',
        ],
      },
    ];

    tiers.forEach((t, idx) => {
      addCard(pptx, s, { x: t.x, y: 1.42, w: 3.69, h: 4.35, topBarColor: t.accent });

      s.addText(t.header, {
        x: t.x + 0.2,
        y: 1.62,
        w: 3.29,
        h: 0.28,
        fontFace: FONT_UI,
        fontSize: 10,
        bold: true,
        color: t.accent,
        margin: 0,
      });
      s.addText(t.stack, {
        x: t.x + 0.2,
        y: 1.92,
        w: 3.29,
        h: 0.42,
        fontFace: FONT_MONO,
        fontSize: 9.5,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addShape(pptx.ShapeType.line, {
        x: t.x + 0.2,
        y: 2.42,
        w: 3.29,
        h: 0,
        line: { color: COLORS.borderSoft, width: 1 },
      });

      const textRuns = t.bullets.map((b) => ({
        text: b,
        options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
      }));
      s.addText(textRuns, {
        x: t.x + 0.2,
        y: 2.56,
        w: 3.29,
        h: 3.05,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.2,
        valign: 'top',
        margin: 0,
      });

      if (idx < 2) {
        s.addText('⇄', {
          x: t.x + 3.71,
          y: 3.25,
          w: 0.5,
          h: 0.45,
          fontFace: FONT_UI,
          fontSize: 20,
          bold: true,
          color: COLORS.cobalt,
          align: 'center',
          margin: 0,
        });
      }
    });

    // Bottom Architecture Principle Strip
    addCard(pptx, s, {
      x: 0.6,
      y: 5.96,
      w: 12.13,
      h: 0.8,
      fill: COLORS.sageLight,
      borderColor: COLORS.azure,
    });
    s.addText('CORE ARCHITECTURAL PRINCIPLE: SEPARATION OF RESPONSIBILITIES', {
      x: 0.85,
      y: 6.06,
      w: 11.6,
      h: 0.24,
      fontFace: FONT_UI,
      fontSize: 9.5,
      bold: true,
      color: COLORS.cobaltDark,
      margin: 0,
    });
    s.addText(
      'Deterministic TypeScript engines compute all rupee caps, GST math, and duplicate scores; Gemini models strictly handle unstructured OCR, natural-language explanations, synthesis, and Q&A.',
      {
        x: 0.85,
        y: 6.32,
        w: 11.6,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 11,
        color: COLORS.slate900,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:00 (Cumulative 02:45 / 12:00)',
        '',
        'KEY POINTS:',
        '- Three cleanly separated tiers:',
        '  1. Client SPA & Desktop PWA: React 19 + TypeScript + Tailwind v4 running inside Vite 8, with deterministic TypeScript policy and risk engines executing instantaneously on the client.',
        '  2. Express AI Proxy: All 5 Gemini endpoints live server-side in Express so API keys never leak to the browser. We enforce strict JSON responseSchemas and route primary calls to gemini-3.1-flash-lite with automatic fallback to gemini-4-hydrogen.',
        '  3. Dual Persistence: Works offline/locally out of the box via localStorage, while offering optional Google Sign-In + Firebase Firestore real-time sync in the sidebar.',
        '',
        'TRANSITION: Let us dive into the first major technical solution—AI Intelligent Document Processing.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 4: AI SOLUTION 1 — MULTIMODAL RECEIPT IDP (01:15 | Cum 04:00)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '03 · AI SOLUTION 1 — INTELLIGENT DOCUMENT PROCESSING',
      title: 'Multimodal Receipt Extraction, GSTIN Guard & Override Audit',
      duration: '01:15',
      cumulative: '04:00',
      slideNum: 4,
    });

    // Top 5-step horizontal pipeline
    const steps = [
      { n: '1', t: 'Upload Receipt', d: 'JPG, PNG, WEBP or PDF\nClient image resize' },
      { n: '2', t: 'Gemini Vision OCR', d: '/api/ai/extract-receipt\nJSON responseSchema' },
      { n: '3', t: 'Auto-Fill 9 Fields', d: 'Merchant, Date, Inv#, Total,\nGST, GSTIN, Currency, Mode' },
      { n: '4', t: 'Confidence & GST', d: 'High/Med/Low tags\n15-char GSTIN & 28% check' },
      { n: '5', t: 'Human Override Log', d: 'AI-suggested vs user-final\naudit diff persisted' },
    ];
    steps.forEach((st, i) => {
      const sx = 0.6 + i * 2.48;
      addCard(pptx, s, { x: sx, y: 1.4, w: 2.22, h: 1.38, topBarColor: COLORS.cobalt });
      s.addText(`STEP ${st.n}`, {
        x: sx + 0.14,
        y: 1.54,
        w: 1.94,
        h: 0.22,
        fontFace: FONT_MONO,
        fontSize: 8.5,
        bold: true,
        color: COLORS.cobalt,
        margin: 0,
      });
      s.addText(st.t, {
        x: sx + 0.14,
        y: 1.76,
        w: 1.94,
        h: 0.28,
        fontFace: FONT_UI,
        fontSize: 11.5,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addText(st.d, {
        x: sx + 0.14,
        y: 2.08,
        w: 1.94,
        h: 0.58,
        fontFace: FONT_UI,
        fontSize: 9.5,
        color: COLORS.slate600,
        lineSpacingMultiple: 1.15,
        margin: 0,
      });
      if (i < 4) {
        s.addText('→', {
          x: sx + 2.22,
          y: 1.9,
          w: 0.26,
          h: 0.35,
          fontFace: FONT_UI,
          fontSize: 15,
          bold: true,
          color: COLORS.cobalt,
          align: 'center',
          margin: 0,
        });
      }
    });

    // Bottom 3 technical columns
    // Col 1: Schema & Category Rationale
    addCard(pptx, s, { x: 0.6, y: 3.02, w: 3.9, h: 3.74 });
    s.addText('Structured Schema & Category AI', {
      x: 0.82,
      y: 3.22,
      w: 3.46,
      h: 0.32,
      fontFace: FONT_UI,
      fontSize: 13,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'Enforced Gemini Type.OBJECT responseSchema prevents free-text parsing errors.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 7 },
        },
        {
          text: 'Auto-classifies across 10 corporate expense categories with a 1-line explanation (e.g., "Classified as Hotel Accommodation — room charges & GSTIN detected").',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 7 },
        },
        {
          text: 'Normalizes invoice dates to ISO YYYY-MM-DD and maps payment mode to 5 corporate modes.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 7 },
        },
      ],
      {
        x: 0.82,
        y: 3.64,
        w: 3.46,
        h: 2.95,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.22,
        margin: 0,
      }
    );

    // Col 2: Confidence & GSTIN Validation
    addCard(pptx, s, { x: 4.71, y: 3.02, w: 3.9, h: 3.74 });
    s.addText('Confidence UX & GST Guardrails', {
      x: 4.93,
      y: 3.22,
      w: 3.46,
      h: 0.32,
      fontFace: FONT_UI,
      fontSize: 13,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    // Example confidence callout inside card
    s.addShape(pptx.ShapeType.roundRect, {
      x: 4.93,
      y: 3.66,
      w: 3.46,
      h: 0.72,
      fill: { color: COLORS.amberBg },
      line: { color: COLORS.amber, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('Low Confidence Highlight (Amber)', {
      x: 5.06,
      y: 3.74,
      w: 3.2,
      h: 0.24,
      fontFace: FONT_UI,
      fontSize: 10,
      bold: true,
      color: COLORS.amber,
      margin: 0,
    });
    s.addText('Faded thermal ink fields highlighted in amber; user can always edit & override.', {
      x: 5.06,
      y: 3.98,
      w: 3.2,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 9.5,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText(
      [
        {
          text: '15-char Indian GSTIN regex: ^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 7 },
        },
        {
          text: 'Slab consistency check flags GST > 28% of base or GST = 0 when valid GSTIN is present.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 7 },
        },
      ],
      {
        x: 4.93,
        y: 4.54,
        w: 3.46,
        h: 2.05,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.22,
        margin: 0,
      }
    );

    // Col 3: Resilience & Audit Log
    addCard(pptx, s, { x: 8.82, y: 3.02, w: 3.91, h: 3.74 });
    s.addText('Resilience & Override Audit Log', {
      x: 9.04,
      y: 3.22,
      w: 3.47,
      h: 0.32,
      fontFace: FONT_UI,
      fontSize: 13,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'SHA-256 hash caching of uploaded file bytes prevents duplicate Gemini quota hits on re-uploads.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
        {
          text: 'Automatic retry + failover from gemini-3.1-flash-lite to gemini-4-hydrogen on 429/503 responses.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
        {
          text: 'Every line stores aiSuggested vs userFinal snapshots (computeAiOverrides), written to auditTrail.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
      ],
      {
        x: 9.04,
        y: 3.64,
        w: 3.47,
        h: 2.95,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.22,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:15 (Cumulative 04:00 / 12:00)',
        '',
        'KEY POINTS:',
        '- When an employee uploads a receipt (JPG, PNG, WEBP, or PDF), client-side compression shrinks large phone photos before sending to /api/ai/extract-receipt.',
        '- Gemini extracts all 9 fields using a strict JSON responseSchema plus a one-line category classification reason.',
        '- Each field receives a High, Medium, or Low confidence rating; Low-confidence fields turn amber so the employee knows exactly what to double-check.',
        '- Deterministic server validation checks the 15-character Indian GSTIN format and verifies that GST does not exceed the 28% Indian slab.',
        '- Crucially for audit governance, computeAiOverrides() logs every difference between AI-extracted values and final user-submitted values.',
        '',
        'TRANSITION: Once the line is populated, our Deterministic Policy Engine validates it against corporate rules.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 5: AI SOLUTION 2 — POLICY COMPLIANCE ENGINE (01:15 | Cum 05:15)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '04 · AI SOLUTION 2 — POLICY COMPLIANCE ENGINE',
      title: 'Zero-Hallucination Policy Rules + AI Pre-Submission Check',
      duration: '01:15',
      cumulative: '05:15',
      slideNum: 5,
    });

    // Top rule principle banner
    addCard(pptx, s, {
      x: 0.6,
      y: 1.38,
      w: 12.13,
      h: 0.68,
      fill: COLORS.sageLight,
      borderColor: COLORS.azure,
    });
    s.addText(
      'GOLDEN RULE: AI NEVER INVENTS LIMITS. All rupee caps come deterministically from expense_policies (Category × Grade G1–G5 × City Tier 1/2/All). Gemini strictly explains results and recommends fixes.',
      {
        x: 0.82,
        y: 1.5,
        w: 11.7,
        h: 0.44,
        fontFace: FONT_UI,
        fontSize: 11,
        bold: true,
        color: COLORS.cobaltDark,
        margin: 0,
      }
    );

    // Left: 5 Deterministic Rules Table
    addCard(pptx, s, { x: 0.6, y: 2.24, w: 6.35, h: 4.52 });
    s.addText('5 Deterministic Line-Level Policy Checks (policyEngine.ts)', {
      x: 0.82,
      y: 2.42,
      w: 5.9,
      h: 0.3,
      fontFace: FONT_UI,
      fontSize: 13,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });

    const ruleRows: PptxGenJS.TableRow[] = [
      [
        { text: 'Check', options: { bold: true, fill: { color: COLORS.cobalt }, color: COLORS.white } },
        { text: 'Deterministic Rule Logic', options: { bold: true, fill: { color: COLORS.cobalt }, color: COLORS.white } },
        { text: 'Outcome', options: { bold: true, fill: { color: COLORS.cobalt }, color: COLORS.white } },
      ],
      [
        { text: '1. Grade & Tier Cap', options: { bold: true } },
        { text: 'Matches category + grade (G1–G5) + Tier 1/2/All in expense_policies' },
        { text: 'Red Exception + Excess INR', options: { color: COLORS.red, bold: true } },
      ],
      [
        { text: '2. Missing Receipt', options: { bold: true } },
        { text: 'Checks policy.requiresReceipt against uploaded receiptName/URL' },
        { text: 'Mandatory Warning / Block', options: { color: COLORS.amber, bold: true } },
      ],
      [
        { text: '3. Weekend / Holiday', options: { bold: true } },
        { text: 'UTC weekday check + 2026 Indian Corporate Holiday Calendar' },
        { text: 'Flags for Justification', options: { color: COLORS.amber, bold: true } },
      ],
      [
        { text: '4. Outside Trip Dates', options: { bold: true } },
        { text: 'Validates line.date ∈ [tripFromDate, tripToDate]' },
        { text: 'Policy Exception Raised', options: { color: COLORS.red, bold: true } },
      ],
      [
        { text: '5. Pre-Approval Ref', options: { bold: true } },
        { text: 'Checks policy.requiresPreApproval (e.g., Airfare / Client Ent.)' },
        { text: 'Requires Ref ID to Submit', options: { color: COLORS.red, bold: true } },
      ],
    ];

    s.addTable(ruleRows, {
      x: 0.82,
      y: 2.84,
      w: 5.91,
      colW: [1.55, 2.76, 1.6],
      fontFace: FONT_UI,
      fontSize: 9.5,
      color: COLORS.slate700,
      border: { type: 'solid', pt: 0.5, color: COLORS.border },
      valign: 'middle',
      rowH: [0.38, 0.64, 0.64, 0.64, 0.64, 0.64],
    });

    // Right: Inline Exception Card + Pre-Submission Check
    addCard(pptx, s, { x: 7.18, y: 2.24, w: 5.55, h: 2.25, topBarColor: COLORS.red });
    s.addText('Inline Exception UI & Mandatory Justification Gate', {
      x: 7.4,
      y: 2.42,
      w: 5.1,
      h: 0.3,
      fontFace: FONT_UI,
      fontSize: 12.5,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addShape(pptx.ShapeType.roundRect, {
      x: 7.4,
      y: 2.8,
      w: 5.11,
      h: 0.9,
      fill: { color: COLORS.redBg },
      line: { color: COLORS.red, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('Policy Exception · Claimed ₹8,500 | Permissible ₹6,000 | Excess ₹2,500', {
      x: 7.52,
      y: 2.88,
      w: 4.87,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9,
      bold: true,
      color: COLORS.red,
      margin: 0,
    });
    s.addText(
      'Hotel limit for Grade G3 in Tier-1 city exceeded. Provide business justification to submit.',
      {
        x: 7.52,
        y: 3.16,
        w: 4.87,
        h: 0.42,
        fontFace: FONT_UI,
        fontSize: 9.8,
        color: COLORS.slate900,
        margin: 0,
      }
    );
    s.addText(
      'Submission is blocked until a written justification is entered; routed to Finance with a red "Policy Exception" tag.',
      {
        x: 7.4,
        y: 3.82,
        w: 5.11,
        h: 0.52,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        margin: 0,
      }
    );

    // Bottom Right: Claim-Level AI Pre-Submission Check
    addCard(pptx, s, { x: 7.18, y: 4.66, w: 5.55, h: 2.1, topBarColor: COLORS.cobalt });
    s.addText('AI Pre-Submission Check & 0–100 Compliance Score', {
      x: 7.4,
      y: 4.84,
      w: 3.7,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 12.5,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addShape(pptx.ShapeType.roundRect, {
      x: 11.2,
      y: 4.82,
      w: 1.31,
      h: 0.5,
      fill: { color: COLORS.sageLight },
      line: { color: COLORS.cobalt, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('84 / 100', {
      x: 11.22,
      y: 4.92,
      w: 1.27,
      h: 0.3,
      fontFace: FONT_MONO,
      fontSize: 13,
      bold: true,
      color: COLORS.cobalt,
      align: 'center',
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'Reviews the full multi-line claim via /api/ai/compliance-check before submission.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 6 },
        },
        {
          text: 'Lists all deterministic line issues alongside plain-English fix suggestions to prevent Manager/Finance rejections.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 6 },
        },
      ],
      {
        x: 7.4,
        y: 5.42,
        w: 5.11,
        h: 1.22,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.2,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:15 (Cumulative 05:15 / 12:00)',
        '',
        'KEY POINTS:',
        '- A major risk with LLMs in finance is hallucinating expense limits. We solved this by making policy rules 100% deterministic.',
        '- policyEngine.ts evaluates 5 checks against our 60-rule expense_policies table: Grade x City-Tier caps, missing receipts, weekend/2026 Indian corporate holidays, out-of-trip-window dates, and missing pre-approval IDs.',
        '- If a line breaches policy, an inline Policy Exception card shows Claimed vs Permissible vs Excess INR and blocks submission unless the employee provides justification.',
        '- Before submitting, employees can run the AI Pre-Submission Check to get a 0–100 Compliance Score and a concrete fix checklist.',
        '',
        'TRANSITION: Beyond single-line policy checks, how do we catch fraud and duplicates across claims?',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 6: AI SOLUTION 3 — DUPLICATE, ANOMALY & REVIEW AGENT (01:00 | Cum 06:15)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '05 · AI SOLUTION 3 — RISK & REVIEW INTELLIGENCE',
      title: 'Cross-Claim Duplicate Detection, Anomaly Engine & AI Review Agent',
      duration: '01:00',
      cumulative: '06:15',
      slideNum: 6,
    });

    // Col 1: Duplicate Detection
    addCard(pptx, s, { x: 0.6, y: 1.42, w: 3.88, h: 4.35, topBarColor: COLORS.red });
    s.addText('1. Duplicate Detection', {
      x: 0.82,
      y: 1.62,
      w: 3.44,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 14,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText('riskEngine.ts · Cross & Intra-Claim', {
      x: 0.82,
      y: 1.96,
      w: 3.44,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9.5,
      color: COLORS.red,
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'Exact Invoice Match (95–99%): Flags identical invoice numbers across any employee or claim.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'Fuzzy Employee Match (86–94%): Triggers when same employee + similar amount + close dates (±3 days) + normalized merchant match.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'Intra-Claim Check: Catches duplicate line items submitted twice inside the same claim.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
      ],
      {
        x: 0.82,
        y: 2.36,
        w: 3.44,
        h: 3.2,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.22,
        margin: 0,
      }
    );

    // Col 2: Behavioral Anomalies
    addCard(pptx, s, { x: 4.72, y: 1.42, w: 3.88, h: 4.35, topBarColor: COLORS.amber });
    s.addText('2. Behavioral Anomaly Engine', {
      x: 4.94,
      y: 1.62,
      w: 3.44,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 14,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText('4 Automated Forensic Signals', {
      x: 4.94,
      y: 1.96,
      w: 3.44,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9.5,
      color: COLORS.amber,
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'Round-Number Amounts: Flags exact ₹500/₹1,000 multiples (common cash/estimated bill signal).',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
        {
          text: '6-Month Baseline Spike: Compares line amount against the employee’s historical 6-month category average.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
        {
          text: 'Just-Below-Limit Pattern: Detects repeated claims clustered at 90–100% of policy cap.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
        {
          text: 'Split-Bill Detection: Spots multiple same-day/same-merchant charges whose combined sum breaches policy limit.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 },
        },
      ],
      {
        x: 4.94,
        y: 2.36,
        w: 3.44,
        h: 3.25,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.2,
        margin: 0,
      }
    );

    // Col 3: Risk Panel & AI Finance Review Agent
    addCard(pptx, s, { x: 8.84, y: 1.42, w: 3.89, h: 4.35, topBarColor: COLORS.cobalt });
    s.addText('3. AI Finance Review Agent', {
      x: 9.06,
      y: 1.62,
      w: 3.45,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 14,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText('/api/ai/finance-review-agent', {
      x: 9.06,
      y: 1.96,
      w: 3.45,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9.5,
      color: COLORS.cobalt,
      margin: 0,
    });
    s.addText(
      [
        {
          text: 'Risk Indicators Panel: Surfaces Low / Medium / High Risk Level + plain-English reasons for Manager & Finance.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'End-to-End Agent Synthesis: Reads OCR override diffs, policy violations, GST flags, duplicates, and anomalies together.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'Draft Verdict: Recommends Approve, Approve with exception, or Send back with full reasoning.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
      ],
      {
        x: 9.06,
        y: 2.36,
        w: 3.45,
        h: 3.25,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.22,
        margin: 0,
      }
    );

    // Human-in-the-Loop footer callout
    addCard(pptx, s, {
      x: 0.6,
      y: 5.96,
      w: 12.13,
      h: 0.8,
      fill: COLORS.sageLight,
      borderColor: COLORS.azure,
    });
    s.addText('HUMAN-IN-THE-LOOP ACCOUNTABILITY GUARANTEE', {
      x: 0.85,
      y: 6.06,
      w: 11.6,
      h: 0.24,
      fontFace: FONT_UI,
      fontSize: 9.5,
      bold: true,
      color: COLORS.cobaltDark,
      margin: 0,
    });
    s.addText(
      'AI never auto-approves or disburses funds. Every AI Review Agent recommendation is logged to auditTrail and requires explicit Finance Controller sign-off before NEFT payout.',
      {
        x: 0.85,
        y: 6.32,
        w: 11.6,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 11,
        color: COLORS.slate900,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:00 (Cumulative 06:15 / 12:00)',
        '',
        'KEY POINTS:',
        '- riskEngine.ts performs two forensic layers on every claim:',
        '  1. Duplicate Detection: catches exact invoice matches across claims and fuzzy matches (same employee + similar amount + close dates + merchant).',
        '  2. Four Anomaly Heuristics: round-number totals, spikes vs the employee’s 6-month category average, repeated claims clustered just below policy caps, and split bills.',
        '- Managers and Finance see a plain-English Risk Indicators panel (Low, Medium, or High).',
        '- Finance Controllers can click "AI Review Agent" to synthesize OCR overrides, policy checks, and risk signals into a draft recommendation—while keeping 100% of final payout authority with the human controller.',
        '',
        'TRANSITION: Next, how does ClaimWise AI surface insights and policy answers across the organization?',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 7: AI SOLUTION 4 — ANALYTICS & ASSISTANT (01:00 | Cum 07:15)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '06 · AI SOLUTION 4 — ANALYTICS & CONVERSATIONAL COPILOT',
      title: 'Finance Analytics Dashboard & Grounded ClaimWise Assistant',
      duration: '01:00',
      cumulative: '07:15',
      slideNum: 7,
    });

    // Left: Finance Analytics Dashboard
    addCard(pptx, s, { x: 0.6, y: 1.42, w: 6.3, h: 5.34, topBarColor: COLORS.cobalt });
    s.addText('Finance Analytics Suite (Finance & Admin Only)', {
      x: 0.84,
      y: 1.62,
      w: 5.82,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 14,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText('analyticsEngine.ts + csvExport.ts + /api/ai/analytics-insights', {
      x: 0.84,
      y: 1.96,
      w: 5.82,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9.5,
      color: COLORS.cobalt,
      margin: 0,
    });

    // 5 KPI tags row
    const kpiBoxes = ['MTD / YTD Spend', 'Pending Liability', 'Avg Turnaround', 'Exception Rate %', 'Duplicate Flags'];
    kpiBoxes.forEach((k, idx) => {
      const kx = 0.84 + idx * 1.18;
      s.addShape(pptx.ShapeType.roundRect, {
        x: kx,
        y: 2.32,
        w: 1.1,
        h: 0.46,
        fill: { color: COLORS.sageLight },
        line: { color: COLORS.azure, width: 0.75 },
        rectRadius: 0.05,
      });
      s.addText(k, {
        x: kx + 0.04,
        y: 2.37,
        w: 1.02,
        h: 0.36,
        fontFace: FONT_UI,
        fontSize: 8.5,
        bold: true,
        color: COLORS.cobaltDark,
        align: 'center',
        valign: 'middle',
        margin: 0,
      });
    });

    s.addText(
      [
        {
          text: '7 Interactive Visualizations: Monthly spend trend, spend by category, spend by department/cost centre, Budget vs. Actual, Top 10 claimants, exception reasons breakdown, and pending claim ageing (0–7, 8–15, 16–30, >30 days).',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'Multi-Dimensional Filtering & CSV/Excel Export: Filter dynamically by date range, department, cost centre, category, or status; export any table in one click.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'AI Insights Panel: Synthesizes filtered KPIs into an executive brief highlighting key trends, top policy exceptions, fraud risks, and recommended actions.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
      ],
      {
        x: 0.84,
        y: 2.98,
        w: 5.82,
        h: 3.6,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.24,
        margin: 0,
      }
    );

    // Right: ClaimWise Assistant
    addCard(pptx, s, { x: 7.12, y: 1.42, w: 5.61, h: 5.34, topBarColor: COLORS.green });
    s.addText('ClaimWise Assistant (Floating Copilot · All Roles)', {
      x: 7.36,
      y: 1.62,
      w: 5.13,
      h: 0.34,
      fontFace: FONT_UI,
      fontSize: 14,
      bold: true,
      color: COLORS.slate900,
      margin: 0,
    });
    s.addText('assistantContext.ts + /api/ai/assistant', {
      x: 7.36,
      y: 1.96,
      w: 5.13,
      h: 0.24,
      fontFace: FONT_MONO,
      fontSize: 9.5,
      color: COLORS.green,
      margin: 0,
    });

    // Example Q&A bubble
    s.addShape(pptx.ShapeType.roundRect, {
      x: 7.36,
      y: 2.34,
      w: 5.13,
      h: 1.42,
      fill: { color: COLORS.canvas },
      line: { color: COLORS.border, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('Employee Query: "What is my hotel limit in Mumbai?"', {
      x: 7.5,
      y: 2.44,
      w: 4.85,
      h: 0.24,
      fontFace: FONT_UI,
      fontSize: 10,
      bold: true,
      color: COLORS.cobalt,
      margin: 0,
    });
    s.addText(
      'Answer: For Grade G2 in Tier-1 city Mumbai, Hotel Accommodation is capped at ₹4,500/night (receipt required).',
      {
        x: 7.5,
        y: 2.72,
        w: 4.85,
        h: 0.45,
        fontFace: FONT_UI,
        fontSize: 10,
        color: COLORS.slate900,
        margin: 0,
      }
    );
    s.addText('Source Cited: Policy Rule · POL-HTL-G2-T1 (expense_policies)', {
      x: 7.5,
      y: 3.3,
      w: 4.85,
      h: 0.32,
      fontFace: FONT_MONO,
      fontSize: 9,
      bold: true,
      color: COLORS.green,
      margin: 0,
    });

    s.addText(
      [
        {
          text: 'Role-Scoped Grounding: Employees receive policy answers matched to their exact Grade & City; Finance/Admin also query live departmental spend & top exception drivers.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
        {
          text: 'Zero Uncited Claims: Server schema enforces structured sources[] citations (Policy Rule, Dataset, or Compliance Engine) rendered visibly beneath every response.',
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 9 },
        },
      ],
      {
        x: 7.36,
        y: 3.96,
        w: 5.13,
        h: 2.6,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.24,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 01:00 (Cumulative 07:15 / 12:00)',
        '',
        'KEY POINTS:',
        '- For Finance Controllers and Admins, our Analytics Dashboard tracks 5 core KPIs and 7 interactive charts including Budget vs Actual and Pending Claim Ageing buckets, with one-click CSV/Excel export.',
        '- Clicking "AI Insights" generates a live management summary of the currently filtered period.',
        '- Across all roles, the floating ClaimWise Assistant answers natural-language questions—policy questions for employees, spend and violation trends for Finance—and strictly displays the underlying source rule or dataset behind every answer.',
        '',
        'TRANSITION: Let us review how we hardened security, API reliability, and desktop installability.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 8: SECURITY, RELIABILITY & DESKTOP PWA (01:00 | Cum 08:15)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '07 · SECURITY, RELIABILITY & DELIVERY ENGINEERING',
      title: 'Production Hardening: Proxy Security, Firestore Rules & Desktop PWA',
      duration: '01:00',
      cumulative: '08:15',
      slideNum: 8,
    });

    const pillars = [
      {
        title: 'API Key Isolation & Quota Resilience',
        tag: 'server.ts · Express Proxy',
        color: COLORS.cobalt,
        bullets: [
          'GEMINI_API_KEY lives strictly in server process.env; browser only calls /api/ai/*.',
          'SHA-256 payload caching avoids redundant Gemini calls on repeated receipts or queries.',
          'Automatic retry + fallback from gemini-3.1-flash-lite to gemini-4-hydrogen on 429/503.',
        ],
      },
      {
        title: 'Eight-Pillar Firebase Firestore Rules',
        tag: 'firestore.rules · RBAC',
        color: COLORS.red,
        bullets: [
          'Global deny-all fallback; verified Firebase Auth email required for cloud reads/writes.',
          'Schema validation blueprints check exact keys, data types, string lengths & INR bounds.',
          'Client payload sanitization strips undefined fields before batch Firestore writes.',
        ],
      },
      {
        title: 'Workflow Auditability & UX Safeguards',
        tag: 'AppContext · ConfirmDialog',
        color: COLORS.amber,
        bullets: [
          'Immutable auditTrail logs every AI extraction override, status change & AI Review verdict.',
          'Targeted role/user notifications alert Managers, Finance, and Employees on transitions.',
          'Confirmation dialogs & mandatory comment modals protect destructive or rejection actions.',
        ],
      },
      {
        title: 'Installable Offline-Ready Desktop PWA',
        tag: 'vite-plugin-pwa · Workbox',
        color: COLORS.green,
        bullets: [
          'Full Web App Manifest + custom app icons allow 1-click desktop & mobile installation.',
          'Workbox precaches UI assets; NetworkOnly rules keep /api/* AI routes & .pptx clean.',
          'Real-time OfflineIndicator banner + loading skeletons keep UX resilient on poor networks.',
        ],
      },
    ];

    pillars.forEach((p, i) => {
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 0.6 + col * 6.2;
      const y = 1.42 + row * 2.7;
      addCard(pptx, s, { x, y, w: 5.93, h: 2.5, topBarColor: p.color });

      s.addText(p.title, {
        x: x + 0.24,
        y: y + 0.2,
        w: 3.75,
        h: 0.34,
        fontFace: FONT_UI,
        fontSize: 13.5,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addText(p.tag, {
        x: x + 4.0,
        y: y + 0.23,
        w: 1.7,
        h: 0.28,
        fontFace: FONT_MONO,
        fontSize: 9,
        bold: true,
        color: p.color,
        align: 'right',
        margin: 0,
      });
      s.addText(
        p.bullets.map((b) => ({
          text: b,
          options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 6 },
        })),
        {
          x: x + 0.24,
          y: y + 0.68,
          w: 5.45,
          h: 1.65,
          fontFace: FONT_UI,
          fontSize: 10.5,
          color: COLORS.slate700,
          lineSpacingMultiple: 1.22,
          margin: 0,
        }
      );
    });

    s.addNotes(
      [
        'TIME TARGET: 01:00 (Cumulative 08:15 / 12:00)',
        '',
        'KEY POINTS:',
        '- Four engineering pillars make ClaimWise AI production-grade:',
        '  1. Security & Resilience: No API keys in frontend code; Express handles rate limits with SHA-256 caching and automatic model fallback.',
        '  2. Database Hardening: Firestore security rules enforce strict field validation and verified authentication.',
        '  3. Governance: Every transition and AI override is recorded in auditTrail, with confirmation modals on critical actions.',
        '  4. Desktop PWA: Using vite-plugin-pwa and Workbox, evaluators can install ClaimWise AI as a standalone desktop app with offline detection.',
        '',
        'TRANSITION: Now let us see all of these technical solutions working together in a 2-minute live walkthrough.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 9: LIVE APPLICATION DEMO WALKTHROUGH (02:00 | Cum 10:15)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '08 · LIVE PRODUCT DEMONSTRATION',
      title: '2-Minute End-to-End Live Demo Runbook (3 Role Acts)',
      duration: '02:00',
      cumulative: '10:15',
      slideNum: 9,
    });

    const acts = [
      {
        act: 'ACT 1 · 00:00 – 00:45',
        role: 'Employee (Aarav Deshmukh · G2)',
        color: COLORS.cobalt,
        steps: [
          'Click "Employee" on redesigned Login Screen.',
          'Open New Claim → load/upload Hotel GST receipt.',
          'Show 9 AI-extracted fields, confidence tags & GSTIN validation.',
          'Trigger inline Policy Exception (Claimed > Permissible), enter justification, run AI Pre-Submission Check (0–100 score) & submit.',
        ],
      },
      {
        act: 'ACT 2 · 00:45 – 01:25',
        role: 'Manager (Priya Nair · G4)',
        color: COLORS.amber,
        steps: [
          'Use Quick Demo Role Switch in sidebar → Manager.',
          'Open Manager Approvals Inbox & select Aarav’s claim.',
          'Inspect Risk Indicators panel (Low/Med/High + duplicate & anomaly checks).',
          'Approve claim forward to Finance queue with manager remark.',
        ],
      },
      {
        act: 'ACT 3 · 01:25 – 02:00',
        role: 'Finance (Vikramaditya Rao · G5)',
        color: COLORS.green,
        steps: [
          'Switch to Finance → open Finance Queue & click "AI Review Agent".',
          'Show draft verdict (Approve with exception), then perform human sign-off.',
          'Open Finance Analytics → trigger "AI Insights" & CSV export.',
          'Ask ClaimWise Assistant a live policy/spend question with cited source.',
        ],
      },
    ];

    acts.forEach((a, idx) => {
      const x = 0.6 + idx * 4.11;
      addCard(pptx, s, { x, y: 1.42, w: 3.91, h: 4.55, topBarColor: a.color });
      s.addText(a.act, {
        x: x + 0.22,
        y: 1.62,
        w: 3.47,
        h: 0.26,
        fontFace: FONT_MONO,
        fontSize: 10,
        bold: true,
        color: a.color,
        margin: 0,
      });
      s.addText(a.role, {
        x: x + 0.22,
        y: 1.92,
        w: 3.47,
        h: 0.36,
        fontFace: FONT_UI,
        fontSize: 13,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addShape(pptx.ShapeType.line, {
        x: x + 0.22,
        y: 2.36,
        w: 3.47,
        h: 0,
        line: { color: COLORS.borderSoft, width: 1 },
      });
      s.addText(
        a.steps.map((st, sIdx) => ({
          text: `${sIdx + 1}. ${st}`,
          options: { breakLine: true, paraSpaceAfter: 10 },
        })),
        {
          x: x + 0.22,
          y: 2.52,
          w: 3.47,
          h: 3.25,
          fontFace: FONT_UI,
          fontSize: 10.5,
          color: COLORS.slate700,
          lineSpacingMultiple: 1.22,
          margin: 0,
        }
      );
    });

    // Bottom Demo Fallback Note
    addCard(pptx, s, {
      x: 0.6,
      y: 6.12,
      w: 12.13,
      h: 0.66,
      fill: COLORS.sageLight,
      borderColor: COLORS.azure,
    });
    s.addText(
      'DEMO READINESS: Pre-seeded with 60 realistic multi-city INR claims + sample hotel/flight invoices + Admin "Reset Demo Data" safeguard for repeatable live runs.',
      {
        x: 0.85,
        y: 6.29,
        w: 11.6,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 10.5,
        bold: true,
        color: COLORS.cobaltDark,
        margin: 0,
      }
    );

    s.addNotes(
      [
        'TIME TARGET: 02:00 (Cumulative 10:15 / 12:00) — SWITCH TO LIVE BROWSER / DESKTOP PWA',
        '',
        'LIVE DEMO CHOREOGRAPHY (KEEP STRICTLY TO 2 MINUTES):',
        '- 0:00–0:45 [Employee]: Switch to App. Click Employee (Aarav). Open New Claim, load the sample Hotel receipt, point out the AI-extracted fields, confidence tags, and GSTIN check. Change amount above limit to show the red Policy Exception card, type justification, click AI Pre-Submission Check, and Submit.',
        '- 0:45–1:25 [Manager]: Click Manager in the sidebar Quick Demo Switch. Open the submitted claim, point out the Risk Indicators panel, and click Approve.',
        '- 1:25–2:00 [Finance]: Switch to Finance, run "AI Review Agent" on the claim, point out the Approve-with-Exception recommendation, then click Verify & Mark Paid. Quickly flash Finance Analytics + "AI Insights" and ask ClaimWise Assistant one question to prove cited grounding.',
        '',
        'TRANSITION: Return to slides to summarize measurable operational impact.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 10: TRADITIONAL VS CLAIMWISE AI IMPACT (00:55 | Cum 11:10)
  // =========================================================================
  {
    const s = pptx.addSlide();
    addSlideChrome(pptx, s, {
      category: '09 · MEASURABLE BUSINESS IMPACT',
      title: 'Traditional Manual Processing vs. ClaimWise AI',
      duration: '00:55',
      cumulative: '11:10',
      slideNum: 10,
    });

    const compRows: PptxGenJS.TableRow[] = [
      [
        { text: 'Capability Area', options: { bold: true, fill: { color: COLORS.cobalt }, color: COLORS.white } },
        { text: 'Traditional Manual Process', options: { bold: true, fill: { color: COLORS.cobalt }, color: COLORS.white } },
        { text: 'ClaimWise AI (AI + Human-in-the-Loop)', options: { bold: true, fill: { color: COLORS.cobaltDark }, color: COLORS.sage } },
      ],
      [
        { text: 'Receipt Data Entry', options: { bold: true } },
        { text: 'Manual typing of all fields from PDFs/photos (5–8 mins/claim).' },
        { text: 'Gemini IDP auto-fills 9 fields in seconds with High/Med/Low confidence tags.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'GST & GSTIN Check', options: { bold: true } },
        { text: 'Sampled manually weeks later; invalid GSTINs leak Input Tax Credit.' },
        { text: 'Real-time 15-char GSTIN regex + 28% GST slab consistency validation at entry.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'Policy Enforcement', options: { bold: true } },
        { text: 'Employees guess Grade G1–G5 & City Tier caps from static PDF manuals.' },
        { text: 'Deterministic checks against 60 rules calculate exact Excess INR & require justification.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'Duplicate & Anomalies', options: { bold: true } },
        { text: 'Rarely caught unless identical invoice numbers are spotted manually.' },
        { text: 'Cross-claim exact + fuzzy duplicate matching, 6-mo spikes, round numbers & split bills.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'Finance Review SLA', options: { bold: true } },
        { text: '5–10 days manual line-by-line audit regardless of claim risk.' },
        { text: 'AI Review Agent drafts decision + reasoning; human verifies high-risk claims in <2 days.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'Policy & Spend Q&A', options: { bold: true } },
        { text: 'Emailing HR/Finance or waiting for monthly Excel pivot tables.' },
        { text: 'ClaimWise Assistant answers live role-scoped questions with explicit cited sources.', options: { fill: { color: COLORS.sageLight } } },
      ],
      [
        { text: 'Audit Governance', options: { bold: true } },
        { text: 'Opaque email approvals with no history of user edits vs invoice.' },
        { text: 'Immutable auditTrail logs AI-suggested vs user-final values & every approval.', options: { fill: { color: COLORS.sageLight } } },
      ],
    ];

    s.addTable(compRows, {
      x: 0.6,
      y: 1.4,
      w: 12.13,
      colW: [2.35, 4.48, 5.3],
      fontFace: FONT_UI,
      fontSize: 9.8,
      color: COLORS.slate900,
      border: { type: 'solid', pt: 0.5, color: COLORS.border },
      valign: 'middle',
      rowH: [0.42, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7],
    });

    s.addNotes(
      [
        'TIME TARGET: 00:55 (Cumulative 11:10 / 12:00)',
        '',
        'KEY POINTS:',
        '- Comparing Traditional Ops vs ClaimWise AI across 7 dimensions:',
        '  - Entry drops from 5–8 minutes to seconds.',
        '  - 100% of invoices receive real-time 15-char GSTIN & GST slab validation before submission.',
        '  - Deterministic rules eliminate policy guesswork and reduce send-backs.',
        '  - Finance review turnaround compresses from 5–10 days to under 2 days while strengthening fraud and audit controls.',
        '',
        'TRANSITION: To wrap up, here are our three key engineering takeaways.',
      ].join('\n')
    );
  }

  // =========================================================================
  // SLIDE 11: KEY ENGINEERING TAKEAWAYS & Q&A (00:50 | Cum 12:00)
  // =========================================================================
  {
    const s = pptx.addSlide();
    s.background = { color: COLORS.cobalt };

    // Top bar
    s.addText('10 · CONCLUSION & KEY ENGINEERING TAKEAWAYS', {
      x: 0.75,
      y: 0.45,
      w: 7.5,
      h: 0.28,
      fontFace: FONT_UI,
      fontSize: 10,
      bold: true,
      color: COLORS.sage,
      margin: 0,
    });
    s.addShape(pptx.ShapeType.roundRect, {
      x: 9.75,
      y: 0.4,
      w: 2.83,
      h: 0.44,
      fill: { color: COLORS.cobaltDark },
      line: { color: COLORS.azure, width: 1 },
      rectRadius: 0.06,
    });
    s.addText('TIME 00:50  |  CUM 12:00 / 12:00', {
      x: 9.82,
      y: 0.49,
      w: 2.69,
      h: 0.26,
      fontFace: FONT_MONO,
      fontSize: 9,
      bold: true,
      color: COLORS.white,
      align: 'center',
      margin: 0,
    });

    s.addText('Responsible AI Built for Enterprise Finance', {
      x: 0.75,
      y: 0.85,
      w: 11.8,
      h: 0.65,
      fontFace: FONT_UI,
      fontSize: 28,
      bold: true,
      color: COLORS.white,
      margin: 0,
    });

    const takeaways = [
      {
        num: '01',
        title: 'Deterministic Math + AI Reasoning',
        body: 'Never let an LLM invent rupee limits or tax rules. Policy tables and regex/ratio guards enforce hard truth; Gemini excels at extraction, explanation, and synthesis.',
      },
      {
        num: '02',
        title: 'Human-in-the-Loop Governance',
        body: 'Amber confidence flags, mandatory exception justifications, AI-vs-human override logs, and Finance final sign-off ensure full accountability and audit readiness.',
      },
      {
        num: '03',
        title: 'Resilient Production Architecture',
        body: 'Server-side API key proxy, SHA-256 caching, automatic multi-model fallback, hardened Firestore rules, and offline-capable Desktop PWA make the system demo- and enterprise-ready.',
      },
    ];

    takeaways.forEach((tk, idx) => {
      const tx = 0.75 + idx * 4.02;
      s.addShape(pptx.ShapeType.roundRect, {
        x: tx,
        y: 1.78,
        w: 3.78,
        h: 3.15,
        fill: { color: COLORS.white },
        line: { color: COLORS.azure, width: 1 },
        rectRadius: 0.08,
      });
      s.addText(tk.num, {
        x: tx + 0.24,
        y: 1.98,
        w: 0.7,
        h: 0.4,
        fontFace: FONT_MONO,
        fontSize: 18,
        bold: true,
        color: COLORS.cobalt,
        margin: 0,
      });
      s.addText(tk.title, {
        x: tx + 0.24,
        y: 2.44,
        w: 3.3,
        h: 0.56,
        fontFace: FONT_UI,
        fontSize: 14,
        bold: true,
        color: COLORS.slate900,
        margin: 0,
      });
      s.addText(tk.body, {
        x: tx + 0.24,
        y: 3.1,
        w: 3.3,
        h: 1.6,
        fontFace: FONT_UI,
        fontSize: 11,
        color: COLORS.slate700,
        lineSpacingMultiple: 1.25,
        margin: 0,
      });
    });

    // Q&A Callout Banner
    s.addShape(pptx.ShapeType.roundRect, {
      x: 0.75,
      y: 5.2,
      w: 11.83,
      h: 1.05,
      fill: { color: COLORS.cobaltDark },
      line: { color: COLORS.sage, width: 1 },
      rectRadius: 0.08,
    });
    s.addText('Thank You · Open for Questions & Technical Discussion', {
      x: 1.0,
      y: 5.34,
      w: 11.3,
      h: 0.38,
      fontFace: FONT_UI,
      fontSize: 17,
      bold: true,
      color: COLORS.white,
      margin: 0,
    });
    s.addText(
      'Ask me about: Receipt OCR Schema · GSTIN & Slab Math · Policy Engine · Duplicate/Anomaly Heuristics · Firestore Eight-Pillar Rules · Desktop PWA',
      {
        x: 1.0,
        y: 5.76,
        w: 11.3,
        h: 0.32,
        fontFace: FONT_UI,
        fontSize: 10.5,
        color: COLORS.sage,
        margin: 0,
      }
    );

    // Footer
    s.addShape(pptx.ShapeType.line, {
      x: 0.75,
      y: 6.55,
      w: 11.83,
      h: 0,
      line: { color: COLORS.azure, width: 1 },
    });
    s.addText(ATTRIBUTION, {
      x: 0.75,
      y: 6.72,
      w: 9.5,
      h: 0.32,
      fontFace: FONT_UI,
      fontSize: 11,
      bold: true,
      color: COLORS.white,
      margin: 0,
    });
    s.addText('Slide 11 / 11', {
      x: 11.08,
      y: 6.72,
      w: 1.5,
      h: 0.32,
      fontFace: FONT_MONO,
      fontSize: 10,
      bold: true,
      color: COLORS.sage,
      align: 'right',
      margin: 0,
    });

    s.addNotes(
      [
        'TIME TARGET: 00:50 (Cumulative 12:00 / 12:00)',
        '',
        'CLOSING TALKING POINTS:',
        '- To summarize our architecture in three takeaways:',
        '  1. Deterministic math + generative AI gives accuracy without hallucinations.',
        '  2. Human-in-the-loop controls and full override logging satisfy Chartered Accountancy and enterprise audit standards.',
        '  3. Multi-model fallback, caching, Firestore rules, and Desktop PWA support make it resilient end to end.',
        '- Thank you! I am now happy to take your questions.',
      ].join('\n')
    );
  }

  const rawBuffer = (await pptx.write({ outputType: 'nodebuffer' })) as Buffer;
  const zip = await JSZip.loadAsync(rawBuffer);

  // 1. Remove any [Content_Types].xml <Override> entries pointing to non-existent parts (e.g. phantom slideMaster2..11)
  const contentTypesFile = zip.file('[Content_Types].xml');
  if (contentTypesFile) {
    const ctXml = await contentTypesFile.async('string');
    const cleanedCtXml = ctXml.replace(/<Override\s+PartName="\/([^"]+)"[^>]*\/>/g, (full, partPath) =>
      zip.file(partPath) ? full : ''
    );
    zip.file('[Content_Types].xml', cleanedCtXml);
  }

  // 2. Ensure strictly unique <p:cNvPr id="..."/> values per slide XML (fixes PptxGenJS table ID collision)
  for (const fileName of Object.keys(zip.files)) {
    if (/^ppt\/slides\/slide\d+\.xml$/.test(fileName)) {
      const slideXml = await zip.file(fileName)!.async('string');
      let nextId = 1;
      const fixedSlideXml = slideXml.replace(/<p:cNvPr\s+id="\d+"/g, () => `<p:cNvPr id="${nextId++}"`);
      zip.file(fileName, fixedSlideXml);
    }

    // 3. Convert line breaks inside Speaker Notes into distinct <a:p> paragraphs
    if (/^ppt\/notesSlides\/notesSlide\d+\.xml$/.test(fileName)) {
      const notesXml = await zip.file(fileName)!.async('string');
      const fixedNotesXml = notesXml.replace(
        /(<p:ph type="body" idx="1"\/>[\s\S]*?<a:lstStyle\/>)<a:p><a:r><a:rPr([^>]*)\/><a:t>([\s\S]*?)<\/a:t><\/a:r><a:endParaRPr([^>]*)\/><\/a:p>/,
        (_m, prefix, rPrAttrs, rawText, endAttrs) => {
          const lines = rawText.split(/\r?\n/);
          const paragraphs = lines
            .map((line: string) =>
              line.length > 0
                ? `<a:p><a:r><a:rPr${rPrAttrs}/><a:t>${line}</a:t></a:r><a:endParaRPr${endAttrs}/></a:p>`
                : `<a:p><a:endParaRPr${endAttrs}/></a:p>`
            )
            .join('');
          return `${prefix}${paragraphs}`;
        }
      );
      zip.file(fileName, fixedNotesXml);
    }
  }

  const finalBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  const outDir = path.resolve(process.cwd(), 'public');
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, 'ClaimWise_AI_Capstone_Presentation.pptx');
  fs.writeFileSync(outPath, finalBuffer);
  console.log(`Generated & validated PowerPoint presentation at: ${outPath}`);
}

generatePresentation().catch((err) => {
  console.error('Failed to generate PPTX:', err);
  process.exit(1);
});
